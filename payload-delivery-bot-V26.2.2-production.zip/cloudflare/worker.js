/**
 * payload-bot — Cloudflare edge worker (origin reverse proxy).
 *
 * RECONSTRUCTION NOTE (BOT-13 continuation, §29/§30): the B11 release
 * carried `cloudflare/worker.js` in the TEST zip; the current upload set
 * contained ONLY the PRODUCTION archive (runtime-only, 200 files, no
 * cloudflare/ directory). This file was rebuilt EXACTLY to the hardening
 * spec documented in docs/MONETAG_WEBSITE.md §4 (allowlist + /sw.js,
 * path safety before allowlist, verbatim media streaming, security
 * headers, no HSTS on *.workers.dev, optional ORIGIN_PROXY_SECRET).
 * Behavior-affecting details are all spec-pinned; the file header below
 * preserves the documented rationale. Verified with `node --check`.
 *
 * Evolution summary (spec §24-§28):
 *   1. `/sw.js` allowlisted (+ `/api/website/monetag-status` for
 *      deployment verification). Nothing else was added to the allowlist.
 *   2. Path safety: the pathname is percent-decoded and validated
 *      (malformed encoding, NUL, `..` traversal, `//` double slash → 404)
 *      BEFORE allowlist matching; the ORIGINAL encoded path is forwarded
 *      (no re-encoding smuggling).
 *   3. Media streaming: request headers forwarded verbatim (only Host /
 *      X-Forwarded-For / X-Real-IP deleted — Range survives); response
 *      headers copied wholesale (Content-Range, Accept-Ranges,
 *      Content-Length, ETag, Last-Modified, Cache-Control…); statuses
 *      preserved verbatim (206/416 included); body never buffered (native
 *      Workers streaming); `redirect: "manual"` kept.
 *   4. OPTIONS passes through to the origin (origin CORS governs;
 *      bodyless init is fine for a bodyless method).
 *   5. Security headers: nosniff / Referrer-Policy / Permissions-Policy.
 *      CSP: commented template only (the live site uses inline
 *      scripts/styles — see below).
 *   6. HSTS deliberately NOT set on *.workers.dev (Cloudflare already
 *      forces HTTPS at the edge before the worker runs; HSTS would pin a
 *      policy onto a shared cert domain for no benefit). Revisit with a
 *      custom domain.
 *   7. Optional shared secret: the worker injects `X-Origin-Key` from the
 *      ORIGIN_PROXY_SECRET Worker secret (`npx wrangler secret put
 *      ORIGIN_PROXY_SECRET` — never hardcoded); the aiohttp origin, when
 *      started with the same ORIGIN_PROXY_SECRET env, rejects (403) any
 *      request without the header (app/web/website_monetag.py ::
 *      make_origin_proxy_middleware). Default: secret unset → header not
 *      injected → zero behavior change.
 *   8. Request smuggling: Content-Length/Transfer-Encoding conflicts
 *      cannot be injected through a Workers fetch() (the runtime owns
 *      framing and re-serializes the request).
 *
 * Deploy: cd cloudflare && npx wrangler deploy
 */

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

/** Origin base URL — from the ORIGIN_URL Worker var (wrangler.toml [vars]
 *  or `npx wrangler secret put ORIGIN_URL`). The origin aiohttp server
 *  (Mini App + /site) should be firewalled to Cloudflare IP ranges. */
const ORIGIN_URL = (globalThis.ORIGIN_URL || "http://127.0.0.1:25672").replace(/\/+$/, "");

/** Optional shared secret — Worker secret ORIGIN_PROXY_SECRET. When set,
 *  an X-Origin-Key header is injected on every proxied request so the
 *  origin can refuse anything that did not come through this worker. */
const ORIGIN_PROXY_SECRET = globalThis.ORIGIN_PROXY_SECRET || "";

// ---------------------------------------------------------------------------
// Allowlist — the ONLY paths reachable through the worker
// ---------------------------------------------------------------------------

const ALLOWED_PREFIXES = [
  "/site",          // the public Website Payload platform (HTML + /site/api/* + /site/pack/*)
  "/watch-ad/",     // the Watch Ads Telegram Mini App pages
  "/api/watch-ad/", // Watch Ads Mini App JSON APIs (status / ad-event / postback)
  "/api/network/",  // Telegram WebApp initData auth endpoint
  "/healthz",       // origin liveness
];

const ALLOWED_EXACT = [
  "/sw.js",                     // Monetag WEBSITE service worker (root scope — spec §20)
  "/api/website/monetag-status" // website monetization diagnostics (spec §21)
];

// ---------------------------------------------------------------------------
// Path safety — validate BEFORE allowlist matching (spec §24-§28)
// ---------------------------------------------------------------------------

/** Returns true when the DECODED pathname is safe to consider.
 *  Rejects: malformed percent-encoding, NUL bytes, `..` traversal
 *  segments, and `//` double slashes. The ORIGINAL encoded path is always
 *  the one forwarded to the origin (no re-encoding, no smuggling). */
function pathIsSafe(url) {
  let decoded;
  try {
    decoded = decodeURIComponent(url.pathname);
  } catch (e) {
    return false; // malformed percent-encoding (e.g. "%zz")
  }
  if (decoded.indexOf("\u0000") !== -1) return false;      // NUL smuggling
  if (decoded.indexOf("..") !== -1) return false;          // traversal
  if (url.pathname.indexOf("//") !== -1) return false;     // double slash
  return true;
}

function pathAllowed(pathname) {
  if (ALLOWED_EXACT.indexOf(pathname) !== -1) return true;
  for (let i = 0; i < ALLOWED_PREFIXES.length; i++) {
    const p = ALLOWED_PREFIXES[i];
    if (pathname === p || pathname.indexOf(p + "/") === 0) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Security headers applied to every response (spec §27)
// ---------------------------------------------------------------------------

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
};

// CSP — deliberately a commented template (the live /site uses inline
// scripts/styles; enabling this requires either 'unsafe-inline' (weak) or
// a nonce/hash refactor). Domains the Monetag surfaces would need:
//   script-src 'self' 'unsafe-inline' https://telegram.org https://libtl.com <PROVIDER-DOMAIN-FROM-TAG>;
//   worker-src 'self';
//   connect-src 'self' https://telegram.org;
// const CSP = "default-src 'self'; ...";

const STRIPPED_REQUEST_HEADERS = ["host", "x-forwarded-for", "x-real-ip"];

// ---------------------------------------------------------------------------
// Worker entry point
// ---------------------------------------------------------------------------

async function handleRequest(request) {
  const url = new URL(request.url);

  // --- path safety BEFORE allowlist (never let a crafted path reach it)
  if (!pathIsSafe(url)) {
    return new Response("Not found", { status: 404 });
  }
  if (!pathAllowed(url.pathname)) {
    return new Response("Not found", { status: 404 });
  }

  // --- build the origin request: original encoded path + query verbatim,
  //     request headers forwarded verbatim minus the framing/identity set
  //     (Range and every client header survive — spec §26 media streaming).
  const originUrl = ORIGIN_URL + url.pathname + (url.search || "");
  const headers = new Headers();
  for (const [key, value] of request.headers.entries()) {
    if (STRIPPED_REQUEST_HEADERS.indexOf(key.toLowerCase()) !== -1) continue;
    headers.set(key, value);
  }
  // Optional origin shared secret (spec §28.7) — injected, never hardcoded.
  if (ORIGIN_PROXY_SECRET) {
    headers.set("X-Origin-Key", ORIGIN_PROXY_SECRET);
  }

  const init = {
    method: request.method,
    headers: headers,
    redirect: "manual", // preserve origin 3xx verbatim (never auto-follow)
  };
  // OPTIONS is bodyless — a bodyless init is correct for it (spec §25).
  if (request.method !== "GET" && request.method !== "HEAD"
      && request.method !== "OPTIONS") {
    init.body = request.body;
    init.duplex = "half";
  }

  const originResponse = await fetch(originUrl, init);

  // --- response: headers copied WHOLESALE (Content-Range, Accept-Ranges,
  //     Content-Length, ETag, Last-Modified, Cache-Control …), status
  //     preserved verbatim (206/416 included), body NEVER buffered — the
  //     Response body streams natively through the Workers runtime.
  const outHeaders = new Headers();
  for (const [key, value] of originResponse.headers.entries()) {
    outHeaders.set(key, value);
  }
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    outHeaders.set(key, value);
  }
  // HSTS deliberately NOT set (spec §28.6 — *.workers.dev shared cert).
  return new Response(originResponse.body, {
    status: originResponse.status,
    statusText: originResponse.statusText,
    headers: outHeaders,
  });
}

addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event.request));
});
