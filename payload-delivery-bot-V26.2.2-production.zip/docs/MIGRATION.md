# Migration & Upgrade Guide — PHASE 8 (schema v27 → v28)

## Why v28

Production evidence (bot.log 22 + the operator's report):

1. **The >9-messages incident.** A manual re-index of storage channel
   `-1004460709020` reported `processed=9 indexed=0 duplicates=8` and
   "finished successfully" while the Storage Center showed `files=1077`.
   Root causes found in the PHASE 0 audit:
   * `REINDEX_DEFAULT_COUNT = 500` silently truncated Full Reindex
     first-scans on channels with more history, then reported
     "Reindex Complete" (the fetch-batch-then-claim-done bug class).
   * The auto-scan path wrote `last_scanned = latest` even when it stopped
     early (per-cycle cap / history gap / bot-blocked), permanently
     skipping unscanned messages.
   * NOTHING compared the 1077 DB records against the live channel — the
     ~1068 records whose source messages no longer existed were invisible.
2. **Dead Force-Join links.** Stored invite links were never verified
   (only the CHANNEL was); expired/revoked links kept producing Join
   buttons. All 9 channels were simultaneously declared
   `INVALID (Chat not found)` at startup, repeatedly, with no persisted
   health state.

## What changes

### Indexing
* `count=None` (the default for every manual scan) means UNBOUNDED within
  the requested range — the 500 cap is replaced by a 2,000,000 runaway
  guard, and hitting it is a FAILURE.
* Durable job records (`index_job:<channel_id>`) persist mid-scan progress
  every 25 messages — an interrupted scan RESUMES from its exact point
  (backward scans resume downward). "Resume" appears in the Index menu
  whenever an interrupted job exists.
* Terminal states are truthful: `SCAN_COMPLETE` only when the range was
  genuinely covered; `SCAN_STOPPED` (admin, resumable), `SCAN_FAILED`
  (channel inaccessible / latest unverifiable — cursor never changed),
  `SCAN_PARTIAL` (cap / history gap — resumable).
* Probe semantics: a transient Telegram error is `unknown`, never
  "missing" (spec §19 applied to indexing).
* Auto-scan persists the furthest message ACTUALLY processed.

### Verification + reconciliation (NEW)
* Storage Center → Index → **Verify Index**: read-only
  source↔DB↔payload verification with the full counter vocabulary.
* **Reconcile**: applies the safe repairs (index missing media, atomic
  in-place file_id repair, mark unavailable, recover). Never deletes;
  never touches payload relationships; identity discipline refuses
  ambiguous merges.
* `indexed_files.source_status`: NULL = legacy = available;
  `'unavailable'` = verification-confirmed dead source.

### Force-Join link health (NEW)
* Every stored invite link is verified via `get_chat_invite_link`
  (expired / revoked / belongs-to-this-channel), cached for 300s
  (configurable), persisted in `force_join_channels.link_health`.
* Users never receive a dead Join button — they see
  "⚠️ this channel's join link is temporarily unavailable" instead.
* Auto-repair (default ON): create → verify → atomic store → revoke old.
  A failed repair changes nothing.
* Startup emits ONE aggregate health line; raw per-channel
  "INVALID (Chat not found)" warnings no longer repeat (state-change
  logging only).
* Custom links are Telegram-verified where possible
  (`link_validation_status`: syntax_valid / telegram_verified / expired /
  revoked / unverifiable).

## Upgrade steps

1. **Back up the database** (`payload_bot.db`) and any custom `.env`.
2. Deploy the WHOLE package directory (run.py, bot.py, app/, docs/,
   requirements.txt). Copying `bot.py` alone is no longer supported —
   `app/core/*` are hard imports.
3. `pip install -r requirements.txt` (unchanged dependencies).
4. Restart: `python run.py` (or `python bot.py` — identical).
5. On startup the v28 migration applies automatically and idempotently
   (ADD COLUMN only where missing; CREATE INDEX IF NOT EXISTS; INSERT OR
   IGNORE setting seeds). Existing rows keep NULL = legacy-available
   semantics. Nothing is dropped, renamed, or rewritten.
6. Recommended post-upgrade actions:
   * Storage Center → Index → **Full Reindex** per channel (walks the
     complete history; refreshes stale file_ids in place — required after
     any bot-token change).
   * Storage Center → Index → **Verify Index**, review the report, then
     **Reconcile** — this converts the "files=1077 vs 9 live" confusion
     into an honest available/unavailable split.
   * Force Join → Manage Channels → confirm each row shows
     "✅ Healthy" or an actionable link state; run Test Channel on any
     flagged channel.

## Rollback

Restore the backed-up database and the previous `bot.py` deployment. v28
columns are additive — a v27 build simply ignores them (the extra
columns/indexes are harmless to older code). The only v28-only data is the
job records, verification reports, and link-health states, all of which
regenerate on demand.

## Compatibility guarantees

* Every existing payload ID, file ID, user ID, channel ID, setting,
  referral state, Watch Ads state, admin permission and session survives
  untouched (the regression battery proves it: 1,199 pre-existing checks
  still pass, plus 77 new PHASE 8 checks).
* Delivery behavior (including the PHASE 7 HOTFIX token-change
  self-recovery) is unchanged.
* Watch Ads remains server-authoritative; the Mini App HTTP server is
  unchanged.

---

# Migration & Upgrade Guide — NETWORK PLATFORM (schema v28 → v29)

## Why v29

The Network Platform (multi-bot expansion) needs its own durable state:
bot registry metadata + encrypted credentials, user↔bot reachability
memberships, the points ledger + point unlocks, Global Payload Links,
routing events, and the network broadcast job/delivery tables.

## What changes

* **10 new tables** (all created via `CREATE TABLE IF NOT EXISTS` —
  identical on fresh and existing databases):
  `network_bots`, `network_bot_credentials`, `user_bot_memberships`,
  `points_ledger`, `point_unlocks`, `global_payload_links`,
  `network_routing_events`, `broadcasts`, `broadcast_bot_jobs`,
  `broadcast_deliveries` (+ their indexes).
* **9 setting seeds** via `INSERT OR IGNORE` (admin values are never
  overwritten): `network_enabled`, `max_registered_bots_per_user=5`,
  `points_per_bot_registration=5`, `max_registration_reward_per_user=25`,
  `points_access_enabled=1`, `payload_point_cost=1`,
  `network_health_check_interval=300`,
  `network_broadcast_rate_per_bot=25`,
  `network_broadcast_confirm_threshold=1000`.
* **No existing table, column, or row is touched.** The legacy
  `scheduled_broadcasts` system (single-bot broadcasts) is untouched and
  fully functional; the Network Broadcast engine uses its OWN tables.

## Upgrade procedure (existing Phase 8 deployment)

1. Back up the database file (standard practice before any migration).
2. Deploy the whole new package (bot.py + app/ + docs + tests) — the
   `app/` directory is a hard import.
3. Set `NETWORK_TOKEN_ENCRYPTION_KEY` (see `.env.example`) BEFORE the
   first start with network bots (tokens encrypted under a key can only
   be decrypted with the same key; unset → per-process derivation with
   `key_version=-1`).
4. Start the bot. The v29 migration applies automatically and
   idempotently; the log line `Applied v29 migrations (NETWORK PLATFORM…)`
   confirms it.
5. Verify: `/network` as a user opens My Network; the admin panel's
   🌐 Network Control opens the control center.

## Rollback

The migration is additive-only: restoring the previous package with a
database backup is a full rollback (the v29 tables are ignored by the
v28 code). No v29 change mutates pre-existing data.

## Migration tests (executed)

* Fresh database → stamped v29 + all 10 tables + seeds (`H1`).
* Existing v28 database → upgraded to v29 with legacy data preserved
  (`H2`).
* Migration executed twice → idempotent, clean (`H3`).

See `docs/NETWORK.md` for the platform architecture.

---

# APPENDIX — the v30 → v33 additive chain (WEBSITE phases + GAP-CLOSURE)

The migration discipline is unchanged across the whole chain: every step
is ADDITIVE and IDEMPOTENT, existing production data survives untouched,
and the chain is re-verified from a fresh database by the regression
battery (`test_media_phase*.py` pin the schema constant; the migration
chain itself is exercised on every clean test database).

## v30 → v32 (WEBSITE PHASES 1–5)

* v30/v31: website listings + website settings tables, stream settings.
* v32: website payload metadata, published listings, thumbnails, the
  Media Gateway settings keys, Watch Ads schema verify views.

## v32 → v33 (GAP-CLOSURE — categories + ads platform)

New tables (additive only):

* `website_categories` — configurable categories (name/slug/icon/order/
  enabled/visible/description/age_restricted), seeded with Movies /
  Anime / 18+ / Shorts.
* `website_payload_categories` — payload → category membership
  (references EXISTING listing rows; never duplicates media; the
  canonical Payload stays authoritative).
* `ad_campaigns`, `ad_creatives`, `ad_placements`, `ad_events`,
  `ad_exempt_users`, `ad_frequency_state` — the centralized ads platform
  (campaigns → creatives → placements; server-side frequency; analytics).

New setting seeds: default category rows, ad placement defaults
(all OFF), ads defaults. No pre-existing column or row is mutated.

## Upgrade / rollback (v32 → v33)

1. Deploy the gap-closure package over the existing installation.
2. Start the bot — the migration applies automatically and idempotently
   (`Database migrated -> version 33` in the log).
3. Verify: the Website admin panel shows Categories and Ads Management;
   the site feed renders category chips.
4. Rollback: restore the previous package + a database backup (the v33
   tables are ignored by the v32 code). Additive-only means a v32 backup
   is a complete rollback.

## Migration tests (executed)

* Fresh database → full v2 → v33 chain, stamped v33, all tables +
  seeds present (every suite constructs a fresh DB).
* The v32 → v33 step is exercised on every clean test database;
  `test_media_phase2.py` J1 / `test_watch_ads.py` pin
  `SCHEMA_VERSION == 33`; `test_botv13_phase8.py` S1 stamps the meta
  row at 33; the full 2,470-check battery is green.

---

# v34 — TRUSTED FILE DELIVERY (schema v33 → v34)

## What changes

New tables (additive, `CREATE TABLE IF NOT EXISTS`, idempotent):

* `file_delivery_bot` — the platform-owned File Delivery Bot singleton
  (identity + the VAULT-ENCRYPTED credential blob + status/storage
  access/worker state; plaintext tokens never touch this table).
* `network_delivery_groups` — exactly ONE private Delivery Group per
  Network Bot (UNIQUE `network_bot_id` + UNIQUE
  `delivery_group_chat_id`); statuses DELIVERY_SETUP_REQUIRED /
  DELIVERY_VERIFYING / DELIVERY_READY / DELIVERY_DEGRADED /
  DELIVERY_UNAVAILABLE; JSON `checks` detail + `verified_at`.
* `delivery_jobs` — durable relay delivery state machine (CREATED →
  RELAY_CREATING → RELAYED → DELIVERING → DELIVERED → DELETE_PENDING →
  DELETED + FAILED / EXPIRED) with attempts, max_attempts,
  next_retry_at, relay/storage/group refs and timestamps.
* `control_audit_events` — safe structured Control Bot audit trail
  (event names + ids, never secrets).

New columns on `network_bots` (nullable/defaulted):

* `management_mode` TEXT DEFAULT 'USER_OWNED' (USER_OWNED |
  PLATFORM_MANAGED — spec §27)
* `credential_control` TEXT DEFAULT 'OWNER' (OWNER | PLATFORM)
* `created_via` TEXT DEFAULT '' (user_flow | create_wizard |
  admin_control_bot)

New setting seeds: `delivery_relay_ttl_seconds=900`,
`delivery_max_attempts=5`, `delivery_retry_base_seconds=30`,
`delivery_sweep_interval_seconds=60`.

## Upgrade / rollback (v33 → v34)

1. Deploy the file-delivery package over the existing installation.
2. Start the bot — the migration applies automatically and idempotently
   (`Database migrated -> version 34` + `Applied v34 migrations`).
3. Existing network bots: fully preserved (rows, credentials, points,
   analytics). Their legacy `capabilities` value is retained as history
   only; routing now requires a verified Delivery Group, so each
   existing bot shows DELIVERY_SETUP_REQUIRED until its owner completes
   group setup. No +5 is re-awarded (legacy-reward guard, §62).
4. Configure the File Delivery Bot (Control Bot → Add Token or
   FILE_DELIVERY_BOT_TOKEN) and set NETWORK_GLOBAL_LINK_SIGNING_KEY for
   new-link minting.
5. Rollback: restore the previous package + a database backup (the v34
   tables/columns are ignored by the v33 code).

## Migration tests (executed)

* Fresh database → full v2 → v34 chain, stamped v34, all new tables +
  columns + seeds present (`test_file_delivery.py` A1-A8).
* v33 database with a pre-existing bot + payload upgraded in place:
  data preserved, management metadata backfilled, old bot left with no
  delivery group (setup required) — A5-A8.
* `test_architecture.py` I1/I3, `test_architecture_decoupling.py`
  K1/K3, `test_botv13_phase8.py` S1, media/watch-ads schema pins all
  updated to the v34 chain and green.
