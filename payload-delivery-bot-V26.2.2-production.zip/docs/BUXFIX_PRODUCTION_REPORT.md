# BOT-26 — UX release production fixes (B18_B23_UX_FIXED)

Baseline: `payload-bot_PRODUCTION_B18_B23_UX.zip`
(SHA-256 `8bf4448b4e4ae5d5150c2c998ccdea3d73b898e9cc9fc4b3f3bdf19038961e59`)
— all work applied IN PLACE on that baseline (no rebuild, no B19, no
renames).

## ISSUE A — Delivery Group Guard NoneType crash: FIXED

Production evidence (bot-26.log, twice):

```
DELIVERY_GROUP_GUARD_ERROR
  app/network/lifecycle.py:446 network_delivery_group_guard
  app/presentation/telegram/delivery_ui.py:761
    state = context.user_data.get(_DG_STATE_KEY) or {}
AttributeError: 'NoneType' object has no attribute 'get'
```

Root cause: A.2.4 routes CHANNEL posts into the detection handler. A
channel post carries no user, so python-telegram-bot provides a context
whose `user_data` is **None** — the plain `.get()` raised and the guard
logged the error on every channel post in the delivery channel
(bot-26.log MSG 10/11 in `-1003849433039`).

Fix (`app/presentation/telegram/delivery_ui.py`):

```python
state = (getattr(context, "user_data", None) or {}).get(
    _DG_STATE_KEY) or {}
```

The preferred None-safe form; the guard is NOT globally suppressed —
with a normal dict the behavior is byte-identical, and with
`user_data=None` the wizard key simply cannot be pending (the durable
DB record / explicit `/setup` still drive channel detection exactly as
before — the A.2.3 trust model is untouched).

Regression coverage (`tests/test_buxfix_production.py` §1, 10 checks):
normal dict + state → still verifies; `user_data=None` → no exception
(the durable record still drives verification); missing `_DG_STATE_KEY`
→ empty state silent return; `chat_not_found` → honest NOT READY result
(never success); the guard wrapper catches a raising handler;
source-pins the None-safe form + no bare `context.user_data.get` on the
detection path.

## ISSUE B — Website solid-green rendering: FIXED (root cause in the
site's own HTML — NOT Monetag, NOT the service worker)

Production evidence: Telegram Android WebView screenshot — solid
`#10B981` main area, B23 bottom nav visible, no site content; server
returning `GET /site 200 99407` (and `/site/search` — the identical
size is the Force-Join gate page, byte-identical for both paths).

### Investigation (layer by layer)

* **Layer 1 — server HTML**: `/site` and `/site/search` DO produce the
  expected shell (title, header, main, footer, B23 nav bootstrap) —
  but the `<body>` tag was **malformed**: `html.py::_page` emitted
  `</head><body data-site-root="/site"` **without the closing `>`**,
  immediately followed by `<a class="skip" href="#main">`.
* **Layer 2 — CSS**: no accidental `position:fixed;inset:0;background:
  #10b981` overlay exists — but `.skip` (the skip-link utility) carries
  `position:absolute;left:-9999px;top:0;z-index:100;background:var(
  --accent-dk)` and `html` sets no background of its own.
* **Layer 3 — JS**: no full-screen element is created by the site's
  JS; `#wintro` auto-hides; `#navprog` is a 2px bar.
* **Layer 5 — Monetag**: the sw.js/ad-tag layer was investigated and
  isolated (see §Monetag isolation below) — it is NOT the green screen.

### Root cause (browser-reproduced on the baseline BEFORE the fix)

The HTML5 parser absorbs an unclosed tag's following markup as
ATTRIBUTES: the `<a class="skip" href="#main">` start tag became body
attributes, so **the `<body>` element itself received
`class="skip"` (and `href`)** and the skip anchor never existed. Then:

1. `.skip` applied to the WHOLE BODY: `position:absolute;
   left:-9999px` — every page's content (header, main, footer) shifted
   9999px off-screen (leftward overflow is not scrollable);
2. `.skip`'s `background:var(--accent-dk)` (`#10b981`) overrode body's
   layered dark background (specificity 0,1,0 > 0,0,1) and — because
   `html` has no background — **propagated to the canvas: the entire
   viewport painted SOLID #10B981**;
3. `position:fixed` children (`#bnav` bottom nav, `#toasts`, `#navprog`)
   escape the body shift and stayed visible.

That is EXACTLY the production screenshot: Telegram top bar → solid
green → visible bottom nav, zero site content. Baseline reproduction
(real Chromium, dark theme, phone viewport):
`bodyClass="skip"`, `bodyPosition=absolute`, `bodyLeft=-9999px`,
`bodyBg=rgb(16,185,129)`, header/main at x=-9983, `#bnav` fixed
visible — and the pixel screenshot matches the production report.

### Fix

`app/web/site/html.py::_page` — the `<body>` tag is now well-formed
(`</head><body data-site-root="/site">`) and the skip link is a real
`<a class="skip" href="#main">` again. Post-fix browser verification:
`bodyClass=null`, `bodyPosition=static`, `bodyBg=rgb(5,6,10)`,
header/main/cards visible, `#bnav` 4 tabs visible, zero
viewport-covering solid-accent elements (geometry scan), zero console
errors — on `/site`, `/site/search?q=` and the Force-Join gate page
(the exact production scenario).

### Follow-on responsive defect (masked by the green screen, now fixed)

With the body fixed, the B23 browser suite's T9 320px check surfaced a
real 7px horizontal overflow the broken baseline had masked (the
content used to be off-screen): the ambient-mode canvas was laid out
`inset:-8%;width:116%` — LAYOUT overflow. It now fills the wrap exactly
(`inset:0;100%`) and the existing `blur(46px)` provides the surrounding
glow (ink overflow — never scrollable; a transform scale would NOT
have worked: the transformed box of an absolutely-positioned element
still contributes to scrollable overflow). T9 → 27/27.

## Monetag isolation: DIAGNOSTIC MECHANISM ADDED (default unchanged)

`WEBSITE_MONETAG_ENABLED` (env, default **true/enabled** — production
behavior unchanged):

* `true` (default): provider sw.js VERBATIM at `/sw.js`, the
  configured ad tag injected into `/site` `<head>` (as before);
* `false`/`0`/`no`/`off` (diagnostic): NO ad tag injected; `/sw.js`
  serves the DIAGNOSTIC NO-OP service worker (self-unregistering — it
  actively removes a previously-registered third-party worker from
  controlling clients and reloads them, so a stale shell cannot
  persist); the status endpoint reports `enabled:false`; the startup
  log warns loudly.

The Monetag CONFIGURATION (db setting / env) is untouched by the flag
and resumes on re-enable. The Telegram Mini App (Watch Ads) surface is
never affected. Because the green screen was fully reproduced and
fixed server-side, the production default stays ENABLED — the switch
exists for future isolation needs. Covered by
`tests/test_buxfix_production.py` §4 (8 checks) + browser G8.

## Service-worker / cache hardening

* **Dynamic /site HTML** (`/site`, `/site/*`, `text/html`, 200) now
  answers `Cache-Control: no-store, no-cache, must-revalidate,
  max-age=0` + `Pragma: no-cache` + `Expires: 0` — implemented as the
  innermost middleware (`make_site_html_cache_middleware`) so the
  Monetag head-injection rebuild carries the headers through. Media
  streams, HLS, thumbs, packs and JSON APIs keep their own
  content-appropriate policies (surgical match).
* **`/sw.js`** keeps `Cache-Control: no-store` — a redeployed provider
  worker is always picked up on the next navigation.
* **Cache-busting**: the site's JS/CSS is INLINE in the HTML (no
  app-owned external assets), so the HTML no-store headers are the
  COMPLETE freshness contract — no asset versioning needed (the brief
  §9 explicitly allows this).
* **SW safety**: the app shell itself registers no service worker
  (only the operator ad tag ever registers the provider worker); the
  HTML is no-store so no intermediary can hold a stale shell; the
  diagnostic no-op (above) is the recovery path for a client
  controlled by a third-party worker.

## Delivery-channel verification: PRESERVED

`chat_not_found` still maps to the honest
unavailable/degraded state (`DELIVERY_GROUP_VERIFY_FAILURE` →
`DELIVERY_GROUP_REVERIFY degraded=0 unavailable=1 ready=0`) — no
exception, no worker crash, no false success, channel terminology and
the A.2 channel-support migration fully intact (regression-pinned in
§1g and §7 of the new suite).

## B23 UX: PRESERVED

All 48 existing battery suites remain green (plus the new
`test_buxfix_production.py` → 49); browser chains afix 13/13, b23
27/27, final1 11/11, b22 32/32 + the new buxfix acceptance 26/26
(phone-viewport screenshot-level: shell, search, gate page, no-green
geometry scan, cache contract, sw.js, zero console errors).
