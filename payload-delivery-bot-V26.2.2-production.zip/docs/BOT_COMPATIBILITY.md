# bot.py Compatibility Strategy — ARCHITECTURE PHASE

## What bot.py is now

`bot.py` (27,751 lines, down from **34,068** — an **18.5% reduction** with
every moved line physically relocated, not deleted functionality) is the
**compatibility facade + bootstrap boundary** of the platform:

1. **Compatibility wrappers** — every extracted function keeps a thin
   `bot.py` wrapper that reads the CURRENT module globals at call time and
   delegates to the canonical implementation in `app/*`. This is what
   preserves the regression suites' monkey-patching semantics exactly
   (`B.db = …`, `B.force_join_active = …`, `B._unjoined_for_access = …`,
   `B._deliver_files_core = …`, `B.fetch_channel_media = …`,
   `B.DELIVERY_RETRY_*`, …).
2. **Source-pinned frozen zones** — code whose bodies are asserted
   verbatim inside `bot.py` by the 12 regression suites (~181 literal
   source-text patterns; see `docs/ARCHITECTURE_AUDIT.md` §3). Moving these
   would break the frozen regression contract without changing behavior.
3. **Bootstrap wiring** — `build_application` / `main` / `post_init` /
   `post_shutdown` / network service singletons / the aiohttp route
   registration.
4. **The legacy admin UI** — panels, wizards, text/media input handler,
   the `on_callback` branch chain (pinned), the Mini App HTML.

**The rule going forward: NO new business logic may be added to bot.py.**
New code goes into `app/core/*` (business), `app/storage/*` (data),
`app/bot/*` / `app/web/*` (adapters), wired through the wrappers.

## What has moved (canonical homes)

| Responsibility | New canonical home | bot.py keeps |
|---|---|---|
| DB connection core + write lock | `app/storage/database.py` (`DatabaseBase`) | subclass `Database` |
| Migration primitives (column/table/version) | `app/storage/migrations.py` | pinned `_migrate` chain (v1→v29) |
| Users repo | `app/storage/repositories/users.py` | — |
| Media/indexed files/storage channels/reindex state | `app/storage/repositories/media.py` | — |
| Payloads/collections/aliases + fuzzy search | `app/storage/repositories/payloads.py` | — |
| Force-join channels/links/health/dashboards | `app/storage/repositories/force_join.py` | — |
| Referral campaigns/tokens/unlocks/progress/access events | `app/storage/repositories/referrals.py` | — |
| Watch-ads settings/session reads/postback logs/stats | `app/storage/repositories/watch_ads.py` | pinned session/reward transaction methods |
| Network bots/credentials/memberships/points/links/events | `app/storage/repositories/network.py` | — |
| Broadcasts (network + legacy scheduled) | `app/storage/repositories/broadcasts.py` | — |
| Pending deletions/delivery records/views/stats | `app/storage/repositories/deliveries.py` | — |
| Settings/start-help/dashboard template/branding | `app/storage/repositories/settings.py` | — |
| Shared constants | `app/core/constants.py` | re-imports |
| `now_iso` / `safe_row_get` | `app/storage/dbutil.py` | alias re-imports |
| Formatting helpers (format_size, media_emoji, …) | `app/core/format.py` | re-imports |
| Payload slug/name/password validation + link builders + `create_unique_payload` | `app/core/payload/service.py` (`make_payload_service`) | wrappers |
| Referral link helpers + gate check + qualification | `app/core/referral/service.py` (`make_referral_service`) | wrappers |
| Watch Ads config/validators/gate/session URL/templates | `app/core/watch_ads/service.py` (`make_watch_ads_service`) | wrappers |
| `AccessResult` + the points alternative | `app/core/access/engine.py` (`make_access_points_service`) | wrappers; resolver shell stays (pinned) |
| FJ membership engine + active-batch state machine | `app/core/force_join/service.py` (`make_force_join_service`, 23 fns + the tri-state enums) | wrappers (`force_join_active`, `_unjoined_for_access` are the monkey-patch boundary) |
| Delivery domain helpers (recovery card, retrieve text/button) | `app/core/delivery/service.py` (`make_delivery_service`) | wrappers |
| WebApp initData HMAC validation | `app/web/auth.py` | wrappers |
| Network UI handlers (Global Link entry, pt-unlock, My Network, registration wizard, Control/Broadcast centers, net callbacks — 42 fns) | `app/bot/handlers/network.py` (`make_network_ui`) | wrappers + pinned worker glue |
| Keyboard builders | `app/bot/keyboards/builders.py` | wrappers |
| aiohttp runner/site lifecycle | `app/web/application.py` (`WebServerLifecycle`) | pinned route registration lines |
| Route registry | `app/web/routes.py` | — |
| Callback namespace registry + dispatch | `app/bot/callbacks/router.py` | pinned `on_callback` chain |
| Service composition | `app/services/container.py` (`ServiceContainer`) | — |
| Application composition root | `app/bootstrap/application.py` (`create_application`) | pinned `build_application` wrapper |
| Media abstraction (foundation) | `app/media/interfaces.py` | — |

## Deprecated imports (still working, scheduled for removal)

- `import bot` for anything OTHER than the compatibility facade, the legacy
  UI, or the entrypoints. New code must import from `app.*`.
- `bot.Database` — new code should type against
  `app.storage.database.DatabaseBase` (the legacy class only adds the
  pinned migration/watch-ad core).
- Direct calls into `bot._wad_*` handlers — the web layer's canonical
  surface is `app.web.*`.

## Remaining legacy areas in bot.py (honest inventory)

1. **The pinned Access Engine resolver shell** (`access_engine`,
   `_apply_watch_ad_gate`, `enforce_access`) — its branches and log lines
   are source-pinned (BASE-policy fallback, referral_inactive, the three
   `_watch_ads_gate_active(payload_row)` call sites). It delegates its
   sub-services (points, gate evaluation) to `app/core/access` +
   `app/core/watch_ads`.
2. **`_deliver_files_core`** — its internal gate-before-content ordering is
   source-pinned by the Phase 7 A0 checks. The delivery-domain helpers it
   calls live in `app/core/delivery/service.py`.
3. **The Watch Ads DB transaction core** (`create_watch_ad_session`,
   `get_or_create_watch_ad_session`, `process_watch_ad_reward`,
   `reconcile_watch_ad_sessions`) — log-format pins.
4. **The migration chain** (`init_schema`, `_migrate`,
   `_verify_watch_ads_schema`) — structure pins (`if current < N` blocks).
5. **The Mini App HTML + handlers + route registration** — HTML-string
   pins.
6. **`on_callback`** (2,600-line dispatcher) — branch-structure pins; the
   router registry in `app/bot/callbacks/router.py` is the extraction
   surface for the next phases (register + dispatch is live and tested).
7. **Admin panels / wizards / `text_handler` / `on_media_input`** — not
   pinned wholesale, but their call graphs reach deep into module state;
   extraction is staged for the next phase (one panel group at a time,
   registering into the callback router).
8. **Network worker glue** (`_build_network_bot_application`,
   `_network_callback_guard`, `_network_send_file_by_source`,
   `init_network_services`, `network_startup/_net_health_loop`/
   `network_shutdown`) — pinned worker-registration source + singleton
   rebinding (bootstrap-layer wiring by design).
9. **Indexing orchestration** (`run_reindex`, `_run_reindex_inner`,
   `scan_channel_for_new`) — the monkey-patch boundary the suites use to
   fake `fetch_channel_media` / `determine_latest_message_id`; the durable
   job engine itself is `app/core/indexing/engine.py`.

## Migration status

- Phase A (this phase): storage + core services + adapters extracted;
  wrappers + frozen zones documented; architecture tests added
  (`test_architecture.py` — 96 checks).
- Phase B (next): register the admin-panel handler groups into
  `app/bot/callbacks/router.py` one namespace at a time; retire the
  corresponding `on_callback` branches when their source pins are retired
  by a suite refresh.
- Phase C (streaming phase): `app/media/` implementations
  (TelegramSource/LocalBotApiSource/CacheSource) + `app/web` payload
  routes + the MediaGateway — the boundaries for which this phase built
  the seams.

**bot.py is NOT fully eliminated — it is a facade that no longer grows.**
