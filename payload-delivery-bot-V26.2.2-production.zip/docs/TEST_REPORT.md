# Test Report — GAP-CLOSURE FINAL BUILD (executed in this build)

> **v36 ADDENDUM (final production build, this session — bot-6.log):**
> the full battery was RE-RUN against the v36 tree plus the NEW suite
> `test_final_v36.py` **102/0** — pinning: (A) the conversation-input
> state purge + single-active-conversation guard that fixes the live
> FDB Add Token stale-state hijack, (B) the full FDB add/change token
> conversation (single submission, no echo, invalid-token /
> encryption-missing / timeout / cancel handling), (C) the admin
> navigation origin (Create Network Bot / Delivery Groups from the admin
> Network Control panel return there on Back), (D) the
> encryption-key fail-fast gates for every bot-token entry point
> (ncreate / nreg / ctl:managed:create refuse entry — no token
> collected) plus the full create flows with the key configured,
> (E) Global Link mint/verify/tamper/wrong-key/legacy-redirect
> semantics with and without the dedicated signing key, (F) the §18A
> Website Monetag SDK admin flow (add/replace/delete/cancel, dedicated
> `website_monetag_ad_tag` setting, validation + TMA separation, no tag
> echo), and (G) markdown safety of the access-policy panel against a
> hostile payload name. Totals: **30 suites · 2,871 checks · 0 failed**
> + both evidence runners ALL PASS + compileall CLEAN + `node --check`
> worker OK + browser QA (site 200, sw.js exact provider bytes at root,
> honest monetag-status, no TMA leak on /site, no audio option, 390×844
> no horizontal overflow). See docs/FINAL_PRODUCTION_REVIEW.md.

> **v35 ADDENDUM (production bug-fix build, this session):** the full
> battery above was RE-RUN against the v35 tree plus four new suites —
> media_v35 **81/0**, website_security_v35 **55/0**,
> website_monetag_v35 **60/0**, callback_integrity_v35 **40/0**;
> architecture_decoupling updated to **53/0** (J1 rewritten for the v35
> control-plane contract: services construct with the network platform
> OFF + isolated failure). network updated to **82/0** (v34 relay pins),
> website_gapclosure **66/0**. Evidence runners re-verified ALL PASS.
> Total: **29 suites, 2,769 checks, 0 failed** + both evidence runners.
> Full issue/root-cause/fix table: `PRODUCTION_FIX_V35_REPORT.md`.

Environment: Python 3.12, real SQLite (aiosqlite), real module imports
(the `app.presentation.telegram` runtime through the REAL composition
root), fake Telegram transports for the bot API (the established pattern
of every prior phase — no mocked-away internal logic; only the Telegram
wire is virtual). No test code ships production behavior.

## Regression battery — ALL GREEN (2,470 checks, 25 suites)

| Suite | Checks | Result |
|---|---|---|
| test_architecture.py | 96 | 0 failed |
| test_architecture_decoupling.py | 51 | 0 failed |
| tests/test_architecture_proper_breakdown.py | 24 | 0 failed |
| test_media_phase1.py | 88 | 0 failed |
| test_media_phase2.py | 77 | 0 failed |
| test_media_phase3.py | 200 | 0 failed |
| test_media_phase3_ux.py | 70 | 0 failed |
| test_media_phase4.py | 204 | 0 failed |
| test_media_phase5.py | 95 | 0 failed |
| **test_media_transport_auto.py (GAP-CLOSURE)** | **74** | **0 failed** |
| test_watch_ads.py (V1) | 91 | 0 failed |
| test_watch_ads_v2.py (V2) | 142 | 0 failed |
| test_watch_ads_v3.py (V3) | 104 | 0 failed |
| test_watch_ads_v4.py (V4) | 153 | 0 failed |
| test_watch_ads_v5.py (V5) | 142 | 0 failed |
| test_watch_ads_v6.py (V5.1) | 113 | 0 failed |
| test_watch_ads_v7.py (V5.2) | 85 | 0 failed |
| test_botv13_phase6.py | 124 | 0 failed |
| test_botv13_phase7.py | 151 | 0 failed |
| test_botv13_phase7_hotfix.py | 94 | 0 failed |
| test_botv13_phase8.py | 77 | 0 failed |
| test_network.py | 79 | 0 failed |
| **test_network_security.py (GAP-CLOSURE)** | **34** | **0 failed** |
| **test_admin_panels_gapclosure.py (GAP-CLOSURE)** | **43** | **0 failed** |
| **test_website_gapclosure.py (GAP-CLOSURE)** | **61** | **0 failed** |

Evidence runners (end-to-end, ALL SECTIONS PASS):
`run_phase8_evidence.py`, `run_network_evidence.py`.

## GAP-CLOSURE coverage highlights

* **Auto media transport (§10–§16)** — test_media_transport_auto:
  config modes, the selector decision matrix (auto/cloud/local ×
  small/large × local up/down/recovery), fallback discipline
  (transport-class only; deterministic rejections never fall back),
  stack integration, the MIME §17 priority matrix, PTB local wiring
  (base_url/base_file_url), the website bot_ref, and the gateway
  `transport_feasibility` controlled too-large state (I1–I7).
* **Cloud capability honesty (§11/§12)** — test_media_phase4 TOO1–TOO4:
  a 30 MB file over the cloud cap gets the CONTROLLED issuance state
  (authorized, `streamable:false`, `too_large_for_transport`, Local Bot
  API guidance) AND the media-level defense-in-depth 503.
* **Website login/identity/Force-Join (§21–§24)** —
  test_website_gapclosure §1–§2 over a real aiohttp TestServer:
  HMAC-validated initData, the ID/username confirmation (mismatch =
  hard 403), the FJ gate with the exact unjoined channel + Verify Again
  (backend re-check, never marks complete), the joined → feed flow.
* **Categories + 18+ (§26–§29)** — default seeds, per-category feeds,
  age interstitial, backend exclusion of age-restricted listings from
  every generic feed until confirmation (query-level).
* **Ads platform (§35–§52)** — decision/frequency (cooldown / session
  cap / daily cap), ads_exempt (backend list + admins), creative KIND
  matching the placement family (4.5b/4.5c — a video creative never
  renders in a display slot), URL validation (javascript: rejected),
  the HTML sanitizer, analytics counting, failure-never-blocks, and the
  video page wiring contract (4.5d: `window.__playerEl` export + the
  non-clobbering `window.__adStage` placeholder).
* **Download pack (§59)** — authorization, bounded files/bytes, the
  store-only ZIP with safe member names.
* **Website OFF regression (§72)** — maintenance 503s with healthz
  alive; ON restore.
* **Broadcast confirmation (§57)** — the backend rejects a broadcast
  start without the explicit confirmation.
* **Network security keys (§3/§4)** — test_network_security: the
  dedicated persistent encryption key (fail-closed for NEW
  registrations, legacy credentials keep decrypting, wrong key fails
  safe) and the dedicated Global Link signing key (timing-safe
  verification, forged/modified rejection, inactive payload rejection,
  BOT_TOKEN rotation survival, legacy links keep verifying).

## LIVE BROWSER QA (§71) — executed, 23 screenshots, ZERO console errors

Real production server through the REAL composition path
(`B.start_mini_app_server(None)`), AUTO and CLOUD transport scenarios
(both transports real-but-loopback), a QA proxy injecting the Telegram
WebApp stub (exactly what the real WebApp environment provides):

* Login → wrong ID REJECTED (403 message) → correct ID → session.
* FJ gate → exact channel + Join buttons + Verify Membership →
  still-missing message → (join) → verified → feed.
* Age gate → 18+ hidden until confirmation → visible after.
* Feed cards + thumbnails + category nav + ⋮ More menu
  (Collections/My Points/About/Settings; 18+ hidden for unconfirmed).
* AD_TOP banner renders (real creative) AND collapses to zero height on
  load failure (§37/§44).
* PRE-ROLL: real video ad, countdown, Skip armed after skip_after,
  skip → content resumes; impression/start/quarters/skip events recorded
  server-side; the SECOND video page gets NO ad (10-min cooldown — §42).
* MID-ROLL state machine: consumed-break tracking, collapse when
  frequency-capped.
* Video: real playback (30 s), seek (Range 206), played to end;
  Next → Part 2 playback; 22 MB large file streams via
  `strategy=local-native-range` (AUTO + healthy local) and shows the
  CONTROLLED "Large file streaming / Local Bot API required" state in
  pure cloud mode.
* Pure CLOUD mode: the 4 MB video streams via the cloud transport
  (cache-fill + cache-range; ZERO local-transport requests) — §12
  verified (works TODAY without a Local Bot API).
* Welcome intro (once per session, skip, reduced-motion CSS), sound
  toggle + persistence.
* Responsive: 360/375/390/412/768/1024/1440/1920 — NO horizontal
  overflow at any width; mobile feed + player verified at 390×844.
* Search (results + honest empty state); Network/Collections/Settings/
  About pages.
* Website OFF → maintenance page (healthz 200) → ON restore.

## Honest NOT-executed list (UNVERIFIED — infrastructure unavailable)

* **Live Local Bot API server** — no real telegram-bot-api instance is
  hosted here; the Local transport path is verified against a REAL
  loopback HTTP server implementing the same surface (getFile + file
  with Range + getMe) plus deterministic mocks in the transport suite.
  A production Local Bot API deployment is UNVERIFIED.
* **Live Telegram cloud API** — no real BOT_TOKEN / channel infra is
  available in the sandbox; the cloud transport path is verified against
  a loopback fake of api.telegram.org's file surface. Real Telegram
  delivery is UNVERIFIED here (it is, however, the unchanged,
  long-production path covered by the botv13/watch-ads/network suites).
* **Live Monetag postback / provider revenue** — the S2S postback flow
  is covered by the watch-ads suites with fake providers; real Monetag
  revenue data is UNVERIFIED (and never claimed).
* **Live network bots / two-worker Global Link failover** — routing and
  failover are deterministic-mock tested (test_network, §5 spec
  fallback); live two-bot infrastructure is UNVERIFIED.

---

# FILE DELIVERY v34 — ADDENDUM (executed in this build)

## Regression battery — ALL GREEN (2,531 checks, 26 suites)

Every baseline suite re-run after the v34 trusted-relay changes:

| Suite | Checks | Result |
|---|---|---|
| test_file_delivery.py (NEW — the §20-§66 chain) | 75 | 0 failed |
| test_network.py (rewritten §E/G/J to the relay contract) | 82 | 0 failed |
| test_network_security.py | 34 | 0 failed |
| test_architecture.py | 96 | 0 failed |
| test_architecture_decoupling.py | 51 | 0 failed |
| test_admin_panels_gapclosure.py | 43 | 0 failed |
| test_botv13_phase6.py | 124 | 0 failed |
| test_botv13_phase7.py | 151 | 0 failed |
| test_botv13_phase7_hotfix.py | 94 | 0 failed |
| test_botv13_phase8.py | 77 | 0 failed |
| test_media_phase1.py | 88 | 0 failed |
| test_media_phase2.py | 77 | 0 failed |
| test_media_phase3.py | 200 | 0 failed |
| test_media_phase3_ux.py | 70 | 0 failed |
| test_media_phase4.py | 204 | 0 failed |
| test_media_phase5.py | 95 | 0 failed |
| test_media_transport_auto.py | 74 | 0 failed |
| test_watch_ads.py | 91 | 0 failed |
| test_watch_ads_v2.py | 142 | 0 failed |
| test_watch_ads_v3.py | 104 | 0 failed |
| test_watch_ads_v4.py | 153 | 0 failed |
| test_watch_ads_v5.py | 142 | 0 failed |
| test_watch_ads_v6.py | 113 | 0 failed |
| test_watch_ads_v7.py | 85 | 0 failed |
| test_website_gapclosure.py (+5 EndieFans/theme/SDK checks) | 66 | 0 failed |
| tests/test_architecture_proper_breakdown.py | 24 | 0 failed |
| run_phase8_evidence.py | all sections | PASS |
| run_network_evidence.py (relay chain + FDB + Delivery Group) | all sections | PASS |

## New coverage highlights (test_file_delivery.py)

* Schema v34 chain + v33 upgrade preservation (§62).
* FDB token add/change/validate/restart/disable — safe order, atomic
  replacement, FAILED change preserves the old credential (§25).
* Delivery Group verification: every §46 check incl. FDB-not-admin,
  missing delete permission, wrong group type, network-bot-absent,
  group-already-claimed; restored → re-verified READY.
* is_delivery_ready predicate truth table (§46/§47).
* Delivery job state machine: inline relay pipeline, §54 relay-kept on
  failure + retry reuse (no duplicate relays), max-attempts → FAILED,
  §57 TTL sweep → EXPIRED, §55 crash cases 1 & 5, sweep idempotency.
* Routing: delivery-ready-only selection, disabled exclusion,
  restore → eligible again.
* Points: no +5 at registration, +5 at DELIVERY_READY, idempotent,
  legacy double-award guard, spec key format.
* Managed bots: metadata persistence, duplicate rejection, backend
  user-deregistration REJECTION (§30), admin rotation with identity
  mismatch rejection + audit.
* Control panel authorization: unauthorized rejected, admin allowed.
* Credential security: no token material in snapshots/audit/log.

## Browser QA (agent-browser, executed in this build)

Real production server (schema v34 DB, AUTO transport, loopback Bot
APIs) + WebApp stub proxy. Verified with ZERO console/page errors:
anonymous EndieFans boot state → login (session) → Force-Join gate →
join+verify → feed (cards, categories, search); theme cycle
system→dark→light→system with localStorage persistence across reload
and system fallback; settings page shows Theme controls and NO sound
toggle anywhere; video player mounts (ready=4, 30s duration), real-time
playback + seek, `window.__playerEl` hook exported; mobile 390×844 no
horizontal overflow; the QA stub injects AFTER the official SDK tag
(the site now loads telegram-web-app.js per §8 — plain-browser visits
reach the honest deny after the bounded wait).

## Honest NOT-executed list (additions)

* **Live relay copyMessage between real bots** — the relay pipeline is
  verified against loopback fakes + the durable job machine; real
  Telegram group infrastructure is UNVERIFIED (LIVE TEST REQUIRED).
* **Real-device Main Mini App** (Android/desktop Telegram clients) —
  SDK lifecycle verified in-browser via the stub + honest deny path in
  a plain desktop browser; LIVE TEST REQUIRED.
* **2-3 GB transfers** — LIVE TEST REQUIRED (Local Bot API recommended
  for >20 MiB; the too-large controlled verdict is transport-tested).
