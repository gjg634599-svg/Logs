# NETWORK PLATFORM — Multi-Bot Expansion (Phase 8 → Network)

> ONE CENTRAL PLATFORM + ONE SHARED BUSINESS-LOGIC LAYER + MANY TELEGRAM BOT
> EXECUTION CONTEXTS. A user registering a bot adds another frontend/worker
> to the same product — never another copy of the application.

## 1. What the Network Platform adds

| Capability | Where | Spec |
|---|---|---|
| Bot registration (verified activation only) | `app/network/registry.py` + `/network` wizard | §2 |
| Encrypted bot-token credentials | `app/network/credentials.py` | §3 |
| Bot invalidation / health states | registry + `_net_health_loop` | §4/§14 |
| Max 5 registered bots per user (transaction-safe) | `db.insert_network_bot` | §5 |
| Points ledger (idempotent, atomic debits) | `app/network/points.py` + `points_ledger` | §6/§7/§10 |
| Points as the third Access-Engine alternative | `access_engine` OR-branches + `ptunlock:` | §8/§9/§51 |
| Global Payload Links (opaque signed `g<code>`) | `app/network/routing.py` + `/start g…` | §17 |
| Health-aware weighted-random routing | `NetworkRouter.select_bot` | §18 |
| Reachability (user↔bot memberships) | `user_bot_memberships` | §15/§16 |
| Bounded fallback, no routing loops | `resolve_request` + `_rkN` counter | §19/§20 |
| Durable network broadcasts | `app/network/broadcast.py` + 3 tables | §25-§46 |
| Shared worker applications | `app/network/workers.py` | §11/§12/§59 |
| Mini App WebApp auth (initData HMAC) | `POST /api/network/auth` | §49 |

## 2. Database (migration v29 — additive-only, idempotent)

New tables: `network_bots`, `network_bot_credentials`,
`user_bot_memberships`, `points_ledger`, `point_unlocks`,
`global_payload_links`, `network_routing_events`, `broadcasts`,
`broadcast_bot_jobs`, `broadcast_deliveries`.

Setting seeds (`bot_settings`, `INSERT OR IGNORE`):
`network_enabled=1`, `max_registered_bots_per_user=5`,
`points_per_bot_registration=5`, `max_registration_reward_per_user=25`
(derived default), `points_access_enabled=1`, `payload_point_cost=1`,
`network_health_check_interval=300`, `network_broadcast_rate_per_bot=25`,
`network_broadcast_confirm_threshold=1000`.

All values are admin-configurable at runtime; changing them never rewrites
ledger history (append-only).

## 3. Registration flow (verified activation ONLY)

```
user submits token
  → format sanity (cheap, NOT validation)
  → Telegram getMe with the candidate token (direct HTTPS; transient
    failures are telegram_unreachable — never 'invalid')
  → identity resolution (telegram_bot_id, username)
  → duplicate check (same Telegram bot cannot register twice, by anyone)
  → explicit ownership/consent screen (§57)
  → per-user limit re-checked INSIDE the insert transaction (§5:
    two simultaneous registrations can never exceed the cap)
  → metadata + ENCRYPTED credential stored (Fernet / stdlib AEAD)
  → worker start + health check
  → status ACTIVE
  → +5 points awarded (idempotency key botreg:<bot>:<user>; capped at 25)
```

Any failing step persists NOTHING (no partial registration, no orphan
credential) and returns a safe, user-explainable reason.

## 4. Token security

* Tokens are encrypted with authenticated encryption
  (`cryptography.Fernet` when available; stdlib HMAC-CTR + EtM otherwise).
* The encryption key comes from `NETWORK_TOKEN_ENCRYPTION_KEY`
  (deployment secret). When unset, a per-process key is derived from
  `BOT_TOKEN` and `key_version=-1` marks it (set the env var for stable
  cross-restart encryption).
* Tokens are NEVER logged, echoed, displayed after registration, or
  returned by APIs. Diagnostics use `mask_token` (id prefix + 2 trailing
  chars). Removal revokes the stored credential; history is preserved.

## 5. Points

* **Ledger-authoritative**: balance = `SUM(points_ledger.amount)`. No
  mutable balance column can drift.
* **Idempotent credits**: `UNIQUE(idempotency_key)` — the same event
  processed twice never awards twice.
* **Atomic debits**: `BEGIN IMMEDIATE` → balance re-check → insert debit →
  COMMIT. Concurrent debits can never produce a negative balance.
* **Payload purchase** (`ptunlock:` callback): one transaction — existing
  unlock → ok WITHOUT a second debit; insufficient → ROLLBACK (no unlock,
  no debit); otherwise debit + `point_unlocks` row commit together.
  Access eligibility is re-verified first: points are never spent when the
  user is already authorized, and Force Join must pass first.
* **OR semantics** (never AND): Force Join AND (Referral OR Watch Ads OR
  Points OR Admin Bypass). Enforced in `access_engine`, the watch-ad gate,
  AND the last-line delivery gate in `_deliver_files_core`.

## 6. Global Payload Links

* Format: `g<code12>-<sig6>` (+ optional `_rkN` routing context). The
  signature is HMAC-SHA256 over the code; forged codes are rejected before
  any DB lookup. The DB mapping (`global_payload_links`) is authoritative.
* `/start g<code>` in ANY network bot (or the main bot):
  * the CURRENT bot delivers whenever it is routable + payload-eligible
    (loop-free by construction);
  * when the current bot cannot serve, ONE controlled deep-link button
    redirects to a strictly better reachable bot with the fallback counter
    incremented (bounded at 2; at exhaustion the current/main bot always
    delivers — a payload request can never ping-pong between bots);
  * no eligible bot → friendly temporary-unavailable + structured
    `GLOBAL_PAYLOAD_ROUTE_FAILED` event.
* Published links (admin: Payload detail → Global Link) render the t.me
  username by weighted-random among healthy storage-capable bots, so a
  link never permanently depends on one bot.

## 7. File identity across the network (HARD RULES)

* `file_unique_id` = identity/dedup only — NEVER sent to Telegram APIs.
* `file_id` = main-bot-scoped delivery reference — NEVER blindly reused by
  a network bot.
* `source_channel_id + source_message_id` = the durable recovery/transport
  reference.
* **Network delivery = native source copy**: a network bot delivers an
  indexed file via `copy_message(user, source_channel, source_message)`.
  Albums are delivered as sequential source copies (Telegram has no
  copyMediaGroup). A network bot that cannot access the storage channel is
  honestly payload-INELIGIBLE (capability `storage:full` tracked at
  registration + health checks) — never a silent wrong delivery.
* Broadcasts use native copy/forward of the central source message per
  job; Copy vs Forward semantics are explicit per job and never silently
  changed.

## 8. Network broadcasts

* Entities: `broadcasts` → `broadcast_bot_jobs` (per-bot durable cursor)
  → `broadcast_deliveries` (per-user durable state).
* Targeting respects reachability: only ACTIVE memberships become delivery
  rows. Blocked memberships are never targeted.
* Methods: TEXT, COPY, FORWARD, COPY_MULTI, FORWARD_MULTI, media types,
  ALBUM, PAYLOAD_ANNOUNCEMENT (poster + Global Payload Link button —
  never giant payload files), TEMPLATE (server-side variable rendering
  reserved; only supported variables are exposed).
* Lifecycle: PENDING → RUNNING → (PAUSED ⇄ RUNNING) → COMPLETED /
  CANCELLED / FAILED. Restart resumes RUNNING broadcasts from the durable
  per-user rows (at-least-once: an in-flight send interrupted by a crash
  is re-sent; already-SENT users never are). A cancelled broadcast is
  never marked completed.
* Rate limiting: per-bot send pacing (`network_broadcast_rate_per_bot`,
  default 25/s), RetryAfter honored, bounded per-user retries (3).
* Failure classification: SUCCESS / TEMPORARY_ERROR / FLOOD_WAIT /
  USER_BLOCKED_BOT / USER_UNAVAILABLE / BOT_INVALID / SOURCE_UNAVAILABLE /
  PERMANENT_ERROR. Blocked users are terminal (BLOCKED — no retry storm);
  token-invalid fails the bot's job; source-unavailable fails the
  broadcast honestly.
* Isolation: one offline bot's job pauses while every other bot
  continues; a crashing worker never touches the others.

## 9. Bot workers

* The MAIN application keeps its existing `run_polling` lifecycle
  (zero regression). Network workers use the PTB manual lifecycle
  (`initialize → start → updater.start_polling`) inside the same process
  and event loop, sharing the SAME handlers, DB, settings, Access Engine,
  Delivery Engine, Watch Ads, Referral, Force Join, and Points.
* Worker context: `app.bot_data["network_bot_id"]` +
  `app.bot_data["bot_username"]`. `/start` in a worker records the
  user↔bot membership (reachability) and bumps bot activity.
* Admin/management callbacks inside network workers are redirected to the
  main bot (fail-closed whitelist of user-safe prefixes) — spec §63.
* post_init restarts workers for every ACTIVE registry bot (credential
  decrypt failure → TOKEN_INVALID); post_shutdown stops all workers and
  broadcast engines.

## 10. Mini App + Network (N5 scope — honest)

Implemented: `POST /api/network/auth` — official Telegram WebApp
`initData` HMAC-SHA256 validation (secret = HMAC(bot_token, "WebAppData")),
auth_date freshness, authenticated user extraction, points balance, and a
shared-Access-Engine verdict for a requested payload. This is the
network-compatible auth foundation.

NOT implemented (documented remaining scope, unchanged from Phase 8):
YouTube-style Mini App browsing UI, HTTP Range streaming, multi-GB cache,
Download Pack, Local Bot API server, Media Gateway. The Network Platform
integrates cleanly so these can be added later.

## 11. Structured logging

`NETWORK_BOT_REGISTER_START/SUCCESS/FAILED`, `NETWORK_BOT_DISABLED`,
`NETWORK_BOT_REMOVED`, `NETWORK_BOT_HEALTH`, `NETWORK_BOT_TOKEN_INVALID`,
`NETWORK_WORKER_STARTED/STOPPED/START_FAILED`,
`POINTS_CREDITED/DEBITED/REJECTED/DUPLICATE_EVENT`,
`GLOBAL_PAYLOAD_RESOLVE/ROUTE/ROUTE_FAILED`,
`BROADCAST_CREATED/STARTED/PROGRESS/COMPLETED/PAUSED/RESUMED/CANCELLED/
FAILED/RETRY`,
`NETWORK_DELIVERY_FILE/NO_STORAGE_ACCESS/SOURCE_GONE/FLOOD/TRANSIENT`,
`NETWORK_WEBAPP_AUTH_OK/REJECTED`. Never any credential material.

## 12. Limits & configuration

* Per-user registration limit: 5 (default; the architecture scales to
  hundreds of bots — the limit is a USER quota, never a global cap).
* Registration reward: +5 per verified activation, max 25 by default.
* Point unlock cost: 1 (configurable).
* Reachability: a network bot only messages users with an ACTIVE
  membership (Telegram's hard constraint — respected everywhere).
