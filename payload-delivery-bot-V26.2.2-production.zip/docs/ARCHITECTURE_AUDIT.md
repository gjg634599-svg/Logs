# Architecture Audit — ARCHITECTURE PHASE (pre-extraction map)

> Produced BEFORE any code movement, as required. Baseline executed by this
> build (not trusted from prior reports): **1,355 checks / 0 failed across the
> 12 existing suites + 2 evidence runners (exit 0)**. `bot.py` = **34,068
> lines**. Schema **v29**. Working tree: the extracted
> `payload_network_platform.zip`.

## 1. Baseline state (executed)

| Suite | Checks | Result |
|---|---|---|
| test_watch_ads.py | 91 | 0 failed |
| test_watch_ads_v2.py | 142 | 0 failed |
| test_watch_ads_v3.py | 104 | 0 failed |
| test_watch_ads_v4.py | 153 | 0 failed |
| test_watch_ads_v5.py | 142 | 0 failed |
| test_watch_ads_v6.py | 113 | 0 failed |
| test_watch_ads_v7.py | 85 | 0 failed |
| test_botv13_phase6.py | 124 | 0 failed |
| test_botv13_phase7.py | 151 | 0 failed |
| test_botv13_phase7_hotfix.py | 94 | 0 failed |
| test_botv13_phase8.py | 77 | 0 failed |
| test_network.py | 79 | 0 failed |
| **TOTAL** | **1,355** | **0 failed** |
| run_phase8_evidence.py | 24 sections | ALL PASS (exit 0) |
| run_network_evidence.py | 19 sections | ALL PASS (exit 0) |

## 2. Current structure (actual)

```
run.py → app.main → bot.main → build_application (bot.py L33956)
bot.py (34,068 lines):
  L44-163      imports (+ app/core, app/network wiring)
  L165-604     configuration/constants (env, ADMIN_IDS, timers, FJ, WA, NET)
  L605-1380    DATABASE SCHEMA (SCHEMA_SQL DDL constants)
  L1383-6622   class Database (253 methods, ~5,240 lines)
  L6623-7143   helpers (slugs/links/passwords/formatting)
  L7144-8057   safe Telegram send/edit helpers, entity preservation
  L8058-8328   rate limiter, global state, index job state
  L8329-9222   join-request policy, FJ batch state machine, settings helpers
  L9223-9692   protection engine, timers, media extraction
  L9693-9814   indexing + auto payload generation
  L9815-10747  FORCE-JOIN verification engine + link health wiring
  L10748-11080 auto delete system
  L11081-11622 ACCESS ENGINE V1 (access_engine, enforce_access, points alt)
  L11623-12928 referral gate, dashboard controller, referral start flow
  L12930-13738 WATCH AD user flow, sessions, templates
  L13739-14162 retrieve system + recovery cards
  L14163-15200 DELIVERY ENGINE (recovery, send_file, deliver core)
  L15201-16304 /start, /help, admin commands
  L16305-17477 incremental reindex system + auto reindex loop
  L17481-17729 channel post handlers, payload manager search
  L17730-19824 text/media input handler, forward batches, collections
  L19825-20752 broadcast system + panels
  L20753-27682 INLINE ADMIN PANELS (30+ panels, wizard, preview, search)
  L27685-30284 CALLBACK QUERY ROUTER (on_callback — 2,600 lines)
  L30288-30772 error handler, lifecycle hooks (post_init/post_shutdown)
  L30773-32262 WATCH AD MINI APP HTTP SERVER (aiohttp, HTML, handlers)
  L32263-33953 NETWORK PLATFORM v29 wiring (~1,690 lines)
  L33956-34068 build_application + main
app/main.py (47)        entrypoint adapter → bot.main
app/core/ (3 modules)   indexing_engine, verification, fj_link_health
app/network/ (6)        credentials, registry, points, routing, broadcast, workers
```

## 3. THE HARD CONSTRAINT discovered by this audit (must-read)

The 12 existing regression suites are **monolith-pinning suites**: besides
calling `bot.<name>` and monkey-patching module globals (`B.db`,
`B.force_join_active`, `B._unjoined_for_access`, `B._deliver_files_core`,
`B.fetch_channel_media`, `B.determine_latest_message_id`,
`B.DELIVERY_RETRY_*`, `B.safe_edit_text`, `B._mini_app_bot`,
`B.MINI_APP_DEV_ALLOW_HTTP`, …), they also assert **~181 literal source-text
patterns inside `bot.py`** (function def lines, log formats, exact call
patterns such as `src.count("await enforce_access(") == 9`, the Mini App
HTML, the migration `if current < 25:` block structure, the aiohttp route
registration lines, the network worker registration source…).

Consequences for this phase (accepted as design input, NOT worked around by
editing tests):

1. **Frozen zones** — code whose *body* is source-pinned stays in `bot.py`
   verbatim (documented per-module below). Moving it would break the frozen
   regression contract.
2. **Facade-compatible zones** — anything whose *def line* is pinned but
   whose body is not can become a thin compatibility wrapper in `bot.py`
   that delegates the real implementation to an extracted module with
   explicit dependency parameters (call-time late binding through the
   `bot.py` namespace — this is what keeps monkey-patching semantics
   identical).
3. **Free zones** — ~245 of 253 `Database` methods, the FJ verification
   engine, referral/points/watch-ads sub-services, delivery core, web auth,
   payload link helpers, keyboards, parts of the network glue and the
   bootstrap are NOT pinned and move physically.

The single-engine rule is preserved everywhere: extracted modules are the
canonical implementation; `bot.py` wrappers only delegate.

## 4. Responsibility map (current → target)

| Current responsibility | Current location (bot.py) | Target module | Dependencies | Migration risk |
|---|---|---|---|---|
| DB connection / locks | Database L1387-1424 | `app/storage/database.py` (base) | aiosqlite, asyncio | LOW (free zone) |
| Schema DDL constants | L605-1380 (SCHEMA_SQL) | stay in bot.py (source-pinned marker) + re-exported via `app/storage/migrations.py` docs | — | FROZEN (pinned) |
| Migrations v1→v29 | Database._migrate L1800-2495 | stays in bot.py subclass (body pinned) + `app/storage/migrations.py` primitives (column_exists/table_exists/add_column/stamp) | SCHEMA_VERSION | FROZEN body; primitives extracted LOW |
| Watch-ad session/reward DB methods | Database L5403-6015, 6217-6271 | stay in bot.py subclass (log-format pins) | — | FROZEN (documented) |
| Users repository | Database user_* / all_user_ids | `app/storage/repositories/users.py` | base | LOW |
| Media/indexed-files repository | Database add/update/repair/count/range methods | `app/storage/repositories/media.py` | base | LOW |
| Payloads/collections/aliases repository | Database create/get/search_payloads*, collections, aliases | `app/storage/repositories/payloads.py` | base | LOW |
| Force-join repository | Database force_channel/invite_link/health methods | `app/storage/repositories/force_join.py` | base | LOW |
| Referral repository | Database campaigns/tokens/unlocks/progress/history | `app/storage/repositories/referrals.py` | base, generate_referral_token | LOW |
| Watch-ads repository (reads/stats) | Database L5350-5401, 5548-5659, 6017-6295 (unpinned subset) | `app/storage/repositories/watch_ads.py` | base | LOW-MED |
| Network repository | Database network_bots/credentials/memberships/points/links/events | `app/storage/repositories/network.py` | base, NET constants | LOW |
| Broadcast repository | Database broadcasts/jobs/deliveries + scheduled | `app/storage/repositories/broadcasts.py` | base | LOW |
| Settings repository | Database settings/start/help/dashboard/branding | `app/storage/repositories/settings.py` | base | LOW |
| Delivery records/analytics repository | Database pending_deletions/delivery_records/views/stats | `app/storage/repositories/deliveries.py` | base | LOW |
| Access Engine decision | access_engine L11211-11445 | frozen shell in bot.py (pinned branches: BASE-policy fallback, referral_inactive, wad_flag calls) + `app/core/access/engine.py` (AccessResult, points alternative, watch-ad gate evaluation, policy constants) | db, is_admin, FJ service, WA service | MED (pinned body; sub-services extracted) |
| Access requirement screens | enforce_access L11510-11616 | stays in bot.py (UI adapter; calls engine sub-services) | access engine, screens | FROZEN-adjacent |
| Points alternative | _point_* L11148-11208 | `app/core/access/engine.py` | db, NET constants | LOW |
| Watch-ad gate eval | _watch_ads_gate_active L13237-13254 | `app/core/watch_ads/service.py` | db | LOW |
| Watch-ad global config/validators | L12961-13132 | `app/core/watch_ads/service.py` | db | LOW |
| Watch-ad session URL | build_watch_ad_session_url L13259-13311 | wrapper in bot.py (gate call pinned context) + service impl | WA service | LOW |
| Watch-ad screens/flow | show_watch_ad_access_screen L13357+, handle_watch_ad L13570+ | stays in bot.py (UI adapter; pinned strings) | WA service | FROZEN (pinned) |
| Delivery core | _deliver_files_core L14696-14914 | `app/core/delivery/service.py` (impl) + pinned-def wrapper in bot.py | db, access, WA gate, transport callables | MED |
| Delivery flow gates | handle_retrieve/handle_retry_failed_file/finalize_delivery/deliver_message_file/attempt_delivery | bot.py wrappers keep the 9 pinned `await enforce_access(` sites; delivery mechanics delegate to service | enforce_access, service | MED (call-site count pinned) |
| Telegram wire retry/albums | _send_with_retries/send_album/_send_chunk/build_input_media L7580-7770 | stays in bot.py (wire adapter; body pins) | telegram | FROZEN (pinned) |
| Stale file_id recovery | L14221-14605 | stays in bot.py (body pins) | telegram | FROZEN (pinned) |
| FJ membership engine | check_membership/is_member/classify L9862-10473 | `app/core/force_join/service.py` | db, PTB-free | LOW |
| FJ batch state machine | L8561-9180 | `app/core/force_join/service.py` (impl) + `_unjoined_for_access`/`unjoined_channels_for_user` wrappers in bot.py (monkey-patch boundary) | db, settings | MED (patch boundary) |
| FJ link health wiring | _fj_check_link_health etc. L10494-10747 | stays in bot.py (wired to app/core/fj_link_health.py — already modular) | app/core | ALREADY MODULAR |
| Referral gate/qualification | check_referral_gate L11623, qualify_referral L11806 | `app/core/referral/service.py` | db, dashboard callable | LOW |
| Referral dashboard | render_referral_dashboard L12092 (pinned count=1) + controllers L12382-12928 | stays in bot.py (UI; pinned body) | — | FROZEN (pinned) |
| Payload link helpers | build_link/parse_* L6803-6981 | `app/core/payload/service.py` | constants | LOW |
| Payload creation | create_unique_payload L9695-9729 | `app/core/payload/service.py` | db, helpers | LOW |
| Payload service API (new-code surface) | — (new) | `app/core/payload/service.py` PayloadService over PayloadsRepo | repos | LOW |
| Indexing orchestration | run_reindex/_run_reindex_inner/scan L16305-17477 | stays in bot.py (monkey-patch boundary fetch_channel_media/determine_latest) + already uses app/core/indexing_engine | app/core | PARTIAL (already modular core) |
| Admin panels (30+) | L20753-27682 | stay in bot.py this phase (UI adapters; multiple pins) | — | DEFERRED (documented) |
| Callback router | on_callback L27685-30284 | frozen dispatch body stays; `app/bot/callbacks/router.py` = namespace registry + dispatch for extracted feature handlers | handlers | MED (pinned branches) |
| Keyboards | build_force_join_keyboard L10690, build_start_buttons L7817, back_to_main_kb L20971 | `app/bot/keyboards/builders.py` | PTB | LOW |
| Mini App HTML/pages | _wad_mini_app_page L30896-31480 | stays in bot.py (HTML pinned) | — | FROZEN (pinned) |
| Web auth (initData HMAC) | validate_telegram_init_data L30804, _validate_webapp_init_data L32094 | `app/web/auth.py` | hmac, hashlib | LOW |
| Network WebApp auth | _net_handle_webapp_auth L32143 | stays in bot.py body (uses web auth + db) — auth logic extracted | app/web/auth | LOW-MED |
| aiohttp server lifecycle | start/stop_mini_app_server L32204-32258 | route lines pinned in bot.py; runner lifecycle → `app/web/application.py` | aiohttp | MED (pins) |
| Web routes table | L32220-32231 (pinned registration) | `app/web/routes.py` (registry + docs) | — | FROZEN registration |
| Network glue (bots/registration/routing/broadcast) | L32263-33953 | app/network/* already modular; pinned glue (_network_callback_guard, _build_network_bot_application, _network_send_file_by_source, network_startup) stays; unpinned helpers move where safe | app/network | MED |
| Bootstrap/composition root | build_application L33956 (pin boundary) + main | `app/bootstrap/application.py` (create_application with handler registry) + bot.py pinned wrapper | handlers | MED |
| Service container | — (new) | `app/services/container.py` | services, repos | LOW |
| Media abstraction | — (new, foundation only) | `app/media/interfaces.py` | — | LOW |
| Config/constants | L165-604 | shared constants used by repos move to `app/core/constants.py`; bot.py re-imports (module attrs preserved for tests) | — | LOW-MED (patch analysis done) |

## 5. Dependency direction (target)

```
run.py → app.main → app.bootstrap.application.create_application
                        │
        ┌───────────────┴────────────────────────────┐
        │ adapters: app/bot (handlers, router,      │
        │  keyboards), app/web, app/network/workers │
        └───────────────┬────────────────────────────┘
                        ▼
        app/core services (access, payload, delivery,
        force_join, referral, watch_ads, indexing, verification)
                        ▼
        app/storage repositories → app/storage.database
                        ▼
        SQLite (aiosqlite) — schema v29 unchanged
```

Rules enforced: core services and repositories import **nothing** from
`bot.py`, PTB, or aiohttp handlers; adapters receive services via explicit
parameters; `bot.py` is the compatibility facade that binds legacy globals
to the extracted implementations at call time.

## 6. Checkpoint plan

A. Baseline — DONE (1,355/0).
B. After storage extraction.
C. After access/watch-ads/referral/points extraction.
D. After delivery extraction.
E. After payload/handlers/router/keyboards/web/bootstrap/media extraction.
H. Final architecture + new architecture tests + clean-ZIP verification.
