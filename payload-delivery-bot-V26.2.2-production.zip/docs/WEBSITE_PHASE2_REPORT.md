# WEBSITE PHASE 2 REPORT — Indexer + Storage + Search

> PHASE 2 of the 5-phase Website/Mini-App/Streaming plan
> (docs/WEBSITE_PHASE0_AUDIT.md §5). STOP-AND-REPORT gate.
> Baseline: the Phase 1 ZIP (payload-bot_website_phase1.zip), re-verified
> green from a FRESH extraction before any change (88/0 + 1,451/0 + both
> evidence runners — executed by this build, none trusted from reports).
> bot.py grew by exactly +130 wiring/indexing lines (27,751 → 27,881):
> migration v30 (the v29 template), richer `extract_media` capture, two
> metadata-backfill call lines on the duplicate paths, and one Storage
> Statistics coverage row. ZERO website/streaming business logic entered
> bot.py; every durable addition lives in `app/storage/`.

## What was implemented

### 1. Migration v30 Part A — richer indexed media metadata (bot.py)

`indexed_files` gains five NULLABLE columns (the Phase 0 audit's exact
plan; additive / idempotent / restart-safe / non-destructive):

| column | meaning |
|---|---|
| `mime_type` | Telegram-reported content type |
| `width` / `height` | intrinsic media dimensions |
| `thumb_file_id` | thumbnail's bot-scoped transport reference |
| `thumb_file_unique_id` | thumbnail's cross-bot identity (cache/dedup key) |

Mechanics (the documented v27→v28→v29 pattern):
* `SCHEMA_VERSION: int = 29 → 30`;
* the columns are appended to the `indexed_files` DDL in `SCHEMA_SQL`
  (fresh databases) with every pre-existing DDL line byte-preserved;
* an `if current < 30:` block applies the same five columns through the
  idempotent `_add_column_if_missing` primitives (existing v29 databases);
* `app/storage/migrations.py` `SCHEMA_STEPS` registry documents step 30;
* the block contains no destructive statements (audited text constraints
  honored — verified by test A8).

Identity discipline is unchanged and extended to thumbnails:
`thumb_file_unique_id` is identity/dedup ONLY; `thumb_file_id` is the
bot-scoped transport reference; the two are never swapped. Legacy rows
keep NULL metadata — **never fabricated**; a re-index of the live source
message backfills only what Telegram actually provides.

### 2. Indexer metadata capture (bot.py `extract_media`, additive keys)

New pure helper `_extract_media_metadata_fields()` + additive keys per
media type (video/animation: mime+dims+thumb; document/audio: mime+thumb;
sticker: dims+thumb; voice: mime; video_note: thumb only — Telegram
exposes no width/height; photo: dims from the largest size + the smallest
variant as its own REAL thumbnail, mime honestly NULL). All extraction is
`getattr`-based — PTB attribute differences never raise; the seven legacy
keys and every pre-v30 consumer behavior are byte-preserved (tested: B1–B12).

### 3. Persistence + duplicate/re-index refresh (app/storage)

* `add_indexed_file` / `update_indexed_file` / `add_indexed_files_batch`
  persist the five new keys (legacy 7-key dicts persist NULL — backward
  compatible; the edit path keeps its full-refresh semantics).
* NEW `backfill_indexed_file_metadata(file_pk, info)` — fill-missing
  discipline for the duplicate/re-index path: only NULL columns, only
  non-NULL fresh values, one atomic guarded UPDATE under the write lock,
  canonical row (pk/file_id/identity/source refs/payload refs) never
  touched. Idempotent; logs `BOT6_INDEX_METADATA_BACKFILL`.
* Wired into BOTH duplicate paths (`index_message` + `_index_one_message`)
  — re-indexing a channel now backfills missing metadata for already
  indexed files while preserving every Phase 7 hotfix guarantee
  (file_id refresh, canonical preservation, no re-insertion).
* NEW `indexed_files_metadata_coverage()` — coverage counters (total /
  with_mime / with_dims / with_thumb / with_thumb_identity) rendered as a
  new row in the existing Storage Statistics panel (`sc:stats` — the
  audit's "Storage Panel improvements", additive lines only).

### 4. DB-side paginated search (app/storage/repositories/payloads.py)

* NEW `search_payloads_paged(query, page, page_size)` — the website
  feed/search engine: SAME tokenization + escaped-LIKE prefilter helpers
  as `search_payloads_fuzzy` (ONE search system — no second engine),
  AND semantics, hashtag/case-insensitive, parameterized SQL, `LIMIT ?
  OFFSET ?` + `COUNT` **in SQL** (no full-catalog memory loading),
  deterministic `id DESC` ordering, bounded page size (1..100), page ≥ 1,
  query truncated to 120 chars.
* NEW `get_payload_file_overview(payload_ids)` — card/player file fields
  for a BATCH of payloads in ONE query (N+1-free, proven by an
  execute-counter in tests: exactly 1 query for 20 payloads). The
  delivery-grade main `file_id` is deliberately NOT projected (web-layer
  boundary — transport references are resolved by the Phase 1 media stack
  keyed on `file_unique_id`).
* NEW `list_collections_paged(page, page_size)` — paginated multi-file
  payload (collection) listing, deterministic `created_at DESC, id DESC`.
* The existing Telegram search path (`search_payloads_fuzzy` + Python
  ranking) is UNTOUCHED and remains authoritative for the bot's search UX
  (regression-tested: I1–I4 + full phase-7 suite).

### 5. Canonical relations preserved (no second Payload system)

Single-file payloads stay `payloads.index_id → indexed_files`
(FK + CASCADE — a dangling reference is impossible by schema); multi-file
payloads stay `collections + collection_items` (explicit positions,
`file_count`). The new methods JOIN these canonical tables; nothing is
copied or duplicated. `website_payloads` (presentation table) is Phase 3's
v30 **part B** — deliberately NOT built in Phase 2.

## Tests EXECUTED (this build)

| Suite | Checks | Result |
|---|---|---|
| test_media_phase2.py (NEW) | 77 | **0 failed** (exit 0) |
| test_media_phase1.py | 88 | **0 failed** (INDEXED_DDL mirrors v30) |
| All 13 pre-existing suites | 1,451 | **0 failed** (identical to baseline) |
| run_phase8_evidence.py | 24 sections | ALL PASS (exit 0) |
| run_network_evidence.py | 19 sections | ALL PASS (exit 0) |

Phase 2 matrix coverage (77 checks): migration fresh/old-v29/idempotent/
restart/rollback-backward-compat/existing-rows-untouched/v30-text-
constraints (A1–A8b); metadata extraction for all 8 media types incl.
partial-metadata + no-fabrication + identity discipline (B1–B12);
persistence single/edit/batch + legacy-NULL (C1–C5); backfill
fill-missing/idempotent/no-clobber/canonical-preserved (C6–C9); coverage
counters (C10); REAL `bot.index_message` integration — duplicate →
file_id refresh + metadata backfill + no re-insertion + canonical refs
preserved, new-file metadata end-to-end (D1–D5); canonical payload +
collection relations (E1–E6); search semantics — hashtag/case/AND/
empty/punctuation/long-query/escape primitive (F1–F8); pagination/
ordering/bounds/large-catalog-1200/N+1-counter-proofs (G1–G10);
collections feed pagination (H1–H3); Telegram search preserved (I1–I4);
structural pins — SCHEMA_VERSION, DDL columns, v30 block, both backfill
wiring sites, storage-panel row, telegram-free storage imports (J1–J9).

Documented test-pin updates (the established 27→28→29 precedent, exactly
the audit's prediction): **20 assertion lines across 10 files** bumped
`29 → 30` (test_architecture ×3, test_botv13_phase8 ×1, test_network ×3,
test_watch_ads ×3, v2 ×3, v3 ×2, v4 ×2, v5/v6/v7 ×1 each). Historical
check LABELS (e.g. "SCHEMA_VERSION == 27") intentionally untouched —
only asserted values changed, semantics-preserving.

## NOT IMPLEMENTED IN THIS PHASE (per the phased plan)

* `website_payloads` presentation table + settings seeds — v30 **part B**,
  Phase 3 (this phase is part A only, as planned).
* Website routes/pages/auth/admin — Phase 3.
* Media Gateway / Range streaming / cache / stream tokens — Phase 4.
* Indexer does NOT download anything (thumbnails are Telegram-provided
  references only — no big-video downloads to fabricate previews).

## Known limitations (honest)

1. `search_payloads_paged` orders by recency (`id DESC`), not the fuzzy
   ranking tiers — deliberate (DB-side pagination + deterministic order);
   the Telegram search keeps the ranked experience. Phase 3 may add a
   ranked SQL variant if the website needs it.
2. Metadata exists only for NEWLY indexed/re-indexed messages; legacy
   rows stay NULL until their channel is re-indexed (visible honestly in
   the Storage Statistics coverage row).
3. No live Telegram traffic (sandbox) — extraction is tested with real
   PTB message objects; migration paths are tested with real v29-shape
   databases (the established pattern of every prior phase).
4. bot.py grew +130 lines (27,751 → 27,881) — all additive, listed above;
   tracked per the spec's before/after reporting rule.

## Clean-build verification

Clean staging tree (122 files; no `__pycache__`/`bot.log`/`.env`/db/venv):
imports OK, py_compile OK, and the ENTIRE battery re-run from the clean
tree (77 + 88 + 1,451 = 1,616/0, both evidence runners ALL PASS). The
release ZIP was assembled from that tree, `unzip -t` verified ("No errors
detected"), and a fresh extraction re-ran the critical suites green
(phase2 77/0, phase1 88/0, architecture 96/0, phase7-hotfix 94/0,
network 79/0).

ZIP differential vs the Phase 1 ZIP:
* **added (2):** `test_media_phase2.py`, `docs/WEBSITE_PHASE2_REPORT.md`
* **changed (13):** `bot.py`, `app/storage/migrations.py`,
  `app/storage/repositories/media.py`,
  `app/storage/repositories/payloads.py`, `test_media_phase1.py`,
  + the 10 pin-updated test files
* **deleted (0):** none
