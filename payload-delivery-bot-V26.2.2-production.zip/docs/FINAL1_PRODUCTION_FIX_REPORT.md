# PAYLOAD-BOT — FINAL PRODUCTION REPAIR REPORT (B18-FIXED)

**Build:** the CURRENT B18 codebase, repaired in place (no B19, no
renamed problems). This report is the forensic record of the
`bot-20.log` production evidence, every root cause found, every fix,
and the verification evidence — honestly separated by evidence class.

**Baseline integrity:** the repair was applied to the tree that is
byte-identical to the shipped
`payload-bot_PRODUCTION_B18_FINAL.zip` (SHA-256
`90be1a5ee1b4c4da02ca06e8098f489e4541d16f250a6276e7b7e5439adc46da`)
— verified before any edit.

---

## 1. Issue table (reported ⊕ discovered)

| ID | Issue | Root Cause | Fix | Test | Runtime Proof | Status |
|----|-------|------------|-----|------|---------------|--------|
| R1 | Startup FJ health pass never ran (bot-20.log 11:31:11 `name '_fj_startup_health_pass' is not defined`) | The B18 extraction renamed the function to `fj_startup_health_pass` but the post_init CALL SITE kept the old underscore name; a SECOND latent NameError (`force_channels`) sat behind it. Both swallowed by the broad except. Unit tests called the function directly, so everything was green while production skipped the pass. | lifecycle.py call site corrected to the real name; `force_channels` → `force_channels_count` | tests/test_final1_production_repair.py A1–A4e (incl. the generic symtable free-name guard over ALL 602 section functions + a RUNTIME post_init drive) | RUNTIME: post_init driven with a fake Application + real v39 DB → `FORCE_JOIN_STARTUP_HEALTH channels=1 healthy=1`, zero join-request-check errors | FIXED |
| R2 | `DELIVERY_MODE_A_SKIPPED reason=capability_cached_no` contradicting `DELIVERY_GROUP_VERIFIED ... storage_access=full` | TWO causes: (a) the negative capability cache was permanent (no TTL, no invalidation, no re-probe — job 38's storage "Chat not found" poisoned every later delivery until restart); (b) `verify_delivery_group` probed storage with the **FDB's** client while labeling the result `network_bot_id=N storage_access=full` — it measured the wrong bot. | TTL'd negative cache (`MODE_A_NEGATIVE_TTL=300s`, visible writes, expiry re-probe); `refresh_mode_a_capability()` health-pass hook restores access without restart; `verify_delivery_group` now probes BOTH clients and logs `fdb_storage_access=X network_bot_storage_access=Y mode_a_ready=Z` + an explicit `NETWORK_BOT_STORAGE_ACCESS_MISSING` remediation warning | A/B suites B1–B7f | UNIT+INTEGRATION (real v39 DB, simulated clients). Real-Telegram Mode-A relay remains ENVIRONMENT-BLOCKED (see §11) | FIXED (deployment note: the network bot must be added to the Storage channel for Mode A — now surfaced honestly in logs instead of hidden) |
| R3 | `WEBSITE_VIDEOAD_DECISION serve=False reason=disabled` vs `WEBSITE_STREAM_ISSUE_DENIED reason=watch_ad_required` "contradiction" | NOT a state contradiction: two SEPARATE ad systems by design (website pre-roll, config `website_preroll_enabled=0`, vs the Telegram Watch-Ads payload gate). bot-20.log proves the gate WORKS (session 126 denied 0/3; session 127 rewarded 2/2 → unlock → `delivery_gate_unlock_valid` → delivered). The defect was OBSERVABILITY: neither log named its surface or carried progress. | `WEBSITE_VIDEOAD_DECISION surface=website_preroll`; watch-ad denials now carry `completed_ads/required_ads/session/session_status` via the new read-only repo method | C1–C2b | UNIT (server-truth session progress verified against a real DB) | FIXED (observability); behavior was already correct |
| R4 | Fullscreen button does nothing (Telegram-Android WebView) | The old chain tried div `requestFullscreen` → div `webkitRequestFullscreen` → `webkitEnterFullscreen` (iOS-only). In Android WebView element-fullscreen is unhandled/unavailable → every path silently no-ops. Additionally the FIRST fix draft had a second-order flaw (a rejecting video-element request ended the chain early) — caught while designing the rejection test and fixed pre-ship. | Rejection-aware chain: container (promise rejection FALLS THROUGH) → video element (rejection falls through) → webkit paths → **CSS pseudo-fullscreen** (`.playerbox.fsfake` position:fixed inset:0, control bar stays visible, body scroll-lock) → honest `fsToast` (role=status); Esc exits the pseudo state; the icon reflects both states | D1–D8b static + node --check on every script block | **BROWSER (real Chromium, 4 runtime scenarios)**: T1 real fullscreen enter/exit; T2 APIs-deleted → pseudo-fullscreen engages (position:fixed, z=2147483000, toast, video keeps playing); T3 Esc exit; T4 rejecting API → full fallthrough → pseudo | FIXED + BROWSER-VERIFIED |
| D1 | Browser QA was testing the WRONG SOURCE TREE | `tests/qa_bot16_browser_server.py` hardcoded `ROOT=/home/z/my-project/work` — an older, divergent copy (24 files differ). ALL previous browser evidence (the B18 "45/45 + 37/37" claims) was generated against the wrong code. | ROOT is now tree-relative (`tests/..`, `B18_QA_ROOT` override); same fix for the b13 server (it pointed at an ancient b11 tree) | The re-runs below are the proof | BROWSER: 45/45 + 37/37 + 11/11 re-established ON THE CORRECT TREE | FIXED (harness); prior evidence invalidated and regenerated |
| D2 | HEVC→HLS QA silently degraded to direct playback | The QA stub `QAGateway.issue_stream_token` lacked the B17 `ttl_max_seconds` kwarg → TypeError swallowed by the issuance's outer except → `codec_verdict=unknown`, no HLS | The stub accepts the REAL gateway signature (legacy-codec fallback kept) | F10a/F10d/F10e/G16 in the re-run | BROWSER: the real transcode manager + real HLS segments + the quality menu now genuinely exercised | FIXED |
| D3 | Collections health line always printed PASS | Placeholder from the original extraction (count computed, verdict hardcoded) | Informational line with the real count | (cosmetic; covered by syntax + battery) | STATIC + battery | FIXED |
| D4 | Sandbox venv certifi CA bundle missing (recurring) | Environment defect (documented by the previous agent; recurred) | Re-applied the repair (system CA bundle copy) | decoupling suite 51/0 after repair | UNIT | ENVIRONMENT (repaired); not a code defect |

---

## 2. Architecture audit summary

The audit mapped: composition root (`app/bootstrap`) → the
namespace-assembled Telegram presentation runtime
(`app/presentation/telegram/namespace.py`; every section function
rebound with the shared namespace as globals — the contract the new
free-name guard now enforces) → network platform
(`app/network`: workers, registry, FDB manager, DeliveryJobEngine with
the Mode A→B→C layered strategy) → media plane (`app/media`: probe,
classify, transcode ladder, StreamCache, stream tokens) → website
(`app/web`: aiohttp same-process server, site routes, HLS surface,
access engine re-verification on EVERY request) → storage (SQLite,
additive migration chain to v39, repository mixins).

DELIVERED-state honesty re-verified (B16/B17/B18 rules hold): confirmed
sends only; crash-ambiguous and TTL-expired outcomes settle EXPIRED,
never a lying DELIVERED. `is_admin` cannot be inherited by normal users
(env list or DB `admins.is_active`). The watch-ad gate flows through
ONE Access Engine for both Telegram and website surfaces (the site
denial and the Telegram delivery gate are the same decision point).
Stream/HLS tokens are AEAD-bound to user+listing+file+purpose+expiry
and re-verified per request. HLS path validation rejects traversal
(`validate_hls_path` + variant-name regex). The postback trust model is
ymid-as-secret (Monetag S2S design; a user can self-forge their OWN
reward — a monetization-fraud limitation inherent to unsigned postbacks
that cannot unlock anyone else's content — documented, not fixable
without provider signatures).

## 3. Files changed (this repair)

- `app/presentation/telegram/lifecycle.py` — the two call-site fixes (R1).
- `app/network/file_delivery.py` — TTL'd capability cache + logged
  writes + `refresh_mode_a_capability()` + honest
  `verify_delivery_group` labels (R2).
- `app/network/lifecycle.py` — resolver injection + the health-pass
  refresh hook (R2).
- `app/web/site/stream.py` — surface label + denial progress (R3).
- `app/storage/repositories/watch_ads.py` — `latest_watch_ad_session_progress` (R3).
- `app/web/site/html.py` — the rejection-aware fullscreen chain + CSS
  pseudo-fullscreen + toast + Esc + icon (R4).
- `app/presentation/telegram/admin_commands.py` — Collections honesty (D3).
- `tests/qa_bot16_browser_server.py`, `tests/qa_bot13_browser_server.py`
  — tree-relative ROOT (D1) + the stub signature fix (D2).
- `tests/test_bot18_fj_link_health.py` — the obsolete C1b pin replaced
  (documented: the old pin encoded the exact broken call).
- NEW: `tests/test_final1_production_repair.py` (47 checks),
  `battery/browser_qa_final1.py` (11 browser checks),
  `battery/run_battery_final.sh` (43 suites).

## 4. Database / migrations

**No schema change.** The chain remains v2→v39; the repair is code,
logs and tests only. Fresh-DB startup smoke (on the extracted PROD zip)
applies the full chain and passes schema verification; a legacy v38 DB
migrates to v39 (verified by the prior B18 release; unchanged here).

## 5. Verification matrix

| Evidence class | Result |
|---|---|
| STATIC (compileall, source pins, AST/symtable guards, secret scan) | PASS (src + both extracted zips; secret scan 0 findings) |
| UNIT + INTEGRATION (battery: 43 suites) | **43/43 suites, 3,129 checks, 0 failures** (includes the new 47-check FINAL-1 suite) |
| BROWSER (real Chromium, correct tree) | FINAL-1 fullscreen **11/11**; B16 functional **45/45** (HLS/transcode/quality genuinely exercised); B17 UX **37/37** |
| TELEGRAM API (real credentials) | **ENVIRONMENT-BLOCKED** — see §6 |
| REAL PRODUCTION-LIKE E2E | website/HLS/browser flows verified with REAL ffmpeg/ffprobe media; real-Telegram delivery remains environment-blocked |

## 6. Environment-blocked (never labeled PASS)

- **Real Network-Bot Mode-A relay** (the network bot itself copying
  storage→group→user against real Telegram): no real bot tokens in this
  sandbox. What WAS verified: the full logic against simulated clients
  (failure classification, cache semantics, refresh/restore, fallback
  honesty, DELIVERED truthfulness). The exact real-world test that
  remains: configure a network bot with a verified delivery group, add
  it to the Storage channel, deliver a file, and observe
  `NETWORK_RELAY_MESSAGE_CREATED_BY_NETWORK_BOT` +
  `NETWORK_DELIVERY_SUCCESS mode=network_relay`.
- **Force Join against real channels** (remove/re-add on a live bot):
  simulated end-to-end (the B18 12-step suite, re-run green in this
  battery); real-channel verification remains blocked.
- **~800–856 MB large-file run**: the bot-20.log production log itself
  shows the 856,182,925-byte file streaming successfully (range
  requests, cache-fill/cache-follow) — production evidence, not
  sandbox-reproducible without credentials.

## 7. Remaining known limitations (honest)

1. Mode A requires the **deployment** action "add the network bot to
   the Storage channel" — until then Mode B (FDB direct) delivers and
   the logs say so explicitly (`NETWORK_BOT_STORAGE_ACCESS_MISSING`).
2. The Monetag postback is unsigned (provider design); reward forgery
   by a user on their OWN session is possible and only affects ad
   revenue, never another user's access.
3. The fullscreen chain's video-element and pseudo-fullscreen paths are
   browser-verified in Chromium simulations of the restrictive-WebView
   behaviors; actual Telegram-Android/iOS WebViews cannot be driven
   from this sandbox (no devices). The chain is designed to never
   silently no-op in any of them.
