# BOT-17 PRODUCTION FIX REPORT

**Build:** payload-bot_PRODUCTION_B17_FINAL (schema v38)
**Evidence base:** bot-18.log (the authoritative production run), the B16
production ZIP extraction, and the B11 TEST/Cloudflare reference ZIP.
**Mandate:** the B16 report claimed fixes that the real deployment
disproved — every claim below is locked by tests that run against THIS
source tree, and the ZIP is verified again from a clean extraction.

---

## 1. ROOT CAUSES (bot-18.log, final)

### 1.1 Telegram file delivery — the relay architecture itself was invalid

```
14:53:23 NETWORK_DELIVERY_BAD_REQUEST chat=8370454312
         group=-1003963643527 relay=198 error=Message to copy not found
14:53:23 NETWORK_DELIVERY_RELAY_GONE   … relay=198
         (self-heal recreates relay 199 → identical failure)
14:53:23 DELIVERY_SEND_FAILED reason=final_delivery_failed
         job_id=30 … verdict=relay_gone
         (jobs 30/31 cycle relays 198–205 — ZERO deliveries)
```

The relay message in the Delivery Group is authored by the **File
Delivery Bot**; the **network bot** then tries `copyMessage` on it.
Telegram **never lets one bot copy a message authored by a different
bot** (bots do not receive other bots' messages, so the message never
enters the copying bot's cache) → *"Message to copy not found"*,
instantly, on every relay id, with `protect=off`, forever. The B16
`protect_content` fix and the self-heal loop both attacked symptoms of
an impossible hop.

**What DID work in that same log:** the FDB's own `copyMessage`
(relay ids 198–205 were created every time — the FDB copying from
Storage is a guaranteed primitive) and the network bot's user-facing
messages.

### 1.2 Website video playback — the getFile phase bound killed large files

```
14:51:50 STREAM_AUTH_OK file_unique_id=AgADUiQAAml2MFU size=856182925
14:51:50 STREAM_START … strategy=cache-fill
14:51:50 MEDIA_CACHE_FILL_START key=media:AgADUiQAAml2MFU window_start=0
14:52:20 MEDIA_UPSTREAM_ERROR origin=local kind=TimeoutError
         phase=getfile retryable=True          ← exactly 30 s later
14:52:20 MEDIA_CACHE_FILL_ABORT … reason=MediaSourceUnavailableError
14:52:51 STREAM_PREFLIGHT_FAIL reason=MediaSourceUnavailableError
         → GET /site/media/… 503 → dead player
         (the 599 MB file AgADyB8AAnV00FA fails identically)
```

A local telegram-bot-api server must **download the file from the
Telegram DC BEFORE answering getFile**. The generic 30 s metadata
timeout (`MEDIA_HTTP_TIMEOUT`) therefore guaranteed failure for any
large file. The retry/preflight machinery was correct — the bound was
wrong for this phase.

---

## 2. THE B17 FIXES

### 2.1 Direct-delivery architecture (Modes A → B → C)

`app/network/file_delivery.py` — every hop now uses ONLY
Telegram-guaranteed primitives; acceptance = **the user actually
receives the file**:

* **Mode A `network_relay`** (best UX, capability-probed): the
  NETWORK BOT copies Storage → its Delivery Group (its OWN relay — a
  bot can always copy messages it authored) and then copies that relay
  → the user. The capability ("can the network bot see the Storage
  master?") is probed by the real copy attempt and cached per
  `(network_bot_id, storage_chat)` — never assumed (the standard
  deployment keeps network bots OUT of Storage, so this usually falls
  through).
* **Mode B `fdb_direct`** (the default reliable path): the shared
  File Delivery Bot performs the FINAL user-facing send
  (`copyMessage` Storage → user, `protect_content` on this hop) — the
  exact primitive that always worked in bot-18.log. Requires the user
  to have started the FDB.
* **Mode C `handoff`** (user has NOT started the FDB): the network
  bot — the bot the user IS talking to — sends a one-tap button
  `t.me/<fdb>?start=dl<token>`. The job waits in the honest
  `HANDOFF_PENDING` state (single-use token, own TTL); the FDB's
  in-process **handoff poller** (getUpdates long-poll) sees
  `/start dl<token>`, atomically claims the job, completes Mode B, and
  only then writes DELIVERED.

**Honesty mandates (locked by tests):**
* DELIVERED is written ONLY after a real Telegram send returns a
  message id — never because a relay exists, a retry ran, a button was
  sent, or a TTL fired;
* an untapped handoff settles **EXPIRED** (`DELIVERY_HANDOFF_EXPIRED`)
  — never a lying DELIVERED;
* the handoff token is single-use (`claim_handoff_job` — atomic
  conditional UPDATE; a second tap gets the honest "no longer valid"
  message);
* `delivery_jobs.delivery_mode` records HOW the file actually reached
  the user (`network_relay` / `fdb_direct` / `handoff` — v38);
* no token is ever logged (handoff tokens appear as a 6-char prefix).

### 2.2 The getFile phase bound (large-file playback)

`app/media/` — new `MEDIA_GETFILE_TIMEOUT` (default **600 s**,
validated ≥ 1) applies ONLY to the getFile phase:
`AioHttpMediaClient.get_json(timeout_seconds=…)` →
`sources/_base.getfile()` → both the local and cloud sources. The
generic 30 s `MEDIA_HTTP_TIMEOUT` stays for every other metadata call;
body streams keep the sock-read bound (stalled connections still fail
promptly). 503 media-error responses now carry `Retry-After: 5` so the
player (and any CDN/Worker in front) backs off politely instead of
re-hammering an upstream that is mid-download on a huge file.

---

## 3. DATABASE / MIGRATION (v37 → v38, additive + idempotent)

```
delivery_jobs.delivery_mode  TEXT NULL   -- how the file reached the user
delivery_jobs.handoff_token  TEXT NULL   -- one-time deep-link token
delivery_jobs.handoff_sent_at TEXT NULL  -- TTL basis
```

No existing row changes; legacy rows keep NULLs; `SCHEMA_VERSION = 38`;
fresh DBs create the columns directly; the v2→v38 chain re-runs
idempotently (locked: H-series migration tests + the fresh-extraction
smoke).

---

## 4. VERIFICATION (this exact tree)

* **New suite** `tests/test_bot17_direct_delivery.py` — **110 checks,
  0 failures**: manager primitives (ok/forbidden/bad_request/chat-not-
  found/unconfigured/no_message_id verdicts, protect-on-final-hop,
  deep-link form), the layered engine (Mode A authorship + protect
  policy + capability cache; the bot-18.log shape now DELIVERS via
  Mode B; cache-hit skip; Mode C button + honest HANDOFF_PENDING;
  transient→bounded retry; no-group→Mode B still delivers; crash
  simulation never DELIVERED; button-send failure), the handoff
  poller (completion, single-use, welcome, unknown token, offset
  advance, lifecycle, forbidden-revert, transient-retry), the sweeper
  (handoff TTL EXPIRED, fresh-stays-pending, due-retry completes,
  forbidden-waits, the B16 honesty rules preserved), the repository on
  real SQLite (mode column, token resolution, atomic claim, v38
  columns, version stamp), the media fix (env override, default 600,
  getfile forwarding, legacy-fake tolerance, source pin, Retry-After),
  and architecture source pins.
* **Full regression battery — 40 suites, 3,027 checks, 0 failures**
  (BOT_TOKEN fake + ADMIN_IDS=1001, run from THIS tree; includes the
  updated BOT-16 relay suite — 45/45 under the B17 semantics — plus
  BOT-12 17/17, BOT-11 E2E 26/26, network 79/79, architecture
  97/97+51/51, media phase 1–5, watch-ads v1–v7, monetag, B10, B16
  removal/transcode/website-FJ).
* `compileall` clean; secret scan 217 files, 0 findings.
* Fresh-extraction startup smoke PASS (schema v38, v38 columns, B17
  surfaces, website server bind, /healthz, /sw.js).

## 5. ENVIRONMENT-BLOCKED (honest, not simulated)

* **Real Telegram end-to-end delivery** (Storage → FDB direct → a real
  user's chat) requires live bot tokens and a real user account; this
  environment has neither. The contract is locked by the 110-check
  suite against strict PTB-signature fakes (the same discipline that
  caught the B12/B16 production bugs).
* **A real 856 MB getFile through a local Bot API server** requires the
  production local server; the fix is locked at every layer below it
  (config → client → source → route).

## 6. OPERATOR NOTES

* Configure the File Delivery Bot (env `FILE_DELIVERY_BOT_TOKEN` or the
  Control Bot panel) — with a token bound, its handoff poller starts
  automatically (`FDB_HANDOFF_POLLER_STARTED` in the logs).
* Users who never started the FDB will receive the one-tap
  **📥 Receive File** button from the network bot they are talking to —
  one tap and the file arrives.
* For local Bot API deployments with large media, keep
  `MEDIA_GETFILE_TIMEOUT` at ≥ 600 (or raise it for slower DC links).

---

## 7. B17 FINAL VERIFICATION ROUND (independent audit + fixes)

An independent audit of the first B17 build against the acceptance
mandate found two real defects (plus several smaller gaps); all were
fixed at the root and re-verified:

### 7.1 Delivery-state honesty (the crash-ambiguous settle)

**Defect:** `sweep_once()`'s TTL pass settled a crash-ambiguous
`DELIVERING` row (crash mid-copy, outcome unknown, no failure recorded)
as **DELIVERED** — without any confirmed Telegram send or destination
message id. Two tests (bot16 §5b, bot17 §D6a) pinned that obsolete
behavior.

**Fix (delivery_jobs TTL settling):**
* a row already DELIVERED **with** `user_message_id` keeps DELIVERED
  (the confirmation was written when the real send returned its id);
* a DELIVERED row **without** `user_message_id` (legacy B16-era lying
  row) is downgraded EXPIRED — no proof of delivery;
* a crash-ambiguous DELIVERING row settles **EXPIRED** — never a lying
  DELIVERED;
* every other (failed) row settles EXPIRED.
Tests 5b/D6a were CORRECTED to the mandate (crash-ambiguous → EXPIRED)
and new checks 5d/5e/D6b lock the confirmed/legacy distinction.

### 7.2 NETWORK_DELIVERY_GROUP_ACCESS_CHECK — now a REAL executable diagnostic

**Defect:** the diagnostic existed only in a docstring; the 10-class
taxonomy did not exist; "Message to copy not found" was classified
`relay_gone` (deleted) without any proof of deletion.

**Fix:**
* `classify_telegram_delivery_failure()` (app/network/file_delivery.py)
  — maps every Telegram delivery-hop exception to EXACTLY ONE canonical
  class: RELAY_DELETED / RELAY_INACCESSIBLE_TO_NETWORK_BOT /
  GROUP_INACCESSIBLE_TO_NETWORK_BOT / MESSAGE_ID_INVALID /
  MESSAGE_NOT_COPYABLE / BOT_IDENTITY_MISMATCH / TELEGRAM_API_RESTRICTION
  / PERMISSION_FAILURE / THREAD_TOPIC_MISMATCH / UNKNOWN_TELEGRAM_FAILURE.
  "Message to copy not found" is RELAY_DELETED **only with
  deletion_proven=True**; without proof it is
  RELAY_INACCESSIBLE_TO_NETWORK_BOT (the bot-18.log root cause class).
* `DeliveryJobEngine.network_delivery_group_access_check()` — the REAL
  executable diagnostic: probes with the NETWORK BOT'S OWN client
  (get_me identity vs the registered row, get_chat on the group,
  get_chat_member for the bot's own membership/read/send capability and
  the FDB's, Storage reachability), records the originating exception
  class/message, attempt, correlation id and timestamp, and emits the
  structured `NETWORK_DELIVERY_GROUP_ACCESS_CHECK` log line with every
  required field. BOT_IDENTITY_MISMATCH is detected live when get_me
  disagrees with the registered telegram_bot_id.
* Wired into BOTH failure paths: the Mode A probe failure
  (`_copy_storage_to_group_as_network_bot`) and the final-hop copy
  failure (`_copy_group_to_user`) run the diagnostic on every
  BadRequest; the final-hop copy-not-found verdict is now
  `relay_inaccessible` (deletion NOT proven) — the relay self-heal
  triggers for both the legacy and the honest verdict; Mode B's
  `deliver_direct_to_user` logs carry `classification=` too.
* Suite section [H] (H1–H6) proves the classifier taxonomy (13 shapes),
  the proof-gated RELAY_DELETED, the real probes (get_me/get_chat/
  get_chat_member actually called), the identity-mismatch detection,
  graceful degradation, and the live-path invocation.

### 7.3 Other audit fixes

* **HLS long-form token clamp** (a real playback bug): stream.py asks
  ≥6 h for a transcoded movie's HLS token but `clamp_stream_ttl`
  silently capped at 3600 s → a >1 h movie 401'd on late segment
  fetches. New `STREAM_TOKEN_TTL_LONGFORM_MAX` + `max_seconds` param,
  forwarded through `issue_stream_token`/`encode_stream_token`
  (F8a–F8d).
* **Player auto-hide controls** (the one missing player feature):
  YouTube-style idle auto-hide (~2.8 s) of the control bar + cursor
  while playing; any pointer/key/click activity revives it; NEVER hides
  while paused, while a menu is open, or during the ad stage; teardown
  clears the timer. Verified in REAL Chromium (E-autohide1/2/3).
* **CRITICAL_COLUMNS defense-in-depth**: v38 delivery columns
  (delivery_mode/handoff_token/handoff_sent_at) + v37 removed_at added
  to the startup verify/auto-repair list.
* **FJ admin health quadruple 🟢🟡🔴🟠** on the Force Join dashboard
  (Healthy / Needs attention / Invalid / Bot permission).
* **Archived bots section**: the Registered Bots admin list now renders
  a browsable ARCHIVED section (@username, #id, owner, removed_at) —
  not just the hidden count (F-arch1–3).
* **Non-admin website FJ real-chain test** (§I): the REAL production
  chain `_fj_gate → _unjoined_for_access → check_membership →
  bot.get_chat_member` for a NON-ADMIN user — real get_chat_member per
  channel, fail-closed on temporary errors (I1–I5).
* Docs/registry hygiene: migrations.py SCHEMA_STEPS v38 entry, stale
  database.py comment fixed, stale test label fixed.

### 7.4 Final verification numbers (this exact tree)

* Full regression battery: **40 suites, 3,069 checks, 0 failures**
  (test_bot17_direct_delivery.py now 141 checks).
* Browser QA (REAL Chromium via agent-browser): **48/48** — including
  the three auto-hide checks and the full HLS ladder
  (codec_verdict=transcode, master.m3u8 + MPEG-TS segments, real
  TranscodeManager runs, quality menu from real variants).
* Fresh-DB startup smoke: PASS (schema v38, v38 columns, B17 surfaces,
  server bind, /healthz, /sw.js).
* Secret scan: 217 files, 0 findings.

## 8. FINAL ACCEPTANCE MATRIX (B17 FINAL VERIFICATION)

Evidence tiers — A: code implemented; B: automated test verified;
C: clean-extraction verified; D: real browser (Chromium) verified;
E: real Telegram verified; F: production runtime verified.

| ID | Requirement | Code | Test | Runtime | Status | Notes |
|---|---|---|---|---|---|---|
| D1 | DELIVERED only after confirmed send + destination msg id | A | B (5a-5e, D6a/b, H6) | — | PASS | 6 legit sites all post-send; sweep TTL now EXPIRED for unconfirmed |
| D2 | Crash-ambiguous DELIVERING never DELIVERED | A | B (5b, D6a) | — | PASS | The user-flagged defect — fixed + tests corrected |
| D3 | Legacy DELIVERED w/o user_message_id downgraded | A | B (5e) | — | PASS | B16-era lying rows repaired on sweep |
| D4 | NETWORK_DELIVERY_GROUP_ACCESS_CHECK real + executable | A | B (H3a-H3l) | D (server paths) | PASS | get_me/get_chat/get_chat_member live probes, all fields, correlation id |
| D5 | 10-class canonical taxonomy | A | B (H1, H2c) | — | PASS | 13 exception shapes → exactly the 10 classes |
| D6 | copy-not-found ≠ RELAY_DELETED without proof | A | B (H2a/H2b, H6c) | — | PASS | verdict relay_inaccessible; self-heal accepts both |
| D7 | BOT_IDENTITY_MISMATCH live detection | A | B (H4) | — | PASS | get_me vs registry row |
| D8 | Mode A/B/C architecture, no broken relay dependency | A | B (bot17 A-D) | — | PASS | engine never calls FDB relay-create (G pin) |
| D9 | Handoff: single-use token, TTL EXPIRED, poller completion | A | B (bot17 C/D) | — | PASS | atomic claim_handoff_job on real SQLite |
| D10 | Website playback chain (token→gateway→cache→getFile→HLS) | A | B (media suites) | D (QA F10a-e) | PASS | real ffprobe/ffmpeg in QA |
| D11 | Large-file getfile timeout 600s | A | B (F1-F6) | — | PASS | per-request phase bound |
| D12 | HLS long-form token 6h ceiling | A | B (F8a-d) | D | PASS | was silently clamped to 1h — fixed |
| D13 | /site base-path normalization (no /site/site) | A | B (relay §7) | D (E11) | PASS | 11 normalize cases + browser zero-bad-URLs |
| D14 | Player: all 21 features incl. auto-hide | A | B (source pins) | D (E12-E-autohide3, G15-G17, H18-H20) | PASS | auto-hide was the one gap — implemented + browser-verified |
| D15 | Quality menu = real HLS variants | A | B (transcode 149) | D (G16) | PASS | ladder-derived, real master.m3u8 |
| FJ1 | 5-state machine, temporary never invalid/joined | A | B (phase6/8, bot11) | — | PASS | names differ (api_temporary_failure etc.), semantics exact |
| FJ2 | Fail-closed, no fail-open | A | B (I5, D2) | D | PASS | incl. the REAL non-admin chain |
| FJ3 | Non-admin website FJ real check | A | B (I1-I4) | D (QA C/D) | PASS | real get_chat_member per channel, non-admin 4242 |
| FJ4 | Invite URL preserved on temporary | A | B (L4/L5, D14) | — | PASS | |
| FJ5 | Bounded request discipline (7+ channels) | A | B (flood replay 0 invalid) | — | PASS | sequential checks + TTL cache + debounce + per-IP buckets |
| FJ6 | Admin health icons 🟢🟡🔴🟠 | A | B (D13b) | — | PASS | quadruple on the FJ dashboard |
| S1 | Surface separation (website ads ≠ Telegram Watch Ads) | A | B (E5, F1/F2) | D (I22/I23) | PASS | zero t.me, zero sessions |
| S2 | Legacy ad-destination routing inert | A | B (G3/G4) | — | PASS | column exists, zero runtime reads |
| S3 | Get File OFF fail-closed / ON works | A | B (D1-D9) | D (J24/J25) | PASS | 403 before any mint |
| S4 | Removed bots never resurrect/route/restart | A | B (removal 57) | — | PASS | unique index + REMOVED filters + guards |
| S5 | Archived bots browsable | A | B (F-arch1-3) | — | PASS | was count-only — upgraded |
| M1 | Migrations additive/idempotent, fresh+upgrade | A | B (H1-H6) | C | PASS | v38 chain + CRITICAL_COLUMNS defense |
| SEC1 | Signed tokens, expiry, fail-closed decode | A | B (media4/5) | — | PASS | AEAD via CredentialVault |
| SEC2 | Path traversal/SSRF/FFmpeg injection | A | B | — | PASS | list-argv subprocess, whitelists, realpath containment |
| SEC3 | No token leakage in logs | A | B | C | PASS | secret scan 0 findings ×3 trees |
| T1 | Test quality (no mock-success blindness) | A | B | C | PASS | battery 40/3,069/0 on work tree AND extraction |
| QA1 | Real browser QA | — | — | D | PASS | 48/48 real Chromium |
| QA2 | Real Telegram E2E | — | — | — | ENVIRONMENT-BLOCKED | no live tokens/users in this environment |
| QA3 | Real 856MB getFile | — | — | — | ENVIRONMENT-BLOCKED | needs production local Bot API server |
