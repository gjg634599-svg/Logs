# TRUSTED FILE DELIVERY — IMPLEMENTATION REPORT (v34)

Spec: `PRODUCTION GAP CLOSURE, MAIN MINI APP AUTH, ENDIEFANS WEBSITE,
GLOBAL LINKS, TRUSTED FILE DELIVERY, CONTROL BOT & PLATFORM-MANAGED
NETWORK BOTS` (85 sections). Baseline: `payload-bot_gapclosure_final.zip`
(schema v33). This phase implements §20-§84 on top of that baseline,
adapting the existing architecture in place (nothing rewritten from
scratch, no existing functionality removed except the explicitly
replaced Website audio option).

---

## 1. Executive summary

The final architecture:

```
                    CONTROL BOT (platform admin control plane)
                         │  existing is_admin authorization
            ┌────────────┼─────────────────────┐
            ▼            ▼                     ▼
   FILE DELIVERY BOT  MANAGED NETWORK BOTS   Diagnostics
   (trusted relay)    (PLATFORM_MANAGED)     (health/audit)
            │            │
            │            ▼
            │      PAYLOAD NETWORK (existing registry/workers)
            │            │
            ▼            ▼
       STORAGE    PRIVATE DELIVERY GROUP (one per bot)
            │            │
            └─ copy → relay → Network Bot copy → USER
                                    │ success
                                    ▼
                       File Delivery Bot deleteMessage (cleanup)
```

* Normal Network Bot delivery NO LONGER requires Storage access (§48).
* The Storage → Network Bot direct copy was REPLACED by the relay
  pipeline (§49/§50) — `network_send_file_by_source` now drives
  `DeliveryJobEngine.deliver()`.
* `is_delivery_ready()` (§46) is THE single authoritative eligibility
  predicate, injected into `NetworkRouter` — every routing path
  (selection, deep-link resolution, published-link username choice)
  consults the same function.
* +5 points moved from registration to the verified DELIVERY_READY
  transition (§60-§62), with double-award guards.
* The Website rebranded to **EndieFans**, loads the official Telegram
  WebApp SDK with a bounded startup state machine (BOOT →
  TELEGRAM_LOADING → TELEGRAM_READY → INTRO → AUTHENTICATING → READY),
  removed the sound option entirely, and gained Dark Mode / Normal Mode
  (persisted, system-aware, no-flash).
* Global Link minting stays fail-closed without
  `NETWORK_GLOBAL_LINK_SIGNING_KEY`; startup logs the safe diagnostic
  `global_link_signing_key_configured=true/false`; the Network → Global
  Links overview gained "➕ Create Global Link" (same canonical mint
  flow, no second implementation).

## 2. Actual codebase analysis

Baseline inspected in full (206 files): app/bootstrap (config,
application), app/services/container.py, app/storage (schema.py,
database.py, repositories/*), app/network (registry, credentials,
workers, lifecycle, routing, points, broadcast), app/presentation/
telegram/* (the 31-module handler layer + namespace assembly),
app/web/* (site: html/screens/pages/session/stream/tokens/auth),
app/core/*, all 24 baseline suites + 2 evidence runners. Two complete
exploration reports were produced first (Task 2-a: network delivery
architecture; Task 2-b: website frontend + auth) and drove every edit.

## 3. Root causes addressed

* **Main Mini App failure**: the Website never loaded
  `telegram-web-app.js` and did a one-shot synchronous
  `window.Telegram` check → premature "Open in Telegram" while the SDK
  was still loading. FIXED: SDK `<head>` tag + bounded 3s wait state
  machine (real Telegram: SDK provides initData natively; plain browser:
  honest deny after the wait).
* **Global Link minting refused**: `NETWORK_GLOBAL_LINK_SIGNING_KEY`
  absent — CORRECT fail-closed behavior, preserved. Added safe startup
  diagnostics + operator guidance surfaced in the Links overview.
* **Old Storage → Network Bot delivery**: replaced by the relay
  pipeline; `_net_probe_storage_access` is no longer consulted for
  payload eligibility (kept only as the historical compat adapter; the
  FDB has its own Storage probe).
* **+5 at registration**: moved to DELIVERY_READY.
* **Branding**: all "Endie Updates" occurrences replaced with
  EndieFans (9 runtime + 5 test pins + QA seeds).
* **Website audio option**: removed entirely (toggle, WebAudio chime,
  speech, settings button, eusound storage); the content `<audio>/<video>`
  players and ad system are untouched.

## 4-10. Architecture sections

* **Control Bot** (`app/network/control_bot.py` + `app/presentation/
  telegram/control_ui.py`): dedicated in-process PTB application
  (CONTROL_BOT_TOKEN, optional) + the same panel reachable from the main
  bot (Platform Control button). Every action re-checks `is_admin`
  server-side (§22) and writes safe audit events (§36). Panel:
  File Delivery Bot / Managed Network Bots / Create / Health /
  Analytics / Credentials / Reconciliation / Settings / Audit trail.
* **File Delivery Bot** (`app/network/file_delivery.py` —
  `FileDeliveryBotManager`): platform-owned trusted client (no update
  polling; initialized Bot + health task). Token add/change/validate/
  restart/disable with the §25 safe order (validate → encrypt → atomic
  persist → rebind → health-verify → retire old). Storage access probe
  via getChat on active channels.
* **Delivery Groups** (§39-§43): `network_delivery_groups` — exactly
  one per bot (UNIQUE both sides), statuses
  DELIVERY_SETUP_REQUIRED/VERIFYING/READY/DEGRADED/UNAVAILABLE.
  Verification chain (§46): group type → FDB administrator + required
  privileges (can_delete_messages) → association uniqueness → network
  bot membership/identity → storage capability. Setup wizard
  (`dg:` callbacks) with Use Existing Group / Create New Group
  (honest BotFather guidance — bots cannot create groups) + the
  network-worker DETECTION hook that captures the group when the owner
  posts in it and runs the real verification.
* **Delivery jobs** (§53-§57): `delivery_jobs` durable rows with the
  full state machine (CREATED → RELAY_CREATING → RELAYED → DELIVERING →
  DELIVERED → DELETE_PENDING → DELETED + FAILED/EXPIRED), attempts +
  exponential backoff, TTL sweep for abandoned relays, crash-recovery
  reconciliation (all five §55 cases), idempotent relay handling
  (retry reuses the relay; "message to delete not found" = success).
* **Isolation** (§59): one private group per bot enforced by UNIQUE
  constraints + per-bot job scoping; the network bot only ever sees its
  own group.
* **Platform-managed bots** (§27-§32): `management_mode`,
  `credential_control`, `created_via` columns; the Create Network Bot
  wizard (`ncreate:`) registers automatically as PLATFORM_MANAGED
  (consent given at submission). User deregistration is REJECTED at the
  backend (`nbot:<id>:remove` on a managed bot answers the §30 message
  and does nothing). The managed credential is never displayed or
  exported; honest §32 limitation stated in the wizard UI (the user
  receives the token from BotFather once — after submission the
  platform retains exclusive possession and never re-exposes it).
* **+5** (§60-§62): `award_delivery_ready_reward` with the
  spec-mandated key `network_setup_reward:<user>:<bot>` + the legacy
  BOT_REGISTERED guard (an old bot rewarded at registration is never
  re-awarded). Awarded exactly at the verified DELIVERY_READY transition
  by the delivery UI. UI text now says "+5 points when your Network Bot
  completes Delivery Group setup".

## 11. Global Links

Existing Payload Detail `gpl:gen:<pid>` remains canonical. NEW:
Network → Global Links overview shows the signing-key diagnostic and
offers "➕ Create Global Link" → payload picker → the SAME
`gpl:gen:<pid>` mint flow (no duplicate implementation). Published
links still always point at the MAIN bot (`t.me/<main>?start=g<code>`);
the resolver picks a DELIVERY-READY bot at click time.

## 12. Database changes (v33 → v34, additive + idempotent)

New tables: `file_delivery_bot` (singleton id=1, encrypted credential
blob), `network_delivery_groups` (UNIQUE network_bot_id +
UNIQUE delivery_group_chat_id, checks JSON, verified_at), `delivery_jobs`
(status machine, attempts/max_attempts/next_retry_at, relay refs,
timestamps), `control_audit_events`. New columns on `network_bots`:
`management_mode` (default USER_OWNED), `credential_control` (default
OWNER), `created_via`. New setting seeds: relay TTL 900s, max attempts
5, retry base 30s, sweep interval 60s. No existing table/row touched;
v33 databases upgrade in place (verified).

## 13. Files changed

app/storage/schema.py (v34 tables + migration), app/storage/repositories/
delivery.py (NEW), network.py (mgmt metadata, credential replace,
ledger query, duplicate-award rollback fix), app/storage/database.py,
app/network/file_delivery.py (NEW), control_bot.py (NEW), routing.py
(delivery-ready predicate), registry.py (no storage probe at
registration; management metadata), points.py (DELIVERY_READY event +
award), lifecycle.py (FDB + job engine wiring, relay transport, DG
detection hook, control bot lifecycle, re-verification pass), bootstrap/
config.py (FILE_DELIVERY_BOT_TOKEN + CONTROL_BOT_TOKEN), services/
container.py (delivery_ui + control_ui factories), presentation/telegram/
delivery_ui.py (NEW), control_ui.py (NEW), network_wiring.py, _manifest.py,
callbacks.py, state.py, text_input.py, network_ui.py (My Network buttons,
+5 texts, managed-bot restrictions, links overview, control panel entry),
admin_panels.py (Platform Control button), web/site/html.py + screens.py +
pages.py (WS-1: SDK lifecycle, EndieFans, theme system, audio removal,
tap-to-play), .env.example (NEW), qa_gap_browser.py (self-relative paths +
post-SDK stub injection), 12 test files (schema pins + new checks),
test_file_delivery.py (NEW, 75 checks).

## 14. Telegram API verification (honest)

| Claim | Status |
|---|---|
| `copyMessage`/`deleteMessage` relay works bot-to-bot via group membership | DOCUMENTED (Bot API); logic verified against loopback fakes — LIVE TEST REQUIRED with real credentials |
| Bots cannot create Telegram groups; user creates + adds bots | DOCUMENTED limitation — wizard reflects it |
| FDB must be ADMIN with delete permission in the Delivery Group | DOCUMENTED (admin rights required to delete others' messages) — verification enforces it |
| No official API for a bot to hand its token to another bot | DOCUMENTED — the platform-managed flow uses the user-supplied BotFather token once |
| `request_managed_bot` / managed-bot APIs | NOT USED — no official stable Bot API method verified; the Create wizard is honest about this |
| Main Mini App initData HMAC validation | IMPLEMENTED per official docs (already present); SDK loading now fixed |
| Large-file (2-3 GB) relay copy limits | DOCUMENTATION DOES NOT SPECIFY A HARD COPY LIMIT — LIVE TEST REQUIRED (Local Bot API recommended for >20 MiB) |

## 15. Large file status

NOT live-tested (no real Telegram infrastructure in this environment).
The existing media transport layer (AUTO/CLOUD/LOCAL selection with
controlled too-large verdicts) is unchanged and covered by the media
suites (74 transport checks). 2-3 GB relay copies: LIVE TEST REQUIRED.

## 16. Test results (actually executed)

| Suite | Result |
|---|---|
| test_file_delivery.py (NEW v34) | PASSED 75/0 |
| test_network.py (updated to relay contract) | PASSED 82/0 |
| test_network_security.py | PASSED 34/0 |
| test_architecture.py | PASSED 96/0 |
| test_architecture_decoupling.py | PASSED 51/0 |
| test_admin_panels_gapclosure.py | PASSED 43/0 |
| test_botv13_phase6/7/7_hotfix/8 | PASSED 124/151/94/77 /0 |
| test_media_phase1/2/3/3ux/4/5 | PASSED 88/77/200/70/204/95 /0 |
| test_media_transport_auto.py | PASSED 74/0 |
| test_watch_ads.py + v2..v7 | PASSED 91/142/104/153/142/113/85 /0 |
| test_website_gapclosure.py | PASSED 66/0 (+5 new checks) |
| run_phase8_evidence.py | ALL SECTIONS PASS |
| run_network_evidence.py (updated to the relay chain) | ALL SECTIONS PASS |
| compileall | CLEAN |

Total: 2,531 checks, 0 failures, across 26 suites + both evidence
runners (run from the work tree). The final ZIP extraction re-runs a
smoke subset (below).

**BLOCKED / NOT RUN (honest):** live Telegram flows (real bot tokens,
real groups, real copyMessage), real-device Main Mini App (Android/
desktop Telegram), 2-3 GB transfers, live Local Bot API, live Monetag.
All deterministic logic for these is loopback-tested and marked above.

## 17. Real device results

NOT RUN in this environment (no Android/desktop Telegram available).
The startup state machine is verified in-browser via the WebApp stub
(see §18 of the wrapper requirements) and the honest non-Telegram deny
path in a plain desktop browser. Real-device verification remains
LIVE TEST REQUIRED.

## 18. Deployment

* `NETWORK_GLOBAL_LINK_SIGNING_KEY` — required for new-link minting
  (existing links keep verifying without it).
* `NETWORK_TOKEN_ENCRYPTION_KEY` — required before any registration or
  FDB credential storage (fail-closed).
* `FILE_DELIVERY_BOT_TOKEN` — optional seed; runtime management via the
  Control Bot (Add/Change Token) stores the encrypted credential.
* `CONTROL_BOT_TOKEN` — optional dedicated control-plane bot; without
  it, Platform Control lives in the main bot's admin panel.
* BotFather: the Main Mini App must be configured as the bot's Mini App
  (Bot Profile → Open). No second Website URL exists.
* Delivery Groups: user creates a private group, adds the FDB + their
  network bot, promotes the FDB to admin (Delete messages enabled),
  posts once in the group → verified automatically.
* Migrations run automatically on start (v34 additive).
* `.env.example` documents every variable; secrets are never logged.

## 19. Existing user migration (§62)

Existing network bots are untouched: rows, encrypted credentials,
points history and analytics preserved. Their legacy
`capabilities='storage:full'` value is no longer consulted by routing —
each existing bot must complete Delivery Group setup to become
DELIVERY_READY (existing bots get `DELIVERY_SETUP_REQUIRED` behavior
until then). No +5 is re-awarded for migration (legacy-reward guard).

## 20. Security model

initData HMAC (server-side, constant-time, freshness) → Website session
(AEAD cookie) → Force Join → Access Engine → 18+/authorization →
payload access — unchanged and enforced. Credentials: Fernet vault with
dedicated key; tokens never in UI/callbacks/URLs/logs/audit (verified
by test section K + the security suite). Platform-managed bots: backend
deregistration rejection, no token export, admin-only rotate/disable/
remove with audit. Storage masters are never deleted by the relay
pipeline (only relay messages the FDB created in delivery groups).
Delivery Group isolation is enforced by Telegram group membership
boundaries + UNIQUE associations.

## 21. Known limitations (honest)

1. Live Telegram behavior (copyMessage between real bots, group
   permission edges, FDB admin promotion UX) requires production
   credentials — verified against loopback fakes only.
2. Telegram offers no official API for a bot to CREATE a group or to
   transfer a token programmatically — the wizard requires the user to
   create the group via the Telegram app (honest UI).
3. The platform-managed bot's token was necessarily seen once by the
   user (BotFather hand-off). The platform prevents EXPORT by retaining
   exclusive possession (§32 honest claim), which the wizard states.
4. 2-3 GB relay transfers: LIVE TEST REQUIRED.
5. Real-device Mini App (Android/desktop, slow network, reduced motion):
   LIVE TEST REQUIRED; the reduced-motion and safe-area handling is
   implemented and browser-verified.
