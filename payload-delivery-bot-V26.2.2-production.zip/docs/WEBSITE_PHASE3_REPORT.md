# WEBSITE PHASE 3 — REPORT: Website Payload Platform

**Status: COMPLETE — STOP GATE (awaiting operator approval for Phase 4).**

Baseline: `payload-bot_website_phase2.zip` (verified green before any change:
77+88+1,451/0 + both evidence runners, re-executed from a fresh extraction in
`p3-work/`).

---

## 1. What was built (spec §1–§22)

### 1.1 Data layer — v31 migration (the planned "v30 part B")
- `website_payloads` — the ONE presentation table. Every row is a LISTING
  that references the canonical Payload system (`payload_id` →
  `payloads.id` for single-file Payloads; `collection_id` →
  `collections.collection_id` for multi-file Payloads), with a CHECK
  constraint enforcing exactly ONE canonical reference. **NO foreign keys by
  design**: deleting a canonical payload/collection never cascades into
  Website state and never blocks Telegram-side deletion; a dangling listing
  simply stops rendering publicly. Deleting a listing NEVER touches the
  canonical system.
- `opaque_id` (16 hex, `secrets`-generated) is the ONLY public identifier.
  Database ids, Telegram ids, message ids and `file_id` values are never
  exposed in Website URLs.
- Website presentation columns: `title`, `description`, `tags`,
  `thumb_file_id`/`thumb_file_unique_id` (identity discipline preserved),
  `position` (ordering), `published`, timestamps, `created_by`.
- Seeds: `website_enabled='false'` (opt-in — the Website starts OFF) and
  `website_public_base_url=''`.
- Migration implemented as a SEPARATE `if current < 31:` block (a database
  stamped at 30 must re-enter migration — the documented 27→28→29→30
  precedent). Additive/idempotent/restart-safe/non-destructive: `CREATE IF
  NOT EXISTS` + `INSERT OR IGNORE` only. `SCHEMA_STEPS` registry entry
  added. 24 documented pin updates (assertion VALUES only, historical
  labels untouched) across 11 test files.

### 1.2 Presentation layer — `app/web/site/` (7 new modules)
- `service.py` — `website_enabled` setting + ON/OFF, public base URL,
  thumbnail fallback chain (configured → payload image → indexed image →
  Telegram thumbnail → styled placeholder art), payload-link parsing
  (t.me links, bare codes, c-codes; strict charset, bounded), canonical
  resolution THROUGH the existing Payload system (`db.get_payload`,
  `get_collection`, `get_payload_file_overview`), listing detail assembly
  (single-file = 1 file; collection = all items in canonical position
  order; dead canonical → honest 404).
- `tokens.py` — opaque short-lived SIGNED video references
  (`encode_video_ref(listing, file_pk)` / `decode_video_ref`) reusing the
  existing CredentialVault AEAD (Fernet primary, stdlib HMAC-CTR fallback;
  no new cryptography). Tamper-proof, expiry-bound, listing-bound. This is
  the MINIMUM Phase 3 authorization boundary — the full stream-token
  playback infrastructure is Phase 4.
- `auth.py` — multi-token Mini App initData validation: main BOT_TOKEN
  first (never breaks main-bot auth), then ACTIVE network bot tokens via
  the injected provider (registry + vault decryption, 60s cache, tokens
  never logged/exposed). Built ON the canonical single-token validator
  from `app/web/auth.py` — zero duplicated HMAC code.
- `ratelimit.py` — bounded in-process sliding-window limiter (site_page
  60/min, site_video 30/min, site_auth 10/min, site_access 20/min; 5000
  tracked keys with pruning — the `_wad_status_ratelimit` discipline).
  Full streaming rate limiting is Phase 4.
- `html.py` — XSS-safe mobile-first rendering (`html.escape` on every
  dynamic value; no external resources; no inline handlers; no
  javascript: URLs; system fonts; ≥44px touch targets; responsive 1→2
  column grid; dark zinc + emerald accent).
- `pages.py` — the 6 aiohttp handlers + route registration on the EXISTING
  Mini App application (additive lines AFTER the pinned Watch Ads
  routes; `start_mini_app_server(None)` stays None-safe):
  - `GET /site` — Payload feed (Payload-level cards, DB-side pagination,
    deterministic order, 2 queries/page — N+1-free by test)
  - `GET /site/search` — normalized DB-side search over published
    listings (shared tokenization helpers — ONE search system)
  - `GET /site/payload/{opaque_id}` — Payload detail (thumbnail art,
    title, description, tags, file count, ordered Part 1..N list, each
    with a short-lived signed video ref; search-state preservation via
    q/p back links)
  - `GET /site/payload/{opaque_id}/video/{video_ref}` — file selection
    page (the Phase 3 minimum authorization boundary; tiny bootstrap
    script posts signed initData to the access API; verdict renders
    client-side from the server decision — the player transport is
    Phase 4, stated honestly)
  - `POST /site/api/auth` — server-side Mini App initData validation
    (multi-token)
  - `POST /site/api/access` — Access Engine verdict for a selected file
    (calls the EXISTING `access_engine` directly; NEVER `enforce_access`;
    the 9-call-site pin is untouched; human requirement text per reason)
- EVERY handler checks the GLOBAL `website_enabled` FIRST (503
  maintenance). The flag is checked ONLY here — never inside the Access
  Engine, never on Telegram-facing endpoints (structurally pinned by
  tests D2–D5).

### 1.3 Admin layer — `app/bot/handlers/website.py` + thin bot.py wiring
- `panel:website` button in the EXISTING main panel + `wsite:` callback
  namespace (verified FREE) — NO second admin dashboard.
- Website Control panel: global ON/OFF toggle, listings stats, entries.
- **Add Website Payload wizard** (exact spec §15 flow): Send Thumbnail
  (photo-only, skippable) → Enter/select existing Payload link → resolve
  canonical Payload → validate (dead payload / empty collection /
  duplicate listing → friendly errors, NO partial DB record) → Preview
  (title, description, tags, thumbnail, canonical identity, file count,
  not-saved marker) → Confirm Publish → listing published (+ URL shown;
  canonical Payload untouched).
- Website management: list (paginated, dangling-canonical markers),
  preview, publish/unpublish, edit title/description/tags/position,
  replace thumbnail, readiness check (honest integrity diagnostics — the
  spec §14 "Test Playback" implemented as a REAL check, never fake
  playback), delete with confirmation (presentation-layer only).
- Website Settings: public base URL editor (HTTPS-only, dash clears),
  Thumbnail Policy panel (the fallback chain + per-listing stats).
- Wizard/editor states registered in `ALL_WIZARD_STATES`
  (`wsite_wizard`, `wsite_edit`) — stale-state hygiene for free.
- bot.py wiring is THIN: `panel:website`/`wsite:` dispatch branches,
  media/text hook lines, `_wsite_deps()` late-binding facade, the website
  deps factory + route registration inside `start_mini_app_server`. All
  website logic lives in `app/`.

### 1.4 Security (spec §20)
Opaque ids + AEAD video refs (tamper/wrong-key/expiry/cross-listing all
fail closed — tested); server-side initData HMAC only (forged/stale
wrong-token → 401 — tested); XSS-escaped output (script/svg/onerror
injection attempts rendered inert — tested); SQL-injection-safe
(parameterized + escaped LIKE — tested); no secrets in URLs (initData in
the POST body; tokens never logged); path traversal style opaque ids →
404; admin-gated `wsite:` namespace (not in USER_FACING_PREFIXES);
`file_id` never projected into any web contract.

## 2. Test evidence — `test_media_phase3.py`: 197/0

The operator's mandatory A–Z list (§23) maps to checks:
- A Website ON → A1–A13 (feed cards/badges/pagination, detail parts,
  search, 404s)
- B Website OFF → B1–B5 (all public routes 503 maintenance)
- C maintenance → C1–C4 (mobile viewport, Telegram note, no data leaks)
- D OFF ≠ Telegram off → D0–D6 (span pins: `website_enabled` absent from
  access_engine / reward processor / start_command / enforce_access;
  enforce_access call sites == 9)
- E Watch Ads → E1–E5 (page served, S2S postback 200, unlock valid,
  engine authorized, identical verdict ON vs OFF)
- F Force Join → F1–F2 · G Referral → G1–G2 · H Points → H1–H3
  (credited, atomic purchase, engine `points_unlocked`)
- I Telegram delivery → I1–I2 (auto-resume runs the EXISTING pipeline
  while the website is OFF)
- J creation → J1–J6 · K canonical resolution → K1–K4 · L invalid link →
  L1–L2 (8 malformed inputs, zero partial records)
- M single-file → M1–M2 · N multi-file → N1 · O ordering → O1–O3
- P thumbnail → P1 · Q fallback → Q1–Q4
- R publish → R1 · S unpublish → S1–S2 · T edit → T1–T2 · U delete → U1
- V survival → V1–V3 (payload + indexed media + collection items)
- W feed → W1–W4 · X pagination → X1–X3 · Y search → Y1–Y7 (incl.
  injection + wildcard escapes) · Z ordering → Z1
- AA auth multi-token → AA1–AA11 · AB security → AB1–AB12 ·
  AC rate limiting → AC1–AC3 · AD N+1 proof → AD1 (+AD2–AD5) ·
  AE structural → AE20–AE38 · AF migration → AF1–AF17

Full battery from the working AND clean trees:
**197 + 88 + 77 + 1,451 = 1,813/0** + `run_phase8_evidence.py` ALL PASS +
`run_network_evidence.py` ALL PASS.

## 3. Live browser QA (agent-browser, real Chromium)

Booted the real site (in-process aiohttp, port 8080) with seeded data and
drove every surface; screenshots in `download/phase3-qa/`:
1. `01-feed.png` — cards with placeholder art, file-count badges, tags,
   search bar; unpublished listing correctly invisible.
2. `02-detail.png` — Part 1–3 ordered list, metadata, back link.
3. `03-search.png` — 1-result search with count; empty state verified.
4. `04-video.png` — Part 2 selection page with the honest "Open in
   Telegram" verdict outside the Mini App (fail-closed by design).
5. `05-maintenance.png` — Website OFF → clean mobile maintenance page
   while `/healthz` (Telegram-facing) stayed alive on the same server.
One cosmetic defect found and fixed by this QA (double arrow in the
detail back link).

## 4. Honesty: NOT implemented (Phase 4 scope, by design)

- Media Gateway (HTTP Range streaming, 206 handling) — NOT implemented.
- Shared streaming cache — NOT implemented.
- Stream-token playback transport beyond the Phase 3 selection-boundary
  authorization — NOT implemented (video page honestly states playback
  arrives with the streaming update; the readiness check never fakes a
  playback test).
- Servable thumbnail bytes over HTTP — Phase 3 renders styled placeholder
  art at every priority level (the chain is resolved as DATA and tested);
  actual thumbnail serving is the Phase 4 Media Gateway.
- Full streaming rate limiting — Phase 4.
- `website_stream_events` table — deliberately NOT created: Phase 3 has
  no real stream event to record (the spec allowed "only if genuinely
  needed by Phase 3" — it is not).

## 5. Known limitations

- Collection feed badges show "N files" (not "N videos") because the
  N+1-free feed query cannot know per-item media types without extra
  queries — honest generic label.
- Multi-token auth caches decrypted network tokens for 60s
  (`_WEBSITE_NET_TOKEN_CACHE_TTL`); a newly registered network bot is
  authable within ≤60s.
- The wizard thumbnail is stored as a Telegram file reference
  (`file_id`+`file_unique_id`) exactly like every other admin media in
  the codebase; rendering it requires Phase 4's gateway.

## 6. Artifacts

- Working tree: `/home/z/my-project/p3-work/payload-bot`
- Clean staging: `/home/z/my-project/phase3-clean/payload-bot` (133 files)
- Deliverable: `/home/z/my-project/payload-bot_website_phase3.zip`
- QA screenshots: `/home/z/my-project/download/phase3-qa/`

**STOPPED per the master prompt. AWAITING APPROVAL before Phase 4
(Media Gateway + Range streaming + shared cache + stream-token playback).**
