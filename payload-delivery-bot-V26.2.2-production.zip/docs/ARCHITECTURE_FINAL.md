# ARCHITECTURE FINAL — Payload Delivery Bot (ARCHITECTURE PROPER BREAKDOWN)

> The authoritative architectural record of the final modularization.
> Companion documents: `ARCHITECTURE_INVENTORY.md` (machine-audited
> before-state), `ARCHITECTURE_DEPENDENCY_GRAPH.md` (before/after graphs).
> Baseline ZIP SHA-256: `ac8b4b0b0a301c49027ec6511816633daec7e4527d081904cd4dfa9dfbd04a90`

## 1. Architecture BEFORE

* `bot.py` — 25,053 lines / 1,227,275 bytes — the center of gravity:
  562 top-level functions, 157 module-level names, ALL Telegram handlers,
  ALL mutable state, 97 compatibility facades. SHA-256
  `cfc59185b6f18860700ef9dab746eec76e6438d943af565c426e459fff120b40`.
* `run.py` and `app/main.py` imported bot.py and injected it into the
  composition root — the application could NOT be constructed without it.
* Domain services, storage, media, network and website layers were already
  extracted under `app/*` (previous phases), but the handler mass and the
  runtime state remained owned by bot.py.

## 2. Architecture AFTER

```
entrypoint (run.py / python -m app.main)
  → composition root (app/bootstrap/application.py)
    → presentation runtime (app/presentation/telegram — namespace.py)
      → application services (app/services/container.py)
        → domain (app/core) + infrastructure (app/storage, app/media,
          app/network, app/web)
```

bot.py is **REMOVED** (§19 Option A). Nothing in the repository imports it.
The production application is constructed exclusively from `app/*`.

## 3. Package responsibilities

| Package | Responsibility |
|---|---|
| `run.py`, `app/main.py` | process entrypoints; import the bootstrap only |
| `app/bootstrap/config.py` | THE configuration leaf: `RuntimeConfig.from_env` (hard guards: BOT_TOKEN sentinel check at build, ADMIN_IDS fail-closed) + `EnvDefaults` (all feature-default env parsing). The only `os.environ` readers in the application are this module and `app/media/config.py` (media transport's own config). |
| `app/bootstrap/application.py` | THE composition root: `load_runtime()` → `build_application(runtime)` → `run_production()`; fail-closed token/admin guards preserved verbatim |
| `app/presentation/telegram/` | THE Telegram presentation layer (see §5) |
| `app/services/container.py` | application-layer composition: `legacy_service_factories(runtime)`, website/media gateway composition, website deps snapshots |
| `app/core/*` | domain: Access Engine, payload/referral/force-join/watch-ads/delivery services, indexing engine, verification engine, FJ link health, format, constants |
| `app/storage/*` | infrastructure persistence: schema v32, migrations, `DatabaseBase` + 12 repository mixins (users, media, payloads, force-join, referrals, watch-ads, network, broadcasts, deliveries, settings, website, verification), dbutil re-export |
| `app/media/*` | media infrastructure: resolver, cloud/local Bot API sources, exactly-once repair, ranges, stream cache, stream tokens, gateway, HTTP client |
| `app/network/*` | network platform: credential vault, bot registry, points, routing, broadcast engine, workers, lifecycle |
| `app/web/*` | website presentation (`site/`: feed/search/detail/stream/auth/ratelimit/html) + mini-app server lifecycle + web auth |

## 4. bot.py final status

**REMOVED ENTIRELY (Option A — preferred).**

* `run.py`, `app/main.py`, all 20 regression suites and all 9 evidence
  scripts were migrated to the authoritative import
  (`from app.presentation.telegram import runtime as B`).
* `app/bot/` (the partial handler package of earlier phases) was merged
  into `app/presentation/telegram/` (`registration.py`, `keyboards.py`,
  `network_ui.py`, `website_ui.py`, `router.py`) and deleted.
* Deployment identity (`RUNTIME_BUILD_ID`, V5.1 §50 semantics) is now the
  SHA-256 of the presentation layer sources (`state._runtime_source_bytes`)
  — same copy → same id, any edit → new id.

## 5. The Telegram presentation package

`app/presentation/telegram/` — 36 modules:

* `state.py` — import zone, configuration bindings, constants, locks,
  caches, singletons (verbatim from bot.py, original order preserved).
* 31 section modules by responsibility: `guards` (admin_only), `compat`
  (service facades), `messaging`, `delivery`, `mediaops`, `indexing`,
  `forcejoin`, `settings`, `deletion`, `access`, `referral`, `watchads`,
  `retrieve`, `start`, `admin_commands`, `search`, `text_input`,
  `collections`, `broadcast`, `admin_panels`, `storage_panels`,
  `payloads_panels`, `access_panels`, `files_panels`, `stats_panels`,
  `callbacks` (the on_callback router), `lifecycle`, `miniapp`,
  `website_admin`, `network_wiring`, `wizard` — every function preserved
  VERBATIM from bot.py.
* `namespace.py` — assembles the shared runtime namespace: state
  foundation → manifest-driven function rebinding (FunctionType against
  the namespace dict) → @admin_only closure patching → RateLimiter class
  rebuild → `_LEGACY_NS`/`_SVCS` binding → manifest completeness assert.
  Published as `app.presentation.telegram.runtime` (importable object).
* `_manifest.py` — generated name→section manifest (completeness gate).
* `registration.py` — the PTB handler grammar (38 commands + 6 handlers).
* `keyboards.py`, `network_ui.py`, `website_ui.py`, `router.py` — the
  extracted UI modules (dependency-injected).

The shared runtime namespace preserves the late-binding contract the
regression suites rely on: monkey-patching `runtime.<name>` keeps working
everywhere, `global` statements mutate the shared namespace, and the
container's `legacy_service_factories(runtime)` binds the same object.

## 6. Database / storage boundaries

* SQLite lifecycle, schema and migrations: `app/storage/` (unchanged —
  **SCHEMA_VERSION remains 32**; existing databases open and migrate
  identically; fresh DBs stamp v32).
* New repository methods added for the RULE E fix:
  `VerificationRepoMixin` (6 read-only verification queries),
  `ForceJoinRepoMixin.get_fj_progress_row / insert_global_fj_progress /
  update_fj_progress_columns`, `UsersRepoMixin.first_active_admin_id`.
* `app/core/*` executes NO SQL (zero `.conn.execute/.commit/connect`) —
  verified by test gate 7a. `now_iso`/`safe_row_get` moved to
  `app/core/dbutil.py` (domain-owned; storage re-exports for compat).

## 7. Domain / application breakdown

* Domain services (app/core) are Telegram-free (gate 6a/6b: zero telegram
  modules after import, zero telegram import statements). The force-join
  membership/error classification uses an injected
  `telegram_types` port (container provides the classes from the
  presentation runtime; a name-based pure-Python fallback covers direct
  test construction).
* All env parsing centralized (`EnvDefaults`; gate 9a) — `constants.py`,
  `container.py`, `credentials.py` and `state.py` no longer read
  `os.environ`.

## 8. Website boundaries

* Website presentation stays in `app/web/site/` (preserved structure):
  feed (`/site`), search (`/site/search`), detail
  (`/site/payload/{opaque}`), signed video refs, multi-token WebApp auth,
  bounded rate limiting, XSS-escaped rendering, Website-OFF maintenance
  gate (checked in presentation — the Access Engine is never gated).
* Telegram-side website administration lives in
  `app/presentation/telegram/website_admin.py` + `website_ui.py`.
* The Mini App / Website HTTP server (`app/web/server.py`) binds the
  runtime namespace handlers (`_wad_*`, `_net_handle_webapp_auth`) and the
  website deps factory — same process, one event loop, one database.

## 9. Media boundaries

Unchanged architecture (cloud/local Bot API sources, file_id /
file_unique_id recovery, exactly-once repair retry, range streaming,
bounded memory, stream cache, tokens, gateway). Presentation delivery
transport (`fetch_channel_media`, `send_file` retry ladder) lives in
`mediaops.py` / `delivery.py` sections. `post_shutdown` now closes the
gateway stack's HTTP session (no dangling aiohttp ClientSession — §15).

## 10. Network / lifecycle boundaries

`app/network/lifecycle.py` owns worker startup/shutdown/health.
`post_init` (lifecycle section) starts background workers; `post_shutdown`
cancels + awaits every task, stops network services, stops the HTTP
server, closes the media gateway session, closes the database —
verified by the QA lifecycle run (§ below) and gate 11a/11b.

## 11. Dependency rules — enforcement

`tests/test_architecture_proper_breakdown.py` — 24 hard gates, all PASS:
bot.py gone (1a-1d), RULE A/B clean-interpreter import proofs (2a-2b),
composition constructs without bot.py — 44 handlers (3a), RULE I (3b),
RULE G/H AST layer-edge scan (4a), RULE J walk_packages import (5a),
RULE C clean-interpreter telegram-free domain+application (6a-6b),
RULE E SQL API scan + verification repository routing (7a-7b), RULE D
aiohttp scan (8a), RULE F env-centralization scan (9a-9b), runtime
namespace completeness + shared-globals + closure-patching semantics
(10a-10c), lifecycle cleanup (11a-11b), SCHEMA_VERSION 32 (12a-12b).

## 12. Test results (final tree)

* 20 regression suites: **2,226 passed / 0 failed** (exact baseline match).
* New architecture suite: **24 passed / 0 failed**.
* Full syntax compilation: every shipped `.py` compiles.
* Import smoke: all 122 `app.*` modules import (with the mandatory
  fail-closed ADMIN_IDS guard satisfied).

Known flake: `test_media_phase5.py` check LCK3 (doomed-entry janitor
directory removal within a 3s window) failed once under heavy parallel
load and passed on rerun — filesystem-timing sensitivity, documented,
not a regression.

## 13. Browser QA (executed against the real server)

Via the production lifecycle harness (`qa_lifecycle_server.py`: the
REAL post_init path with a fake Telegram identity, real DB, real
aiohttp server on :8080):

* Website ON: feed renders both published listings (cards, tags, sort
  links: Curated/Newest/A–Z); search filters correctly (q=video → only
  the video package); detail page shows the Part file list with a
  short-lived signed video reference; the video page renders the
  auth-gated honest fallback ("Open in Telegram" / not-streamable notice).
* Website OFF: maintenance page, HTTP 503, Telegram-side flows unaffected.
* Rate limiting: burst → 429 after the configured budget.
* XSS: `<script>alert(1)</script>` search payload renders escaped
  (`&lt;script&gt;…`); no unescaped script reflection.
* Mobile: 390×844 viewport renders responsively (viewport meta verified).
* No browser console errors / page errors on any page.
* Shutdown: SIGTERM → clean `post_shutdown` (server stopped, DB closed,
  zero dangling sessions).

Limitation: no real Telegram credentials / Local Bot API server were
available in this environment — credentialed Telegram delivery, real
media streaming and multi-GB range transfers were NOT exercised
end-to-end (only their architecture, unit-level transports and bounded
memory behavior via the existing suites).

## 14. Artifacts

See `RELEASE_NOTES` in the final report: complete runnable ZIP
`payload-bot_architecture_proper_final.zip` (source + tests + docs +
requirements + .env.example + miniapp driver + QA harness), extracted
and re-tested from a fresh directory + fresh venv.
