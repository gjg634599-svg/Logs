# Deployment Guide — Payload Delivery Bot (PHASE 8)

## Requirements

* Python 3.12+
* A Telegram bot token (@BotFather)
* The bot added as **administrator** to every storage channel and every
  force-join channel (invite-permission + join-request management
  recommended)
* SQLite (file-based, no external service)

## Install

```bash
pip install -r requirements.txt
cp .env.example .env      # then edit
python run.py             # production entrypoint (app/bootstrap composition)
```

**Deploy the whole directory.** `run.py` and `app/` must travel
together — the PHASE 8 correctness services (`app/core/*`) are hard
imports. The single-file bot.py build was removed by the ARCHITECTURE
PROPER BREAKDOWN — deploy the tree.
fails fast at startup with a clear ImportError.

## Environment variables

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `BOT_TOKEN` | yes | — | Telegram bot token |
| `ADMIN_IDS` | yes | — | Comma-separated owner Telegram user ids |
| `BOT_USERNAME` | auto | detected | Bot @username (auto-detected at startup) |
| `DATABASE_FILE` | no | `payload_bot.db` | SQLite database path |
| `MINI_APP_ENABLED` | no | `true` | Watch Ads Mini App HTTP server toggle |
| `MINI_APP_PORT` | no | `8080` | Mini App HTTP port (same process as the bot) |
| `MINI_APP_BASE_URL` | no | — | One-time SEED for the Watch Ads URL (the DB setting is authoritative afterwards) |
| `AUTO_REINDEX_ON_STARTUP` | no | `true` | One-shot incremental scan of active channels at boot |
| `AUTO_REINDEX_INTERVAL` | no | `60` | Auto-scan period (seconds) |

## Runtime settings (Settings panel / bot_settings)

PHASE 8 additions (all seeded with backward-compatible defaults):

* `fj_link_auto_rotate` = `1` — auto-repair Telegram-confirmed dead
  invite links (create → verify → atomic store → revoke old). Set `0` to
  require manual rotation.
* `fj_link_health_cache_ttl` = `300` — link-health cache seconds
  (spec §18). Invalidated automatically on admin link change, rotation,
  join-request events, Telegram API errors and the manual Test button.

## Reverse proxy / networking

The bot process serves the Watch Ads Mini App on `MINI_APP_PORT`
(aiohttp, same event loop). Put it behind an HTTPS reverse proxy and set
Settings → Watch Ads → Mini App Website to the public URL. Health probe:
`GET /healthz`.

## Local Bot API (large files) — NOT DEPLOYED in this build

The unified specification's multi-GB streaming architecture (MediaResolver
+ Local Bot API + Range streaming + persistent chunk cache) is **PHASE 4
of the staged plan and is NOT part of this build** — see
`docs/TEST_REPORT.md` §"Not executed". When it lands, deployment will
require: `api_id`/`api_hash`, a `telegram-bot-api` server with
`--local`, PTB `base_url`/`base_file_url` pointing at it, `--log-out` of
the cloud session once, and a volume for the file cache. Those variables
are documented here so operators can plan; nothing in the current build
reads them.

## Operations runbook

* **After a bot-token change:** restart, then run Storage Center → Index →
  Full Reindex (refreshes every canonical file_id in place; the run
  summary shows "File IDs refreshed: N"). First deliveries also
  self-repair transparently (PHASE 7 HOTFIX engine).
* **Storage Center numbers:** "Indexed files in DB" is the database total;
  the available/unavailable split comes from verification. Run Verify
  Index + Reconcile whenever the two disagree with reality.
* **Index menu:** Quick Sync (incremental, auto-resumes), Full Reindex
  (fresh complete walk), Resume (only offered when an interrupted job
  exists), Reindex From File, Verify Index (read-only), Reconcile
  (apply safe repairs).
* **Force Join:** every channel row shows its channel + link health.
  Dead links offer "Generate New Link"; the Test Channel diagnostic
  verifies the link via Telegram.
* **Logs:** structured events include
  `BOT6_INDEX_SCAN_FINISHED status=…`, `BOT6_INDEX_RESUME`,
  `INDEX_VERIFY_COMPLETE …`, `FORCE_JOIN_LINK_HEALTH …`,
  `FORCE_JOIN_STARTUP_HEALTH …`, `FORCE_JOIN_LINK_AUTO_REPAIR …`.
  No secrets or full invite URLs are ever logged (prefixes only).

## Upgrades

See `docs/MIGRATION.md`. Always back up `payload_bot.db` first; the v28
migration is idempotent, additive-only and restart-safe.

---

# Deployment — NETWORK PLATFORM (v29)

## New environment variable

* `NETWORK_TOKEN_ENCRYPTION_KEY` — master secret for encrypting registered
  network-bot tokens (authenticated encryption). Generate once, store in
  your secret manager:
  `python3 -c "import secrets; print(secrets.token_urlsafe(48))}"`.
  Unset → a per-process key derived from BOT_TOKEN is used and
  `key_version=-1` marks it (tokens decrypt only on the same deployment;
  set the variable before registering network bots in production).

## New admin surfaces

* **Admin panel → 🌐 Network Control** — registered bots, bot health
  (with manual re-check), points settings (enable/disable, cost), global
  payload links overview, network settings (enable/disable, max bots per
  user, broadcast rate, confirmation threshold).
* **Payload Manager → payload detail → 🌐 Global Link** — mint an opaque
  signed Global Payload Link for any payload.
* **Broadcast Center** (Network Control → 📢) — TEXT / Copy Message /
  Forward / Payload Announcement wizards with preview (audience + method
  + reachable-user count + large-broadcast confirmation) and durable
  pause/resume/cancel.

## New user surfaces

* `/network` — 🌐 My Network: registered bots (with disable/remove),
  points balance + history, the Add-Bot wizard (token submission →
  Telegram verification → explicit ownership consent → activation →
  +5 points).
* `[⭐ Unlock with N Points]` on gated payloads (Watch Ads / Referral
  screens) — atomic point purchase.

## Network bot prerequisites (operational)

* The bot token must be free (not polled elsewhere — Telegram allows one
  connection per bot).
* For PAYLOAD delivery the network bot must be added to the storage
  channel(s) (read/copy access); otherwise it is honestly
  payload-ineligible (still usable for broadcasts from sources it can
  access, and it still records reachability).
* Removal/leave events: workers recover at restart; health checks mark
  TEMPORARILY_UNAVAILABLE (transient) vs TOKEN_INVALID (needs explicit
  re-registration/credential replacement).

## Runbook additions

* **Restart behavior:** ACTIVE network bots' workers restart
  automatically; RUNNING broadcasts resume from their durable per-user
  rows (never from zero; already-SENT users are not re-sent).
* **After a MAIN-bot token change:** unchanged runbook (Full Reindex
  refreshes canonical file_ids in place). Network bots are unaffected
  (their delivery path is source-copy, not file_id).
* **Broadcast monitoring:** Broadcast Center → Active Jobs shows
  per-broadcast progress (sent/failed/blocked) and per-bot job status;
  statistics come from the durable tables (never 100% before durable
  completion).
* **Structured logs:** NETWORK_BOT_REGISTER_SUCCESS/FAILED,
  NETWORK_WORKER_STARTED, NETWORK_BOT_TOKEN_INVALID, POINTS_CREDITED/
  DEBITED/REJECTED/DUPLICATE_EVENT, GLOBAL_PAYLOAD_RESOLVE/ROUTE/
  ROUTE_FAILED, BROADCAST_CREATED/STARTED/PROGRESS/COMPLETED/PAUSED/
  RESUMED/CANCELLED/FAILED, NETWORK_DELIVERY_*, NETWORK_WEBAPP_AUTH_*.
  Credential material is never logged.

## Mini App (network)

`POST /api/network/auth` validates Telegram WebApp initData
(HMAC-SHA256, auth-date freshness) and returns the authenticated user +
points + a shared-Access-Engine payload verdict. The full browsing UI
remains future scope (see docs/NETWORK.md §10).

---

# GAP-CLOSURE deployment notes (schema v33)

## Required production secrets

| Variable | Purpose | When missing |
|---|---|---|
| `NETWORK_TOKEN_ENCRYPTION_KEY` | Encrypts registered network-bot tokens at rest (authenticated encryption, key_version tracked) | NEW registrations are REFUSED (fail-closed); existing legacy credentials keep decrypting |
| `NETWORK_GLOBAL_LINK_SIGNING_KEY` | Signs Global Payload Links | Creating NEW links is REFUSED (fail-closed); existing links keep verifying |

Generate once, store in your secret manager, back them up, and keep them
independent of `BOT_TOKEN`:

```
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

Rotation: set the new value, then re-register network bots / re-mint links
(dual-key verification keeps OLD links valid across the rotation window).

## Media transport (AUTO — recommended)

`TELEGRAM_API_MODE=auto` + `TELEGRAM_LOCAL_API_URL` (optional):

* No local server configured → everything runs on the plain cloud Bot API
  (works TODAY; a 4.3 MB video streams fine with range seeks).
* Local server configured + healthy → used for media streaming; small
  files automatically fall back to cloud when it goes down mid-request;
  large files (> `MEDIA_CLOUD_MAX_BYTES`, one constant, default 20 MiB)
  REQUIRE the local server and fail with a controlled error otherwise.
* Health is automatic: startup probe → cached HEALTHY state (60s TTL) →
  backoff probes while UNAVAILABLE (15s) → recovery without restart.
  Traffic outcomes feed the monitor (DEGRADED after transient errors).
* Explicit `local` mode also points the python-telegram-bot runtime at the
  local server (base_url/base_file_url) for the main bot AND workers.

## Website (login, categories, ads, packs)

* The site is login-gated: Telegram WebApp initData is HMAC-validated
  server-side; the user may additionally type their Telegram user ID OR
  username, which the backend compares against the authenticated identity
  (mismatch = 403). Sessions are signed cookies (identity only — payload
  access ALWAYS re-runs the Access Engine).
* Force Join: the site shows the exact unjoined channels (backend-provided
  URLs) with a Verify Again recheck — the same authoritative batch view as
  the Telegram side.
* Categories (Movies/Anime/18+/Shorts by default) are managed from
  Website Control → 🗂 Categories; payloads are ASSIGNED to categories
  (never duplicated). 18+ content is excluded from every feed at the SQL
  level for users without a confirmed age gate.
* Ads: Website Control → 📢 Ads Management (campaigns, creatives,
  placements, analytics, previews). All ad decisions are server-side;
  frequency caps use the authenticated identity; admins + the exempt list
  never see ads; an ads failure NEVER blocks content.
* Download packs: `POST /site/api/pack` (per-file Access Engine
  authorization, bounded by files/bytes settings) streams a store-only ZIP.

## Schema

v33 (additive only): `website_categories`, `website_payload_categories`,
`ad_campaigns`, `ad_creatives`, `ad_placements`, `ad_events`,
`ad_frequency_state` + setting seeds. The v32 → v33 migration is
idempotent and preserves all existing data.

v36 (BOT-13, additive only): `payloads.show_get_file` (per-payload
📥 Get File ON/OFF, default 1) + `payloads.video_ad_destination`
(per-payload delivery mode BOT/WEBSITE/NONE, default 'BOT') +
`delivery_jobs.user_message_id` (duplicate-delivery audit) +
`network_capability_ttl_seconds` seed. Backward compatible: existing
payloads keep Get File ON and BOT mode; migrations are idempotent and
preserve all existing data.

---

## v37 (bot-8.log production fixes) — operator notes

### What changed for operators

1. **NETWORK_TOKEN_ENCRYPTION_KEY now reports one unambiguous line at
   startup** — `NETWORK_TOKEN_ENCRYPTION_KEY: configured (dedicated key
   active, key_version=1; ...)` when set, `... : missing — ...` when not.
   The secret itself is never logged.
2. **Setting the dedicated encryption key NO LONGER breaks existing
   network bots.** Previously, configuring
   `NETWORK_TOKEN_ENCRYPTION_KEY` made every legacy
   (BOT_TOKEN-encrypted) credential undecryptable at restart
   (`NETWORK_BOT_TOKEN_INVALID network_bot_id=1`,
   `NETWORK_WORKERS_STARTED count=0`). The vault now keeps a
   decrypt-only legacy secondary key and **transparently migrates**
   legacy credentials to the dedicated key on worker start
   (`NETWORK_BOT_CREDENTIAL_MIGRATED network_bot_id=...` in the log).
   A credential that fails under BOTH keys is reported honestly as
   `NETWORK_BOT_CREDENTIAL_INVALID ... reason=CREDENTIAL_DECRYPT_FAILED`
   (the record is preserved — nothing is deleted or fabricated; recover
   by replacing the token via Managed Bot token replacement or
   re-registering the bot).
3. **Global Links work with mixed-case codes.** The `/start` handler no
   longer lowercases the deep-link argument before signature
   verification (the root cause of "Invalid or expired link" for
   virtually every minted link). Every link stage emits a structured
   diagnostic (`GLOBAL_LINK_START_RECEIVED/PARSE_OK/DB_LOOKUP_OK/
   PAYLOAD_OK/ROUTE_DECISION/DELIVERY_OK` + failure variants).
4. **`/network` is in the user command menu** (it already had a real
   CommandHandler; the menu entry was missing). The panel is the
   persistent **Network Bot Management** view — fully reconstructed
   from the database, with a per-bot **Manage Bot** button and truthful
   worker status. It survives restarts and re-opening `/network`.
5. **Delivery Group "Check Again" explains itself.** A Network Bot that
   is TOKEN_INVALID or has no running worker is reported explicitly;
   `DELIVERY_GROUP_VERIFY_START/RESULT/FAILURE` structured logs carry
   network_bot_id / chat_id / result / reason. Network workers also
   register an explicit `/setup` command handler (deterministic entry;
   any group message still triggers detection).
6. **Create Network Bot uses the REAL Telegram Managed Bot flow**
   (`KeyboardButtonRequestManagedBot` → Telegram's managed-bot creation
   UI → `getManagedBotToken` → encrypted registration). No BotFather
   token pasting in the normal path. The manual token import survives
   only as an admin-only **LEGACY/MANUAL IMPORT** (`nleg:`) for
   migration. Token replacement uses the atomic
   `replaceManagedBotToken` sequence (old credential kept on failure).
7. **Video pre-roll ads** are available on the website player
   (Control Panel → Website Settings → Video Pre-Roll Ads, `wspr:`).
   OFF by default; the operator sets an absolute `https://` ad source
   (`.mp4`/`.webm`) and enables it. The Website Monetag Rich Tag
   (DB-configured) and the root `sw.js` are untouched.
8. **Rapid double-taps** on state-changing callbacks
   (`gpl:gen:*`, `ctl:fdb:restart`, `ctl:managed:*`, `nbc:*` state
   transitions) are de-bounced (1.2 s, exact-duplicate only) — the
   duplicate is answered "Already processing" and skipped.
9. **Client disconnects during media streaming** are classified as
   quiet `STREAM_CLIENT_DISCONNECT ... phase=write` (INFO) — never as
   upstream `STREAM_HTTP_ABORT` warnings. Upstream body failures keep
   the honest WARNING (`phase=body`).

### Required environment (unchanged names — do not invent new ones)

- `BOT_TOKEN`, `ADMIN_IDS`, `DATABASE_FILE`
- `NETWORK_TOKEN_ENCRYPTION_KEY` (dedicated; required for NEW bot
  registrations — fail-closed without it)
- `NETWORK_GLOBAL_LINK_SIGNING_KEY` (dedicated; required for NEW global
  link minting — fail-closed without it)
- Optional: `FILE_DELIVERY_BOT_TOKEN`, `CONTROL_BOT_TOKEN`,
  `TELEGRAM_API_MODE`/`TELEGRAM_LOCAL_API_URL`, `MINI_APP_*`,
  `ORIGIN_PROXY_SECRET`, `WEBSITE_MONETAG_AD_TAG`

### Known operator actions still open (from bot-8.log)

- The 7 force-join channels are inaccessible to the bot
  (`channel_invalid=7`) — remove or replace them in Force Join
  Settings; the diagnostics stay truthful and never blame users.
- Configure the Website pre-roll ad source URL if you want pre-roll
  ads (off by default).

## b10 FINAL (bot-10.log production fixes) — operator notes

### What changed for operators (on top of v37)

1. **Delivery Group setup completes end-to-end from the group.** The
   pending-setup intent is now a DURABLE database record (visible to the
   worker app, 24h expiry) — `/setup` (or ANY owner message) in the
   group runs the REAL verification chain and answers definitively:
   `✅ DELIVERY GROUP READY` or `❌ DELIVERY GROUP NOT READY` with the
   exact reason. "Check Again" always re-runs verification (never a
   dead end).
2. **Manual bot-token input is reliable.** The token-input intent
   survives callback navigation and is accepted exactly once; the flow
   emits `BOT_TOKEN_INPUT_STARTED / BOT_TOKEN_RECEIVED /
   BOT_TOKEN_VALIDATION_STARTED / BOT_TOKEN_VALIDATION_RESULT /
   BOT_TOKEN_PERSISTED / BOT_TOKEN_FLOW_FAILED` (never the token).
   Invalid tokens keep the retry state; duplicates are reported as
   `duplicate_bot`.
3. **Managed-bot creation works from ANY registered Network Bot** with
   the `can_manage_bots` capability (fresh getMe check per creating
   bot). A worker without the capability answers with the exact
   BotFather one-time setup instruction (never "open the main bot").
4. **Every registered bot exposes the MAIN Mini App** — `🌐 Open Main
   App` button (canonical `website_public_base_url + /site`,
   HTTPS-validated) on the worker start/menu surfaces, a best-effort
   Telegram menu button (`NETWORK_BOT_MENU_BUTTON_APPLIED/_FAILED`),
   re-applied on every worker start. Operator policy:
   `bot_settings.network_bots_menu_button_mode = auto|preserve`
   (default auto). Admin bulk action: Network Control → **Apply Main
   App Link to All Registered Bots**.
5. **Removing a Network Bot is now terminal and consistent** — status
   REMOVED, excluded from the 5-bot cap and all panels, stale actions
   answered truthfully, repeated removes idempotent
   (`NETWORK_BOT_REMOVE_IDEMPOTENT`).
6. **Global Links route terminally.** MAIN-bot arrival delivers
   immediately; a network-bot arrival that cannot serve redirects
   terminally to the MAIN bot ("Continue in @main"); funnel counts are
   logged (`routable=… ready=… reachable=…`).
7. **Website 18+ category is usable.** `GET /site/c/{slug}` serves the
   age gate pre-confirmation (no content/metadata/media leaks; the API
   plane enforces the same), and the 🔞 18+ nav entry is always
   visible. Confirmation uses the existing session age flag only.
8. **Website video ads are provider-agnostic.** Configure per §9-§16:
   provider `none|direct|vast` (bot settings via the admin panel);
   HilltopAds VAST URL is an admin value (never hardcoded). Not
   configured → content plays with no ad (`WEBSITE_VIDEOAD_DECISION …
   serve=False reason=disabled`).
9. **Access-policy panels never trip the Markdown fallback** (the
   byte-177 `_FORCE\_JOIN_` legacy-parser bug is fixed at the root).
10. **Rapid double-clicks on state-changing network callbacks are
    debounced** (exact-shape patterns; read-only navigation unaffected).

### Deploy steps

Deploy the whole tree and restart. No migration action needed — all
schema changes are additive and auto-applied at startup. After restart:
- verify `MANAGED_BOTS_READY can_manage_bots=…`,
- re-test `/network` → Create Network Bot (main AND from a registered
  bot), the Delivery Group `/setup` flow, and a Global Link click,
- set `website_public_base_url` (drives the Open Main App link) if not
  already set,
- fix or remove the 7 invalid force-join channels (operator data —
  startup reports them truthfully as channel_invalid).

## B11 (bot-11) — multi-bot delivery, random website routing, honest recovery

Root causes from bot-11.log are fixed at source; the B10 FINAL multi-bot
plane is complete. Operator notes:

11. **Set the two dedicated persistent secrets before first start** (both
    fail CLOSED when missing): `NETWORK_TOKEN_ENCRYPTION_KEY` (new bot
    credentials are refused without it) and `NETWORK_GLOBAL_LINK_SIGNING_KEY`
    (Global Link / Website Get File minting is refused without it; existing
    BOT_TOKEN-signed links keep verifying). Generate with
    `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`.
12. **The Website "Get File" button routes through a RANDOM
    delivery-eligible REGISTERED bot** (server-side
    `select_random_delivery_bot`: ACTIVE/DEGRADED + enabled + a
    DELIVERY_READY delivery group; REMOVED/DISABLED/not-ready bots are
    never picked, the MAIN bot is never the silent default). Each click
    mints a DURABLE targeted Global Link (`target_network_bot_id`,
    `target_mode='random'` — locked in at creation, never re-rolled at
    /start). No eligible bot → the honest 503 `no_delivery_bot` notice
    (the `website_get_file_allow_main_fallback` operator switch, default
    0, is the ONLY path back to the main bot). Rapid and CONCURRENT
    duplicate clicks coalesce into ONE mint (2s window + in-flight lock).
13. **Force Join is verified by the MAIN bot** on every surface — even
    when the /start arrived through a network worker (§18:
    FORCE_JOIN_MAIN_VERIFIER_START/RESULT in the logs).
14. **Removed bots recover honestly**: same-owner REMOVED duplicates are
    offered Reactivate / Change Token (fresh getMe identity validation,
    no fabricated credentials); ACTIVE duplicates offer Manage / Change
    Token. `ctl:managed:list` buttons render real labels (the dict-as-text
    BadRequest is fixed; a defensive keyboard-text validator now coerces
    any non-string label with TELEGRAM_KEYBOARD_TEXT_FIXED).
15. **File delivery in worker context resolves its network_bot_id** through
    the explicit worker-manager chain (DELIVERY_TARGET_BOT_RESOLVED /
    DELIVERY_RESOLVE_START…DELIVERY_SEND_FAILED chain logs) — the
    network_bot_id=0 mass-failure class from bot-11.log is gone.
16. **python-telegram-bot>=22.8,<23 is REQUIRED** (managed-bot APIs:
    KeyboardButtonRequestManagedBot, get_managed_bot_token,
    set_chat_menu_button). Older versions will ImportError at startup.

After deploy: register 2+ bots, complete their Delivery Group /setup,
verify the website Get File URL points at a REGISTERED bot username
(t.me/<registered_bot>?start=g…), and re-run /network → Refresh Bot
Capabilities + Apply to All Registered Bots.
