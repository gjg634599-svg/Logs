# BOT-16 Production Fix Report

This release fixes the production failures reported with bot-16.log and
the 1000043701.pdf screenshots against `payload-bot_PRODUCTION_CLEAN_FINAL.zip`
(SHA-256 f66baa7936d0d5a0865ab0f9ce4e3ed180638ca5ca146775be9b7fb30f2c2207).

## Root causes and fixes

### 1. Telegram delivery failure (jobs 28/29: NETWORK_DELIVERY_RELAY_GONE)
**Root causes (layered):**
- The relay message was created with `protect_content=True`; a protected
  relay can be rejected when the network bot copies it onward
  ("message to copy not found" 200 ms after creation, while the relay
  actually existed — the TTL sweep deleted it 15 minutes later).
- The retry plane was 100 % broken: `bot = await resolver(nid)` awaited
  the SYNC `BotWorkerManager.get_bot_client` → the recurring
  `DELIVERY_SWEEP_ERROR object ExtBot can't be used in 'await' expression`
  (bot-16.log every ~75 s). Jobs 28/29 never retried.
- The TTL pass then marked the FAILED jobs `DELIVERED` (a lying state).

**Fixes (app/network/file_delivery.py):**
- Relays are created WITHOUT `protect_content` (protection applies only
  on the final user-facing hop).
- `_copy_group_to_user` returns `(message_id, verdict)` with the REAL
  Telegram exception class + description logged at every failure point
  (chat/group/relay/job context included — never a bare
  `final_delivery_failed` again).
- **Relay self-heal**: on "message to copy not found" the relay is
  recreated from the Storage master and the user copy retried once
  (inline AND retry paths).
- `_resolve_worker_client` supports sync AND async resolvers.
- The TTL pass settles FAILED rows as `EXPIRED` (only crash-ambiguous
  DELIVERING rows without a recorded failure settle DELIVERED).

### 2. /site/site/media/... 404 (every media request)
**Root cause:** `build_site_url("site/media/…", base)` concatenated the
admin's `website_public_base_url` (legitimately ending in `/site`) with
the internal route path (already prefixed `site/…`). Same bug produced
the broken `…/site/site` Main Mini App menu button on every network bot.

**Fixes:** `normalize_site_url` (app/web/site/service.py) normalizes the
base path EXACTLY ONCE (segment-overlap dedup, idempotent; unit-locked
for `/`, `/site`, `/site/`, worker-prefixed deployments);
`canonical_main_app_url` (app/network/bot_miniapp.py) reuses it.

### 3. MKV/HEVC "Cannot play in this browser"
**Root cause:** zero codec detection — raw Telegram bytes were served
with `video/x-matroska` and the browser rejected HEVC-in-MKV.

**Fixes (new):** `app/media/probe.py` (cached ffprobe verdicts +
`classify_browser_compatibility`), `app/media/transcode.py`
(TranscodeManager: per-identity coalescing, bounded concurrency, variant
ladder ≤ source height, corrupt-partial redo, LRU/TTL cleanup), the
`/site/hls/{token}/{path}` route (app/web/site/hls.py — token decode +
Access Engine re-verification per request, strict path validation), and
issuance-time `codec_verdict`/`hls_url`/`variants`/`duration`
(app/web/site/stream.py). The player uses native HLS or hls.js (CDN,
direct-stream fallback) and a REAL quality menu.

### 4. Website force join (non-admin)
**Fixes:** FJ gates on the payload/video/search surfaces (pages.py);
per-channel state mapping (`not_joined` / `api_temporary_failure` /
`invalid_channel` / `bot_permission_failure` — never "not joined" on a
verify error); the temporary-error regression fixed (a stored invite URL
still renders its Join button with an honest note); the player renders
an in-place Join Required UI with Join buttons + Verify Membership →
re-issues the stream WITHOUT a reload or a Telegram redirect;
`playerbox.gated` keeps the box clickable before media mounts.
Verified for a NON-ADMIN user end-to-end in real Chromium.

### 5. Ad surface separation
**Fixes:** the per-payload `video_ad_destination` (BOT/WEBSITE/NONE)
gate is REMOVED from stream issuance (the website pre-roll follows the
Website ad settings; Telegram Watch Ads follow the Telegram settings —
zero shared state, zero watch_ad_sessions from website playback). The
admin payload panel shows clean controls (Telegram Ads / Get File /
Website Ads via Website Settings); the literal-template bug
(`Watch Ads: {'ON' if wad_on else 'OFF'}` rendered verbatim) is fixed;
the stale `plvad:` callback answers honestly without mutating the
deprecated column; the pre-roll block state no longer offers a Telegram
CTA. The DB column is preserved (deprecated, inert).

### 6. Registered-bot removal (the REMOVED bot still listed)
**Fixes:** the three repository list methods exclude REMOVED rows by
default (`include_removed=True` opt-in); health checks and capability
refresh no longer write onto REMOVED rows; `managed:enable/disable/
remove/rotate` gained stale-REMOVED guards (a removed bot can no longer
be flipped back to PENDING); `remove_bot` now also disables the bot,
retires memberships, deactivates targeted global links, clears
capability/mini-app state and writes `removed_at` (schema v37,
additive); the full lifecycle is logged
(`MANAGED_BOT_REMOVE_REQUEST` → `MANAGED_BOT_WORKER_STOPPED` →
`MANAGED_BOT_REMOVE_COMPLETE`). Restart and capability refresh cannot
resurrect a removed bot (locked by tests).

### 7. Player experience
Custom control bar (play/pause, seek with buffered shading, time,
volume/mute), playback speed (0.5–2×, persisted), fullscreen (container
level + iOS fallback), PiP, keyboard shortcuts, loading/error/retry
states (re-issue without a page reload), resume (per user+listing+file
localStorage identity; >95 % completed clears it), Start Over (real
currentTime reset), quality menu with the REAL variant ladder, HLS
branch with hls.js/native HLS, mobile-first layout.

## Verification
- 39 test suites / 2,914 checks / 0 failures (includes 4 new BOT-16
  suites: transcoding 149, bot removal 54, delivery relay 42, website
  FJ 79 — real ffmpeg in the loop).
- Browser QA (real Chromium + real server): 45/45 checks, 14
  screenshots — see `battery/qa16_final_result.txt` in the TEST archive.
- Security: compileall clean, secret scan 217 files / 0 findings,
  ffmpeg via exec (no shell), HLS path traversal rejected, AEAD stream
  tokens with per-request Access Engine re-verification.

## Environment-blocked (honest)
- Live Telegram delivery (no live token in this environment) — the
  relay chain is verified to the PTB boundary with strict stubs.
- Live VAST/HilltopAds/Monetag inventory (provider adapters are
  suite-verified; the QA ad media is locally served).
- Live Cloudflare Worker deployment (worker.js is `node --check` clean;
  no wrangler credentials here).

## Migration
Schema v37 (additive `network_bots.removed_at`; no destructive change;
`video_ad_destination` retained but deprecated/inert). Fresh DBs and
v36 databases both verified.
