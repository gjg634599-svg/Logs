#!/usr/bin/env python3
"""BOT-43 (work-stream A) — STORAGE LIFECYCLE REGRESSION SUITE.

Run:  python3 tests/test_bot43_indexing.py

Covers the three BOT-43 storage-lifecycle fixes against the REAL
production code (the composed runtime namespace, the real Database /
schema, the real repo mixins) on a throwaway SQLite file — only the
Telegram transport boundary is faked (the same class of mocked
verification tests/test_v26_production.py uses; the live Telegram API is
unreachable from this environment):

  R. SOURCE_MEDIA_REPLACEMENT — the same (channel_id, message_id) with a
     NEW file_unique_id updates the canonical row IN PLACE (pk, payload
     FKs and stats preserved) instead of silently inserting a SECOND row;
     the identity-conflict / missing-field guards fall through to the
     normal path; the preload-set semantics; the live index_message
     path; the unchanged-uid duplicate regression.
  P. RENAME PROPAGATION — an edited filename propagates to the DERIVED
     display defaults (payloads.display_name + single-listing
     website_payloads.title) and NEVER over admin-curated values.
  S. SINGLE_SOURCE_RESOLVE — the exact-source resolution lifecycle
     telemetry (START / RESULT / classified REJECT) in the Single File
     Link wizard text handler.
  W. WIZARD MARKDOWN — the payload wizard name/confirm steps render the
     RAW filename as a code span (the production file_pk=681
     "Can't parse entities: can't find end of the entity" root cause).
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import sys
import types
from datetime import datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:BOT43_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(_ROOT, "tests", "_bot43_indexing_test.db")

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


# ---------------------------------------------------------------------------
# Fakes (transport boundary only — everything else is the REAL code)
# ---------------------------------------------------------------------------
CAPTURED: dict = {}


async def fake_safe_edit_text(q, text, reply_markup=None, **kw):
    CAPTURED["edit"] = (text, reply_markup)
    return True


async def fake_safe_send_text(bot, chat_id, text, reply_markup=None, **kw):
    CAPTURED.setdefault("sends", []).append((text, reply_markup))
    return True


class _FakeBot:
    """Stands in for the PTB client object (never actually called — the
    safe_send_text / safe_edit_text wrappers are faked above)."""


_FAKE_BOT = _FakeBot()


class FakeCallbackQuery:
    async def answer(self, text=None, show_alert=False):
        return True


class FakeChat:
    def __init__(self, chat_id):
        self.id = chat_id
        self.type = "private"


class FakeUser:
    id = 8370454312
    first_name = "Admin"


class FakeMessageObj:
    def __init__(self, text):
        self.text = text


class FakeUpdate:
    def __init__(self, text=None, chat_id=8370454312):
        self.message = FakeMessageObj(text) if text is not None else None
        self.callback_query = FakeCallbackQuery()
        self.effective_chat = FakeChat(chat_id)
        self.effective_user = FakeUser()

    def get_bot(self):
        return _FAKE_BOT


class FakeContext:
    def __init__(self, user_data=None):
        self.user_data = user_data if user_data is not None else {}
        self.bot_data = {}
        self.application = types.SimpleNamespace(bot_data={})
        self.bot = _FAKE_BOT


async def build_env():
    """Fresh DB + namespace with the REAL production code loaded."""
    for suffix in ("", "-wal", "-shm"):
        _p = os.environ["DATABASE_FILE"] + suffix
        if os.path.exists(_p):
            os.remove(_p)
    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    NS = _ns_mod.NS
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    NS.db = db
    NS.safe_edit_text = fake_safe_edit_text
    NS.safe_send_text = fake_safe_send_text
    return NS, db


class _Cap(logging.Handler):
    """INFO capture on the production payload-bot logger."""

    def __init__(self):
        super().__init__(level=logging.INFO)
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


class _LogCapture:
    """Context manager: capture INFO lines from the payload-bot logger."""

    def __init__(self):
        self.cap = _Cap()
        self._pl = logging.getLogger("payload-bot")
        self._prev = self._pl.level

    def __enter__(self):
        self._pl.setLevel(logging.INFO)
        self._pl.addHandler(self.cap)
        return self

    def __exit__(self, *exc):
        self._pl.removeHandler(self.cap)
        self._pl.setLevel(self._prev)
        return False


# ---------------------------------------------------------------------------
# Telegram object builders (REAL telegram.Message / Document — the same
# pattern the V26 suite's section S uses for the reindex duplicate path)
# ---------------------------------------------------------------------------
ADMIN = 8370454312
CH = -1004460709060        # replacement/propagation scenarios
CH2 = -1004460709070       # single-source resolve (exact pair)
CH3 = -1004460709080       # single-source resolve (ambiguity)


def _tg_classes():
    from telegram import Message as TGMsg, Chat as TGChat, Document as TGDoc
    return TGMsg, TGChat, TGDoc


def _doc(uid, fid, name, size=1000, mime="video/mp4"):
    _TGMsg, _TGChat, _TGDoc = _tg_classes()
    return _TGDoc(file_id=fid, file_unique_id=uid, file_name=name,
                  file_size=size, mime_type=mime)


class FakeScanBot:
    """Stands in for the PTB client: copy_message returns a REAL
    telegram.Message carrying the (possibly replaced) document."""

    def __init__(self, doc):
        self._doc = doc

    async def copy_message(self, chat_id, from_chat_id, message_id, **kw):
        _TGMsg, _TGChat, _TGDoc = _tg_classes()
        return _TGMsg(
            message_id=777, date=datetime.now(timezone.utc),
            chat=_TGChat(id=ADMIN, type="private"),
            document=self._doc)

    async def delete_message(self, chat_id, message_id, **kw):
        return True


async def _seed_row(db, ch, msg, uid, fid, name, size=1000,
                    media_type="document"):
    """Insert an indexed_files row directly; returns its pk."""
    now = datetime.now(timezone.utc).isoformat()
    await db.conn.execute(
        "INSERT INTO indexed_files(channel_id, message_id, file_id, "
        "file_unique_id, media_type, file_name, file_size, upload_date) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (ch, msg, fid, uid, media_type, name, size, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM indexed_files WHERE file_unique_id = ?", (uid,))
    return int((await cur.fetchone())[0])


async def _seed_payload(db, slug, index_pk, display_name=None):
    """Insert a payloads row (display_name NULL unless given); returns id."""
    now = datetime.now(timezone.utc).isoformat()
    if display_name is None:
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, created_at, "
            "updated_at) VALUES (?, ?, 'active', ?, ?)",
            (slug, index_pk, now, now))
    else:
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, display_name, "
            "created_at, updated_at) VALUES (?, ?, 'active', ?, ?, ?)",
            (slug, index_pk, display_name, now, now))
    await db.conn.commit()
    cur = await db.conn.execute(
        "SELECT id FROM payloads WHERE payload = ?", (slug,))
    return int((await cur.fetchone())[0])


async def _pair_count(db, ch, msg):
    cur = await db.conn.execute(
        "SELECT COUNT(*) AS c FROM indexed_files WHERE channel_id = ? "
        "AND message_id = ?", (ch, msg))
    return int((await cur.fetchone())["c"])


async def _get_payload(db, pid):
    cur = await db.conn.execute(
        "SELECT * FROM payloads WHERE id = ?", (pid,))
    return await cur.fetchone()


async def _get_listing(db, dbid):
    return await db.get_website_payload_by_dbid(dbid)


def _md_parses(text) -> bool:
    """Legacy-Markdown safety proxy: outside code spans every entity
    marker must be balanced (no 'can't find end of the entity' shapes)."""
    if text is None:
        return False
    segs = str(text).split("`")
    if len(segs) % 2 == 0:
        return False  # unmatched code span
    for i, seg in enumerate(segs):
        if i % 2 == 1:
            continue  # inside a code span — inert for Telegram
        if seg.count("_") % 2 or seg.count("*") % 2:
            return False
        if seg.count("[") != seg.count("]"):
            return False
    return True


def _uid_hash(value) -> str:
    return hashlib.sha256(str(value or "").encode("utf-8", "replace")).hexdigest()[:16]


# ===========================================================================
async def section_r(ns, db):
    """[R] SOURCE_MEDIA_REPLACEMENT — the guarded in-place swap."""
    print("\n[R] BOT-43 §A — source media replacement (same source, new identity)")

    # R1/R2/R5 — the production scenario: admin replaced the media in the
    # edited post; a payload + a website listing already point at the row.
    pk1 = await _seed_row(db, CH, 700, "UID_A_OLD", "FID_A_OLD",
                          "original_a.mp4")
    cur = await db.conn.execute(
        "SELECT upload_date FROM indexed_files WHERE id = ?", (pk1,))
    seeded_upload = (await cur.fetchone())["upload_date"]
    p1 = await _seed_payload(db, "b43rep_a", pk1)
    l1 = await db.create_website_payload(payload_id=p1, title="original_a",
                                          published=1)

    with _LogCapture() as cap:
        bot = FakeScanBot(_doc("UID_A_NEW", "FID_A_NEW", "replaced_b.mp4"))
        outcome, info = await ns._index_one_message(bot, ADMIN, CH, 700)

    row = await db.get_indexed_file_by_id(pk1)
    check("R1 same source + new uid -> outcome 'replaced', ONE row, "
          "file_pk preserved, identity updated",
          outcome == "replaced"
          and await _pair_count(db, CH, 700) == 1
          and int(row["id"]) == pk1
          and str(row["file_unique_id"]) == "UID_A_NEW"
          and str(row["file_id"]) == "FID_A_NEW"
          and str(row["file_name"]) == "replaced_b.mp4"
          and int(row["channel_id"]) == CH
          and int(row["message_id"]) == 700,
          f"outcome={outcome} row={dict(row) if row else None}")

    check("R1b preserved columns: upload_date/stats never touched",
          str(row["upload_date"]) == str(seeded_upload)
          and int(row["views"]) == 0 and int(row["downloads"]) == 0)

    prow = await _get_payload(db, p1)
    check("R2 payload FK still resolves to the SAME canonical row",
          prow is not None and int(prow["index_id"]) == pk1
          and (await db.get_indexed_file_by_id(int(prow["index_id"]))) is not None
          and int((await _get_listing(db, l1["id"]))["payload_id"]) == p1)

    starts = [ln for ln in cap.cap.lines
              if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_START")]
    completes = [ln for ln in cap.cap.lines
                 if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE")]
    check("R5 replacement telemetry START + COMPLETE (hashes, no raw ids)",
          bool(starts) and bool(completes)
          and f"channel_id={CH}" in starts[-1]
          and "message_id=700" in starts[-1]
          and f"file_pk={pk1}" in starts[-1]
          and f"old_file_unique_id_hash={_uid_hash('UID_A_OLD')}" in starts[-1]
          and f"new_file_unique_id_hash={_uid_hash('UID_A_NEW')}" in starts[-1]
          and "old_filename='original_a.mp4'" in starts[-1]
          and "new_filename='replaced_b.mp4'" in starts[-1]
          and "result=ok" in completes[-1]
          and "UID_A_OLD" not in starts[-1] and "UID_A_NEW" not in starts[-1]
          and "FID_A_NEW" not in completes[-1])

    # R3 — UNIQUE conflict: the NEW uid is already owned by ANOTHER row.
    # (Preload-mode race shape: the scan's identity set was built BEFORE the
    # conflicting row appeared — the guard must refuse and fall through to
    # the normal insert path, where the UNIQUE constraint stays intact.)
    await _seed_row(db, CH, 701, "UID_C", "FID_C", "conflict_src.mp4")
    pk3 = await _seed_row(db, CH, 702, "UID_X_NEW", "FID_X", "owner.mp4")
    known3 = await db.all_indexed_unique_ids()
    known3.discard("UID_X_NEW")  # the concurrent insert the scan missed
    with _LogCapture() as cap3:
        bot3 = FakeScanBot(_doc("UID_X_NEW", "FID_X2", "conflicting.mp4"))
        outcome3, _ = await ns._index_one_message(
            bot3, ADMIN, CH, 701, known_unique_ids=known3)
    row701 = await db.get_indexed_file_by_channel_message(CH, 701)
    row702 = await db.get_indexed_file_by_unique_id("UID_X_NEW")
    failed3 = [ln for ln in cap3.cap.lines
               if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_FAILED")]
    check("R3 identity conflict -> NO replacement, honest FAILED, normal path",
          outcome3 == "error"  # the normal insert path hit the UNIQUE guard
          and str(row701["file_unique_id"]) == "UID_C"
          and str(row701["file_name"]) == "conflict_src.mp4"
          and await _pair_count(db, CH, 701) == 1
          and int(row702["id"]) == pk3
          and str(row702["file_name"]) == "owner.mp4"
          and bool(failed3) and "reason=identity_conflict" in failed3[-1]
          and "message_id=701" in failed3[-1]
          and not [ln for ln in cap3.cap.lines
                   if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE")],
          f"outcome={outcome3} failed={failed3[-1] if failed3 else None}")

    # R4 — guard: fresh uid present but file_id EMPTY -> honest skip +
    # fall through to the normal insert path (no replacement).
    pk4 = await _seed_row(db, CH, 703, "UID_D_OLD", "FID_D", "guard_src.mp4")
    with _LogCapture() as cap4:
        bot4 = FakeScanBot(_doc("UID_D_NEW", "", "guard_new.mp4"))
        outcome4, _ = await ns._index_one_message(bot4, ADMIN, CH, 703)
    row703 = await db.get_indexed_file_by_channel_message(CH, 703)
    skipped4 = [ln for ln in cap4.cap.lines
                if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_SKIPPED")]
    check("R4 fresh file_id empty -> no replacement (normal insert path)",
          outcome4 != "replaced"
          and str(row703["file_unique_id"]) == "UID_D_OLD"
          and str(row703["file_name"]) == "guard_src.mp4"
          and bool(skipped4)
          and "reason=missing_fresh_file_id" in skipped4[-1]
          and not [ln for ln in cap4.cap.lines
                   if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE")],
          f"outcome={outcome4} skipped={skipped4[-1] if skipped4 else None}")

    # R6 — batched preload semantics: after a replacement the OLD uid is
    # gone from THIS scan's perspective; the NEW uid dedups; a later
    # message carrying the OLD uid re-inserts as a genuinely new row.
    pk5 = await _seed_row(db, CH, 706, "UID_E_OLD", "FID_E", "old_e.mp4")
    known = await db.all_indexed_unique_ids()
    with _LogCapture():
        bot5 = FakeScanBot(_doc("UID_E_NEW", "FID_E_NEW", "new_e.mp4"))
        outcome5, _ = await ns._index_one_message(
            bot5, ADMIN, CH, 706, known_unique_ids=known)
    check("R6a preload set: OLD uid discarded, NEW uid added",
          outcome5 == "replaced"
          and "UID_E_OLD" not in known
          and "UID_E_NEW" in known,
          f"outcome={outcome5} old_in={'UID_E_OLD' in known} "
          f"new_in={'UID_E_NEW' in known}")
    with _LogCapture():
        bot6 = FakeScanBot(_doc("UID_E_OLD", "FID_E_OLD2", "resurrected_e.mp4"))
        outcome6, _ = await ns._index_one_message(
            bot6, ADMIN, CH, 707, known_unique_ids=known)
    row_e_old = await db.get_indexed_file_by_unique_id("UID_E_OLD")
    check("R6b re-scan with the OLD uid inserts a genuinely new row",
          outcome6 == "indexed"
          and row_e_old is not None
          and int(row_e_old["message_id"]) == 707
          and str(row_e_old["file_name"]) == "resurrected_e.mp4"
          and int(row_e_old["id"]) != pk5,
          f"outcome={outcome6}")

    # R7 — the LIVE edited-post path (index_message) mirrors the replacement.
    pk7 = await _seed_row(db, CH, 710, "UID_F_OLD", "FID_F", "live_old.mp4")
    _TGMsg, _TGChat, _TGDoc = _tg_classes()
    live_msg = _TGMsg(
        message_id=710, date=datetime.now(timezone.utc),
        chat=_TGChat(id=CH, type="channel"),
        document=_doc("UID_F_NEW", "FID_F_NEW", "live_replaced.mp4"))
    with _LogCapture() as cap7:
        await ns.index_message(live_msg, edited=True, bot=None)
    row710 = await db.get_indexed_file_by_channel_message(CH, 710)
    completes7 = [ln for ln in cap7.cap.lines
                  if ln.startswith("INDEX_REPLACE_SOURCE_MEDIA_COMPLETE")]
    check("R7 live index_message path replaces in place too",
          row710 is not None
          and int(row710["id"]) == pk7
          and str(row710["file_unique_id"]) == "UID_F_NEW"
          and str(row710["file_name"]) == "live_replaced.mp4"
          and await _pair_count(db, CH, 710) == 1
          and bool(completes7) and "result=ok" in completes7[-1])

    # R8 — regression: UNCHANGED uid at the same source is still a
    # duplicate + the mutable-metadata refresh still fires (V26 §S).
    pk8 = await _seed_row(db, CH, 720, "UID_G", "FID_G", "old_g.mp4")
    with _LogCapture() as cap8:
        bot8 = FakeScanBot(_doc("UID_G", "FID_G", "new_g.mp4"))
        outcome8, _ = await ns._index_one_message(bot8, ADMIN, CH, 720)
    row720 = await db.get_indexed_file_by_id(pk8)
    changed8 = [ln for ln in cap8.cap.lines
                if ln.startswith("INDEX_REINDEX_METADATA_CHANGED")]
    check("R8 unchanged uid at same source -> still 'duplicate' + refresh",
          outcome8 == "duplicate"
          and str(row720["file_name"]) == "new_g.mp4"
          and str(row720["file_unique_id"]) == "UID_G"
          and await _pair_count(db, CH, 720) == 1
          and bool(changed8)
          and "old_filename='old_g.mp4'" in changed8[-1]
          and "new_filename='new_g.mp4'" in changed8[-1])


# ===========================================================================
async def section_p(ns, db):
    """[P] RENAME PROPAGATION — edited filename -> derived defaults."""
    print("\n[P] BOT-43 §B — edited filename propagates to derived defaults")

    pk = await _seed_row(db, CH, 730, "UID_H", "FID_H", "clip_one.mp4")
    p_def = await _seed_payload(db, "b43prop_one", pk, display_name="clip_one")
    p_cur = await _seed_payload(db, "b43prop_two", pk, display_name="Curated Name Stays")
    p_null = await _seed_payload(db, "b43prop_three", pk, display_name=None)
    l_slug = await db.create_website_payload(payload_id=p_def, title="clip_one",
                                             published=1)
    l_cur = await db.create_website_payload(payload_id=p_cur,
                                            title="Curated Title Stays",
                                            published=1)
    l_null = await db.create_website_payload(payload_id=p_def, title=None,
                                             published=1)
    l_raw = await db.create_website_payload(payload_id=p_null,
                                            title="clip_one.mp4", published=1)
    l_coll = await db.create_website_payload(collection_id="a1b2c3d4",
                                            title="clip_one", published=1)

    with _LogCapture() as cap:
        bot = FakeScanBot(_doc("UID_H", "FID_H", "clip_two.mp4"))
        outcome, _ = await ns._index_one_message(bot, ADMIN, CH, 730)

    row = await db.get_indexed_file_by_id(pk)
    check("P1 file_name OLD->NEW refreshed on the canonical row",
          outcome == "duplicate" and str(row["file_name"]) == "clip_two.mp4")

    dn_def = await _get_payload(db, p_def)
    dn_null = await _get_payload(db, p_null)
    check("P2 payloads.display_name default (=slug of OLD) -> slug of NEW "
          "(NULL materializes too)",
          str(dn_def["display_name"]) == "clip_two"
          and str(dn_null["display_name"]) == "clip_two")

    dn_cur = await _get_payload(db, p_cur)
    check("P3 admin-curated display_name NOT touched",
          str(dn_cur["display_name"]) == "Curated Name Stays")

    t_slug = await _get_listing(db, l_slug["id"])
    t_null = await _get_listing(db, l_null["id"])
    t_raw = await _get_listing(db, l_raw["id"])
    check("P4 single-listing title defaults updated (slug / NULL / raw-name "
          "shapes)",
          str(t_slug["title"]) == "clip_two"
          and str(t_null["title"]) == "clip_two"
          and str(t_raw["title"]) == "clip_two.mp4",
          f"slug={t_slug['title']!r} null={t_null['title']!r} raw={t_raw['title']!r}")

    t_cur = await _get_listing(db, l_cur["id"])
    t_coll = await _get_listing(db, l_coll["id"])
    check("P5 curated title + collection/package listing NOT touched",
          str(t_cur["title"]) == "Curated Title Stays"
          and str(t_coll["title"]) == "clip_one"
          and t_coll["collection_id"] == "a1b2c3d4")

    propagated = [ln for ln in cap.cap.lines
                  if ln.startswith("INDEX_RENAME_PROPAGATED")]
    check("P6 INDEX_RENAME_PROPAGATED logged with bounded id lists",
          bool(propagated)
          and f"file_pk={pk}" in propagated[-1]
          and f"payload_ids={p_def}" in propagated[-1]
          and f"payload_ids={p_def},{p_null}" in propagated[-1]
          and str(l_slug["id"]) in propagated[-1].split("listing_ids=")[1]
          and str(l_null["id"]) in propagated[-1].split("listing_ids=")[1]
          and str(l_raw["id"]) in propagated[-1].split("listing_ids=")[1]
          and str(l_cur["id"]) not in propagated[-1].split("listing_ids=")[1]
          and "old_filename='clip_one.mp4'" in propagated[-1]
          and "new_filename='clip_two.mp4'" in propagated[-1],
          propagated[-1] if propagated else "no line")

    changed = [ln for ln in cap.cap.lines
               if ln.startswith("INDEX_REINDEX_METADATA_CHANGED")]
    check("P7 INDEX_REINDEX_METADATA_CHANGED carries old/new filename",
          bool(changed)
          and "old_filename='clip_one.mp4'" in changed[-1]
          and "new_filename='clip_two.mp4'" in changed[-1])


# ===========================================================================
async def section_s(ns, db):
    """[S] SINGLE_SOURCE_RESOLVE telemetry + the wizard markdown fix."""
    print("\n[S] BOT-43 §C — single-source resolve telemetry + wizard markdown")
    from app.presentation.telegram import runtime as _rt  # noqa: F401 — pin

    hostile = "video_[special_2024.mkv"
    pk_ss1 = await _seed_row(db, CH2, 800, "UID_SS1", "FID_SS1", hostile)
    await _seed_row(db, CH3, 800, "UID_SS2", "FID_SS2", "other.mkv")
    pk_w = await _seed_row(db, CH2, 810, "UID_W", "FID_W",
                           "confirm_[name_2024.mp4", media_type="video")

    async def _drive(text, user_data=None):
        CAPTURED.pop("sends", None)
        CAPTURED.pop("edit", None)
        upd = FakeUpdate(text)
        ctx = FakeContext(user_data if user_data is not None else {})
        await ns.text_handler(upd, ctx)
        return ctx

    # S1/S2 — exact pair resolves: START + RESULT + the wizard name step.
    with _LogCapture() as cap:
        await _drive(f"{CH2}:800",
                     user_data={"awaiting_single_msgid": True})
    starts = [ln for ln in cap.cap.lines
              if ln.startswith("SINGLE_SOURCE_RESOLVE_START")]
    results = [ln for ln in cap.cap.lines
               if ln.startswith("SINGLE_SOURCE_RESOLVE_RESULT")]
    check("S1 SINGLE_SOURCE_RESOLVE_START/RESULT on exact-pair success",
          bool(starts) and bool(results)
          and f"channel_id={CH2}" in starts[-1]
          and "message_id=800" in starts[-1]
          and f"channel_id={CH2}" in results[-1]
          and "message_id=800" in results[-1]
          and f"file_pk={pk_ss1}" in results[-1]
          and "media_type=document" in results[-1]
          and f"file_unique_id_hash={_uid_hash('UID_SS1')}" in results[-1]
          and "outcome=resolved" in results[-1]
          and "UID_SS1" not in results[-1] and "FID_SS1" not in results[-1])

    # S2 — the wizard name step carries the filename ESCAPED (code span),
    # and the whole text parses as valid legacy Markdown. (Callback-driven
    # flow edits the message; text-driven flow sends — check BOTH shapes.)
    name_step = None
    for t, _rk in (CAPTURED.get("sends") or []):
        if "Selected File" in t:
            name_step = t
    if name_step is None and CAPTURED.get("edit"):
        _et = CAPTURED["edit"][0]
        if "Selected File" in _et:
            name_step = _et
    check("S2 wizard name-step renders the hostile filename as a code span",
          name_step is not None
          and f"`{hostile}`" in name_step
          and _md_parses(name_step),
          f"step={name_step!r}")

    # S3 — invalid number.
    with _LogCapture() as cap3:
        await _drive("not_a_number",
                     user_data={"awaiting_single_msgid": True})
    rej3 = [ln for ln in cap3.cap.lines
            if ln.startswith("SINGLE_SOURCE_RESOLVE_REJECT")]
    check("S3 reject reason=invalid_number",
          bool(rej3) and "reason=invalid_number" in rej3[-1]
          and "media_type=-" in rej3[-1])

    # S4 — exact pair not found.
    with _LogCapture() as cap4:
        await _drive("555:800", user_data={"awaiting_single_msgid": True})
    rej4 = [ln for ln in cap4.cap.lines
            if ln.startswith("SINGLE_SOURCE_RESOLVE_REJECT")]
    check("S4 reject reason=exact_pair_not_found",
          bool(rej4) and "reason=exact_pair_not_found" in rej4[-1]
          and "channel_id=555" in rej4[-1] and "message_id=800" in rej4[-1])

    # S5 — ambiguous bare id (exists in TWO channels).
    with _LogCapture() as cap5:
        await _drive("800", user_data={"awaiting_single_msgid": True})
    rej5 = [ln for ln in cap5.cap.lines
            if ln.startswith("SINGLE_SOURCE_RESOLVE_REJECT")]
    check("S5 reject reason=ambiguous",
          bool(rej5) and "reason=ambiguous" in rej5[-1]
          and "channel_id=-" in rej5[-1] and "message_id=800" in rej5[-1])

    # S6 — not indexed.
    with _LogCapture() as cap6:
        await _drive("999", user_data={"awaiting_single_msgid": True})
    rej6 = [ln for ln in cap6.cap.lines
            if ln.startswith("SINGLE_SOURCE_RESOLVE_REJECT")]
    check("S6 reject reason=not_indexed",
          bool(rej6) and "reason=not_indexed" in rej6[-1]
          and "message_id=999" in rej6[-1])

    # W1 — the confirm step (ParseMode.MARKDOWN) renders the auto-preview
    # filename as a code span too (the second raw-filename interpolation).
    CAPTURED.pop("edit", None)
    state = ns._pcw_new_state(index_id=pk_w)
    state["owner_id"] = ADMIN
    state["name"] = "b43wz01"
    ctx = FakeContext()
    ctx.user_data[ns.PCW_KEY] = state
    upd = FakeUpdate()
    await ns.pcw_show_confirm_step(upd, ctx)
    confirm_text = (CAPTURED.get("edit") or (None, None))[0]
    check("W1 confirm step (MARKDOWN) renders the preview filename escaped",
          confirm_text is not None
          and "`confirm_[name_2024.mp4`" in confirm_text
          and _md_parses(confirm_text),
          f"text={confirm_text!r}"[:200])

    # W2 — source-level pin: the production crash site is fixed in wizard.py.
    import inspect as _insp
    from app.presentation.telegram import wizard as _wizard_mod
    _wsrc = _insp.getsource(_wizard_mod.pcw_show_name_step)
    check("W2 the name step builds the Selected File line via md_code_span",
          "md_code_span(truncate(frow['file_name'], 60)" in _wsrc
          and "f\"\\U0001F4C4 Selected File\\n{truncate(" not in _wsrc)


# ===========================================================================
async def main() -> int:
    ns, db = await build_env()
    await section_r(ns, db)
    await section_p(ns, db)
    await section_s(ns, db)
    await db.close()
    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nBOT-43 INDEXING SUITE: {RESULTS['pass']}/{total} "
          f"passed, {RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
