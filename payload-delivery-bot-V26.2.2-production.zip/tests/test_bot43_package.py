#!/usr/bin/env python3
"""BOT-43 WORK-STREAM B — the Website PACKAGE PICKER authoritative-state
+ association DIFF-SAVE contract (spec §11).

Run:  python3 tests/test_bot43_package.py

Every check runs against the REAL production code (the real
Database/schema/repositories, the real website_ui handlers and wizard
publish engine) on a throwaway SQLite file. Nothing is mocked except
the Telegram transport boundary (the same class of fakes the V26
suite's O/X/Z sections use to drive handle_wsite_callback).

The BOT-43 §11 contract under test:
  * list_website_collection_codes — the AUTHORITATIVE package
    association set (website_payloads rows with a non-null
    collection_id, deterministic order);
  * the picker OPEN (wsite:addpkg) SEEDS the selection from the
    authoritative rows UNION any surviving in-session toggles — the
    green-check (✅) keyboard marks show what is LIVE on the Website,
    even after clear_wizard_states purged the transient state;
  * WEBSITE_PACKAGE_SELECTION_{OPEN,STATE,ADD,REMOVE,CLEAR,SAVE}
    telemetry with the exact field shapes (phase=save distinguishes an
    APPLIED removal from a picker toggle);
  * Continue (wsite:pkcont) is a DIFF SAVE: current (authoritative) vs
    desired (validated selection) — added codes route INTO the existing
    wizard (added-only; kept/removed need no wizard), removed codes are
    deleted from website_payloads IMMEDIATELY (only that table), an
    EMPTY selection is a deliberate UNSELECT-ALL that removes every
    package association while collections / collection_items /
    indexed_files / storage are NEVER touched;
  * apply_website_collection_diff is ONE all-or-nothing transaction
    (write_lock + BEGIN IMMEDIATE): an unknown added code rolls back
    the whole diff; already-listed added codes are skipped (idempotent);
    the default title replicates the wizard's _package_display_name
    chain;
  * Select All asks for exactly the repository page-size clamp (100 —
    the previous request of 200 was silently truncated) and documents
    the cap in the toast;
  * every picker callback stays ≤ 64 bytes and well-formed (never a
    payload_id=None / Button_data_invalid shape).
"""
from __future__ import annotations

import asyncio
import os
import re as _re
import sys
import types
from datetime import datetime, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:V26_MAIN_TEST_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
DB_PATH = os.path.join(_ROOT, "tests", "_bot43_package_test.db")
os.environ["DATABASE_FILE"] = DB_PATH

import logging  # noqa: E402

logging.basicConfig(level=logging.WARNING)

RESULTS = {"pass": 0, "fail": 0, "failures": []}


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        RESULTS["pass"] += 1
        print(f"  ✓ {name}")
    else:
        RESULTS["fail"] += 1
        RESULTS["failures"].append(f"{name} {detail}")
        print(f"  ✗ FAIL {name} {detail}")


AID = 8370454312  # the admin id driving every callback (ADMIN_IDS)


class _LogCap:
    """Capture structured log lines from the payload-bot logger."""

    def __init__(self):
        self.lines = []
        self._h = logging.Handler()
        self._h.emit = lambda rec: self.lines.append(rec.getMessage())  # type: ignore[method-assign]
        self._h.setLevel(logging.INFO)

    def __enter__(self):
        logging.getLogger("payload-bot").addHandler(self._h)
        logging.getLogger("payload-bot").setLevel(logging.INFO)
        return self

    def __exit__(self, *a):
        logging.getLogger("payload-bot").removeHandler(self._h)

    def lines_with(self, prefix):
        return [ln for ln in self.lines if ln.startswith(prefix)]


# ---------------------------------------------------------------------------
# The Telegram transport boundary fakes (the O/X/Z machinery).
# ---------------------------------------------------------------------------
class FakeCallbackQuery:
    def __init__(self):
        self.data = ""
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))
        return True


class FakeChat:
    id = AID


class FakeUser:
    id = AID
    first_name = "Admin"


class FakeMessage:
    chat = FakeChat()


class FakeUpdate:
    def __init__(self):
        self.callback_query = FakeCallbackQuery()
        self.effective_chat = FakeChat()
        self.effective_user = FakeUser()
        self.effective_message = FakeMessage()


def _fake_cb(upd, data):
    upd.callback_query.data = data
    return upd


class FakeContext:
    def __init__(self):
        self.user_data = {}
        self.bot = types.SimpleNamespace()


sent: list = []


async def _edit(q, text, reply_markup=None, **kw):
    sent.append((text, reply_markup))
    return True


async def _send(bot, chat_id, text, reply_markup=None, **kw):
    sent.append((text, reply_markup))
    return True


async def _answer(q, text=None, show_alert=False):
    return True


async def _log_action(*a, **kw):
    return True


async def _rpl(link):
    return None


def _flat_kb(kb):
    return [b for row in (kb.inline_keyboard if kb else []) for b in row]


def _btn_by_cb(flat, cb):
    for b in flat:
        if str(b.callback_data or "") == cb:
            return b
    return None


# ---------------------------------------------------------------------------
async def main() -> int:
    from app.presentation.telegram import website_ui as wui
    from app.storage.schema import Database

    for suffix in ("", "-shm", "-wal"):
        if os.path.exists(DB_PATH + suffix):
            os.remove(DB_PATH + suffix)

    db = Database(DB_PATH)
    await db.connect()
    await db.init_schema()
    deps = types.SimpleNamespace(db=db, safe_edit_text=_edit,
                                 safe_send_text=_send,
                                 safe_answer_callback=_answer,
                                 log_admin_action=_log_action,
                                 resolve_payload_link=_rpl)
    upd = FakeUpdate()

    NOW = datetime.now(timezone.utc).isoformat()
    CH = -1004460799

    async def mk_coll(code, mid_base, n, display):
        """A REAL package: collections + collection_items + indexed_files
        + the c<code> wrapper payload with its display_name (the exact
        shape the V26 suite's X section seeds)."""
        await db.conn.execute(
            "INSERT INTO collections(collection_id, channel_id, "
            "file_count, created_at) VALUES (?, ?, ?, ?)",
            (code, CH, n, NOW))
        for p in range(n):
            await db.conn.execute(
                "INSERT INTO indexed_files(channel_id, message_id, "
                "file_id, file_unique_id, media_type, file_name, "
                "file_size, upload_date) VALUES (?, ?, ?, ?, 'video', "
                "?, 1000, ?)",
                (CH, mid_base + p, f"XFID{mid_base}{p}",
                 f"XFUID{mid_base}{p}", f"{display} part{p}.mp4", NOW))
            await db.conn.execute(
                "INSERT INTO collection_items(collection_id, channel_id, "
                "message_id, position) VALUES (?, ?, ?, ?)",
                (code, CH, mid_base + p, p + 1))
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid_base))
        first_idx = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, "
            "access_policy, display_name, created_at, updated_at) VALUES "
            "(?, ?, 'active', 'OPEN', ?, ?, ?)",
            (f"c{code}", first_idx, display, NOW, NOW))
        await db.conn.commit()

    A, B, C = "b43aaa01", "b43bbb02", "b43ccc03"
    await mk_coll(A, 9101, 2, "Alpha Pack")
    await mk_coll(B, 9111, 2, "Beta Pack")
    await mk_coll(C, 9121, 1, "Gamma Pack")
    # Two listings LIVE on the Website (the AUTHORITATIVE state).
    await db.create_website_payload(collection_id=A, title="Alpha Pack",
                                    published=1)
    await db.create_website_payload(collection_id=B, title="Beta Pack",
                                    published=1)

    # ---- P1: the authoritative association set -------------------------
    codes = await db.list_website_collection_codes()
    check("P1 list_website_collection_codes returns the listed codes "
          "(deterministic order, unlisted absent)",
          codes == [A, B], str(codes))

    # ---- P2/P3: the OPEN seeds the selection from the authoritative rows
    sent.clear()
    ctx = FakeContext()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"),
                                        ctx, deps)
    ptext, pkb = sent[-1]
    flat = _flat_kb(pkb)
    btn_a = _btn_by_cb(flat, f"wsite:pktog:{A}")
    btn_b = _btn_by_cb(flat, f"wsite:pktog:{B}")
    btn_c = _btn_by_cb(flat, f"wsite:pktog:{C}")
    check("P2 picker open seeds the selection from the AUTHORITATIVE "
          "state (✅ marks on the LISTED packages, ⬜ on the unlisted)",
          (btn_a is not None and str(btn_a.text).startswith("\u2705")
           and btn_b is not None and str(btn_b.text).startswith("\u2705")
           and btn_c is not None and str(btn_c.text).startswith("\u2b1c")),
          f"a={btn_a and btn_a.text!r} c={btn_c and btn_c.text!r}")
    check("P3 the 'Selected:' line shows the AUTHORITATIVE count on open",
          f"Selected: 2" in (ptext or "")
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_OPEN admin_user_id={AID} "
                        f"selected_count=2 authoritative_count=2 page=1"
                  for ln in cap.lines),
          repr((ptext or "").splitlines()[-4:]))

    # ---- P4/P5: the toggle telemetry (exact shapes) --------------------
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{C}"),
                                        ctx, deps)
    sel = ctx.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    check("P4 toggle ON emits WEBSITE_PACKAGE_SELECTION_ADD (exact line) "
          "+ the selection grows",
          sel.get("selected") == [A, B, C]
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_ADD admin_user_id={AID} "
                        f"canonical_id={C} selected_count=3"
                  for ln in cap.lines),
          str(cap.lines_with("WEBSITE_PACKAGE_SELECTION_")))
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{A}"),
                                        ctx, deps)
    sel = ctx.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    check("P5 toggle OFF emits WEBSITE_PACKAGE_SELECTION_REMOVE (exact "
          "line, no phase) + the selection shrinks",
          sel.get("selected") == [B, C]
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_REMOVE "
                        f"admin_user_id={AID} canonical_id={A} "
                        f"selected_count=2"
                  for ln in cap.lines),
          str(cap.lines_with("WEBSITE_PACKAGE_SELECTION_")))

    # ---- P6: the selection survives pagination -------------------------
    for i in range(1, 10):
        await mk_coll(f"b43ddd0{i}", 9200 + i * 10, 1, f"Delta Pack {i}")
    ctx2 = FakeContext()
    sent.clear()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx2,
                                    deps)
    page1_kb = _flat_kb(sent[-1][1])
    # toggle the FIRST button on page 1 (the newest Delta Pack)
    first_cb = str(page1_kb[0].callback_data)
    await wui.handle_wsite_callback(_fake_cb(upd, first_cb), ctx2,
                                    deps)
    toggled_code = first_cb.rsplit(":", 1)[1]
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkpage:2"),
                                        ctx2, deps)
    page2_text, page2_kb = sent[-1]
    page2_flat = _flat_kb(page2_kb)
    sel2 = ctx2.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    btn_a2 = _btn_by_cb(page2_flat, f"wsite:pktog:{A}")
    check("P6a the selection SURVIVES pagination (seeded + toggled codes "
          "all held; page-2 marks correct; STATE telemetry fired)",
          sel2.get("selected") == [A, B, toggled_code]
          and f"Selected: 3" in (page2_text or "")
          and btn_a2 is not None and str(btn_a2.text).startswith("\u2705")
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_STATE "
                        f"admin_user_id={AID} selected_count=3 page=2"
                  for ln in cap.lines),
          str(sel2.get("selected")))
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkpage:1"),
                                        ctx2, deps)
    page1_kb2 = _flat_kb(sent[-1][1])
    btn_tog = _btn_by_cb(page1_kb2, first_cb)
    check("P6b the page-1 toggled mark PERSISTS across the page round "
          "trip (state not reset)",
          btn_tog is not None and str(btn_tog.text).startswith("\u2705")
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_STATE "
                        f"admin_user_id={AID} selected_count=3 page=1"
                  for ln in cap.lines),
          f"btn={btn_tog and btn_tog.text!r}")

    # ---- P13/P14: callback safety on EVERY rendered keyboard ----------
    all_cbs = [str(b.callback_data) for b in
               (page1_kb + page2_flat + page1_kb2)
               if b.callback_data is not None]
    shape = _re.compile(
        r"^(wsite:pktog:[0-9a-f]{8}|wsite:pkall|wsite:pkclr|"
        r"wsite:pkcont|wsite:pkpage:[0-9]+|panel:website)$")
    check("P13 every picker callback is ≤ 64 bytes (all buttons, both "
          "pages)",
          all_cbs and all(len(c.encode()) <= 64 for c in all_cbs),
          str(max((len(c.encode()) for c in all_cbs), default=0)))
    check("P14 every callback_data is a WELL-FORMED string (no "
          "payload_id=None / Button_data_invalid shapes)",
          all(isinstance(b.callback_data, str) and b.callback_data
              for b in (page1_kb + page2_flat + page1_kb2))
          and all(shape.match(c) for c in all_cbs)
          and not any("None" in c for c in all_cbs),
          str([c for c in all_cbs if not shape.match(c)][:3]))

    # ---- P15: Select All asks for EXACTLY the repo clamp (100) ---------
    ctx3 = FakeContext()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx3,
                                    deps)
    spied: list = []
    _orig_lc = db.list_collections_paged

    async def _spy_lc(page=1, page_size=20):
        spied.append((page, page_size))
        return await _orig_lc(page=page, page_size=page_size)

    db.list_collections_paged = _spy_lc  # type: ignore[method-assign]
    try:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkall"),
                                        ctx3, deps)
    finally:
        del db.list_collections_paged  # type: ignore[method-assign]
    sel3 = ctx3.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    all_codes = {A, B, C} | {f"b43ddd0{i}" for i in range(1, 10)}
    _ui_src = open(os.path.join(_ROOT, "app", "presentation", "telegram",
                                "website_ui.py")).read()
    check("P15 pkall requests page_size=100 (the repo clamp — the old "
          "request of 200 was silently truncated) and selects every "
          "collection",
          spied and spied[0] == (1, 100)
          and all(ps != 200 for _, ps in spied)
          and set(sel3.get("selected") or []) == all_codes
          and "page_size=200" not in _ui_src,
          str(spied))

    # ---- P7: reopen after the purge re-seeds from the AUTHORITATIVE rows
    ctx4 = FakeContext()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx4,
                                    deps)
    sel4 = ctx4.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    assert sel4.get("selected") == [A, B]
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{C}"),
                                    ctx4, deps)
    # the REAL purge (the exact function every admin navigation runs)
    # the REAL purge effect on this key (clear_wizard_states sweeps
    # ALL_WIZARD_STATES through the composed namespace; standalone it
    # cannot resolve that late-bound global — pop the key directly).
    ctx4.user_data.pop(wui.WSITE_PKG_PICK_KEY, None)
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"),
                                        ctx4, deps)
    sel4 = ctx4.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    flat4 = _flat_kb(sent[-1][1])
    # C sits on page 2 by now (12 collections, newest-first) — the
    # purged toggle must NOT survive as a selected mark anywhere.
    sent.clear()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkpage:2"),
                                    ctx4, deps)
    flat4b = _flat_kb(sent[-1][1])
    check("P7 REOPEN after the clear_wizard_states purge re-seeds from "
          "the AUTHORITATIVE state (marks correct WITHOUT transient "
          "state)",
          sel4.get("selected") == [A, B]
          and (_btn_by_cb(flat4b, f"wsite:pktog:{C}") is not None
               and str(_btn_by_cb(flat4b, f"wsite:pktog:{C}").text)
               .startswith("\u2b1c"))
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_OPEN "
                        f"admin_user_id={AID} selected_count=2 "
                        f"authoritative_count=2 page=1"
                  for ln in cap.lines),
          str(sel4.get("selected")))
    # the union: surviving in-session toggles are PRESERVED on reopen
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{C}"),
                                    ctx4, deps)
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx4,
                                    deps)
    sel4 = ctx4.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    check("P7b reopen MERGES the authoritative codes with the surviving "
          "in-session toggles (union)",
          sel4.get("selected") == [A, B, C],
          str(sel4.get("selected")))

    # ---- P8/P12: THE DIFF SAVE (mixed: 2 listed + 1 added + 1 unselected)
    ctx5 = FakeContext()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx5,
                                    deps)                      # seeds [A,B]
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{C}"),
                                    ctx5, deps)                # +C
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{A}"),
                                    ctx5, deps)                # -A
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"),
                                        ctx5, deps)
    l_a = await db.find_website_payload_for_canonical(collection_id=A)
    l_b = await db.find_website_payload_for_canonical(collection_id=B)
    l_c = await db.find_website_payload_for_canonical(collection_id=C)
    wiz5 = ctx5.user_data.get(wui.WSITE_WIZARD_KEY) or {}
    check("P8 the DIFF SAVE applies the removal IMMEDIATELY (removed "
          "listing gone, kept untouched, added not yet inserted — the "
          "wizard owns the add)",
          l_a is None and l_b is not None and l_c is None
          and wiz5.get("prefill_link") == f"c{C}"
          and wiz5.get("prefill_kind") == "collection",
          f"a={l_a is not None} b={l_b is not None} c={l_c is not None}")
    check("P12 WEBSITE_PACKAGE_SELECTION_SAVE telemetry with the exact "
          "diff counts (+ per-association phase=save removal)",
          any(ln == f"WEBSITE_PACKAGE_SELECTION_SAVE admin_user_id={AID} "
                    f"selected_count=2 added_count=1 removed_count=1 "
                    f"kept_count=1" for ln in cap.lines)
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_REMOVE "
                        f"admin_user_id={AID} canonical_id={A} "
                        f"selected_count=2 phase=save"
                  for ln in cap.lines),
          str(cap.lines_with("WEBSITE_PACKAGE_SELECTION_")))
    # complete the wizard (the ADDED-only single flow) -> publish C
    sent.clear()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx5,
                                    deps)
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx5,
                                    deps)
    l_c2 = await db.find_website_payload_for_canonical(collection_id=C)
    codes = await db.list_website_collection_codes()
    check("P8b after the wizard publish the DB association set EXACTLY "
          "matches the desired selection {B, C}",
          codes == [B, C] and l_c2 is not None
          and int(l_c2["published"]) == 1
          and str(l_c2["title"] or "") == "Gamma Pack",
          str(codes))

    # ---- P16: the batch wizard starts for the ADDED-ONLY set -----------
    D1, D2 = "b43ddd01", "b43ddd02"
    ctx6 = FakeContext()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx6,
                                    deps)                      # seeds [B,C]
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{D1}"),
                                    ctx6, deps)
    await wui.handle_wsite_callback(_fake_cb(upd, f"wsite:pktog:{D2}"),
                                    ctx6, deps)
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"), ctx6,
                                    deps)
    wiz6 = ctx6.user_data.get(wui.WSITE_WIZARD_KEY) or {}
    codes = await db.list_website_collection_codes()
    check("P16 the batch wizard carries EXACTLY the ADDED codes after a "
          "mixed save (kept packages never re-run)",
          wiz6.get("batch") is True
          and list(wiz6.get("batch_codes") or []) == [D1, D2]
          and codes == [B, C],
          f"batch={wiz6.get('batch_codes')} codes={codes}")
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:wskip"), ctx6,
                                    deps)
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:wpub"), ctx6,
                                    deps)
    codes = await db.list_website_collection_codes()
    check("P16b the added-only batch publish lists exactly the two new "
          "packages",
          codes == [B, C, D1, D2], str(codes))

    # ---- P9/P11/P18: the UNSELECT-ALL save -----------------------------
    async def _count(sql):
        cur = await db.conn.execute(sql)
        return int((await cur.fetchone())[0])

    pre = {
        "coll": await _count("SELECT COUNT(*) FROM collections"),
        "items": await _count("SELECT COUNT(*) FROM collection_items"),
        "idx": await _count("SELECT COUNT(*) FROM indexed_files"),
        "wp": await _count("SELECT COUNT(*) FROM website_payloads"),
        "payloads": await _count("SELECT COUNT(*) FROM payloads"),
    }
    ctx7 = FakeContext()
    await wui.handle_wsite_callback(_fake_cb(upd, "wsite:addpkg"), ctx7,
                                    deps)              # seeds [B,C,D1,D2]
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkclr"),
                                        ctx7, deps)
    sel7 = ctx7.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    check("P18 pkclr clears the DESIRED set (WEBSITE_PACKAGE_SELECTION_"
          "CLEAR telemetry, exact line)",
          sel7.get("selected") == []
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_CLEAR "
                        f"admin_user_id={AID} selected_count=0"
                  for ln in cap.lines),
          str(cap.lines_with("WEBSITE_PACKAGE_SELECTION_")))
    sent.clear()
    with _LogCap() as cap:
        await wui.handle_wsite_callback(_fake_cb(upd, "wsite:pkcont"),
                                        ctx7, deps)
    post = {
        "coll": await _count("SELECT COUNT(*) FROM collections"),
        "items": await _count("SELECT COUNT(*) FROM collection_items"),
        "idx": await _count("SELECT COUNT(*) FROM indexed_files"),
        "wp": await _count("SELECT COUNT(*) FROM website_payloads"),
        "payloads": await _count("SELECT COUNT(*) FROM payloads"),
    }
    codes = await db.list_website_collection_codes()
    summary = "\n".join(t or "" for t, _ in sent)
    check("P9 UNSELECT-ALL + Continue removes EVERY package association "
          "(all website_payloads package rows deleted; the confirmation "
          "states exactly that)",
          codes == [] and post["wp"] == 0
          and "Website updated: +0 \u22124" in summary
          and "All package associations were removed" in summary
          and any(ln == f"WEBSITE_PACKAGE_SELECTION_SAVE "
                        f"admin_user_id={AID} selected_count=0 "
                        f"added_count=0 removed_count=4 kept_count=0"
                  for ln in cap.lines),
          f"codes={codes} wp={post['wp']}")
    check("P11 the STORAGE MASTER is protected (collections / "
          "collection_items / indexed_files / payloads counts unchanged)",
          post["coll"] == pre["coll"] == 12
          and post["items"] == pre["items"]
          and post["idx"] == pre["idx"]
          and post["payloads"] == pre["payloads"],
          str((pre, post)))
    sel7 = ctx7.user_data.get(wui.WSITE_PKG_PICK_KEY) or {}
    check("P9b the unselect-all save clears the picker state (no wizard "
          "started)",
          sel7.get("selected") == []
          and not ctx7.user_data.get(wui.WSITE_WIZARD_KEY),
          str(sel7))

    # ---- P10: apply_website_collection_diff transactionality -----------
    await db.create_website_payload(collection_id=A, title="Alpha relisted",
                                    published=1)
    raised = False
    try:
        await db.apply_website_collection_diff(added=["b43dead99"],
                                               removed=[A])
    except ValueError:
        raised = True
    except Exception:  # noqa: BLE001 — must be the honest ValueError
        raised = False
    l_a = await db.find_website_payload_for_canonical(collection_id=A)
    cur = await db.conn.execute(
        "SELECT COUNT(*) FROM website_payloads WHERE collection_id = ?",
        ("b43dead99",))
    dead_n = int((await cur.fetchone())[0])
    check("P10 an UNKNOWN added code ROLLS BACK the whole diff (ValueError; "
          "the removal in the same call never landed)",
          raised and l_a is not None and dead_n == 0,
          f"raised={raised} a={l_a is not None} dead={dead_n}")

    # ---- P17: the repo diff method's own add/remove round-trip ---------
    res_add = await db.apply_website_collection_diff(added=[C],
                                                     created_by=AID)
    l_c = await db.find_website_payload_for_canonical(collection_id=C)
    res_dup = await db.apply_website_collection_diff(added=[C])
    res_rm = await db.apply_website_collection_diff(removed=[C])
    l_c2 = await db.find_website_payload_for_canonical(collection_id=C)
    check("P17 the repo diff method inserts with the DEFAULT title chain "
          "(display_name level), is idempotent on already-listed codes, "
          "and removes cleanly",
          res_add == {"added": 1, "removed": 0, "skipped_existing": 0}
          and l_c is not None
          and str(l_c["title"] or "") == "Gamma Pack"
          and int(l_c["published"]) == 1
          and res_dup == {"added": 0, "removed": 0, "skipped_existing": 1}
          and res_rm == {"added": 0, "removed": 1, "skipped_existing": 0}
          and l_c2 is None,
          f"add={res_add} dup={res_dup} rm={res_rm} "
          f"title={l_c and l_c['title']!r}")

    await db.close()
    for suffix in ("", "-shm", "-wal"):
        if os.path.exists(DB_PATH + suffix):
            os.remove(DB_PATH + suffix)

    total = RESULTS["pass"] + RESULTS["fail"]
    print(f"\n{'=' * 60}\nBOT-43 PACKAGE SUITE: {RESULTS['pass']}/{total} "
          f"passed, {RESULTS['fail']} failed")
    if RESULTS["failures"]:
        print("FAILURES:")
        for f in RESULTS["failures"]:
            print("  -", f)
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
