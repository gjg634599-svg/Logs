# Telegram Payload Delivery Bot — Production Package (V26 build)

A production Telegram bot platform that delivers payload files (videos,
documents, collections) through a **fleet of registered Network Bots**
with Force-Join gating, a full **website** (Telegram Mini App + public
site with streaming, categories, 18+ area), Watch-Ads / video-ad
monetization, points, referrals, and **Global Payload Links** that can
target any registered bot.

This is the runtime-only production package. The V26 verification
suite ships as `tests/test_v26_production.py` inside this tree; the
browser-QA demo services (site-demo + watchad-demo) live under
`mini-services/` (demo-only glue, never part of the production boot
path).

---

## 0. V26 — Network Bot Watch Ads + the message-872 identity fixes

**V26** is the production-fix release root-caused from the uploaded
bot-36/bot-37 logs + the production PDF screenshots (the Watch-Ad
"Ad Unavailable — this ad session could not reach the server" report):

* **Network Bot Watch Ads (the PDF page-2 failure).** A Watch Ad Mini
  App launched from a NETWORK bot signs its initData with THAT bot's
  token; the Watch Ads status/ad-event endpoints validated against the
  MAIN bot token only → 401 on every poll → the bounded sync expired →
  "Ad Unavailable" although the session and the reward pipeline were
  healthy. V26 adds the SAME multi-token contract the public Website has
  used since WEBSITE PHASE 3 §11: main bot FIRST (byte-identical
  behavior), then every ACTIVE network bot token decrypted through the
  existing credential registry — validated with the SAME canonical
  HMAC validator (no second HMAC implementation, no bypass; cross-user
  rejection, freshness and the Monetag S2S reward authority are all
  unchanged). `/api/network/auth` gets the same multi-token contract.
* **Reward routing through the serving bot.** The session records its
  launch context (`watch_ad_sessions.launch_network_bot_id`, schema v43
  — additive, nullable, idempotent; legacy rows stay NULL = main bot)
  when the [🎬 Watch Ad] screen renders inside a network worker, so the
  VERIFIED-reward notification + auto-resume delivery run through the
  bot the user is actually talking to (the main bot may have no chat
  with them at all). Fallbacks: a stopped/removed worker or any lookup
  failure degrades to the main bot exactly as before.
* **The message-872 identity fix (bot-37.log).** A single-file payload
  whose auto-generated name begins with "c" (payload 787
  `clipmatezone_indias_got_latent_2026_bonus_s02e03_1080p`, created
  from message 872) was misdetected as a COLLECTION by the naive
  `startswith("c")` checks → `managefiles:lipmatezone…` = **65 bytes >
  Telegram's 64-byte callback_data limit → Button_data_invalid** on BOTH
  the edit and the fallback send — the Payload Manager could NEVER
  render. All the naive sites (payload detail, preview panel, retrieve,
  wizard edit, delivery retry, retrieve list) now use the CANONICAL
  `is_collection_link`/`is_msg_link` predicates (c + hex-only / m +
  digits — the exact /start routing truth), with a 64-byte guard on the
  `managefiles` callback as defense in depth.
* **Forward duplicate detection for single-file payloads.** Re-forwarding
  message 872 ALWAYS produced `decision=create_wizard` (the detection
  was collection-only) — the admin could silently mint duplicate
  payloads of the same file. V26 adds exact-identity single-file
  detection (`find_single_payload_by_channel_message`) with the same
  "Existing Payload Found" screen collections get.
* **Fresh first-click Age Gate.** The one-time welcome overlay (`#wintro`,
  full-screen z-index 220, ~2.9 s) rendered ON TOP of the age-gate
  interstitial on a fresh session — the user's FIRST tap on "I am 18 or
  older" hit the overlay, not the button (bot-37.log: every fresh
  session re-requested /site/c/adult before the confirm POST fired).
  The gate page now suppresses ONLY the overlay markup (`no_intro`) —
  the bootstrap script still ships (it owns the theme toggle); the
  one-time intro still shows on the next (content) page.
* **No group/supergroup delivery (enforced).** The V25 two-stage
  Delivery Channel architecture (Storage Channel → File Delivery Bot →
  Delivery Channel → Network Bot → User) is preserved; NEW Delivery
  Channel setups now REQUIRE a real broadcast CHANNEL (groups and
  supergroups are rejected with the honest remediation). A chat already
  persisted as the bot's `delivery_channel_chat_id` (the v42 legacy
  migration) stays grandfathered — production delivery keeps working.

V26 verification: **63/63 automated checks** (`tests/
test_v26_production.py` — the REAL namespace, REAL schema, real HTTP
handler calls with the official initData signing model) + **live HTTP
verification** of the Network Bot Watch Ads flow (the exact PDF page-2
scenario: network-signed status poll → 200 pending; cross-user → 403;
tampered → 401; main-bot unchanged) + **live browser verification** of
the fresh first-click Age Gate (first tap → immediate POST → content;
no overlay over the button; the wintro still shows on content pages) +
full `py_compile` across every module. See
`docs/V26_PRODUCTION_IMPLEMENTATION_REPORT.md`.

Round-2 QA hardening (demo glue only — the production tree is
unchanged): the two demo services are now **gateway-aware**
(`mini-services/_gateway_aware.py` keeps `?XTransformPort=` alive
through redirects, links and fetches so the preview-panel "Open" links
work), the SDK shim actually applies (two latent demo bugs fixed), the
watchad-demo mints always-fresh sessions (`GET /demo/renew`) and signs
its shim initData with the NETWORK bot token (official WebAppData
model) — so a real browser through the gateway now demonstrates the
ENTIRE V26 fix live: `WATCH_AD_AUTH_VIA_NETWORK` → 200 pending → ad
event → S2S postback → "Your payload is unlocked". Start both demos
with `bash mini-services/start-demos.sh` (double-fork daemons — they
survive the launching shell).

Round-5 QA (demo glue + dashboard only — the production tree is
unchanged): the watchad-demo gained a **V25 pre-fix fault-injection
mode** (`GET /watch-ad/<token>?mode=v25` sets a demo-only cookie; while
it is set, the status/ad-event POSTs answer `401 {"status":
"unauthorized"}` BEFORE the production handlers run — the exact outcome
the pre-V26 main-token-only validator produced for a NETWORK-bot-signed
initData; `mode=v26` clears it). This lets the verification center
reproduce the exact PDF page-2 failure on demand (the real Mini App
retries, the 20s production sync deadline fires, "Ad Unavailable" —
the exact screen) and then flip to the fixed behavior live. All
`WATCH_AD_DEMO_V25_MODE` lines are clearly logged as the simulation.
The dashboard itself was accessibility-hardened (proper heading
hierarchy, labelled landmarks, focusable log regions, valid tab
semantics, contrast sweep, favicon).

Round-6 (V27 — PRODUCTION TREE + demo surface): the schema-v43
`launch_network_bot_id` column becomes admin observability —
`Database.watch_ad_launch_metrics()` (app/storage/repositories/
watch_ads.py) rolls up Watch-Ad sessions per launch context (the main
bot vs each network bot; NULL/0 both mean main/legacy, orphan ids are
labeled `unknown`, never merged) with the reward funnel, completion
rate and last activity, and the 📊 Watch Ads Status panel renders it as
the 🚀 Launch context section (only when there are sessions — a fresh
deployment's panel stays exactly as long as before). Read-only,
best-effort, never mutates. The suite grows to **73/73** (new section
H — 10 checks: empty structure, NULL+0 merge, network join, rate math,
orphan honesty, totals reconcile, last-activity, read-only twice, the
panel render, the no-session panel). Demo surface: watchad-demo stamps
the network launch context on every mint/renew (the same production
setter `build_watch_ad_session_url` uses), seeds two historical
rewarded sessions (one main, one network — future unlock windows so
the lazy expiry never flips them), and serves `GET /demo/metrics` (the
REAL production rollup over the demo DB). site-demo gained the second
fault injection: `?mode=v25` re-injects the `#wintro` overlay markup
into the age-gate page (the pre-V26 first-tap swallow — the bootstrap
script always ships, so the div alone restores the full behavior; a
fresh-session guard clears the sessionStorage intro flag first); the
dashboard's age-gate demo now has the same V25/V26 before/after
toggle as the Watch Ad demo (live DOM probe shows `#wintro overlay
PRESENT` + `button COVERED`, the bot-37.log evidence panel, and the
BUG REPRODUCED badge).

---

## 1. Installation

Requirements: **Python 3.10+** (developed and verified on CPython 3.12).

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 run.py
```

`python-telegram-bot` is pinned to `>=22.8,<23` — the managed-bot APIs
used by this codebase (`KeyboardButtonRequestManagedBot`,
`get_managed_bot_token`, `getMe().can_manage_bots`,
`set_chat_menu_button`) require 22.8+; the upper bound keeps the
verified surface pinned.

The first start creates `payload_bot.db` (SQLite) and applies all schema
migrations automatically (currently **schema v43**) — upgrades from any
older schema are additive and idempotent; no existing data is touched.
**v43 adds `watch_ad_sessions.launch_network_bot_id`** (the Network Bot
Watch Ads launch context for reward routing; legacy rows stay NULL =
main-bot semantics). v36 added the per-payload **📥 Get File ON/OFF** switch and the (now DEPRECATED, BOT-16) ad-destination column; v37 adds `network_bots.removed_at` (the terminal removal audit stamp); **v38 adds the direct-delivery audit columns** (`delivery_jobs.delivery_mode` + `handoff_token` + `handoff_sent_at`); **v39 adds the honest Mode-A metrics columns** (`delivery_jobs.mode_a_failure` + `mode_a_failure_at`) and `force_join_channels.link_provenance`; **v42 is the V25 FINAL two-stage Delivery Channel schema** (`network_bots.delivery_channel_chat_id` + `delivery_jobs.delivery_channel_id/delivery_message_id`). **BOT-16** was the production-fix release: relay-delivery self-healing + honest error logging, the /site/site URL normalization (single-prefix), website force-join gates on every surface (including the in-player Join/Verify flow for NON-ADMIN users), surface-separated ads (website pre-roll follows the Website ad settings; Telegram Watch Ads stay in Telegram), REAL registered-bot removal (REMOVED rows leave every active list/count, workers stop, links deactivate, restart cannot resurrect), and browser-compatible video playback: ffprobe verdicts + FFmpeg HLS transcoding with a real quality ladder, plus the professional player (custom controls, speed menu, fullscreen, PiP, keyboard, resume/start-over, retry).

**BOT-17** is the direct-delivery release (root-caused from bot-18.log):
the FDB-authored relay + network-bot copy chain was fundamentally
invalid on Telegram (a bot can never copy another bot's message — jobs
30/31 cycled relays 198–205 with zero deliveries). Delivery is now a
layered strategy — **Mode A** network-bot-owned relay (capability-probed
+ cached), **Mode B `fdb_direct`** (the File Delivery Bot performs the
final user-facing send — the primitive that always worked), **Mode C
handoff** (a one-tap `t.me/<fdb>?start=dl<token>` button from the
network bot; the FDB's in-process poller completes the send on `/start`)
— with `DELIVERED` written only after a real Telegram send returns a
message id, untapped handoffs honestly expiring, and single-use tokens.
Large-file website playback is fixed by the dedicated
`MEDIA_GETFILE_TIMEOUT` (default 600 s — a local Bot API server
downloads the file from the Telegram DC BEFORE answering getFile; the
generic 30 s bound killed the 856 MB/599 MB videos in bot-18.log) and
polite `Retry-After: 5` on 503s.

**B17 FINAL VERIFICATION round** (independent audit): the TTL sweeper
now settles crash-ambiguous `DELIVERING` rows as **EXPIRED — never a
lying DELIVERED** (a legacy DELIVERED row without a recorded
`user_message_id` is downgraded too); `NETWORK_DELIVERY_GROUP_ACCESS_
CHECK` is a REAL executable diagnostic probing with the network bot's
OWN client (get_me identity vs the registry row, group reachability,
own membership/read/send capability, FDB membership, Storage
reachability) and classifying every Telegram failure into the
canonical 10-class taxonomy — "Message to copy not found" is
RELAY_DELETED only when deletion is PROVEN, otherwise the honest class
RELAY_INACCESSIBLE_TO_NETWORK_BOT (the bot-18 root cause); the HLS
segment token honors a 6 h long-form ceiling (a >1 h transcoded movie
no longer 401s on late segment fetches); the player auto-hides its
controls on idle (YouTube-style, real-Chromium verified); the Force
Join admin dashboard shows the 🟢🟡🔴🟠 health quadruple; the
Registered Bots list renders a browsable ARCHIVED section for removed
bots. Full battery: 40 suites / 3,069 checks / 0 failures; browser QA
48/48. See `docs/BOT17_PRODUCTION_FIX_REPORT.md` §7.

**BOT-18** is the production-hardening release (root-caused from
bot-19.log + carrying forward the full B17 UX work):

* **Network Bot delivery honesty.** bot-19.log jobs 34/35 proved the
  network bot (@helpsupport_dox_bot) could not see the STORAGE channel —
  `copyMessage` failed "Chat not found" while the delivery group was
  healthy (bot administrator) — yet the failure was classified
  GROUP_INACCESSIBLE and a healthy group was marked LOST, and the FDB
  fallback that ACTUALLY delivered was logged `NETWORK_DELIVERY_SUCCESS
  mode=fdb_direct`. B18: "Chat not found" on the Mode-A hop is
  disambiguated by REAL probe evidence (group reachable + Storage
  unreachable → `STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT` — the group
  is NEVER degraded, and the remediation is stated); every FDB send
  (first attempt, handoff completion, retry) logs
  `FDB_DIRECT_DELIVERY_SUCCESS` — `NETWORK_DELIVERY_SUCCESS` is reserved
  for the network bot itself delivering; the true Mode-A verdict is
  logged without editorial spin AND recorded durably on the job row
  (`mode_a_failure`/`mode_a_failure_at`, v39) so metrics distinguish
  "Mode A failed → fallback delivered" from a clean delivery without
  parsing logs; `NETWORK_RELAY_MESSAGE_CREATED_BY_NETWORK_BOT` only
  appears on a real network-bot relay.
* **Diagnostics on every failure class.** `NETWORK_DELIVERY_GROUP_ACCESS_
  CHECK` (the real executable diagnostic with the network bot's own
  client) now runs on BadRequest, ChatNotFound, Forbidden, TimedOut,
  NetworkError and unknown exceptions (RetryAfter logs the
  classification without probes — extra API calls under flood control
  make it worse), carries `failing_hop` (so `source_reachable` reflects
  the chat the failing copy actually READ from) and the TRUE registry
  nid (bot-19.log showed `network_bot_id=0 registered_bot_id=-`).
* **Delivery HTTP timeouts.** PTB's default 5 s HTTPX read bound
  produced bot-19.log's consecutive TimedOut failures on large-media
  copies (the storage master was an 856 MB video) and even the worker's
  `set_chat_menu_button`. Every delivery client (network worker
  applications + the FDB client) now uses explicit timeouts
  (read/write 60 s, connect 30 s — centralized in
  `app/network/file_delivery.py`).
* **Force Join root causes.** The B17 link verifier called
  `get_chat_invite_link` — a method the Bot API DOES NOT HAVE — so every
  channel with an invite link was temporary_error at every startup
  (bot-19.log: `channels=7 healthy=0 temporary=7`, even right after a
  successful rotate). B18's verifier is Bot-API-CAPABLE: public links
  are verified by username resolution (getChat id match proven, mismatch
  proven wrong-chat, resolution failure never a dead verdict); invite
  links cannot be introspected by hash (no Bot API method) — the channel
  is verified instead (the bot's own membership via getChatMember) plus
  the link's PROVENANCE (v39 `link_provenance`: bot_created = provably
  valid until our own rotation revokes it; custom = trusted with the
  capability documented). A capability limitation NEVER becomes a
  misleading temporary_error or dead verdict.
* **Remove/re-add self-healing.** A re-added channel row has no stored
  link; the old verifier classified the MISSING link as `link_invalid`
  ("stored link is not a t.me link") → `dead_links=1` for a valid
  channel. B18: a missing link is the honest `NO_LINK` state (not dead,
  auto-creatable), and the startup pass MINTS a fresh bot-created link
  when the auto-repair policy allows it — no manual workaround. The
  normalizer accepts the full vocabulary (t.me/telegram.me/telegram.dog
  mirrors, tg://join?invite=, tg://resolve?domain=, @username, +hash,
  joinchat/hash, query/fragment, case-insensitive hosts) and canonical
  URLs are preserved.
* **The full B17 website UX work carried forward** (SVG icon system,
  auto-hide controls with 2.8 s idle, mobile single-row controls + the
  Settings sheet, 16:9 player stage, responsive 320–1536, FJ gate mobile
  fix, big-play z-order fix, HLS player, fullscreen/PiP, speed/quality,
  resume/start-over, error/retry UI, ad separation, light/dark themes) —
  verified again by BOTH browser suites (37/37 UX + 45/45 functional).


## 2. Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `BOT_TOKEN` | yes | the MAIN bot's token (from @BotFather) |
| `ADMIN_IDS` | yes | comma-separated Telegram user ids of the admins |
| `DATABASE_FILE` | no | SQLite path (default `payload_bot.db`) |
| `NETWORK_TOKEN_ENCRYPTION_KEY` | **yes for network bots** | dedicated persistent key that encrypts registered-bot tokens (generate: `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`). Fail-closed: new registrations are refused without it. |
| `NETWORK_GLOBAL_LINK_SIGNING_KEY` | **yes for Global Links** | dedicated persistent signing key for Global Payload Links (same generation command). Minting fails closed without it; existing links keep verifying. |
| `CONTROL_BOT_TOKEN` | no | optional dedicated control-bot token (the control panel is also inside the main bot: `panel:control`) |
| `WEBSITE_*`, `MEDIA_*`, `WATCH_AD_*`, `MINI_APP_*` | no | website / media transport / Watch Ads tuning — see `.env.example` and `docs/DEPLOYMENT.md` |

Never derive the two dedicated keys from `BOT_TOKEN` — they must survive
token rotation.

## 3. Database

SQLite via `aiosqlite`. All migrations are transactional/idempotent and
run at startup. **Do not** delete the DB to "reset" — every payload,
file index, category, Force-Join channel, bot registry row, credential,
points ledger and link is production data. Back up via the admin panel
(`backup:db`).

## 4. Network Bots (the multi-bot fleet)

The MAIN bot is the **verification authority**: it performs every
Force-Join membership check (`getChatMember`) and owns the payload file
references. Registered **Network Bots** are delivery/serve contexts —
they need **no** Force-Join channel admin rights and no storage-channel
membership.

- **Register a bot**: My Network → Add Existing Bot → paste the
  BotFather token. The token is validated with Telegram (`getMe`) BEFORE
  anything is persisted, encrypted with the dedicated key, and never
  logged, echoed or shown again.
- **Managed-bot creation**: a registered bot with Telegram's
  Bot-Management capability (`getMe().can_manage_bots=True`) offers
  ➕ Create Network Bot directly (the official
  `KeyboardButtonRequestManagedBot` flow; the token is retrieved via
  `getManagedBotToken`). Capability is detected per bot, persisted, and
  refreshable (🔄 Refresh Bot Capabilities in the admin panel). Bots
  without the capability get the honest BotFather instruction.
- **Per-bot lifecycle**: Manage (status badges: Bot Management /
  Mini App / Delivery), 🔑 **Change Token** (validated before replace;
  identity changes require explicit confirmation), ⛽ Disable/Re-enable,
  🗑 **Remove Bot** (stops the worker, revokes the credential, terminal
  REMOVED status, history preserved, idempotent, stale callbacks answered
  honestly). A removed bot can be **reactivated** with its token
  (♻️ Reactivate) — no new slot consumed, no double reward.
- **Delivery Group**: one private relay group per bot (bot + the File
  Delivery Bot). Setup: add the bot + the FDB to a private group, then
  /setup or Check Again in that group — the platform verifies membership,
  permissions and storage access (DELIVERY_READY). Delivery flows
  storage → FDB copy → group relay → network-bot copy → user; durable
  retryable jobs; the network bot needs no storage access.
- **Five-bot cap per owner**; removed bots never count toward it.

## 5. Force Join

Progressive batches (active batch gates delivery; future batches never
block the current payload), Join buttons with health-checked invite
links, 🔄 Check Again (always a fresh server-side check **performed by
the MAIN bot**), request-to-join policy, admin bypass, and honest
bot-fault diagnostics (the user is never blamed for a channel the MAIN
bot cannot verify). Invalid channels are reported truthfully at startup
and are inspectable/removable in the admin panel.

## 6. Global Links (per-bot targeting)

`https://t.me/<bot>?start=g<code12>-<sig6>` — opaque, HMAC-signed with
the dedicated key (BOT_TOKEN rotation survives; legacy links keep
verifying).

- The admin's **Global Link panel** picks the target: **Main Bot**,
  **Random Registered Bot** (one eligible bot selected and LOCKED IN at
  creation — never re-rolled at click), or a specific Network Bot.
- The target is **persisted in the link row** and routes
  deterministically: arrival at the target delivers there; arrival
  anywhere else gets ONE deep-link button to the target (the original
  signed argument, case-preserved).
- Removed/disabled/invalid targets produce the honest
  "This delivery bot is no longer available" notice (never a re-roll,
  never a resurrection).
- Un-targeted (legacy) links keep the original health-aware routing.

## 7. Main Mini App

One canonical URL: `website_public_base_url` + `/site` (HTTPS-validated).
The admin panel (🌐 Main Mini App) shows the current URL, lets you
**Change URL** (validated: HTTPS, absolute, no whitespace/control chars —
malformed URLs are never stored), **Apply to All Registered Bots**
(`setChatMenuButton` with a WebApp menu button; truthful per-bot results;
custom menu buttons are preserved by the operator policy), and Refresh.
Every registered bot automatically receives the link when its worker
starts (restart-safe); per-bot apply state (url / last applied / status /
error) is persisted.

## 8. Website (/site)

Telegram-verified sessions (initData HMAC, multi-token: main + network
bots), payload listings with categories, a YouTube-style **player**
(server-authorized streams, HTTP Range/206, seek, resume, parts), the
🔞 18+ category (always-visible nav entry → server-side age gate;
every restricted surface — detail/player/access/stream/thumb/pack —
enforces the same server-side predicate), download packs, and the
**📥 Get File** button: **per-payload ON/OFF** (BOT-13 §46 — when OFF
the button AND its script are absent from the page and the endpoint
answers the truthful `get_file_disabled` denial; every other payload
feature is unaffected); when ON the server selects a **random eligible
registered delivery bot** (ACTIVE + credential + worker + Delivery
Group), mints a durable targeted Global Link, and redirects to that
bot's deep link. With zero eligible bots you get the truthful
"No delivery bot is currently available" state — the MAIN bot is used
only if the operator sets `website_get_file_allow_main_fallback=1`.
Rapid double-clicks are debounced (the same link is returned).

Ordinary **video playback never redirects to Telegram** (BOT-13 §47):
clicking play opens the on-site player; only the Get File button enters
the Telegram flow.

## 9. Video ads (website) & Watch Ads (Mini App)

- **Per-payload ad destination** (BOT-13 §48): `video_ad_destination =
  BOT` keeps ads on the Telegram side (NO website pre-roll);
  `WEBSITE` runs the on-site pre-roll below; `NONE` plays content
  directly. The setting is per payload, persisted, and independent of
  the Get File switch.
- **Website pre-roll** (provider-agnostic `PRE_ROLL` slot, VAST adapter
  for HilltopAds or any VAST endpoint): poster → play → Advertisement →
  skip-when-permitted → content. Ad failures always fail OPEN to content.
  Not configured → content plays directly.
- **TMA Watch Ads** (Monetag SDK, `/watch-ad/<token>`): server-side S2S
  reward verification, unlock windows — completely separate from the
  website pre-roll (no reward for pre-rolls).
- `sw.js` is the provider's service-worker asset (byte-identical,
  sha-pinned in the test package).

## 10. Cloudflare (optional)

A hardened reverse-proxy Worker (`cloudflare/`) fronts the origin: HTTPS,
origin-key header, `/sw.js` at root scope. Deploy with
`npx wrangler deploy` (credentials are operator-controlled; never
committed). Static verification: `node --check cloudflare/worker.js`.

## 11. Deployment / restart

One process runs the bot, the workers (registered bots), the Watch-Ads
Mini App HTTP server and the public website (`run.py`). Restart is safe:
workers restart from the registry, ACTIVE bots re-apply the Mini App
link, durable delivery jobs resume/retry, pending broadcasts resume.

## 12. Troubleshooting

| Symptom | Meaning / action |
|---|---|
| `NETWORK_BOT_REGISTER_FAILED reason=encryption_key_missing` | set `NETWORK_TOKEN_ENCRYPTION_KEY` and restart |
| `GLOBAL_LINK_MINT_REFUSED reason=signing_key_missing` | set `NETWORK_GLOBAL_LINK_SIGNING_KEY` |
| `NETWORK_BOT_MENU_BUTTON_SKIPPED reason=no_url` | set `website_public_base_url` (https) — no URL is invented |
| `NETWORK_DELIVERY_NO_DELIVERY_GROUP` | that bot's Delivery Group is not DELIVERY_READY — run setup |
| `WEBSITE_GET_FILE_NO_ELIGIBLE_BOT` | no ACTIVE delivery-ready registered bot; configure a Delivery Group or enable the main fallback explicitly |
| 7 invalid force-join channels at startup | remove/replace them in Force Join Settings — users are never blamed for these |
| `MANAGED_BOT_BEGIN_REFUSED reason=worker_not_manager` | enable bot management for that bot in @BotFather, then 🔄 Refresh Bot Capabilities |

Historical design documents live under `docs/` (clearly identified as
historical). The operator runbook is `docs/DEPLOYMENT.md`.

Round-7 (V27 continued — the per-payload funnel): the worklog's own
suggestion — **`Database.watch_ad_payload_launch_metrics(limit=5)`**
(app/storage/repositories/watch_ads.py) — WHERE the Watch-Ads traffic
lives: the top payloads by session volume, each row carrying its reward
funnel (rewarded/pending/expired/rejected), its completion rate, its
**launch split** (main-bot vs network-bot sessions; NULL/0 = main,
`launch_network_bot_id > 0` = network; `main + network == sessions`
always) and its last activity, joined to `payloads` for the code +
display name (orphan payload ids render the numeric id — labeled, never
fabricated). Read-only, bounded (limit 1..20), failures return []. The
📊 Watch Ads Status panel renders it as the 📦 **Top payloads by
Watch-Ad sessions** section (`• v26_watchme: 3 sessions · 2 rewarded
(67%) · main 2 · network 1`) — absent on a fresh deployment. The suite
grows to **85/85** (new section I — 12 checks: empty list, top-N
ordering, per-payload funnel, launch split, rate math, last-activity,
limit, the payload join + orphan label, read-only, cross-rollup
reconciliation with `watch_ad_launch_metrics`, the panel render, the
no-session absence). Demo: a second Watch-Ads payload (`v27_metrics2`,
one rewarded main launch + one expired network launch — future unlock
window) so the breakdown shows two rows, and `/demo/metrics` now serves
BOTH rollups. Dashboard: the metrics card gained a "by launch context /
per payload" view toggle (radiogroup) — the per-payload table shows the
funnel bars + two-segment launch-split micro-bars + the reconciliation
footnote. ZIP rebuilt (same 201-file list), sha256 synced.

Round-8 (V27.1 — the windows + the drill-down): the worklog's time-series
suggestion — both V27 rollups gained the **`window_hours`** parameter
(`watch_ad_launch_metrics(window_hours)` +
`watch_ad_payload_launch_metrics(limit, window_hours)`): sessions
created within the last N hours only (the same UTC `created_at >=
cutoff` string-comparison convention as the postback last-24h filter);
`None` stays byte-identical all-time, `<= 0` clamps to all-time (never a
false empty window). The 📊 Watch Ads Status panel renders the 📈
**Sessions · windows (V27.1)** recency line (`Last 24h: N | Last 7d: M`)
only when sessions exist. The suite grows to **96/96** (new section J —
11 checks: the empty shape, 24h/7d filtering on controlled ages, the
all-time default, windowed last_activity, the clamp, the windowed
per-payload breakdown, the cross-window reconciliation, read-only, the
panel line, the no-session absence). Demo: the seed history spans 2h /
30h / 200h ago so the three windows genuinely differ, and
`/demo/metrics` serves all three rollups. Dashboard: a window selector
(all-time / last 7d / last 24h — amber/teal/zinc radiogroup), a recency
strip with `−N older` deltas, and window-aware tables. NEW this round —
the **feature drill-down**: every feature card links to its exact live
surface (the metrics card focuses that view/window via a `v26:focus-
metrics` event + a violet glow) AND to the suite section that pins it
(the explorer accordion is now controlled — "Suite J — 11 checks"
expands exactly section J, 11 checks listed). Also fixed live: the
share bar now renders the ACTIVE window (was all-time alongside
windowed tables — now consistent + a window badge), and the window
footnote carries an honesty guard (never claims a cutoff the tables
aren't backed by). Contrast hardened under axe-core 4.11.1 (the newer
engine computes blended translucent backgrounds and definitively flags
zinc-500 small text at ~4.3:1 — all 25 informational labels in the
metrics card swept zinc-500 → zinc-400; violations 25 → 0). The
vendored `public/axe.min.js` (offline audits) is excluded from lint
(`public/**` in the eslint ignores). ZIP rebuilt (same 201-file list),
sha256 synced.

### Round 9 — V27.2 hourly trend (buckets + direction) + fixes drill-down

`Database.watch_ad_session_trend(window_hours=24)` (app/storage/
repositories/watch_ads.py): the worklog's own next-step suggestion — a
bucketed `GROUP BY hour` over `substr(created_at, 1, 13)` turns the
session history into the last N hour-aligned buckets (zero-filled,
OLDEST first, N clamped 1..168, `<= 0` → 24) with per-bucket
sessions / rewarded / the main-vs-network launch split, plus a
this-window vs previous-window comparison (`current`, `previous`,
`delta`, `trend` up/down/flat, the rewarded variants), the PEAK bucket
(latest on ties, never fabricated when empty) and an honest
`max_bucket_sessions` chart scale. Read-only; failures return the
zeroed structure. Reconciliation is exact by construction: `current ==
sum(buckets)` (the window is hour-aligned, deliberately NOT the
minute-precise V27.1 cutoff — documented in the docstring). The 📊
Watch Ads Status panel renders the 📈 **Hourly trend (V27.2 · 24h
buckets)** line (`This 24h: N · previous 24h: M ▲ up · rewarded K ·
peak P @ HH:00`) only when either window has a session. The suite
grows to **108/108** (new section K — 12 checks: the zeroed shape, the
contiguous bucket skeleton, bucket aggregation, rewarded per bucket,
the launch split, current-vs-previous + trend, outside-window
exclusion, peak + scale, the clamps, read-only, the panel line, the
no-session absence). Demo: a 5h-ago network session joins the seed
history so the hourly chart shows three active hours, and
`/demo/metrics` serves `trend.h24` / `trend.h168`. Dashboard: the
launch-metrics card gains the hourly chart (24 slim stacked bars —
violet main / emerald network, the peak bucket ringed amber, a
wall-clock hour axis, per-bar tooltips + sr-only summary), trend
arrows on the window chips (▲/▼/▶ with the delta + "prev Nh: M"), and
a V27.2 badge. NEW this round — the **fixes drill-down**: every fix
card now links to the suite sections that pin it ("Suite A — 14
checks", "Suite B — 15 checks", …) and, where a live demo drives the
exact fix, a "Drive it — the Watch Ad flow / the Age Gate first click"
anchor; the QA explorer card now glows violet on the landing (the same
focus contract as the metrics card). Also fixed this round (found by
the axe 4.11.1 audit with all demo states rendered): 10 color-contrast
violations — inactive TabsTriggers inherited the light-theme
`text-foreground` (#0a0a0a) on the custom dark surface (the log viewer
+ endpoint explorer tabs now carry explicit `text-zinc-400`), plus the
endpoint row descriptions/badges and the log-viewer footnote swept
zinc-500 → zinc-400. ZIP rebuilt (same 201-file list), sha256 synced.

### Round 10 — V27.3 day-bucketed trend (the week view) + prefs persistence

`Database.watch_ad_session_trend(window_hours=24, bucket="hour")` gains a
**day mode** (the worklog's own deferred suggestion): `bucket="day"`
derives `days = window_hours // 24` (min 1; the 168h cap ⇒ at most 7)
and buckets by `substr(created_at, 1, 10)` — the last N CALENDAR DAYS
(zero-filled, oldest first) with the same per-bucket
sessions/rewarded/main/network split, the same current-vs-previous
window comparison (`previous` = the same number of calendar days
immediately before the window), the same peak/scale honesty. Day mode
keeps every V27.2 guarantee — `current == sum(buckets)` exactly
(day-aligned by construction) — and adds a `bucket` field to the output
(the bucket key still rides `hour_start`; the field name kept for
structure compatibility). An unknown `bucket` value falls back to hour
mode; hour mode is byte-identical (all 12 K checks unchanged). The 📊
Watch Ads Status panel renders the 7d line under the hourly one
(`This 7d: N · previous 7d: M ▲ up · rewarded K · peak P @ MM-DD
(V27.3 · day buckets)`) — guarded to vanish on a session-less DB. The
suite grows to **121/121** (new section L — 13 checks: the zeroed
day-mode structure, the contiguous 7-day skeleton, same-day
aggregation, the previous-7d window, reconciliation, the launch split,
the peak, hour-mode stability, the unknown-bucket fallback, the days
derivation, read-only, the panel line, the no-session absence). Demo:
`/demo/metrics` serves `trend.h168d`; the boot log prints the V27.3
baseline. Dashboard: the metrics card renders the DAY chart for the 7d
window (7 weekday-labelled bars, emerald V27.3 badge), a chart legend
row with a **rewarded-overlay toggle** (amber dashed watermarks at the
rewarded height INSIDE each bar — a level marker, never a second bar:
rewarded ⊂ sessions), and the view/window/overlay preferences now
**persist across reloads** (guarded localStorage). ALSO FIXED this
round: a staleness bug in the QA explorer — the persisted last-run
cache (the test-run route's memory) could HIDE a newly shipped suite
section from the accordion (section L was missing until a re-run); the
section list is now the manifest-anchored merge (status route sections
∪ parsed per-check detail by id).
