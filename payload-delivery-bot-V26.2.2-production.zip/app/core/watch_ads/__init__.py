"""Watch Ads domain service."""
