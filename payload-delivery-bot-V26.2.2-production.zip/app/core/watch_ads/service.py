"""Watch Ads domain service: configuration, validation, the gate
evaluation used by the Access Engine, unlock templates and the
per-session Mini App URL builder."""
from __future__ import annotations

import logging
from types import SimpleNamespace

from app.core.constants import WATCH_AD_SDK_MAX_CHARS
from app.core.dbutil import safe_row_get as _safe_row_get
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlsplit
import aiosqlite
import re
import string as _string

logger = logging.getLogger("payload-bot")

WATCH_AD_TEMPLATE_SETTING_KEY = "watch_ads_unlock_template"

WATCH_AD_UNLOCK_TEMPLATE_DEFAULT = (
    "\U0001F3AC Watch Ads to Unlock \U0001F513\n\n"
    "Watch a short rewarded ad to unlock unlimited\n"
    "access for the next {minutes} minutes."
)

_WATCH_AD_TEMPLATE_FIELDS = frozenset({
    "minutes", "ads_required", "completed_ads", "remaining_ads", "payload",
})

WATCH_AD_TEMPLATE_MAX_LEN = 600  # Telegram-friendly; 4096 is the hard cap


def make_watch_ads_service(db, MINI_APP_BASE_URL=None, WATCH_AD_UNLOCK_WINDOW=None, MINI_APP_DEV_ALLOW_HTTP=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    def validate_watch_ads_mini_app_url(raw: str) -> Tuple[Optional[str], str]:
        """Server-side validation for the Watch Ads Mini App Website URL.

        Production requirements: HTTPS only, valid absolute URL, valid hostname,
        supported scheme. Rejects malformed URLs, javascript:, data:, and any
        unsupported scheme. HTTP is ONLY permitted when the explicit development
        switch (MINI_APP_DEV_ALLOW_HTTP=true) is set.

        Returns (normalized_url, error_message). error_message is "" when valid.
        """
        if not raw or not raw.strip():
            return None, "URL is empty."
        candidate = raw.strip()
        # Reject obvious scheme-injection whitespace / control characters.
        if any(ch.isspace() or ord(ch) < 32 for ch in candidate):
            return None, "URL contains invalid characters."
        lowered = candidate.lower()
        if lowered.startswith(("javascript:", "data:", "vbscript:", "file:", "ftp:")):
            return None, "Unsupported URL scheme."
        try:
            from urllib.parse import urlsplit
            parts = urlsplit(candidate)
        except Exception:  # noqa: BLE001
            return None, "Malformed URL."
        scheme = (parts.scheme or "").lower()
        if scheme not in ("https", "http"):
            return None, "URL must start with https://"
        if scheme == "http" and not MINI_APP_DEV_ALLOW_HTTP:
            return None, ("HTTPS is required in production. "
                          "http:// is only allowed with MINI_APP_DEV_ALLOW_HTTP=true.")
        host = (parts.hostname or "").strip().lower()
        if not host or "." not in host and host not in ("localhost", "127.0.0.1"):
            return None, "URL hostname is invalid."
        if any(ch.isspace() for ch in host):
            return None, "URL hostname is invalid."
        # Normalize: strip trailing slash; keep path/query empty (base URL only).
        normalized = f"{scheme}://{parts.netloc}"
        if parts.path and parts.path != "/":
            normalized += parts.path.rstrip("/")
        return normalized, ""

    def validate_watch_ads_sdk_code(raw: str) -> Tuple[Optional[str], str]:
        """Validation for the admin-pasted Monetag SDK / ad-tag code.

        The pasted code is UNTRUSTED CONFIGURATION:
          * rejected when empty
          * rejected above WATCH_AD_SDK_MAX_CHARS
          * must be text and plausibly Monetag integration code (contains a
            <script tag, or SDK markers like show_ / data-zone / data-sdk / zone)
          * NEVER executed during validation
          * NEVER logged in full
          * NEVER sent to ordinary Telegram users
        Returns (accepted_code, error_message). error_message is "" when valid.
        """
        if raw is None:
            return None, "SDK code is empty."
        code = raw.strip()
        if not code:
            return None, "SDK code is empty."
        if len(code) > WATCH_AD_SDK_MAX_CHARS:
            return None, (f"SDK code is too large ({len(code)} chars, max "
                          f"{WATCH_AD_SDK_MAX_CHARS}).")
        if "\x00" in code:
            return None, "SDK code contains invalid characters."
        lowered = code.lower()
        plausibly_integration = (
            "<script" in lowered
            or "show_" in lowered
            or "data-zone" in lowered
            or "data-sdk" in lowered
            or "monetag" in lowered
            or "sdk.js" in lowered
        )
        if not plausibly_integration:
            return None, "Invalid Monetag SDK code."
        return code, ""

    def _parse_monetag_sdk_tag(sdk_code: Optional[str]) -> Dict[str, Optional[str]]:
        """Extract the SDK function name + zone id from the stored Monetag SDK tag.

        The official Monetag TMA SDK tag looks like:
            <script src="https://<domain>/sdk.js" data-zone="123456"
                    data-sdk="show_123456"></script>
        The show_XXX global function is what the Mini App calls with
        {ymid: <session token>, type: 'end'} to run the Rewarded Interstitial.
        """
        if not sdk_code:
            return {"sdk_fn": None, "zone": None}
        fn = re.search(r"data-sdk\s*=\s*[\"']([A-Za-z0-9_]+)[\"']", sdk_code)
        zone = re.search(r"data-zone\s*=\s*[\"'](\w+)[\"']", sdk_code)
        return {"sdk_fn": (fn.group(1) if fn else None),
                "zone": (zone.group(1) if zone else None)}

    async def get_watch_ads_global_config() -> Dict[str, Any]:
        """Load the GLOBAL Watch Ads configuration (database is authoritative).

        Keys returned:
          mini_app_url — validated base URL of the Mini App website (or None)
          sdk_code     — the stored Monetag SDK code (or None)
          unlock_window— seconds a verified unlock stays valid
          session_ttl  — seconds a pending ad session stays valid (v27)
          enabled      — GLOBAL Watch Ads master switch (v27; default ON)
          url_ok / sdk_ok / configured — readiness flags
        The MINI_APP_BASE_URL environment variable only acts as an OPTIONAL
        seed (applied once in post_init when the DB key is absent); it never
        overwrites the admin's database value on restart.
        """
        url_raw = await db.get_setting("watch_ads_mini_app_url")
        mini_app_url, _err = validate_watch_ads_mini_app_url(url_raw or "")
        if not mini_app_url and not url_raw and MINI_APP_BASE_URL:
            # Env fallback (read-only; never persisted over a DB value).
            mini_app_url, _err = validate_watch_ads_mini_app_url(MINI_APP_BASE_URL)
        sdk_code = await db.get_setting("watch_ads_monetag_sdk")
        sdk_code = sdk_code.strip() if isinstance(sdk_code, str) and sdk_code.strip() else None
        unlock_window = await db.get_setting_int("watch_ads_unlock_window",
                                                 WATCH_AD_UNLOCK_WINDOW)
        # V2 (v26): Ads Control mode (DB authoritative; env never writes it).
        ad_control = await db.get_watch_ads_ad_control()
        # V4 (v27): GLOBAL master switch + admin-configurable session TTL.
        global_enabled = await db.get_watch_ads_global_enabled()
        session_ttl = await db.get_watch_ads_session_ttl()
        return {
            "mini_app_url": mini_app_url,
            "sdk_code": sdk_code,
            "unlock_window": int(unlock_window) if unlock_window else WATCH_AD_UNLOCK_WINDOW,
            "ad_control": ad_control,
            "enabled": global_enabled,
            "session_ttl": int(session_ttl),
            "url_ok": bool(mini_app_url),
            "sdk_ok": bool(sdk_code),
            "configured": bool(mini_app_url and sdk_code),
        }

    def validate_watch_ads_unlock_template(text: str) -> Tuple[Optional[str], Optional[str]]:
        """Validate an admin-supplied unlock template.

        Returns (normalized_template, None) on success or (None, error_message)
        on failure. A FAILED validation never overwrites the stored value.

        Invalid:
          * empty / whitespace-only
          * longer than WATCH_AD_TEMPLATE_MAX_LEN
          * control characters (except newline)
          * malformed brace groups (unclosed '{', empty '{}', stray '}')
        Unknown placeholders (e.g. {hours}) are VALID — they render literally
        (documented in the admin panel), they never crash the renderer.
        """
        if not isinstance(text, str) or not text.strip():
            return None, "Template is empty."
        normalized = text.strip()
        if len(normalized) > WATCH_AD_TEMPLATE_MAX_LEN:
            return None, (f"Template is too long ({len(normalized)} chars; "
                          f"max {WATCH_AD_TEMPLATE_MAX_LEN}).")
        for ch in normalized:
            if ord(ch) < 32 and ch != "\n":
                return None, "Template contains control characters."
        # Malformed-brace detection: string.Formatter().parse() raises ValueError
        # on unclosed '{', '}', or empty '{}' groups. PHASE 6: an empty field name
        # ('{}') parses cleanly but is meaningless — rejected explicitly.
        import string as _string
        try:
            parsed = list(_string.Formatter().parse(normalized))
        except ValueError as e:
            return None, (f"Malformed placeholder braces: {e}. "
                          "Check that every '{{' has a matching '}}'.")
        for _lit, field, _spec, _conv in parsed:
            if field == "":
                return None, "Empty placeholder '{}' is not valid."
        return normalized, None

    def render_watch_ads_unlock_message(template: Optional[str], *,
                                        minutes: int = 0,
                                        ads_required: int = 1,
                                        completed_ads: int = 0,
                                        payload: str = "") -> str:
        """Render the unlock template with the supported placeholders.

        Unknown placeholders render LITERALLY (never crash, never silently
        vanish). Malformed braces are likewise left untouched — validation
        happens at save time, rendering is always safe.
        """
        body = template if (isinstance(template, str) and template.strip()) \
            else WATCH_AD_UNLOCK_TEMPLATE_DEFAULT
        values = {
            "minutes": int(max(0, minutes)),
            "ads_required": int(max(1, ads_required)),
            "completed_ads": int(max(0, completed_ads)),
            "remaining_ads": int(max(0, max(1, ads_required) - max(0, completed_ads))),
            "payload": str(payload or ""),
        }

        class _SafeMap(dict):
            """str.format_map fallback: unknown keys render literally."""

            def __missing__(self, key):  # pragma: no cover - trivial
                return "{" + key + "}"

        try:
            return body.format_map(_SafeMap(values))
        except Exception:  # noqa: BLE001 — the renderer can NEVER crash a screen
            return body

    async def get_watch_ads_unlock_template() -> str:
        """Read the stored unlock template (bot_settings key). Falls back to the
        default when absent/blank — restart-safe, no migration required."""
        try:
            stored = await db.get_setting(WATCH_AD_TEMPLATE_SETTING_KEY)
        except Exception:  # noqa: BLE001
            stored = None
        if isinstance(stored, str) and stored.strip():
            return stored
        return WATCH_AD_UNLOCK_TEMPLATE_DEFAULT

    def _watch_ads_template_unknown_placeholders(template: str) -> List[str]:
        """List unknown {placeholders} in a template (admin diagnostics only)."""
        import string as _string
        unknown: List[str] = []
        try:
            for _lit, field, _spec, _conv in _string.Formatter().parse(template):
                if field and field not in _WATCH_AD_TEMPLATE_FIELDS:
                    unknown.append("{" + field + "}")
        except ValueError:
            pass
        return unknown

    async def _watch_ads_unlock_minutes() -> int:
        """Unlock window in whole minutes (for the {minutes} placeholder)."""
        try:
            cfg = await get_watch_ads_global_config()
            return max(1, int(cfg.get("unlock_window") or 0) // 60)
        except Exception:  # noqa: BLE001
            return max(1, WATCH_AD_UNLOCK_WINDOW // 60)

    async def _watch_ads_gate_active(payload_row: Optional[aiosqlite.Row]) -> bool:
        """WATCH_AD V4 (v27): is the Watch Ads requirement ACTIVE for this payload?

        True only when BOTH hold:
          * the payload has watch_ads_enabled=1 (per-payload toggle, unchanged),
          * the GLOBAL master switch is ON (watch_ads_global_enabled, default ON).

        Global OFF => every payload behaves exactly as if watch_ads_enabled=0:
        base policy only (single authorization layer, no scattered checks). A
        session that is already in flight keeps running (stability), but no new
        gates/launch buttons/sessions are created.
        """
        if payload_row is None or not _safe_row_get(payload_row, "watch_ads_enabled"):
            return False
        try:
            return await db.get_watch_ads_global_enabled()
        except Exception:  # noqa: BLE001
            return True  # fail-open only for the SWITCH READ (default ON); the

    async def build_watch_ad_session_url(user_id: int, payload_row: aiosqlite.Row,
                                         network_bot_id: Optional[int] = None
                                         ) -> Optional[str]:
        """Build the secure per-session Mini App URL for (user, payload).

        Returns None (and NEVER a broken link) when:
          * the Mini App Website URL is not configured, or
          * the Monetag SDK is not configured, or
          * session creation is capped / unavailable.
        Reuses a live pending session so repeated presses never spawn unlimited
        simultaneous sessions.

        V26 (Network Bot Watch Ads): ``network_bot_id`` (the bot whose
        [🎬 Watch Ad] button is being rendered — the serving bot when the
        access screen runs inside a NETWORK worker) is stamped onto the
        session row (``launch_network_bot_id``) so the VERIFIED-reward
        notification + auto-resume route through the bot the user is
        actually talking to. Best-effort: a stamping failure never breaks
        the launch (the reward path falls back to the main bot exactly as
        before). ``None``/0 keeps the session's existing value (main-bot
        semantics for every legacy caller).
        """
        cfg = await get_watch_ads_global_config()
        # V4 (v27): GLOBAL master switch OFF -> no new sessions / launch URLs.
        # (In-flight sessions keep their stability; the access engine already
        # treats every payload as WA-off while the switch is OFF.)
        if not cfg.get("enabled", True):
            logger.warning("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                           "reason=watch_ads_globally_disabled", user_id,
                           _safe_row_get(payload_row, "id"))
            return None
        if not cfg["url_ok"] or not cfg["sdk_ok"]:
            # Structured diagnostics (spec §17): which global piece is missing.
            # A URL that was SET but failed validation is URL_INVALID; an absent
            # URL/SDK is CONFIG_MISSING. Never logged: values/SDK contents.
            if cfg["url_ok"] is False:
                _raw = await db.get_setting("watch_ads_mini_app_url")
                if _raw:
                    logger.warning("WATCH_AD_URL_INVALID user_id=%s payload_id=%s "
                                   "reason=stored_url_failed_validation", user_id,
                                   _safe_row_get(payload_row, "id"))
                else:
                    logger.warning("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                                   "reason=mini_app_url_not_configured", user_id,
                                   _safe_row_get(payload_row, "id"))
            if cfg["sdk_ok"] is False:
                logger.warning("WATCH_AD_CONFIG_MISSING user_id=%s payload_id=%s "
                               "reason=monetag_sdk_not_configured", user_id,
                               _safe_row_get(payload_row, "id"))
            return None
        if payload_row is None or _safe_row_get(payload_row, "id") is None:
            logger.warning("WATCH_AD_SESSION_INVALID user_id=%s reason=payload_row_missing",
                           user_id)
            return None
        session, _created = await db.get_or_create_watch_ad_session(
            int(user_id), int(payload_row["id"]))
        if not session:
            # create_watch_ad_session() already logged the structured cause.
            logger.warning("WATCH_AD_SESSION_INVALID user_id=%s payload_id=%s "
                           "reason=session_creation_returned_none", user_id,
                           int(payload_row["id"]))
            return None
        # V26: stamp the launch context (idempotent — only write when the
        # value actually changes, so repeated renders stay read-only).
        try:
            _nid = int(network_bot_id) if network_bot_id else 0
            _cur = int(_safe_row_get(session, "launch_network_bot_id")
                       or 0)
            if _nid != _cur:
                setter = getattr(db, "set_watch_ad_session_launch_network_bot_id",
                                 None)
                if callable(setter):
                    await setter(int(session["id"]), _nid or None)
                    logger.info(
                        "WATCH_AD_LAUNCH_CONTEXT session=%s user_id=%s "
                        "payload_id=%s network_bot_id=%s (the Watch Ad "
                        "button's serving bot — reward routing context)",
                        int(session["id"]), int(user_id),
                        int(payload_row["id"]), _nid or "main")
        except Exception:  # noqa: BLE001 — routing hint only, never fatal
            logger.debug("watch_ad launch-context stamp failed",
                         exc_info=True)
        base = cfg["mini_app_url"].rstrip("/")
        return f"{base}/watch-ad/{session['token']}"

    return SimpleNamespace(
        validate_watch_ads_mini_app_url=validate_watch_ads_mini_app_url,
        validate_watch_ads_sdk_code=validate_watch_ads_sdk_code,
        _parse_monetag_sdk_tag=_parse_monetag_sdk_tag,
        get_watch_ads_global_config=get_watch_ads_global_config,
        validate_watch_ads_unlock_template=validate_watch_ads_unlock_template,
        render_watch_ads_unlock_message=render_watch_ads_unlock_message,
        get_watch_ads_unlock_template=get_watch_ads_unlock_template,
        _watch_ads_template_unknown_placeholders=_watch_ads_template_unknown_placeholders,
        _watch_ads_unlock_minutes=_watch_ads_unlock_minutes,
        _watch_ads_gate_active=_watch_ads_gate_active,
        build_watch_ad_session_url=build_watch_ad_session_url,
    )
