"""PHASE 8 (§11-§18): Force-Join invite-link health service.

STANDALONE MODULE — never imports the bot monolith (no circular imports).
bot.py wires it at call time by passing a bot instance + persistence hooks.

Purpose (production evidence bot.log 22):
  * Users were shown "Join" buttons whose invite links were expired/revoked.
  * Stored links were NEVER verified (only the CHANNEL was checked).
  * All 9 configured channels were declared "INVALID (Chat not found)" at
    startup, repeatedly, with no persisted health state and no distinction
    between transient Telegram failures and real configuration problems.

B18 (bot-19.log) — the two production root causes this version fixes:
  * bot-19.log 03:23:59: ``FORCE_JOIN_LINK_HEALTH state=temporary_error
    detail=bot API lacks get_chat_invite_link`` — the B17 verifier called
    a Bot API method that DOES NOT EXIST (the Bot API can create/edit/
    revoke invite links but has NO getChatInviteLink), so EVERY channel
    with an invite link degraded to temporary_error at every startup
    (``channels=7 healthy=0 temporary=7``) — including a link the bot had
    JUST created and stored itself (03:23:57 FORCE_JOIN_INVITE_ROTATE
    result=success → 03:23:59 temporary_error).
  * bot-19.log 03:33:55: ``state=link_invalid detail=stored link is not a
    t.me link`` — after remove/re-add the channel row had invite_link=NULL
    (add_force_channel stores no link), and the verifier classified a
    MISSING link as LINK_INVALID ("dead link") → ``dead_links=1`` for a
    perfectly valid channel.

This module provides:
  * LinkHealth states matching the unified specification:
        HEALTHY            — verified usable right now (or trusted with a
                             verified channel — see the capability note)
        LINK_EXPIRED       — Telegram-confirmed expiry (or expired_at < now)
        LINK_REVOKED       — Telegram-confirmed revocation
        LINK_INVALID       — Telegram-confirmed unusable for this channel
        CHANNEL_INVALID    — the channel itself is inaccessible to the bot
        BOT_PERMISSION     — bot lacks rights to manage the link/channel
        TEMPORARY_ERROR    — flood control / timeout / network (NOT invalid)
        UNVERIFIABLE       — public t.me/<username> links the bot cannot
                             resolve right now (permanent form; no dead
                             verdict is possible from a resolution failure)
        NO_LINK            — no link stored yet (NOT dead — auto-creatable
                             by _get_or_create_invite_link / startup
                             auto-repair)
  * ``normalize_join_link`` — the canonical URL normalizer supporting
    https://t.me/<username>, https://t.me/+<hash>,
    https://t.me/joinchat/<hash>, http/https variants, bare-domain forms,
    telegram.me + telegram.dog mirrors, tg://join?invite=<hash>,
    tg://resolve?domain=<username>, @username, query strings/fragments,
    and case-insensitive hosts.
  * The Bot-API-CAPABLE verification path (B18): public links are
    verified by resolving the username via getChat (id match proven,
    mismatch proven wrong-chat, resolution failure NEVER a dead
    verdict); invite links cannot be introspected by hash (NO Bot API
    method) — the correct alternative path verifies the CHANNEL: the
    bot's own membership/administrator status (getChatMember) + the
    stored link's PROVENANCE (bot_created = provably valid until our
    own rotation revokes it; custom = trusted with the channel
    verified). A capability limitation NEVER becomes a misleading
    permanent failure (bot-19.log's every-channel-temporary loop).
  * A TTL health cache with explicit invalidation (admin link change,
    rotation, join-request event, Telegram API error, manual Test/Refresh).
  * Pure classification logic (exception-name based — no PTB dependency),
    fully unit-testable with fabricated exceptions.

Rules enforced here (spec §12/§19):
  * A transient Telegram error (RetryAfter / TimedOut / NetworkError /
    generic network) is TEMPORARY_ERROR — NEVER an invalid verdict.
  * Only Telegram-confirmed conditions produce invalid/expired/revoked.
  * The caller persists state changes; this module never touches the DB.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

# ---------------------------------------------------------------------------
# Health states
# ---------------------------------------------------------------------------
LINK_HEALTHY = "healthy"
LINK_EXPIRED = "link_expired"
LINK_REVOKED = "link_revoked"
LINK_INVALID = "link_invalid"
CHANNEL_INVALID = "channel_invalid"
BOT_PERMISSION = "bot_permission"
TEMPORARY_ERROR = "temporary_error"
UNVERIFIABLE = "unverifiable"
NO_LINK = "no_link"

_TRANSIENT_STATES = frozenset({TEMPORARY_ERROR})
_DEAD_LINK_STATES = frozenset({LINK_EXPIRED, LINK_REVOKED, LINK_INVALID})

DEFAULT_CACHE_TTL_SECONDS = 300.0

# ---------------------------------------------------------------------------
# B18 — the canonical join-link normalizer (bot-19.log "stored link is not
# a t.me link" root cause: the B17 parser only accepted a handful of literal
# prefixes and rejected EVERYTHING else — including links stored as
# tg://join?invite=… or telegram.dog mirrors, and the NULL link a re-added
# channel row legitimately has).
# ---------------------------------------------------------------------------
_TME_HOSTS = ("t.me", "www.t.me", "telegram.me", "www.telegram.me",
              "telegram.dog", "www.telegram.dog")


def normalize_join_link(link: Optional[str]) -> Tuple[Optional[str],
                                                       Optional[str]]:
    """Normalize ANY supported Telegram join-link spelling to the canonical
    ``https://t.me/<...>`` form.

    Returns ``(canonical_url, kind)`` where kind is ``'public'``
    (t.me/<username>) or ``'invite'`` (t.me/+<hash> | t.me/joinchat/<hash>),
    or ``(None, None)`` when the input is empty or is NOT a join link
    (message permalinks t.me/c/<id>/<msg> are NOT join links; neither are
    non-Telegram URLs).

    Supported inputs (host case-insensitive, scheme optional, trailing
    slashes/query strings/fragments tolerated):
      https://t.me/<username>     http://t.me/+<hash>      t.me/joinchat/<hash>
      https://telegram.me/…       https://telegram.dog/…   tg://join?invite=<hash>
      tg://resolve?domain=<username>                       @<username>
    """
    if not link or not isinstance(link, str):
        return None, None
    raw = link.strip()
    if not raw:
        return None, None
    lowered = raw.lower()

    # ---- tg:// deep links ------------------------------------------------
    if lowered.startswith("tg://"):
        try:
            parsed = urlparse(raw)          # raw: query values are
            lowered_parsed = urlparse(lowered)  # case-sensitive (hashes!)
        except ValueError:
            return None, None
        host = (lowered_parsed.netloc or "").strip().lower()
        qs = parse_qs(parsed.query)
        if host == "join":
            hashes = qs.get("invite") or qs.get("hash") or []
            if not hashes or not hashes[0]:
                return None, None
            return f"https://t.me/+{unquote(hashes[0])}", "invite"
        if host == "resolve":
            domains = qs.get("domain") or []
            if not domains or not domains[0]:
                return None, None
            uname = unquote(domains[0]).strip().lstrip("@")
            if not uname:
                return None, None
            return f"https://t.me/{uname}", "public"
        return None, None

    # ---- @username shorthand ---------------------------------------------
    if raw.startswith("@"):
        uname = raw[1:].strip().strip("/").split("?")[0].split("#")[0]
        if not uname or "/" in uname:
            return None, None
        return f"https://t.me/{uname}", "public"

    # ---- http(s) t.me-family URLs (and scheme-less bare domains) ---------
    body = raw
    for scheme in ("https://", "http://"):
        if lowered.startswith(scheme):
            body = raw[len(scheme):]
            lowered = lowered[len(scheme):]
            break
    # strip userinfo-free host: split path
    host_part = lowered.split("/", 1)[0]
    if host_part not in _TME_HOSTS:
        return None, None
    path = body[len(host_part):].lstrip("/")
    # strip query string / fragment
    path = path.split("?", 1)[0].split("#", 1)[0].strip("/")
    if not path:
        return None, None
    seg = path.split("/")
    first = seg[0]
    if first.startswith("+") and len(first) > 1:
        return f"https://t.me/{first}", "invite"
    if first.lower() == "joinchat" and len(seg) >= 2 and seg[1]:
        return f"https://t.me/+{seg[1]}", "invite"
    if first.lower() == "c":
        # t.me/c/<internal_id>/<message_id> — a MESSAGE permalink into a
        # private channel, NOT a join link (joining requires membership).
        return None, None
    # public username (optionally followed by a message id — still a
    # join link for the channel)
    if not first or "/" in first and len(seg) > 2:
        return None, None
    return f"https://t.me/{first}", "public"


def link_syntax_kind(link: Optional[str]) -> Optional[str]:
    """Classify a stored join link purely by syntax.

    Returns 'public' (t.me/<username> — permanent), 'invite'
    (t.me/+<hash> or t.me/joinchat/<hash> — revocable, expirable), or
    None when the value is not a recognizable Telegram join link.
    B18: built on ``normalize_join_link`` (which also accepts tg://
    deep links, telegram.me/telegram.dog mirrors, @usernames and
    query-string variants that the B17 literal-prefix parser rejected).
    """
    _canonical, kind = normalize_join_link(link)
    return kind


@dataclass
class LinkHealthResult:
    """Outcome of one link-health verification."""
    state: str
    detail: str = ""
    expires_at: Optional[str] = None          # ISO-8601 when Telegram reports it
    verified_at: Optional[str] = None         # ISO-8601 of this check
    checked_api: bool = False                 # True when Telegram was actually asked

    @property
    def is_transient(self) -> bool:
        return self.state in _TRANSIENT_STATES

    @property
    def is_dead_link(self) -> bool:
        """True ONLY for Telegram-confirmed unusable links."""
        return self.state in _DEAD_LINK_STATES


def _exc_name(exc: BaseException) -> str:
    return type(exc).__name__


def _classify_telegram_exception(exc: BaseException) -> str:
    """Name-based Telegram exception classification (PTB class names are
    stable; this keeps the module free of PTB imports and unit-testable)."""
    name = _exc_name(exc)
    lowered = str(exc).lower()
    if name == "RetryAfter" or getattr(exc, "retry_after", None) is not None:
        return TEMPORARY_ERROR
    if name in ("TimedOut", "NetworkError", "ClientConnectorError",
                "ServerDisconnectedError", "ConnectionResetError",
                "AsyncTimeoutError"):
        return TEMPORARY_ERROR
    if name == "Forbidden":
        return BOT_PERMISSION
    if name == "BadRequest":
        # Telegram-confirmed refusals. Expired invite links are reported by
        # the Bot API with phrases like 'INVITE_HASH_EXPIRED' /
        # 'invite link expired'.
        if "expired" in lowered:
            return LINK_EXPIRED
        if "revoked" in lowered:
            return LINK_REVOKED
        if "invite" in lowered or "link" in lowered or "chat not found" in lowered:
            return LINK_INVALID
        return LINK_INVALID
    if name == "InvalidChatId" or "chat not found" in lowered:
        return CHANNEL_INVALID
    # Unknown/unclassified (e.g. rare TelegramError subclasses, upstream
    # aiohttp errors) — NEVER a permanent verdict.
    return TEMPORARY_ERROR


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_dt(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value))
        except (TypeError, ValueError):
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


async def verify_invite_link(bot: Any, channel_id: int,
                             link: Optional[str],
                             channel_accessible: Optional[bool] = None,
                             link_provenance: Optional[str] = None,
                             ) -> LinkHealthResult:
    """Verify one stored join link for a channel — B18 Bot-API-CAPABLE.

    ``channel_accessible`` — when the caller already knows the tri-state
    channel-access result it passes it here to avoid a duplicate get_chat:
      * False  → CHANNEL_INVALID immediately (no link API call needed)
      * None   → a transient/unverified access result: the link check is
                 still attempted (a stored link keeps working for users
                 regardless of current bot access — PHASE 6 §9 semantics).

    ``link_provenance`` — WHO minted the stored link (schema v39 column):
      'bot_created' (export/create/rotate — provably valid until our own
      rotation revokes it) | 'custom' (admin-supplied) | None (legacy).

    CAPABILITY NOTE (the bot-19.log root cause): the Telegram Bot API has
    createChatInviteLink / editChatInviteLink / revokeChatInviteLink but
    NO getChatInviteLink — an invite link's hash CANNOT be introspected
    by ANY Bot API call. The B17 verifier depended on the nonexistent
    method (every channel → temporary_error forever). The B18 path
    verifies what the Bot API CAN:
      * public links — resolve the @username via getChat: an id MATCH is
        proof (HEALTHY); an id MISMATCH is proof of a wrong-chat link
        (LINK_INVALID); a resolution failure is NEVER a dead verdict
        (UNVERIFIABLE / TEMPORARY_ERROR);
      * invite links — verify the CHANNEL instead: the bot's own
        membership via getChatMember (administrator/creator = the bot can
        serve the channel, check user membership and mint links) + the
        link's provenance (bot_created = tracked, provably valid until
        OUR rotation revokes it; custom = trusted with the channel
        verified — Test Channel / Auto Change Link remain available).
    """
    if channel_accessible is False:
        return LinkHealthResult(CHANNEL_INVALID,
                                "channel inaccessible to the bot",
                                verified_at=_now_iso())
    # B18 (bot-19.log 03:33:55): a MISSING link is NO_LINK — NOT a dead
    # link. add_force_channel creates rows with invite_link=NULL; the
    # old verifier classified that as LINK_INVALID ("stored link is not
    # a t.me link") and a freshly re-added VALID channel landed in
    # dead_links. NO_LINK is auto-creatable (_get_or_create_invite_link
    # + the startup auto-repair).
    if not link or not str(link).strip():
        return LinkHealthResult(
            NO_LINK, "no link stored yet (auto-creatable by the bot when "
                     "it has invite rights — not an error)",
            verified_at=_now_iso())
    canonical, kind = normalize_join_link(link)
    if canonical is None:
        return LinkHealthResult(
            LINK_INVALID,
            "stored link is not a valid Telegram join link (expected "
            "t.me/<username>, t.me/+<hash>, t.me/joinchat/<hash> or a "
            "tg:// equivalent)",
            verified_at=_now_iso())

    # ------------------------------------------------------------------
    # PUBLIC links — REAL verification via username resolution.
    # ------------------------------------------------------------------
    if kind == "public":
        uname = canonical.rsplit("/", 1)[-1]
        getter = getattr(bot, "get_chat", None)
        if not callable(getter):
            return LinkHealthResult(
                UNVERIFIABLE,
                "public username link (permanent); this client cannot "
                "resolve usernames",
                verified_at=_now_iso())
        try:
            chat = await getter(f"@{uname}")
        except Exception as e:  # noqa: BLE001 — classified below
            state = _classify_telegram_exception(e)
            if state == LINK_INVALID:
                # Telegram answered that the username resolves to nothing
                # (getChat is a LIVE answer) — the link cannot join anyone.
                return LinkHealthResult(
                    LINK_INVALID,
                    f"public username does not resolve: "
                    f"{_exc_name(e)}: {str(e)[:100]}",
                    verified_at=_now_iso(), checked_api=True)
            if state == TEMPORARY_ERROR:
                return LinkHealthResult(
                    TEMPORARY_ERROR,
                    f"username resolution hit a transient error "
                    f"({_exc_name(e)}) — NOT marked invalid",
                    verified_at=_now_iso())
            # Any other resolution failure (Forbidden, unclassifiable) —
            # the public link is permanent; NO dead verdict is possible.
            return LinkHealthResult(
                UNVERIFIABLE,
                f"public username link (permanent); bot could not resolve "
                f"the username right now ({_exc_name(e)})",
                verified_at=_now_iso())
        resolved_raw = getattr(chat, "id", 0)
        try:
            resolved_id = int(resolved_raw or 0)
        except (TypeError, ValueError):
            # Test fakes / exotic clients may return non-int ids — treat
            # as unresolvable (UNVERIFIABLE, never a dead verdict).
            resolved_id = 0
        if resolved_id and int(channel_id) and resolved_id == int(channel_id):
            return LinkHealthResult(
                LINK_HEALTHY,
                f"public link verified (getChat resolved @{uname} to this "
                "channel)",
                verified_at=_now_iso(), checked_api=True)
        if resolved_id:
            return LinkHealthResult(
                LINK_INVALID,
                f"public link points at a DIFFERENT chat (username "
                f"resolves to {resolved_id}, this channel is "
                f"{int(channel_id)}) — Telegram-confirmed wrong-chat link",
                verified_at=_now_iso(), checked_api=True)
        return LinkHealthResult(
            UNVERIFIABLE,
            "public username link (permanent); Telegram returned no "
            "resolvable id",
            verified_at=_now_iso())

    # ------------------------------------------------------------------
    # INVITE links — the Bot API CANNOT introspect the hash (no
    # getChatInviteLink exists). The correct alternative verification
    # path: the CHANNEL (the bot's own membership/administrator status
    # via getChatMember) + the link's PROVENANCE.
    # ------------------------------------------------------------------
    me_getter = getattr(bot, "get_me", None)
    member_getter = getattr(bot, "get_chat_member", None)
    if not callable(me_getter) or not callable(member_getter):
        # Strict test fakes / partial deployments — the capability-limited
        # honest verdict (NEVER temporary_error: the limitation is
        # permanent for THIS client, and NEVER invalid: nothing about the
        # link is disproven).
        return LinkHealthResult(
            UNVERIFIABLE,
            "invite link; this client cannot probe membership (Bot API "
            "cannot introspect invite hashes) — link trusted",
            verified_at=_now_iso())
    try:
        me = await me_getter()
        bot_id = int(getattr(me, "id", 0) or 0)
    except Exception as e:  # noqa: BLE001
        state = _classify_telegram_exception(e)
        if state == TEMPORARY_ERROR:
            return LinkHealthResult(
                TEMPORARY_ERROR,
                f"identity probe hit a transient error ({_exc_name(e)}) "
                "— NOT marked invalid",
                verified_at=_now_iso())
        return LinkHealthResult(
            UNVERIFIABLE,
            f"invite link; identity probe failed ({_exc_name(e)}) — "
            "link trusted (Bot API cannot introspect invite hashes)",
            verified_at=_now_iso())
    if not bot_id:
        return LinkHealthResult(
            UNVERIFIABLE,
            "invite link; identity probe returned no id — link trusted "
            "(Bot API cannot introspect invite hashes)",
            verified_at=_now_iso())
    try:
        member = await member_getter(int(channel_id), bot_id)
    except Exception as e:  # noqa: BLE001 — classified below
        low = str(e).lower()
        state = _classify_telegram_exception(e)
        if "chat not found" in low:
            return LinkHealthResult(
                CHANNEL_INVALID,
                f"channel not found for the bot's own membership check "
                f"({_exc_name(e)})",
                verified_at=_now_iso(), checked_api=True)
        if "user not found" in low or "member list is inaccessible" in low:
            return LinkHealthResult(
                BOT_PERMISSION,
                "bot is not a member of the channel (cannot verify or "
                "manage the join link / check user membership) — grant "
                "the bot administrator rights",
                verified_at=_now_iso(), checked_api=True)
        if state == TEMPORARY_ERROR:
            return LinkHealthResult(
                TEMPORARY_ERROR,
                f"membership probe hit a transient error ({_exc_name(e)}) "
                "— NOT marked invalid",
                verified_at=_now_iso())
        if state == BOT_PERMISSION:
            return LinkHealthResult(
                BOT_PERMISSION,
                f"{_exc_name(e)}: {str(e)[:120]}",
                verified_at=_now_iso(), checked_api=True)
        # Unclassifiable probe failure — the capability-limited honest
        # verdict (trusted link, channel unverified RIGHT NOW).
        return LinkHealthResult(
            UNVERIFIABLE,
            f"invite link; membership probe failed ({_exc_name(e)}) — "
            "link trusted, channel unverified right now (Bot API cannot "
            "introspect invite hashes)",
            verified_at=_now_iso())
    status = str(getattr(member, "status", "") or "").lower()
    can_invite = getattr(member, "can_invite_users", None)
    if status in ("administrator", "creator"):
        if str(link_provenance or "") == "bot_created":
            return LinkHealthResult(
                LINK_HEALTHY,
                "bot-created invite link (provably valid until our own "
                f"rotation revokes it); channel verified: bot is "
                f"{status}, can_invite_users="
                f"{can_invite if can_invite is not None else 'unknown'}",
                verified_at=_now_iso(), checked_api=True)
        return LinkHealthResult(
            LINK_HEALTHY,
            f"channel verified: bot is {status} "
            f"(can_invite_users={can_invite if can_invite is not None else 'unknown'}); "
            "the Bot API cannot introspect invite hashes — the stored "
            "link is trusted (Test Channel / Auto Change Link remain "
            "available)",
            verified_at=_now_iso(), checked_api=True)
    return LinkHealthResult(
        BOT_PERMISSION,
        f"bot is '{status or 'unknown'}' (not an administrator): cannot "
        "verify or manage the join link / check user membership — grant "
        "the bot administrator rights in the channel",
        verified_at=_now_iso(), checked_api=True)


# ---------------------------------------------------------------------------
# Health cache (spec §18 — never call Telegram repeatedly per user request)
# ---------------------------------------------------------------------------
@dataclass
class CachedHealth:
    state: str
    checked_at: float
    expires_at: Optional[str] = None
    detail: str = ""


class LinkHealthCache:
    """In-process TTL cache for per-channel link health.

    Invalidation triggers (spec §18) are explicit method calls:
      * admin link change          -> invalidate()
      * automatic rotation         -> invalidate() / store()
      * join-request event         -> invalidate()
      * Telegram API error on use  -> invalidate()
      * manual Test button         -> invalidate()
    """

    def __init__(self, ttl_seconds: float = DEFAULT_CACHE_TTL_SECONDS) -> None:
        self.ttl = float(ttl_seconds)
        self._entries: Dict[int, CachedHealth] = {}

    def get(self, channel_id: int) -> Optional[CachedHealth]:
        entry = self._entries.get(int(channel_id))
        if entry is None:
            return None
        if (time.time() - entry.checked_at) > self.ttl:
            self._entries.pop(int(channel_id), None)
            return None
        return entry

    def store(self, channel_id: int, state: str,
              expires_at: Optional[str] = None, detail: str = "") -> None:
        self._entries[int(channel_id)] = CachedHealth(
            state=state, checked_at=time.time(),
            expires_at=expires_at, detail=detail)

    def invalidate(self, channel_id: Optional[int] = None) -> None:
        if channel_id is None:
            self._entries.clear()
        else:
            self._entries.pop(int(channel_id), None)

    def snapshot(self) -> Dict[int, CachedHealth]:
        return dict(self._entries)


# ---------------------------------------------------------------------------
# UI helpers (spec §12/§16 — admin rows, user-facing friendly lines)
# ---------------------------------------------------------------------------
_STATE_BADGES = {
    LINK_HEALTHY: "\u2705 Healthy",
    LINK_EXPIRED: "\u26A0\uFE0F Link Expired",
    LINK_REVOKED: "\u26A0\uFE0F Link Revoked",
    LINK_INVALID: "\u274C Link Invalid",
    CHANNEL_INVALID: "\u274C Channel Invalid",
    BOT_PERMISSION: "\U0001F512 Bot Permission Problem",
    TEMPORARY_ERROR: "\u26A0\uFE0F Temporary Error",
    UNVERIFIABLE: "\U0001F517 Public Link (permanent)",
    NO_LINK: "\u26A0\uFE0F No Link Stored",
}


def health_badge(state: Optional[str]) -> str:
    return _STATE_BADGES.get(state or NO_LINK, _STATE_BADGES[NO_LINK])


def user_unavailable_line(label: str) -> str:
    """The friendly user-facing line shown instead of a dead Join button
    (spec §17 — never expose raw Telegram exceptions to users)."""
    return (f"\u26A0\uFE0F {label}: this channel's join link is temporarily "
            "unavailable.\n   Please try again shortly.")


__all__ = [
    "LINK_HEALTHY", "LINK_EXPIRED", "LINK_REVOKED", "LINK_INVALID",
    "CHANNEL_INVALID", "BOT_PERMISSION", "TEMPORARY_ERROR", "UNVERIFIABLE",
    "NO_LINK", "DEFAULT_CACHE_TTL_SECONDS",
    "LinkHealthResult", "LinkHealthCache", "CachedHealth",
    "verify_invite_link", "link_syntax_kind", "normalize_join_link",
    "health_badge", "user_unavailable_line",
]
