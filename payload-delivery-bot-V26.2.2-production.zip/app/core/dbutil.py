"""Domain row/time utilities (ARCHITECTURE PROPER BREAKDOWN).

``now_iso`` and ``safe_row_get`` are pure, dependency-free helpers used by
domain services, repositories and the presentation layer alike. They live
in the DOMAIN layer; ``app/storage/dbutil.py`` re-exports them for backward
compatibility (infrastructure may import domain — never the reverse).
"""
from __future__ import annotations

from datetime import datetime, timezone


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_row_get(row, key: str, default=None):
    """Safe column access for aiosqlite.Row — returns default if key missing.

    Issue 37: aiosqlite.Row raises IndexError on missing keys (unlike a dict
    which returns None). This helper makes access safe across all row types.
    """
    if row is None:
        return default
    try:
        return row[key]
    except (IndexError, KeyError):
        return default
