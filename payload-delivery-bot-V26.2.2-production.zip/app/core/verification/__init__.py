"""Verification & reconciliation engine (PHASE 8 — canonical).

The implementation lives in ``app.core.verification.engine``; this package
__init__ re-exports the public surface so legacy imports
``from app.core import verification`` keep working unchanged.
"""
from app.core.verification.engine import *  # noqa: F401,F403
from app.core.verification.engine import Deps, run_verification, render_report  # noqa: F401
