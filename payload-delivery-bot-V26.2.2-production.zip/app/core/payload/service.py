"""Payload domain service: slug/name validation, link builders,
unique payload creation (closure service) and the PayloadService
facade for future web/Mini-App code paths."""
from __future__ import annotations

import logging
from types import SimpleNamespace

from app.core.constants import COLLECTION_CODE_LENGTH
from app.core.constants import COLLECTION_LINK_PREFIX
from app.core.constants import DISPLAY_NAME_MAX_LENGTH
from app.core.constants import MSG_LINK_PREFIX
from app.core.constants import PAYLOAD_PATTERN
from app.core.constants import RANGE_LINK_PREFIX
from datetime import datetime
from typing import Optional, Tuple
import hashlib
import os
import re
import secrets as _secrets
import unicodedata

logger = logging.getLogger("payload-bot")

def sanitize_slug(name: str) -> str:
    """Convert a filename into a clean lowercase payload slug.

    Removes extensions, special characters, emoji and duplicate spaces, then
    lowercases and joins remaining tokens with underscores.
    """
    if not name:
        return ""
    name = os.path.splitext(name)[0]
    name = unicodedata.normalize("NFKD", name)
    # Drop emoji / anything that is not a word char, space or hyphen.
    name = re.sub(r"[^\w\s-]", "", name, flags=re.UNICODE).strip()
    name = re.sub(r"[\s\-]+", "_", name)
    name = re.sub(r"_+", "_", name)
    name = name.lower().strip("_")
    return name[:64]

def validate_payload(payload: str) -> bool:
    return bool(payload and PAYLOAD_PATTERN.match(payload.lower()))

def sanitize_payload_name(display_name: str) -> str:
    """V14: Sanitize a human-readable payload name into a valid internal slug.

    Allows the admin to type 'Brandy love' → stores 'brandy_love'.
    - Lowercases the input.
    - Replaces spaces and hyphens with underscores.
    - Strips invalid characters (keeps a-z, 0-9, _).
    - Ensures the result starts with a letter or digit.
    - Truncates to 64 chars.
    Returns the sanitized name, or "" if the input has no usable characters.
    """
    if not display_name:
        return ""
    # Lowercase + replace spaces/hyphens with underscores.
    s = display_name.lower().strip()
    s = s.replace(" ", "_").replace("-", "_")
    # Remove any character that isn't a-z, 0-9, or _.
    s = re.sub(r"[^a-z0-9_]", "", s)
    # Collapse multiple underscores into one.
    s = re.sub(r"_+", "_", s)
    # Strip leading/trailing underscores.
    s = s.strip("_")
    # Truncate to 64 chars.
    s = s[:64].strip("_")
    return s

def sanitize_display_name(text: str) -> str:
    """BOTV13: Sanitize a human-readable display name.

    Allows: spaces, mixed case, hyphens, digits, Unicode letters, punctuation.
    Strips: Markdown specials (` * [ ] _) so the name never breaks parse_mode.
    Rejects: control characters (they are removed, not escaped).
    Truncates to DISPLAY_NAME_MAX_LENGTH (128).
    Returns the cleaned name, or "" if the input has no usable characters.
    """
    if not text:
        return ""
    # Normalize Unicode (NFKC) so composed/decomposed forms are consistent.
    s = unicodedata.normalize("NFKC", text).strip()
    # Remove control characters entirely.
    s = _CONTROL_CHARS_RE.sub("", s)
    # Strip Markdown specials (they break parse_mode rendering).
    s = _MARKDOWN_SPECIALS_RE.sub("", s)
    # Collapse runs of whitespace into a single space.
    s = re.sub(r"\s+", " ", s).strip()
    # Truncate to max length.
    s = s[:DISPLAY_NAME_MAX_LENGTH].strip()
    return s

def validate_display_name(text: str) -> bool:
    """BOTV13: Validate a display name. Accepts human-readable names like
    'Kimmy Granger', 'Video 55', 'OnlyFans Pack', 'Summer Collection',
    'Scene #12'. Rejects: empty, control characters, or length > 128 after
    sanitization."""
    if not text:
        return False
    cleaned = sanitize_display_name(text)
    if not cleaned:
        return False
    if len(cleaned) > DISPLAY_NAME_MAX_LENGTH:
        return False
    if _CONTROL_CHARS_RE.search(text):
        return False
    return True

def get_payload_display_name(payload_slug: str, file_name: Optional[str] = None,
                             display_name: Optional[str] = None) -> str:
    """V16/BOTV13: THE single display-name resolver. Every UI must use this.

    BOTV13 priority:
      1. Stored `display_name` (if non-empty) — the editable human-readable title.
      2. Payload slug (Title-Cased) — fallback for legacy rows without display_name.
      3. Filename (stem) — fallback when slug is empty.
      4. 'Unknown Payload'.

    The stored payload name (routing slug) is NEVER changed — this is display-only.
    """
    # Priority 1: stored display_name (BOTV13).
    if display_name:
        cleaned = display_name.strip()
        if cleaned:
            return cleaned
    if payload_slug:
        # Replace underscores with spaces, then title-case each word.
        display = payload_slug.replace("_", " ").strip()
        if display:
            return " ".join(w[:1].upper() + w[1:] if w else w for w in display.split())
    if file_name:
        # Fall back to filename without extension.
        base = file_name.rsplit(".", 1)[0] if "." in file_name else file_name
        return base.replace("_", " ").strip() or file_name
    return "Unknown Payload"

def is_valid_date(date_str: str) -> bool:
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def hash_password(password: str) -> str:
    """Hash a password with SHA-256 + salt. Returns 'sha256:<hex_digest>'."""
    return "sha256:" + hashlib.sha256(
        (_PASSWORD_SALT + password).encode("utf-8")
    ).hexdigest()

def verify_password(password: str, stored: Optional[str]) -> bool:
    """Verify a password against the stored value.

    Handles both new hashed passwords ('sha256:...' prefix) and legacy
    plaintext passwords (no prefix — compared directly, then re-hashed).
    """
    if not stored:
        return False
    if stored.startswith("sha256:"):
        return hash_password(password) == stored
    # Legacy plaintext — compare directly, then caller should re-hash.
    return password == stored

def is_password_hashed(stored: Optional[str]) -> bool:
    """Check if a stored password is already hashed."""
    return stored is not None and stored.startswith("sha256:")

def is_msg_link(arg: str) -> bool:
    """True if a /start argument looks like an m-message link (e.g. 'm8619')."""
    return (len(arg) >= 2 and arg[0] == MSG_LINK_PREFIX
            and arg[1:].isdigit())

def parse_msg_link(arg: str) -> Optional[int]:
    """Extract the message_id from an 'm8619' style argument."""
    if is_msg_link(arg):
        return int(arg[1:])
    return None

def build_range_link(start_id: int, end_id: int) -> str:
    """Range delivery link: ?start=rSTART_END (e.g. r8619_8625)."""
    return build_start_link(f"{RANGE_LINK_PREFIX}{start_id}_{end_id}")

def is_range_link(arg: str) -> bool:
    """True if a /start argument looks like a range link (e.g. 'r8619_8625')."""
    if len(arg) < 4 or arg[0] != RANGE_LINK_PREFIX:
        return False
    body = arg[1:]
    if "_" not in body:
        return False
    left, right = body.split("_", 1)
    return left.isdigit() and right.isdigit()

def parse_range_link(arg: str) -> Optional[Tuple[int, int]]:
    """Extract (start_id, end_id) from an 'r8619_8625' style argument."""
    if not is_range_link(arg):
        return None
    left, right = arg[1:].split("_", 1)
    return int(left), int(right)

def generate_collection_code() -> str:
    """Generate a unique short collection code (e.g. '7f3a9b2c')."""
    return _secrets.token_hex(COLLECTION_CODE_LENGTH // 2)

def is_collection_link(arg: str) -> bool:
    """True if a /start argument looks like a collection link (e.g. 'c7f3a9b2')."""
    # Must start with 'c' prefix followed by at least 4 hex chars.
    if len(arg) < 5 or arg[0] != COLLECTION_LINK_PREFIX:
        return False
    body = arg[1:]
    return all(c in "0123456789abcdefABCDEF" for c in body)

def parse_collection_link(arg: str) -> Optional[str]:
    """Extract the collection code from a 'c7f3a9b2' style argument."""
    if not is_collection_link(arg):
        return None
    return arg[1:].lower()

def is_internal_id_ref(arg: str) -> bool:
    """V26 callback_data safety — is this a compact internal id reference
    ('i<numeric payload id>')? The reversible form used inside
    callback_data instead of raw routing slugs (a 64-char slug +
    'verify:'/'wadcheck:'/'retryfile:' prefixes exceeds Telegram's
    64-byte callback_data limit — the Button_data_invalid root cause,
    reproduced on production payload 787's 54-char slug)."""
    if not arg or arg[0] != "i" or len(arg) > 12:
        return False
    return arg[1:].isdigit()


def compact_callback_arg(arg: str, payload_id=None) -> str:
    """V26 callback_data safety — map a routing arg to its COMPACT,
    reversible callback form.

      * structurally short link forms (m<msg id>, c<code>, r<a>:<b>) pass
        through unchanged (byte-bounded by construction);
      * a NAMED payload slug (up to 64 chars — the Button_data_invalid
        risk) becomes 'i<payload_id>' when the payload row (id) is
        available — the compact reversible INTERNAL identifier;
      * otherwise the arg passes through and the caller-side guard /
        central validate_keyboard_markup tripwire (messaging.py) is the
        defense in depth.
    """
    if not arg:
        return arg or ""
    if is_msg_link(arg) or is_collection_link(arg) or is_range_link(arg):
        return arg
    if payload_id is not None:
        try:
            pid = int(payload_id)
        except (TypeError, ValueError):
            return arg
        if pid > 0:
            return f"i{pid}"
    return arg


_CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f-\x9f]")

_MARKDOWN_SPECIALS_RE = re.compile(r"[`*\[\]_]")

_PASSWORD_SALT = "payload_bot_v4_salt"


def make_payload_service(db, BOT_USERNAME=None, one_time_default=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    async def create_unique_payload(base_slug: str, index_id: int) -> Optional[str]:
        """Create a payload from a base slug, appending _2, _3 ... on collision.

        BOTV13 fix: the check-then-act (get_payload → create_payload) is a TOCTOU
        race — two concurrent index_message calls for different files with the same
        derived slug can both pass the existence check and both INSERT, causing
        `UNIQUE constraint failed: payloads.payload`. The INSERT is now wrapped in
        try/except IntegrityError; on collision, the slug is incremented and retried.
        """
        if not base_slug:
            return None
        slug = base_slug
        n = 2
        one_time = await one_time_default()
        while True:
            existing = await db.get_payload(slug)
            if not existing:
                try:
                    await db.create_payload(slug, index_id, status="active", one_time=one_time)
                    logger.info("Auto payload created: %s -> file #%d (one_time=%d)", slug, index_id, one_time)
                    return slug
                except Exception as e:  # noqa: BLE001
                    err_lower = str(e).lower()
                    if "unique constraint" in err_lower or "integrityerror" in err_lower:
                        # Lost the race — another coroutine inserted the same slug.
                        # Fall through to the collision-increment below.
                        logger.debug("Auto payload: slug collision on %s — retrying with suffix.", slug)
                    else:
                        logger.error("Auto payload: create failed for %s: %s", slug, e)
                        return None
            slug = f"{base_slug}_{n}"
            n += 1
            if n > 1000:
                logger.warning("Slug collision overflow for %s", base_slug)
                return None

    def build_start_link(payload: str) -> str:
        """Master helper for every deep link. Uses the auto-detected BOT_USERNAME
        so links stay correct even if the bot's username changes."""
        return f"https://t.me/{BOT_USERNAME}?start={payload}"

    def build_link(payload: str, display_name: Optional[str] = None) -> str:
        """Build a deep link for a named payload.

        BOTV13 Part 1: produces human-friendly links in the format
        ``<slugified_display_name>_<routing_id>`` when a display_name is available
        and its slug differs from the routing slug. Falls back to the bare
        ``?start=<routing_slug>`` for backward compat (old-style links where the
        slug IS the display-name-derived value, or when display_name is unknown).

        CRITICAL: Telegram's /start parameter has a 64-character limit. If the
        human-friendly link would exceed 64 chars, we fall back to the bare routing
        ID so the link always works. A truncated link loses the routing ID at the
        end and the payload can never be resolved.

        Routing uses ONLY the routing_id (the last ``_``-separated segment).
        The display-name portion is ignored by the parser — it exists purely for
        human readability and SEO. Multiple payloads can share the same display
        name because the routing_id is always unique.
        """
        if display_name:
            slug = sanitize_payload_name(display_name)
            if slug and slug != payload:
                # New format: <slugified_display_name>_<routing_id>
                friendly = f"{slug}_{payload}"
                # Telegram's /start parameter is limited to 64 characters.
                # If the human-friendly link exceeds this, fall back to the bare
                # routing ID so the link always works (a truncated link loses the
                # routing ID at the end and the payload can never be resolved).
                if len(friendly) <= 64:
                    return build_start_link(friendly)
                # Display name too long — fall back to bare routing ID.
                logger.info("build_link: human-friendly link too long (%d chars > 64) — using bare routing_id %s",
                            len(friendly), payload)
        # Old format: just the routing slug (backward compat).
        return build_start_link(payload.lower())

    def build_collection_link(collection_id: str,
                              display_name: Optional[str] = None) -> str:
        """Build a deep link for an explicit collection.

        BOTV13 Part 1: when display_name is available, produces
        ``<slugified_display_name>_c<code>``. Falls back to ``c<code>`` for
        backward compat. The parser extracts ``c<code>`` from the end.

        CRITICAL: Telegram's /start parameter has a 64-character limit. If the
        human-friendly link would exceed 64 chars, fall back to the bare ``c<code>``.
        """
        routing_id = f"{COLLECTION_LINK_PREFIX}{collection_id}"
        if display_name:
            slug = sanitize_payload_name(display_name)
            if slug:
                friendly = f"{slug}_{routing_id}"
                if len(friendly) <= 64:
                    return build_start_link(friendly)
                logger.info("build_collection_link: human-friendly link too long (%d chars > 64) — using bare %s",
                            len(friendly), routing_id)
        return build_start_link(routing_id)

    return SimpleNamespace(
        create_unique_payload=create_unique_payload,
        build_start_link=build_start_link,
        build_link=build_link,
        build_collection_link=build_collection_link,
    )
