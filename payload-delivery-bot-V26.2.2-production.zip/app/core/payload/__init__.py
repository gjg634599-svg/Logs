"""Payload domain service."""
