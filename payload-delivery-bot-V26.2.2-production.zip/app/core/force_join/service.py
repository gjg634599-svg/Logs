"""Force Join domain service: the tri-state membership engine, the
stable active-batch state machine and the authoritative access
view used by the Access Engine."""
from __future__ import annotations

from enum import Enum
import hashlib
import re

import logging
from types import SimpleNamespace

from app.core.constants import FJ_BATCH_SIZE_DEFAULT
from app.core.constants import FJ_MODE_DEFAULT
from app.core.constants import FJ_MODE_FIXED_ORDER
from app.core.constants import FJ_MODE_PROGRESSIVE_RANDOM
from app.core.constants import FJ_MODE_SHOW_ALL
from app.core.constants import JOIN_REQUEST_POLICY_REQUEST
from app.core.constants import JOIN_REQUEST_TTL
from app.core.dbutil import now_iso as _now_iso
# ARCHITECTURE PROPER BREAKDOWN (RULE C): this domain service imports NO
# Telegram framework classes. The Telegram membership/error classification
# port (``telegram_types``) is injected by the composition (the presentation
# runtime namespace carries the classes) — ``classify_member_error`` /
# ``member_status_is`` below provide the pure-Python fallback used when the
# port is not supplied (tests constructing the service directly).
from typing import Any, List, Optional, Set, Tuple
import aiosqlite
import json
import json as _json
import random as _random
import time

logger = logging.getLogger("payload-bot")

class MemberCheckResult(Enum):
    """Authoritative membership classification.

    is_joined() is True only for MEMBER / ADMINISTRATOR / CREATOR (and
    RESTRICTED, which Telegram treats as still-in-chat). Every error path is
    a distinct non-joined category so callers never confuse "bot can't see
    the member list" with "user genuinely hasn't joined".
    """
    MEMBER = "member"
    ADMINISTRATOR = "administrator"
    CREATOR = "creator"
    NOT_MEMBER = "not_member"                       # user genuinely not joined / left / banned
    REQUEST_PENDING = "request_pending"             # join request submitted, awaiting approval
    BOT_NOT_ADMIN = "bot_not_admin"                 # Forbidden / "Member list is inaccessible"
    CHANNEL_NOT_FOUND = "channel_not_found"         # BadRequest "Chat not found"
    PRIVATE_CHANNEL_UNAVAILABLE = "private_unavailable"  # private chat not accessible
    TELEGRAM_ERROR = "telegram_error"               # any other transient API error

    def is_joined(self) -> bool:
        return self in (MemberCheckResult.MEMBER, MemberCheckResult.ADMINISTRATOR,
                        MemberCheckResult.CREATOR)

    @property
    def is_bot_fault(self) -> bool:
        """True when the failure is the BOT's/config's fault, NOT the user's.
        Callers MUST NOT blame the user for these — they get a diagnostic."""
        return self in (MemberCheckResult.BOT_NOT_ADMIN,
                        MemberCheckResult.CHANNEL_NOT_FOUND,
                        MemberCheckResult.PRIVATE_CHANNEL_UNAVAILABLE,
                        MemberCheckResult.TELEGRAM_ERROR)

class ChannelAccessStatus(Enum):
    """PHASE 6 §8/§9: authoritative force-join channel ACCESS classification.

    A TRANSIENT result (Telegram flood control / timeout / network) must
    NEVER be treated as an invalid channel and NEVER be shown to a user as
    'you haven't joined'. Only the INVALID_* results are confirmed
    configuration problems; UNKNOWN is neither valid nor invalid.
    """
    VALID = "valid"                              # get_chat succeeded
    TRANSIENT_ERROR = "transient_error"          # RetryAfter / Network / Timeout
    INVALID_NOT_FOUND = "invalid_not_found"      # BadRequest "Chat not found"
    INVALID_FORBIDDEN = "invalid_forbidden"      # bot removed / no access
    INVALID_BAD_REQUEST = "invalid_bad_request"  # other confirmed BadRequest
    UNKNOWN = "unknown"                          # other TelegramError — unverified

    @property
    def is_invalid(self) -> bool:
        """True ONLY for confirmed permanent configuration problems."""
        return self in (ChannelAccessStatus.INVALID_NOT_FOUND,
                        ChannelAccessStatus.INVALID_FORBIDDEN,
                        ChannelAccessStatus.INVALID_BAD_REQUEST)

    @property
    def is_transient(self) -> bool:
        """True when the check itself failed temporarily (rate limit etc.)."""
        return self in (ChannelAccessStatus.TRANSIENT_ERROR,
                        ChannelAccessStatus.UNKNOWN)


def make_force_join_service(db, ENABLE_FORCE_JOIN=None, get_join_request_policy=None, _consume_join_request=None, _has_pending_join_request=None, _prune_join_requests=None, PENDING_JOIN_REQUESTS=None, telegram_types=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals).

    ``telegram_types`` is the Telegram classification PORT (RULE C): the
    composition injects the framework's error classes + ChatMemberStatus;
    without it, classification falls back to exception-name matching and
    the Bot-API status literals (pure Python, no framework import).
    """

    def _is_cls(exc: BaseException, name: str) -> bool:
        cls = None
        if telegram_types is not None:
            cls = getattr(telegram_types, name, None)
        if cls is not None:
            return isinstance(exc, cls)
        return type(exc).__name__ == name

    def _is_telegram_error(exc: BaseException) -> bool:
        return any(_is_cls(exc, n) for n in (
            "Forbidden", "BadRequest", "NetworkError", "RetryAfter",
            "TelegramError", "TimedOut"))

    _STATUS_LITERALS = {
        "OWNER": "creator", "ADMINISTRATOR": "administrator",
        "MEMBER": "member", "RESTRICTED": "restricted",
        "LEFT": "left", "BANNED": "kicked",
    }

    def _status_is(status, name: str) -> bool:
        st = None
        if telegram_types is not None:
            st = getattr(telegram_types, "ChatMemberStatus", None)
        if st is not None and hasattr(st, name):
            return status == getattr(st, name)
        return status == _STATUS_LITERALS[name]

    async def check_membership(bot, user_id: int, channel_id: int) -> MemberCheckResult:
        """Authoritative live Telegram membership check.

        ALWAYS performs a fresh get_chat_member call — never cached, never trusts
        stale state. Every Telegram API failure is classified into a distinct
        MemberCheckResult so the caller can render the correct UX:
          * USER_NOT_MEMBER  -> show Join button + "🔒 Not joined"
          * BOT_NOT_ADMIN    -> show admin diagnostic, do NOT blame the user
          * CHANNEL_NOT_FOUND -> admin diagnostic (channel misconfigured)
          * TELEGRAM_ERROR   -> friendly retry message
        """
        if bot is None:
            logger.warning("BOT6_FJ_CHECK result=BOT_NOT_ADMIN channel_id=%s user_id=%s "
                           "error=bot_is_None", channel_id, user_id)
            return MemberCheckResult.BOT_NOT_ADMIN
        try:
            member = await bot.get_chat_member(channel_id, user_id)
        except Exception as e:  # noqa: BLE001 — classified below; non-Telegram re-raised
            if _is_cls(e, "Forbidden"):
                logger.warning("BOT6_FJ_CHECK result=BOT_NOT_ADMIN channel_id=%s user_id=%s "
                               "error=Forbidden", channel_id, user_id)
                return MemberCheckResult.BOT_NOT_ADMIN
            if _is_cls(e, "BadRequest"):
                err_lower = str(e).lower()
                if "member list is inaccessible" in err_lower or "not enough rights" in err_lower:
                    logger.warning("BOT6_FJ_CHECK result=BOT_NOT_ADMIN channel_id=%s user_id=%s "
                                   "error='Member list is inaccessible'", channel_id, user_id)
                    return MemberCheckResult.BOT_NOT_ADMIN
                if "not found" in err_lower or "chat not found" in err_lower:
                    logger.warning("BOT6_FJ_CHECK result=CHANNEL_NOT_FOUND channel_id=%s user_id=%s "
                                   "error='Chat not found'", channel_id, user_id)
                    return MemberCheckResult.CHANNEL_NOT_FOUND
                if "private" in err_lower and "not accessible" in err_lower:
                    logger.warning("BOT6_FJ_CHECK result=PRIVATE_CHANNEL_UNAVAILABLE "
                                   "channel_id=%s user_id=%s error='%s'", channel_id, user_id, e)
                    return MemberCheckResult.PRIVATE_CHANNEL_UNAVAILABLE
                logger.warning("BOT6_FJ_CHECK result=NOT_MEMBER channel_id=%s user_id=%s "
                               "error='%s'", channel_id, user_id, e)
                return MemberCheckResult.NOT_MEMBER
            if _is_cls(e, "NetworkError") or _is_cls(e, "TimedOut"):
                logger.warning("BOT6_FJ_CHECK result=TELEGRAM_ERROR channel_id=%s user_id=%s "
                               "error=%s", channel_id, user_id, e)
                return MemberCheckResult.TELEGRAM_ERROR
            if _is_cls(e, "TelegramError"):
                logger.warning("BOT6_FJ_CHECK result=TELEGRAM_ERROR channel_id=%s user_id=%s "
                               "error=%s", channel_id, user_id, e)
                return MemberCheckResult.TELEGRAM_ERROR
            raise  # not a Telegram error — original behavior (propagate)

        status = member.status
        if _status_is(status, "OWNER"):
            logger.info("BOT6_FJ_CHECK result=CREATOR channel_id=%s user_id=%s", channel_id, user_id)
            return MemberCheckResult.CREATOR
        if _status_is(status, "ADMINISTRATOR"):
            logger.info("BOT6_FJ_CHECK result=ADMINISTRATOR channel_id=%s user_id=%s", channel_id, user_id)
            return MemberCheckResult.ADMINISTRATOR
        if _status_is(status, "MEMBER"):
            logger.info("BOT6_FJ_CHECK result=MEMBER channel_id=%s user_id=%s", channel_id, user_id)
            return MemberCheckResult.MEMBER
        if _status_is(status, "RESTRICTED"):
            # Restricted users are still in the chat (just muted/limited).
            logger.info("BOT6_FJ_CHECK result=MEMBER channel_id=%s user_id=%s (restricted)",
                         channel_id, user_id)
            return MemberCheckResult.MEMBER
        # LEFT / BANNED / anything else -> genuinely not a member.
        # Request-to-Join handling: pending request may grant access under the
        # 'request' policy (issue 7). 'approval' policy requires actual approval,
        # so the user sees a REQUEST_PENDING state (not NOT_MEMBER, not MEMBER).
        if _has_pending_join_request(user_id, channel_id):
            policy = await get_join_request_policy()
            if policy == JOIN_REQUEST_POLICY_REQUEST:
                logger.info("BOT6_FJ_CHECK result=MEMBER channel_id=%s user_id=%s "
                             "(pending request, policy=request)", channel_id, user_id)
                return MemberCheckResult.MEMBER
            else:
                # Approval policy: request submitted but not yet approved.
                logger.info("BOT6_FJ_CHECK result=REQUEST_PENDING channel_id=%s user_id=%s "
                             "(pending request, policy=approval)", channel_id, user_id)
                return MemberCheckResult.REQUEST_PENDING
        logger.info("BOT6_FJ_CHECK result=NOT_MEMBER channel_id=%s user_id=%s status=%s",
                     channel_id, user_id, status)
        return MemberCheckResult.NOT_MEMBER

    async def is_member(bot, user_id: int, channel_id: int) -> bool:
        """Bool wrapper around check_membership for legacy callers.
        Returns True only for MEMBER / ADMINISTRATOR / CREATOR (joined states).
        Every error/verification-failure returns False (FAIL-CLOSED) so an
        invalid/broken channel never silently grants access.
        """
        result = await check_membership(bot, user_id, channel_id)
        return result.is_joined()

    async def get_pending_channel_for_user(bot, user_id: int) -> Optional[Tuple[int, str]]:
        """If the user has pending join requests but is not yet a member, return
        (channel_id, status_message) for the first such channel.

        Used to show the proper pending message:
          - policy=request: should not happen (request grants access)
          - policy=approval: "Your join request is awaiting approval."
        Returns None if no pending channels.
        """
        _prune_join_requests()
        for (uid, cid), ts in list(PENDING_JOIN_REQUESTS.items()):
            if uid != user_id:
                continue
            if time.time() - ts > JOIN_REQUEST_TTL:
                continue
            # Check if user is now an actual member (approved).
            try:
                member = await bot.get_chat_member(cid, user_id)
                if any(_status_is(member.status, n) for n in
                       ("MEMBER", "ADMINISTRATOR", "OWNER")):
                    # Approved! Consume the request.
                    _consume_join_request(user_id, cid)
                    continue
            except Exception as e:  # noqa: BLE001 — only Telegram errors swallowed
                if not _is_telegram_error(e):
                    raise
            # Still pending.
            ch = await db.get_force_channel(cid)
            label = _force_channel_label(ch) if ch else f"channel {cid}"
            return cid, label
        return None

    async def unjoined_channels(bot, user_id: int) -> List[aiosqlite.Row]:
        """Return force-join channels the user has NOT joined (or has no valid
        pending request for under approval policy)."""
        channels = await db.list_force_channels()
        not_joined: List[aiosqlite.Row] = []
        for ch in channels:
            if not await is_member(bot, user_id, ch["channel_id"]):
                not_joined.append(ch)
        return not_joined

    def _force_channel_label(ch: aiosqlite.Row) -> str:
        """Safe label — never crashes on missing columns.

        Issue 37 Critical Fix: uses .get() with fallbacks instead of ch["col"]
        which raises IndexError if the column doesn't exist (e.g. 'username'
        is not a column in force_join_channels).
        """
        title = ch["title"] if "title" in ch.keys() else None
        name = ch["channel_name"] if "channel_name" in ch.keys() else None
        cid = ch["channel_id"] if "channel_id" in ch.keys() else "?"
        return title or name or f"Channel {cid}"

    def _fj_requirement_identity(mode: str, batch_size: int,
                                 all_channels: List[aiosqlite.Row]) -> str:
        """V26: the 12-hex fingerprint of the CURRENT force-join REQUIREMENT
        configuration — (mode, batch_size, the sorted channel-id set).

        The identity is what makes the requirement state authoritative for
        (user_id, payload_id, force_join_requirement_identity): when the
        admin changes ANY component, the identity changes and the service
        deterministically starts the appropriate NEW requirement state
        (presentation re-derivation) — while the LIVE Telegram membership
        checks remain the sole AUTHORIZATION authority (a config change can
        never fabricate or destroy completion). Safe to log (no secrets;
        channel ids are configuration, not credentials)."""
        ids = sorted(int(ch["channel_id"]) for ch in (all_channels or []))
        raw = f"{mode}|{int(batch_size)}|{','.join(str(i) for i in ids)}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]

    async def classify_channel_access(bot, channel_id: int) -> ChannelAccessStatus:
        """PHASE 6 §8/§9: classify whether the bot can access a force-join channel.

        RetryAfter (flood control) IS a TelegramError subclass and MUST be
        caught BEFORE the generic TelegramError handler — the production log
        (bot.log 20 @ 06:01:09-10) shows all 9 channels hitting flood control
        at startup and then being declared 'Invalid force-join channel(s)'.
        That false positive is impossible now: TRANSIENT/UNKNOWN are never
        invalid.
        """
        if bot is None:
            logger.warning("FORCE_JOIN_TRANSIENT_ERROR channel_id=%s "
                           "error=bot_is_None (unverified)", channel_id)
            return ChannelAccessStatus.UNKNOWN
        try:
            await bot.get_chat(channel_id)
            return ChannelAccessStatus.VALID
        except Exception as e:  # noqa: BLE001 — classified below; non-Telegram re-raised
            if _is_cls(e, "RetryAfter"):
                logger.warning("FORCE_JOIN_TRANSIENT_ERROR channel_id=%s error=RetryAfter "
                               "retry_after=%ss (NOT marked invalid)",
                               channel_id, getattr(e, "retry_after", "?"))
                return ChannelAccessStatus.TRANSIENT_ERROR
            if _is_cls(e, "BadRequest"):
                err_lower = str(e).lower()
                if "not found" in err_lower or "chat not found" in err_lower:
                    # PHASE 8 §11: the raw 'INVALID (Chat not found)' warning that
                    # repeated on every startup (bot.log 22 @ 03:23+03:25) is demoted
                    # to debug — the structured FORCE_JOIN_LINK_HEALTH state-change
                    # line + the FORCE_JOIN_STARTUP_HEALTH aggregate are the
                    # authoritative, non-spammy signals now.
                    logger.debug("ForceJoin: channel %s INVALID (Chat not found)",
                                 channel_id)
                    return ChannelAccessStatus.INVALID_NOT_FOUND
                logger.debug("ForceJoin: channel %s INVALID (BadRequest: %s)",
                             channel_id, e)
                return ChannelAccessStatus.INVALID_BAD_REQUEST
            if _is_cls(e, "Forbidden"):
                logger.debug("ForceJoin: channel %s INVALID (bot removed/no access)",
                             channel_id)
                return ChannelAccessStatus.INVALID_FORBIDDEN
            if _is_cls(e, "NetworkError") or _is_cls(e, "TimedOut"):
                logger.warning("FORCE_JOIN_TRANSIENT_ERROR channel_id=%s error=%s "
                               "(NOT marked invalid)", channel_id, type(e).__name__)
                return ChannelAccessStatus.TRANSIENT_ERROR
            if _is_cls(e, "TelegramError"):
                # Any other Telegram error (rare for get_chat) — unverified, NOT
                # invalid: a temporary API failure must never become a permanent
                # configuration verdict.
                logger.warning("FORCE_JOIN_TRANSIENT_ERROR channel_id=%s error=%s "
                               "(unverified, NOT marked invalid)",
                               channel_id, type(e).__name__)
                return ChannelAccessStatus.UNKNOWN
            raise  # not a Telegram error — original behavior (propagate)

    async def _check_force_channel_valid(bot, channel_id: int) -> Optional[bool]:
        """Issue 37 + PHASE 6 §9: is a force-join channel still accessible?

        Tri-state result:
          True  — channel accessible (VALID)
          False — CONFIRMED invalid (deleted / bot removed / wrong ID)
          None  — could not verify RIGHT NOW (flood control / timeout / network).
                  Callers MUST NOT treat None as invalid and MUST NOT blame the
                  user for it. The channel is never permanently marked invalid
                  on a transient error.
        """
        status = await classify_channel_access(bot, channel_id)
        if status == ChannelAccessStatus.VALID:
            return True
        if status.is_invalid:
            return False
        return None

    def _channel_validity_label(valid: Optional[bool]) -> str:
        """Human-readable three-state label for admin panels."""
        if valid is True:
            return "\U0001F7E2 Accessible"
        if valid is False:
            return "\u274C Invalid"
        return "\u26A0\uFE0F Unverified (Telegram rate limit — try again)"

    async def _get_fj_progress(user_id: int, payload_code: str = "") -> Optional[aiosqlite.Row]:
        """Get the per-USER force-join progress row.

        BOTV13 fix (PART 6): Force Join progress is per-user, NOT per-payload.
        A user who joined channels for Payload A must NOT have to rejoin for
        Payload B. We query by user_id only and return the most recent row.
        The payload_code parameter is kept for signature compat but ignored.
        """
        return await db.get_fj_progress_row(user_id)

    async def _get_or_init_fj_progress(user_id: int, payload_code: str = "",
                                        all_channels: List[aiosqlite.Row] = None) -> aiosqlite.Row:
        """Get or create the fj_progress row (per-USER, not per-payload).

        BOTV13 fix (PART 6): progress is keyed on user_id only. The payload_code
        is stored as '' (global) so the UNIQUE(user_id, payload_code) constraint
        creates a single row per user. For progressive_random mode, shuffles the
        channel order ONCE and persists it so the same order is used across all
        payload visits.

        BOTV13 Phase A (v23): also initializes active_batch/completed_batches/
        batch_cursor to safe defaults. The active_batch is created LAZILY by
        _get_fj_batch (not here) so the first batch reflects the current channel
        set at the moment of first need.

        V26 (v44): the row is created WITH the current requirement_identity
        (mode|batch_size|sorted channel ids) — the (user_id, payload_id,
        force_join_requirement_identity) state contract. Legacy rows adopt the
        identity on first read WITHOUT any other change (see
        _apply_requirement_identity).
        """
        if all_channels is None:
            all_channels = await db.list_force_channels()
        row = await _get_fj_progress(user_id)
        if row:
            return row
        mode = await get_fj_mode()
        chan_ids = [int(ch["channel_id"]) for ch in all_channels]
        if mode == FJ_MODE_PROGRESSIVE_RANDOM:
            import random
            random.shuffle(chan_ids)
        now = _now_iso()
        import json as _json
        identity = _fj_requirement_identity(
            mode, await get_fj_batch_size(), all_channels)
        # Use payload_code='' so the UNIQUE(user_id, payload_code) creates ONE
        # global row per user (not per-payload). active_batch=NULL (created lazily
        # by _get_fj_batch on first need).
        await db.insert_global_fj_progress(
            user_id, _json.dumps(chan_ids), now, requirement_identity=identity)
        return await db.get_fj_progress_row(user_id)

    async def _apply_requirement_identity(
            user_id: int, mode: str, batch_size: int,
            all_channels: List[aiosqlite.Row],
            progress: Optional[aiosqlite.Row]) -> Optional[aiosqlite.Row]:
        """V26 requirement-identity handling — the deterministic bridge between
        the admin's configuration changes and the user's requirement state.

        The state row's authority tuple is (user_id, payload_id,
        force_join_requirement_identity): the identity fingerprints the CURRENT
        requirement (mode|batch_size|sorted channel ids). Three cases:

          * stored == current  -> no change (the common path — progress
            survives refresh / reconnect / process restart / repeated
            verification / opening another payload / returning to the same
            payload, because nothing about the requirement changed);

          * stored is NULL     -> LEGACY row (pre-v44): ADOPT the current
            identity and change NOTHING else (legacy production progress
            survives byte-identically);

          * stored != current  -> the requirement CHANGED. Deterministically
            start the appropriate NEW requirement state — the PRESENTATION
            state is re-derived (fresh order per the new mode semantics /
            retained-order + appended channels on channel-set changes,
            active_batch cleared, cursor reset, completed_batches kept for
            retained channels) while the LIVE Telegram membership checks
            remain the sole AUTHORIZATION authority:
              - retained channels retain completion (live membership is
                unchanged by a config edit);
              - newly added channels become new work (they are in the new
                order and live-checked);
              - removed channels do not resurrect (excluded from the new
                order AND from kept completed_batches);
              - a mode change to progressive_random generates the NEW
                requirement's one-time order (never reshuffled on mere
                refresh/reopen — only on a genuine identity change).
        """
        current = _fj_requirement_identity(mode, batch_size, all_channels)
        stored = None
        if progress is not None and "requirement_identity" in progress.keys():
            stored = progress["requirement_identity"]
        if stored == current:
            return progress
        if stored is None:
            # Legacy pre-v44 row: adopt the identity, keep every other column.
            await _persist_fj_progress(user_id, requirement_identity=current)
            logger.info(
                "FJ_STATE user_id=%s identity=%s change=legacy_adopt mode=%s "
                "batch_size=%s channels=%s (legacy row adopted the current "
                "requirement identity; progress untouched)",
                user_id, current, mode, batch_size,
                [int(ch["channel_id"]) for ch in all_channels])
            return await db.get_fj_progress_row(user_id)
        # The requirement CHANGED — deterministic presentation re-derivation.
        stored_order = [int(x) for x in _parse_json_list(
            progress["channel_order"] if progress is not None
            and "channel_order" in progress.keys() else None, [])]
        current_ids = [int(ch["channel_id"]) for ch in all_channels]
        current_set = set(current_ids)
        retained = [cid for cid in stored_order if cid in current_set]
        appended = [cid for cid in current_ids if cid not in set(stored_order)]
        set_changed = bool(appended) or len(retained) != len(stored_order)
        if mode == FJ_MODE_PROGRESSIVE_RANDOM and not set_changed:
            # A mode/batch-size change under progressive_random: the NEW
            # requirement's one-time order (generated once, persisted,
            # never reshuffled on refresh/reopen).
            new_order = list(current_ids)
            _random.shuffle(new_order)
        else:
            # Channel-set change (or fixed/show_all mode): retain the stored
            # order for retained channels and append the new ones at the END
            # (existing batches stay stable — the reconcile semantics).
            new_order = retained + appended
        kept_completed = []
        for b in _parse_json_list_of_lists(
                progress["completed_batches"] if progress is not None
                and "completed_batches" in progress.keys() else None, []):
            kept = [cid for cid in b if cid in current_set]
            if kept:
                kept_completed.append(kept)
        await _persist_fj_progress(
            user_id, order=new_order, active_batch=[], cursor=0,
            completed_batches=kept_completed,
            requirement_identity=current)
        logger.info(
            "FJ_STATE user_id=%s identity_old=%s identity_new=%s "
            "change=requirement_changed mode=%s batch_size=%s order=%s "
            "completed_batches=%s (presentation state re-derived; live "
            "membership stays the sole authorization authority — channels "
            "the user already joined are never re-asked)",
            user_id, stored, current, mode, batch_size, new_order,
            kept_completed)
        return await db.get_fj_progress_row(user_id)

    def _parse_json_list(raw, default):
        """Safely parse a JSON list column. Returns `default` on any error."""
        if not raw:
            return list(default)
        try:
            import json as _json
            data = _json.loads(raw)
            if isinstance(data, list):
                return data
            return list(default)
        except (ValueError, TypeError):
            return list(default)

    def _parse_json_list_of_lists(raw, default):
        """Safely parse a JSON list-of-lists column (completed_batches)."""
        if not raw:
            return list(default)
        try:
            import json as _json
            data = _json.loads(raw)
            if isinstance(data, list):
                out = []
                for sub in data:
                    if isinstance(sub, list):
                        out.append([int(x) for x in sub])
                return out
            return list(default)
        except (ValueError, TypeError):
            return list(default)

    async def _reconcile_fj_channel_order(progress: aiosqlite.Row,
                                          all_channels: List[aiosqlite.Row]) -> tuple:
        """Reconcile stored channel_order with the current channel set.

        Handles admin add/remove of channels AFTER progress was created:
          - removes deleted channels from order/presented/active_batch/completed_batches
          - appends new channels to the END of the order (so existing batches stay stable)
        Returns (order, presented, active_batch_ids, completed_batches, cursor, changed).
        `changed` is True if any persistence is needed.
        """
        import json as _json
        order: List[int] = [int(x) for x in _parse_json_list(progress["channel_order"], [])]
        presented: List[int] = [int(x) for x in _parse_json_list(progress["presented"], [])]
        active_batch_ids: List[int] = [int(x) for x in _parse_json_list(progress["active_batch"], [])] if "active_batch" in progress.keys() else []
        completed_batches = _parse_json_list_of_lists(progress["completed_batches"] if "completed_batches" in progress.keys() else None, [])
        cursor = int(progress["batch_cursor"]) if "batch_cursor" in progress.keys() and progress["batch_cursor"] is not None else 0

        current_ids = {int(ch["channel_id"]) for ch in all_channels}
        changed = False

        # 1. Remove deleted channels from order.
        new_order = [cid for cid in order if cid in current_ids]
        if len(new_order) != len(order):
            order = new_order
            changed = True
        # 2. Remove deleted channels from presented (legacy).
        new_presented = [cid for cid in presented if cid in current_ids]
        if len(new_presented) != len(presented):
            presented = new_presented
            changed = True
        # 3. Remove deleted channels from active_batch.
        new_active = [cid for cid in active_batch_ids if cid in current_ids]
        if len(new_active) != len(active_batch_ids):
            active_batch_ids = new_active
            changed = True
        # 4. Remove deleted channels from completed_batches (and flatten empties).
        new_completed = []
        for batch in completed_batches:
            kept = [cid for cid in batch if cid in current_ids]
            if kept != batch:
                changed = True
            if kept:
                new_completed.append(kept)
        if new_completed != completed_batches:
            completed_batches = new_completed
            changed = True
        # 4b. V25 §2.1 (bot-34.log persistence hygiene): normalize LEGACY
        # dirty state — exact-duplicate batch entries (the pre-dedupe
        # production build accumulated e.g. 12 entries with the same
        # slice repeated 5x) are collapsed preserving first-occurrence
        # order, and the list is capped at the most recent 20 (the same
        # bounds the completion path enforces). The list is diagnostics/
        # history ONLY (authorization is the live membership checks), so
        # this cleanup is safe — and it lazily repairs every legacy row
        # on the next read+persist cycle.
        deduped_completed = []
        _seen_batches = set()
        for batch in completed_batches:
            _key = tuple(int(x) for x in batch)
            if _key in _seen_batches:
                continue
            _seen_batches.add(_key)
            deduped_completed.append(batch)
        if len(deduped_completed) > 20:
            deduped_completed = deduped_completed[-20:]
        if deduped_completed != completed_batches:
            completed_batches = deduped_completed
            changed = True
        # 5. Append new channels to the END of order (existing batches stay stable).
        ordered_set = set(order)
        for cid in current_ids:
            if cid not in ordered_set:
                order.append(cid)
                ordered_set.add(cid)
                changed = True
        # 6. Clamp cursor into valid range (channels may have been removed).
        if cursor > len(order):
            cursor = len(order)
            changed = True
        return order, presented, active_batch_ids, completed_batches, cursor, changed

    async def _persist_fj_progress(user_id: int, *,
                                    order: Optional[List[int]] = None,
                                    presented: Optional[List[int]] = None,
                                    active_batch: Optional[List[int]] = None,
                                    completed_batches: Optional[List[List[int]]] = None,
                                    cursor: Optional[int] = None,
                                    unlocked_payload_ids: Optional[List[int]] = None,
                                    requirement_identity: Optional[str] = None) -> None:
        """Persist (subset of) FJ progress fields for the user's global row.

        Only fields passed (not None) are updated. `active_batch=None` sets it to
        SQL NULL (no active batch / batch complete). Pass a list (incl. []) to
        store a JSON array. V26: requirement_identity updates the requirement
        fingerprint (None = leave unchanged).
        """
        import json as _json
        # RULE E: the SQL lives in the storage repository
        # (update_fj_progress_columns); this service only builds the
        # (column, value) assignments.
        assignments: List[Any] = []
        if order is not None:
            assignments.append(("channel_order", _json.dumps([int(x) for x in order])))
        if presented is not None:
            assignments.append(("presented", _json.dumps([int(x) for x in presented])))
        if active_batch is not None:
            assignments.append(("active_batch", _json.dumps([int(x) for x in active_batch])))
        if completed_batches is not None:
            assignments.append(("completed_batches",
                                _json.dumps([[int(x) for x in b] for b in completed_batches])))
        if cursor is not None:
            assignments.append(("batch_cursor", int(cursor)))
        if unlocked_payload_ids is not None:
            assignments.append(("unlocked_payload_ids",
                                _json.dumps([int(x) for x in unlocked_payload_ids])))
        if requirement_identity is not None:
            assignments.append(("requirement_identity", str(requirement_identity)))
        await db.update_fj_progress_columns(user_id, assignments)

    async def _get_active_fj_batch_ids(user_id: int) -> List[int]:
        """Return the channel IDs of the user's CURRENT active batch (may be empty).

        BOTV13 Phase A: the active batch is PERSISTED and stable. It only changes
        when ALL channels in it are joined (then it's cleared and the next batch is
        created). Never recalculated from the unjoined set.
        """
        progress = await _get_fj_progress(user_id)
        if not progress:
            return []
        if "active_batch" not in progress.keys():
            return []
        return [int(x) for x in _parse_json_list(progress["active_batch"], [])]

    async def _get_active_fj_batch_channels(user_id: int) -> List[aiosqlite.Row]:
        """Return the channel ROWS in the user's current active batch.

        Used by access_engine (only the active batch gates the current payload)
        and by the force-join page renderer (show the stable batch).
        """
        active_ids = await _get_active_fj_batch_ids(user_id)
        if not active_ids:
            return []
        all_channels = await db.list_force_channels()
        chan_map = {int(ch["channel_id"]): ch for ch in all_channels}
        return [chan_map[cid] for cid in active_ids if cid in chan_map]

    async def _get_fj_batch(user_id: int, payload_code: str,
                             *, for_access: bool = False,
                             access_payload_id: Optional[int] = None,
                             bot=None) -> List[aiosqlite.Row]:
        """Return the STABLE ACTIVE BATCH of channels to show / require.

        BOT5: accepts explicit `bot` parameter for ALL membership checks.
        NO _bot_ref fallback — if bot is None, fail-closed (return all channels
        as unjoined, which blocks access safely).

        BOT6 STABLE ACTIVE BATCH STATE MACHINE + V25 §9.3/§9.5 FULL-
        REQUIREMENT VERDICT:

          USER FJ STATE
              ↓
          Does the user have an active batch?
              ↓ (NO)
          for ACCESS: live-check EVERY configured channel; create the next
          batch (first batch_size un-joined, in the PERSISTED order) only
          when some are genuinely un-joined.
              ↓ (YES)
          Always use the PERSISTED active batch
              ↓
          Check live Telegram membership for channels IN THAT BATCH
              ↓
          If some are unjoined → keep showing the SAME active batch
              ↓
          If ALL channels in active batch are joined → mark batch complete,
          advance cursor, clear active_batch — then RE-EVALUATE the FULL
          requirement: if required channels remain un-joined, the NEXT batch
          is presented (never full access on partial completion, §9.5);
          only when the requirement is fully satisfied is the access ALLOW
          (COMPLETE, §9.3) and the payload recorded in unlocked_payload_ids
          (an honest history record — authorization NEVER reads it).

        The active batch is NEVER replaced just because some of its channels were
        joined. It stays stable until ALL of its channels are completed.

        V25 §9 (Force-Join completion persistence — the reported production
        regression): the authorization verdict is ALWAYS derived from the
        LIVE verified memberships of the CURRENT configured channels, so it
        is —
          * stable across payload re-clicks / refresh / browser reopen /
            navigation (same live state → same verdict, no new batch when
            the requirement is satisfied);
          * NOT reset by dashboard-user edits (fj_progress is keyed on the
            canonical Telegram user_id which the user record never changes);
          * recalculated on membership removal (only the genuinely missing
            requirement is presented, §9.6);
          * recalculated on configuration change (a newly added required
            channel is enforced; a removed channel drops out, §9.7).
        The old BOTV13 per-payload "unlocked fast-path" (future batches must
        NOT block the current payload) granted PERMANENT access after a
        single batch completed — violating §9.3 (COMPLETE requires all
        batches), §9.5 (no full access on partial completion), §9.6 (it
        bypassed membership removal) and §9.7 Case B (it bypassed newly
        added channels). It is REMOVED: unlocked_payload_ids is now a
        diagnostics-only completion record, never an authorization source.

        `for_access=True` (called from _unjoined_for_access): used for authorization.
        `for_access=False` (called from the FJ page renderer): always creates the
        next batch if none exists (to show the user what to join next).

        For show_all mode: returns ALL unjoined channels (legacy behaviour, no
        batching). For progressive_random / fixed_order: uses the stable batch.
        """
        mode = await get_fj_mode()
        all_channels = await db.list_force_channels()
        # BOT6 Phase 4D/5: log the active mode + channel order + active batch so the
        # FJ state is reconstructable from logs (required: 'authorization uses the
        # SAME active randomized batch shown to the user').
        _all_ids = [int(ch["channel_id"]) for ch in all_channels]
        logger.info(
            "BOT6_FJ_MODE mode=%s user_id=%s payload_code=%s configured_channels=%s "
            "batch_size=%s",
            mode, user_id, payload_code or "-", _all_ids, await get_fj_batch_size(),
        )
        # show_all mode: no batching — return all unjoined (legacy behaviour).
        # V26: identity handling still runs FIRST (below) so a mode change to a
        # batched mode deterministically starts the new requirement state.
        batch_size = await get_fj_batch_size()
        if batch_size <= 0:
            batch_size = FJ_BATCH_SIZE_DEFAULT
        progress = await _get_or_init_fj_progress(user_id, payload_code, all_channels)
        # V26 requirement-identity: adopt (legacy) / re-derive (config change)
        # BEFORE any evaluation — the state machine always runs under the
        # CURRENT requirement identity.
        progress = await _apply_requirement_identity(
            user_id, mode, batch_size, all_channels, progress)
        if mode == FJ_MODE_SHOW_ALL:
            return await unjoined_channels_for_user(user_id, all_channels, bot=bot)
        if not all_channels:
            return []

        # Reconcile stored order with current channel set (admin add/remove).
        order, presented, active_ids, completed_batches, cursor, changed = \
            await _reconcile_fj_channel_order(progress, all_channels)
        unlocked_ids = _parse_json_list(progress["unlocked_payload_ids"] if "unlocked_payload_ids" in progress.keys() else None, [])
        if changed or (not unlocked_ids and "unlocked_payload_ids" in progress.keys() and progress["unlocked_payload_ids"] and progress["unlocked_payload_ids"] != "[]"):
            # persist reconciled state (unlocked_ids is reconciled separately above)
            await _persist_fj_progress(
                user_id, order=order, presented=presented,
                active_batch=active_ids, completed_batches=completed_batches, cursor=cursor,
            )
        # BOT6: log the active batch + channel order so 'authorization uses the
        # SAME active randomized batch shown to the user' is verifiable from logs.
        # BOT7: completed_batches + unlocked_payload_ids added so the full FJ state
        # is reconstructable from logs.
        logger.info(
            "BOT6_FJ_MODE mode=%s user_id=%s payload_code=%s channel_order=%s active_batch=%s "
            "completed_batches=%s cursor=%s unlocked_payload_ids=%s",
            mode, user_id, payload_code or "-", order, active_ids,
            completed_batches, cursor, unlocked_ids,
        )
        # V26 FJ_STATE telemetry: the authoritative requirement-state snapshot
        # (user, payload, requirement identity, mode, batch size, order, cursor,
        # active batch, completed batches) — safe fields only (no secrets; the
        # identity is a config fingerprint). One line per state-machine run.
        logger.info(
            "FJ_STATE user_id=%s payload_code=%s identity=%s mode=%s "
            "batch_size=%s channel_order=%s cursor=%s active_batch=%s "
            "completed_batches=%s",
            user_id, payload_code or "-",
            _fj_requirement_identity(mode, batch_size, all_channels),
            mode, batch_size, order, cursor, active_ids, completed_batches,
        )

        # V25 §9: unlocked_payload_ids is a DIAGNOSTICS-ONLY completion record
        # (which payloads were accessed with the requirement fully satisfied).
        # Authorization NEVER reads it — the live membership checks below are
        # the sole authority, so no stored flag can grant, reset or bypass
        # the requirement.

        chan_map = {int(ch["channel_id"]): ch for ch in all_channels}

        # Flatten completed_batches into a set of completed channel IDs.
        # NOTE: completed_flat is used ONLY for UI display (to avoid re-showing
        # channels the user already joined). For ACCESS decisions (for_access=True),
        # we do NOT trust completed_flat — we live-check ALL channels. This prevents
        # the stale-state bypass where a user leaves a completed-batch channel and
        # the bot still grants access.
        completed_flat: Set[int] = set()
        for b in completed_batches:
            for cid in b:
                completed_flat.add(cid)

        # --- STATE MACHINE: do we have an active batch? ---
        if active_ids:
            # YES — use the PERSISTED active batch. Check live membership for
            # channels IN THAT BATCH only. If ALL joined → complete + advance.
            all_joined = True
            unjoined_in_batch: List[aiosqlite.Row] = []
            for cid in active_ids:
                if cid not in chan_map:
                    # Channel was deleted mid-batch — treat as complete (skip).
                    continue
                if bot is None:
                    all_joined = False
                    unjoined_in_batch.append(chan_map[cid])
                    continue
                if await is_member(bot, user_id, cid):
                    continue
                all_joined = False
                unjoined_in_batch.append(chan_map[cid])

            if all_joined:
                # BATCH COMPLETE — persist completion + advance cursor + clear active.
                # V25 §9.3/§9.5 (Force-Join completion persistence): a
                # completed batch is a PRESENTATION SLICE of the requirement,
                # NOT the requirement itself. bot-33.log evidence: the JOINREQ
                # refresh completed batch [-1004426441778, -1004475110285,
                # -1004436085880] and reported decision=ALLOW while
                # -1003963044126 was still `left` — the user was told
                # "complete", then the next payload click presented ANOTHER
                # batch (the reported regression). The verdict is now
                # RE-EVALUATED against the FULL configured requirement: only
                # when NO required channel remains un-joined does the access
                # ALLOW (COMPLETE); otherwise the NEXT batch of genuinely
                # un-joined channels is presented (never a restart from
                # batch 1 — the joined channels stay completed, §9.5).
                # V25 §10 (bot-31.log): completed_batches accumulated
                # 35+ DUPLICATE entries in production (the same batch
                # appended again on every re-completion after leave/rejoin
                # cycles). Dedupe on append + keep the most recent 20 —
                # the list is diagnostics/history only (authorization uses
                # the live membership checks + cursor, never this list).
                _new_batch = [int(x) for x in active_ids]
                completed_batches = [b for b in completed_batches
                                     if b != _new_batch]
                completed_batches.append(_new_batch)
                if len(completed_batches) > 20:
                    completed_batches = completed_batches[-20:]
                for cid in active_ids:
                    completed_flat.add(cid)
                cursor = min(cursor + len(active_ids), len(order))
                await _persist_fj_progress(
                    user_id, active_batch=[], completed_batches=completed_batches,
                    cursor=cursor,
                )
                # --- V25 full-requirement re-evaluation -----------------------
                # Live-check every OTHER configured channel (the just-completed
                # batch channels are proven joined this call). bot=None fails
                # CLOSED (the channel is treated as un-joined) — same safety
                # rule as every other membership check.
                remaining_rows: List[aiosqlite.Row] = []
                for cid in order:
                    if cid in active_ids or cid not in chan_map:
                        continue
                    if bot is None:
                        remaining_rows.append(chan_map[cid])
                        continue
                    if not await is_member(bot, user_id, cid):
                        remaining_rows.append(chan_map[cid])
                if not remaining_rows:
                    # FULL requirement satisfied — the honest completion
                    # record (diagnostics only; authorization above never
                    # reads unlocked_payload_ids).
                    _unlock_pid: Optional[int] = None
                    _unlock_recorded = False
                    if for_access and access_payload_id is not None:
                        _unlock_pid = int(access_payload_id)
                        if _unlock_pid not in unlocked_ids:
                            unlocked_ids = list(unlocked_ids) + [_unlock_pid]
                            _unlock_recorded = True
                    if _unlock_recorded:
                        await _persist_fj_progress(
                            user_id, unlocked_payload_ids=unlocked_ids,
                        )
                        logger.info(
                            "BOT6_FJ_PAYLOAD_UNLOCK user_id=%s mode=%s payload_id=%s "
                            "active_batch=%s completed_batches=%s cursor=%s "
                            "unlocked_payload_ids=%s remaining=[] decision=UNLOCKED",
                            user_id, mode, _unlock_pid, list(active_ids),
                            completed_batches, cursor, unlocked_ids,
                        )
                    logger.info(
                        "BOT6_FJ_BATCH_COMPLETE user_id=%s batch=%s cursor=%s mode=%s "
                        "payload_id=%s completed_batches=%s unlocked_payload_ids=%s "
                        "decision=ALLOW",
                        user_id, list(active_ids), cursor, mode,
                        _unlock_pid if _unlock_pid is not None else "-",
                        completed_batches, unlocked_ids,
                    )
                    # V26 FJ_COMPLETE telemetry: the FULL requirement is
                    # satisfied (every configured channel live-verified as
                    # joined under the current requirement identity).
                    logger.info(
                        "FJ_COMPLETE user_id=%s payload_id=%s identity=%s "
                        "mode=%s completed_batches=%s cursor=%s",
                        user_id,
                        _unlock_pid if _unlock_pid is not None else "-",
                        _fj_requirement_identity(mode, batch_size, all_channels),
                        mode, completed_batches, cursor,
                    )
                    # Requirement complete → this access (and every future
                    # access with the same live memberships) is ALLOWED.
                    return []
                # Required channels remain — present the NEXT batch (the
                # first batch_size genuinely-un-joined channels in the
                # PERSISTED order: completed channels are never re-asked,
                # the order never reshuffles).
                next_rows = remaining_rows[:batch_size]
                next_ids = [int(ch["channel_id"]) for ch in next_rows]
                await _persist_fj_progress(user_id, active_batch=next_ids)
                logger.info(
                    "BOT6_FJ_BATCH_COMPLETE user_id=%s batch=%s cursor=%s mode=%s "
                    "payload_id=%s completed_batches=%s unlocked_payload_ids=%s "
                    "decision=NEXT_BATCH",
                    user_id, list(active_ids), cursor, mode,
                    int(access_payload_id) if access_payload_id is not None else "-",
                    completed_batches, unlocked_ids,
                )
                logger.info(
                    "BOT6_FJ_BATCH_CREATE user_id=%s batch=%s (next after "
                    "completed batch) mode=%s payload_id=%s cursor=%s "
                    "remaining=%s decision=DENY",
                    user_id, next_ids, mode,
                    int(access_payload_id) if access_payload_id is not None else "-",
                    cursor, next_ids,
                )
                # V26 FJ_BATCH_ADVANCE telemetry: the active batch completed
                # and the NEXT batch was created (completed channels never
                # re-asked; the persisted order never reshuffles).
                logger.info(
                    "FJ_BATCH_ADVANCE user_id=%s completed_batch=%s "
                    "next_batch=%s cursor=%s identity=%s mode=%s batch_size=%s",
                    user_id, list(active_ids), next_ids, cursor,
                    _fj_requirement_identity(mode, batch_size, all_channels),
                    mode, batch_size,
                )
                return next_rows
            # Still unjoined channels in the active batch — keep showing it.
            return unjoined_in_batch

        # NO active batch.
        # V25 §9 (CRITICAL): for ACCESS decisions the verdict is ALWAYS the
        # live verified memberships of the configured channels — NEVER a
        # stored completion flag. The old BOTV13 unlocked_payload_ids
        # fast-path permanently allowed a payload after ONE batch completed
        # (bypassing §9.5 partial completion, §9.6 membership removal and
        # §9.7 Case B added channels); it is REMOVED. Unchanged requirement
        # + all required channels still joined → ALLOW with NO new batch
        # (completion persists across clicks/refresh/reopen/dashboard edits
        # because the live state and the persisted order are unchanged);
        # any genuinely un-joined channel → the next batch is presented.
        if for_access:
            all_unjoined: List[aiosqlite.Row] = []
            for cid in order:
                if cid not in chan_map:
                    continue
                if bot is None:
                    all_unjoined.append(chan_map[cid])
                    continue
                if not await is_member(bot, user_id, cid):
                    all_unjoined.append(chan_map[cid])
            if not all_unjoined:
                # ALL channels genuinely joined → ALLOW. Record the honest
                # full-completion diagnostics entry (authorization never
                # reads it — the live checks above ARE the authorization).
                _unlock_pid = None
                if access_payload_id is not None:
                    _unlock_pid = int(access_payload_id)
                    if _unlock_pid not in unlocked_ids:
                        unlocked_ids = list(unlocked_ids) + [_unlock_pid]
                        await _persist_fj_progress(
                            user_id, unlocked_payload_ids=unlocked_ids,
                        )
                        logger.info(
                            "BOT6_FJ_PAYLOAD_UNLOCK user_id=%s mode=%s payload_id=%s "
                            "active_batch=[] completed_batches=%s cursor=%s "
                            "unlocked_payload_ids=%s remaining=[] decision=UNLOCKED",
                            user_id, mode, _unlock_pid, completed_batches,
                            cursor, unlocked_ids,
                        )
                # V26 FJ_COMPLETE telemetry (the no-active-batch path: the
                # requirement was already fully satisfied by live membership).
                logger.info(
                    "FJ_COMPLETE user_id=%s payload_id=%s identity=%s "
                    "mode=%s completed_batches=%s cursor=%s",
                    user_id,
                    _unlock_pid if _unlock_pid is not None else "-",
                    _fj_requirement_identity(mode, batch_size, all_channels),
                    mode, completed_batches, cursor,
                )
                return []
            # Some channels not joined → create a batch from the first batch_size.
            new_batch = all_unjoined[:batch_size]
            new_ids = [int(ch["channel_id"]) for ch in new_batch]
            await _persist_fj_progress(
                user_id, active_batch=new_ids,
            )
            logger.info(
                "BOT6_FJ_BATCH_CREATE user_id=%s batch=%s (for_access) mode=%s "
                "payload_id=%s completed_batches=%s cursor=%s unlocked_payload_ids=%s "
                "remaining=%s decision=DENY",
                user_id, new_ids, mode,
                int(access_payload_id) if access_payload_id is not None else "-",
                completed_batches, cursor, unlocked_ids, new_ids,
            )
            return new_batch

        # For UI display (for_access=False): build the next batch from remaining
        # un-batched channels (using completed_flat to skip already-shown channels).
        # This is for display only — access uses the for_access path above.
        next_batch: List[aiosqlite.Row] = []
        next_ids: List[int] = []
        for i in range(cursor, len(order)):
            cid = order[i]
            if cid in completed_flat:
                continue
            if cid not in chan_map:
                continue
            if bot is None:
                next_batch.append(chan_map[cid])
                next_ids.append(cid)
                continue
            if await is_member(bot, user_id, cid):
                # Already joined — mark completed (UI only) so it's not re-shown.
                completed_flat.add(cid)
                continue
            next_batch.append(chan_map[cid])
            next_ids.append(cid)
            if len(next_batch) >= batch_size:
                break

        if not next_batch:
            # No remaining channels to batch — FJ is fully complete for this user.
            return []

        # BOT6: no unlocked_payload_ids bypass. PERSIST the new active batch.
        await _persist_fj_progress(
            user_id, active_batch=next_ids,
            completed_batches=[[int(x) for x in b] for b in (list(completed_batches))],
        )
        return next_batch

    async def _mark_fj_presented(user_id: int, payload_code: str,
                                  presented_ids: List[int]) -> None:
        """Mark channels as presented in the progress tracker (LEGACY compat).

        BOTV13 Phase A: the active_batch column is the source of truth for what to
        show. The `presented` list is kept for backward compat + analytics only.
        Updates the user's global progress row. Malformed JSON is safely rebuilt.
        """
        progress = await _get_fj_progress(user_id)
        if not progress:
            return
        presented = _parse_json_list(progress["presented"], [])
        for pid in presented_ids:
            pid = int(pid)
            if pid not in presented:
                presented.append(pid)
        await _persist_fj_progress(user_id, presented=presented)

    async def unjoined_channels_for_user(user_id: int,
                                          channels: List[aiosqlite.Row],
                                          *, bot=None) -> List[aiosqlite.Row]:
        """Filter channels the user has NOT joined (live API check).
        BOT5: requires explicit bot — NO _bot_ref fallback."""
        if bot is None:
            logger.warning("BOT6_FJ_ERROR error=bot_is_None — returning all channels as unjoined (FAIL-CLOSED)")
            return list(channels)
        not_joined: List[aiosqlite.Row] = []
        for ch in channels:
            if not await is_member(bot, user_id, ch["channel_id"]):
                not_joined.append(ch)
        return not_joined

    async def _unjoined_for_access(user_id: int,
                                    payload_id: Optional[int] = None,
                                    *, bot=None) -> List[aiosqlite.Row]:
        """BOT6 AUTHORITATIVE access-control view of the FJ requirement.

        Routes through the SAME batch state machine as the UI renderer
        (_get_fj_batch), so the configured mode (SHOW_ALL / FIXED_ORDER /
        PROGRESSIVE_RANDOM) and batch size actually affect AUTHORIZATION —
        not just the UI. This fixes the Phase 2 defect where progressive mode
        only paginated the UI while authorization behaved like SHOW_ALL.

        V25 §9 (Force-Join completion persistence): the verdict is ALWAYS
        derived from LIVE verified memberships of the configured channels
        (backend-authoritative — no stored completion flag can grant or
        reset it):
          * all required channels joined → ALLOW (no new batch; stable
            across re-clicks / refresh / browser reopen / navigation /
            dashboard-user edits);
          * a genuinely un-joined channel → DENY with the CURRENT stable
            batch (partial completion keeps completed channels completed,
            §9.5; membership removal presents only the genuinely missing
            requirement, §9.6; a newly added required channel is enforced,
            §9.7 Case B);
          * completing the active batch re-evaluates the FULL requirement —
            the next batch is presented until every configured channel is
            joined (§9.3: batch 1 → verify → batch 2 → verify → batch 3 →
            verify → COMPLETE).

        Semantics per mode:
          * SHOW_ALL          -> live-check ALL configured channels.
          * FIXED_ORDER / PROGRESSIVE_RANDOM -> the stable persisted batch
            is presented until complete, then the next, until the whole
            requirement is satisfied. The randomized order is persisted
            once and never reshuffles (§9.8).
        """
        not_joined = await _get_fj_batch(user_id, "", for_access=True,
                                         access_payload_id=payload_id, bot=bot)
        mode = await get_fj_mode()
        all_channels = await db.list_force_channels()
        progress = await _get_fj_progress(user_id)
        active = _parse_json_list(
            progress["active_batch"] if progress and "active_batch" in progress.keys() else None,
            [])
        if mode == FJ_MODE_SHOW_ALL:
            required = len(all_channels)
        else:
            # Progress denominator = the active batch size (not the global total),
            # so the user sees e.g. 2/3 (current batch) not 2/6 (global).
            if active:
                required = len(active)
            elif not_joined:
                # Just-created batch: required = len(not_joined) of this batch.
                required = len(not_joined)
            else:
                required = len(all_channels)  # no active batch, all complete
        joined = required - len(not_joined)
        logger.info(
            "BOT6_ACCESS_DECISION user_id=%s payload_id=%s mode=%s required=%s joined=%s "
            "remaining=%s decision=%s",
            user_id, payload_id, mode, required, joined, len(not_joined),
            "ALLOW" if not not_joined else "DENY",
        )
        # V25 §9 structured FJ access log: full state (batches, cursor,
        # completion record, remaining channels, decision). live_verdict=1
        # marks an ALLOW derived from the full live membership verification
        # (the V25 model — the old BOTV13 unlocked fast-path is removed and
        # unlocked_payload_ids is diagnostics-only).
        completed_batches = _parse_json_list_of_lists(
            progress["completed_batches"] if progress and "completed_batches" in progress.keys() else None,
            [])
        cursor = int(progress["batch_cursor"]) if progress and "batch_cursor" in progress.keys() and progress["batch_cursor"] is not None else 0
        unlocked_ids = [int(x) for x in _parse_json_list(
            progress["unlocked_payload_ids"] if progress and "unlocked_payload_ids" in progress.keys() else None,
            [])]
        remaining_ids = [int(ch["channel_id"]) for ch in not_joined]
        _live_verdict = (mode != FJ_MODE_SHOW_ALL and payload_id is not None
                         and not active and not not_joined)
        logger.info(
            "BOT6_FJ_ACCESS user_id=%s mode=%s payload_id=%s active_batch=%s "
            "completed_batches=%s cursor=%s unlocked_payload_ids=%s remaining=%s "
            "live_verdict=%s decision=%s",
            user_id, mode, payload_id, active, completed_batches, cursor,
            unlocked_ids, remaining_ids, 1 if _live_verdict else 0,
            "ALLOW" if not not_joined else "DENY",
        )
        return not_joined

    async def get_fj_mode() -> str:
        """Get the force-join display mode (progressive_random / fixed_order / show_all)."""
        val = await db.get_setting("fj_mode", FJ_MODE_DEFAULT)
        if val in (FJ_MODE_PROGRESSIVE_RANDOM, FJ_MODE_FIXED_ORDER, FJ_MODE_SHOW_ALL):
            return val
        return FJ_MODE_DEFAULT

    async def get_fj_batch_size() -> int:
        """Get the batch size for progressive mode (default 3)."""
        return await db.get_setting_int("fj_batch_size", FJ_BATCH_SIZE_DEFAULT)

    async def force_join_active() -> bool:
        return await db.get_setting_bool("force_join_enabled", ENABLE_FORCE_JOIN)

    async def force_join_requirement_identity() -> str:
        """V26: the CURRENT requirement identity (mode|batch_size|sorted
        channel ids) — the authoritative fingerprint for the (user_id,
        payload_id, force_join_requirement_identity) state tuple."""
        mode = await get_fj_mode()
        batch_size = await get_fj_batch_size()
        if batch_size <= 0:
            batch_size = FJ_BATCH_SIZE_DEFAULT
        all_channels = await db.list_force_channels()
        return _fj_requirement_identity(mode, batch_size, all_channels)

    async def fj_gate_view(user_id: int, gate_key: str,
                           *, payload_id: Optional[int] = None,
                           bot=None) -> dict:
        """V26.2 (bot-41 §16-§24): the PER-GATE progressive-batching view.

        The operator's requirement: when a user opens ONE gated video and
        presses Play, the server delivers ONLY the CURRENT configured
        batch (admin ``fj_batch_size`` is authoritative; never a hard-coded
        size); after a successful Verify the NEXT gated content presents
        the NEXT batch; completed channels never reappear; the state
        survives refresh / SPA navigation / player reopen / retry; future
        batches are NEVER delivered to the client (not hidden with CSS —
        absent from the response payload).

        Semantics (server-authoritative — the client can never influence
        any of it):
          * every distinct GATE (website: one video of a payload; bot/FDB:
            one gated payload delivery) PINS the batch that is pending at
            its first evaluation, persisted in fj_gate_presentations keyed
            (user_id, gate_key, requirement_identity);
          * the gate is SATISFIED when every channel of ITS pinned batch
            is live-verified joined (monotonic per pinned batch) — the
            progressive unlock the operator specified: Video 1 requires
            batch 1, Video 2 requires batch 2, … until the requirement
            completes (then no gate at all);
          * an abandoned batch is RESUMED (the same pending batch is
            re-presented on any reopening, §18);
          * a requirement-identity change (mode / batch size / channel
            set) deterministically re-arms every gate (re-pin on the next
            evaluation) — the EXISTING identity rules, nothing new;
          * the GLOBAL requirement state stays the ONE fj_progress row
            shared by the Website and the File Delivery Bot (§21: neither
            surface can reset the other) — pinned presentations are the
            per-gate view of that shared state;
          * batched modes (fixed_order / progressive_random) pin through
            the EXISTING stable-batch state machine; show_all pins the
            first ``batch_size`` live-unjoined channels in admin order
            (§19: the runtime obeys the configured batch size — never
            render all future channels in the current response);
          * ``bot=None`` fails CLOSED (channels treated as unjoined —
            never a fabricated ALLOW).

        Returns a dict (safe fields only — no secrets, no tokens):
          satisfied, channels (the pinned batch's UNJOINED rows — the ONLY
          rows the client may see for this gate), identity, mode,
          batch_size, batch_index, batch_count, cursor,
          current_batch_count, completed_count, remaining_count,
          gate_key, payload_id, pinned (the pinned channel ids).
        """
        mode = await get_fj_mode()
        all_channels = await db.list_force_channels()
        batch_size = await get_fj_batch_size()
        if batch_size <= 0:
            batch_size = FJ_BATCH_SIZE_DEFAULT
        identity = _fj_requirement_identity(mode, batch_size, all_channels)
        gate_key = str(gate_key or "")[:64]

        def _view(satisfied: bool, channels: List[aiosqlite.Row],
                  pinned: List[int], *, cursor: int,
                  completed_count: Optional[int],
                  remaining_count: Optional[int]) -> dict:
            return {
                "gate_key": gate_key,
                "payload_id": int(payload_id) if payload_id is not None
                else None,
                "requirement_identity": identity,
                "mode": mode,
                "batch_size": int(batch_size),
                "satisfied": bool(satisfied),
                "channels": list(channels),
                "pinned": [int(c) for c in pinned],
                "batch_count": (len(all_channels) + int(batch_size) - 1)
                // int(batch_size) if all_channels else 0,
                "batch_index": (int(cursor) // int(batch_size) + 1)
                if pinned else 0,
                "cursor": int(cursor),
                "current_batch_count": len(channels),
                "completed_count": int(completed_count) if completed_count
                is not None else None,
                "remaining_count": int(remaining_count) if remaining_count
                is not None else None,
            }

        if not all_channels:
            return _view(True, [], [], cursor=0,
                         completed_count=0, remaining_count=0)

        chan_map = {int(ch["channel_id"]): ch for ch in all_channels}

        # ---- requirement COMPLETE fast-path (live, fail-closed) ----------
        _all_unjoined: List[aiosqlite.Row] = []
        if bot is not None:
            for ch in all_channels:
                if not await is_member(bot, user_id, ch["channel_id"]):
                    _all_unjoined.append(ch)
        else:
            _all_unjoined = list(all_channels)
        if not _all_unjoined:
            # Every configured channel is live-verified joined: no gate
            # exists for anyone (until the requirement identity changes).
            try:
                await db.delete_fj_gate_presentations_for_user(user_id)
            except Exception:  # noqa: BLE001 — cleanup is best-effort
                logger.debug("fj gate presentation cleanup failed",
                             exc_info=True)
            logger.info(
                "FJ_COMPLETE user_id=%s payload_id=%s identity=%s mode=%s "
                "completed_batches=live_verified cursor=-",
                user_id,
                int(payload_id) if payload_id is not None else "-",
                identity, mode)
            # BOT-43 (§4 work-stream C): the presentation telemetry at the
            # COMPLETE fast-path — the SAME field order/format as the
            # website verify endpoint's FJ_PRESENTATION line (user_id,
            # gate_key, state, remaining_count, payload_id) so both
            # emission sites are greppable as ONE event. Safe fields only
            # (the gate key is the server-rendered selector, payload_id
            # numeric — never tokens/secrets).
            logger.info(
                "FJ_PRESENTATION user_id=%s gate_key=%s state=complete "
                "remaining_count=0 payload_id=%s",
                user_id, gate_key,
                int(payload_id) if payload_id is not None else "-")
            return _view(True, [], [], cursor=0,
                         completed_count=len(all_channels),
                         remaining_count=0)

        # ---- an existing PIN for this gate under the CURRENT identity ---
        presentation = None
        try:
            presentation = await db.get_fj_gate_presentation(
                user_id, gate_key)
        except Exception:  # noqa: BLE001 — treat as unpinned
            presentation = None
        if presentation is not None:
            stored_identity = str(
                presentation["requirement_identity"]
                if "requirement_identity" in presentation.keys() else "")
            pinned = [int(x) for x in _parse_json_list(
                presentation["pinned_batch"]
                if "pinned_batch" in presentation.keys() else None, [])]
            if stored_identity == identity and pinned:
                # Live-check ONLY the pinned batch channels (fail-closed).
                unjoined_rows: List[aiosqlite.Row] = []
                for cid in pinned:
                    ch = chan_map.get(cid)
                    if ch is None:
                        continue  # removed from config — not re-asked
                    if bot is None or \
                            not await is_member(bot, user_id, cid):
                        unjoined_rows.append(ch)
                if not unjoined_rows:
                    # SATISFIED (monotonic): drive the GLOBAL state machine
                    # once past this batch so the shared pending batch /
                    # completed_batches / FJ_BATCH_ADVANCE / FJ_COMPLETE
                    # state advances exactly once (idempotent afterwards:
                    # the active batch no longer intersects the pin).
                    progress = await _get_fj_progress(user_id)
                    active_now = [int(x) for x in _parse_json_list(
                        progress["active_batch"]
                        if progress and "active_batch" in progress.keys()
                        else None, [])] if mode != FJ_MODE_SHOW_ALL else []
                    if active_now and set(active_now) & set(pinned) \
                            and bot is not None:
                        try:
                            await _get_fj_batch(
                                user_id, "", for_access=True,
                                access_payload_id=payload_id, bot=bot)
                        except Exception:  # noqa: BLE001 — state drive
                            logger.debug("fj gate state advance failed",
                                         exc_info=True)
                    joined_total = len(all_channels) - len(_all_unjoined)
                    logger.info(
                        "FJ_PLAY_GATE user_id=%s payload_id=%s gate_key=%s "
                        "identity=%s batch_index=%s batch_size=%s "
                        "batch_count=%s current_batch_count=0 "
                        "completed_count=%s remaining_count=%s "
                        "decision=ALLOW reason=pinned_batch_complete",
                        user_id,
                        int(payload_id) if payload_id is not None else "-",
                        gate_key, identity,
                        (len(all_channels) - len(_all_unjoined))
                        // int(batch_size) + 1,
                        batch_size,
                        (len(all_channels) + int(batch_size) - 1)
                        // int(batch_size),
                        joined_total, len(_all_unjoined))
                    return _view(True, [], pinned,
                                 cursor=int(progress["batch_cursor"])
                                 if progress and "batch_cursor" in
                                 progress.keys() and
                                 progress["batch_cursor"] is not None
                                 else 0,
                                 completed_count=joined_total,
                                 remaining_count=len(_all_unjoined))
                # Abandoned/pending batch — RESUME the same pinned batch
                # (§18: reopening must resume the same pending batch).
                logger.info(
                    "FJ_PLAY_GATE user_id=%s payload_id=%s gate_key=%s "
                    "identity=%s batch_index=%s batch_size=%s batch_count=%s "
                    "current_batch_count=%s completed_count=%s "
                    "remaining_count=%s decision=DENY reason=pinned_batch_"
                    "pending resume=True",
                    user_id,
                    int(payload_id) if payload_id is not None else "-",
                    gate_key, identity,
                    (len(all_channels) - len(_all_unjoined))
                    // int(batch_size) + 1,
                    batch_size,
                    (len(all_channels) + int(batch_size) - 1)
                    // int(batch_size),
                    len(unjoined_rows),
                    len(all_channels) - len(_all_unjoined),
                    len(_all_unjoined))
                return _view(False, unjoined_rows, pinned,
                             cursor=0,
                             completed_count=len(all_channels)
                             - len(_all_unjoined),
                             remaining_count=len(_all_unjoined))

        # ---- no valid pin: PIN the CURRENT pending batch ------------------
        if mode == FJ_MODE_SHOW_ALL:
            # §19: show_all ALSO obeys the configured batch size at the
            # gate — the first batch_size live-unjoined channels in the
            # admin-configured order (order = list_force_channels order).
            pending_rows = _all_unjoined[:int(batch_size)]
            pinned = [int(ch["channel_id"]) for ch in pending_rows]
        else:
            # The EXISTING stable-batch state machine decides the pending
            # batch (creates/advances it exactly as the legacy surface
            # does — the SAME state the bot FJ page renders).
            pending_rows = await _get_fj_batch(
                user_id, "", for_access=True,
                access_payload_id=payload_id, bot=bot)
            pinned = [int(ch["channel_id"]) for ch in pending_rows]
            if not pending_rows:
                # The machine live-verified the FULL requirement satisfied
                # while pinning (or all joined) — no gate for this content.
                joined_total = len(all_channels) - len(_all_unjoined)
                return _view(True, [], pinned, cursor=0,
                             completed_count=joined_total,
                             remaining_count=len(_all_unjoined))
        if not pinned:
            return _view(True, [], [], cursor=0,
                         completed_count=len(all_channels)
                         - len(_all_unjoined),
                         remaining_count=len(_all_unjoined))
        try:
            await db.upsert_fj_gate_presentation(
                user_id, gate_key, identity, json.dumps(pinned))
        except Exception:  # noqa: BLE001 — pin persistence is best-effort
            logger.debug("fj gate presentation pin failed", exc_info=True)
        _cursor = 0
        try:
            progress = await _get_fj_progress(user_id)
            if progress and "batch_cursor" in progress.keys() \
                    and progress["batch_cursor"] is not None:
                _cursor = int(progress["batch_cursor"])
        except Exception:  # noqa: BLE001
            _cursor = 0
        joined_total = len(all_channels) - len(_all_unjoined)
        logger.info(
            "FJ_PLAY_GATE user_id=%s payload_id=%s gate_key=%s identity=%s "
            "batch_index=%s batch_size=%s batch_count=%s "
            "current_batch_count=%s completed_count=%s remaining_count=%s "
            "decision=DENY reason=batch_pinned pinned_batch=%s "
            "future_batches_delivered=0",
            user_id,
            int(payload_id) if payload_id is not None else "-",
            gate_key, identity,
            joined_total // int(batch_size) + 1,
            batch_size,
            (len(all_channels) + int(batch_size) - 1) // int(batch_size),
            len([c for c in pinned if not (bot is not None and
                await is_member(bot, user_id, c))]),
            joined_total, len(_all_unjoined), pinned)
        # FJ_STATE (gate-scoped): the authoritative snapshot at pin time.
        logger.info(
            "FJ_STATE user_id=%s payload_id=%s gate_key=%s identity=%s "
            "mode=%s batch_size=%s batch_index=%s batch_count=%s cursor=%s "
            "active_batch=%s pinned_batch=%s future_batches_delivered=0",
            user_id,
            int(payload_id) if payload_id is not None else "-",
            gate_key, identity, mode, batch_size,
            joined_total // int(batch_size) + 1,
            (len(all_channels) + int(batch_size) - 1) // int(batch_size),
            _cursor, "-", pinned)
        # BOT-43 (§4 work-stream C): the presentation telemetry at pin
        # time — the SAME field order/format as the website verify
        # endpoint's FJ_PRESENTATION line (user_id, gate_key, state,
        # remaining_count, payload_id; remaining_count mirrors the view's
        # remaining_count field — the channels still un-joined overall).
        logger.info(
            "FJ_PRESENTATION user_id=%s gate_key=%s state=remaining "
            "remaining_count=%s payload_id=%s",
            user_id, gate_key, len(_all_unjoined),
            int(payload_id) if payload_id is not None else "-")
        return _view(False, pending_rows, pinned, cursor=_cursor,
                     completed_count=joined_total,
                     remaining_count=len(_all_unjoined))

    async def fj_gate_unjoined(user_id: int, gate_key: str,
                               *, payload_id: Optional[int] = None,
                               bot=None) -> List[aiosqlite.Row]:
        """The ACCESS ENGINE adapter for the gate view: the unjoined rows
        of THIS gate's pinned batch ([] when the gate is satisfied). The
        callers render / enforce exactly this slice — never the full
        requirement list, never a future batch."""
        view = await fj_gate_view(user_id, gate_key,
                                  payload_id=payload_id, bot=bot)
        return list(view.get("channels") or [])

    async def fj_state(user_id: int, payload_id: Optional[int] = None,
                       *, bot=None) -> dict:
        """V26: READ-ONLY authoritative requirement-state snapshot for
        (user_id, payload_id, force_join_requirement_identity).

        Observability + tests: NEVER mutates state (no batch creation, no
        persistence) — the gates and the Access Engine keep using
        _get_fj_batch / _unjoined_for_access; this view reports what the
        persisted row + the CURRENT requirement config + live membership
        say RIGHT NOW. ``bot=None`` (or a membership-check failure) is
        reported honestly: joined/remaining are None (fail-closed — never
        a fabricated ALLOW).
        """
        mode = await get_fj_mode()
        batch_size = await get_fj_batch_size()
        if batch_size <= 0:
            batch_size = FJ_BATCH_SIZE_DEFAULT
        all_channels = await db.list_force_channels()
        identity = _fj_requirement_identity(mode, batch_size, all_channels)
        progress = await _get_fj_progress(user_id)
        order = [int(x) for x in _parse_json_list(
            progress["channel_order"] if progress and "channel_order" in progress.keys() else None,
            [int(ch["channel_id"]) for ch in all_channels])]
        active = [int(x) for x in _parse_json_list(
            progress["active_batch"] if progress and "active_batch" in progress.keys() else None,
            [])]
        completed_batches = _parse_json_list_of_lists(
            progress["completed_batches"] if progress and "completed_batches" in progress.keys() else None,
            [])
        completed_flat = sorted({int(cid) for b in completed_batches for cid in b})
        cursor = int(progress["batch_cursor"]) if progress \
            and "batch_cursor" in progress.keys() \
            and progress["batch_cursor"] is not None else 0
        stored_identity = None
        if progress and "requirement_identity" in progress.keys():
            stored_identity = progress["requirement_identity"]
        joined = None
        remaining = None
        decision = "unknown"
        if bot is not None:
            try:
                remaining = []
                for ch in all_channels:
                    if not await is_member(bot, user_id, ch["channel_id"]):
                        remaining.append(int(ch["channel_id"]))
                joined = len(all_channels) - len(remaining)
                decision = "allow" if not remaining else "deny"
            except Exception:  # noqa: BLE001 — honest unknown, never fabricated
                joined = remaining = None
                decision = "unknown"
        return {
            "user_id": int(user_id),
            "payload_id": int(payload_id) if payload_id is not None else None,
            "requirement_identity": identity,
            "stored_identity": stored_identity,
            "identity_matches": (stored_identity == identity),
            "mode": mode,
            "batch_size": int(batch_size),
            "channels": [int(ch["channel_id"]) for ch in all_channels],
            "channel_order": order,
            "cursor": cursor,
            "active_batch": active,
            "completed_batches": completed_batches,
            "completed_channels": completed_flat,
            "joined": joined,
            "remaining": remaining,
            "decision": decision,
            "has_progress_row": progress is not None,
        }

    return SimpleNamespace(
        check_membership=check_membership,
        is_member=is_member,
        get_pending_channel_for_user=get_pending_channel_for_user,
        unjoined_channels=unjoined_channels,
        _force_channel_label=_force_channel_label,
        classify_channel_access=classify_channel_access,
        _check_force_channel_valid=_check_force_channel_valid,
        _channel_validity_label=_channel_validity_label,
        _get_fj_progress=_get_fj_progress,
        _get_or_init_fj_progress=_get_or_init_fj_progress,
        _parse_json_list=_parse_json_list,
        _parse_json_list_of_lists=_parse_json_list_of_lists,
        _reconcile_fj_channel_order=_reconcile_fj_channel_order,
        _persist_fj_progress=_persist_fj_progress,
        _get_active_fj_batch_ids=_get_active_fj_batch_ids,
        _get_active_fj_batch_channels=_get_active_fj_batch_channels,
        _get_fj_batch=_get_fj_batch,
        _mark_fj_presented=_mark_fj_presented,
        unjoined_channels_for_user=unjoined_channels_for_user,
        _unjoined_for_access=_unjoined_for_access,
        get_fj_mode=get_fj_mode,
        get_fj_batch_size=get_fj_batch_size,
        force_join_active=force_join_active,
        _fj_requirement_identity=_fj_requirement_identity,
        _apply_requirement_identity=_apply_requirement_identity,
        force_join_requirement_identity=force_join_requirement_identity,
        fj_gate_view=fj_gate_view,
        fj_gate_unjoined=fj_gate_unjoined,
        fj_state=fj_state,
    )
