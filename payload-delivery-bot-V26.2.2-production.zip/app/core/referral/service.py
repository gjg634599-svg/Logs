"""Referral domain service: link helpers, gate check, qualification
transaction and the referral share link."""
from __future__ import annotations

import logging
from types import SimpleNamespace

from app.core.constants import ACCESS_POLICY_FORCE_JOIN_REFERRAL
from app.core.constants import REFERRAL_LINK_PREFIX
from app.core.constants import REFERRAL_TOKEN_LENGTH
from app.core.dbutil import safe_row_get as _safe_row_get
from typing import Any, Dict, Optional, Tuple
import asyncio

logger = logging.getLogger("payload-bot")

def is_referral_link(arg: str) -> bool:
    """True if a /start argument looks like a referral link (ref_<token>)."""
    if not arg.startswith(REFERRAL_LINK_PREFIX):
        return False
    token = arg[len(REFERRAL_LINK_PREFIX):]
    return len(token) == REFERRAL_TOKEN_LENGTH and all(
        c in "0123456789abcdefABCDEF" for c in token
    )

def parse_referral_token(arg: str) -> Optional[str]:
    """Extract the token from a 'ref_<token>' style argument."""
    if not is_referral_link(arg):
        return None
    return arg[len(REFERRAL_LINK_PREFIX):].lower()


def make_referral_service(db, access_engine=None, auto_deliver_unlocked_payload=None, _build_progress_bar_styled=None, _maybe_send_appreciation=None, safe_send_text=None, build_start_link=None, _referral_dedup_locks=None, _referral_dedup_locks_guard=None, BOT_USERNAME=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    async def check_referral_gate(payload_id: int, user_id: int) -> Dict[str, Any]:
        """Backward-compat wrapper around the Access Engine.

        Returns the legacy dict shape so any existing call site keeps working:
          gate_enabled, unlocked, campaign, unlock_record,
          required_referrals, completed_referrals
        """
        res = await access_engine(None, user_id, payload_id=payload_id, check_force_join=False)
        gate_enabled = res.policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL and res.campaign is not None
        return {
            "gate_enabled": gate_enabled,
            "unlocked": res.authorized or (gate_enabled and res.reason == "unlocked"),
            "campaign": res.campaign,
            "unlock_record": res.unlock_record,
            "required_referrals": res.required_referrals,
            "completed_referrals": res.completed_referrals,
        }

    async def qualify_referral(bot, campaign_id: int, inviter_user_id: int,
                                referred_user_id: int) -> Tuple[bool, int, bool]:
        """Access Engine V1: Qualify a referral after all checks pass.

        BOTV13 Fix: the entire check-and-act sequence (is_already_referred →
        has_user_qualified → qualify_referral_atomic) is wrapped in a per-referral
        dedup lock keyed on (campaign_id, inviter_user_id, referred_user_id). This
        closes the TOCTOU race where two concurrent /start ref_<token> clicks for
        the same referred user both pass the SELECT checks. The DB-level
        ON CONFLICT DO NOTHING in qualify_referral_atomic is the backstop, but
        this lock also prevents duplicate side-effects (notifications, auto-deliver,
        analytics) that fire outside the atomic block.
        """
        logger.info("Referral trace [qualify_referral]: ENTER campaign=%s inviter=%s referred=%s", campaign_id, inviter_user_id, referred_user_id)

        if not inviter_user_id or inviter_user_id <= 0:
            logger.error("Referral trace [qualify_referral]: ABORT — inviter_user_id=%s is invalid (campaign=%s referred=%s)", inviter_user_id, campaign_id, referred_user_id)
            return False, 0, False

        # 1. Self-referral.
        if inviter_user_id == referred_user_id:
            logger.info("Referral: self-referral blocked (inviter=%s)", inviter_user_id)
            return False, 0, False

        # BOTV13 Fix: acquire the per-referral dedup lock BEFORE any SELECT so the
        # check-and-act window is atomic at the coroutine level.
        dedup_lock = await _get_referral_dedup_lock(campaign_id, inviter_user_id, referred_user_id)
        async with dedup_lock:
            # FIX: Restore the missing campaign database lookup here!
            campaign = await db.get_referral_campaign_by_id(campaign_id)
            if not campaign or not _safe_row_get(campaign, "enabled"):
                logger.warning("Referral: Campaign %s is missing or disabled.", campaign_id)
                return False, 0, False

            # 2. Already referred (defensive — the atomic INSERT also guards this).
            if await db.is_already_referred(campaign_id, inviter_user_id, referred_user_id):
                logger.info("Referral: duplicate blocked (campaign=%s inviter=%s referred=%s)",
                             campaign_id, inviter_user_id, referred_user_id)
                return False, 0, False

            # 3. Already qualified as a referred user for this campaign (no re-counting).
            if await db.has_user_qualified_for_campaign(campaign_id, referred_user_id):
                logger.info("Referral: already qualified (campaign=%s user=%s)",
                             campaign_id, referred_user_id)
                return False, 0, False

            # 4. Atomic record + increment (single transaction).
            required = int(campaign["required_referrals"])
            qualified, new_count, just_unlocked, already_unlocked = await db.qualify_referral_atomic(
                campaign_id, inviter_user_id, referred_user_id,
                campaign["payload_id"], required,
            )

            if not qualified:
                return False, new_count, just_unlocked

            # Analytics: qualified_referral event.
            await db.log_access_event("qualified_referral",
                                      payload_id=campaign["payload_id"],
                                      campaign_id=campaign_id, user_id=referred_user_id)

            # Notify the inviter + auto-deliver on unlock.
            try:
                if just_unlocked:
                    # BOTV13 Seamless Unlock: NO separate congrats message is sent.
                    # The dashboard is edited in-place into the congratulations /
                    # ready screen (Collection Ready menu or File Ready screen).
                    # No chat spam, no duplicate dashboard, no auto-send of files.
                    await auto_deliver_unlocked_payload(bot, inviter_user_id, campaign["payload_id"])
                elif already_unlocked:
                    # BOTV13 Part 2: inviter was already unlocked. Send at most one
                    # appreciation notification per 24 hours. No progress notification.
                    await _maybe_send_appreciation(bot, campaign, inviter_user_id, required)
                else:
                    progress_bar = _build_progress_bar_styled(new_count, required, "block")
                    notify_text = (
                        "\U0001F389 New Referral!\n\n"
                        f"Progress: {progress_bar}\n"
                        f"{new_count} / {required}\n\n"
                        f"Keep sharing to unlock!"
                    )
                    await safe_send_text(bot, inviter_user_id, notify_text)
            except Exception as e:
                logger.warning("Referral: failed to notify inviter %s: %s", inviter_user_id, e)

            return True, new_count, just_unlocked

    async def _get_referral_dedup_lock(campaign_id: int, inviter_user_id: int,
                                        referred_user_id: int) -> asyncio.Lock:
        """Get (or create) the per-referral dedup lock. Serialised creation under
        a guard lock so two racing coroutines never create two locks for the same
        triple."""
        key = (campaign_id, inviter_user_id, referred_user_id)
        lock = _referral_dedup_locks.get(key)
        if lock is not None:
            return lock
        async with _referral_dedup_locks_guard:
            lock = _referral_dedup_locks.get(key)
            if lock is None:
                lock = asyncio.Lock()
                _referral_dedup_locks[key] = lock
            return lock

    def build_referral_link(token: str) -> str:
        """Build a deep link for a referral: ?start=ref_<token>."""
        return build_start_link(f"{REFERRAL_LINK_PREFIX}{token}")

    return SimpleNamespace(
        check_referral_gate=check_referral_gate,
        qualify_referral=qualify_referral,
        _get_referral_dedup_lock=_get_referral_dedup_lock,
        build_referral_link=build_referral_link,
    )
