"""Legacy import-path shim (ARCHITECTURE PHASE).

The canonical implementation moved to ``app.core.indexing.engine``; this
module keeps the legacy import path (``import app.core.indexing_engine``)
working unchanged for the regression suites.
"""
from app.core.indexing.engine import *  # noqa: F401,F403
from app.core.indexing.engine import (  # noqa: F401
    SCAN_COMPLETE, SCAN_PARTIAL, SCAN_STOPPED, SCAN_FAILED, SCAN_RUNNING,
    resume_plan, new_job_record, advance, touch, finish,
    merge_live_counters, job_is_stale, scan_state_label,
)
