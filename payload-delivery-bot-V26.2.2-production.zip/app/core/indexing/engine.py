"""PHASE 8 (§1-§9): durable index-job engine helpers.

STANDALONE MODULE — never imports the bot monolith. bot.py wires these
helpers with its DB/settings layer at call time.

Production evidence driving this module (bot.log 22 + user report):
  * A manual re-index reported processed=9 / indexed=0 / duplicates=8 and
    "finished successfully" while the Storage Center showed files=1077 —
    nobody could tell WHAT the scan actually covered.
  * REINDEX_DEFAULT_COUNT=500 silently truncated Full Reindex first-scans
    on channels with more than 500 messages and then reported
    "Reindex Complete" — the classic fetch-batch-then-claim-done bug.
  * Scan progress did not survive restarts (cursor persisted only at END);
    an interrupted 18k-message first scan restarted from zero.
  * The auto-scan path wrote last_scanned=latest even when it stopped
    early — silently skipping unscanned messages forever.

What this module provides (pure logic, no I/O except via injected hooks):
  * IndexJobRecord — the durable per-channel job state persisted in the
    bot_settings KV store (key index_job:<channel_id>) every
    JOB_PERSIST_EVERY messages, at every flush boundary, and at completion.
  * SCAN_* terminal states with honest semantics:
        SCAN_RUNNING    — a scan is in progress right now
        SCAN_COMPLETE   — genuinely reached the end of the requested range
        SCAN_STOPPED    — admin-requested graceful stop (resumable)
        SCAN_FAILED     — fatal error (channel inaccessible / runaway guard)
        SCAN_PARTIAL    — stopped before the end for any other reason
                          (history gap, safety cap, no-media streak)
  * resume_plan() — decide, given a persisted job record and the requested
    mode, whether to RESUME the interrupted scan (and from where) or start
    fresh. A backward FIRST scan resumes DOWNWARD (its remaining work is
    below the interruption point); a forward incremental scan resumes
    UPWARD. This fixes the old restart-from-zero behaviour.
  * A runaway guard constant replacing the old 500-message truncation.
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Dict, Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
JOB_PERSIST_EVERY = 25            # persist job state every N processed messages
STALE_RUNNING_SECONDS = 900.0     # a 'running' job untouched for 15 min is dead

# The old REINDEX_DEFAULT_COUNT=500 truncation is REPLACED by this runaway
# guard: a scan is bounded by its [scan_start..scan_end] range anyway; this
# only protects against a pathological loop. Hitting it is a FAILURE, never
# a "complete".
SCAN_RUNAWAY_GUARD = 2_000_000

# ---------------------------------------------------------------------------
# Truthful scan states (spec §2/§6)
# ---------------------------------------------------------------------------
SCAN_RUNNING = "SCAN_RUNNING"
SCAN_COMPLETE = "SCAN_COMPLETE"
SCAN_STOPPED = "SCAN_STOPPED"
SCAN_FAILED = "SCAN_FAILED"
SCAN_PARTIAL = "SCAN_PARTIAL"

_STATE_LABELS = {
    SCAN_RUNNING: "\U0001F504 Indexing…",
    SCAN_COMPLETE: "\u2705 Full Scan Complete",
    SCAN_STOPPED: "\u23F9 Scan Stopped (resumable)",
    SCAN_FAILED: "\u274C Scan Failed",
    SCAN_PARTIAL: "\u26A0\uFE0F Partial Scan (incomplete)",
}


def scan_state_label(state: Optional[str]) -> str:
    return _STATE_LABELS.get(state or "", SCAN_PARTIAL)


# ---------------------------------------------------------------------------
# Durable job record
# ---------------------------------------------------------------------------
def new_job_record(channel_id: int, mode: str, direction: int,
                   scan_start: int, scan_end: int, latest: int
                   ) -> Dict[str, Any]:
    """Create a fresh RUNNING job record for a channel scan."""
    return {
        "job_id": uuid.uuid4().hex[:10],
        "channel_id": int(channel_id),
        "mode": mode,                    # 'first_scan_backward' | 'incremental_forward'
        "direction": int(direction),     # -1 backward, +1 forward
        "status": SCAN_RUNNING,
        "scan_start": int(scan_start),
        "scan_end": int(scan_end),
        "latest": int(latest),
        "resume_msg_id": int(scan_start),
        "counters": {
            "processed": 0, "indexed": 0, "duplicates": 0,
            "file_ids_refreshed": 0, "no_media": 0, "protected": 0,
            "missing": 0, "errors": 0,
        },
        "consecutive_missing": 0,
        "consecutive_no_media": 0,
        "started_at": _now_iso(),
        "updated_at": _now_iso(),
        "finished_at": None,
        "stopped_reason": None,
    }


def _now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def job_is_stale(job: Optional[Dict[str, Any]],
                 now: Optional[float] = None) -> bool:
    """A RUNNING job whose updated_at is older than STALE_RUNNING_SECONDS
    belongs to a dead process (bot restarted mid-scan) — it is resumable."""
    if not job or job.get("status") != SCAN_RUNNING:
        return False
    try:
        updated = float(job.get("updated_epoch") or 0.0)
    except (TypeError, ValueError):
        return False
    if updated <= 0:
        return True  # legacy record without a timestamp — treat as stale
    return (now if now is not None else time.time()) - updated > STALE_RUNNING_SECONDS


def resume_plan(job: Optional[Dict[str, Any]], *, full_rescan: bool,
                incremental: bool, resume_requested: bool
                ) -> Dict[str, Any]:
    """Decide how to proceed given the persisted job record.

    Returns a plan dict:
        {"action": "resume" | "fresh", "job": <record or None>,
         "reason": str}

    Rules:
      * Full Re-index (explicit)  -> ALWAYS fresh (admin chose to re-walk
        everything); an old interrupted record is replaced.
      * Incremental / auto / quick-> resume an interrupted INCREMENTAL job
        (direction +1) from its resume point; an interrupted BACKWARD job
        also resumes (its cursor semantics are handled by the caller).
      * resume_requested (the explicit Resume button) -> resume whichever
        interrupted record exists.
      * No record / completed record / non-stale RUNNING record (another
        worker still active) -> fresh, with the reason set.
    """
    if job is None:
        return {"action": "fresh", "job": None, "reason": "no_previous_job"}
    status = job.get("status")
    if status == SCAN_RUNNING and not job_is_stale(job):
        return {"action": "fresh", "job": None,
                "reason": "job_still_running_other_worker"}
    if full_rescan:
        return {"action": "fresh", "job": None,
                "reason": "full_rescan_requested"}
    resumable = status in (SCAN_RUNNING, SCAN_STOPPED, SCAN_PARTIAL)
    if not resumable:
        return {"action": "fresh", "job": None,
                "reason": f"previous_job_{str(status).lower()}"}
    if resume_requested or incremental or status in (SCAN_STOPPED,
                                                     SCAN_PARTIAL):
        return {"action": "resume", "job": job,
                "reason": "resuming_interrupted_scan"}
    return {"action": "fresh", "job": None, "reason": "not_resumable"}


def advance(job: Dict[str, Any], msg_id: int, outcome: Optional[str],
            *, refreshed: bool = False) -> None:
    """Record one processed message into the job record (in place)."""
    counters = job.setdefault("counters", {})
    counters["processed"] = int(counters.get("processed", 0)) + 1
    if outcome == "indexed":
        counters["indexed"] = int(counters.get("indexed", 0)) + 1
        job["consecutive_missing"] = 0
        job["consecutive_no_media"] = 0
    elif outcome == "duplicate":
        counters["duplicates"] = int(counters.get("duplicates", 0)) + 1
        if refreshed:
            counters["file_ids_refreshed"] = int(
                counters.get("file_ids_refreshed", 0)) + 1
        job["consecutive_missing"] = 0
        job["consecutive_no_media"] = 0
    elif outcome == "no_media":
        counters["no_media"] = int(counters.get("no_media", 0)) + 1
        job["consecutive_missing"] = 0
        job["consecutive_no_media"] = int(job.get("consecutive_no_media", 0)) + 1
    elif outcome == "missing":
        counters["missing"] = int(counters.get("missing", 0)) + 1
        job["consecutive_missing"] = int(job.get("consecutive_missing", 0)) + 1
    elif outcome == "protected":
        counters["protected"] = int(counters.get("protected", 0)) + 1
        job["consecutive_missing"] = 0
        job["consecutive_no_media"] = int(job.get("consecutive_no_media", 0)) + 1
    elif outcome == "error":
        counters["errors"] = int(counters.get("errors", 0)) + 1
        job["consecutive_missing"] = 0
    job["resume_msg_id"] = int(msg_id)
    job["updated_at"] = _now_iso()
    job["updated_epoch"] = time.time()


def touch(job: Dict[str, Any]) -> None:
    """Refresh the liveness timestamp without counting a message."""
    job["updated_at"] = _now_iso()
    job["updated_epoch"] = time.time()


def finish(job: Dict[str, Any], status: str, reason: str) -> None:
    """Mark the job terminal (COMPLETE / STOPPED / FAILED / PARTIAL)."""
    job["status"] = status
    job["stopped_reason"] = reason
    job["finished_at"] = _now_iso()
    job["updated_at"] = _now_iso()
    job["updated_epoch"] = time.time()


def merge_live_counters(job: Dict[str, Any]) -> Dict[str, Any]:
    """The counters block for rendering/persistence."""
    return dict(job.get("counters", {}))


__all__ = [
    "JOB_PERSIST_EVERY", "STALE_RUNNING_SECONDS", "SCAN_RUNAWAY_GUARD",
    "SCAN_RUNNING", "SCAN_COMPLETE", "SCAN_STOPPED", "SCAN_FAILED",
    "SCAN_PARTIAL", "scan_state_label",
    "new_job_record", "job_is_stale", "resume_plan", "advance", "touch",
    "finish", "merge_live_counters",
]
