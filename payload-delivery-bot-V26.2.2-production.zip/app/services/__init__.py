"""Application service container."""
