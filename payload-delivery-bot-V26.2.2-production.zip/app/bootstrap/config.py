"""Runtime configuration assembly (ARCHITECTURE DECOUPLING).

Extracted from the legacy ``bot.py`` module-level configuration zone:
environment parsing, validation order, and error messages are preserved
VERBATIM (including the two CRITICAL SECURITY ERROR ``ValueError`` guards
for ``ADMIN_IDS`` — the bot refuses to start without explicit admins).

``RuntimeConfig.from_env(source_file)`` is invoked exactly once by the
composition (bot.py's import today; app/bootstrap/application.py as the
authoritative entrypoint wiring). The parsed values are then bound as
module-level names in the legacy namespace so the regression suites'
monkey-patching semantics (e.g. ``B.MINI_APP_DEV_ALLOW_HTTP = True``)
keep working unchanged — the RuntimeConfig object is the PARSER, the
runtime bindings remain the compatibility facade's module globals.

``compute_runtime_build_id(source_file)`` keeps the V5.1 deployment
identity semantics: SHA-256 of the RUNNING bot.py source content (the
composition passes ``bot.__file__`` — a plain copy keeps the identity,
an edit changes it).
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from typing import List


def compute_runtime_build_id(source_file: str) -> str:
    """WATCH_AD V5.1 (§50): deployment identity — SHA-256 of the SOURCE FILE
    CONTENT (not mtime: a plain copy must keep the identity, an edit must
    change it). Cached in RUNTIME_BUILD_ID at import; carried by the startup
    banner AND by WATCH_AD_MODE_RESOLVED, so 'the source says X while an old
    container actually runs Y' can no longer stay hidden (the exact situation
    the V5.1 audit had to rule out for the random→1 sessions in bot.log 16/17).
    """
    try:
        with open(source_file, "rb") as _f:
            return "bot6-" + hashlib.sha256(_f.read()).hexdigest()[:12]
    except Exception:  # noqa: BLE001  # unreadable source (frozen/embedded)
        return "bot6-unknown"


@dataclass(frozen=True)
class EnvDefaults:
    """Environment-seeded feature defaults (ARCHITECTURE PROPER BREAKDOWN
    RULE F: environment parsing is centralized HERE — app/core/constants.py
    and every other module read the PARSED values, never os.environ).

    Deliberately separate from RuntimeConfig.from_env (which enforces the
    hard ADMIN_IDS guards): these are import-time feature DEFAULTS that must
    never fail an import. Same variables, same defaults, same parsing as the
    legacy bot.py-era constants.
    """

    enable_analytics: bool = True
    watch_ad_session_ttl: int = 900
    auto_delete_default: int = 20
    watch_ad_initdata_max_age: int = 86400
    media_cache_root: str = ""
    network_token_encryption_key: str = ""
    network_global_link_signing_key: str = ""
    watch_ad_session_hourly_cap: int = 10
    # FILE DELIVERY v34 (spec §25): bootstrap seed for the File Delivery
    # Bot credential. Runtime management (add/change/rotate) happens via
    # the Control Bot; this env var seeds the ENCRYPTED store on first
    # boot when no credential is stored yet.
    file_delivery_bot_token: str = ""
    control_bot_token: str = ""
    # BOT-13 RULE F centralization: the website-layer env fallbacks move
    # here so app/web/website_monetag.py contains ZERO os.environ reads
    # (the architecture gate requires env parsing ONLY in bootstrap +
    # media config).
    website_monetag_ad_tag: str = ""
    # BOT-26 ISSUE B diagnostic (production green-screen investigation):
    # the master switch for the Monetag WEBSITE surface. Default "true"
    # (production unchanged — provider sw.js verbatim + configured ad tag
    # injected). "false" is a DIAGNOSTIC/development state: no ad tag is
    # injected and /sw.js serves a self-unregistering no-op worker so an
    # operator can isolate the third-party ad layer WITHOUT removing the
    # Monetag configuration (docs/MONETAG_WEBSITE.md §6).
    website_monetag_enabled: bool = True
    origin_proxy_secret: str = ""
    # BOT-16 RULE F centralization: the transcode cache root env override
    # (app/media/transcode.py must contain ZERO os.environ reads — the
    # architecture gate requires env parsing ONLY in bootstrap + media
    # config).
    media_transcode_root: str = ""
    database_file: str = ""

    @staticmethod
    def from_env() -> "EnvDefaults":
        return EnvDefaults(
            enable_analytics=(
                os.environ.get("ENABLE_ANALYTICS", "true").lower() == "true"),
            watch_ad_session_ttl=int(
                os.environ.get("WATCH_AD_SESSION_TTL", "900")),
            auto_delete_default=int(
                os.environ.get("AUTO_DELETE_DEFAULT", "20")),
            watch_ad_initdata_max_age=int(
                os.environ.get("WATCH_AD_INITDATA_MAX_AGE", "86400")),
            media_cache_root=os.environ.get("MEDIA_CACHE_ROOT", "").strip(),
            network_token_encryption_key=(
                os.environ.get("NETWORK_TOKEN_ENCRYPTION_KEY") or ""),
            network_global_link_signing_key=(
                os.environ.get("NETWORK_GLOBAL_LINK_SIGNING_KEY") or ""),
            watch_ad_session_hourly_cap=int(
                os.environ.get("WATCH_AD_SESSION_HOURLY_CAP", "10")),
            file_delivery_bot_token=(
                os.environ.get("FILE_DELIVERY_BOT_TOKEN") or "").strip(),
            control_bot_token=(
                os.environ.get("CONTROL_BOT_TOKEN") or "").strip(),
            website_monetag_ad_tag=(
                os.environ.get("WEBSITE_MONETAG_AD_TAG") or "").strip(),
            website_monetag_enabled=(
                os.environ.get("WEBSITE_MONETAG_ENABLED", "true").lower()
                not in ("0", "false", "no", "off")),
            media_transcode_root=(
                os.environ.get("MEDIA_TRANSCODE_ROOT") or "").strip(),
            database_file=(
                os.environ.get("DATABASE_FILE") or "").strip(),
            origin_proxy_secret=(
                os.environ.get("ORIGIN_PROXY_SECRET") or "").strip(),
        )


@dataclass(frozen=True)
class RuntimeConfig:
    """Parsed runtime configuration (env-driven values only).

    Pure constants (page sizes, prefixes, policy labels...) remain in
    ``app.core.constants`` / the legacy layer — this object owns exactly
    the environment-parsed surface, with the original validation order.
    """

    bot_token: str = "PUT_YOUR_BOT_TOKEN_HERE"
    admin_ids: List[int] = field(default_factory=list)
    database_file: str = "payload_bot.db"
    runtime_build_id: str = "bot6-unknown"
    bot_username: str = ""
    auto_reindex_interval: int = 60
    enable_force_join: bool = True
    enable_auto_payload: bool = False
    auto_reindex_on_startup: bool = False
    mini_app_port: int = 8080
    mini_app_enabled: bool = True
    mini_app_dev_allow_http: bool = False
    mini_app_base_url: str = ""
    watch_ad_unlock_window: int = 180
    watch_ad_session_hourly_cap: int = 10

    @staticmethod
    def from_env(source_file: str) -> "RuntimeConfig":
        """Parse the runtime configuration from the environment.

        Validation order and error messages replicate the legacy bot.py
        import-time sequence exactly:
          1. BOT_TOKEN (sentinel default — never a hard failure at import)
          2. ADMIN_IDS (hard ValueError guards — CRITICAL SECURITY ERROR)
          3. DATABASE_FILE
          4. RUNTIME_BUILD_ID (SHA-256 of the running bot source)
          5. BOT_USERNAME (optional env fallback, auto-detected at startup)
          6. operational toggles / intervals
          7. Mini App (Watch Ads) settings
          8. Watch Ads unlock window + session cap
        """
        # ---- token (sentinel default; build_application refuses to start
        # on the sentinel — same split as the legacy layer) ----
        bot_token: str = os.environ.get("BOT_TOKEN", "PUT_YOUR_BOT_TOKEN_HERE")

        # ---- admins (no default — hard failure, preserved verbatim) ----
        _raw_admins = os.environ.get("ADMIN_IDS")
        # Security Fix: Force the bot to crash if the admin ID is missing
        if not _raw_admins:
            raise ValueError(
                "CRITICAL SECURITY ERROR: ADMIN_IDS environment variable is "
                "missing! Please set it in your .env or config.")
        admin_ids: List[int] = [
            int(x.strip()) for x in _raw_admins.split(",") if x.strip().isdigit()
        ]
        if not admin_ids:
            raise ValueError(
                "CRITICAL SECURITY ERROR: ADMIN_IDS was provided but "
                "contained no valid numeric IDs.")

        # ---- storage ----
        database_file: str = os.environ.get("DATABASE_FILE", "payload_bot.db")

        # ---- deployment identity ----
        runtime_build_id: str = compute_runtime_build_id(source_file)

        # Bot username is auto-detected at startup via bot.get_me(). It can
        # be seeded from the environment as a fallback, but is overwritten
        # once the bot connects.
        bot_username: str = os.environ.get("BOT_USERNAME", "").lstrip("@")

        # ---- operational toggles / intervals ----
        auto_reindex_interval: int = int(
            os.environ.get("AUTO_REINDEX_INTERVAL", "60"))
        enable_force_join: bool = (
            os.environ.get("ENABLE_FORCE_JOIN", "true").lower() == "true")
        enable_auto_payload: bool = (
            os.environ.get("ENABLE_AUTO_PAYLOAD", "false").lower() == "true")
        auto_reindex_on_startup: bool = (
            os.environ.get("AUTO_REINDEX_ON_STARTUP", "false").lower() == "true")

        # ---- Mini App (Watch Ads) ----
        mini_app_port: int = int(os.environ.get("MINI_APP_PORT", "8080"))
        mini_app_enabled: bool = (
            os.environ.get("MINI_APP_ENABLED", "true").lower() == "true")
        # Production requires HTTPS for Telegram Mini Apps. HTTP may only be
        # permitted when this explicit development switch is set.
        mini_app_dev_allow_http: bool = (
            os.environ.get("MINI_APP_DEV_ALLOW_HTTP", "false").lower() == "true")
        # MINI_APP_BASE_URL is ONLY an optional seed value for
        # watch_ads_mini_app_url; the database value is authoritative and is
        # NEVER overwritten by the environment on restart.
        mini_app_base_url: str = (
            os.environ.get("MINI_APP_BASE_URL", "") or "").strip()

        # ---- Watch Ads ----
        # How long a VERIFIED ad unlock satisfies the Watch Ads requirement
        # (rewarded_at -> unlock_expires_at). Default 180s per the product
        # example.
        watch_ad_unlock_window: int = int(
            os.environ.get("WATCH_AD_UNLOCK_WINDOW", "180"))
        # Anti-spam: max new ad sessions per (user, payload) per hour.
        watch_ad_session_hourly_cap: int = int(
            os.environ.get("WATCH_AD_SESSION_HOURLY_CAP", "10"))

        return RuntimeConfig(
            bot_token=bot_token,
            admin_ids=admin_ids,
            database_file=database_file,
            runtime_build_id=runtime_build_id,
            bot_username=bot_username,
            auto_reindex_interval=auto_reindex_interval,
            enable_force_join=enable_force_join,
            enable_auto_payload=enable_auto_payload,
            auto_reindex_on_startup=auto_reindex_on_startup,
            mini_app_port=mini_app_port,
            mini_app_enabled=mini_app_enabled,
            mini_app_dev_allow_http=mini_app_dev_allow_http,
            mini_app_base_url=mini_app_base_url,
            watch_ad_unlock_window=watch_ad_unlock_window,
            watch_ad_session_hourly_cap=watch_ad_session_hourly_cap,
        )
