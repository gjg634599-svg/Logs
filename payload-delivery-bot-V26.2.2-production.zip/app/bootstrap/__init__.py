"""Application composition root (bootstrap)."""
