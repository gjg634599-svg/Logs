"""TRUSTED FILE DELIVERY (V25 FINAL — TWO-STAGE DELIVERY CHANNEL ARCHITECTURE).

V25 FINAL (bot-35.log + the master continuation prompt) ARCHITECTURE:

    SOURCE / STORAGE CHANNEL
        ↓ Stage A: copyMessage (the File Delivery Bot reads the
          storage master and writes the Delivery Channel message;
          protected-content sources fall back to a fresh file-ID
          identity send INTO the channel)
    DELIVERY CHANNEL (the per-network-bot private channel both the
        FDB and the Network Bot administer — network_bots.
        delivery_channel_chat_id, schema v42)
        ↓ Stage B: copyMessage / copyMessages (the NETWORK BOT — the
          bot the user is actually talking to — performs the FINAL
          user-facing send FROM the Delivery Channel; albums render as
          real Telegram media groups via the copyMessages API)
    NETWORK BOT
        ↓
    DESTINATION USER

The File Delivery Bot is NEVER the final user-facing sender (bot-35.log
FDB_DIRECT_DELIVERY_START/SUCCESS — the bot-34 "channel-only" Mode B —
is REMOVED from production routing). There is NO group-delivery
architecture in production: no delivery groups, no relay groups, no
group setup, no group membership, no group verification, no group-based
fallback and no network relay through a group. The historical evidence
(bot-18.log relay failures, bot-31 job 65 + bot-34 job 78 protected-
content group-hop rejections, bot-35 DELIVERY_GROUP_VERIFY_FAILURE
chat_not_found cycles) is resolved at the root:

  * ``DeliveryJobEngine.deliver`` / ``_deliver_layered`` route every
    job two-stage (Stage A FDB → Delivery Channel, Stage B Network Bot
    → user); the job row carries the DURABLE Stage-A identity
    (delivery_channel_id + delivery_message_id, schema v42);
  * ``is_delivery_ready`` requires the configured Delivery Channel
    (registered + enabled + routable + credential + FDB operational +
    delivery_channel_chat_id);
  * the periodic health loop never re-verifies groups; the admin
    Delivery Center exposes the two-stage topology;
  * legacy delivery-group TABLE rows and job columns survive as
    ISOLATED compatibility data: schema v42 TRANSFERS each legacy
    group chat to the owning bot's delivery_channel_chat_id (the old
    group WAS the intended Delivery Channel); the sweeper still
    TTL-cleans HISTORICAL relay messages and re-routes legacy
    network_relay / fdb_direct / handoff job rows to the two-stage
    plane on retry — but no production routing decision ever reads
    the group table, so legacy data can never re-activate group or
    direct delivery.

  Stage A — FDB → Delivery Channel (FDB_DELIVERY_CHANNEL_COPY_START /
  FDB_DELIVERY_CHANNEL_COPY_SUCCESS / DELIVERY_CHANNEL_MESSAGE_READY):
      copyMessage storage → delivery channel. Protected-content
      storage sources reject the copy deterministically → the FDB
      re-sends the media BY FILE IDENTITY into the channel
      (_send_by_file_identity — a FRESH send: protected-content
      restrictions govern copies, never original sends) creating the
      correct Delivery Channel message. "Message to copy not found"
      → the source is gone → honest source_not_copyable verdict.

  Stage B — Network Bot → user (NETWORK_BOT_COPY_TO_USER_START /
  NETWORK_BOT_COPY_TO_USER_SUCCESS):
      the network bot copyMessage(delivery channel → user) — a TRUE
      copy with NO Forwarded-from header (Hide Source semantics by
      construction; NEVER forward). The user is talking to THIS bot
      (they clicked ITS payload link), so the send succeeds without
      any handoff. A stale/deleted channel message self-heals by
      re-running Stage A. Albums use the copyMessages API (Bot API
      7.17+, PTB >= 21.11) chunked ≤ 10 in order — real Telegram
      media-group presentation — with an honest sequential fallback.

Delivery-state honesty (B17 mandate): DELIVERED is written ONLY after
a real Telegram send returns a message id in the user's chat. A
crash-interrupted job with unknown outcome settles EXPIRED — never a
lying DELIVERED.

Diagnostics (never tokens): NETWORK_DELIVERY_GROUP_ACCESS_CHECK is a
REAL EXECUTABLE diagnostic (DeliveryJobEngine.network_delivery_group_
access_check) that probes with the NETWORK BOT'S OWN client — get_me
identity vs the registered row, get_chat on the delivery chat,
get_chat_member for the bot's own membership/privileges and the FDB's,
source reachability — and classifies every failure into the canonical
taxonomy (RELAY_DELETED / RELAY_INACCESSIBLE_TO_NETWORK_BOT /
GROUP_INACCESSIBLE_TO_NETWORK_BOT / STORAGE_MASTER_INACCESSIBLE_TO_
NETWORK_BOT / MESSAGE_ID_INVALID / MESSAGE_NOT_COPYABLE /
BOT_IDENTITY_MISMATCH / TELEGRAM_API_RESTRICTION / PERMISSION_FAILURE /
THREAD_TOPIC_MISMATCH / UNKNOWN_TELEGRAM_FAILURE) with a correlation id,
the failing hop, attempt and timestamp. "Message to copy not found" is
RELAY_DELETED only when deletion is PROVEN — otherwise the honest class
is RELAY_INACCESSIBLE_TO_NETWORK_BOT.

B18 (bot-19.log) hard honesty rules, on top of B17:
  * The diagnostics run on EVERY failure class — BadRequest,
    ChatNotFound, Forbidden, TimedOut, NetworkError, RetryAfter,
    Telegram server errors and unknown exceptions (RetryAfter logs the
    classification WITHOUT probes — extra API calls under flood control
    would make it worse).
  * NETWORK_BOT_COPY_TO_USER_SUCCESS is the success label for every
    Stage-B user-facing send — first attempt or retry. FDB_DIRECT_
    DELIVERY_SUCCESS (the bot-34 label) is retired from production and
    the legacy NETWORK_DELIVERY_SUCCESS label stays reserved for the
    deprecated network_relay mode; neither is produced by production
    paths.
  * The durable topology marker on the job row (delivery_jobs.
    mode_a_failure / mode_a_failure_at, schema v39) records
    "hide_source_copy_semantics" (§18, setting ON) or
    "delivery_channel_architecture" (setting OFF) so metrics can
    attribute the routing without parsing logs.
  * The delivery Telegram clients (network worker applications + the
    FDB client) use EXPLICIT HTTPX timeouts (read/write 60 s, connect
    30 s) — PTB's 5 s defaults produced the bot-19.log consecutive
    TimedOut failures on large-media copy operations.

Legacy compatibility (isolated, never the production path): the B23-2
HYBRID relay primitives (relay_create_hybrid, copy_from_storage_to_
group, delete_relay_message, verify_delivery_group, reverify_all_
groups, _mode_a_hybrid_relay, _forward_group_to_user and the Mode-A
capability cache) are RETAINED as deprecated tooling for auditing and
cleaning HISTORICAL group state only. bot-18/bot-23/bot-31/bot-34
disproved the group architecture for delivery; nothing in the
production routing calls these surfaces.
"""
from __future__ import annotations

import asyncio
import json
import logging
import secrets
import time
from typing import Any, Callable, Dict, List, Optional

from telegram import Bot, error as tg_error
from telegram.constants import ChatMemberStatus, ChatType

from app.core.constants import (
    DELIVERY_SETTING_MAX_ATTEMPTS,
    DELIVERY_DEFAULT_MAX_ATTEMPTS,
    DELIVERY_SETTING_RELAY_TTL,
    DELIVERY_DEFAULT_RELAY_TTL,
    DELIVERY_SETTING_RETRY_BASE,
    DELIVERY_DEFAULT_RETRY_BASE,
    DELIVERY_SETTING_SWEEP_INTERVAL,
    DELIVERY_DEFAULT_SWEEP_INTERVAL,
    DELIVERY_SETTING_HANDOFF_TTL,
    DELIVERY_DEFAULT_HANDOFF_TTL,
)
from app.storage.repositories.delivery import (
    CRED_CONTROL_PLATFORM,
    DC_BOT_IDENTITY_MISMATCH,
    DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT,
    DC_MESSAGE_ID_INVALID,
    DC_MESSAGE_NOT_COPYABLE,
    DC_PERMISSION_FAILURE,
    DC_RELAY_DELETED,
    DC_RELAY_INACCESSIBLE_TO_NETWORK_BOT,
    DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT,
    DC_TELEGRAM_API_RESTRICTION,
    DC_THREAD_TOPIC_MISMATCH,
    DC_UNKNOWN_TELEGRAM_FAILURE,
    DG_DEGRADED,
    DG_READY,
    DG_SETUP_REQUIRED,
    DG_UNAVAILABLE,
    DG_VERIFYING,
    DM_DELIVERY_CHANNEL,
    DM_FDB_DIRECT,
    DM_HANDOFF,
    DM_NETWORK_RELAY,
    FDB_DEGRADED,
    FDB_DISABLED,
    FDB_READY,
    FDB_TOKEN_INVALID,
    FDB_UNCONFIGURED,
    FDB_WORKER_RUNNING,
    FDB_WORKER_STOPPED,
    JOB_CREATED,
    JOB_DELETE_PENDING,
    JOB_DELETED,
    JOB_DELIVERED,
    JOB_DELIVERING,
    JOB_EXPIRED,
    JOB_FAILED,
    JOB_HANDOFF_PENDING,
    JOB_RELAYED,
    JOB_RELAY_CREATING,
    MGMT_PLATFORM_MANAGED,
)
from app.storage.dbutil import safe_row_get as _safe_row_get

logger = logging.getLogger("payload-bot")

# Required File Delivery Bot administrator privileges inside a Delivery
# Channel (V25 FINAL): only what the channel genuinely needs — delete
# messages + invite-free membership. The network bot stays an ORDINARY
# member (its Stage-B copy only needs read access).
_FDB_REQUIRED_ADMIN_PRIVILEGES = ("can_delete_messages",)

# V25 FINAL §6/§7 — album semantics (mirrors the presentation-layer
# constants): photo/video/animation form Telegram media groups; the
# copyMessages chunks are capped at Telegram's 10-per-group limit,
# delivered in the collection's canonical order.
ALBUM_ELIGIBLE_TYPES = ("photo", "video", "animation")
ALBUM_MAX_ITEMS = 10

# ---------------------------------------------------------------------------
# B18 (bot-19.log) — explicit Telegram HTTP timeouts for the DELIVERY
# clients. PTB's HTTPXRequest defaults are read=5s / write=5s / connect=5s
# / pool=1s; bot-19.log 03:35:12-24 shows TWO consecutive TimedOut
# failures on the SAME Mode-A copy (and 03:34:04 the same worker's
# set_chat_menu_button TimedOut) — the 5 s read bound is too short for
# large-media copyMessage operations (the storage master there was an
# 856 MB video) and for transient Telegram/server slowness. The fallback
# semantics stay UNCHANGED (TimedOut remains transient, bounded retries,
# then Mode B) — this raises the headroom so a merely-slow Telegram no
# longer fails the hop.
# ---------------------------------------------------------------------------
TELEGRAM_HTTP_READ_TIMEOUT = 60.0
TELEGRAM_HTTP_WRITE_TIMEOUT = 60.0
TELEGRAM_HTTP_CONNECT_TIMEOUT = 30.0
TELEGRAM_HTTP_POOL_TIMEOUT = 30.0


# ---------------------------------------------------------------------------
# FINAL-1 (bot-20.log) — the Mode-A negative-capability cache TTL.
# Job 38's storage "Chat not found" poisoned (network_bot_id, storage)
# for the whole process life; jobs 39/40+ then skipped Mode A with
# capability_cached_no even after the operator could have fixed storage
# membership. 300 s aligns the TTL with the periodic delivery-group
# health pass (NET_SETTING_HEALTH_INTERVAL default), so a cached "no"
# is re-probed at most one health pass later — and refresh_mode_a_
# capability() can restore it sooner the moment access returns.
# ---------------------------------------------------------------------------
MODE_A_NEGATIVE_TTL = 300.0


def _delivery_httpx_request_kwargs() -> Dict[str, Any]:
    """The explicit HTTPXRequest timeout kwargs every DELIVERY Telegram
    client must use (network worker applications + the FDB manager's
    client). Centralized so tests can pin it (B18 regression) and the
    values can be tuned in ONE place."""
    return {
        "read_timeout": TELEGRAM_HTTP_READ_TIMEOUT,
        "write_timeout": TELEGRAM_HTTP_WRITE_TIMEOUT,
        "connect_timeout": TELEGRAM_HTTP_CONNECT_TIMEOUT,
        "pool_timeout": TELEGRAM_HTTP_POOL_TIMEOUT,
    }


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# B17 FINAL VERIFICATION — the canonical Telegram delivery-failure
# classifier (NETWORK_DELIVERY_GROUP_ACCESS_CHECK's taxonomy).
# ---------------------------------------------------------------------------
def classify_telegram_delivery_failure(exc: BaseException, *,
                                       deletion_proven: bool = False,
                                       failing_hop: Optional[str] = None,
                                       group_reachable: Optional[bool] = None,
                                       storage_reachable: Optional[bool] = None,
                                       ) -> Dict[str, Any]:
    """Map ANY Telegram delivery-hop exception to EXACTLY ONE canonical
    classification (DELIVERY_FAILURE_CLASSIFICATIONS) + routing hints.

    Hard honesty rule (bot-18.log): BadRequest("Message to copy not
    found") is classified ``RELAY_DELETED`` ONLY when deletion has
    actually been proven (``deletion_proven=True`` — e.g. our own
    delete_relay_message observed success). Without proof it is
    ``RELAY_INACCESSIBLE_TO_NETWORK_BOT`` — the exact root cause that
    made the B16 relay architecture undeliverable (Telegram never lets
    one bot copy a message authored by a different bot; the message
    never enters the copying bot's cache).

    B18 hard honesty rule (bot-19.log 03:18:30): on a relay-create hop
    that READS FROM the Storage master INTO the group
    (``failing_hop='mode_a_relay_create'`` — the legacy network-bot copy
    — or ``'fdb_relay_create'`` — the B23-2 HYBRID hop 1, the FDB's
    copyMessage) a BadRequest "Chat not found" is NOT automatically a
    group problem. When the access check has already proven the group
    reachable (``group_reachable=True``) and the Storage chat
    unreachable (``storage_reachable=False``) for the client that
    READS the storage master, the honest classification is
    ``STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT`` — a healthy delivery
    group must never be marked lost because the STORAGE channel is the
    invisible one. Without probe evidence the legacy
    GROUP_INACCESSIBLE class is kept (the caller's access check then
    re-classifies with evidence).

    Returns ``{"classification": str, "retryable": bool, "detail": str}``.
    Never raises — classification itself failing falls back to
    UNKNOWN_TELEGRAM_FAILURE.
    """
    try:
        text = str(exc)
        low = text.lower()
        name = type(exc).__name__
        retry_after = getattr(exc, "retry_after", None)
        if retry_after is not None or "too many requests" in low:
            return {"classification": DC_TELEGRAM_API_RESTRICTION,
                    "retryable": True, "detail": text[:160]}
        if name == "Forbidden" or low == "forbidden":
            return {"classification": DC_PERMISSION_FAILURE,
                    "retryable": False, "detail": text[:160]}
        if "message to copy not found" in low \
                or "message to forward not found" in low:
            if deletion_proven:
                return {"classification": DC_RELAY_DELETED,
                        "retryable": False, "detail": text[:160]}
            # NOT proven deleted — the honest class is INACCESSIBLE (the
            # copying bot cannot see the message; may or may not exist).
            return {"classification": DC_RELAY_INACCESSIBLE_TO_NETWORK_BOT,
                    "retryable": False, "detail": text[:160]}
        if "message identifier is invalid" in low \
                or "message id is invalid" in low \
                or "message_id_invalid" in low:
            return {"classification": DC_MESSAGE_ID_INVALID,
                    "retryable": False, "detail": text[:160]}
        if "can't be copied" in low or "cannot be copied" in low \
                or "can't be forwarded" in low or "not copyable" in low:
            return {"classification": DC_MESSAGE_NOT_COPYABLE,
                    "retryable": False, "detail": text[:160]}
        if "message thread not found" in low \
                or "thread not found" in low or "topic_closed" in low \
                or "topic_deleted" in low or "topic mismatch" in low:
            return {"classification": DC_THREAD_TOPIC_MISMATCH,
                    "retryable": False, "detail": text[:160]}
        if "chat not found" in low or "bot is not a member" in low \
                or "bot was kicked" in low \
                or "chat_send_write_forbidden" in low:
            # B18: WHICH chat is the inaccessible one? On the Mode-A hop
            # the copy READS from the Storage master — with probe evidence
            # (group reachable + storage NOT) the failure is the STORAGE
            # channel, not the group. Only without evidence (or with the
            # group proven unreachable) does the group take the blame.
            if failing_hop in ("mode_a_relay_create", "fdb_relay_create") \
                    and group_reachable is True \
                    and storage_reachable is False:
                return {
                    "classification":
                        DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT,
                    "retryable": False,
                    "detail": ("network bot cannot see the Storage master "
                               "(group verified reachable): " + text[:110])}
            return {"classification": DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT,
                    "retryable": False, "detail": text[:160]}
        if "not enough rights" in low \
                or "need administrator rights" in low \
                or "rights restricted" in low:
            return {"classification": DC_PERMISSION_FAILURE,
                    "retryable": False, "detail": text[:160]}
        if name in ("TimedOut", "NetworkError", "TimeoutError") \
                or "timed out" in low or "network" in low:
            # Transport-level failure — retryable, but the taxonomy has no
            # dedicated transport class; UNKNOWN keeps the detail honest.
            return {"classification": DC_UNKNOWN_TELEGRAM_FAILURE,
                    "retryable": True, "detail": text[:160]}
        return {"classification": DC_UNKNOWN_TELEGRAM_FAILURE,
                "retryable": True, "detail": text[:160]}
    except Exception:  # noqa: BLE001 — classification must never raise
        return {"classification": DC_UNKNOWN_TELEGRAM_FAILURE,
                "retryable": True, "detail": ""}


def _verdict_is_protected_content(verdict) -> bool:
    """V25 §7/§8: does a delivery verdict string carry Telegram's
    deterministic protected-content rejection?

    Bot API text: "Message has protected content and can't be forwarded"
    (forwardMessage AND copyMessage both reject protected sources with the
    same class). The verdict here is the classified ``bad_request:<detail>``
    string the hop functions return — matched on the canonical
    classification constant OR the raw Telegram text (either surface).
    """
    if not verdict:
        return False
    v = str(verdict).lower()
    return (DC_MESSAGE_NOT_COPYABLE.lower() in v
            or "protected content" in v
            or "can't be forwarded" in v
            or "cannot be forwarded" in v)


async def _validate_bot_token_via_telegram(token: str) -> Dict[str, Any]:
    """getMe against the REAL Telegram Bot API (token never logged).

    Returns {"ok": True, "id": int, "username": str, "first_name": str}
    or {"ok": False, "reason": "invalid_token"|"telegram_unreachable"}.
    Same contract as the registry's validator so both paths stay honest.
    """
    import aiohttp
    try:
        async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15)) as sess:
            async with sess.get(
                    f"https://api.telegram.org/bot{token}/getMe") as resp:
                data = await resp.json(content_type=None)
    except Exception:  # noqa: BLE001 — transport failure is a verdict
        return {"ok": False, "reason": "telegram_unreachable"}
    if resp_status_ok(data) and data.get("result"):
        r = data["result"]
        return {"ok": True, "id": int(r.get("id") or 0),
                "username": str(r.get("username") or "").lstrip("@"),
                "first_name": str(r.get("first_name") or "")}
    desc = str(data.get("description") or "").lower()
    if "unauthorized" in desc or resp_status_unauthorized(data):
        return {"ok": False, "reason": "invalid_token"}
    return {"ok": False, "reason": "invalid_token"}


def resp_status_ok(data: Dict[str, Any]) -> bool:
    return bool(data.get("ok"))


def resp_status_unauthorized(data: Dict[str, Any]) -> bool:
    return str(data.get("description") or "").lower().startswith("unauthorized")


# ---------------------------------------------------------------------------
# File Delivery Bot manager
# ---------------------------------------------------------------------------
class FileDeliveryBotManager:
    """Platform-owned trusted relay authority (spec §21/§24/§37).

    Lifecycle:
        UNCONFIGURED → (add/validate token via Control Bot OR
        FILE_DELIVERY_BOT_TOKEN env seed) → READY (client initialized +
        storage access verified) ⇄ DEGRADED / TOKEN_INVALID / DISABLED.

    The token is persisted ONLY as the vault-encrypted blob; the in-memory
    client holds the live credential.
    """

    def __init__(self, db, vault, *, local_api: Optional[Dict[str, str]] = None
                 ) -> None:
        self.db = db
        self.vault = vault
        self._client: Optional[Bot] = None
        self._token: Optional[str] = None
        self._health_task: Optional[asyncio.Task] = None
        self._sweeper: Optional[asyncio.Task] = None
        # B17 — the deep-link handoff poller (the FDB's ONLY inbound
        # update surface; getUpdates long-poll for /start dl<token>).
        self._poll_task: Optional[asyncio.Task] = None
        self._running = False
        self._local_api = local_api or None
        # Set by the wiring layer: async (job) -> None — the delivery job
        # sweeper loop (owned by DeliveryJobEngine.start).
        self.job_sweeper: Optional[Any] = None
        # FINAL-1: set by the wiring layer — nid → the network bot's LIVE
        # client (the worker manager's get_bot_client). Used by
        # verify_delivery_group to probe the NETWORK BOT's storage access
        # separately from the FDB's (the bot-20.log "storage_access=full"
        # label measured the FDB while claiming the network bot), and by
        # DeliveryJobEngine.refresh_mode_a_capability to restore stale
        # negative Mode-A verdicts. Optional — absence degrades to the
        # honest "unknown", never a fabricated capability.
        self.network_bot_client_resolver: Optional[
            Callable[[int], Any]] = None

    # ------------------------------------------------------------------
    # Readiness / introspection
    # ------------------------------------------------------------------
    @property
    def configured(self) -> bool:
        return self._client is not None

    @property
    def bot_username(self) -> str:
        return getattr(self._client, "username", None) or ""

    @property
    def telegram_bot_id(self) -> Optional[int]:
        return getattr(self._client, "id", None)

    def client(self) -> Optional[Bot]:
        return self._client

    async def status_snapshot(self) -> Dict[str, Any]:
        """Safe panel snapshot (spec §24) — identity/state, never the token."""
        row = await self.db.get_file_delivery_bot()
        return {
            "configured": self.configured,
            "status": (row or {}).get("status") or FDB_UNCONFIGURED,
            "username": (row or {}).get("username") or self.bot_username,
            "telegram_bot_id": (row or {}).get("telegram_bot_id")
            or self.telegram_bot_id,
            "storage_access": (row or {}).get("storage_access") or "unknown",
            "worker_state": (row or {}).get("worker_state")
            or FDB_WORKER_STOPPED,
            "last_health_check": (row or {}).get("last_health_check"),
            "last_error": (row or {}).get("last_error"),
            "running": self._running,
        }

    async def is_operational(self) -> bool:
        """Operational = configured + not disabled + healthy client."""
        snap = await self.status_snapshot()
        return (self.configured
                and snap["status"] in (FDB_READY, FDB_DEGRADED))

    # ------------------------------------------------------------------
    # Token lifecycle (spec §25)
    # ------------------------------------------------------------------
    async def configure_token(self, token: str, *,
                              actor_user_id: Optional[int] = None,
                              audit_event: str = "FILE_DELIVERY_BOT_TOKEN_VALIDATED"
                              ) -> Dict[str, Any]:
        """Validate + persist + bind a token (ADD or CHANGE).

        Order (spec §25 — never destroy the working credential first):
        1. getMe validation (real Telegram);
        2. identity confirmation;
        3. encrypt (fail-closed without NETWORK_TOKEN_ENCRYPTION_KEY);
        4. atomic persist (upsert singleton row);
        5. rebind live client;
        6. verify health (getMe through the bound client);
        7. only then retire the old in-memory token.
        """
        token = (token or "").strip()
        if not token or ":" not in token:
            return {"ok": False, "reason": "bad_token_format"}
        if not self.vault.can_encrypt:
            return {"ok": False, "reason": "encryption_key_missing"}
        verdict = await _validate_bot_token_via_telegram(token)
        if not verdict.get("ok"):
            return {"ok": False, "reason": verdict.get("reason",
                                                       "invalid_token")}
        old_row = await self.db.get_file_delivery_bot_credential()
        event = ("FILE_DELIVERY_BOT_TOKEN_CHANGED" if old_row
                 and old_row.get("encrypted_token")
                 else audit_event)
        blob = self.vault.encrypt(token)
        client = await self._make_client(token)
        # Health-verify through the BOUND client before persisting.
        try:
            me = await client.get_me()
            uname = (getattr(me, "username", "") or "").lstrip("@")
            tg_id = int(getattr(me, "id", 0) or 0)
        except Exception:  # noqa: BLE001 — new client failed: keep old live
            return {"ok": False, "reason": "telegram_unreachable"}
        storage_access = await self._probe_storage_access(client)
        await self.db.upsert_file_delivery_bot(
            username=uname, telegram_bot_id=tg_id, encrypted_token=blob,
            key_version=self.vault.key_version, status=FDB_READY,
            storage_access=storage_access, worker_state=(
                FDB_WORKER_RUNNING if self._running else FDB_WORKER_STOPPED))
        # Only after full success: swap the live credential.
        self._client, self._token = client, token
        await self.db.insert_control_audit_event(
            event, actor_user_id=actor_user_id,
            detail=f"username=@{uname} storage={storage_access}")
        logger.info("FILE_DELIVERY_BOT_TOKEN_CONFIGURED username=@%s "
                    "storage_access=%s credential=protected "
                    "(token never logged)", uname, storage_access)
        # V25 FINAL: the handoff poller (the FDB-direct completion
        # surface for legacy deep-link jobs) is NO LONGER auto-started —
        # production delivery is two-stage (FDB → Delivery Channel →
        # Network Bot → user) and new jobs never enter HANDOFF_PENDING;
        # legacy pending rows settle via their own TTL. The poller
        # primitive survives for isolated/legacy compat use only.
        logger.info(
            "FDB_HANDOFF_POLLER_NOT_STARTED reason=final_architecture "
            "(V25 FINAL: production delivery is two-stage — the FDB never "
            "sends to users; legacy HANDOFF_PENDING rows TTL-expire)")
        return {"ok": True, "username": uname, "telegram_bot_id": tg_id,
                "storage_access": storage_access}

    async def change_token(self, new_token: str, *,
                           actor_user_id: Optional[int] = None
                           ) -> Dict[str, Any]:
        """Spec §25 change flow — validate FIRST, atomic swap, health
        verify, old credential retired only after successful replacement."""
        return await self.configure_token(
            new_token, actor_user_id=actor_user_id,
            audit_event="FILE_DELIVERY_BOT_TOKEN_CHANGED")

    async def rotate_network_bot_credential(self, network_bot_id: int,
                                            new_token: str, *,
                                            actor_user_id: Optional[int] = None
                                            ) -> Dict[str, Any]:
        """Platform-admin credential rotation for a MANAGED network bot
        (spec §64 ROTATE). Validated first; the existing worker is only
        rebound after the atomic credential replacement succeeds."""
        if not self.vault.can_encrypt:
            return {"ok": False, "reason": "encryption_key_missing"}
        verdict = await _validate_bot_token_via_telegram(new_token)
        if not verdict.get("ok"):
            return {"ok": False, "reason": verdict.get("reason",
                                                       "invalid_token")}
        bot = await self.db.get_network_bot(int(network_bot_id))
        if not bot:
            return {"ok": False, "reason": "bot_not_found"}
        if verdict.get("id") and int(bot["telegram_bot_id"]) \
                and int(verdict["id"]) != int(bot["telegram_bot_id"]):
            return {"ok": False, "reason": "identity_mismatch"}
        blob = self.vault.encrypt(new_token)
        await self.db.replace_network_bot_credential(
            int(network_bot_id), encrypted_token=blob,
            key_version=self.vault.key_version)
        await self.db.insert_control_audit_event(
            "MANAGED_NETWORK_BOT_TOKEN_ROTATED", actor_user_id=actor_user_id,
            network_bot_id=int(network_bot_id),
            detail=f"username=@{verdict.get('username')}")
        logger.info("MANAGED_NETWORK_BOT_TOKEN_ROTATED network_bot_id=%s "
                    "credential=protected (token never logged)",
                    network_bot_id)
        return {"ok": True, "username": verdict.get("username")}

    async def validate_current(self) -> Dict[str, Any]:
        """[✅ Validate] — live getMe through the bound client (spec §24)."""
        if not self._client:
            return {"ok": False, "reason": "not_configured"}
        try:
            me = await self._client.get_me()
            await self.db.update_file_delivery_bot(
                status=FDB_READY, last_health_check=_now_iso(),
                last_error=None,
                username=(getattr(me, "username", "") or "").lstrip("@"),
                telegram_bot_id=int(getattr(me, "id", 0) or 0))
            return {"ok": True,
                    "username": (getattr(me, "username", "") or "").lstrip("@")}
        except Exception as exc:  # noqa: BLE001
            await self.db.update_file_delivery_bot(
                status=FDB_TOKEN_INVALID, last_health_check=_now_iso(),
                last_error=str(exc)[:200])
            return {"ok": False, "reason": "invalid_token"}

    async def disable(self, *, actor_user_id: Optional[int] = None
                      ) -> Dict[str, Any]:
        await self.db.update_file_delivery_bot(
            status=FDB_DISABLED, worker_state=FDB_WORKER_STOPPED)
        await self.db.insert_control_audit_event(
            "FILE_DELIVERY_BOT_DISABLED", actor_user_id=actor_user_id)
        logger.info("FILE_DELIVERY_BOT_DISABLED (relay delivery paused; "
                    "credential retained encrypted)")
        return {"ok": True}

    async def restart(self, *, actor_user_id: Optional[int] = None
                      ) -> Dict[str, Any]:
        """[🔄 Restart] — rebind from the stored credential + health check."""
        row = await self.db.get_file_delivery_bot_credential()
        if not row or not row.get("encrypted_token"):
            return {"ok": False, "reason": "not_configured"}
        try:
            token = self.vault.decrypt(row["encrypted_token"])
        except Exception:  # noqa: BLE001
            return {"ok": False, "reason": "decrypt_failed"}
        client = await self._make_client(token)
        try:
            await client.get_me()
        except Exception:  # noqa: BLE001
            await self.db.update_file_delivery_bot(
                status=FDB_TOKEN_INVALID, last_health_check=_now_iso())
            return {"ok": False, "reason": "invalid_token"}
        self._client, self._token = client, token
        storage = await self._probe_storage_access(client)
        await self.db.update_file_delivery_bot(
            status=FDB_READY, storage_access=storage,
            worker_state=(FDB_WORKER_RUNNING if self._running
                          else FDB_WORKER_STOPPED),
            last_health_check=_now_iso(), last_error=None)
        logger.info("FILE_DELIVERY_BOT_RESTARTED storage_access=%s", storage)
        # V25 FINAL: the handoff poller is NOT restarted on the fresh
        # client (production delivery is two-stage — see configure_token).
        return {"ok": True, "storage_access": storage}

    # ------------------------------------------------------------------
    # Startup / shutdown
    # ------------------------------------------------------------------
    async def start(self) -> None:
        """Bind from the DB credential (or the env seed) + start tasks."""
        row = await self.db.get_file_delivery_bot_credential()
        token: Optional[str] = None
        if row and row.get("encrypted_token"):
            try:
                token = self.vault.decrypt(row["encrypted_token"])
            except Exception:  # noqa: BLE001
                logger.error("FILE_DELIVERY_BOT_CREDENTIAL_DECRYPT_FAILED "
                             "(stored credential unreadable — reconfigure "
                             "via the Control Bot)")
                await self.db.update_file_delivery_bot(
                    status=FDB_TOKEN_INVALID,
                    last_error="credential decrypt failed")
        elif self._env_seed_token:
            # First boot with FILE_DELIVERY_BOT_TOKEN set and no stored
            # credential: seed the encrypted store (spec §25 config path).
            await self.configure_token(self._env_seed_token,
                                       audit_event=(
                                           "FILE_DELIVERY_BOT_CONFIG_STARTED"))
            token = self._token
        if token:
            client = await self._make_client(token)
            try:
                await client.get_me()
                self._client, self._token = client, token
                storage = await self._probe_storage_access(client)
                await self.db.update_file_delivery_bot(
                    status=FDB_READY, storage_access=storage,
                    worker_state=FDB_WORKER_RUNNING,
                    last_health_check=_now_iso(), last_error=None)
            except Exception as exc:  # noqa: BLE001
                logger.error("FILE_DELIVERY_BOT_START_FAILED error=%s",
                             str(exc)[:200])
                await self.db.update_file_delivery_bot(
                    status=FDB_TOKEN_INVALID, last_error=str(exc)[:200])
        else:
            logger.warning(
                "FILE_DELIVERY_BOT_UNCONFIGURED — relay delivery OFF. "
                "Configure via the Control Bot (panel → File Delivery Bot "
                "→ Add Token) or set FILE_DELIVERY_BOT_TOKEN.")
        self._running = True
        await self.db.update_file_delivery_bot(
            worker_state=FDB_WORKER_RUNNING
            if self._client else FDB_WORKER_STOPPED)
        self._health_task = asyncio.create_task(self._health_loop())
        # V25 FINAL — the deep-link handoff poller is NOT started: new
        # jobs never enter HANDOFF_PENDING (two-stage architecture — the
        # FDB never sends to users); legacy pending rows settle via their
        # own TTL. The poller primitive survives for isolated/legacy
        # compat use only.

    _env_seed_token: Optional[str] = None

    def set_env_seed_token(self, token: Optional[str]) -> None:
        self._env_seed_token = (token or "").strip() or None

    async def stop(self) -> None:
        self._running = False
        await self.stop_handoff_poller()
        if self._health_task:
            self._health_task.cancel()
            try:
                await self._health_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._health_task = None
        await self.db.update_file_delivery_bot(worker_state=FDB_WORKER_STOPPED)
        self._client, self._token = None, None

    async def _health_loop(self) -> None:
        interval = 300
        while True:
            await asyncio.sleep(interval)
            try:
                if self._client is None:
                    continue
                await self._client.get_me()
                storage = await self._probe_storage_access(self._client)
                await self.db.update_file_delivery_bot(
                    status=FDB_READY, storage_access=storage,
                    last_health_check=_now_iso(), last_error=None)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                await self.db.update_file_delivery_bot(
                    status=FDB_DEGRADED, last_health_check=_now_iso(),
                    last_error=str(exc)[:200])
                logger.warning("FILE_DELIVERY_BOT_HEALTH_CHECK_FAILED %s",
                               str(exc)[:120])

    # ------------------------------------------------------------------
    # Telegram primitives
    # ------------------------------------------------------------------
    async def _make_client(self, token: str) -> Bot:
        # B18 (bot-19.log): explicit HTTPXRequest timeouts — PTB's 5 s
        # defaults produced consecutive TimedOut failures on large-media
        # copy operations. The delivery client needs headroom (see
        # TELEGRAM_HTTP_READ_TIMEOUT above).
        from telegram.request import HTTPXRequest
        kwargs = _delivery_httpx_request_kwargs()
        if self._local_api:
            return Bot(token=token, base_url=self._local_api["base_url"],
                       base_file_url=self._local_api["base_file_url"],
                       request=HTTPXRequest(**kwargs))
        return Bot(token=token, request=HTTPXRequest(**kwargs))

    async def _probe_storage_access(self, client: Bot) -> str:
        """getChat on every ACTIVE storage channel (spec §24 Storage Access).

        'full' = every active channel reachable; 'partial' = some;
        'none' = no channel reachable (relay delivery cannot source files).
        """
        try:
            channels = await self.db.list_storage_channels(active_only=True)
        except Exception:  # noqa: BLE001
            return "unknown"
        if not channels:
            return "none"
        ok = 0
        for ch in channels:
            try:
                await client.get_chat(int(ch["channel_id"]))
                ok += 1
            except Exception:  # noqa: BLE001
                continue
        if ok == len(channels):
            return "full"
        return "partial" if ok else "none"

    # ------------------------------------------------------------------
    # Relay operations (spec §49/§50) — the ONLY storage-copy authority
    # ------------------------------------------------------------------
    async def copy_from_storage_to_group(self, delivery_group_chat_id: int,
                                         storage_chat_id: int,
                                         storage_message_id: int,
                                         *, protect_content: bool = False
                                         ) -> Optional[int]:
        """RELAY CREATE: copyMessage storage → delivery group.

        Returns the relay message id, or None (caller classifies).

        BOT-16 FIX — the relay message is an INTERNAL, short-lived platform
        message inside a private, platform-owned delivery group. It is
        created WITHOUT ``protect_content`` (the parameter is accepted for
        backward compatibility but deliberately NOT forwarded): a relay
        marked protected could be rejected by Telegram when the NETWORK
        bot copies it onward ("message to copy not found" — the exact
        bot-16.log production failure for jobs 28/29). Content protection
        is applied ONLY on the final user-facing hop (network bot → user).
        """
        if not self._client:
            logger.error("RELAY_CREATE_FAILED reason=fdb_unconfigured")
            return None
        logger.info("RELAY_CREATE_START group=%s src=%s/%s",
                    delivery_group_chat_id, storage_chat_id,
                    storage_message_id)
        try:
            # BOT-12 §5: PTB 22.8 signature is
            # copy_message(chat_id=..., from_chat_id=..., message_id=...).
            # The historical 'from_message_id' keyword produced 135×
            # RELAY_CREATE_FAILED in bot-14.log — regression-locked by
            # tests/test_bot12_delivery_ptb_signature.py.
            msg = await self._client.copy_message(
                chat_id=int(delivery_group_chat_id),
                from_chat_id=int(storage_chat_id),
                message_id=int(storage_message_id))
            mid = getattr(msg, "message_id", None)
            if mid:
                logger.info(
                    "RELAY_MESSAGE_CREATED job_ref=inline group=%s "
                    "src=%s/%s relay_message_id=%s protect=off(relay)",
                    delivery_group_chat_id, storage_chat_id,
                    storage_message_id, mid)
            return int(mid) if mid else None
        except tg_error.RetryAfter as exc:
            await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            return await self.copy_from_storage_to_group(
                delivery_group_chat_id, storage_chat_id, storage_message_id)
        except Exception as exc:  # noqa: BLE001 — classified by caller
            logger.error("RELAY_CREATE_FAILED group=%s src=%s/%s "
                         "error_class=%s error=%s",
                         delivery_group_chat_id, storage_chat_id,
                         storage_message_id, type(exc).__name__,
                         str(exc)[:160])
            return None

    # ------------------------------------------------------------------
    # B23-2 — HYBRID delivery primitives (the FDB owns hop 1)
    # ------------------------------------------------------------------
    async def probe_storage_chat(self, storage_chat_id: int) -> Optional[bool]:
        """B23-2 §2.1 — getChat(storage_chat) with the FDB'S OWN client.

        Under HYBRID the storage-master hop belongs to the FDB (it performs
        hop 1: copyMessage storage → group), so storage reachability for
        the delivery pipeline is measured with the FDB's client — never
        the network bot's (the bot-23.log misattribution: the network bot
        cannot see Storage and does not need to). Returns True (reachable
        for the FDB) / False (unreachable), or None when no live FDB
        client / probe method exists (the honest unknown — never a
        fabricated verdict in either direction).
        """
        if not self._client:
            return None
        get_chat = getattr(self._client, "get_chat", None)
        if not callable(get_chat):
            return None
        try:
            await get_chat(int(storage_chat_id))
            return True
        except Exception:  # noqa: BLE001 — unreachable IS the verdict
            return False

    async def relay_create_hybrid(self, group_chat: int, storage_chat: int,
                                  storage_msg: int, *, job_id: int = 0
                                  ) -> tuple:
        """B23-2 HYBRID HOP 1 — the FDB'S OWN client performs
        copyMessage(Storage master → Delivery Group).

        bot-23.log evidence: the Network Bot (administrator of the
        Delivery Group -1003963643527) could NOT see the Storage channel
        -1004460709020, so the old Mode A (network-bot-authored relay)
        failed "Chat not found" on every job; the FDB CAN see Storage
        (fdb_storage_access=full) and is administrator of the group.
        HYBRID keeps the NETWORK BOT as the user-facing sender (hop 2
        forwardMessage group → user) while the FDB authors the
        short-lived group relay message here.

        Protection NEVER applies on this internal hop (the BOT-16 relay
        policy kept verbatim — protection belongs on the user-facing hop
        only).

        Unlike copy_from_storage_to_group this classifies failures
        WITHOUT swallowing them. Returns ``(relay_message_id | None,
        verdict)``:
          ``ok``                    — relay created (real message id);
          ``unconfigured``          — no live FDB client;
          ``no_message_id``         — Telegram answered without a mid;
          ``forbidden_group``       — Forbidden on the copy;
          ``bad_request:<text>``    — deterministic Telegram rejection
                                      (the real text is kept; the caller
                                      runs the §2.6 evidence probe for
                                      the authoritative classification);
          ``transient``             — transport hiccup (retryable).
        §2.6 ordering: the FIRST BadRequest emitter logs
        classification=UNKNOWN_TELEGRAM_FAILURE probe=pending_evidence —
        never a speculative pre-probe class.
        """
        from telegram.error import BadRequest, Forbidden, RetryAfter
        if not self._client:
            logger.error("FDB_RELAY_CREATE_FAILED reason=fdb_unconfigured "
                         "group=%s src=%s/%s", group_chat, storage_chat,
                         storage_msg)
            return None, "unconfigured"
        for attempt in (1, 2):
            try:
                msg = await self._client.copy_message(
                    chat_id=int(group_chat),
                    from_chat_id=int(storage_chat),
                    message_id=int(storage_msg))
                mid = int(getattr(msg, "message_id", 0) or 0) or None
                if mid is None:
                    return None, "no_message_id"
                if job_id:
                    logger.info("FDB_RELAY_CREATE_SUCCESS job_id=%s "
                                "group_msg=%s group=%s src=%s/%s "
                                "protect=off(relay)",
                                int(job_id), mid, group_chat, storage_chat,
                                storage_msg)
                return mid, "ok"
            except RetryAfter as exc:
                ra = int(getattr(exc, "retry_after", 3))
                logger.warning("FDB_RELAY_CREATE_RETRY_AFTER group=%s "
                               "src=%s/%s retry_after=%ss attempt=%s "
                               "classification=%s (flood control — no "
                               "probes while rate-limited)",
                               group_chat, storage_chat, storage_msg, ra,
                               attempt, DC_TELEGRAM_API_RESTRICTION)
                await asyncio.sleep(ra + 1)
            except Forbidden as exc:
                logger.warning("FDB_RELAY_CREATE_FORBIDDEN group=%s "
                               "src=%s/%s error=%s", group_chat, storage_chat,
                               storage_msg, str(exc)[:160])
                return None, "forbidden_group"
            except BadRequest as exc:
                # §2.6 FIRST emitter — the classification is UNKNOWN until
                # the caller's evidence probe (network_delivery_group_
                # access_check) classifies with proof.
                logger.warning("FDB_RELAY_CREATE_BAD_REQUEST group=%s "
                               "src=%s/%s error=%s "
                               "classification=UNKNOWN_TELEGRAM_FAILURE "
                               "probe=pending_evidence",
                               group_chat, storage_chat, storage_msg,
                               str(exc)[:200])
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning("FDB_RELAY_CREATE_TRANSIENT attempt=%s "
                               "group=%s src=%s/%s error_class=%s error=%s",
                               attempt, group_chat, storage_chat, storage_msg,
                               type(exc).__name__, str(exc)[:120])
                await asyncio.sleep(1.5)
        return None, "transient"

    async def delete_relay_message(self, delivery_group_chat_id: int,
                                   relay_message_id: int) -> bool:
        """RELAY DELETE: remove a temporary relay message the FDB created.

        NEVER touches Storage master messages (spec §38) — the chat id is
        always the delivery group; the sweeper only feeds ids recorded in
        delivery_jobs.relay_message_id for that same group.
        """
        if not self._client:
            return False
        try:
            await self._client.delete_message(
                chat_id=int(delivery_group_chat_id),
                message_id=int(relay_message_id))
            logger.info("RELAY_MESSAGE_DELETED group=%s relay_message_id=%s",
                        delivery_group_chat_id, relay_message_id)
            return True
        except tg_error.BadRequest as exc:
            low = str(exc).lower()
            if "message to delete not found" in low:
                # Already deleted — idempotent success (spec §56).
                return True
            logger.warning("RELAY_DELETE_REJECTED group=%s id=%s error=%s",
                           delivery_group_chat_id, relay_message_id,
                           str(exc)[:120])
            return False
        except Exception as exc:  # noqa: BLE001
            logger.warning("RELAY_DELETE_FAILED group=%s id=%s error=%s",
                           delivery_group_chat_id, relay_message_id,
                           str(exc)[:120])
            return False

    async def delete_delivery_channel_message(
            self, delivery_channel_id: int, message_id: int,
            *, job_id: Optional[int] = None) -> str:
        """V26.x Phase 3 — DELIVERY CHANNEL SOURCE DELETE.

        Removes the exact Delivery Channel message the FDB itself created
        at Stage A (the FDB is the message AUTHOR — it holds the delete
        right; the Network Bot only ever READ from this message). Called
        AFTER the user delivery is CONFIRMED (the job's user_message_id
        exists) — never before, never speculatively.

        The Storage Channel MASTER is never touched (spec §38: only this
        Delivery Channel message dies).

        Returns a verdict string:
          ``ok``            — deleted (or already gone — idempotent);
          ``retry_after``   — Telegram flood limit (caller retries);
          ``forbidden``     — the FDB lost the delete permission
                              (reported, the record is preserved for the
                              reconciliation sweeper);
          ``failed:<text>`` — any other honest failure (same handling);
          ``unconfigured``  — no live FDB client.
        """
        if not self._client:
            logger.error(
                "FDB_DELIVERY_CHANNEL_DELETE_FAILED reason=fdb_unconfigured"
                " job_id=%s delivery_channel_id=%s message_id=%s",
                int(job_id or 0), int(delivery_channel_id), int(message_id))
            return "unconfigured"
        from telegram.error import RetryAfter
        try:
            await self._client.delete_message(
                chat_id=int(delivery_channel_id),
                message_id=int(message_id))
            logger.info(
                "FDB_DELIVERY_CHANNEL_DELETE_OK job_id=%s "
                "delivery_channel_id=%s message_id=%s",
                int(job_id or 0), int(delivery_channel_id), int(message_id))
            return "ok"
        except RetryAfter as exc:
            logger.warning(
                "FDB_DELIVERY_CHANNEL_DELETE_RETRY_AFTER job_id=%s "
                "delivery_channel_id=%s message_id=%s retry_after=%ss",
                int(job_id or 0), int(delivery_channel_id), int(message_id),
                int(getattr(exc, "retry_after", 3)))
            return "retry_after"
        except tg_error.BadRequest as exc:
            low = str(exc).lower()
            if "message to delete not found" in low:
                # Already deleted — IDEMPOTENT SUCCESS (the exact
                # contract: a repeat delete never fails the cleanup).
                logger.info(
                    "FDB_DELIVERY_CHANNEL_DELETE_OK job_id=%s "
                    "delivery_channel_id=%s message_id=%s "
                    "via=already_gone",
                    int(job_id or 0), int(delivery_channel_id),
                    int(message_id))
                return "ok"
            logger.warning(
                "FDB_DELIVERY_CHANNEL_DELETE_REJECTED job_id=%s "
                "delivery_channel_id=%s message_id=%s error=%s",
                int(job_id or 0), int(delivery_channel_id), int(message_id),
                str(exc)[:160])
            return f"failed:{str(exc)[:120]}"
        except tg_error.Forbidden as exc:
            logger.warning(
                "FDB_DELIVERY_CHANNEL_DELETE_FORBIDDEN job_id=%s "
                "delivery_channel_id=%s message_id=%s error=%s (the FDB "
                "lost the delete permission — the record is preserved for "
                "the reconciliation sweeper)",
                int(job_id or 0), int(delivery_channel_id), int(message_id),
                str(exc)[:160])
            return "forbidden"
        except Exception as exc:  # noqa: BLE001 — honest failure
            logger.warning(
                "FDB_DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
                "delivery_channel_id=%s message_id=%s error_class=%s "
                "error=%s",
                int(job_id or 0), int(delivery_channel_id), int(message_id),
                type(exc).__name__, str(exc)[:160])
            return f"failed:{type(exc).__name__}"

    # ------------------------------------------------------------------
    # B17 — DIRECT DELIVERY (Mode B) + deep-link HANDOFF (Mode C)
    # ------------------------------------------------------------------
    # bot-18.log: the network bot could NEVER copy the FDB-authored relay
    # ("Message to copy not found" on relays 198-205, jobs 30/31, zero
    # deliveries). The primitives that DID work in that log were the FDB's
    # own copyMessage (storage → group, relay ids 198-205 were created
    # every time) and the network bot's user-facing messages. Mode B/C use
    # exactly those proven primitives and nothing else.
    # ------------------------------------------------------------------
    async def deliver_direct_to_user(self, chat_id: int,
                                     storage_chat_id: int,
                                     storage_message_id: int, *,
                                     protect_content: bool = True,
                                     file_row: Optional[Dict[str, Any]] = None
                                     ) -> tuple:
        """MODE B — the File Delivery Bot performs the FINAL user-facing
        send: copyMessage storage master → user.

        This is the SAME Telegram primitive that always worked for relay
        creation (the FDB copying from Storage), pointed straight at the
        user — no bot-to-bot visibility assumption anywhere in the hop.
        ``protect_content`` applies on THIS hop only (the user-facing one).

        V25 (§7): when the STORAGE channel itself restricts saving content,
        copyMessage is deterministically rejected. The LAST-RESORT fallback
        (only with a usable ``file_row``) re-sends the media BY FILE IDENTITY
        — sendVideo / sendPhoto / sendDocument / … with the stored file_id
        (this bot's own reference, so the send is valid) + the stored
        caption. A fresh identity send is NOT a copy: Telegram's
        protected-content restriction governs forward/copy operations, not
        original sends — and the resulting message has NO Forwarded-from
        header (true Hide-Source semantics). Media, caption and the
        protect_content flag are preserved; albums/ordering are owned by
        the CALLER (one file per delivery job — the per-file pipeline
        preserves order).

        Returns ``(message_id | None, verdict)``:
          ``ok``                      — delivered, real message id;
          ``forbidden``               — the user has NOT started the FDB
                                        (or blocked it) → caller routes to
                                        the Mode C handoff button;
          ``bad_request:<detail>``    — deterministic Telegram rejection
                                        (the real text is kept);
          ``transient``               — transport hiccup (retryable);
          ``no_message_id``           — Telegram answered without a message
                                        id (honest failure, never DELIVERED);
          ``unconfigured``            — no live FDB client;
          ``identity_send_unavailable`` — protected source AND no usable
                                        stored file identity (the honest
                                        Telegram limitation verdict — never
                                        retried blindly).
        The token is NEVER logged; failures carry the error class + the
        real Telegram description only.
        """
        if not self._client:
            logger.error("FDB_DIRECT_DELIVERY_FAILED reason=fdb_unconfigured "
                         "chat_id=%s", chat_id)
            return None, "unconfigured"
        logger.info("FDB_DIRECT_DELIVERY_START chat_id=%s storage_chat=%s "
                    "storage_message=%s protect=%s", chat_id, storage_chat_id,
                    storage_message_id, bool(protect_content))
        from telegram.error import BadRequest, Forbidden, RetryAfter
        for attempt in (1, 2):
            try:
                msg = await self._client.copy_message(
                    chat_id=int(chat_id),
                    from_chat_id=int(storage_chat_id),
                    message_id=int(storage_message_id),
                    protect_content=bool(protect_content))
                mid = int(getattr(msg, "message_id", 0) or 0) or None
                if mid is None:
                    logger.error("FDB_DIRECT_DELIVERY_FAILED "
                                 "reason=no_message_id chat_id=%s", chat_id)
                    return None, "no_message_id"
                logger.info("FDB_DIRECT_DELIVERY_SUCCESS chat_id=%s "
                            "user_message_id=%s", chat_id, mid)
                return mid, "ok"
            except RetryAfter as exc:
                logger.warning("FDB_DIRECT_DELIVERY_RETRY_AFTER chat_id=%s "
                               "retry_after=%ss attempt=%s", chat_id,
                               int(getattr(exc, "retry_after", 3)), attempt)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except Forbidden as exc:
                logger.warning(
                    "FDB_DIRECT_DELIVERY_FORBIDDEN chat_id=%s error_class="
                    "Forbidden error=%s (user has not started the File "
                    "Delivery Bot — routing to the deep-link handoff)",
                    chat_id, str(exc)[:160])
                return None, "forbidden"
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                logger.warning("FDB_DIRECT_DELIVERY_BAD_REQUEST chat_id=%s "
                               "error_class=BadRequest error=%s "
                               "classification=%s",
                               chat_id, str(exc)[:200],
                               cinfo["classification"])
                if "chat not found" in low or "bot was blocked" in low \
                        or "bot can't initiate conversation" in low:
                    # Same semantics as Forbidden: the user must START the
                    # FDB first → the caller's Mode C handoff path.
                    return None, "forbidden"
                if "message to copy not found" in low \
                        or "message to forward not found" in low:
                    # B17 FINAL VERIFICATION: the canonical classification
                    # (RELAY_INACCESSIBLE_TO_NETWORK_BOT — deletion never
                    # proven here) is in the log; the routing verdict keeps
                    # the source_not_copyable semantics for Mode B.
                    return None, "bad_request:source_not_copyable:" \
                                 + str(exc)[:120]
                if "protected content" in low:
                    # V25 §7: the STORAGE channel restricts saving content —
                    # copyMessage can never succeed. Last resort: a fresh
                    # send BY FILE IDENTITY (sendVideo/sendPhoto/… with the
                    # stored file_id + caption). Only when a usable file_row
                    # exists; otherwise the honest limitation verdict.
                    mid2 = await self._send_by_file_identity(
                        chat_id, file_row, protect_content=protect_content,
                        reason="storage_protected")
                    if mid2 is not None:
                        return mid2, "ok"
                    return None, "identity_send_unavailable"
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning("FDB_DIRECT_DELIVERY_TRANSIENT attempt=%s "
                               "chat_id=%s error_class=%s error=%s",
                               attempt, chat_id, type(exc).__name__,
                               str(exc)[:120])
                await asyncio.sleep(1.5)
        return None, "transient"

    async def _send_by_file_identity(self, chat_id: int,
                                     file_row: Optional[Dict[str, Any]], *,
                                     protect_content: bool = False,
                                     reason: str = ""
                                     ) -> Optional[int]:
        """V25 §7 — the LAST-RESORT identity send (NOT a Telegram copy).

        A fresh send by the stored file_id (this bot's own reference) with
        the stored caption: the protected-content restriction governs
        forward/copy operations, never original sends. The resulting message
        carries NO Forwarded-from header (true Hide-Source semantics).
        Returns the sent message id or None (no usable identity / Telegram
        rejected the id — both honest, never blindly retried by callers).
        """
        if not self._client:
            return None
        if not file_row:
            logger.warning(
                "FDB_IDENTITY_SEND_UNAVAILABLE chat_id=%s reason=no_file_row "
                "(no stored file identity available for the fallback)",
                chat_id, )
            return None
        fid = str(file_row.get("file_id") or "")
        mtype = str(file_row.get("media_type") or "").lower()
        caption = file_row.get("caption")
        if not fid or mtype not in ("video", "photo", "document", "audio",
                                    "voice", "animation", "video_note",
                                    "sticker"):
            logger.warning(
                "FDB_IDENTITY_SEND_UNAVAILABLE chat_id=%s reason=%s "
                "media_type=%s file_id_present=%s (the stored identity does "
                "not map to a send API — the honest Telegram limitation)",
                chat_id, reason or "-", mtype or "-", bool(fid))
            return None
        kw: Dict[str, Any] = {}
        if caption:
            kw["caption"] = str(caption)[:1024]
        kw["protect_content"] = bool(protect_content)
        sender = None
        try:
            if mtype == "video":
                sender = self._client.send_video(chat_id, fid, **kw)
            elif mtype == "photo":
                kw.pop("protect_content", None)  # sendPhoto has no such param
                sender = self._client.send_photo(chat_id, fid, **kw)
            elif mtype == "document":
                sender = self._client.send_document(chat_id, fid, **kw)
            elif mtype == "audio":
                sender = self._client.send_audio(chat_id, fid, **kw)
            elif mtype == "voice":
                sender = self._client.send_voice(chat_id, fid, **kw)
            elif mtype == "animation":
                sender = self._client.send_animation(chat_id, fid, **kw)
            elif mtype == "video_note":
                kw.pop("caption", None)  # video notes carry no caption
                kw.pop("protect_content", None)
                sender = self._client.send_video_note(chat_id, fid)
            elif mtype == "sticker":
                kw.pop("caption", None)
                kw.pop("protect_content", None)
                sender = self._client.send_sticker(chat_id, fid)
        except TypeError:
            # A PTB version without protect_content on this method: retry
            # once without the flag (media still delivered, protection
            # best-effort — logged honestly).
            kw.pop("protect_content", None)
            try:
                if mtype == "video":
                    sender = self._client.send_video(chat_id, fid, **kw)
                elif mtype == "photo":
                    sender = self._client.send_photo(chat_id, fid, **kw)
                elif mtype == "document":
                    sender = self._client.send_document(chat_id, fid, **kw)
                elif mtype == "audio":
                    sender = self._client.send_audio(chat_id, fid, **kw)
                elif mtype == "voice":
                    sender = self._client.send_voice(chat_id, fid, **kw)
                elif mtype == "animation":
                    sender = self._client.send_animation(chat_id, fid, **kw)
            except Exception:  # noqa: BLE001
                sender = None
        if sender is None:
            return None
        try:
            msg = await sender
        except Exception as exc:  # noqa: BLE001 — honest classification below
            logger.warning(
                "FDB_IDENTITY_SEND_FAILED chat_id=%s media=%s reason=%s "
                "error_class=%s error=%s (the stored file_id was rejected — "
                "the stale-id recovery plane owns the repair; never "
                "blindly retried)",
                chat_id, mtype, reason or "-", type(exc).__name__,
                str(exc)[:160])
            return None
        mid = int(getattr(msg, "message_id", 0) or 0) or None
        if mid is not None:
            logger.info(
                "FDB_IDENTITY_SEND_SUCCESS chat_id=%s media=%s msg_id=%s "
                "reason=%s (a FRESH send by stored file identity — no "
                "Forwarded-from header, protected-content restrictions do "
                "not apply to original sends)",
                chat_id, mtype, mid, reason or "-")
        return mid

    # ------------------------------------------------------------------
    # V25 FINAL — STAGE A: the File Delivery Bot writes the Delivery
    # Channel message (storage → delivery channel). The ONLY FDB file
    # transport in production; never user-facing.
    # ------------------------------------------------------------------
    async def copy_storage_to_delivery_channel(
            self, delivery_channel_id: int, storage_chat_id: int,
            storage_message_id: int, *,
            protect_content: bool = False,
            file_row: Optional[Dict[str, Any]] = None,
            job_id: Optional[int] = None) -> tuple:
        """STAGE A — copyMessage storage master → Delivery Channel.

        The File Delivery Bot reads the storage master and creates the
        Delivery Channel message the Network Bot's user-facing copy will
        read from (Stage B). This is the ONLY FDB file transport in the
        V25 FINAL architecture — the FDB is never the final user-facing
        sender.

        Protected content (§8): when the STORAGE channel restricts
        copying, copyMessage is deterministically rejected — the FDB
        then re-sends the media BY FILE IDENTITY into the Delivery
        Channel (``_send_by_file_identity`` — a FRESH send: Telegram's
        protected-content restriction governs forward/copy operations,
        never original sends). The correct Delivery Channel message is
        created either way; caption and media are preserved.

        Returns ``(delivery_message_id | None, verdict)``:
          ``ok``                       — channel message created;
          ``bad_request:source_not_copyable:<text>`` — the storage
                                         message is gone/inaccessible;
          ``identity_send_unavailable`` — protected source AND no usable
                                         stored file identity;
          ``transient``                — transport hiccup (retryable);
          ``no_message_id``            — Telegram answered without an id;
          ``unconfigured``             — no live FDB client.
        The token is NEVER logged.
        """
        if not self._client:
            logger.error("FDB_DELIVERY_CHANNEL_COPY_FAILED "
                         "reason=fdb_unconfigured delivery_channel_id=%s",
                         delivery_channel_id)
            return None, "unconfigured"
        logger.info(
            "FDB_DELIVERY_CHANNEL_COPY_START job_id=%s "
            "delivery_channel_id=%s storage_chat=%s storage_message=%s "
            "protect=%s", int(job_id or 0), int(delivery_channel_id),
            int(storage_chat_id), int(storage_message_id),
            bool(protect_content))
        from telegram.error import BadRequest, RetryAfter
        for attempt in (1, 2):
            try:
                msg = await self._client.copy_message(
                    chat_id=int(delivery_channel_id),
                    from_chat_id=int(storage_chat_id),
                    message_id=int(storage_message_id),
                    protect_content=bool(protect_content))
                mid = int(getattr(msg, "message_id", 0) or 0) or None
                if mid is None:
                    logger.error(
                        "FDB_DELIVERY_CHANNEL_COPY_FAILED "
                        "reason=no_message_id delivery_channel_id=%s",
                        delivery_channel_id)
                    return None, "no_message_id"
                logger.info(
                    "FDB_DELIVERY_CHANNEL_COPY_SUCCESS job_id=%s "
                    "delivery_channel_id=%s delivery_message_id=%s",
                    int(job_id or 0), int(delivery_channel_id), mid)
                return mid, "ok"
            except RetryAfter as exc:
                logger.warning(
                    "FDB_DELIVERY_CHANNEL_COPY_RETRY_AFTER "
                    "delivery_channel_id=%s retry_after=%ss attempt=%s",
                    delivery_channel_id,
                    int(getattr(exc, "retry_after", 3)), attempt)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                logger.warning(
                    "FDB_DELIVERY_CHANNEL_COPY_BAD_REQUEST "
                    "delivery_channel_id=%s error_class=BadRequest "
                    "error=%s classification=%s",
                    delivery_channel_id, str(exc)[:200],
                    cinfo["classification"])
                if "message to copy not found" in low \
                        or "message to forward not found" in low:
                    # The storage master message is gone — NOT the
                    # channel's fault. Honest verdict; the stale-id
                    # recovery plane (BOT6_DELIVERY_SOURCE_*) owns the
                    # repair when a re-upload re-points the canonical.
                    return None, "bad_request:source_not_copyable:" \
                                 + str(exc)[:120]
                if "protected content" in low:
                    # §8: the STORAGE channel restricts copying — the
                    # FDB-side file-ID fallback creates the correct
                    # Delivery Channel message (a fresh send into the
                    # channel, never user-facing).
                    mid2 = await self._send_by_file_identity(
                        int(delivery_channel_id), file_row,
                        protect_content=protect_content,
                        reason="storage_protected_stage_a")
                    if mid2 is not None:
                        logger.info(
                            "FDB_DELIVERY_CHANNEL_COPY_SUCCESS job_id=%s "
                            "delivery_channel_id=%s delivery_message_id=%s "
                            "via=identity_send (protected storage source — "
                            "fresh file-ID send into the Delivery Channel)",
                            int(job_id or 0), int(delivery_channel_id), mid2)
                        return mid2, "ok"
                    return None, "identity_send_unavailable"
                if "chat not found" in low or "bot is not a member" in low \
                        or "bot was kicked" in low \
                        or "not enough rights" in low:
                    # The FDB cannot see/write the Delivery Channel —
                    # remediation is the FDB's channel admin membership.
                    return None, "bad_request:channel_inaccessible:" \
                                 + str(exc)[:120]
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning(
                    "FDB_DELIVERY_CHANNEL_COPY_TRANSIENT attempt=%s "
                    "delivery_channel_id=%s error_class=%s error=%s",
                    attempt, delivery_channel_id, type(exc).__name__,
                    str(exc)[:120])
                await asyncio.sleep(1.5)
        return None, "transient"

    async def verify_delivery_channel(
            self, network_bot_row: Dict[str, Any], chat_id: int, *,
            title: str = "",
            owner_user_id: Optional[int] = None) -> Dict[str, Any]:
        """V25 FINAL — verify + CONFIGURE one candidate Delivery Channel.

        Production verification chain for the two-stage architecture
        (replaces the legacy group verification in every production
        path — the entity persisted is ``network_bots.```
        ``delivery_channel_chat_id``, NEVER a network_delivery_groups
        row):

          1. chat exists and is a CHANNEL (the required transport —
             bot-to-bot copy messages are invisible in supergroups);
             legacy supergroup chats stay accepted (compat migration
             path v42);
          2. File Delivery Bot present + ADMINISTRATOR (it writes the
             Stage-A messages);
          3. FDB has the required admin privileges (delete messages);
          4. Network Bot present (member — it reads + performs the
             Stage-B user-facing copy);
          5. FDB operational.

        On success: ``set_delivery_channel`` persists the chat on the
        network bot row + a DELIVERY_CHANNEL_CONFIGURED audit event +
        the DELIVERY_CHANNEL_VERIFIED log. Every failure logs
        DELIVERY_CHANNEL_VERIFY_FAILURE with the REAL reason and the
        remediation. Returns the same {ok, reason, checks} contract
        run_verification/delivery_ui consume.
        """
        nid = int(network_bot_row["network_bot_id"])
        owner = int(owner_user_id or network_bot_row["owner_user_id"])
        checks: Dict[str, Any] = {}
        snap = await self.status_snapshot()
        if not snap["configured"] or snap["status"] == FDB_DISABLED:
            checks["file_delivery_bot"] = "unconfigured"
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=fdb_not_operational",
                nid, int(chat_id))
            return {"ok": False, "reason": "fdb_not_operational",
                    "checks": checks}
        client = self._client
        assert client is not None
        # 1: chat exists + is a channel. V26 (No group/supergroup delivery):
        #    a NEW Delivery Channel configuration must be a real broadcast
        #    CHANNEL (ChatType.CHANNEL) — groups and supergroups are
        #    rejected with the honest remediation. The ONLY grandfathered
        #    exception: the chat is ALREADY this bot's persisted
        #    delivery_channel_chat_id (the v42 legacy-migration transfer —
        #    production evidence bot-37.log shows those channels
        #    WORKING: NETWORK_BOT_COPY_TO_USER_SUCCESS jobs 83/84 —
        #    re-setup/re-verification of an existing channel must never
        #    break a working delivery plane).
        try:
            chat = await client.get_chat(int(chat_id))
            chat_type = str(getattr(chat, "type", "") or "")
            _persisted_dc = _safe_row_get(
                network_bot_row, "delivery_channel_chat_id")
            _is_persisted_dc = False
            try:
                _is_persisted_dc = (_persisted_dc is not None
                                    and int(_persisted_dc) == int(chat_id))
            except (TypeError, ValueError):
                _is_persisted_dc = False
            if chat_type != str(ChatType.CHANNEL) and not _is_persisted_dc:
                checks["chat_type"] = chat_type
                logger.warning(
                    "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                    "chat_id=%s result=failed reason=not_a_channel "
                    "chat_type=%s (V26: a NEW Delivery Channel must be a "
                    "broadcast CHANNEL — create a private channel, add the "
                    "File Delivery Bot as ADMIN and the network bot as a "
                    "member, then POST /setup there; groups and supergroups "
                    "are not accepted for new setups)",
                    nid, int(chat_id), chat_type)
                return {"ok": False, "reason": "not_a_channel",
                        "checks": checks}
            checks["chat_type"] = chat_type
            if chat_type != str(ChatType.CHANNEL):
                logger.info(
                    "DELIVERY_CHANNEL_LEGACY_CHAT_ACCEPTED network_bot_id=%s "
                    "chat_id=%s chat_type=%s (the chat is ALREADY the "
                    "persisted Delivery Channel — grandfathered legacy "
                    "migration; production routing stays two-stage "
                    "Delivery Channel)",
                    nid, int(chat_id), chat_type)
            title = title or str(getattr(chat, "title", "") or "")
        except Exception as exc:  # noqa: BLE001 — honest probe failure
            err_class = type(exc).__name__
            err_msg = str(exc)[:120]
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=chat_not_found "
                "probed_by=fdb_client error_class=%s error=%s "
                "(remediation: add the File Delivery Bot as ADMIN of the "
                "Delivery Channel — a private channel with the FDB and "
                "the network bot both admin — then POST /setup there)",
                nid, int(chat_id), err_class, err_msg)
            return {"ok": False, "reason": "chat_not_found",
                    "checks": {**checks,
                               "probe_error_class": err_class,
                               "probe_error": err_msg}}
        # 2 + 3: FDB present + administrator with privileges.
        fdb_member_status = ""
        fdb_privileges_ok = False
        try:
            fdb_id = self.telegram_bot_id
            member = await client.get_chat_member(int(chat_id), int(fdb_id))
            fdb_member_status = str(getattr(member, "status", ""))
            checks["fdb_member_status"] = fdb_member_status
            if fdb_member_status == ChatMemberStatus.ADMINISTRATOR:
                missing = [p for p in _FDB_REQUIRED_ADMIN_PRIVILEGES
                           if not bool(getattr(member, p, False))]
                fdb_privileges_ok = not missing
                checks["fdb_missing_privileges"] = missing
        except Exception as exc:  # noqa: BLE001
            checks["fdb_member_status"] = f"error: {str(exc)[:100]}"
        # 4: network bot membership in the channel.
        nb_member_status = ""
        try:
            nb = await client.get_chat_member(
                int(chat_id), int(network_bot_row["telegram_bot_id"]))
            nb_member_status = str(getattr(nb, "status", ""))
            checks["network_bot_member_status"] = nb_member_status
        except Exception as exc:  # noqa: BLE001
            checks["network_bot_member_status"] = f"error: {str(exc)[:100]}"
        # 5: FDB storage access (Stage A reads the storage master).
        storage = await self._probe_storage_access(client)
        checks["fdb_storage_access"] = storage
        # Decisions (same priority as the legacy chain).
        if fdb_member_status != ChatMemberStatus.ADMINISTRATOR \
                or not fdb_privileges_ok:
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=fdb_not_admin "
                "fdb_member_status=%s missing_privileges=%s "
                "(remediation: promote the File Delivery Bot to ADMIN of "
                "the Delivery Channel with delete-message rights)",
                nid, int(chat_id), fdb_member_status,
                checks.get("fdb_missing_privileges"))
            return {"ok": False, "reason": "fdb_not_admin",
                    "checks": checks}
        if not nb_member_status:
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=network_bot_not_member "
                "(remediation: add the Network Bot to the Delivery "
                "Channel — it performs the Stage-B user-facing copy)",
                nid, int(chat_id))
            return {"ok": False, "reason": "network_bot_not_member",
                    "checks": checks}
        # ALL PASSED → persist the Delivery Channel on the bot row.
        setter = getattr(self.db, "set_delivery_channel", None)
        if not callable(setter):
            logger.error(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=repo_primitive_missing",
                nid, int(chat_id))
            return {"ok": False, "reason": "repo_primitive_missing",
                    "checks": checks}
        await setter(nid, int(chat_id))
        try:
            await self.db.insert_control_audit_event(
                "DELIVERY_CHANNEL_CONFIGURED", actor_user_id=owner,
                network_bot_id=nid,
                detail=f"chat={chat_id} type={chat_type} "
                       f"fdb_storage={storage}")
        except Exception:  # noqa: BLE001 — audit is best-effort
            pass
        logger.info(
            "DELIVERY_CHANNEL_VERIFIED network_bot_id=%s chat_id=%s "
            "chat_type=%s fdb_storage_access=%s "
            "network_bot_member_status=%s (Stage A: FDB copies Storage → "
            "Delivery Channel; Stage B: Network Bot copies Delivery "
            "Channel → user — the V25 FINAL two-stage architecture)",
            nid, int(chat_id), chat_type, storage, nb_member_status)
        return {"ok": True, "status": DG_READY, "checks": checks,
                "delivery_channel_chat_id": int(chat_id),
                "storage_access": storage}

    def handoff_deep_link(self, token: str) -> str:
        """MODE C — the one-tap deep link the network bot shows the user:

            t.me/<fdb>?start=dl<token>

        Empty string when the FDB username is unknown (the caller must
        then fail honestly instead of shipping a broken button).
        """
        uname = (self.bot_username or "").strip().lstrip("@")
        tok = str(token or "").strip()
        if not uname or not tok:
            return ""
        return f"https://t.me/{uname}?start=dl{tok}"

    # -- the handoff poller (the FDB's ONLY inbound-update surface) ------
    def _poller_running(self) -> bool:
        return bool(self._poll_task) and not self._poll_task.done()

    async def start_handoff_poller(self) -> bool:
        """Start the getUpdates long-poll loop on the FDB client.

        The FDB never runs a full PTB Application (nothing else needs
        inbound updates); the poller is the ONLY consumer, so plain
        long polling is safe (Telegram rejects concurrent getUpdates for
        one token — there is exactly one here).
        """
        if not self._client:
            return False
        if self._poller_running():
            return True
        self._poll_task = asyncio.create_task(self._handoff_poll_loop())
        logger.info("FDB_HANDOFF_POLLER_STARTED username=@%s "
                    "(deep-link dl<token> deliveries enabled)",
                    self.bot_username)
        return True

    async def stop_handoff_poller(self) -> None:
        task, self._poll_task = self._poll_task, None
        if task is not None:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            logger.info("FDB_HANDOFF_POLLER_STOPPED")

    async def _fdb_get_updates(self, offset: int, timeout: int):
        """One long-poll round through the bound PTB client ( tolerant of
        reduced-signature fakes — extras degrade, never crash)."""
        try:
            return await self._client.get_updates(
                offset=offset, timeout=timeout,
                allowed_updates=["message"],
                read_timeout=timeout + 10)
        except TypeError:
            return await self._client.get_updates(
                offset=offset, timeout=timeout)
        except Exception as exc:  # noqa: BLE001 — poll errors are verdicts
            kind = type(exc).__name__
            logger.warning("FDB_HANDOFF_POLL_ERROR error_class=%s error=%s",
                           kind, str(exc)[:160])
            return []

    async def _handoff_poll_loop(self) -> None:
        poll_timeout = 25
        offset = 0
        while True:
            try:
                updates = await self._fdb_get_updates(offset, poll_timeout)
            except asyncio.CancelledError:
                raise
            for upd in updates or []:
                uid = int(getattr(upd, "update_id", 0) or 0)
                if uid >= offset:
                    offset = uid + 1
                try:
                    await self._process_fdb_update(upd)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001 — one bad update
                    logger.warning("FDB_HANDOFF_UPDATE_ERROR error_class=%s "
                                   "error=%s", type(exc).__name__,
                                   str(exc)[:160])
            # Yield the event loop every round: the REAL getUpdates blocks
            # ~poll_timeout server-side, but an instantly-answering
            # transport (tests, local API edge cases) must never turn this
            # loop into a starvation spin.
            await asyncio.sleep(0.05)

    def _start_arg(self, text: str) -> str:
        """Extract the /start deep-link argument ('' when plain /start)."""
        t = str(text or "").strip()
        if not t.startswith("/start"):
            return ""
        return t[len("/start"):].strip()

    async def _process_fdb_update(self, upd) -> None:
        """Route ONE FDB update: /start dl<token> completes a handoff
        delivery; any other /start gets the polite welcome. Everything
        else is ignored (the FDB is a delivery surface, not a chat bot)."""
        msg = getattr(upd, "message", None)
        if msg is None:
            return
        text = str(getattr(msg, "text", "") or "").strip()
        if not text or not text.startswith("/start"):
            return
        chat = getattr(msg, "chat", None)
        chat_id = int(getattr(chat, "id", 0) or 0)
        if not chat_id:
            return
        arg = self._start_arg(text)
        token = ""
        if arg[:2].lower() == "dl":
            token = arg[2:].strip().split()[0] if arg[2:].strip() else ""
        if not token:
            await self._fdb_send_message(
                chat_id,
                "This is the platform File Delivery Bot. It delivers the "
                "files you request from the network bots — tap the "
                "\U0001F4E5 Receive File button you received there and your "
                "file will arrive here.")
            logger.info("FDB_STARTED chat_id=%s (plain /start — welcome "
                        "sent)", chat_id)
            return
        await self.complete_handoff_delivery(chat_id, token)

    async def complete_handoff_delivery(self, chat_id: int,
                                        token: str) -> None:
        """MODE C completion: the user tapped t.me/<fdb>?start=dl<token>.

        Single-use: the job is atomically CLAIMED (HANDOFF_PENDING →
        DELIVERING) before any Telegram send; a second tap finds no
        claimable job and gets the honest expired answer. DELIVERED is
        written ONLY after the real user-facing send returns a message id
        (the B17 honesty mandate).
        """
        tok = str(token or "").strip()
        job = await self.db.get_delivery_job_by_handoff_token(tok)
        if job is None:
            await self._fdb_send_message(
                chat_id, "This delivery link is no longer valid — it was "
                "already used or has expired. Ask the bot you requested "
                "the file from to send it again.")
            logger.info("FDB_HANDOFF_TOKEN_INVALID chat_id=%s "
                        "token_prefix=%s (single-use token dead)",
                        chat_id, tok[:6])
            return
        jid = int(job.get("id") or 0)
        claimed = False
        claim = getattr(self.db, "claim_handoff_job", None)
        if callable(claim):
            claimed = bool(await claim(jid))
        else:  # fakes without the atomic claim — best-effort guard
            claimed = str(job.get("status")) == JOB_HANDOFF_PENDING
        if not claimed:
            await self._fdb_send_message(
                chat_id, "This delivery link is no longer valid — it was "
                "already used or has expired. Ask the bot you requested "
                "the file from to send it again.")
            logger.info("FDB_HANDOFF_TOKEN_INVALID chat_id=%s "
                        "token_prefix=%s (claim lost the single-use race)",
                        chat_id, tok[:6])
            return
        user_id = int(job.get("user_id") or 0)
        sc = job.get("storage_chat_id")
        sm = job.get("storage_message_id")
        if not (user_id and sc and sm):
            await self.db.update_delivery_job(
                jid, status=JOB_FAILED,
                last_error="handoff job missing source refs")
            logger.error("FDB_HANDOFF_DELIVERY_FAILED job_id=%s "
                         "reason=no_source_ref", jid)
            return
        logger.info("FDB_HANDOFF_DELIVERY_START job_id=%s chat_id=%s "
                    "user_id=%s storage_chat=%s storage_message=%s",
                    jid, chat_id, user_id, sc, sm)
        protect = bool(int(job.get("protect_content") or 0)) \
            if "protect_content" in job else True
        mid, verdict = await self.deliver_direct_to_user(
            user_id, int(sc), int(sm), protect_content=protect)
        if mid is not None:
            await self.db.update_delivery_job(
                jid, status=JOB_DELIVERED, delivered_at=_now_iso(),
                user_message_id=int(mid), delivery_mode=DM_HANDOFF,
                last_error=None)
            logger.info("FDB_HANDOFF_DELIVERY_COMPLETED job_id=%s "
                        "user_id=%s user_message_id=%s mode=handoff",
                        jid, user_id, mid)
            # B18 honesty rule: the FDB performed this send — labeled
            # FDB_DIRECT_DELIVERY_SUCCESS, never NETWORK_DELIVERY_SUCCESS
            # (reserved for the network bot itself delivering).
            logger.info("FDB_DIRECT_DELIVERY_SUCCESS job_id=%s msg_id=%s "
                        "mode=handoff", jid, mid)
            return
        if verdict == "forbidden":
            # The chat was started (we just received /start) yet the send
            # was refused — revert to HANDOFF_PENDING honestly; the
            # sweeper/poller retries and the TTL eventually expires it.
            await self.db.update_delivery_job(
                jid, status=JOB_HANDOFF_PENDING,
                last_error=f"final_delivery_failed[{verdict}]")
            logger.warning("FDB_HANDOFF_DELIVERY_REVERTED job_id=%s "
                           "reason=forbidden (kept HANDOFF_PENDING — TTL "
                           "will settle)", jid)
            return
        # Transient / bad_request — bounded retry through the sweeper's
        # HANDOFF_PENDING retry pass, FAILED at max_attempts (never a
        # lying DELIVERED).
        await self._handoff_fail_or_retry(jid, job, verdict)

    async def _handoff_fail_or_retry(self, job_id: int, job: Dict[str, Any],
                                     verdict: str) -> None:
        """Bounded backoff for a handoff completion failure (mirrors the
        engine's _fail_or_retry semantics; terminal at max_attempts)."""
        attempts = int(job.get("attempts") or 0) + 1
        max_attempts = int(job.get("max_attempts")
                           or DELIVERY_DEFAULT_MAX_ATTEMPTS)
        error = f"final_delivery_failed[{verdict}]"
        if attempts >= max_attempts:
            await self.db.update_delivery_job(
                job_id, status=JOB_FAILED, attempts=attempts,
                last_error=error)
            logger.error("FDB_HANDOFF_DELIVERY_FAILED job_id=%s "
                         "attempts=%s error=%s", job_id, attempts, error)
            return
        from datetime import datetime, timedelta, timezone
        base = await self.db.get_setting_int(
            DELIVERY_SETTING_RETRY_BASE, DELIVERY_DEFAULT_RETRY_BASE)
        nxt = (datetime.now(timezone.utc)
               + timedelta(seconds=base * (2 ** max(0, attempts - 1)))
               ).isoformat(timespec="seconds")
        await self.db.update_delivery_job(
            job_id, attempts=attempts, next_retry_at=nxt, last_error=error)
        logger.info("FDB_HANDOFF_RETRY_SCHEDULED job_id=%s attempt=%s "
                    "next_retry_at=%s error=%s", job_id, attempts, nxt,
                    error)

    async def _fdb_send_message(self, chat_id: int, text: str) -> None:
        """Best-effort FDB chat message (welcome / invalid-link UX)."""
        if not self._client:
            return
        try:
            await self._client.send_message(chat_id=int(chat_id), text=text)
        except Exception as exc:  # noqa: BLE001 — UX only, never fatal
            logger.warning("FDB_SEND_MESSAGE_FAILED chat_id=%s "
                           "error_class=%s error=%s", chat_id,
                           type(exc).__name__, str(exc)[:120])

    # ------------------------------------------------------------------
    # Delivery Group verification (spec §41/§46)
    # ------------------------------------------------------------------
    async def verify_delivery_group(self, network_bot_row: Dict[str, Any],
                                    chat_id: int, *,
                                    title: str = "",
                                    owner_user_id: Optional[int] = None
                                    ) -> Dict[str, Any]:
        """Full verification of ONE candidate delivery channel.

        Checks (spec §41/§46):
          1. correct chat — exists and is a (super)group or CHANNEL;
          2. A.2 (bot-25): a private CHANNEL is the REQUIRED transport —
             bot-to-bot relay messages are invisible in supergroups
             (the bot-25.log jobs 48/49 "Message to forward not found"
             root cause), while channel posts ARE accessible to admin
             bots. (Super)groups stay accepted for already-verified rows
             (deprecated for new setups, never broken);
          3. File Delivery Bot present + ADMINISTRATOR;
          4. FDB has the required permissions (delete messages);
          5. Network Bot present (member);
          6. Network Bot identity matches the registered telegram_bot_id;
          7. correct association — no other bot claimed this chat;
          8. delivery capability — FDB operational.

        B23-2 §2.2 — after the probes, ONE HYBRID_DELIVERY_DIAGNOSTICS line
        reports the four pipeline hops with per-identity attribution:
          FDB_STORAGE_ACCESS        — getChat on every active Storage
                                      channel with the FDB'S client;
          FDB_RELAY_CREATE          — storage PASS + FDB admin privileges
                                      (HYBRID hop 1);
          NETWORK_BOT_GROUP_ACCESS  — the network bot's membership
                                      (HYBRID hop 2 reads FROM the group);
          NETWORK_BOT_USER_FORWARD  — group access PASS, strengthened by
                                      an own-client getChat(group) probe
                                      when a live network bot client
                                      resolves (honest unknown otherwise).
        HYBRID_MODE_READY = all four PASS. Under HYBRID the network bot
        does NOT need Storage access: network_bot_storage_access stays
        INFORMATIONAL (checks dict only — never warned on, never gated).
        ``mode_a_ready`` now carries the HYBRID_MODE_READY value (the
        Mode-A pipeline IS the hybrid pipeline).

        On success the association is persisted DELIVERY_READY (and the
        +5 reward is issued by the caller — spec §60 — so that the award
        happens exactly once, after FULL verification).
        """
        nid = int(network_bot_row["network_bot_id"])
        owner = int(owner_user_id or network_bot_row["owner_user_id"])
        checks: Dict[str, Any] = {}
        snap = await self.status_snapshot()
        if not snap["configured"] or snap["status"] == FDB_DISABLED:
            checks["file_delivery_bot"] = "unconfigured"
            await self._dg_persist(nid, owner, chat_id, title,
                                   DG_SETUP_REQUIRED, checks,
                                   "file delivery bot not configured")
            return {"ok": False, "reason": "fdb_not_operational",
                    "checks": checks}
        client = self._client
        assert client is not None
        # 1 + 2: chat exists, is a group/supergroup/CHANNEL (A.2: the
        # Delivery CHANNEL is the required transport; supergroups remain
        # accepted for existing rows).
        try:
            chat = await client.get_chat(int(chat_id))
            chat_type = str(getattr(chat, "type", "") or "")
            if chat_type not in (str(ChatType.GROUP), str(ChatType.SUPERGROUP),
                                 str(ChatType.CHANNEL)):
                checks["chat_type"] = chat_type
                await self._dg_persist(nid, owner, chat_id, title,
                                       DG_SETUP_REQUIRED, checks,
                                       "not a group/supergroup/channel")
                return {"ok": False, "reason": "not_a_group", "checks": checks}
            checks["chat_type"] = chat_type
            title = title or str(getattr(chat, "title", "") or "")
        except Exception as exc:  # noqa: BLE001
            # B24 (Phase 1/8): surface the EXACT Telegram exception class
            # so operators can distinguish "bot never added" (BadRequest
            # "Chat not found") from "bot was kicked" (Forbidden) from a
            # transient NetworkError — all map to the same user-facing
            # chat_not_found reason (correct), but the diagnostic now
            # names the prober (the FDB's client) + the remediation.
            err_class = type(exc).__name__
            err_msg = str(exc)[:120]
            logger.warning(
                "DELIVERY_GROUP_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=chat_not_found "
                "probed_by=fdb_client error_class=%s error=%s "
                "(remediation: add the File Delivery Bot as admin of the "
                "configured delivery chat, OR create a NEW private channel "
                "and add both the FDB + the network bot as admins, then "
                "POST /setup there)",
                nid, int(chat_id), err_class, err_msg)
            await self._dg_persist(nid, owner, chat_id, title,
                                   DG_SETUP_REQUIRED, checks,
                                   f"chat not reachable ({err_class}): "
                                   f"{err_msg}")
            return {"ok": False, "reason": "chat_not_found",
                    "checks": {**checks,
                               "probe_error_class": err_class,
                               "probe_error": err_msg}}
        # 3 + 4: FDB present + administrator with required privileges
        #        (probed first; the DECISION is applied after the §2.2
        #        diagnostics below so every post-group-reachable path
        #        emits the full HYBRID evidence line).
        fdb_member_status = ""
        fdb_privileges_ok = False
        try:
            fdb_id = self.telegram_bot_id
            member = await client.get_chat_member(int(chat_id), int(fdb_id))
            fdb_member_status = str(getattr(member, "status", ""))
            checks["fdb_member_status"] = fdb_member_status
            if fdb_member_status == ChatMemberStatus.ADMINISTRATOR:
                missing = [p for p in _FDB_REQUIRED_ADMIN_PRIVILEGES
                           if not bool(getattr(member, p, False))]
                fdb_privileges_ok = not missing
                checks["fdb_missing_privileges"] = missing
        except Exception as exc:  # noqa: BLE001
            checks["fdb_member_status"] = f"error: {str(exc)[:100]}"
        # 6 (probe): network bot membership in the group.
        nb_member_status = ""
        try:
            nb = await client.get_chat_member(
                int(chat_id), int(network_bot_row["telegram_bot_id"]))
            nb_member_status = str(getattr(nb, "status", ""))
            checks["network_bot_member_status"] = nb_member_status
        except Exception as exc:  # noqa: BLE001
            checks["network_bot_member_status"] = f"error: {str(exc)[:100]}"
        # 8 (probe): capability — FDB storage access, checked live with
        #    the FDB'S OWN client (the HYBRID hop-1 identity).
        storage = await self._probe_storage_access(client)
        checks["fdb_storage_access"] = storage

        # ------------------------------------------------------------------
        # B23-2 §2.2 — the HYBRID pipeline diagnostics (ONE line, INFO,
        # per-identity attribution for every hop).
        # ------------------------------------------------------------------
        fdb_storage_ok = (storage == "full")
        fdb_relay_create_ok = bool(
            fdb_storage_ok
            and fdb_member_status == ChatMemberStatus.ADMINISTRATOR
            and fdb_privileges_ok)
        nb_group_access_ok = nb_member_status in (
            ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER,
            ChatMemberStatus.MEMBER)
        # NETWORK_BOT_USER_FORWARD — membership first; an own-client
        # getChat(group) probe STRENGTHENS it when a live network bot
        # client resolves (honest unknown handling: no resolver / no
        # client / probe unavailable → the membership verdict stands).
        nb_own_group_probe = "not_probed(no_live_client)"
        if nb_group_access_ok:
            nb_resolver = getattr(self, "network_bot_client_resolver", None)
            if callable(nb_resolver):
                try:
                    nb_client = nb_resolver(nid)
                    if asyncio.iscoroutine(nb_client):
                        nb_client = await nb_client
                except Exception:  # noqa: BLE001 — honest unknown
                    nb_client = None
                if nb_client is not None:
                    own_get_chat = getattr(nb_client, "get_chat", None)
                    if callable(own_get_chat):
                        try:
                            await own_get_chat(int(chat_id))
                            nb_own_group_probe = "reachable"
                        except Exception as exc:  # noqa: BLE001 — evidence
                            nb_own_group_probe = f"error: {str(exc)[:100]}"
                    else:
                        nb_own_group_probe = "probe_unavailable"
        nb_user_forward_ok = bool(
            nb_group_access_ok
            and not nb_own_group_probe.startswith("error:"))
        checks["network_bot_own_group_probe"] = nb_own_group_probe
        hybrid_mode_ready = bool(fdb_storage_ok and fdb_relay_create_ok
                                 and nb_group_access_ok
                                 and nb_user_forward_ok)
        # B23-2: under HYBRID the network bot does NOT need Storage — the
        # network_bot_storage_access probe is INFORMATIONAL only (checks
        # dict; never warned on, never gated). The FINAL-1 labels stay
        # honest and SEPARATE: fdb_storage_access (the HYBRID hop-1
        # authority) vs network_bot_storage_access (the informational
        # legacy label, probed with the network bot's OWN client when a
        # live worker exists — "unknown" otherwise, never fabricated).
        nb_storage = "unknown"
        nb_resolver = getattr(self, "network_bot_client_resolver", None)
        if callable(nb_resolver):
            try:
                nb_client = nb_resolver(nid)
                if asyncio.iscoroutine(nb_client):
                    nb_client = await nb_client
                if nb_client is not None:
                    nb_storage = await self._probe_storage_access(nb_client)
            except Exception:  # noqa: BLE001 — honest unknown
                nb_storage = "unknown"
        checks["network_bot_storage_access"] = nb_storage
        # ``mode_a_ready`` now carries the HYBRID verdict (the Mode-A
        # pipeline IS the hybrid pipeline; the old network-bot-storage
        # gate is retired).
        mode_a_ready = hybrid_mode_ready
        checks["mode_a_ready"] = mode_a_ready
        checks["hybrid_mode_ready"] = hybrid_mode_ready
        fdb_identity = (str(getattr(client, "username", "") or "")
                        or str(snap.get("username") or "")).lstrip("@")
        nb_identity = str(network_bot_row.get("username") or "").lstrip("@")

        def _warn_hybrid_not_ready() -> None:
            """§2.2 — the HYBRID_MODE_NOT_READY warning listing the hops
            that failed (with per-hop remediation)."""
            if hybrid_mode_ready:
                return
            failed = [name for name, ok in (
                ("FDB_STORAGE_ACCESS", fdb_storage_ok),
                ("FDB_RELAY_CREATE", fdb_relay_create_ok),
                ("NETWORK_BOT_GROUP_ACCESS", nb_group_access_ok),
                ("NETWORK_BOT_USER_FORWARD", nb_user_forward_ok)) if not ok]
            logger.warning(
                "HYBRID_MODE_NOT_READY network_bot_id=%s group=%s "
                "failed_hops=%s fdb_storage_access=%s "
                "network_bot_storage_access=%s(informational) (the HYBRID "
                "pipeline cannot run — Mode B (FDB direct) delivers "
                "meanwhile; remediation: FDB_STORAGE_ACCESS/FDB_RELAY_"
                "CREATE → the File Delivery Bot's Storage membership + "
                "group admin rights; NETWORK_BOT_GROUP_ACCESS/"
                "NETWORK_BOT_USER_FORWARD → add the Network Bot to the "
                "Delivery Group — the network bot does NOT need Storage "
                "under HYBRID)",
                nid, chat_id, ",".join(failed), storage, nb_storage)

        logger.info(
            "HYBRID_DELIVERY_DIAGNOSTICS network_bot_id=%s group=%s "
            "FDB_STORAGE_ACCESS=%s FDB_RELAY_CREATE=%s "
            "NETWORK_BOT_GROUP_ACCESS=%s NETWORK_BOT_USER_FORWARD=%s "
            "HYBRID_MODE_READY=%s fdb_identity=@%s "
            "network_bot_identity=@%s "
            "probed_fdb_hops=FDB_STORAGE_ACCESS,FDB_RELAY_CREATE "
            "probed_network_bot_hops=NETWORK_BOT_GROUP_ACCESS,"
            "NETWORK_BOT_USER_FORWARD",
            nid, chat_id, "PASS" if fdb_storage_ok else "FAIL",
            "PASS" if fdb_relay_create_ok else "FAIL",
            "PASS" if nb_group_access_ok else "FAIL",
            "PASS" if nb_user_forward_ok else "FAIL",
            "PASS" if hybrid_mode_ready else "FAIL",
            fdb_identity, nb_identity)

        # ---- decisions (same priority as the pre-B23-2 flow) ------------
        if fdb_member_status != ChatMemberStatus.ADMINISTRATOR \
                or not fdb_privileges_ok:
            await self._dg_persist(nid, owner, chat_id, title,
                                   DG_SETUP_REQUIRED, checks,
                                   "file delivery bot is not administrator "
                                   "with required permissions")
            _warn_hybrid_not_ready()
            return {"ok": False, "reason": "fdb_not_admin", "checks": checks}
        # 5: association uniqueness — a group claimed by another bot is
        # rejected deterministically (the repo also enforces the UNIQUE
        # chat constraint; §39 one group per bot).
        clash = await self.db.get_delivery_group_by_chat(int(chat_id))
        if clash and int(clash["network_bot_id"]) != nid:
            return {"ok": False, "reason": "group_already_used",
                    "checks": checks}
        if not nb_member_status:
            await self._dg_persist(nid, owner, chat_id, title,
                                   DG_SETUP_REQUIRED, checks,
                                   "network bot not found in group")
            _warn_hybrid_not_ready()
            return {"ok": False, "reason": "network_bot_not_member",
                    "checks": checks}
        # ALL PASSED → DELIVERY_READY (spec §45 full chain).
        await self._dg_persist(nid, owner, chat_id, title, DG_READY, checks,
                               None, verified=True)
        await self.db.insert_control_audit_event(
            "DELIVERY_GROUP_VERIFIED", actor_user_id=owner,
            network_bot_id=nid,
            detail=f"chat={chat_id} fdb_storage={storage} "
                   f"network_bot_storage={nb_storage} "
                   f"hybrid_mode_ready={hybrid_mode_ready}")
        logger.info("DELIVERY_GROUP_VERIFIED network_bot_id=%s chat=%s "
                    "fdb_storage_access=%s network_bot_storage_access=%s "
                    "mode_a_ready=%s hybrid_mode_ready=%s", nid, chat_id,
                    storage, nb_storage, mode_a_ready, hybrid_mode_ready)
        # B23-2: the OLD NETWORK_BOT_STORAGE_ACCESS_MISSING warning is
        # RETIRED — under HYBRID the network bot does not need Storage
        # (the FDB relays). A network bot that cannot see storage is NOT
        # a pipeline failure; only HYBRID_MODE_READY failures warn.
        _warn_hybrid_not_ready()
        return {"ok": True, "status": DG_READY, "checks": checks,
                "storage_access": storage,
                "network_bot_storage_access": nb_storage,
                "mode_a_ready": mode_a_ready,
                "hybrid_mode_ready": hybrid_mode_ready}

    async def _dg_persist(self, nid: int, owner: int, chat_id: int,
                           title: str, status: str,
                           checks: Dict[str, Any],
                           error: Optional[str], *,
                           verified: bool = False) -> None:
        res = await self.db.upsert_delivery_group(
            nid, owner, int(chat_id), title=title, status=status,
            checks=checks, last_error=error, verified=verified)
        if res.get("ok"):
            return
        # Clash path — surface as unavailable rather than overwriting
        # another bot's group.
        await self.db.update_delivery_group_status(
            nid, DG_UNAVAILABLE, last_error=error or "association failed")

    async def reverify_all_groups(self) -> Dict[str, int]:
        """DEPRECATED (V25 §1 channel-only) — legacy compatibility only.

        Production NEVER calls this (the periodic health loop no longer
        re-verifies delivery groups and the admin reconcile entry is
        disabled): delivery groups are not part of the production
        delivery graph (storage channel → File Delivery Bot → user).
        The method is retained so legacy deployments can still audit
        their HISTORICAL group rows in isolation; it updates only the
        legacy delivery_groups table state, which no production routing
        path reads — it can never re-activate group delivery.
        """
        groups = await self.db.list_delivery_groups()
        stats = {"total": len(groups), "ready": 0, "degraded": 0,
                 "unavailable": 0, "setup": 0, "deprecated": 1}
        for g in groups:
            nid = int(g["network_bot_id"])
            bot = await self.db.get_network_bot(nid)
            if not bot:
                continue
            before = str(g["status"])
            res = await self.verify_delivery_group(
                bot, int(g["delivery_group_chat_id"]),
                title=str(g["title"] or ""),
                owner_user_id=int(g["owner_user_id"]))
            if res.get("ok"):
                stats["ready"] += 1
                if before in (DG_DEGRADED, DG_UNAVAILABLE):
                    logger.info("DELIVERY_GROUP_CAPABILITY_RESTORED "
                                "network_bot_id=%s", nid)
                    await self.db.insert_control_audit_event(
                        "DELIVERY_GROUP_CAPABILITY_RESTORED",
                        network_bot_id=nid)
            else:
                if before == DG_READY:
                    logger.warning("DELIVERY_GROUP_CAPABILITY_LOST "
                                   "network_bot_id=%s reason=%s",
                                   nid, res.get("reason"))
                    await self.db.insert_control_audit_event(
                        "DELIVERY_GROUP_CAPABILITY_LOST", network_bot_id=nid,
                        detail=str(res.get("reason")))
                if res.get("reason") in ("fdb_not_operational",):
                    stats["degraded"] += 1
                else:
                    stats["unavailable"] += 1
        return stats

    async def mark_group_lost(self, network_bot_id: int, reason: str) -> None:
        """Delivery-time capability loss (relay copy failed because the
        bot/group state regressed) — spec §67 DELIVERY_GROUP_CAPABILITY_LOST."""
        await self.db.update_delivery_group_status(
            int(network_bot_id), DG_DEGRADED, last_error=str(reason)[:200])
        await self.db.insert_control_audit_event(
            "DELIVERY_GROUP_CAPABILITY_LOST", network_bot_id=int(network_bot_id),
            detail=str(reason)[:120])
        logger.warning("DELIVERY_GROUP_CAPABILITY_LOST network_bot_id=%s "
                       "reason=%s", network_bot_id, reason)


# ---------------------------------------------------------------------------
# THE authoritative delivery-ready predicate (spec §46)
# ---------------------------------------------------------------------------
async def is_delivery_ready(db, fdb: FileDeliveryBotManager,
                            bot_row: Dict[str, Any], *,
                            group_row: Optional[Dict[str, Any]] = None
                            ) -> bool:
    """One predicate, used by EVERY routing path (spec §46).

    V25 FINAL (bot-35.log): a network bot is payload-eligible when it is
    registered, enabled, routable, holds a credential, has a CONFIGURED
    DELIVERY CHANNEL (network_bots.delivery_channel_chat_id — schema
    v42) AND the platform File Delivery Bot is operational (Stage A:
    the FDB copies Storage → Delivery Channel; Stage B: the network bot
    performs the user-facing copy FROM the Delivery Channel). No group
    has to be configured, verified or reachable, and legacy
    delivery-group rows (whatever their status) can never gate or
    restore eligibility — ``group_row`` is compat data, deliberately
    ignored.

    Verifies from durable state (no Telegram traffic on the hot path):
      * registered      — row exists;
      * enabled         — enabled = 1;
      * status          — ACTIVE or DEGRADED (routable);
      * credential      — a stored credential exists;
      * delivery channel — delivery_channel_chat_id IS NOT NULL;
      * FDB operational — configured and not disabled/dead.
    """
    if bot_row is None:
        return False
    if str(bot_row.get("status")) not in ("ACTIVE", "DEGRADED"):
        return False
    if int(bot_row.get("enabled") or 0) != 1:
        return False
    # V25 FINAL: the Delivery Channel is REQUIRED — Stage A writes
    # there and Stage B reads from there. A bot without one can never
    # deliver a file (honest ineligibility, never a silent guess).
    if not bot_row.get("delivery_channel_chat_id"):
        return False
    # V25 §1: NO delivery-group requirement — `group_row` (when passed)
    # is legacy compatibility data and is deliberately ignored.
    # The File Delivery Bot must be operational — it performs every
    # Stage-A storage → Delivery Channel copy.
    snap = await fdb.status_snapshot()
    if not snap["configured"] or str(snap["status"]) in (
            FDB_DISABLED, FDB_TOKEN_INVALID, FDB_UNCONFIGURED):
        return False
    cred = await db.get_network_bot_credential(int(bot_row["network_bot_id"]))
    return bool(cred and cred.get("encrypted_token"))


# ---------------------------------------------------------------------------
# Delivery job engine (spec §53-§57)
# ---------------------------------------------------------------------------
class DeliveryJobEngine:
    """Durable delivery jobs + retries + TTL + reconciliation (B17).

    The INLINE pipeline is used by the user-facing request path (fast,
    synchronous): create job → channel-only delivery (Mode B
    fdb_direct → Mode C handoff) → cleanup when applicable.
    Any failure leaves the job in a retryable state; the background
    sweeper (spec §54/§55/§57 + the B17 handoff lifecycle) retries with
    exponential backoff, cleans LEGACY relays past the TTL (compat),
    expires untapped handoffs, and reconciles crash-interrupted jobs.
    """

    def __init__(self, db, fdb: FileDeliveryBotManager,
                 resolve_network_bot_id: Optional[
                     Callable[[Any], Optional[int]]] = None) -> None:
        self.db = db
        self.fdb = fdb
        self._task: Optional[asyncio.Task] = None
        # B17 Mode A capability cache: (network_bot_id, storage_chat_id)
        # → (can: bool, cached_at: float) once PROBED by a real copy
        # attempt ("the network bot can / cannot see the storage master"
        #). Never assumed — bot-18.log proved assuming it delivers
        # nothing.
        #
        # FINAL-1 PRODUCTION FIX (bot-20.log jobs 38/39/40): the OLD cache
        # stored a bare False FOREVER — job 38's storage "Chat not found"
        # poisoned (nid, storage) for the WHOLE PROCESS LIFE, so jobs
        # 39/40+ logged capability_cached_no even after the operator
        # fixed storage membership (no TTL, no invalidation, no re-probe
        # — only a restart cleared it). NOW:
        #   * NEGATIVE entries carry a TTL (MODE_A_NEGATIVE_TTL = one
        #     health-pass interval). An expired entry is dropped and the
        #     next delivery RE-PROBES Mode A (the real copy IS the probe).
        #   * Every negative write is LOGGED (MODE_A_CAPABILITY_NEGATIVE_
        #     CACHED with nid + storage_chat + ttl) — the cache write is
        #     visible evidence, never a silent poison.
        #   * refresh_mode_a_capability() (wired into the periodic health
        #     loop) re-probes cached-negative pairs with the network bot's
        #     own client (get_chat on the storage chat) and RESTORES the
        #     capability the moment access returns — no restart needed.
        self._mode_a_capability: Dict[tuple, tuple] = {}
        self._mode_a_neg_announced: set = set()
        # BOT-11 §9 (B11-A): worker-manager lookup injected at wiring time
        # (init_network_services) — resolves the network_bot_id for a live
        # PTB Bot CLIENT (bot_data lives on Application, never on Bot —
        # the bot-11.log network_bot_id=0 root cause). Optional: tests and
        # older wiring keep the legacy resolution chain.
        self._resolve_network_bot_id = resolve_network_bot_id
        fdb.job_sweeper = self

    # ------------------------------------------------------------------
    # Inline pipeline
    # ------------------------------------------------------------------
    async def _resolve_target_nid(self, network_bot,
                                  network_bot_id: Optional[int]) -> int:
        """BOT-11 §9 network_bot_id resolution chain (never guess):

        explicit param → client stamp (``_network_bot_id``) → injected
        worker-manager lookup → legacy ``bot_data`` attempt → 0.

        A PTB ``Bot`` client carries NO ``bot_data`` (that attribute lives
        on ``Application``) — the manager lookup is what resolves real
        worker-context deliveries; the legacy attempt stays LAST so the
        historical fake-transport tests keep working.
        """
        try:
            nid = int(network_bot_id or 0)
        except (TypeError, ValueError):
            nid = 0
        if nid:
            return nid
        # 2) client stamp (workers.py may stamp the id on the client).
        try:
            stamp = int(getattr(network_bot, "_network_bot_id", 0) or 0)
        except (TypeError, ValueError):
            stamp = 0
        if stamp:
            return stamp
        # 3) worker-manager lookup (sync or async callable).
        resolver = self._resolve_network_bot_id
        if resolver is not None:
            try:
                res = resolver(network_bot)
                if asyncio.iscoroutine(res):
                    res = await res
                res = int(res or 0)
            except Exception:  # noqa: BLE001 — lookup must never crash delivery
                res = 0
            if res:
                return res
        # 4) legacy attempt (Application-style objects / test fakes).
        bd = getattr(network_bot, "bot_data", None)
        if isinstance(bd, dict):
            try:
                return int(bd.get("network_bot_id") or 0)
            except (TypeError, ValueError):
                return 0
        return 0

    async def deliver(self, *, network_bot, chat_id: int, file_row: Dict,
                      protect_content: bool = False,
                      payload_code: Optional[str] = None,
                      payload_id: Optional[int] = None,
                      user_id: Optional[int] = None,
                      network_bot_id: Optional[int] = None,
                      ) -> Optional[int]:
        """Deliver ONE file through the V25 FINAL TWO-STAGE strategy:

            SOURCE / STORAGE CHANNEL
                ↓ Stage A (File Delivery Bot copyMessage / identity send)
            DELIVERY CHANNEL (network_bots.delivery_channel_chat_id)
                ↓ Stage B (Network Bot copyMessage — the FINAL
                   user-facing send, a TRUE copy with NO forward header)
            DESTINATION USER

        The File Delivery Bot is NEVER the final user-facing sender
        (bot-35.log FDB_DIRECT_DELIVERY_* is removed from production
        routing); the Network Bot never reads the Storage Channel (its
        ONLY source is the Delivery Channel message). The user is
        talking to the NETWORK bot (they clicked its payload link), so
        Stage B succeeds without any handoff.

        Returns the user-facing message id, or None on failure
        (honestly classified + scheduled for retry when retryable).

        BOT-11 §9 delivery-chain structured logs (opaque ids only, never
        tokens): DELIVERY_RESOLVE_START / DELIVERY_PERMISSION_CHECK /
        DELIVERY_SOURCE_FILE_RESOLVED / DELIVERY_SEND_START /
        DELIVERY_SEND_FAILED + DELIVERY_TARGET_BOT_UNRESOLVED when the
        serving network bot's id cannot be resolved (honest failure —
        NEVER a nid=0 guess).
        """
        # BOT-11 §9: delivery-chain trace start (job fields, opaque ids).
        logger.info(
            "DELIVERY_RESOLVE_START user_id=%s chat_id=%s file_pk=%s "
            "payload_code=%s payload_id=%s network_bot_id_param=%s",
            user_id or chat_id, chat_id, file_row.get("id"),
            payload_code or "-", payload_id or 0, network_bot_id or 0)
        nid = await self._resolve_target_nid(network_bot, network_bot_id)
        if not nid:
            # bot-11.log root cause: every worker-context delivery got
            # nid=0 → NO_DELIVERY_GROUP. Now an HONEST failure — never
            # a delivery-group lookup with a guessed 0 id.
            logger.error(
                "DELIVERY_TARGET_BOT_UNRESOLVED (the serving network bot's "
                "registry id could not be resolved — no explicit param, no "
                "client stamp, no live worker-manager match, no bot_data; "
                "refusing to guess)")
            logger.error("DELIVERY_SEND_FAILED reason=target_bot_unresolved")
            return None
        # V25 FINAL: the Delivery Channel is resolved from the network
        # bot's OWN row (network_bots.delivery_channel_chat_id, schema
        # v42 — the legacy group table is never consulted).
        channel_id = await self._resolve_delivery_channel(nid)
        if not channel_id:
            logger.error(
                "DELIVERY_CHANNEL_UNCONFIGURED network_bot_id=%s chat_id=%s "
                "(V25 FINAL: the two-stage architecture REQUIRES a Delivery "
                "Channel — a private channel where BOTH the File Delivery "
                "Bot and this network bot are admins. Configure it via "
                "/setup in that channel, or My Network → Delivery; legacy "
                "delivery-group chats migrate automatically on schema v42)",
                nid, chat_id)
            logger.error("DELIVERY_SEND_FAILED "
                         "reason=delivery_channel_unconfigured "
                         "network_bot_id=%s", nid)
            return None
        logger.info(
            "DELIVERY_TWO_STAGE_ROUTE job_id=- network_bot_id=%s "
            "chat_id=%s delivery_channel_id=%s (V25 FINAL: storage channel "
            "→ File Delivery Bot → Delivery Channel → Network Bot → user; "
            "the FDB is never the final user-facing sender; no group is "
            "required or configured)", nid, chat_id, channel_id)
        # BOT-11 §9: relay-plane permission trace (defensive — patched
        # fdb fakes in tests may not expose status_snapshot).
        try:
            snap = await self.fdb.status_snapshot()
            fdb_configured = bool(snap.get("configured"))
            fdb_status = str(snap.get("status") or "-")
        except Exception:  # noqa: BLE001 — diagnostics only
            fdb_configured = bool(getattr(self.fdb, "configured", False))
            fdb_status = "-"
        logger.info("DELIVERY_PERMISSION_CHECK fdb_configured=%s "
                    "fdb_status=%s network_bot_id=%s delivery_channel_id=%s",
                    fdb_configured, fdb_status, nid, channel_id)
        try:
            storage_chat = int(file_row["channel_id"])
            storage_msg = int(file_row["message_id"])
        except (KeyError, TypeError, ValueError):
            logger.error("DELIVERY_JOB_FAILED reason=no_source_ref "
                         "file_pk=%s", file_row.get("id"))
            logger.error("DELIVERY_SEND_FAILED reason=no_source_ref "
                         "file_pk=%s", file_row.get("id"))
            return None
        # BOT-11 §9: source-file resolution trace.
        logger.info("DELIVERY_SOURCE_FILE_RESOLVED file_pk=%s "
                    "storage_chat_id=%s storage_message_id=%s "
                    "network_bot_id=%s delivery_channel_id=%s",
                    file_row.get("id"), storage_chat,
                    storage_msg, nid, channel_id)
        job_id = await self.db.insert_delivery_job(
            user_id=int(user_id or chat_id), network_bot_id=nid,
            payload_id=payload_id, payload_code=payload_code,
            file_pk=file_row.get("id"), storage_chat_id=storage_chat,
            storage_message_id=storage_msg,
            delivery_group_chat_id=None,
            max_attempts=await self.db.get_setting_int(
                DELIVERY_SETTING_MAX_ATTEMPTS,
                DELIVERY_DEFAULT_MAX_ATTEMPTS))
        logger.info("DELIVERY_JOB_CREATED job_id=%s network_bot_id=%s "
                    "file_pk=%s delivery_channel_id=%s "
                    "mode_plan=two_stage(A→B)",
                    job_id, nid, file_row.get("id"), channel_id)
        # BOT-11 §9: send-phase trace start.
        logger.info("DELIVERY_SEND_START job_id=%s network_bot_id=%s "
                    "chat_id=%s mode=delivery_channel", job_id, nid,
                    chat_id)
        return await self._deliver_layered(
            network_bot=network_bot, chat_id=chat_id, job_id=job_id, nid=nid,
            group_chat=None, storage_chat=storage_chat,
            storage_msg=storage_msg, protect_content=protect_content,
            file_row=file_row)

    async def _resolve_delivery_channel(self, nid: int) -> Optional[int]:
        """V25 FINAL: the network bot's Delivery Channel — read from the
        AUTHORITATIVE network_bots row (schema v42 column; the legacy
        network_delivery_groups table is never consulted for routing).
        Defensive against DB fakes without the column: a missing
        get_network_bot / KeyError / NULL resolves honestly to None
        (the caller fails with DELIVERY_CHANNEL_UNCONFIGURED)."""
        try:
            row = await self.db.get_network_bot(int(nid))
        except Exception:  # noqa: BLE001 — fake DBs / dead repo
            return None
        if not row:
            return None
        try:
            cid = int(row.get("delivery_channel_chat_id") or 0)
        except (TypeError, ValueError, KeyError):
            return None
        return cid or None

    # ------------------------------------------------------------------
    # B17 — the delivery strategy (one implementation shared by the inline
    # pipeline and the sweeper's retry plane). V25 FINAL: TWO-STAGE.
    # ------------------------------------------------------------------
    async def _deliver_layered(self, *, network_bot, chat_id: int,
                               job_id: int, nid: int,
                               group_chat: Optional[int],
                               storage_chat: int, storage_msg: int,
                               protect_content: bool,
                               file_row: Optional[Dict[str, Any]] = None,
                               delivery_channel_id: Optional[int] = None,
                               delivery_message_id: Optional[int] = None,
                               ) -> Optional[int]:
        """V25 FINAL TWO-STAGE: Stage A (FDB → Delivery Channel) →
        Stage B (Network Bot → user).

        The production delivery graph is ALWAYS:

            STORAGE CHANNEL → FILE DELIVERY BOT → DELIVERY CHANNEL
                → NETWORK BOT → USER

        The File Delivery Bot is NEVER the final user-facing sender
        (bot-35.log evidence); the Network Bot's ONLY copy source is
        the Delivery Channel message (never the Storage Channel). The
        ``group_chat`` parameter is DEPRECATED AND IGNORED (legacy
        callers/tests bind); no routing decision reads it.

        Retry/reconciliation semantics: ``delivery_message_id`` may be
        pre-supplied (a sweeper retry or crash recovery with Stage A
        already complete) — Stage A is then SKIPPED; a Stage-B
        "message to copy not found" self-heals by re-running Stage A
        exactly once (§7 stale relay reference recovery).

        V25 (§18) HIDE SOURCE — COPY semantics: when the AUTHORITATIVE
        hide_source protection setting is ON the durable marker
        ``hide_source_copy_semantics`` is recorded and the
        DELIVERY_HIDE_SOURCE_COPY trace fires — BOTH hops are TRUE
        copyMessage operations (no forward header anywhere), so the
        requirement is satisfied by the architecture itself for BOTH
        settings values; the marker preserves the §18 observability.
        The setting is read from the backend bot_settings table ONLY
        (never any frontend flag).

        Returns the user-facing message id, or None on failure.
        """
        # ---- V25 FINAL + §18: two-stage routing + the durable topology --
        # ---- marker (hide_source ON keeps its §18 copy-semantics ------
        # ---- marker; OFF records the delivery-channel architecture) ---
        hide_source = False
        try:
            hide_source = bool(await self.db.get_setting_bool(
                "prot_v3_hide_source", True))
        except Exception:  # noqa: BLE001 — authoritative read, fail-open OFF
            hide_source = False
        _topology_marker = ("hide_source_copy_semantics" if hide_source
                            else "delivery_channel_architecture")
        try:
            await self.db.update_delivery_job(
                job_id, mode_a_failure=_topology_marker,
                mode_a_failure_at=_now_iso())
        except Exception:  # noqa: BLE001 — metrics persistence is best-effort
            pass
        if hide_source:
            logger.info(
                "DELIVERY_HIDE_SOURCE_COPY job_id=%s network_bot_id=%s "
                "chat_id=%s reason=hide_source_on (V25 FINAL two-stage + "
                "§18: BOTH hops are copyMessage — true COPIES with NO "
                "Forwarded-from provenance anywhere in the chain; the "
                "authoritative backend setting is ON)",
                job_id, nid, chat_id)
        else:
            logger.info(
                "DELIVERY_CHANNEL_ROUTE job_id=%s network_bot_id=%s "
                "chat_id=%s (V25 FINAL: storage channel → File Delivery "
                "Bot → Delivery Channel → Network Bot → user — no delivery "
                "group exists, is required, or is consulted; the FDB is "
                "never the final user-facing sender)", job_id, nid, chat_id)

        # ---- resolve the Delivery Channel (retry rows may re-resolve) ---
        channel_id = int(delivery_channel_id or 0)
        if not channel_id:
            channel_id = int(await self._resolve_delivery_channel(nid) or 0)
        if not channel_id:
            logger.error(
                "DELIVERY_CHANNEL_UNCONFIGURED job_id=%s network_bot_id=%s "
                "(retry path: the bot has no Delivery Channel configured — "
                "configure it via /setup in the private channel where both "
                "the FDB and the network bot are admins)",
                job_id, nid)
            await self._fail_or_retry(job_id, "delivery_channel_unconfigured")
            return None

        # ---- Stage A: the FDB writes the Delivery Channel message ------
        if delivery_message_id:
            # Retry/reconciliation fast path: Stage A already completed
            # (the durable delivery_message_id is the evidence).
            logger.info(
                "DELIVERY_CHANNEL_MESSAGE_READY job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s "
                "via=existing (Stage A already complete — retry proceeds "
                "straight to the Stage-B user copy)", job_id, channel_id,
                int(delivery_message_id))
        else:
            stage_a = getattr(self.fdb, "copy_storage_to_delivery_channel",
                              None)
            if not callable(stage_a):
                logger.error(
                    "DELIVERY_SEND_FAILED reason=stage_a_unavailable "
                    "job_id=%s (the manager does not expose the V25 FINAL "
                    "Stage-A primitive)", job_id)
                await self._fail_or_retry(job_id, "stage_a_unavailable")
                return None
            await self.db.update_delivery_job(
                job_id, status=JOB_RELAY_CREATING,
                delivery_mode=DM_DELIVERY_CHANNEL,
                delivery_channel_id=channel_id)
            dmid, verdict = await stage_a(
                int(channel_id), int(storage_chat), int(storage_msg),
                protect_content=protect_content, file_row=file_row,
                job_id=int(job_id))
            if dmid is None:
                logger.error(
                    "DELIVERY_STAGE_A_FAILED job_id=%s network_bot_id=%s "
                    "delivery_channel_id=%s verdict=%s (the File Delivery "
                    "Bot could not create the Delivery Channel message)",
                    job_id, nid, channel_id, verdict)
                await self._fail_or_retry(
                    job_id, f"stage_a_failed[{verdict}]")
                return None
            delivery_message_id = int(dmid)
            await self.db.update_delivery_job(
                job_id, status=JOB_RELAYED,
                delivery_channel_id=channel_id,
                delivery_message_id=delivery_message_id,
                relay_message_id=delivery_message_id,
                relay_created_at=_now_iso(),
                # V26.x Phase 3: the Delivery Channel SOURCE message now
                # EXISTS — the cleanup is owed until the confirmed FDB
                # delete clears this flag (post-delivery or sweeper).
                channel_cleanup_pending=1)
            logger.info(
                "DELIVERY_CHANNEL_MESSAGE_READY job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s (Stage A "
                "complete — the Network Bot's user-facing copy reads FROM "
                "this Delivery Channel message)", job_id, channel_id,
                delivery_message_id)

        # ---- Stage B: the Network Bot performs the FINAL user-facing ----
        # ---- send: copyMessage Delivery Channel → user (never forward) --
        await self.db.update_delivery_job(
            job_id, status=JOB_DELIVERING,
            delivery_mode=DM_DELIVERY_CHANNEL)
        logger.info(
            "NETWORK_BOT_COPY_TO_USER_START job_id=%s network_bot_id=%s "
            "chat_id=%s delivery_channel_id=%s delivery_message_id=%s",
            job_id, nid, chat_id, channel_id, delivery_message_id)
        mid, verdict = await self._copy_channel_to_user(
            network_bot, int(chat_id), int(channel_id),
            int(delivery_message_id), protect_content=bool(protect_content),
            nid=int(nid))
        if mid is None and verdict == "channel_message_gone":
            # §7/§10 stale-reference self-heal: the Delivery Channel
            # message is gone (deleted/expired) — re-run Stage A ONCE,
            # then retry the Stage-B copy with the fresh message id.
            logger.warning(
                "DELIVERY_CHANNEL_MESSAGE_STALE job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s (the "
                "channel message is no longer copyable — re-running "
                "Stage A once to recreate it)", job_id, channel_id,
                delivery_message_id)
            stage_a = getattr(self.fdb, "copy_storage_to_delivery_channel",
                              None)
            if callable(stage_a):
                dmid2, verdict2 = await stage_a(
                    int(channel_id), int(storage_chat), int(storage_msg),
                    protect_content=protect_content, file_row=file_row,
                    job_id=int(job_id))
                if dmid2 is not None:
                    delivery_message_id = int(dmid2)
                    await self.db.update_delivery_job(
                        job_id, delivery_message_id=delivery_message_id,
                        relay_message_id=delivery_message_id,
                        relay_created_at=_now_iso(),
                        channel_cleanup_pending=1)
                    logger.info(
                        "DELIVERY_CHANNEL_MESSAGE_READY job_id=%s "
                        "delivery_channel_id=%s delivery_message_id=%s "
                        "via=self_heal (Stage A re-ran after a stale "
                        "channel message)", job_id, channel_id,
                        delivery_message_id)
                    mid, verdict = await self._copy_channel_to_user(
                        network_bot, int(chat_id), int(channel_id),
                        int(delivery_message_id),
                        protect_content=bool(protect_content), nid=int(nid))
        if mid is not None:
            await self.db.update_delivery_job(
                job_id, status=JOB_DELIVERED, delivered_at=_now_iso(),
                last_error=None, user_message_id=int(mid),
                delivery_mode=DM_DELIVERY_CHANNEL)
            logger.info(
                "NETWORK_BOT_COPY_TO_USER_SUCCESS job_id=%s msg_id=%s "
                "user_msg=%s mode=delivery_channel (Stage B complete — the "
                "NETWORK BOT performed the final user-facing copy FROM "
                "the Delivery Channel)",
                job_id, mid, mid)
            # V26.x Phase 3: the user delivery is CONFIRMED (user_message_id
            # recorded) — delete the exact Delivery Channel SOURCE message
            # now (the FDB is its author). A failure is honest + retried by
            # the reconciliation sweeper; it never touches the delivered
            # record or the Storage master.
            try:
                await self._cleanup_channel_source(
                    int(job_id), int(channel_id), int(delivery_message_id),
                    nid=int(nid), via="post_delivery_single")
            except Exception as exc:  # noqa: BLE001 — cleanup never fails
                logger.warning(
                    "DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
                    "reason=cleanup_exception error_class=%s (the sweeper "
                    "will retry)", job_id, type(exc).__name__)
            return mid
        logger.error(
            "DELIVERY_SEND_FAILED reason=final_delivery_failed "
            "job_id=%s network_bot_id=%s chat_id=%s verdict=%s "
            "mode=delivery_channel", job_id, nid, chat_id, verdict)
        await self._fail_or_retry(job_id, f"final_delivery_failed[{verdict}]")
        return None

    async def _copy_channel_to_user(self, network_bot, chat_id: int,
                                    channel_id: int, delivery_message_id: int,
                                    *, protect_content: bool,
                                    nid: int = 0) -> tuple:
        """V25 FINAL STAGE B — the Network Bot's user-facing copyMessage:
        Delivery Channel → user.

        A TRUE copy (no Forwarded-from header — Hide Source semantics by
        construction; NEVER forwardMessage). Errors are honestly
        classified; ``channel_message_gone`` lets the caller self-heal by
        re-running Stage A. Returns ``(message_id | None, verdict)``.
        """
        from telegram.error import BadRequest, Forbidden, RetryAfter
        for attempt in (1, 2):
            try:
                result = await network_bot.copy_message(
                    chat_id=int(chat_id),
                    from_chat_id=int(channel_id),
                    message_id=int(delivery_message_id),
                    protect_content=bool(protect_content))
                mid = int(getattr(result, "message_id", 0) or 0) or None
                if mid is None:
                    return None, "no_message_id"
                return mid, "ok"
            except RetryAfter as exc:
                logger.warning(
                    "NETWORK_BOT_COPY_TO_USER_RETRY_AFTER job_id=- "
                    "chat_id=%s delivery_channel_id=%s "
                    "delivery_message_id=%s retry_after=%ss attempt=%s",
                    chat_id, channel_id, delivery_message_id,
                    int(getattr(exc, "retry_after", 3)), attempt)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except Forbidden as exc:
                logger.warning(
                    "NETWORK_BOT_COPY_TO_USER_FORBIDDEN chat_id=%s "
                    "delivery_channel_id=%s delivery_message_id=%s "
                    "error_class=Forbidden error=%s (the user blocked the "
                    "network bot — the honest verdict; no hidden "
                    "direct-to-user fallback exists)",
                    chat_id, channel_id, delivery_message_id,
                    str(exc)[:160])
                return None, "forbidden"
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                logger.warning(
                    "NETWORK_BOT_COPY_TO_USER_BAD_REQUEST chat_id=%s "
                    "delivery_channel_id=%s delivery_message_id=%s "
                    "error_class=BadRequest error=%s classification=%s "
                    "hop=stage_b_user_copy",
                    chat_id, channel_id, delivery_message_id,
                    str(exc)[:200], cinfo["classification"])
                if "message to copy not found" in low \
                        or "message to forward not found" in low:
                    # The Delivery Channel message is gone — the caller
                    # self-heals by re-running Stage A (never proof of
                    # source deletion on its own).
                    return None, "channel_message_gone"
                if "chat not found" in low or "bot is not a member" in low \
                        or "bot was kicked" in low:
                    # The NETWORK BOT lost the Delivery Channel (its
                    # Stage-B copy source) — honest verdict + remediation.
                    return None, "bad_request:channel_inaccessible:" \
                                 + str(exc)[:120]
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning(
                    "NETWORK_BOT_COPY_TO_USER_TRANSIENT attempt=%s "
                    "chat_id=%s delivery_channel_id=%s "
                    "delivery_message_id=%s error_class=%s error=%s "
                    "hop=stage_b_user_copy",
                    attempt, chat_id, channel_id, delivery_message_id,
                    type(exc).__name__, str(exc)[:120])
                await asyncio.sleep(1.5)
        return None, "transient"

    async def deliver_album(self, *, network_bot, chat_id: int,
                            file_rows: List[Dict[str, Any]],
                            protect_content: bool = False,
                            payload_code: Optional[str] = None,
                            payload_id: Optional[int] = None,
                            user_id: Optional[int] = None,
                            network_bot_id: Optional[int] = None,
                            ) -> tuple:
        """V25 FINAL §6/§7 — MULTI-FILE / ALBUM delivery, two-stage.

        Stage A: the FDB copies EVERY file Storage → Delivery Channel
        (in order; one durable job per file carrying its own
        delivery_channel_id + delivery_message_id).

        Stage B: the Network Bot delivers the collection to the user as
        REAL Telegram albums — the ``copyMessages`` Bot API (7.17+,
        PTB >= 21.11) copied from the Delivery Channel in deterministic
        chunks of ≤ 10 album-eligible consecutive files (Telegram's
        media-group limit), preserving part order and collection
        identity. Non-album types (documents etc.) and mixed-type runs
        are delivered as ordered single copyMessage sends. When the
        client/API does not support copyMessages the fallback is an
        HONEST sequential copyMessage per file (order preserved,
        logged NETWORK_BOT_ALBUM_FALLBACK — never unrelated messages
        presented as an album).

        Returns ``(list_of_user_message_ids, sent_count)`` — the ids in
        the collection's canonical order.
        """
        logger.info(
            "DELIVERY_ALBUM_START chat_id=%s files=%s payload_code=%s "
            "payload_id=%s", chat_id, len(file_rows), payload_code or "-",
            payload_id or 0)
        nid = await self._resolve_target_nid(network_bot, network_bot_id)
        if not nid:
            logger.error(
                "DELIVERY_TARGET_BOT_UNRESOLVED (album: the serving "
                "network bot's registry id could not be resolved — "
                "refusing to guess)")
            return [], 0
        channel_id = int(await self._resolve_delivery_channel(nid) or 0)
        if not channel_id:
            logger.error(
                "DELIVERY_CHANNEL_UNCONFIGURED network_bot_id=%s chat_id=%s "
                "(album: the two-stage architecture REQUIRES a Delivery "
                "Channel — /setup in the private channel where both the "
                "FDB and the network bot are admins)", nid, chat_id)
            return [], 0
        # ---- Stage A: one job + one channel message per file, in order --
        stage_a = getattr(self.fdb, "copy_storage_to_delivery_channel", None)
        if not callable(stage_a):
            logger.error("DELIVERY_SEND_FAILED reason=stage_a_unavailable "
                         "(album: the manager lacks the Stage-A primitive)")
            return [], 0
        entries: List[Dict[str, Any]] = []
        for frow in file_rows:
            try:
                storage_chat = int(frow["channel_id"])
                storage_msg = int(frow["message_id"])
            except (KeyError, TypeError, ValueError):
                logger.error(
                    "DELIVERY_JOB_FAILED reason=no_source_ref file_pk=%s "
                    "(album member skipped — the collection continues)",
                    frow.get("id"))
                continue
            job_id = await self.db.insert_delivery_job(
                user_id=int(user_id or chat_id), network_bot_id=nid,
                payload_id=payload_id, payload_code=payload_code,
                file_pk=frow.get("id"), storage_chat_id=storage_chat,
                storage_message_id=storage_msg,
                delivery_group_chat_id=None,
                max_attempts=await self.db.get_setting_int(
                    DELIVERY_SETTING_MAX_ATTEMPTS,
                    DELIVERY_DEFAULT_MAX_ATTEMPTS))
            await self.db.update_delivery_job(
                job_id, status=JOB_RELAY_CREATING,
                delivery_mode=DM_DELIVERY_CHANNEL)
            dmid, verdict = await stage_a(
                int(channel_id), int(storage_chat), int(storage_msg),
                protect_content=protect_content, file_row=dict(frow),
                job_id=int(job_id))
            if dmid is None:
                logger.error(
                    "DELIVERY_STAGE_A_FAILED job_id=%s file_pk=%s "
                    "verdict=%s (album member failed honestly — the rest "
                    "of the collection still delivers)", job_id,
                    frow.get("id"), verdict)
                await self._fail_or_retry(
                    job_id, f"stage_a_failed[{verdict}]")
                continue
            await self.db.update_delivery_job(
                job_id, status=JOB_RELAYED,
                delivery_channel_id=channel_id,
                delivery_message_id=int(dmid),
                relay_message_id=int(dmid),
                relay_created_at=_now_iso(),
                channel_cleanup_pending=1)
            entries.append({"job_id": int(job_id), "file_row": dict(frow),
                            "delivery_message_id": int(dmid)})
        if not entries:
            logger.error(
                "DELIVERY_ALBUM_FAILED chat_id=%s reason=stage_a_all_failed",
                chat_id)
            return [], 0
        logger.info(
            "DELIVERY_CHANNEL_MESSAGES_READY delivery_channel_id=%s "
            "count=%s (Stage A complete for the collection — ordered "
            "delivery_message_ids=%s)", channel_id, len(entries),
            [e["delivery_message_id"] for e in entries])
        # ---- Stage B: album chunks via copyMessages, in order -----------
        all_msg_ids: List[int] = []
        i = 0
        while i < len(entries):
            # Determine the maximal run starting at i that is
            # album-eligible AND <= ALBUM_MAX_ITEMS (10).
            run = []
            j = i
            while j < len(entries) and len(run) < ALBUM_MAX_ITEMS:
                mtype = str(entries[j]["file_row"].get("media_type")
                            or "").lower()
                if mtype not in ALBUM_ELIGIBLE_TYPES:
                    break
                run.append(entries[j])
                j += 1
            if not run:
                # A single non-album file — ordered single copy.
                e = entries[i]
                mid = await self._stage_b_single(
                    network_bot, int(chat_id), int(channel_id),
                    int(e["delivery_message_id"]), e["job_id"],
                    protect_content=bool(protect_content), nid=nid)
                if mid is not None:
                    all_msg_ids.append(mid)
                i += 1
                continue
            mids = await self._stage_b_album_chunk(
                network_bot, int(chat_id), int(channel_id), run,
                protect_content=bool(protect_content), nid=nid)
            all_msg_ids.extend(mids)
            i = j
        sent = len(all_msg_ids)
        logger.info(
            "DELIVERY_ALBUM_RESULT chat_id=%s files=%s delivered=%s "
            "mode=delivery_channel (ordered user message ids=%s)",
            chat_id, len(file_rows), sent, all_msg_ids)
        return all_msg_ids, sent

    # ------------------------------------------------------------------
    # V26.x Phase 3 — Delivery Channel SOURCE cleanup
    # ------------------------------------------------------------------
    async def _cleanup_channel_source(self, job_id: int, channel_id: int,
                                      delivery_message_id: int,
                                      *, nid: int = 0,
                                      via: str = "post_delivery") -> bool:
        """Delete the exact Delivery Channel SOURCE message after the
        user delivery is CONFIRMED (the caller only invokes this for
        jobs whose user_message_id was recorded — DELIVERED).

        Contract (bot-38.log: FDB created Delivery Channel messages
        110-115, NETWORK_BOT_ALBUM_COPY_SUCCESS delivered 6/6, but the
        channel sources were never deleted):
          * authoritative identity: (delivery_channel_id,
            delivery_message_id) — the durable Stage-A pair;
          * the FDB (the message AUTHOR) performs the delete;
          * already-deleted → IDEMPOTENT SUCCESS;
          * RetryAfter → one bounded retry (DELIVERY_CHANNEL_DELETE_RETRY);
          * permission/transient failure → the flag STAYS SET and the
            reconciliation sweeper retries later (the record survives —
            the failure is reported, never hidden);
          * the Storage Channel MASTER is never touched; the USER
            delivery TTL cleanup is a completely independent pass.

        Returns True when the source is confirmed gone (or was never
        owed).
        """
        jid = int(job_id or 0)
        cid = int(channel_id or 0)
        mid = int(delivery_message_id or 0)
        if not (jid and cid and mid):
            # Nothing owed (legacy row / no durable Stage-A identity):
            # confirm the flag cleared so the sweeper never spins on it.
            try:
                await self.db.update_delivery_job(
                    jid, channel_cleanup_pending=0)
            except Exception:  # noqa: BLE001 — flag hygiene, never fatal
                pass
            return True
        logger.info(
            "DELIVERY_CHANNEL_DELETE_START job_id=%s "
            "delivery_channel_id=%s delivery_message_id=%s network_bot_id=%s"
            " via=%s", jid, cid, mid, int(nid or 0), via)
        del_fn = getattr(self.fdb, "delete_delivery_channel_message", None)
        if not callable(del_fn):
            logger.error(
                "DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s "
                "reason=primitive_unavailable (the FDB manager does not "
                "expose the V26.x channel-source delete — the sweeper will "
                "retry once it does)", jid, cid, mid)
            return False
        verdict = await del_fn(cid, mid, job_id=jid)
        if verdict == "retry_after":
            logger.warning(
                "DELIVERY_CHANNEL_DELETE_RETRY job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s "
                "reason=retry_after (one bounded in-line retry)",
                jid, cid, mid)
            await asyncio.sleep(3)
            verdict = await del_fn(cid, mid, job_id=jid)
        if str(verdict) == "ok":
            try:
                await self.db.update_delivery_job(
                    jid, channel_cleanup_pending=0)
            except Exception:  # noqa: BLE001 — flag hygiene, never fatal
                pass
            logger.info(
                "DELIVERY_CHANNEL_DELETE_SUCCESS job_id=%s "
                "delivery_channel_id=%s delivery_message_id=%s via=%s",
                jid, cid, mid, via)
            return True
        logger.warning(
            "DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
            "delivery_channel_id=%s delivery_message_id=%s verdict=%s "
            "(the cleanup flag stays SET — the reconciliation sweeper "
            "retries; the delivered record itself is untouched)",
            jid, cid, mid, str(verdict)[:160])
        return False

    async def _stage_b_single(self, network_bot, chat_id: int,
                              channel_id: int, delivery_message_id: int,
                              job_id: int, *, protect_content: bool,
                              nid: int) -> Optional[int]:
        """Album helper — Stage B for ONE entry (single copyMessage from
        the Delivery Channel; the job settles DELIVERED/FAILED)."""
        logger.info(
            "NETWORK_BOT_COPY_TO_USER_START job_id=%s network_bot_id=%s "
            "chat_id=%s delivery_channel_id=%s delivery_message_id=%s "
            "(single)", job_id, nid, chat_id, channel_id,
            delivery_message_id)
        mid, verdict = await self._copy_channel_to_user(
            network_bot, chat_id, channel_id, delivery_message_id,
            protect_content=protect_content, nid=nid)
        if mid is None and verdict == "channel_message_gone":
            mid, verdict = await self._self_heal_stage_a(
                network_bot, chat_id, channel_id, job_id,
                protect_content=protect_content, nid=nid)
        if mid is not None:
            await self.db.update_delivery_job(
                job_id, status=JOB_DELIVERED, delivered_at=_now_iso(),
                last_error=None, user_message_id=int(mid),
                delivery_mode=DM_DELIVERY_CHANNEL)
            logger.info(
                "NETWORK_BOT_COPY_TO_USER_SUCCESS job_id=%s msg_id=%s "
                "user_msg=%s mode=delivery_channel (single)",
                job_id, mid, mid)
            # V26.x Phase 3: confirmed user delivery — delete the exact
            # Delivery Channel SOURCE message (see _cleanup_channel_source).
            # The authoritative identity is the CURRENT job row: the
            # self-heal path above may have REPLACED delivery_message_id
            # after a stale channel message (the local would be stale).
            dmid_now = int(delivery_message_id)
            try:
                job_row = await self.db.get_delivery_job(int(job_id))
                if job_row and job_row.get("delivery_message_id"):
                    dmid_now = int(job_row["delivery_message_id"])
            except Exception:  # noqa: BLE001 — best-effort identity read
                pass
            try:
                await self._cleanup_channel_source(
                    int(job_id), int(channel_id), int(dmid_now),
                    nid=int(nid), via="post_delivery_single_album_member")
            except Exception as exc:  # noqa: BLE001 — cleanup never fails
                logger.warning(
                    "DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
                    "reason=cleanup_exception error_class=%s (the sweeper "
                    "will retry)", job_id, type(exc).__name__)
            return mid
        await self._fail_or_retry(job_id, f"final_delivery_failed[{verdict}]")
        return None

    async def _self_heal_stage_a(self, network_bot, chat_id: int,
                                 channel_id: int, job_id: int, *,
                                 protect_content: bool,
                                 nid: int) -> tuple:
        """Album helper — re-run Stage A for ONE job whose channel message
        went stale, then retry the Stage-B copy once."""
        job = None
        try:
            job = await self.db.get_delivery_job(int(job_id))
        except Exception:  # noqa: BLE001 — fake DBs
            job = None
        if not job:
            return None, "channel_message_gone"
        try:
            storage_chat = int(job["storage_chat_id"])
            storage_msg = int(job["storage_message_id"])
        except (KeyError, TypeError, ValueError):
            return None, "channel_message_gone"
        frow = None
        fpk = job.get("file_pk")
        if fpk:
            try:
                row = await self.db.get_indexed_file_by_id(int(fpk))
                if row is not None:
                    frow = dict(row)
            except Exception:  # noqa: BLE001
                frow = None
        stage_a = getattr(self.fdb, "copy_storage_to_delivery_channel", None)
        if not callable(stage_a):
            return None, "channel_message_gone"
        logger.warning(
            "DELIVERY_CHANNEL_MESSAGE_STALE job_id=%s delivery_channel_id=%s "
            "(album member — re-running Stage A once)", job_id, channel_id)
        dmid, verdict2 = await stage_a(
            int(channel_id), int(storage_chat), int(storage_msg),
            protect_content=protect_content, file_row=frow,
            job_id=int(job_id))
        if dmid is None:
            return None, "channel_message_gone"
        await self.db.update_delivery_job(
            int(job_id), delivery_message_id=int(dmid),
            relay_message_id=int(dmid), relay_created_at=_now_iso(),
            channel_cleanup_pending=1)
        return await self._copy_channel_to_user(
            network_bot, chat_id, channel_id, int(dmid),
            protect_content=protect_content, nid=nid)

    async def _stage_b_album_chunk(self, network_bot, chat_id: int,
                                   channel_id: int, run: List[Dict[str, Any]],
                                   *, protect_content: bool,
                                   nid: int) -> List[int]:
        """Album helper — Stage B for ONE consecutive album-eligible run:
        the Network Bot ``copyMessages`` from the Delivery Channel (a
        REAL Telegram media group), with the honest sequential fallback.
        Returns the ordered user message ids."""
        job_ids = [int(e["job_id"]) for e in run]
        mids_in = [int(e["delivery_message_id"]) for e in run]
        logger.info(
            "NETWORK_BOT_ALBUM_COPY_START chat_id=%s delivery_channel_id=%s "
            "files=%s message_ids=%s network_bot_id=%s",
            chat_id, channel_id, len(run), mids_in, nid)
        copy_many = getattr(network_bot, "copy_messages", None)
        if callable(copy_many):
            try:
                results = await copy_many(
                    chat_id=int(chat_id),
                    from_chat_id=int(channel_id),
                    message_ids=mids_in,
                    protect_content=bool(protect_content))
                ids: List[int] = []
                for r in (results or []):
                    mid = int(getattr(r, "message_id", 0) or 0)
                    if mid:
                        ids.append(mid)
                if ids:
                    for jid, umid in zip(job_ids, ids):
                        await self.db.update_delivery_job(
                            int(jid), status=JOB_DELIVERED,
                            delivered_at=_now_iso(), last_error=None,
                            user_message_id=int(umid),
                            delivery_mode=DM_DELIVERY_CHANNEL)
                    logger.info(
                        "NETWORK_BOT_ALBUM_COPY_SUCCESS chat_id=%s "
                        "delivery_channel_id=%s files=%s user_msg_ids=%s "
                        "(copyMessages — a REAL Telegram media-group album "
                        "copied from the Delivery Channel)",
                        chat_id, channel_id, len(run), ids)
                    # V26.x Phase 3: every album member's user delivery is
                    # CONFIRMED (each user_message_id recorded above) —
                    # delete the exact Delivery Channel SOURCE messages
                    # now. A per-message failure is honest and independent:
                    # only THIS chunk's confirmed sources are attempted;
                    # failed deletions keep their cleanup flag set for the
                    # reconciliation sweeper.
                    for e in run:
                        try:
                            await self._cleanup_channel_source(
                                int(e["job_id"]), int(channel_id),
                                int(e["delivery_message_id"]),
                                nid=int(nid), via="post_delivery_album")
                        except Exception as exc:  # noqa: BLE001
                            logger.warning(
                                "DELIVERY_CHANNEL_DELETE_FAILED job_id=%s "
                                "reason=cleanup_exception error_class=%s "
                                "(the sweeper will retry)",
                                e.get("job_id"), type(exc).__name__)
                    return ids
                logger.warning(
                    "NETWORK_BOT_ALBUM_COPY_EMPTY chat_id=%s files=%s "
                    "(copyMessages returned no message ids — sequential "
                    "fallback)", chat_id, len(run))
            except TypeError as exc:
                logger.warning(
                    "NETWORK_BOT_ALBUM_FALLBACK chat_id=%s files=%s "
                    "reason=copy_messages_unsupported error=%s (this "
                    "client/PTB lacks the copyMessages surface — honest "
                    "sequential per-file copyMessage fallback, order "
                    "preserved)", chat_id, len(run), str(exc)[:160])
            except Exception as exc:  # noqa: BLE001 — honest fallback
                logger.warning(
                    "NETWORK_BOT_ALBUM_FALLBACK chat_id=%s files=%s "
                    "reason=copy_messages_failed error_class=%s error=%s "
                    "(sequential per-file copyMessage fallback, order "
                    "preserved)", chat_id, len(run), type(exc).__name__,
                    str(exc)[:160])
        else:
            logger.warning(
                "NETWORK_BOT_ALBUM_FALLBACK chat_id=%s files=%s "
                "reason=copy_messages_unavailable (the client exposes no "
                "copyMessages method — honest sequential per-file "
                "copyMessage fallback, order preserved)",
                chat_id, len(run))
        # Sequential fallback — order preserved, one copy per file.
        out: List[int] = []
        for e in run:
            mid = await self._stage_b_single(
                network_bot, chat_id, channel_id,
                int(e["delivery_message_id"]), int(e["job_id"]),
                protect_content=protect_content, nid=nid)
            if mid is not None:
                out.append(mid)
        return out

    async def _fdb_relay_create(self, network_bot, job_id: int, nid: int,
                                group_chat: int, storage_chat: int,
                                storage_msg: int) -> tuple:
        """B23-2 HYBRID hop 1 — create the relay/group message VIA THE FDB
        (FileDeliveryBotManager.relay_create_hybrid) + the §2.6 evidence
        classification.

        The primitive logs FDB_RELAY_CREATE_START is emitted here (the
        task-format hop-1 trace), the copy runs on the FDB'S OWN client,
        and a BadRequest failure is re-classified with REAL probe
        evidence (network_delivery_group_access_check — storage probed
        with the FDB's client per §2.1, group with the network bot's)
        BEFORE any verdict is routed. Shared by the Mode-A probe path
        (_mode_a_hybrid_relay) and BOTH relay self-heal paths.

        Returns ``(relay_message_id | None, verdict)`` — verdicts:
        ``ok`` / ``storage_master_inaccessible`` / ``group_lost`` /
        ``forbidden_group`` / ``bad_request:<detail>`` / ``transient`` /
        ``no_message_id`` / ``unconfigured`` / ``fdb_relay_unavailable``.
        """
        relay_fn = getattr(self.fdb, "relay_create_hybrid", None)
        if not callable(relay_fn):
            logger.error("FDB_RELAY_CREATE_FAILED reason=relay_primitive_"
                         "unavailable job_id=%s (the manager does not "
                         "expose the B23-2 hybrid relay primitive — "
                         "honest fallback to Mode B)", job_id)
            return None, "fdb_relay_unavailable"
        logger.info("FDB_RELAY_CREATE_START job_id=%s src=%s/%s "
                    "network_bot_id=%s group=%s",
                    int(job_id), storage_chat, storage_msg, nid, group_chat)
        relay_mid, verdict = await relay_fn(
            int(group_chat), int(storage_chat), int(storage_msg),
            job_id=int(job_id))
        if relay_mid is not None:
            return relay_mid, "ok"
        if str(verdict).startswith("bad_request:"):
            verdict = await self._classify_fdb_relay_failure(
                network_bot, job_id, nid, group_chat, storage_chat,
                storage_msg, str(verdict))
        return None, verdict

    async def _classify_fdb_relay_failure(self, network_bot, job_id: int,
                                         nid: int, group_chat: int,
                                         storage_chat: int, storage_msg: int,
                                         verdict: str) -> str:
        """§2.6 — the authoritative, evidence-based classification of a
        failed HYBRID hop-1 (FDB copyMessage storage → group).

        The primitive already logged the FIRST emitter
        (FDB_RELAY_CREATE_BAD_REQUEST classification=UNKNOWN_TELEGRAM_
        FAILURE probe=pending_evidence); THIS runs the evidence probe —
        network_delivery_group_access_check with failing_hop=
        'fdb_relay_create' (storage reachability probed with the FDB'S
        client per §2.1, group reachability with the network bot's own
        client) — whose NETWORK_DELIVERY_GROUP_ACCESS_CHECK line carries
        the AUTHORITATIVE classification, then routes the verdict:

          * storage unreachable (FDB probe) → ``storage_master_inaccessible``
            — the File Delivery Bot cannot see the Storage master; the
            delivery group is NOT degraded; remediation: the FDB's
            Storage membership (bot-23.log: this is the EXACT production
            topology when the storage channel drops the FDB);
          * group unreachable (network bot probe) → ``group_lost`` +
            mark_group_lost (the hop-2 forward reads FROM the group, so
            the group being unreachable for the network bot is a real
            pipeline loss);
          * otherwise → the primitive's honest ``bad_request:<detail>``
            (NO group degradation without probe proof — the bot-19.log
            lesson kept under HYBRID).
        """
        text = verdict.split(":", 1)[1] if ":" in verdict else verdict
        low = text.lower()
        evidence: Dict[str, Any] = {}
        try:
            evidence = await self.network_delivery_group_access_check(
                network_bot, network_bot_id=nid or None,
                group_chat_id=group_chat,
                storage_chat_id=storage_chat,
                storage_message_id=storage_msg,
                originating_exception=tg_error.BadRequest(text),
                classification=DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT,
                failing_hop="fdb_relay_create",
                attempt=1) or {}
        except Exception:  # noqa: BLE001 — diagnostics never crash delivery
            pass
        chat_family = ("chat not found" in low
                       or "bot is not a member" in low
                       or "bot was kicked" in low
                       or "not enough rights" in low)
        if not chat_family:
            return verdict
        storage_ok = evidence.get("storage_reachable")
        group_ok = evidence.get("group_reachable")
        if storage_ok is False:
            logger.warning(
                "FDB_RELAY_CREATE_STORAGE_MASTER_INACCESSIBLE job_id=%s "
                "group=%s src=%s/%s error=%s classification=%s "
                "storage_probe_client=fdb group_probe_client=network_bot "
                "(the File Delivery Bot cannot see the STORAGE channel — "
                "under HYBRID the relay hop is the FDB's; the delivery "
                "group is NOT degraded; remediation: add the File "
                "Delivery Bot to the Storage channel, or keep the FDB "
                "direct fallback which is what actually delivers)",
                job_id, group_chat, storage_chat, storage_msg,
                text[:160], DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT)
            return "storage_master_inaccessible"
        if group_ok is False:
            logger.warning(
                "FDB_RELAY_CREATE_GROUP_LOST job_id=%s group=%s src=%s/%s "
                "error=%s (probe-confirmed: the delivery group itself is "
                "unreachable for the network bot — its hop-2 forward "
                "reads FROM the group)",
                job_id, group_chat, storage_chat, storage_msg, text[:160])
            mark_lost = getattr(self.fdb, "mark_group_lost", None)
            if callable(mark_lost):
                await mark_lost(nid or 0,
                                f"group access lost: {text[:120]}")
            return "group_lost"
        # No usable probe evidence — keep the primitive's honest verdict
        # (NEVER degrade the group without proof; the bot-19.log lesson).
        return verdict

    async def _mode_a_hybrid_relay(self, network_bot, job_id: int,
                                   nid: int, group_chat: int,
                                   storage_chat: int, storage_msg: int
                                   ) -> tuple:
        """MODE A (B23 HYBRID) — capability-probed, never assumed.

        HOP 1 runs on the FDB's client: the File Delivery Bot copies the
        Storage master into the Delivery Group (the copy primitive that
        has ALWAYS worked in production — bot-18/bot-22/bot-23 relay
        creations succeeded every time; it was the NETWORK-BOT-authored
        relay hop that "Chat not found" killed). HOP 2 (the network
        bot's forwardMessage group → user) lives in the caller. The
        network bot needs NO Storage access under this architecture.

        The relay capability (the FDB can source-copy THIS storage chat
        into THIS group) is probed by the real copy attempt and cached
        per (network_bot_id, storage_chat) so later deliveries skip the
        doomed hop instantly; the cached negative honors the
        MODE_A_NEGATIVE_TTL and is re-probed by the health pass
        (refresh_mode_a_capability — with the FDB's OWN client).

        Returns ``(relay_message_id | None, verdict)``.
        """
        cap_key = (int(nid), int(storage_chat))
        # FINAL-1: TTL-checked negative cache. A cached "no" is honored
        # only inside MODE_A_NEGATIVE_TTL seconds of the probe that wrote
        # it; after that the entry is DROPPED and the real copy re-probes
        # (bot-20.log: job 38 poisoned the pair for the whole process
        # life — jobs 39/40+ skipped Mode A even after the operator
        # could have fixed storage membership; only a restart cleared
        # the poison). The skip line now carries the evidence fields:
        # the age of the cached verdict and its TTL.
        cached = self._mode_a_capability.get(cap_key)
        if cached is not None and cached[0] is False:
            age = max(0.0, time.time() - float(cached[1]))
            if age < MODE_A_NEGATIVE_TTL:
                logger.info("DELIVERY_MODE_A_SKIPPED job_id=%s "
                            "network_bot_id=%s storage_chat=%s "
                            "reason=capability_cached_no cache_age=%.0fs "
                            "ttl=%.0fs (probe already proved the FDB "
                            "cannot source-copy this storage chat; "
                            "re-probe when the TTL lapses or the health "
                            "pass restores it)",
                            job_id, nid, storage_chat, age,
                            MODE_A_NEGATIVE_TTL)
                return None, "capability_cached_no"
            # Expired negative — drop it and re-probe for real.
            self._mode_a_capability.pop(cap_key, None)
            self._mode_a_neg_announced.discard(cap_key)
            logger.info("MODE_A_CAPABILITY_NEGATIVE_EXPIRED "
                        "network_bot_id=%s storage_chat=%s age=%.0fs "
                        "(re-probing Mode A with a real FDB relay — the "
                        "cached 'no' was never permanent)", nid,
                        storage_chat, age)
        await self.db.update_delivery_job(
            job_id, status=JOB_RELAY_CREATING, delivery_mode=DM_NETWORK_RELAY)
        # The engine wrapper logs FDB_RELAY_CREATE_START (§2.5) + runs the
        # §2.6 evidence classification on BadRequest (the FIRST emitter
        # inside the manager primitive logs UNKNOWN_TELEGRAM_FAILURE +
        # probe=pending_evidence; _classify_fdb_relay_failure produces the
        # authoritative class with the FDB-client storage probe).
        relay_mid, verdict = await self._fdb_relay_create(
            network_bot, job_id, nid, group_chat, storage_chat, storage_msg)
        if relay_mid is not None:
            self._mode_a_capability[cap_key] = (True, time.time())
            await self.db.update_delivery_job(
                job_id, status=JOB_RELAYED, relay_message_id=relay_mid,
                relay_created_at=_now_iso())
            return relay_mid, "ok"
        # FINAL-1: the negative write is LOGGED (who created it, when,
        # against which chat, how long it lives) — never a silent
        # poison of every later delivery.
        self._mode_a_capability[cap_key] = (False, time.time())
        logger.info("MODE_A_CAPABILITY_NEGATIVE_CACHED network_bot_id=%s "
                    "storage_chat=%s verdict=%s ttl=%.0fs (later "
                    "deliveries skip the doomed hop until the TTL lapses "
                    "or the health pass proves access restored)",
                    nid, storage_chat, verdict, MODE_A_NEGATIVE_TTL)
        return None, verdict

    async def refresh_mode_a_capability(self) -> Dict[str, int]:
        """FINAL-1 health-pass hook, B23-2 HYBRID form: re-probe
        CACHED-NEGATIVE Mode-A pairs with the FILE DELIVERY BOT'S OWN
        CLIENT.

        Under HYBRID a cached negative means "the FDB cannot relay
        (storage → group)" — so the re-probe runs getChat(storage_chat)
        with the FDB's client (``self.fdb.client()``; the §2.1 identity —
        the network bot's client is irrelevant for this hop and is never
        used here):
          * reachable NOW  → the negative verdict is STALE (the operator
            re-added the FDB to the Storage channel after the failure):
            the entry is DROPPED so the next delivery uses Mode A again,
            logged as MODE_A_CAPABILITY_RESTORED (with the source:
            health_pass_probe). No restart needed.
          * still failing  → the cached verdict stands (the skip keeps
            answering fast); logged as MODE_A_CAPABILITY_STILL_MISSING
            ONCE per (nid, storage) until it flips (no log spam), with
            the HYBRID remediation: check the FDB's Storage membership.

        Honest unknowns: no live FDB client / no probe method → the
        entry is LEFT AS IS (this method never fabricates a capability
        in either direction).
        Returns {probed, restored, kept, skipped}.
        """
        stats = {"probed": 0, "restored": 0, "kept": 0, "skipped": 0}
        now = time.time()
        negatives = {k: v for k, v in self._mode_a_capability.items()
                     if v[0] is False}
        if not negatives:
            return stats
        # The FDB's OWN live client (the §2.1 storage-hop identity).
        fdb_client = None
        client_fn = getattr(self.fdb, "client", None)
        if callable(client_fn):
            try:
                fdb_client = client_fn()
            except Exception:  # noqa: BLE001 — honest unknown
                fdb_client = None
        if fdb_client is None:
            fdb_client = getattr(self.fdb, "_client", None)
        get_chat = getattr(fdb_client, "get_chat", None) \
            if fdb_client is not None else None
        for (nid, storage_chat), entry in negatives.items():
            if now - float(entry[1]) >= MODE_A_NEGATIVE_TTL:
                # Expired anyway — the delivery path will re-probe for
                # real; nothing to restore here.
                continue
            if not callable(get_chat):
                stats["skipped"] += 1
                continue
            stats["probed"] += 1
            try:
                await get_chat(int(storage_chat))
            except Exception:  # noqa: BLE001 — still inaccessible
                stats["kept"] += 1
                if (nid, storage_chat) not in self._mode_a_neg_announced:
                    self._mode_a_neg_announced.add((nid, storage_chat))
                    logger.warning(
                        "MODE_A_CAPABILITY_STILL_MISSING network_bot_id=%s "
                        "storage_chat=%s probe_client=fdb (the File "
                        "Delivery Bot still cannot see the Storage "
                        "channel — under HYBRID the relay hop is the "
                        "FDB's; Mode A stays skipped, Mode B (FDB direct) "
                        "delivers; remediation: check the FDB's Storage "
                        "channel membership)",
                        nid, storage_chat)
                continue
            # Reachable NOW — the cached negative is stale; restore.
            self._mode_a_capability.pop((nid, storage_chat), None)
            self._mode_a_neg_announced.discard((nid, storage_chat))
            stats["restored"] += 1
            logger.info(
                "MODE_A_CAPABILITY_RESTORED network_bot_id=%s "
                "storage_chat=%s source=health_pass_probe probe_client=fdb "
                "(the File Delivery Bot can see the Storage channel "
                "again — the next delivery uses Mode A (HYBRID "
                "network_relay) instead of the FDB fallback)",
                nid, storage_chat)
        return stats

    async def _copy_storage_to_group_as_network_bot(self, network_bot,
                                                    group_chat: int,
                                                    storage_chat: int,
                                                    storage_msg: int,
                                                    *,
                                                    network_bot_id: int = 0,
                                                    job_id: int = 0
                                                    ) -> tuple:
        """LEGACY (B17/B18) Mode-A relay create — copyMessage storage →
        group BY THE NETWORK BOT (its own relay). B23-2: the production
        Mode-A path no longer calls this (HYBRID hop 1 is the FDB's
        copyMessage via FileDeliveryBotManager.relay_create_hybrid);
        the method is retained as a legacy/classification surface for
        callers and regression suites. Protection NEVER applies on this
        internal hop (BOT-16 policy).

        B18 (bot-19.log 03:18:30): a BadRequest "Chat not found" on THIS
        hop is disambiguated by REAL probe evidence — the network bot's
        own client proves which chat is the invisible one before the
        group is ever marked lost:
          * group unreachable            → verdict group_lost (unchanged);
          * group reachable + Storage
            unreachable                 → verdict storage_master_inaccessible
            (classification STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT —
            the group is NOT touched; bot-19.log's job 34 marked a
            HEALTHY group lost through the old blanket rule);
          * no evidence (probe failed)  → legacy group_lost semantics.
        """
        from telegram.error import BadRequest, Forbidden, RetryAfter
        nid = int(network_bot_id or 0)
        for attempt in (1, 2):
            try:
                msg = await network_bot.copy_message(
                    chat_id=int(group_chat),
                    from_chat_id=int(storage_chat),
                    message_id=int(storage_msg))
                mid = int(getattr(msg, "message_id", 0) or 0) or None
                if mid is None:
                    return None, "no_message_id"
                logger.info(
                    "DELIVERY_RELAY_MESSAGE_CREATED_BY_NETWORK_BOT "
                    "group=%s src=%s/%s relay_message_id=%s "
                    "protect=off(relay)", group_chat, storage_chat,
                    storage_msg, mid)
                return mid, "ok"
            except RetryAfter as exc:
                ra = int(getattr(exc, "retry_after", 3))
                logger.warning(
                    "NETWORK_RELAY_CREATE_RETRY_AFTER group=%s src=%s/%s "
                    "retry_after=%ss attempt=%s classification=%s "
                    "(flood control — no probes while rate-limited)",
                    group_chat, storage_chat, storage_msg, ra, attempt,
                    DC_TELEGRAM_API_RESTRICTION)
                await asyncio.sleep(ra + 1)
            except Forbidden as exc:
                logger.warning("NETWORK_RELAY_CREATE_FORBIDDEN group=%s "
                               "src=%s/%s error=%s", group_chat, storage_chat,
                               storage_msg, str(exc)[:160])
                # B18 Phase-2B: diagnostics run on Forbidden too (the
                # network bot's own client proves WHOSE permission failed).
                try:
                    await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat,
                        storage_message_id=storage_msg,
                        originating_exception=exc,
                        classification=DC_PERMISSION_FAILURE,
                        failing_hop="mode_a_relay_create",
                        attempt=attempt)
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                return None, "forbidden_group"
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                # B23-2 §2.6 (bot-22.log line-63 misread, hardened): the
                # FIRST emitter now logs classification=UNKNOWN_TELEGRAM_
                # FAILURE — the evidence pass below
                # (network_delivery_group_access_check with the network
                # bot's OWN client) logs the AUTHORITATIVE classification
                # with proof in the same second. A speculative pre-probe
                # class can never be misread as a final verdict.
                logger.warning("NETWORK_RELAY_CREATE_BAD_REQUEST group=%s "
                               "src=%s/%s error_class=BadRequest error=%s "
                               "classification=UNKNOWN_TELEGRAM_FAILURE "
                               "probe=pending_evidence",
                               group_chat, storage_chat, storage_msg,
                               str(exc)[:200])
                # B17 FINAL VERIFICATION + B18 identity fix: the REAL
                # diagnostic with the network bot's OWN client — full
                # evidence for WHY the Mode A probe failed (identity /
                # group / membership / source reachability / the exception
                # itself). B18 passes the TRUE registry nid (bot-19.log
                # showed network_bot_id=0 + registered_bot_id=- because the
                # old call guessed via _mode_a_group_nid) and captures the
                # evidence for the disambiguation below.
                evidence: Dict[str, Any] = {}
                try:
                    evidence = await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat,
                        storage_message_id=storage_msg,
                        originating_exception=exc,
                        classification=cinfo["classification"],
                        failing_hop="mode_a_relay_create",
                        attempt=attempt) or {}
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                if "message to copy not found" in low \
                        or "message to forward not found" in low:
                    # THE bot-18.log failure shape — the network bot cannot
                    # see the Storage master (standard deployment: network
                    # bots are NOT storage members). Mode A is impossible;
                    # the capability cache remembers. Classification:
                    # RELAY_INACCESSIBLE_TO_NETWORK_BOT (deletion NOT
                    # proven — the honest class).
                    logger.info(
                        "DELIVERY_MODE_A_PROBE_FAILED group=%s src=%s/%s "
                        "error=%s classification=%s (the network bot "
                        "cannot see the Storage master — Mode B takes "
                        "over)", group_chat,
                        storage_chat, storage_msg, str(exc)[:120],
                        cinfo["classification"])
                    return None, "storage_not_visible_to_network_bot"
                if "chat not found" in low or "bot is not a member" in low \
                        or "bot was kicked" in low \
                        or "not enough rights" in low:
                    # B18 evidence-based disambiguation (bot-19.log
                    # 03:18:30): the access check just PROVED which chat
                    # is invisible with the network bot's OWN client.
                    group_ok = evidence.get("group_reachable")
                    storage_ok = evidence.get("storage_reachable")
                    if group_ok is True and storage_ok is False:
                        # The group is HEALTHY; the STORAGE master is the
                        # invisible chat. Honest verdict + NO group-lost
                        # marking (bot-19.log's job 34 falsely degraded a
                        # healthy delivery group via
                        # DELIVERY_GROUP_CAPABILITY_LOST).
                        logger.warning(
                            "NETWORK_RELAY_CREATE_STORAGE_MASTER_INACCESSIBLE "
                            "group=%s src=%s/%s error=%s classification=%s "
                            "(the network bot cannot see the STORAGE "
                            "channel — the delivery group is verified "
                            "healthy; remediation: add the network bot to "
                            "the Storage channel, or keep the FDB direct "
                            "fallback which is what actually delivers)",
                            group_chat, storage_chat, storage_msg,
                            str(exc)[:160],
                            DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT)
                        return None, "storage_master_inaccessible"
                    if group_ok is False:
                        logger.warning(
                            "NETWORK_RELAY_CREATE_GROUP_LOST group=%s "
                            "src=%s/%s error=%s (probe-confirmed: the "
                            "delivery group itself is unreachable)",
                            group_chat, storage_chat, storage_msg,
                            str(exc)[:160])
                        await self.fdb.mark_group_lost(
                            nid or 0,
                            f"group access lost: {str(exc)[:120]}")
                        return None, "group_lost"
                    # No usable probe evidence — legacy honest semantics.
                    await self.fdb.mark_group_lost(
                        nid or 0,
                        f"group access lost: {str(exc)[:120]}")
                    return None, "group_lost"
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning("NETWORK_RELAY_CREATE_TRANSIENT attempt=%s "
                               "group=%s src=%s/%s error_class=%s error=%s",
                               attempt, group_chat, storage_chat, storage_msg,
                               type(exc).__name__, str(exc)[:120])
                # B18 Phase-2B (bot-19.log job 35): diagnostics execute on
                # TimedOut/NetworkError/unknown exceptions too — the
                # network bot's OWN client provides the evidence (identity,
                # group, membership, storage reachability) that separates
                # "Telegram is slow" from "this hop can never work".
                try:
                    await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat,
                        storage_message_id=storage_msg,
                        originating_exception=exc,
                        classification=classify_telegram_delivery_failure(
                            exc)["classification"],
                        failing_hop="mode_a_relay_create",
                        attempt=attempt)
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                await asyncio.sleep(1.5)
        return None, "transient"

    def _mode_a_group_nid(self, group_chat: int) -> int:
        """Best-effort nid for a group-lost attribution (never guesses in
        the delivery path itself — this is diagnostic attribution only)."""
        return getattr(self, "_last_resolved_nid", 0) or 0

    async def _mode_c_handoff(self, network_bot, job_id: int, chat_id: int,
                              nid: int) -> Optional[int]:
        """MODE C — the one-tap deep-link handoff (bot the user IS talking
        to shows the button; the FDB completes the real send on /start).

        The job settles HANDOFF_PENDING (honest: NOT delivered yet) with a
        single-use token; the FDB's handoff poller completes it, and the
        TTL expires it if the user never taps — never a lying DELIVERED.
        """
        link_fn = getattr(self.fdb, "handoff_deep_link", None)
        if not callable(link_fn):
            logger.error("DELIVERY_SEND_FAILED reason=handoff_unavailable "
                         "job_id=%s (manager lacks the B17 handoff "
                         "surface)", job_id)
            await self._fail_or_retry(job_id, "handoff_unavailable")
            return None
        token = secrets.token_urlsafe(18)
        url = link_fn(token)
        if not url:
            logger.error("DELIVERY_SEND_FAILED "
                         "reason=handoff_unavailable_fdb_username_missing "
                         "job_id=%s (cannot build t.me/<fdb>?start=dl…)",
                         job_id)
            await self._fail_or_retry(
                job_id, "handoff_unavailable_fdb_username_missing")
            return None
        button_mid = await self._send_handoff_button(network_bot, chat_id,
                                                     url)
        if button_mid is None:
            logger.error("DELIVERY_SEND_FAILED "
                         "reason=handoff_button_send_failed job_id=%s "
                         "network_bot_id=%s chat_id=%s", job_id, nid,
                         chat_id)
            await self._fail_or_retry(job_id, "handoff_button_send_failed")
            return None
        await self.db.update_delivery_job(
            job_id, status=JOB_HANDOFF_PENDING, delivery_mode=DM_HANDOFF,
            handoff_token=token, handoff_sent_at=_now_iso(),
            last_error=None)
        logger.info(
            "DELIVERY_HANDOFF_ARMED job_id=%s chat_id=%s "
            "network_bot_id=%s token_prefix=%s (one-tap deep-link button "
            "delivered; completion happens when the user taps and the "
            "FDB poller sees /start dl<token>)", job_id, chat_id, nid,
            token[:6])
        return button_mid

    async def _send_handoff_button(self, network_bot, chat_id: int,
                                   url: str) -> Optional[int]:
        """Send the one-tap handoff button through the NETWORK bot (the
        bot the user is ALREADY talking to — this send always works)."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        from telegram.error import RetryAfter
        markup = InlineKeyboardMarkup(
            [[InlineKeyboardButton("📥 Receive File", url=url)]])
        text = ("Your file is ready — tap the button below to receive it.\n"
                "The platform File Delivery Bot will deliver it to you in "
                "one tap.")
        for attempt in (1, 2):
            try:
                msg = await network_bot.send_message(
                    chat_id=int(chat_id), text=text, reply_markup=markup)
                mid = int(getattr(msg, "message_id", 0) or 0) or None
                if mid is None:
                    logger.warning(
                        "NETWORK_DELIVERY_HANDOFF_BUTTON_NO_MESSAGE_ID "
                        "chat_id=%s", chat_id)
                    return None
                logger.info("NETWORK_DELIVERY_HANDOFF_BUTTON_SENT "
                            "chat_id=%s button_message_id=%s", chat_id, mid)
                return mid
            except RetryAfter as exc:
                logger.warning(
                    "NETWORK_DELIVERY_HANDOFF_BUTTON_RETRY_AFTER chat_id=%s "
                    "retry_after=%ss attempt=%s", chat_id,
                    int(getattr(exc, "retry_after", 3)), attempt)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "NETWORK_DELIVERY_HANDOFF_BUTTON_FAILED chat_id=%s "
                    "error_class=%s error=%s", chat_id,
                    type(exc).__name__, str(exc)[:160])
                return None
        return None

    async def _mark_delivered_and_cleanup(self, job_id: int, sent_mid: int,
                                          group_chat: Optional[int],
                                          relay_mid: Optional[int], *,
                                          mode: str) -> None:
        """DELIVERED only AFTER the real Telegram send returned a message
        id (B17 honesty mandate) + the relay cleanup (spec §57).

        B23-2 §2.5: the success line carries BOTH the explicit
        user-facing message id (``user_msg``) and the legacy ``msg_id``
        field (same value — kept for existing metrics consumers), plus
        the mode — which is only ever network_relay here, because this
        helper is reached exclusively from the Mode-A (HYBRID) path where
        the NETWORK BOT performed the user-facing send."""
        await self.db.update_delivery_job(
            job_id, status=JOB_DELIVERED, delivered_at=_now_iso(),
            last_error=None, user_message_id=int(sent_mid))
        logger.info("NETWORK_DELIVERY_SUCCESS job_id=%s mode=%s user_msg=%s "
                    "msg_id=%s", job_id, mode, sent_mid, sent_mid)
        # Immediate cleanup on success (spec §57) — relay plane only.
        if group_chat and relay_mid:
            await self.db.update_delivery_job(job_id,
                                              status=JOB_DELETE_PENDING)
            if await self.fdb.delete_relay_message(group_chat, relay_mid):
                await self.db.update_delivery_job(
                    job_id, status=JOB_DELETED, deleted_at=_now_iso())
        # DELETE_PENDING leftover (delete failed) is cleaned by the
        # sweeper's TTL pass.
        return sent_mid

    async def network_delivery_group_access_check(
            self, network_bot, *, network_bot_id: int = 0,
            group_chat_id: Optional[int] = None,
            storage_chat_id: Optional[int] = None,
            storage_message_id: Optional[int] = None,
            user_chat_id: Optional[int] = None,
            originating_exception: Optional[BaseException] = None,
            deletion_proven: bool = False,
            attempt: int = 1,
            classification: Optional[str] = None,
            correlation_id: Optional[str] = None,
            failing_hop: Optional[str] = None) -> Dict[str, Any]:
        """B17 FINAL VERIFICATION — the REAL executable delivery diagnostic
        (B23-2 §2.1 identity attribution).

        Runs with the NETWORK BOT'S OWN client (``network_bot`` — the
        client of the bot facing the user) for the GROUP-side probes, and
        with the FILE DELIVERY BOT'S OWN client for the STORAGE-side
        probe (under HYBRID the storage master is read by the FDB — hop
        1 — so storage reachability is an FDB-client fact, never a
        network-bot one). Every hop's evidence records WHICH identity
        probed it (``storage_probe_client`` / ``group_probe_client``).
        Gathers REAL evidence for every field the root-cause analysis
        requires:

          * network bot ID (registry row id) + the REGISTERED bot id and
            username from the registry row (``get_network_bot``);
          * the ACTUAL bot id + username via a live ``get_me()`` on the
            network bot's own client — a mismatch is classified
            BOT_IDENTITY_MISMATCH (the B16 verify could never see this);
          * group chat: live ``get_chat`` (reachable? type?);
          * membership: live ``get_chat_member`` for the network bot's
            own id — status, read capability (privacy-mode evidence),
            send capability where the Telegram response exposes it;
          * the FDB's own membership in the group (when its id is known);
          * source chat/message reachability (``get_chat`` on the copy
            source);
          * copy capability — evidenced by the ORIGINATING exception
            (the real copy attempt that failed), never assumed;
          * the Telegram exception class/code/message, attempt number,
            correlation id and timestamp;
          * B18 ``failing_hop`` — WHICH copy failed
            (``mode_a_relay_create``/``fdb_relay_create`` read FROM
            Storage into the group — the legacy network-bot copy and the
            B23-2 HYBRID hop 1 (the FDB's copy); ``final_user_copy``/
            ``final_user_forward`` read FROM the group into the user
            chat), so ``source_reachable`` reflects the chat the failing
            copy actually READ from (bot-19.log 03:18:32 showed the B17
            logic reporting source_reachable=True for a Mode-A failure
            whose source — the Storage master — was provably
            unreachable).

        Every probe is DEFENSIVE: a client without the method (strict
        test fakes, partial deployments) records ``*_probe_unavailable``
        and the diagnostic still returns the classification derived from
        the real exception. NEVER raises, NEVER logs tokens (none are in
        scope — only opaque ids).
        """
        corr = str(correlation_id or secrets.token_hex(8))
        hop = str(failing_hop or "")
        ev: Dict[str, Any] = {
            "correlation_id": corr,
            "timestamp": _now_iso(),
            "network_bot_id": int(network_bot_id or 0),
            "attempt": int(attempt or 1),
            "failing_hop": hop or None,
            "group_chat": int(group_chat_id) if group_chat_id else None,
            "storage_chat": int(storage_chat_id) if storage_chat_id else None,
            "storage_message": (int(storage_message_id)
                                if storage_message_id else None),
            "user_chat": int(user_chat_id) if user_chat_id else None,
            "deletion_proven": bool(deletion_proven),
            "exception_class": (type(originating_exception).__name__
                                if originating_exception is not None else None),
            "exception_code": (getattr(originating_exception, "code", None)
                               if originating_exception is not None else None),
            "exception_message": (str(originating_exception)[:160]
                                  if originating_exception is not None else None),
            "retry_after": (getattr(originating_exception, "retry_after", None)
                            if originating_exception is not None else None),
        }

        async def _probe(fn, *args):
            """Call a (possibly absent) client method; coroutine-safe."""
            if not callable(fn):
                return None, "probe_unavailable"
            try:
                res = fn(*args)
                if asyncio.iscoroutine(res):
                    res = await res
                return res, None
            except Exception as pexc:  # noqa: BLE001 — probe errors ARE evidence
                return None, f"{type(pexc).__name__}: {str(pexc)[:100]}"

        # -- registered identity (registry row; degraded fakes → unknown) --
        registered_bot_id = registered_username = None
        if ev["network_bot_id"]:
            get_nb = getattr(self.db, "get_network_bot", None)
            if callable(get_nb):
                _row, _err = await _probe(get_nb, ev["network_bot_id"])
                if _row:
                    registered_bot_id = int(_row.get("telegram_bot_id") or 0) or None
                    registered_username = (str(_row.get("username") or "")
                                           .lstrip("@") or None)
                elif _err and _err != "probe_unavailable":
                    ev["registry_probe_error"] = _err
        # -- ACTUAL identity: get_me with the network bot's OWN client ------
        actual_bot_id = actual_username = None
        me, merr = await _probe(getattr(network_bot, "get_me", None))
        if me is not None:
            actual_bot_id = int(getattr(me, "id", 0) or 0) or None
            actual_username = (str(getattr(me, "username", "") or "")
                               .lstrip("@") or None)
            actual_first_name = str(getattr(me, "first_name", "") or "") or None
        else:
            actual_first_name = None
            ev["identity_probe_error"] = merr or "get_me_failed"
        identity_match = None
        if registered_bot_id is not None and actual_bot_id is not None:
            identity_match = registered_bot_id == actual_bot_id
        # -- group reachability + own membership + FDB membership ----------
        #    (the network bot's OWN client — group access is a
        #    network-bot-side fact under HYBRID: hop 2 reads FROM the
        #    group with this very client.)
        group_reachable = group_type = bot_membership = None
        read_capability = send_capability = fdb_membership = None
        group_probe_client = "network_bot"
        if ev["group_chat"]:
            chat, gerr = await _probe(getattr(network_bot, "get_chat", None),
                                      ev["group_chat"])
            if chat is not None:
                group_reachable = True
                group_type = str(getattr(chat, "type", "") or "") or None
                ev["group_title"] = str(getattr(chat, "title", "") or "") or None
            else:
                group_reachable = False
                ev["group_probe_error"] = gerr or "get_chat_failed"
            member_probe_id = actual_bot_id or registered_bot_id
            if member_probe_id:
                member, memb_err = await _probe(
                    getattr(network_bot, "get_chat_member", None),
                    ev["group_chat"], int(member_probe_id))
                if member is not None:
                    bot_membership = str(getattr(member, "status", "") or "") or None
                    can_read = getattr(member, "can_read_all_group_messages", None)
                    if bot_membership in ("administrator", "creator"):
                        read_capability = "yes(admin)"
                    elif can_read is True:
                        read_capability = "yes(privacy_off)"
                    elif can_read is False:
                        read_capability = "limited(privacy_on)"
                    else:
                        read_capability = f"unknown(status={bot_membership})"
                    can_send = getattr(member, "can_send_messages", None)
                    if can_send is True or getattr(
                            member, "can_send_other_messages", False):
                        send_capability = "yes"
                    elif can_send is False:
                        send_capability = "no(restricted)"
                    elif bot_membership == "member":
                        send_capability = "member_default"
                    else:
                        send_capability = f"unknown(status={bot_membership})"
                else:
                    bot_membership = None
                    ev["membership_probe_error"] = memb_err or "probe_failed"
            fdb_id = getattr(self.fdb, "telegram_bot_id", None)
            if fdb_id:
                fm, ferr = await _probe(
                    getattr(network_bot, "get_chat_member", None),
                    ev["group_chat"], int(fdb_id))
                if fm is not None:
                    fdb_membership = str(getattr(fm, "status", "") or "") or None
                else:
                    ev["fdb_membership_probe_error"] = ferr or "probe_failed"
        # -- source reachability: the chat the FAILING copy READ from.
        # B18 (bot-19.log 03:18:32): the B17 logic reported
        # source_reachable=True for a Mode-A failure whose actual source
        # (the Storage master) was provably unreachable — it assumed the
        # final hop's direction. The hop is now EXPLICIT:
        #   * mode_a_relay_create / fdb_relay_create read FROM Storage →
        #     source = storage;
        #   * final_user_copy / final_user_forward read FROM the group →
        #     source = group;
        #   * unknown hop          → both probed, source = the reachable
        #     best-guess with the ambiguity recorded (legacy callers).
        # B23-2 §2.1: the STORAGE probe runs with the FILE DELIVERY
        # BOT'S OWN client — under HYBRID the storage master is read by
        # the FDB (hop 1), so "can the pipeline see Storage?" is an
        # FDB-client fact. The network bot's own storage visibility is
        # irrelevant to this hop (and is never fabricated here).
        storage_reachable = None
        storage_probe_client = "fdb"
        if ev["storage_chat"]:
            fdb_client = None
            client_fn = getattr(self.fdb, "client", None)
            if callable(client_fn):
                try:
                    fdb_client = client_fn()
                except Exception:  # noqa: BLE001 — honest unknown
                    fdb_client = None
            if fdb_client is None:
                fdb_client = getattr(self.fdb, "_client", None)
            fdb_get_chat = (getattr(fdb_client, "get_chat", None)
                            if fdb_client is not None else None)
            if not callable(fdb_get_chat):
                storage_probe_client = "unavailable"
                ev["storage_probe_error"] = "fdb_client_unavailable"
            else:
                st, sterr = await _probe(fdb_get_chat, ev["storage_chat"])
                if st is not None:
                    storage_reachable = True
                    ev["storage_chat_type"] = str(
                        getattr(st, "type", "") or "") or None
                else:
                    storage_reachable = False
                    ev["storage_probe_error"] = sterr or "get_chat_failed"
        if hop in ("mode_a_relay_create", "fdb_relay_create"):
            # The failing copy read FROM the Storage master.
            source_reachable = storage_reachable
        elif hop in ("final_user_copy", "final_user_forward") \
                or (not hop and ev["group_chat"]):
            # Final hop (or legacy direction inference): the copy read
            # FROM the group.
            source_reachable = group_reachable
        elif ev["storage_chat"]:
            source_reachable = storage_reachable
        else:
            source_reachable = None
        # -- copy capability: evidenced by the REAL failing copy attempt ---
        if originating_exception is not None:
            ev["copy_capability"] = (
                f"failed:{type(originating_exception).__name__}:"
                f"{str(originating_exception)[:80]}")
        else:
            ev["copy_capability"] = "unprobed(no_originating_copy_attempt)"
        # -- classification (canonical taxonomy; identity mismatch wins) --
        cls = classification
        if cls is None and originating_exception is not None:
            cls = classify_telegram_delivery_failure(
                originating_exception,
                deletion_proven=deletion_proven)["classification"]
        # B18 (bot-19.log 03:18:32): with the probes' OWN evidence a
        # "chat not found" classification is RE-DERIVED — the Mode-A hop
        # reading FROM a Storage master the network bot cannot see (group
        # proven healthy) is STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT,
        # never GROUP_INACCESSIBLE (the bot-19 misclassification that
        # marked a healthy delivery group lost).
        if cls == DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT and hop:
            cls = classify_telegram_delivery_failure(
                originating_exception,
                deletion_proven=deletion_proven, failing_hop=hop,
                group_reachable=group_reachable,
                storage_reachable=storage_reachable)["classification"]
        if identity_match is False:
            cls = DC_BOT_IDENTITY_MISMATCH
        ev["classification"] = str(cls or DC_UNKNOWN_TELEGRAM_FAILURE)
        ev.update({
            "registered_bot_id": registered_bot_id,
            "registered_username": registered_username,
            "actual_bot_id": actual_bot_id,
            "actual_username": actual_username,
            "actual_first_name": actual_first_name,
            "identity_match": identity_match,
            "group_reachable": group_reachable,
            "group_type": group_type,
            "bot_membership": bot_membership,
            "read_capability": read_capability,
            "send_capability": send_capability,
            "fdb_membership": fdb_membership,
            "source_reachable": source_reachable,
            "storage_reachable": storage_reachable,
            "storage_probe_client": storage_probe_client,
            "group_probe_client": group_probe_client,
        })
        logger.info(
            "NETWORK_DELIVERY_GROUP_ACCESS_CHECK correlation_id=%s "
            "network_bot_id=%s registered_bot_id=%s actual_bot_id=%s "
            "bot_username=%s identity_match=%s group_chat=%s "
            "group_reachable=%s group_type=%s bot_membership=%s "
            "read_capability=%s send_capability=%s fdb_membership=%s "
            "source_chat=%s source_message=%s source_reachable=%s "
            "storage_reachable=%s storage_probe_client=%s "
            "group_probe_client=%s user_chat=%s copy_capability=%s "
            "exception_class=%s exception_code=%s retry_after=%s "
            "exception_message=%s classification=%s deletion_proven=%s "
            "attempt=%s failing_hop=%s timestamp=%s",
            corr, ev["network_bot_id"], registered_bot_id or "-",
            actual_bot_id or "-", actual_username or "-",
            identity_match if identity_match is not None else "-",
            ev["group_chat"] or "-", group_reachable
            if group_reachable is not None else "-", group_type or "-",
            bot_membership or "-", read_capability or "-",
            send_capability or "-", fdb_membership or "-",
            ev["storage_chat"] or "-", ev["storage_message"] or "-",
            source_reachable if source_reachable is not None else "-",
            storage_reachable if storage_reachable is not None else "-",
            storage_probe_client, group_probe_client,
            ev["user_chat"] or "-", ev["copy_capability"],
            ev["exception_class"] or "-", ev["exception_code"] or "-",
            ev["retry_after"] if ev["retry_after"] is not None else "-",
            (ev["exception_message"] or "-").replace("\n", " ")[:120],
            ev["classification"], bool(deletion_proven), ev["attempt"],
            hop or "-", ev["timestamp"])
        return ev

    async def _forward_group_to_user(self, network_bot, chat_id: int,
                                     group_chat: int, relay_mid: int,
                                     protect_content: bool,
                                     network_bot_id: Optional[int] = None,
                                     storage_chat_id: Optional[int] = None,
                                     storage_message_id: Optional[int] = None
                                     ) -> tuple:
        """B23-2 HYBRID HOP 2 — the NETWORK BOT performs forwardMessage
        (delivery group → user, spec §50 user-facing hop).

        forwardMessage is the HYBRID hop-2 primitive: the relay message is
        authored by the FDB (hop 1), and Telegram lets a group member
        forward a message authored by another bot (forwarding needs no
        copy-cache of the original — the exact bot-18.log property that
        made COPY impossible for foreign-authored messages). The verdict
        classification MIRRORS _copy_group_to_user (the legacy copy hop):
        ``ok`` / ``relay_inaccessible`` / ``group_lost`` / ``forbidden`` /
        ``bad_request:<detail>`` / ``transient`` / ``no_message_id``.

        B18 evidence rules kept verbatim: "Chat not found" is
        disambiguated by the REAL probe (network_delivery_group_access_
        check, failing_hop='final_user_forward' — the forward reads FROM
        the group) before the group is ever degraded; "message to
        forward not found" is ``relay_inaccessible`` (deletion NOT
        proven — the honest class); protect_content applies on THIS hop
        only (the user-facing one).
        """
        from telegram.error import BadRequest, Forbidden, RetryAfter
        nid = int(network_bot_id or 0)
        for attempt in (1, 2):
            try:
                result = await network_bot.forward_message(
                    chat_id=int(chat_id), from_chat_id=int(group_chat),
                    message_id=int(relay_mid),
                    protect_content=bool(protect_content))
                mid = int(getattr(result, "message_id", 0) or 0) or None
                if mid is None:
                    return None, "no_message_id"
                return mid, "ok"
            except RetryAfter as exc:
                logger.warning(
                    "NETWORK_DELIVERY_RETRY_AFTER chat=%s group=%s "
                    "relay=%s retry_after=%ss attempt=%s classification=%s "
                    "hop=forward",
                    chat_id, group_chat, relay_mid,
                    int(getattr(exc, "retry_after", 3)), attempt,
                    DC_TELEGRAM_API_RESTRICTION)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except Forbidden as exc:
                logger.warning(
                    "NETWORK_DELIVERY_FORBIDDEN chat=%s group=%s relay=%s "
                    "error_class=Forbidden error=%s classification=%s "
                    "hop=forward (user blocked the bot)",
                    chat_id, group_chat, relay_mid, str(exc)[:160],
                    DC_PERMISSION_FAILURE)
                return None, "forbidden"
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                # §2.6 ordering + the BOT-16 full-context rule: the real
                # Telegram text with the exact chat/group/relay
                # coordinates, the canonical classification, and the REAL
                # evidence probe (network bot's OWN client; hop explicit).
                logger.warning(
                    "NETWORK_DELIVERY_BAD_REQUEST chat=%s group=%s "
                    "relay=%s error_class=BadRequest error=%s "
                    "classification=%s hop=forward",
                    chat_id, group_chat, relay_mid, str(exc)[:200],
                    cinfo["classification"])
                evidence: Dict[str, Any] = {}
                try:
                    evidence = await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat_id,
                        storage_message_id=storage_message_id,
                        user_chat_id=chat_id,
                        originating_exception=exc,
                        classification=cinfo["classification"],
                        failing_hop="final_user_forward",
                        attempt=attempt) or {}
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                if "chat not found" in low or "bot is not a member" in low \
                        or "bot was kicked" in low \
                        or "not enough rights" in low:
                    # Evidence-based disambiguation (the B18 rule): a
                    # group PROVEN unreachable is group_lost; a group
                    # PROVEN healthy means the failure is on the USER-chat
                    # side (honest bad_request verdict — the group must
                    # not take the blame).
                    group_ok = evidence.get("group_reachable")
                    if group_ok is False:
                        if not nid:
                            nid = await self._resolve_target_nid(network_bot,
                                                                 None)
                        mark_lost = getattr(self.fdb, "mark_group_lost", None)
                        if callable(mark_lost):
                            await mark_lost(
                                nid,
                                f"group access lost: {str(exc)[:120]}")
                        return None, "group_lost"
                    if group_ok is True:
                        logger.warning(
                            "NETWORK_DELIVERY_USER_SIDE_BAD_REQUEST "
                            "chat=%s group=%s relay=%s error=%s "
                            "classification=%s hop=forward (the delivery "
                            "group is verified healthy — the failure is on "
                            "the user-chat side; the group is NOT degraded)",
                            chat_id, group_chat, relay_mid, str(exc)[:160],
                            cinfo["classification"])
                        return None, f"bad_request:{str(exc)[:120]}"
                    if not nid:
                        nid = await self._resolve_target_nid(network_bot, None)
                    mark_lost = getattr(self.fdb, "mark_group_lost", None)
                    if callable(mark_lost):
                        await mark_lost(
                            nid, f"group access lost: {str(exc)[:120]}")
                    return None, "group_lost"
                if "message to forward not found" in low \
                        or "message to copy not found" in low:
                    # B17 honesty rule kept: NOT proof of deletion — the
                    # honest class is RELAY_INACCESSIBLE and the caller
                    # self-heals by recreating the relay VIA THE FDB.
                    logger.warning(
                        "NETWORK_DELIVERY_RELAY_INACCESSIBLE chat=%s group=%s "
                        "relay=%s error=%s classification=%s "
                        "deletion_proven=no hop=forward (the relay message "
                        "is not accessible to the network bot; recreating "
                        "it via the FDB is the valid HYBRID recovery)",
                        chat_id, group_chat, relay_mid, str(exc)[:160],
                        cinfo["classification"])
                    return None, "relay_inaccessible"
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning(
                    "NETWORK_DELIVERY_TRANSIENT attempt=%s chat=%s group=%s "
                    "relay=%s error_class=%s error=%s hop=forward",
                    attempt, chat_id, group_chat, relay_mid,
                    type(exc).__name__, str(exc)[:120])
                # B18 Phase-2B kept: diagnostics execute on TimedOut/
                # NetworkError/unknown exceptions too.
                try:
                    await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat_id,
                        storage_message_id=storage_message_id,
                        user_chat_id=chat_id,
                        originating_exception=exc,
                        classification=classify_telegram_delivery_failure(
                            exc)["classification"],
                        failing_hop="final_user_forward",
                        attempt=attempt)
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                await asyncio.sleep(1.5)
        return None, "transient"

    async def _copy_group_to_user(self, network_bot, chat_id: int,
                                   group_chat: int, relay_mid: int,
                                   protect_content: bool,
                                   network_bot_id: Optional[int] = None,
                                   storage_chat_id: Optional[int] = None,
                                   storage_message_id: Optional[int] = None
                                   ) -> tuple:
        """LEGACY (B17/B18) network bot copyMessage: delivery group → user
        (spec §50). B23-2: the production Mode-A hop 2 no longer calls
        this (the HYBRID hop is the network bot's forwardMessage via
        _forward_group_to_user); retained as a legacy/classification
        surface for callers and regression suites.

        BOT-16: returns ``(message_id | None, verdict)`` where verdict is a
        stable classification carrying the REAL Telegram failure cause:
        ``ok`` / ``relay_inaccessible`` / ``group_lost`` / ``forbidden`` /
        ``bad_request:<detail>`` / ``transient`` / ``no_message_id``.
        B17 FINAL VERIFICATION: "Message to copy not found" returns
        ``relay_inaccessible`` (RELAY_INACCESSIBLE_TO_NETWORK_BOT) — the
        honest class; the B16 name ``relay_gone`` assumed deletion that
        was never proven. The caller logs the verdict with full job
        context, and the REAL diagnostic
        (network_delivery_group_access_check) runs with the network
        bot's OWN client on every BadRequest — a failure is NEVER
        reduced to a bare ``final_delivery_failed`` again.
        """
        from telegram.error import BadRequest, Forbidden, RetryAfter
        kw = {"protect_content": bool(protect_content)}
        # BOT-11 §9: the nid resolved by deliver() (explicit param — the
        # legacy bot_data guess on a Bot CLIENT is always 0 and left a
        # group-loss unattributable).
        nid = int(network_bot_id or 0)
        for attempt in (1, 2):
            try:
                result = await network_bot.copy_message(
                    chat_id, group_chat, relay_mid, **kw)
                mid = int(getattr(result, "message_id", 0) or 0) or None
                if mid is None:
                    return None, "no_message_id"
                return mid, "ok"
            except RetryAfter as exc:
                logger.warning(
                    "NETWORK_DELIVERY_RETRY_AFTER chat=%s group=%s "
                    "relay=%s retry_after=%ss attempt=%s classification=%s",
                    chat_id, group_chat, relay_mid,
                    int(getattr(exc, "retry_after", 3)), attempt,
                    DC_TELEGRAM_API_RESTRICTION)
                await asyncio.sleep(int(getattr(exc, "retry_after", 3)) + 1)
            except Forbidden as exc:
                logger.warning(
                    "NETWORK_DELIVERY_FORBIDDEN chat=%s group=%s relay=%s "
                    "error_class=Forbidden error=%s classification=%s "
                    "(user blocked the bot)",
                    chat_id, group_chat, relay_mid, str(exc)[:160],
                    DC_PERMISSION_FAILURE)
                return None, "forbidden"
            except BadRequest as exc:
                low = str(exc).lower()
                cinfo = classify_telegram_delivery_failure(exc)
                # BOT-16: ALWAYS log the full Telegram BadRequest text with
                # the exact chat/group/relay coordinates; B17 adds the
                # canonical classification.
                logger.warning(
                    "NETWORK_DELIVERY_BAD_REQUEST chat=%s group=%s "
                    "relay=%s error_class=BadRequest error=%s "
                    "classification=%s",
                    chat_id, group_chat, relay_mid, str(exc)[:200],
                    cinfo["classification"])
                # B17 FINAL VERIFICATION: the REAL diagnostic — probes with
                # the NETWORK BOT'S OWN client; every failure carries full
                # evidence (identity, group, membership, source, exception).
                # B18: the hop is explicit (final_user_copy — the copy read
                # FROM the group) and the evidence feeds the group-lost
                # decision below.
                evidence: Dict[str, Any] = {}
                try:
                    evidence = await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat_id,
                        storage_message_id=storage_message_id,
                        user_chat_id=chat_id,
                        originating_exception=exc,
                        classification=cinfo["classification"],
                        failing_hop="final_user_copy",
                        attempt=attempt) or {}
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                if "chat not found" in low or "bot is not a member" in low \
                        or "bot was kicked" in low or "not enough rights" in low:
                    # The network bot may have lost the DELIVERY GROUP (the
                    # copy source) — B18 uses the probe evidence before
                    # ever degrading the group: a group PROVEN unreachable
                    # is group_lost; a group PROVEN healthy means the
                    # failure is on the USER-chat side (honest bad_request
                    # verdict — the group must not take the blame).
                    group_ok = evidence.get("group_reachable")
                    if group_ok is False:
                        if not nid:
                            # BOT-11 §9: resolve honestly instead of the broken
                            # bot_data-on-Bot guess (kept only as last resort).
                            nid = await self._resolve_target_nid(network_bot, None)
                        await self.fdb.mark_group_lost(
                            nid,
                            f"group access lost: {str(exc)[:120]}")
                        return None, "group_lost"
                    if group_ok is True:
                        logger.warning(
                            "NETWORK_DELIVERY_USER_SIDE_BAD_REQUEST "
                            "chat=%s group=%s relay=%s error=%s "
                            "classification=%s (the delivery group is "
                            "verified healthy — the failure is on the "
                            "user-chat side; the group is NOT degraded)",
                            chat_id, group_chat, relay_mid, str(exc)[:160],
                            cinfo["classification"])
                        return None, f"bad_request:{str(exc)[:120]}"
                    if not nid:
                        nid = await self._resolve_target_nid(network_bot, None)
                    await self.fdb.mark_group_lost(
                        nid,
                        f"group access lost: {str(exc)[:120]}")
                    return None, "group_lost"
                if "message to copy not found" in low \
                        or "message to forward not found" in low:
                    # B17 FINAL VERIFICATION honesty rule: "Message to copy
                    # not found" is NOT proof of deletion. Without proof the
                    # canonical classification is
                    # RELAY_INACCESSIBLE_TO_NETWORK_BOT (the bot-18.log root
                    # cause class — Telegram never lets one bot copy a
                    # message authored by a different bot) and the verdict is
                    # "relay_inaccessible". The caller self-heals by
                    # recreating the relay from the Storage master — the
                    # valid recovery for BOTH a TTL-deleted and an
                    # inaccessible relay.
                    logger.warning(
                        "NETWORK_DELIVERY_RELAY_INACCESSIBLE chat=%s group=%s "
                        "relay=%s error=%s classification=%s "
                        "deletion_proven=no (the relay message is not "
                        "accessible to the network bot; recreating from the "
                        "Storage master is the valid recovery)",
                        chat_id, group_chat, relay_mid, str(exc)[:160],
                        cinfo["classification"])
                    return None, "relay_inaccessible"
                return None, f"bad_request:{str(exc)[:120]}"
            except Exception as exc:  # noqa: BLE001 — transient
                logger.warning(
                    "NETWORK_DELIVERY_TRANSIENT attempt=%s chat=%s group=%s "
                    "relay=%s error_class=%s error=%s",
                    attempt, chat_id, group_chat, relay_mid,
                    type(exc).__name__, str(exc)[:120])
                # B18 Phase-2B: diagnostics execute on TimedOut/
                # NetworkError/unknown exceptions too (the network bot's
                # OWN client provides the evidence that separates "Telegram
                # is slow" from "this hop can never work").
                try:
                    await self.network_delivery_group_access_check(
                        network_bot, network_bot_id=nid or None,
                        group_chat_id=group_chat,
                        storage_chat_id=storage_chat_id,
                        storage_message_id=storage_message_id,
                        user_chat_id=chat_id,
                        originating_exception=exc,
                        classification=classify_telegram_delivery_failure(
                            exc)["classification"],
                        failing_hop="final_user_copy",
                        attempt=attempt)
                except Exception:  # noqa: BLE001 — diagnostics never crash delivery
                    pass
                await asyncio.sleep(1.5)
        return None, "transient"

    async def _fail_or_retry(self, job_id: int, error: str) -> None:
        """Retry with exponential backoff until max_attempts; then FAILED
        (spec §53/§54).

        V25 §8: DETERMINISTIC failures never schedule retries — the exact
        same Telegram rejection would occur on every attempt (bot-31.log
        job 65: five identical "Message has protected content" attempts).
        Classes that fail fast with actionable diagnostics:
          * protected content (MESSAGE_NOT_COPYABLE);
          * a rejected stored file identity (identity_send_unavailable /
            wrong file identifier);
          * source_not_copyable (deleted source message).
        Everything else (transient / flood / unknown) keeps the honest
        bounded-retry schedule.
        """
        job = await self.db.get_delivery_job(job_id)
        if not job:
            return
        attempts = int(job["attempts"] or 0) + 1
        max_attempts = int(job["max_attempts"] or DELIVERY_DEFAULT_MAX_ATTEMPTS)
        base = await self.db.get_setting_int(
            DELIVERY_SETTING_RETRY_BASE, DELIVERY_DEFAULT_RETRY_BASE)
        _err = str(error or "")
        _deterministic = (
            _verdict_is_protected_content(_err)
            or "identity_send_unavailable" in _err
            or "wrong file identifier" in _err.lower()
            or "source_not_copyable" in _err)
        if _deterministic:
            await self.db.update_delivery_job(
                job_id, status=JOB_FAILED, attempts=attempts,
                last_error=_err)
            logger.error(
                "NETWORK_DELIVERY_FAILED job_id=%s attempts=%s "
                "error=%s deterministic=True classification=%s (no retry "
                "scheduled — the identical Telegram rejection would recur; "
                "actionable diagnostics recorded on the job row)",
                job_id, attempts, _err,
                "protected_content" if _verdict_is_protected_content(_err)
                else "invalid_file_identity" if (
                    "identity_send_unavailable" in _err
                    or "wrong file identifier" in _err.lower())
                else "source_deleted")
            return
        if attempts >= max_attempts:
            await self.db.update_delivery_job(
                job_id, status=JOB_FAILED, attempts=attempts,
                last_error=error)
            logger.error("NETWORK_DELIVERY_FAILED job_id=%s attempts=%s "
                         "error=%s", job_id, attempts, error)
            return
        from datetime import datetime, timedelta, timezone
        nxt = (datetime.now(timezone.utc)
               + timedelta(seconds=base * (2 ** max(0, attempts - 1)))
               ).isoformat(timespec="seconds")
        await self.db.update_delivery_job(
            job_id, attempts=attempts, next_retry_at=nxt, last_error=error)
        logger.info("DELIVERY_RETRY_SCHEDULED job_id=%s attempt=%s "
                    "next_retry_at=%s error=%s", job_id, attempts, nxt,
                    error)

    # ------------------------------------------------------------------
    # Background sweeper: retries + TTL cleanup + reconciliation
    # ------------------------------------------------------------------
    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self._sweep_loop())
        # Crash recovery pass (spec §55) at startup.
        asyncio.create_task(self.reconcile_startup())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._task = None

    async def _sweep_loop(self) -> None:
        while True:
            try:
                interval = await self.db.get_setting_int(
                    DELIVERY_SETTING_SWEEP_INTERVAL,
                    DELIVERY_DEFAULT_SWEEP_INTERVAL)
                await asyncio.sleep(max(15, interval))
                await self.sweep_once()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — the loop must survive
                logger.warning("DELIVERY_SWEEP_ERROR %s", str(exc)[:160])
                await asyncio.sleep(15)

    async def sweep_once(self) -> Dict[str, int]:
        """One sweep pass: TTL cleanup + handoff TTL + due retries
        (spec §54/§57 + the B17 handoff lifecycle)."""
        stats = {"ttl_deleted": 0, "retried": 0, "reconciled": 0,
                 "handoff_expired": 0}
        ttl = await self.db.get_setting_int(
            DELIVERY_SETTING_RELAY_TTL, DELIVERY_DEFAULT_RELAY_TTL)
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        cutoff = (now - timedelta(seconds=max(60, ttl))
                  ).isoformat(timespec="seconds")
        # 1) TTL cleanup: relays older than the TTL in non-terminal states.
        rows = await self.db.list_delivery_jobs(relay_open=True, limit=200)
        for job in rows:
            stamp = str(job.get("relay_created_at")
                        or job.get("updated_at") or "")
            if not stamp or stamp > cutoff:
                continue
            gid = job.get("delivery_group_chat_id")
            rmid = job.get("relay_message_id")
            if gid and rmid:
                if await self.fdb.delete_relay_message(int(gid), int(rmid)):
                    stats["ttl_deleted"] += 1
            # B17 FINAL VERIFICATION FIX — the delivery-state honesty
            # mandate: DELIVERED requires a CONFIRMED Telegram final-user
            # send (a real destination message id in the user's chat).
            # This TTL settling pass NEVER fabricates that confirmation:
            #   * a row already DELIVERED WITH a recorded user_message_id
            #     keeps DELIVERED (the confirmation was written when the
            #     real send returned its message id);
            #   * a DELIVERED row WITHOUT user_message_id (a legacy
            #     B16-era row produced by the OLD crash-ambiguous
            #     settling) has NO proof of delivery — settles EXPIRED;
            #   * a crash-ambiguous DELIVERING row (crash mid-copy,
            #     outcome genuinely unknown, NO failure recorded) has NO
            #     confirmed send — settles EXPIRED, NEVER a lying
            #     DELIVERED;
            #   * every other (failed) row settles EXPIRED.
            # (bot-16.log: jobs 28/29 were marked DELIVERED while the user
            # never received anything — the B16 "crash-ambiguous →
            # DELIVERED" rule was exactly that lie, and this fixes it at
            # the root: an UNCONFIRMED outcome can never be DELIVERED.)
            confirmed = (str(job.get("status")) == JOB_DELIVERED
                         and job.get("user_message_id"))
            if confirmed:
                await self.db.update_delivery_job(
                    int(job["id"]), status=JOB_DELIVERED,
                    deleted_at=_now_iso(),
                    last_error=job.get("last_error") or None)
            else:
                await self.db.update_delivery_job(
                    int(job["id"]), status=JOB_EXPIRED,
                    deleted_at=_now_iso(),
                    last_error=str(job.get("last_error")
                                   or "relay TTL expired (delivery outcome "
                                      "unconfirmed — honest EXPIRED, never "
                                      "a lying DELIVERED)"))
        # 2) B17 handoff TTL: a deep-link button the user never tapped
        #    settles EXPIRED — honestly, NEVER a lying DELIVERED (the user
        #    demonstrably did not receive the file).
        handoff_ttl = await self.db.get_setting_int(
            DELIVERY_SETTING_HANDOFF_TTL, DELIVERY_DEFAULT_HANDOFF_TTL)
        hcut = (now - timedelta(seconds=max(60, handoff_ttl))
                ).isoformat(timespec="seconds")
        try:
            hrows = await self.db.list_delivery_jobs(
                status=JOB_HANDOFF_PENDING, limit=500)
        except TypeError:
            # Fakes with the older relay-only signature — fall back to the
            # unfiltered listing and gate per-row (never crashes a sweep).
            hrows = await self.db.list_delivery_jobs(limit=500)
        for job in hrows:
            if str(job.get("status")) != JOB_HANDOFF_PENDING:
                continue  # per-row gate (tolerates loose fake filters)
            stamp = str(job.get("handoff_sent_at")
                        or job.get("updated_at") or "")
            if not stamp or stamp > hcut:
                continue
            await self.db.update_delivery_job(
                int(job["id"]), status=JOB_EXPIRED,
                deleted_at=_now_iso(),
                last_error=str(job.get("last_error")
                               or "handoff TTL expired"))
            stats["handoff_expired"] += 1
            logger.info(
                "DELIVERY_HANDOFF_EXPIRED job_id=%s (the user never tapped "
                "the deep-link button within the TTL — honest EXPIRED, "
                "never DELIVERED)", job.get("id"))
        # 3) Retry due jobs.
        due = await self.db.list_delivery_jobs(due_for_retry=True, limit=50)
        for job in due:
            if str(job.get("status")) == JOB_HANDOFF_PENDING:
                # B17: a handoff only retries when a completion attempt
                # FAILED transiently (next_retry_at set); without it the
                # job is legitimately waiting for the user's tap (the TTL
                # pass above is its only clock).
                if not job.get("next_retry_at"):
                    continue
                await self._retry_handoff(job)
                stats["retried"] += 1
            elif str(job.get("status")) in (JOB_CREATED, JOB_RELAY_CREATING):
                await self._retry_relay_side(job)
                stats["retried"] += 1
            elif str(job.get("status")) in (JOB_RELAYED, JOB_DELIVERING):
                # BOT-12 §9 idempotency: a DELIVERING row with NO
                # next_retry_at never went through _fail_or_retry — its
                # user-copy outcome is UNKNOWN (crash mid-flight). Never
                # re-copy it blindly (duplicate user delivery); the TTL
                # pass above settles it EXPIRED — honestly, NEVER a
                # lying DELIVERED — and cleans the relay.
                if (str(job.get("status")) == JOB_DELIVERING
                        and not job.get("next_retry_at")):
                    logger.warning(
                        "DELIVERY_RETRY_SKIPPED job_id=%s "
                        "reason=delivering_outcome_unknown (crash mid-copy — "
                        "re-copy could duplicate; TTL pass will settle)",
                        job.get("id"))
                    continue
                await self._retry_delivery_side(job)
                stats["retried"] += 1
            elif str(job.get("status")) == JOB_DELETE_PENDING:
                gid = job.get("delivery_group_chat_id")
                rmid = job.get("relay_message_id")
                if gid and rmid and await self.fdb.delete_relay_message(
                        int(gid), int(rmid)):
                    await self.db.update_delivery_job(
                        int(job["id"]), status=JOB_DELETED,
                        deleted_at=_now_iso())
                    stats["reconciled"] += 1
        # 4) V26.x Phase 3 — Delivery Channel SOURCE cleanup
        #    reconciliation: rows whose channel_cleanup_pending flag is
        #    still SET (a crash between the CONFIRMED user delivery and
        #    the channel deletion, a failed/permission-rejected delete, or
        #    an FDB restart). INDEPENDENT of the USER delivery TTL cleanup
        #    above (that pass removes USER-facing messages; THIS pass
        #    removes the Delivery Channel SOURCES — different chats,
        #    different criteria, never conflated).
        try:
            crows = await self.db.list_delivery_jobs(
                channel_cleanup_pending=True, limit=50)
        except TypeError:
            # Fakes with the older signature — fall back to the status
            # filter + per-row gate (never crashes a sweep).
            crows = []
            try:
                crows = await self.db.list_delivery_jobs(limit=200)
            except Exception:  # noqa: BLE001
                crows = []
            crows = [j for j in crows
                     if str(j.get("status")) == JOB_DELIVERED
                     and int(j.get("channel_cleanup_pending") or 0)
                     and j.get("delivery_message_id")]
        if crows:
            logger.info(
                "DELIVERY_CHANNEL_CLEANUP_RECONCILE pending=%s (V26.x "
                "Phase 3: Delivery Channel sources owed deletion — crash/"
                "failure recovery; the USER delivery TTL pass is separate)",
                len(crows))
        for job in crows:
            # Authoritative gate: only CONFIRMED deliveries (a real
            # user_message_id) may release their channel source; any other
            # pending row (e.g. a retryable job whose source must survive
            # for a later Stage-B attempt) is LEFT ALONE this pass.
            if str(job.get("status")) != JOB_DELIVERED \
                    or not job.get("user_message_id"):
                continue
            cid = int(job.get("delivery_channel_id") or 0)
            dmid = int(job.get("delivery_message_id") or 0)
            nid = int(job.get("network_bot_id") or 0)
            if not (cid and dmid):
                # No durable identity — clear the flag so the row never
                # spins (nothing deletable is recorded).
                try:
                    await self.db.update_delivery_job(
                        int(job["id"]), channel_cleanup_pending=0)
                except Exception:  # noqa: BLE001
                    pass
                continue
            done = await self._cleanup_channel_source(
                int(job["id"]), cid, dmid, nid=nid,
                via="sweep_reconcile")
            if done:
                stats["channel_sources_deleted"] = \
                    stats.get("channel_sources_deleted", 0) + 1
        if stats["ttl_deleted"] or stats["retried"] or stats["reconciled"] \
                or stats["handoff_expired"]:
            logger.info("DELIVERY_SWEEP ttl_deleted=%s retried=%s "
                        "reconciled=%s handoff_expired=%s",
                        stats["ttl_deleted"], stats["retried"],
                        stats["reconciled"], stats["handoff_expired"])
        return stats

    async def _retry_handoff(self, job: Dict[str, Any]) -> None:
        """V25 FINAL — reroute a legacy HANDOFF_PENDING retry through the
        two-stage plane.

        Legacy rows (created by pre-V25-FINAL builds) waited for the
        user to tap the FDB deep-link button; a transiently-failed
        completion used to re-attempt the FDB DIRECT send. Under the
        final architecture the FDB never sends to users — the retry
        delivers through the NETWORK bot (the user is already talking
        to it), which is strictly better for the user. Jobs still
        waiting for a tap (no next_retry_at) are untouched here — the
        handoff TTL pass settles them EXPIRED honestly."""
        jid = int(job["id"])
        sc, sm = job.get("storage_chat_id"), job.get("storage_message_id")
        user_id = int(job.get("user_id") or 0)
        nid = int(job.get("network_bot_id") or 0)
        if not (sc and sm and user_id and nid):
            await self.db.update_delivery_job(
                jid, status=JOB_FAILED, last_error="missing source refs")
            return
        bot = await self._resolve_worker_client(nid)
        if bot is None:
            await self._fail_or_retry(jid, "bot worker not running")
            return
        logger.info(
            "DELIVERY_RETRY_REROUTE job_id=%s mode=handoff->delivery_channel "
            "reason=final_architecture (V25 FINAL: a legacy handoff retry "
            "delivers through the two-stage plane — the FDB never sends "
            "to users)", jid)
        await self.db.update_delivery_job(
            jid, delivery_mode=DM_DELIVERY_CHANNEL,
            handoff_token=None)
        job = dict(job)
        job["delivery_mode"] = DM_DELIVERY_CHANNEL
        await self._retry_two_stage(job, bot)

    async def _retry_relay_side(self, job: Dict[str, Any]) -> None:
        """Retry a job that never got past the Stage-A/relay-create phase
        (crash mid-``deliver``) — V25 FINAL: re-enter the FULL two-stage
        strategy with a live network bot client. The delivery group is
        never resolved — ``group_chat`` is always None and no legacy
        relay is ever created."""
        nid = int(job.get("network_bot_id") or 0)
        chat_id = int(job.get("user_id") or 0)
        sc, sm = job.get("storage_chat_id"), job.get("storage_message_id")
        if not (nid and chat_id and sc and sm):
            await self.db.update_delivery_job(
                int(job["id"]), status=JOB_FAILED,
                last_error="missing source refs")
            return
        bot = await self._resolve_worker_client(nid)
        if bot is None:
            await self._fail_or_retry(int(job["id"]),
                                      "bot worker not running")
            return
        await self._deliver_layered(
            network_bot=bot, chat_id=chat_id, job_id=int(job["id"]), nid=nid,
            group_chat=None, storage_chat=int(sc),
            storage_msg=int(sm),
            protect_content=bool(int(job.get("protect_content") or 0))
            if "protect_content" in job else False)

    async def _resolve_worker_client(self, nid: int):
        """BOT-16 FIX — resolve the live network bot client through the
        injected ``bot_client_resolver``, supporting BOTH sync and async
        resolvers. The historical ``await resolver(nid)`` crashed on the
        SYNC ``BotWorkerManager.get_bot_client`` with ``TypeError: object
        ExtBot can't be used in 'await' expression`` — the recurring
        bot-16.log DELIVERY_SWEEP_ERROR that silently killed EVERY retry
        pass (jobs 28/29 never retried; the TTL pass then marked them
        DELIVERED although the user never received the file).
        """
        resolver = getattr(self, "bot_client_resolver", None)
        if not callable(resolver):
            return None
        try:
            res = resolver(nid)
            if asyncio.iscoroutine(res):
                res = await res
            return res
        except Exception as exc:  # noqa: BLE001 — lookup must never crash
            logger.warning("DELIVERY_RETRY_RESOLVER_FAILED network_bot_id=%s "
                           "error_class=%s error=%s", nid,
                           type(exc).__name__, str(exc)[:120])
            return None

    async def _retry_delivery_side(self, job: Dict[str, Any]) -> None:
        """V25 FINAL two-stage retry of the user-facing send: EVERY job —
        including legacy ``network_relay`` rows carrying a stale relay
        message AND legacy ``fdb_direct`` rows — routes through the
        Delivery Channel plane (Stage A skip-or-rerun + Stage B Network
        Bot user copy). The obsolete group→user forward and the FDB
        direct-to-user send are NEVER re-attempted; a legacy relay
        message still referenced by the job row is cleaned up
        best-effort (compat housekeeping — the sweeper TTL pass covers
        the rest)."""
        nid = int(job.get("network_bot_id") or 0)
        chat_id = int(job.get("user_id") or 0)
        if not (nid and chat_id):
            await self._fail_or_retry(int(job["id"]),
                                      "no bot client for retry")
            return
        bot = await self._resolve_worker_client(nid)
        if bot is None:
            await self._fail_or_retry(int(job["id"]),
                                      "bot worker not running")
            return
        mode = str(job.get("delivery_mode") or "")
        gid = job.get("delivery_group_chat_id")
        rmid = job.get("relay_message_id")
        if mode in (DM_NETWORK_RELAY, DM_FDB_DIRECT) or (gid and rmid):
            # V25 FINAL: legacy group-relay AND fdb-direct rows are
            # re-routed to the two-stage Delivery Channel plane — never
            # through the group and never FDB-direct-to-user again. The
            # stale legacy relay message is removed best-effort.
            logger.info(
                "DELIVERY_RETRY_REROUTE job_id=%s mode=%s->delivery_channel "
                "reason=final_architecture (V25 FINAL: the legacy routing "
                "modes are deprecated — the retry runs the two-stage "
                "Delivery Channel plane: FDB → Delivery Channel → Network "
                "Bot → user; the stale legacy relay message is cleaned up)",
                int(job["id"]), mode or "legacy")
            if gid and rmid and mode != DM_DELIVERY_CHANNEL:
                try:
                    await self.fdb.delete_relay_message(int(gid), int(rmid))
                except Exception:  # noqa: BLE001 — legacy cleanup is best-effort
                    pass
            await self.db.update_delivery_job(
                int(job["id"]), delivery_mode=DM_DELIVERY_CHANNEL,
                relay_message_id=None)
            job = dict(job)
            job["delivery_mode"] = DM_DELIVERY_CHANNEL
        await self._retry_two_stage(job, bot)

    async def _retry_two_stage(self, job: Dict[str, Any], bot) -> None:
        """V25 FINAL — retry a job through the two-stage plane with a live
        network bot client. A durable ``delivery_message_id`` skips
        Stage A (reconciliation fast path); otherwise Stage A re-runs.
        No FDB direct-to-user send can ever happen here."""
        jid = int(job["id"])
        chat_id = int(job.get("user_id") or 0)
        nid = int(job.get("network_bot_id") or 0)
        sc, sm = job.get("storage_chat_id"), job.get("storage_message_id")
        if not (chat_id and sc and sm):
            await self._fail_or_retry(jid, "missing source refs")
            return
        protect = bool(int(job.get("protect_content") or 0)) \
            if "protect_content" in job else True
        # V25 §7: load the file row so Stage A can use the identity-send
        # fallback when the storage source is protected.
        file_row = None
        fpk = job.get("file_pk")
        if fpk:
            try:
                row = await self.db.get_indexed_file_by_id(int(fpk))
                if row is not None:
                    file_row = dict(row)
            except Exception:  # noqa: BLE001 — best-effort enrichment
                file_row = None
        channel_id = 0
        try:
            channel_id = int(job.get("delivery_channel_id") or 0)
        except (TypeError, ValueError):
            channel_id = 0
        dmid = 0
        try:
            dmid = int(job.get("delivery_message_id") or 0)
        except (TypeError, ValueError):
            dmid = 0
        await self._deliver_layered(
            network_bot=bot, chat_id=chat_id, job_id=jid, nid=nid,
            group_chat=None, storage_chat=int(sc), storage_msg=int(sm),
            protect_content=protect, file_row=file_row,
            delivery_channel_id=channel_id or None,
            delivery_message_id=dmid or None)

    async def reconcile_startup(self) -> None:
        """Crash recovery (spec §55) — the five interruption cases:

        1. relay created, DB update failed  → reconcile Telegram state
           first: if a relay message id is recorded, trust it (RELAYED);
        2. relay exists, delivery incomplete → retry (due_for_retry);
        3. delivered, cleanup interrupted    → DELETE_PENDING sweep;
        4. relay deleted, DB update failed   → record DELETED;
        5. relay missing                     → recreate from the Storage
           master when a retry is due.
        """
        rows = await self.db.list_delivery_jobs(relay_open=True, limit=500)
        fixed = 0
        for job in rows:
            st = str(job.get("status"))
            rmid = job.get("relay_message_id")
            if st == JOB_RELAY_CREATING and rmid:
                # Case 1: the Telegram copy succeeded but the row never
                # advanced — trust the recorded relay id.
                await self.db.update_delivery_job(
                    int(job["id"]), status=JOB_RELAYED,
                    relay_created_at=_now_iso())
                fixed += 1
            elif st in (JOB_RELAYED, JOB_DELIVERING, JOB_DELETE_PENDING):
                logger.info("DELIVERY_RECONCILIATION job_id=%s status=%s "
                            "(sweeper will retry/clean)", job["id"], st)
        if fixed:
            logger.info("DELIVERY_RECONCILIATION recovered=%s jobs", fixed)
        # V26.x Phase 3 — case 3 extension (the DELIVERED row whose
        # Delivery Channel SOURCE deletion was interrupted by the crash):
        # one immediate reconciliation pass now (the sweep loop also
        # covers it every interval). Only CONFIRMED deliveries release
        # their channel source; the USER delivery TTL cleanup stays
        # independent.
        try:
            crows = await self.db.list_delivery_jobs(
                channel_cleanup_pending=True, limit=50)
        except TypeError:
            crows = []
        crows = [j for j in crows
                 if str(j.get("status")) == JOB_DELIVERED
                 and j.get("user_message_id")]
        if crows:
            logger.info(
                "DELIVERY_CHANNEL_CLEANUP_RECONCILE pending=%s "
                "via=startup (V26.x Phase 3 crash recovery: confirmed "
                "deliveries whose channel-source deletion was interrupted)",
                len(crows))
            for job in crows:
                cid = int(job.get("delivery_channel_id") or 0)
                dmid = int(job.get("delivery_message_id") or 0)
                nid = int(job.get("network_bot_id") or 0)
                if cid and dmid:
                    await self._cleanup_channel_source(
                        int(job["id"]), cid, dmid, nid=nid,
                        via="startup_reconcile")
