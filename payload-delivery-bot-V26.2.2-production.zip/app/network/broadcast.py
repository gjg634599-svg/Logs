"""NETWORK (N4): durable Network Broadcast engine.

STANDALONE MODULE — pure orchestration over injected adapters (same
discipline as app/core/*). bot.py wires this engine with its DB adapter,
per-bot Telegram clients, and the send implementations.

Spec sections implemented here:

§25/§26 — ONE broadcast, distributed through eligible network bots to
    REACHABLE users (user_bot_memberships). The owner never recreates the
    broadcast per bot. Targeting modes: all network bots / selected bots /
    users of a selected bot / all reachable users.

§27 BROADCAST METHODS — COPY, COPY_MULTI (album), FORWARD,
    FORWARD_MULTI, TEXT, PHOTO, VIDEO, DOCUMENT, AUDIO, ALBUM,
    PAYLOAD_ANNOUNCEMENT, TEMPLATE. Telegram-native operations are
    preferred (copy/forward by source message id) — no giant downloads.

§28/§29/§30 COPY vs FORWARD — semantics are EXPLICIT per job
    (method column); a protected-content failure reports the exact safe
    reason and offers the fallback; the engine NEVER silently changes a
    Copy into a Forward. Cross-bot file_id reuse NEVER happens — media
    broadcasts are sent via per-bot native copy/forward of the CENTRAL
    source message, or re-sent from per-bot resolved references by the
    injected sender (which follows the file identity rules).

§38/§39 BROADCAST JOB ARCHITECTURE + DURABILITY — broadcasts →
    broadcast_bot_jobs (per-bot durable cursor) → broadcast_deliveries
    (per-user durable state). Survives process/bot/server restart,
    FloodWait, and Telegram errors: restart resumes at the per-bot cursor
    with per-user attempt state — never from zero.

§40 PAUSE / RESUME / CANCEL — durable state transitions; cancelled jobs
    are never marked completed; paused progress is never lost; workers
    observe cancellation safely between batches.

§41 RATE LIMITING — per-bot send rate (configurable), FloodWait /
    RetryAfter honored, bounded retries per user, per-bot failure
    isolation (one unhealthy bot never blocks the network — its job just
    fails/degrades on its own).

§42 FAILURE CLASSIFICATION — SUCCESS / TEMPORARY_ERROR / FLOOD_WAIT /
    USER_BLOCKED_BOT / USER_UNAVAILABLE / BOT_INVALID / SOURCE_UNAVAILABLE
    / PERMANENT_ERROR / CANCELLED. Only appropriate failures retry;
    blocked users / invalid tokens / permanent source failures are
    terminal.

§46 STATISTICS — totals/queued/sent/failed/blocked/skipped/retrying/
    remaining + per-bot breakdown computed from the durable tables (never
    shows 100% until durable completion).
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable, Dict, List, Optional

logger = logging.getLogger("app.network.broadcast")

# Broadcast statuses (durable)
B_PENDING = "PENDING"
B_RUNNING = "RUNNING"
B_PAUSED = "PAUSED"
B_COMPLETED = "COMPLETED"
B_CANCELLED = "CANCELLED"
B_FAILED = "FAILED"

# Per-bot job statuses
BJ_PENDING = "PENDING"
BJ_RUNNING = "RUNNING"
BJ_PAUSED = "PAUSED"
BJ_COMPLETED = "COMPLETED"
BJ_CANCELLED = "CANCELLED"
BJ_FAILED = "FAILED"

# Delivery statuses (durable per user)
D_PENDING = "PENDING"
D_SENT = "SENT"
D_FAILED = "FAILED"
D_BLOCKED = "BLOCKED"
D_UNAVAILABLE = "UNAVAILABLE"
D_CANCELLED = "CANCELLED"
D_RETRYING = "RETRYING"

# Failure classification (spec §42)
C_SUCCESS = "SUCCESS"
C_TEMPORARY = "TEMPORARY_ERROR"
C_FLOOD_WAIT = "FLOOD_WAIT"
C_BLOCKED = "USER_BLOCKED_BOT"
C_UNAVAILABLE = "USER_UNAVAILABLE"
C_BOT_INVALID = "BOT_INVALID"
C_SOURCE_UNAVAILABLE = "SOURCE_UNAVAILABLE"
C_PERMANENT = "PERMANENT_ERROR"

# Broadcast methods (spec §27)
M_TEXT = "TEXT"
M_COPY = "COPY"
M_COPY_MULTI = "COPY_MULTI"
M_FORWARD = "FORWARD"
M_FORWARD_MULTI = "FORWARD_MULTI"
M_PHOTO = "PHOTO"
M_VIDEO = "VIDEO"
M_DOCUMENT = "DOCUMENT"
M_AUDIO = "AUDIO"
M_ALBUM = "ALBUM"
M_PAYLOAD_ANNOUNCEMENT = "PAYLOAD_ANNOUNCEMENT"
M_TEMPLATE = "TEMPLATE"

# Targeting modes (spec §26)
T_ALL_BOTS = "ALL_BOTS"
T_SELECTED_BOTS = "SELECTED_BOTS"
T_USERS_OF_BOT = "USERS_OF_BOT"
T_ALL_REACHABLE = "ALL_REACHABLE"

# Retry policy
MAX_USER_ATTEMPTS = 3
BATCH_PAGE = 200
PROGRESS_PERSIST_EVERY = 25

# Classification of Telegram exceptions → (class, retryable)
def classify_send_error(exc: Exception) -> tuple:
    """Map a Telegram send exception to a spec §42 class.

    Returns (classification, retryable). Implemented defensively via
    duck-typing so tests and the live PTB exceptions both classify.
    """
    name = type(exc).__name__
    msg = str(exc) or ""
    if name == "Forbidden":
        return (C_BLOCKED, False)
    if name == "RetryAfter":
        return (C_FLOOD_WAIT, True)
    if name in ("TimedOut", "NetworkError", "ConnectionError",
                "ClientConnectorError", "ServerDisconnectedError"):
        return (C_TEMPORARY, True)
    if name == "BadRequest":
        low = msg.lower()
        if "chat not found" in low:
            return (C_UNAVAILABLE, False)
        if "bot was blocked" in low or "bot was kicked" in low:
            return (C_BLOCKED, False)
        if "message to copy not found" in low or "message to forward not found" in low:
            return (C_SOURCE_UNAVAILABLE, False)
        if "wrong file identifier" in low or "file is too big" in low:
            return (C_SOURCE_UNAVAILABLE, False)
        return (C_PERMANENT, False)
    if name == "InvalidToken" or "invalid token" in msg.lower():
        return (C_BOT_INVALID, False)
    if name in ("TelegramError", "APIError"):
        return (C_TEMPORARY, True)
    return (C_TEMPORARY, True)


class NetworkBroadcastEngine:
    """Durable broadcast orchestration.

    Adapters (wired in bot.py):
        db — broadcast tables + settings methods
        get_bot_client — async (network_bot_id) -> bot-like client | None
        send_one — async (bot, method, broadcast_row, target_user_id) ->
            {"ok": bool, "message_id": int|None, "error": Exception|None,
             "classification": str|None}
        notify_admin — async (text) -> None (progress/completion notices)
    """

    def __init__(self, db_adapter, get_bot_client, send_one,
                 notify_admin: Optional[Callable[[str], Awaitable[None]]] = None
                 ) -> None:
        self.db = db_adapter
        self._get_bot_client = get_bot_client
        self._send_one = send_one
        self._notify_admin = notify_admin
        self._tasks: Dict[int, asyncio.Task] = {}  # broadcast_id → worker task

    # ------------------------------------------------------------------
    # Job creation / targeting (spec §25/§26)
    # ------------------------------------------------------------------
    async def create_broadcast(self, *, method: str, created_by: int,
                               text: Optional[str] = None,
                               source_chat_id: Optional[int] = None,
                               source_message_ids: Optional[List[int]] = None,
                               payload_id: Optional[int] = None,
                               target_mode: str = T_ALL_BOTS,
                               target_bot_ids: Optional[List[int]] = None,
                               protect_content: bool = False,
                               ) -> Dict[str, Any]:
        """Create a PENDING broadcast + expand targets + per-bot jobs.

        Target expansion respects reachability: only users with an ACTIVE
        membership in the selected bots become delivery rows (spec §16/§26
        — never send through a bot to users who never started it).
        """
        broadcast_id = await self.db.create_broadcast(
            method=method, created_by=int(created_by), text=text,
            source_chat_id=source_chat_id,
            source_message_ids=source_message_ids or None,
            payload_id=payload_id, target_mode=target_mode,
            target_bot_ids=target_bot_ids or None,
            protect_content=bool(protect_content))
        expanded = await self.db.expand_broadcast_targets(
            int(broadcast_id), target_mode,
            [int(x) for x in (target_bot_ids or [])])
        logger.info("BROADCAST_CREATED broadcast_id=%s method=%s "
                    "target_mode=%s bots=%s users=%s",
                    broadcast_id, method, target_mode,
                    expanded.get("bot_count"), expanded.get("user_count"))
        return {"broadcast_id": int(broadcast_id),
                "bot_count": int(expanded.get("bot_count") or 0),
                "user_count": int(expanded.get("user_count") or 0)}

    # ------------------------------------------------------------------
    # Lifecycle (spec §40)
    # ------------------------------------------------------------------
    async def start(self, broadcast_id: int) -> Dict[str, Any]:
        """Start (or resume) a broadcast: mark RUNNING, spawn the worker."""
        bid = int(broadcast_id)
        row = await self.db.get_broadcast(bid)
        if row is None:
            return {"ok": False, "reason": "not_found"}
        if str(row["status"]) in (B_COMPLETED, B_CANCELLED):
            return {"ok": False, "reason": f"already_{str(row['status']).lower()}"}
        await self.db.set_network_broadcast_status(bid, B_RUNNING)
        await self.db.mark_pending_bot_jobs_running(bid)
        if bid in self._tasks and not self._tasks[bid].done():
            return {"ok": True, "already_running": True}
        task = asyncio.create_task(self._worker(bid))
        # PHASE 5: naturally-finished workers leave the registry — the
        # per-bid dict can no longer grow without bound over the process
        # lifetime (cancelled/stopped entries were already handled).
        task.add_done_callback(self._make_task_popper(bid))
        self._tasks[bid] = task
        logger.info("BROADCAST_STARTED broadcast_id=%s", bid)
        return {"ok": True}

    def _make_task_popper(self, bid: int):
        """PHASE 5: done-callback that removes COMPLETED tasks from the
        registry (identity-guarded — a restarted broadcast's newer task is
        never evicted by an older task's callback)."""
        def _pop(task) -> None:
            try:
                if self._tasks.get(bid) is task:
                    del self._tasks[bid]
            except Exception:  # noqa: BLE001 — never raise in a callback
                pass
        return _pop

    async def pause(self, broadcast_id: int) -> Dict[str, Any]:
        await self.db.set_network_broadcast_status(int(broadcast_id), B_PAUSED)
        logger.info("BROADCAST_PAUSED broadcast_id=%s (durable; workers "
                    "observe between batches)", broadcast_id)
        return {"ok": True}

    async def resume(self, broadcast_id: int) -> Dict[str, Any]:
        return await self.start(broadcast_id)

    async def cancel(self, broadcast_id: int) -> Dict[str, Any]:
        """Durable cancel: pending deliveries become CANCELLED (never
        'completed'); running workers observe + exit."""
        bid = int(broadcast_id)
        await self.db.set_network_broadcast_status(bid, B_CANCELLED)
        await self.db.cancel_pending_deliveries(bid)
        task = self._tasks.pop(bid, None)
        if task is not None and not task.done():
            try:
                await asyncio.wait_for(task, timeout=10)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                task.cancel()
        logger.info("BROADCAST_CANCELLED broadcast_id=%s", bid)
        return {"ok": True}

    async def resume_pending(self) -> int:
        """Restart recovery (spec §39): find RUNNING broadcasts and resume
        their per-bot workers at the durable cursors — never from zero."""
        ids = await self.db.list_broadcast_ids_by_status(B_RUNNING)
        for bid in ids:
            await self.start(int(bid))
            logger.info("BROADCAST_RESUMED broadcast_id=%s (after restart)",
                        bid)
        return len(ids)

    async def stop_all(self) -> None:
        """Graceful shutdown (post_shutdown hook)."""
        for bid, task in list(self._tasks.items()):
            if not task.done():
                task.cancel()
        self._tasks.clear()

    # ------------------------------------------------------------------
    # The per-bot worker loop (spec §38/§41/§42)
    # ------------------------------------------------------------------
    async def _worker(self, broadcast_id: int) -> None:
        bid = int(broadcast_id)
        try:
            while True:
                brow = await self.db.get_broadcast(bid)
                if brow is None:
                    return
                status = str(brow["status"])
                if status == B_CANCELLED:
                    return
                if status == B_PAUSED:
                    await asyncio.sleep(2.0)
                    continue
                worked = await self._pump_once(bid, brow)
                if not worked:
                    await self._finalize(bid)
                    return
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 — isolate per broadcast
            logger.error("BROADCAST_FAILED broadcast_id=%s error=%s",
                         bid, exc)
            await self.db.set_network_broadcast_status(bid, B_FAILED,
                                               error=str(exc)[:500])
            raise

    async def _pump_once(self, broadcast_id: int, brow) -> bool:
        """Process one batch across the broadcast's per-bot jobs.

        Returns True when there is more work, False when every bot job is
        drained (terminal or complete). One bot's failure NEVER stops the
        others (spec §59 failure isolation)."""
        jobs = await self.db.list_broadcast_bot_jobs(broadcast_id)
        any_work = False
        for job in jobs:
            jstatus = str(job["status"])
            if jstatus in (BJ_COMPLETED, BJ_CANCELLED, BJ_FAILED):
                continue
            bot_id = int(job["network_bot_id"])
            bot = await self._get_bot_client(bot_id)
            if bot is None:
                # Bot worker unavailable → mark the JOB degraded but keep
                # the network running; its deliveries stay PENDING for a
                # later resume (spec §59 — isolated failure).
                await self.db.set_bot_job_status(
                    broadcast_id, bot_id, BJ_PAUSED,
                    error="bot_client_unavailable")
                logger.warning("BROADCAST_BOT_SKIPPED broadcast_id=%s "
                               "network_bot_id=%s reason=client_unavailable",
                               broadcast_id, bot_id)
                continue
            more = await self._run_bot_batch(broadcast_id, bot_id, bot, brow)
            any_work = any_work or more
        return any_work

    async def _run_bot_batch(self, broadcast_id: int, network_bot_id: int,
                             bot, brow) -> bool:
        """Send up to BATCH_PAGE deliveries for one bot. Returns True when
        this bot still has pending work."""
        rows = await self.db.fetch_pending_deliveries(
            broadcast_id, network_bot_id, limit=BATCH_PAGE)
        if not rows:
            await self.db.set_bot_job_status(
                broadcast_id, network_bot_id, BJ_COMPLETED)
            return False
        rate = max(1, int(await self.db.get_setting_int(
            "network_broadcast_rate_per_bot", 25)))
        sent = failed = 0
        for drow in rows:
            # Durable cancellation observation between sends (spec §40).
            bstat = await self.db.get_broadcast_status(broadcast_id)
            if bstat == B_CANCELLED:
                await self.db.set_bot_job_status(
                    broadcast_id, network_bot_id, BJ_CANCELLED)
                return False
            if bstat == B_PAUSED:
                await self.db.set_bot_job_status(
                    broadcast_id, network_bot_id, BJ_PAUSED)
                return True
            target_id = int(drow["user_id"])
            attempts = int(drow["attempts"] or 0)
            t0 = time.monotonic()
            result = await self._send_one(bot, str(brow["method"]), brow,
                                          target_id)
            # Per-bot rate limiting (spec §41): pace the sends.
            elapsed = time.monotonic() - t0
            min_gap = 1.0 / rate
            if elapsed < min_gap:
                await asyncio.sleep(min_gap - elapsed)
            if result.get("ok"):
                sent += 1
                await self.db.update_broadcast_delivery(
                    int(drow["id"]), D_SENT,
                    message_id=result.get("message_id"))
                continue
            cls = result.get("classification") or C_TEMPORARY
            exc = result.get("error")
            retryable = cls in (C_TEMPORARY, C_FLOOD_WAIT)
            if isinstance(exc, Exception) and type(exc).__name__ == "RetryAfter":
                await asyncio.sleep(getattr(exc, "retry_after", 5) + 1.0)
            if retryable and attempts + 1 < MAX_USER_ATTEMPTS:
                await self.db.update_broadcast_delivery(
                    int(drow["id"]), D_RETRYING,
                    attempts=attempts + 1, error_code=cls,
                    error=_safe_err(exc))
                continue
            status = D_FAILED
            if cls == C_BLOCKED:
                status = D_BLOCKED
            elif cls == C_UNAVAILABLE:
                status = D_UNAVAILABLE
            failed += 1
            await self.db.update_broadcast_delivery(
                int(drow["id"]), status, attempts=attempts + 1,
                error_code=cls, error=_safe_err(exc))
            if cls == C_BOT_INVALID:
                # Terminal for the WHOLE bot job (spec §42 — never endlessly
                # retry an invalid token).
                await self.db.set_bot_job_status(
                    broadcast_id, network_bot_id, BJ_FAILED,
                    error="token_invalid")
                return False
            if cls == C_SOURCE_UNAVAILABLE:
                # Terminal for the whole broadcast: the central source is
                # gone — report honestly, stop.
                await self.db.set_network_broadcast_status(
                    broadcast_id, B_FAILED,
                    error="source_unavailable")
                await self.db.set_bot_job_status(
                    broadcast_id, network_bot_id, BJ_FAILED,
                    error="source_unavailable")
                return False
        await self.db.bump_bot_job_progress(
            broadcast_id, network_bot_id, sent=sent, failed=failed)
        logger.info("BROADCAST_PROGRESS broadcast_id=%s network_bot_id=%s "
                    "batch_sent=%s batch_failed=%s",
                    broadcast_id, network_bot_id, sent, failed)
        return True

    async def _finalize(self, broadcast_id: int) -> None:
        """Mark the broadcast durably complete only when every per-bot job
        is terminal (spec §46 — never show 100% before durable completion)
        AND the broadcast was not cancelled/failed/paused meanwhile
        (spec §40 — a cancelled job is NEVER marked completed)."""
        jobs = await self.db.list_broadcast_bot_jobs(broadcast_id)
        if all(str(j["status"]) in (BJ_COMPLETED, BJ_CANCELLED, BJ_FAILED)
               for j in jobs):
            current = await self.db.get_broadcast_status(broadcast_id)
            if current not in (None, B_RUNNING):
                # Cancelled / failed / paused during the final drain — the
                # terminal state set by that control action WINS.
                logger.info("BROADCAST_FINALIZE_SKIPPED broadcast_id=%s "
                            "current_status=%s (not RUNNING — control "
                            "action wins)", broadcast_id, current)
                return
            stats = await self.stats(broadcast_id)
            await self.db.set_network_broadcast_status(
                broadcast_id, B_COMPLETED)
            logger.info("BROADCAST_COMPLETED broadcast_id=%s sent=%s "
                        "failed=%s blocked=%s",
                        broadcast_id, stats.get("sent"),
                        stats.get("failed"), stats.get("blocked"))
            if self._notify_admin is not None:
                try:
                    await self._notify_admin(
                        f"📢 Network broadcast #{broadcast_id} completed — "
                        f"sent={stats.get('sent')} failed={stats.get('failed')} "
                        f"blocked={stats.get('blocked')}")
                except Exception:  # noqa: BLE001
                    pass

    # ------------------------------------------------------------------
    # Statistics (spec §46)
    # ------------------------------------------------------------------
    async def stats(self, broadcast_id: int) -> Dict[str, Any]:
        return await self.db.broadcast_stats(int(broadcast_id))


def _safe_err(exc: Optional[Exception]) -> str:
    if exc is None:
        return ""
    return f"{type(exc).__name__}: {exc}"[:300]


__all__ = [
    "NetworkBroadcastEngine", "classify_send_error",
    "B_PENDING", "B_RUNNING", "B_PAUSED", "B_COMPLETED", "B_CANCELLED",
    "B_FAILED", "BJ_PENDING", "BJ_RUNNING", "BJ_PAUSED", "BJ_COMPLETED",
    "BJ_CANCELLED", "BJ_FAILED", "D_PENDING", "D_SENT", "D_FAILED",
    "D_BLOCKED", "D_UNAVAILABLE", "D_CANCELLED", "D_RETRYING",
    "C_SUCCESS", "C_TEMPORARY", "C_FLOOD_WAIT", "C_BLOCKED",
    "C_UNAVAILABLE", "C_BOT_INVALID", "C_SOURCE_UNAVAILABLE",
    "C_PERMANENT",
    "M_TEXT", "M_COPY", "M_COPY_MULTI", "M_FORWARD", "M_FORWARD_MULTI",
    "M_PHOTO", "M_VIDEO", "M_DOCUMENT", "M_AUDIO", "M_ALBUM",
    "M_PAYLOAD_ANNOUNCEMENT", "M_TEMPLATE",
    "T_ALL_BOTS", "T_SELECTED_BOTS", "T_USERS_OF_BOT", "T_ALL_REACHABLE",
    "MAX_USER_ATTEMPTS", "BATCH_PAGE",
]
