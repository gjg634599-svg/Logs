"""app.network — the NETWORK PLATFORM service package (Phase 8 → Network).

Additive layer on top of the verified Phase 8 architecture. Modules:

  * ``credentials``  — CredentialVault: authenticated encryption for bot
    tokens (Fernet primary, stdlib HMAC-CTR+EtM fallback). Spec §3.
  * ``registry``     — BotRegistryService: verified-activation
    registration state machine, identity/duplicate/limit/consent gates,
    health + lifecycle transitions, memberships. Spec §2/§4/§5/§13/§14/
    §15/§57/§58.
  * ``points``       — PointService: idempotent ledger, atomic debits,
    registration reward (+5 capped at 25 by default), transactional
    payload unlocks. Spec §6/§7/§8/§10.
  * ``routing``      — NetworkRouter + GlobalPayloadLinks: health-aware
    weighted-random routing, reachability, bounded fallback, loop
    prevention, opaque signed link codes. Spec §16-§20/§55.
  * ``broadcast``    — NetworkBroadcastEngine: durable broadcast jobs,
    per-bot workers, pause/resume/cancel, failure classification, rate
    limiting. Spec §25-§46.
  * ``workers``      — BotWorkerManager: PTB application lifecycles for
    network bots sharing the SAME business logic. Spec §11/§12/§59.

All modules are STANDALONE (never import the bot monolith) — bot.py
wires them with its DB adapter and transports, exactly like app/core/*.
"""
from .credentials import CredentialVault, mask_token, KEY_VERSION
from .registry import BotRegistryService, token_format_ok
from .points import PointService
from .routing import NetworkRouter, GlobalPayloadLinks, MAX_REDIRECTS
from .broadcast import NetworkBroadcastEngine, classify_send_error
from .workers import BotWorkerManager, BotWorker

__all__ = [
    "CredentialVault", "mask_token", "KEY_VERSION",
    "BotRegistryService", "token_format_ok",
    "PointService",
    "NetworkRouter", "GlobalPayloadLinks", "MAX_REDIRECTS",
    "NetworkBroadcastEngine", "classify_send_error",
    "BotWorkerManager", "BotWorker",
]
