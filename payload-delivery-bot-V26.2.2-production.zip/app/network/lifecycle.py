"""Network platform lifecycle (ARCHITECTURE DECOUPLING — §7/§9).

The network wiring previously embedded in bot.py (service singleton
construction, worker application builder, worker error classification,
the network delivery transport, startup/shutdown orchestration, the
health loop) — extracted with the same late-binding contract: ALL
state and handler references resolve through the legacy namespace
``ns`` at CALL TIME.

Worker lifecycle ownership (§9) is explicit here:
* ``network_startup(ns)`` starts workers + the health loop exactly once
  (post_init);
* ``network_shutdown(ns)`` cancels the health loop, stops the broadcast
  engines, then the workers, exactly once (post_shutdown) — always
  BEFORE the shared DB closes.

The singletons themselves stay on the legacy namespace
(``ns._net_vault`` ... ``ns._net_workers``, ``ns.net_health_task``) so
the regression suites' patching semantics keep working unchanged.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

from telegram import Update
from telegram.error import BadRequest, Forbidden, RetryAfter, TelegramError  # noqa: F401 — retained for facade re-export compat
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ManagedBotUpdatedHandler,
    MessageHandler,
    filters,
)

from app.core.constants import (
    NET_DEFAULT_MAX_BOTS,
    NET_DEFAULT_POINT_COST,
    NET_DEFAULT_POINTS_PER_BOT,
    NET_SETTING_HEALTH_INTERVAL,
    NET_SETTING_MAX_BOTS,
    NET_SETTING_POINT_COST,
    NET_SETTING_POINTS_PER_BOT,
    NET_PT_UNLOCK_CB, NET_PTS_CB, NET_BOT_CB, NET_REG_CB,
)
from app.network.credentials import CredentialVault
from app.network.points import PointService
from app.network.registry import BotRegistryService
from app.network.routing import GlobalPayloadLinks, NetworkRouter
from app.network.broadcast import NetworkBroadcastEngine
from app.network.workers import BotWorkerManager

logger = logging.getLogger("payload-bot")


def is_network_bot_client(bot, ns) -> bool:
    """True when `bot` is a NETWORK worker's client (not the main bot).

    Identifies by telegram id when available (PTB ExtBot carries .id after
    initialize); falls back to username lookup against the worker manager
    (fake transports in tests)."""
    if getattr(ns, "_MAIN_BOT_TG_ID", None) is None:
        return False
    try:
        bid = getattr(bot, "id", None)
        if bid is not None:
            return int(bid) != int(ns._MAIN_BOT_TG_ID)
        uname = (getattr(bot, "username", "") or "").lstrip("@")
        if uname and getattr(ns, "_net_workers", None) is not None:
            return ns._net_workers.get_by_username(uname) is not None
    except Exception:  # noqa: BLE001
        return False
    return False


def _worker_manager_nid_lookup(manager, bot) -> Optional[int]:
    """BOT-11 §9 (B11-A): resolve a live worker client's network_bot_id
    through the BotWorkerManager — telegram-id lookup first, username
    fallback. Returns None when the bot is not a live registered worker.

    PTB NOTE: ``Bot.id`` / ``Bot.username`` raise RuntimeError before
    ``initialize()`` (getattr defaults do NOT absorb it) — every access
    is guarded. ``bot_data`` lives on Application, NEVER on Bot: that
    wrong assumption is the bot-11.log network_bot_id=0 root cause."""
    if manager is None or bot is None:
        return None
    try:
        bid = getattr(bot, "id", None)
    except Exception:  # noqa: BLE001 — uninitialized PTB client
        bid = None
    if bid:
        try:
            w = manager.get_by_telegram_id(int(bid))
        except Exception:  # noqa: BLE001
            w = None
        if w is not None:
            return int(w.network_bot_id)
    try:
        uname = (getattr(bot, "username", "") or "").lstrip("@")
    except Exception:  # noqa: BLE001 — uninitialized PTB client
        uname = ""
    if uname:
        try:
            w = manager.get_by_username(uname)
        except Exception:  # noqa: BLE001
            w = None
        if w is not None:
            return int(w.network_bot_id)
    return None


async def init_network_services(main_bot_tg_id: Optional[int], ns) -> None:
    """Create the network service singletons (post_init, after DB).

    The singletons are written onto the legacy namespace (identical
    global-assignment semantics to the original bot.py implementation —
    patching ``B._net_registry`` etc. keeps working).

    GAP-CLOSURE (spec §3/§4): the DEDICATED persistent secrets are wired
    here — NETWORK_TOKEN_ENCRYPTION_KEY (fail-closed for new credential
    encryption) and NETWORK_GLOBAL_LINK_SIGNING_KEY (dedicated link
    signing; the legacy BOT_TOKEN derivation is kept for VERIFICATION of
    pre-existing links only). Neither key is ever logged.
    """
    from app.bootstrap.config import EnvDefaults as _EnvDefaults
    _env = _EnvDefaults.from_env()

    ns._MAIN_BOT_TG_ID = main_bot_tg_id
    ns._net_vault = CredentialVault(bot_token_fallback=ns.BOT_TOKEN)
    ns._net_points = PointService(ns.db)
    _signing_key = (_env.network_global_link_signing_key or "").strip()
    if _signing_key:
        ns._net_links = GlobalPayloadLinks(
            _signing_key, legacy_secret=ns.BOT_TOKEN)
    else:
        # Spec §4 fail-closed for MINTING; legacy BOT_TOKEN-signed links
        # keep verifying through parse().
        ns._net_links = GlobalPayloadLinks(ns.BOT_TOKEN, dedicated=False)
    ns._net_router = NetworkRouter(ns.db)
    ns._net_registry = BotRegistryService(
        ns.db, ns._net_vault,
        validate_token=ns._net_validate_token_via_telegram,
        probe_storage_access=ns._net_probe_storage_access)
    ns._net_workers = BotWorkerManager(ns._build_network_bot_application,
                                       on_worker_error=ns._net_worker_error,
                                       # b10 §8 (B10-B2): reapply the Main
                                       # Mini App link (menu button) on
                                       # every worker start — new bots,
                                       # re-registrations AND the restart
                                       # path (requirement C). Resolved
                                       # defensively: a namespace without
                                       # the facade simply skips it.
                                       on_worker_started=getattr(
                                           ns, "_net_on_worker_started",
                                           None))
    ns._net_broadcast = NetworkBroadcastEngine(
        ns.db,
        get_bot_client=ns._net_get_bot_client,
        send_one=ns._net_broadcast_send_one)
    # ---- FILE DELIVERY v34 (spec §20-§66): the trusted relay plane -------
    from app.network.file_delivery import (
        FileDeliveryBotManager, DeliveryJobEngine, is_delivery_ready,
    )
    try:
        from app.bootstrap.application import ptb_local_api_endpoints
        _fdb_endpoints = ptb_local_api_endpoints()
    except Exception:  # noqa: BLE001 — never block service construction
        _fdb_endpoints = None
    ns._fdb = FileDeliveryBotManager(ns.db, ns._net_vault,
                                      local_api=_fdb_endpoints)
    ns._fdb.set_env_seed_token(_env.file_delivery_bot_token)
    # BOT-11 §9 (B11-A): the delivery engine resolves the serving worker
    # client's network_bot_id through the MANAGER (a PTB Bot client carries
    # NO bot_data — Application owns it; the legacy engine guess therefore
    # always returned 0 → NETWORK_DELIVERY_NO_DELIVERY_GROUP, the 13
    # consecutive bot-11.log delivery failures).
    ns._net_delivery_jobs = DeliveryJobEngine(
        ns.db, ns._fdb,
        resolve_network_bot_id=lambda bot: _worker_manager_nid_lookup(
            getattr(ns, "_net_workers", None), bot))
    # The router's authoritative delivery-ready predicate (spec §46):
    # ONE definition shared by every routing path.
    ns._net_router.delivery_ready = (
        lambda bot_row, group_row=None: is_delivery_ready(
            ns.db, ns._fdb, bot_row, group_row=group_row))
    ns.logger.info(
        "NETWORK_PLATFORM_INIT key_version=%s encryption_key_dedicated=%s "
        "link_signing_dedicated=%s max_bots=%s "
        "points_per_bot=%s point_cost=%s",
        ns._net_vault.key_version,
        not ns._net_vault.encryption_key_missing,
        bool(getattr(ns._net_links, "uses_dedicated_key", False)),
        await ns.db.get_setting_int(NET_SETTING_MAX_BOTS,
                                    NET_DEFAULT_MAX_BOTS),
        await ns.db.get_setting_int(NET_SETTING_POINTS_PER_BOT,
                                    NET_DEFAULT_POINTS_PER_BOT),
        await ns.db.get_setting_int(NET_SETTING_POINT_COST,
                                    NET_DEFAULT_POINT_COST))
    # v37 (bot-8 A1): ONE unambiguous truthful status line for the dedicated
    # encryption key — the operator-facing "configured / missing" answer.
    # Never logs the secret itself.
    if not ns._net_vault.encryption_key_missing:
        ns.logger.info(
            "NETWORK_TOKEN_ENCRYPTION_KEY: configured (dedicated key "
            "active, key_version=%s; legacy credentials keep decrypting "
            "and are migrated on worker start)",
            ns._net_vault.key_version)
    # Safe startup diagnostics (spec §3 — never the secret itself):
    ns.logger.info(
        "GLOBAL_LINK_SIGNING_KEY_CONFIGURED global_link_signing_key_configured"
        "=%s (new link minting %s)",
        bool(getattr(ns._net_links, "uses_dedicated_key", False)),
        "enabled" if getattr(ns._net_links, "uses_dedicated_key", False)
        else "REFUSED fail-closed")
    if ns._net_vault.encryption_key_missing:
        ns.logger.warning(
            "NETWORK_TOKEN_ENCRYPTION_KEY: missing — NEW network-bot "
            "registrations are refused (fail-closed, spec §3). Existing "
            "legacy credentials keep decrypting. Set the dedicated key to "
            "enable registrations.")
    if not getattr(ns._net_links, "uses_dedicated_key", False):
        ns.logger.warning(
            "NETWORK_GLOBAL_LINK_SIGNING_KEY not set: creating NEW global "
            "payload links is refused (fail-closed, spec §4). Existing "
            "links keep verifying. Set the dedicated key to enable minting.")


async def net_worker_error(network_bot_id: int, exc: Exception, ns) -> None:
    """Worker startup failure — classify honestly (spec §4/§14): an
    InvalidToken-ish failure marks TOKEN_INVALID; other failures keep the
    bot PENDING/ERROR without disabling routing forever."""
    try:
        name = type(exc).__name__
        msg = str(exc) or ""
        if "InvalidToken" in name or "unauthorized" in msg.lower() \
                or "Not Found" in msg:
            await ns.db.update_network_bot_status(
                int(network_bot_id), "TOKEN_INVALID",
                last_error_code="TOKEN_INVALID")
            ns.logger.warning("NETWORK_BOT_TOKEN_INVALID network_bot_id=%s",
                              network_bot_id)
        else:
            await ns.db.update_network_bot_health(
                int(network_bot_id), "TEMPORARILY_UNAVAILABLE",
                error_code="WORKER_START_FAILED")
    except Exception:  # noqa: BLE001
        pass


async def network_callback_guard(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 ns) -> None:
    """Callback dispatch for NETWORK workers: shared on_callback handles
    every USER-safe prefix; admin/management actions are redirected to
    the main bot (spec §63)."""
    q = update.callback_query
    if not q or not q.data:
        return
    data = str(q.data)
    if data.startswith(ns._NET_USER_CALLBACK_PREFIXES):
        await ns.on_callback(update, context)
        return
    await ns.safe_answer_callback(q, show_alert=True,
        text="This action is managed in the main bot.")
    ns.logger.info("NETWORK_CALLBACK_REDIRECT network_bot_id=%s user_id=%s "
                   "prefix=%s (admin/management action — main bot only)",
                   ns._net_context_id(context),
                   q.from_user.id if q.from_user else 0, data.split(":", 1)[0])

    # Non-admin media messages in network bots are ignored (same as the
    # main bot's behavior for unconfigured states).


async def build_network_bot_application(token: str, network_bot_id: int,
                                        username: str, ns):
    """Build a NETWORK worker PTB Application with the SHARED handlers.

    Every handler function is the SAME code the main bot uses — the
    business logic (Access Engine, Delivery Engine, Watch Ads, Referral,
    Force Join, Points, DB, settings) is entirely shared. Only the
    execution context differs: app.bot_data carries network_bot_id +
    bot_username for scoping (memberships, link building, admin guard).
    """
    # GAP-CLOSURE spec §15: network workers get the SAME Local Bot API
    # base_url/base_file_url wiring as the main bot when TELEGRAM_API_MODE
    # is actually local (cloud/auto workers keep the normal API URL).
    try:
        from app.bootstrap.application import ptb_local_api_endpoints
        _endpoints = ptb_local_api_endpoints()
    except Exception:  # noqa: BLE001 — never block worker construction
        _endpoints = None
    _builder = ApplicationBuilder().token(token)
    if _endpoints is not None:
        _builder = _builder.base_url(_endpoints["base_url"])
        _builder = _builder.base_file_url(_endpoints["base_file_url"])
    # B18 (bot-19.log 03:34:04 + 03:35:12-24): PTB's HTTPXRequest defaults
    # (read=5 s) are too short for large-media copy operations — the same
    # worker's set_chat_menu_button AND two consecutive Mode-A relay
    # copies TimedOut in bot-19.log. Every DELIVERY-capable worker client
    # gets the explicit delivery timeouts (single source of truth in
    # app/network/file_delivery.py).
    try:
        from telegram.request import HTTPXRequest
        from app.network.file_delivery import _delivery_httpx_request_kwargs
        _rq = _delivery_httpx_request_kwargs()
        # getUpdates long-poll keeps its own bounded pool (poll responses
        # are small; the delivery pool is the one that needs headroom).
        _builder = _builder.request(HTTPXRequest(**_rq))
        _builder = _builder.get_updates_request(HTTPXRequest(
            read_timeout=_rq["read_timeout"],
            write_timeout=_rq["write_timeout"],
            connect_timeout=_rq["connect_timeout"]))
    except Exception:  # noqa: BLE001 — never block worker construction
        pass
    app = (
        _builder
        .concurrent_updates(True)
        .build()
    )
    app.bot_data["network_bot_id"] = int(network_bot_id)
    app.bot_data["bot_username"] = (username or "").lstrip("@")
    app.add_handler(CommandHandler("start", ns.start_command))
    app.add_handler(CommandHandler("recent", ns.recent_command))
    app.add_handler(CommandHandler("help", ns.help_command))
    app.add_handler(CommandHandler("network", ns.network_command))
    app.add_handler(CallbackQueryHandler(ns._network_callback_guard))
    app.add_handler(MessageHandler(
        (filters.PHOTO | filters.VIDEO | filters.Document.ALL
         | filters.AUDIO | filters.VOICE | filters.ANIMATION)
        & ~filters.COMMAND, ns._network_media_guard))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,
                                    ns.text_handler))
    # b10 §7 (B10-B2): MANAGED-BOT CREATION FROM ANY REGISTERED NETWORK
    # BOT — a worker that itself has Telegram's can_manage_bots
    # capability can manage (create) NEW bots, and the
    # MANAGED_BOT_CREATED service message + Update.managed_bot then
    # arrive at THAT worker (it is the new bot's manager). The SAME
    # namespace facades (network_wiring.py → app/network/managed_bots.py)
    # are registered here in handler group 1 (deterministic, after the
    # shared group-0 handlers — zero behavior change for normal
    # messages; begin_managed_creation capability-gates the entry).
    # Resolved defensively: a namespace without the facades simply does
    # not get managed creation in its workers (honest degradation).
    _mb_created_handler = getattr(ns, "handle_managed_bot_created_message",
                                  None)
    if _mb_created_handler is not None:
        app.add_handler(MessageHandler(
            filters.StatusUpdate.MANAGED_BOT_CREATED,
            _mb_created_handler), group=1)
    _mb_updated_handler = getattr(ns, "handle_managed_bot_update", None)
    if _mb_updated_handler is not None:
        app.add_handler(ManagedBotUpdatedHandler(_mb_updated_handler),
                        group=1)
    # FILE DELIVERY v34 (spec §41/§73): Delivery Group DETECTION. Group
    # messages reach the network bot worker (commands always arrive even
    # under privacy mode); a dedicated handler in a LATER handler group
    # (1) sees them AFTER the existing group-0 handlers — zero behavior
    # change for normal chats. When a Delivery Group setup is pending for
    # THIS bot and the sender is the owner, the chat is captured and the
    # full verification chain runs (FDB present + admin + permissions +
    # network bot identity — spec §46).
    # v37 (bot-8 A5): an EXPLICIT /setup command handler is registered so
    # the documented "send /setup in the group" path is deterministic
    # (commands reach the worker even under Telegram privacy mode; the
    # generic group-message guard below remains the any-message path).
    app.add_handler(CommandHandler("setup", ns._net_setup_command), group=1)
    # A.2.4 (bot-25): Delivery CHANNEL transport — the detection
    # MessageHandler now ALSO matches CHANNEL posts
    # (filters.ChatType.CHANNEL) alongside (super)group messages. The
    # named shim network_delivery_channel_guard (below, in THIS module —
    # never a partial or inline lambda) is the explicit dispatch target
    # through the network_wiring facade; it routes into the EXISTING
    # detection handler chain. (Super)group relays remain supported for
    # already-verified rows but are deprecated for new setups — a bot
    # cannot see another bot's supergroup messages (bot-25.log jobs
    # 48/49: Message to forward not found), while channel posts ARE
    # accessible to admin bots.
    _delivery_channel_guard = getattr(ns, "_net_delivery_channel_guard", None)
    if _delivery_channel_guard is None:
        _delivery_channel_guard = getattr(ns, "_net_delivery_group_guard")
    app.add_handler(MessageHandler(
        (filters.ChatType.CHANNEL | filters.ChatType.GROUPS)
        & ~filters.StatusUpdate.ALL,
        _delivery_channel_guard), group=1)
    return app


async def network_setup_command(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                ns) -> None:
    """v37 (bot-8 A5): explicit /setup on NETWORK workers.

    Deterministic entry for the documented Delivery Channel setup step: log
    SETUP_COMMAND_RECEIVED, then run the SAME detection/verification chain
    as any group/channel message (never a fake success — the real
    verification runs inside). No-op when no setup is pending for this bot
    (the instructions message already tells the user what to do)."""
    try:
        chat = update.effective_chat
        user = update.effective_user
        bd = getattr(context, "application", None)
        bd = getattr(bd, "bot_data", None) if bd is not None else None
        nid = int(bd.get("network_bot_id")) if bd and bd.get(
            "network_bot_id") else None
        logger.info("SETUP_COMMAND_RECEIVED network_bot_id=%s "
                    "chat_id=%s user_id=%s",
                    nid or 0,
                    getattr(chat, "id", 0),
                    getattr(user, "id", 0))
    except Exception:  # noqa: BLE001 — diagnostics only
        pass
    await network_delivery_channel_guard(update, context, ns)


async def network_delivery_channel_guard(update: Update,
                                         context: ContextTypes.DEFAULT_TYPE,
                                         ns) -> None:
    """A.2.4 (bot-25): the Delivery CHANNEL detection shim.

    A minimal, module-level NAMED function (never a partial or inline
    lambda) so the worker's channel+group MessageHandler has a stable,
    importable dispatch target. It routes into the EXISTING detection
    handler chain (network_delivery_group_guard →
    ns._net_handle_delivery_group_detection → delivery_ui), which now
    accepts channel-type chats too."""
    await network_delivery_group_guard(update, context, ns)


async def network_delivery_group_guard(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE,
                                        ns) -> None:
    """Group-message hook on NETWORK workers (spec §41/§73 detection).

    Only acts when a Delivery Group setup is PENDING for this network
    bot AND the message sender is the owner — otherwise silently
    returns (the shared handlers already processed the message in
    handler group 0). On capture it runs the REAL verification chain.
    """
    try:
        handler = getattr(ns, "_net_handle_delivery_group_detection", None)
        if handler is None:
            return
        await handler(update, context)
    except Exception:  # noqa: BLE001 — never break worker message flow
        ns.logger.exception("DELIVERY_GROUP_GUARD_ERROR")


async def network_send_file_by_source(bot, chat_id: int, file_row,
                                      protect_content: bool = False,
                                      payload_code: Optional[str] = None,
                                      ns=None) -> Optional[int]:
    """Deliver ONE indexed file through a NETWORK bot via the V25 FINAL
    two-stage Delivery Channel architecture:

        Storage master (channel_id + message_id)
            ↓ File Delivery Bot copyMessage (Stage A)
        Delivery Channel message (durable delivery_message_id)
            ↓ Network Bot copyMessage (Stage B — the FINAL user-facing
              send, a true copy with no forward header)
        USER

    The network bot requires NO Storage Channel access at all. Durable
    state lives in delivery_jobs: failures are scheduled for retry, TTL
    cleanup covers abandoned legacy relays, and crash recovery
    reconciles interrupted jobs.

    V25 FINAL §10: a CONFIRMED-unavailable source (source_status=
    'unavailable' — proven deleted) is NEVER re-attempted; the honest
    notice replaces the dead operation.

    NEVER a cross-bot file_id reuse; NEVER file_unique_id in send APIs.
    """
    if ns is None:  # pragma: no cover — defensive; facade always passes ns
        raise RuntimeError("network_send_file_by_source requires ns")
    try:
        channel_id = int(file_row["channel_id"])
        message_id = int(file_row["message_id"])
    except (KeyError, TypeError, ValueError):
        ns.logger.error("NETWORK_DELIVERY_NO_SOURCE_REF file_pk=%s (row has no "
                        "channel/message reference — cannot source-copy)",
                        file_row["id"] if "id" in file_row.keys() else "-")
        return None
    # V25 FINAL §10 (bot-35.log file_pk=688): skip the dead operation
    # for a CONFIRMED-unavailable source (defensive against Row/dict).
    try:
        _status = str((file_row["source_status"] if "source_status"
                       in file_row.keys() else "") or "").lower()
    except Exception:  # noqa: BLE001 — gate must never crash delivery
        _status = ""
    if _status == "unavailable":
        ns.logger.error(
            "BOT6_DELIVERY_SOURCE_UNAVAILABLE_SKIP file_pk=%s chat=%s "
            "payload_code=%s (network path: source CONFIRMED unavailable "
            "— the dead Stage-A send is NOT re-executed)",
            file_row["id"] if "id" in file_row.keys() else "-", chat_id,
            payload_code or "-")
        try:
            await ns._send_delivery_failure(bot, chat_id, file_row,
                                            payload_code)
        except Exception:  # noqa: BLE001 — notice is best-effort
            pass
        return None
    user_id = int(chat_id)  # private delivery: the chat id IS the user id
    # Resolve the delivery job engine (v34). Falls back honestly when the
    # relay plane is not wired (defensive — the wiring is unconditional
    # in init_network_services).
    engine = getattr(ns, "_net_delivery_jobs", None)
    fdb = getattr(ns, "_fdb", None)
    if engine is None or fdb is None:
        ns.logger.error("NETWORK_DELIVERY_NO_RELAY_PLANE (file delivery "
                        "services not initialized)")
        return None
    # BOT-11 §9 (B11-A): resolve the serving bot's network_bot_id
    # AUTHORITATIVELY (bot-11.log root cause: the engine's legacy
    # bot_data-on-Bot guess is ALWAYS 0 for a live PTB worker client —
    # bot_data lives on Application, never on Bot). Manager lookup first
    # (telegram id → username fallback), client stamp second.
    nid = 0
    via = "unknown"
    mgr_nid = _worker_manager_nid_lookup(
        getattr(ns, "_net_workers", None), bot)
    if mgr_nid:
        nid, via = int(mgr_nid), "worker_manager"
    else:
        try:
            stamp = int(getattr(bot, "_network_bot_id", 0) or 0)
        except (TypeError, ValueError):
            stamp = 0
        if stamp:
            nid, via = stamp, "client_stamp"
    ns.logger.info("DELIVERY_TARGET_BOT_RESOLVED network_bot_id=%s via=%s",
                   nid, via)
    # The user-facing failure card is the shared engine's job (same UX
    # as the pre-v34 transport: retry button etc.).
    sent = await engine.deliver(
        network_bot=bot, chat_id=int(chat_id), file_row=dict(file_row),
        protect_content=bool(protect_content),
        payload_code=payload_code,
        user_id=user_id,
        network_bot_id=nid)
    if sent is None:
        # Deliver the retry card directly (spec §54 honest failure UX).
        await ns._send_delivery_failure(bot, chat_id, file_row, payload_code)
        return None
    return sent


async def network_send_files_by_source(ns, bot, chat_id: int, file_rows,
                                       protect_content: bool = False,
                                       payload_code: Optional[str] = None
                                       ) -> "tuple[list, int]":
    """V25 FINAL §6/§7 — deliver a MULTI-FILE collection through the
    two-stage Delivery Channel architecture with REAL album semantics:

        Storage masters (channel_id + message_id each)
            ↓ File Delivery Bot copyMessage (Stage A, per file, in order)
        Delivery Channel messages (durable delivery_message_ids)
            ↓ Network Bot copyMessages (Stage B, ≤10-file chunks —
              a REAL Telegram media-group album to the user)
        USER

    The user receives a proper Telegram album/media-group presentation
    whenever Telegram's API permits (photo/video/animation runs);
    non-album types and mixed runs deliver as ordered single copies.
    Album-eligible ordering/collection identity are preserved; a failed
    member never aborts the rest (each file has its own durable job).

    Returns ``(user_message_ids, sent_count)`` — empty list on honest
    failure (the caller shows the failure card).
    """
    if ns is None:
        raise RuntimeError("network_send_files_by_source requires ns")
    rows = [dict(f) for f in file_rows]
    if not rows:
        return [], 0
    engine = getattr(ns, "_net_delivery_jobs", None)
    if engine is None:
        ns.logger.error("NETWORK_DELIVERY_NO_RELAY_PLANE (album: file "
                        "delivery services not initialized)")
        return [], 0
    user_id = int(chat_id)
    nid = 0
    via = "unknown"
    mgr_nid = _worker_manager_nid_lookup(
        getattr(ns, "_net_workers", None), bot)
    if mgr_nid:
        nid, via = int(mgr_nid), "worker_manager"
    else:
        try:
            stamp = int(getattr(bot, "_network_bot_id", 0) or 0)
        except (TypeError, ValueError):
            stamp = 0
        if stamp:
            nid, via = stamp, "client_stamp"
    ns.logger.info("DELIVERY_TARGET_BOT_RESOLVED network_bot_id=%s via=%s "
                   "(album files=%s)", nid, via, len(rows))
    ids, sent = await engine.deliver_album(
        network_bot=bot, chat_id=int(chat_id), file_rows=rows,
        protect_content=bool(protect_content),
        payload_code=payload_code,
        user_id=user_id,
        network_bot_id=nid or None)
    if not ids:
        frow = rows[0]
        await ns._send_delivery_failure(bot, chat_id, frow, payload_code)
    return ids, sent


async def reactivate_network_bot(ns, owner_user_id: int, token: str, *,
                                  consent_confirmed: bool = True,
                                  existing_network_bot_id: Optional[int] = None,
                                  telegram_bot_id: Optional[int] = None,
                                  restart_worker: bool = True
                                  ) -> Dict[str, Any]:
    """BOT-11 §5/§6/§7 (B11-A): thin facade for the registry's
    reactivate_removed_bot + the worker restart.

    Mirrors the registration flows (control_ui / network_ui): registry
    service call first (fresh getMe verification — nothing persisted on
    failure), then start_worker for the row + mark_active when the worker
    actually starts. Reactivation awards NOTHING (not a new registration).
    The recovery UX itself lives in network_ui.py (agent B11-B) — this is
    the complete service layer it calls into.
    """
    registry = getattr(ns, "_net_registry", None)
    if registry is None:
        ns.logger.error("NETWORK_BOT_REACTIVATION_SKIPPED reason="
                        "network_service_unavailable owner=%s",
                        int(owner_user_id))
        return {"ok": False, "reason": "network_service_unavailable"}
    res = await registry.reactivate_removed_bot(
        int(owner_user_id), token,
        consent_confirmed=bool(consent_confirmed),
        existing_network_bot_id=existing_network_bot_id,
        telegram_bot_id=telegram_bot_id)
    if not res.get("ok"):
        # Honest failure — the registry already logged the precise reason.
        return res
    nid = int(res["network_bot_id"])
    ns.logger.info("NETWORK_BOT_REACTIVATED network_bot_id=%s owner=%s",
                   nid, int(owner_user_id))
    res["worker_started"] = False
    if restart_worker:
        worker = None
        try:
            worker = await ns._net_workers.start_worker(
                nid, int(res.get("telegram_bot_id") or 0),
                str(res.get("username") or ""), token)
        except Exception as exc:  # noqa: BLE001 — isolated, honest flag
            ns.logger.error("NETWORK_BOT_REACTIVATION_WORKER_FAILED "
                            "network_bot_id=%s error=%s",
                            nid, str(exc)[:160])
        if worker is not None:
            res["worker_started"] = True
            await ns._net_registry.mark_active(nid)
        else:
            ns.logger.warning(
                "NETWORK_BOT_REACTIVATED network_bot_id=%s worker=NOT_STARTED "
                "(row stays PENDING — the restart path picks it up after the "
                "token/transport issue is fixed)", nid)
    return res


async def network_startup(app_bot, ns) -> None:
    """post_init hook: init services, restart ACTIVE workers, resume
    RUNNING broadcasts. Failures are isolated per bot."""
    # FILE DELIVERY v35 (production bug fix, spec §31/§32): the service
    # singletons — including the File Delivery Bot manager and the durable
    # delivery-job engine — are constructed BEFORE the network_enabled
    # check. The relay plane is an independent subsystem: with the network
    # platform toggled OFF, admins must still be able to open the Control
    # Panel / Delivery Group UI and (de)configure the File Delivery Bot.
    # (Previously this early-return left ns._fdb unset and panel:control
    # crashed with AttributeError.)
    me_id = getattr(app_bot, "id", None)
    try:
        await init_network_services(me_id, ns)
    except Exception as e:  # noqa: BLE001 — diagnose, never block the bot
        ns.logger.error("NETWORK_PLATFORM service init failed: %s",
                        e, exc_info=True)
    if not await ns.network_enabled():
        ns.logger.info("NETWORK_PLATFORM disabled (network_enabled=0) — "
                       "no workers started.")
        return
    # Restart workers for every ACTIVE bot (skip the main bot's own
    # identity — the main bot is never a network worker).
    bots = await ns.db.list_network_bots()
    started = 0
    for b in bots:
        if str(b["status"]) != "ACTIVE":
            continue
        if ns._MAIN_BOT_TG_ID is not None \
                and int(b["telegram_bot_id"]) == int(ns._MAIN_BOT_TG_ID):
            continue
        cred = await ns.db.get_network_bot_credential(int(b["id"]))
        if not cred:
            await ns.db.update_network_bot_status(
                int(b["id"]), "TOKEN_INVALID",
                last_error_code="CREDENTIAL_MISSING")
            logger.warning(
                "NETWORK_BOT_CREDENTIAL_INVALID network_bot_id=%s "
                "reason=CREDENTIAL_MISSING (no stored credential for an "
                "ACTIVE bot — re-register or replace the token to recover)",
                int(b["id"]))
            continue
        try:
            # v37 (bot-8 A2): decrypt through the compatibility path — the
            # dedicated key first, the legacy BOT_TOKEN-derived key second —
            # then MIGRATE a legacy credential to the dedicated key so the
            # next restart needs no fallback.
            token, used_legacy = ns._net_vault.decrypt_with_info(
                cred["encrypted_token"])
        except ValueError as exc:
            await ns._net_registry.mark_token_invalid(
                int(b["id"]), "CREDENTIAL_DECRYPT_FAILED")
            logger.warning(
                "NETWORK_BOT_CREDENTIAL_INVALID network_bot_id=%s "
                "reason=CREDENTIAL_DECRYPT_FAILED stored_key_version=%s "
                "detail=%s (the credential cannot be decrypted with the "
                "current NETWORK_TOKEN_ENCRYPTION_KEY nor the legacy "
                "BOT_TOKEN-derived key — replace the token via Managed Bot "
                "token replacement or re-register the bot; the record is "
                "preserved, nothing was deleted)",
                int(b["id"]), cred.get("key_version"), str(exc)[:80])
            continue
        if used_legacy and ns._net_vault.can_encrypt:
            try:
                migrated = ns._net_vault.encrypt(token)
                await ns.db.replace_network_bot_credential(
                    int(b["id"]), encrypted_token=migrated,
                    key_version=ns._net_vault.key_version)
                logger.info(
                    "NETWORK_BOT_CREDENTIAL_MIGRATED network_bot_id=%s "
                    "from_key_version=%s to_key_version=%s (legacy "
                    "credential transparently re-encrypted with the "
                    "dedicated key)", int(b["id"]),
                    cred.get("key_version"), ns._net_vault.key_version)
            except Exception as exc:  # noqa: BLE001 — migration is best-effort
                logger.warning(
                    "NETWORK_BOT_CREDENTIAL_MIGRATE_FAILED network_bot_id=%s "
                    "error=%s (legacy credential keeps working this run)",
                    int(b["id"]), str(exc)[:80])
        worker = await ns._net_workers.start_worker(
            int(b["id"]), int(b["telegram_bot_id"]),
            str(b["username"] or ""), token)
        if worker is not None:
            started += 1
            await ns._net_registry.mark_health(int(b["id"]), "HEALTHY")
    ns.logger.info("NETWORK_WORKERS_STARTED count=%s (ACTIVE bots in "
                   "registry)", started)
    # Resume durable RUNNING broadcasts (spec §39 — never from zero).
    resumed = await ns._net_broadcast.resume_pending()
    if resumed:
        ns.logger.info("NETWORK_BROADCAST_RESUMED count=%s", resumed)
    # FILE DELIVERY v34: start the trusted relay plane (File Delivery
    # Bot client + durable delivery job sweeper — spec §21/§53).
    try:
        await ns._fdb.start()
        ns._net_delivery_jobs.bot_client_resolver = (
            ns._net_workers.get_bot_client)
        # FINAL-1 (bot-20.log) + B23-2: the FDB manager gets the SAME
        # nid→client resolver. Under HYBRID it serves TWO honest purposes:
        # verify_delivery_group's INFORMATIONAL network_bot_storage_access
        # probe (checks dict only — the network bot does NOT need storage
        # under HYBRID) and the NETWORK_BOT_USER_FORWARD strengthening
        # probe (the network bot's own getChat(group) — hop 2 reads FROM
        # the group with that client). The HYBRID hop-1 storage probe
        # itself always runs with the FDB's OWN client (§2.1).
        ns._fdb.network_bot_client_resolver = (
            ns._net_workers.get_bot_client)
        await ns._net_delivery_jobs.start()
        # Crash recovery for interrupted delivery jobs (spec §55).
        await ns._net_delivery_jobs.reconcile_startup()
    except Exception as exc:  # noqa: BLE001 — isolated: never kill startup
        ns.logger.error("FILE_DELIVERY_START_FAILED error=%s", str(exc)[:200])
    # Periodic health loop.
    interval = max(60, await ns.db.get_setting_int(NET_SETTING_HEALTH_INTERVAL,
                                                   300))
    ns.net_health_task = asyncio.create_task(
        net_health_loop(interval, ns))


async def net_health_loop(interval: int, ns) -> None:
    """Light periodic health check (spec §13/§14 — configurable, never a
    tight Telegram poll)."""
    try:
        while True:
            await asyncio.sleep(int(interval))
            bots = await ns.db.list_network_bots()
            for b in bots:
                if str(b["status"]) != "ACTIVE":
                    continue
                nid = int(b["id"])
                client = ns._net_workers.get_bot_client(nid)
                if client is None:
                    await ns.db.update_network_bot_health(
                        nid, "TEMPORARILY_UNAVAILABLE",
                        error_code="WORKER_STOPPED")
                    continue
                try:
                    await client.get_me()
                    await ns._net_registry.mark_health(nid, "HEALTHY")
                except Exception as exc:  # noqa: BLE001
                    name = type(exc).__name__
                    if "InvalidToken" in name or "Unauthorized" in str(exc):
                        await ns._net_registry.mark_token_invalid(nid)
                    else:
                        await ns._net_registry.mark_health(
                            nid, "TEMPORARILY_UNAVAILABLE",
                            error_code=f"HEALTH_{name}")
            # V25 §1 CHANNEL-ONLY: the periodic Delivery-Group
            # re-verification + the Mode-A capability refresh are REMOVED
            # from the production health loop — delivery groups are no
            # longer part of the production delivery graph (storage
            # channel → File Delivery Bot → user). No group is verified,
            # degraded or restored in production; the legacy
            # reverify_all_groups stays available as isolated
            # compatibility tooling only (never scheduled here).
    except asyncio.CancelledError:
        pass
    except Exception as exc:  # noqa: BLE001
        ns.logger.error("network health loop crashed: %s", exc)


async def network_shutdown(ns) -> None:
    """post_shutdown hook — stop everything network-owned, isolated."""
    if getattr(ns, "net_health_task", None) is not None:
        ns.net_health_task.cancel()
        try:
            await ns.net_health_task
        except asyncio.CancelledError:
            pass
        ns.net_health_task = None
    if getattr(ns, "_net_delivery_jobs", None) is not None:
        try:
            await ns._net_delivery_jobs.stop()
        except Exception:  # noqa: BLE001
            pass
    if getattr(ns, "_fdb", None) is not None:
        try:
            await ns._fdb.stop()
        except Exception:  # noqa: BLE001
            pass
    if getattr(ns, "_net_broadcast", None) is not None:
        try:
            await ns._net_broadcast.stop_all()
        except Exception:  # noqa: BLE001
            pass
    if getattr(ns, "_net_workers", None) is not None:
        try:
            await ns._net_workers.stop_all()
        except Exception:  # noqa: BLE001
            pass
