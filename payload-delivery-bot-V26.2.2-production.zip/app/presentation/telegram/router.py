"""Centralized callback dispatch registry (ARCHITECTURE PHASE).

The legacy ``on_callback`` chain in bot.py remains the executed dispatcher
for the still-frozen admin namespaces (its branch structure is pinned by the
regression suites). THIS module is the canonical registry every future
extraction registers into: one namespace → one handler, no collisions
(architecture tests assert the table). ``CallbackRouter.dispatch`` is the
single delegation entrypoint for handlers that have been extracted out of
the monolith.
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, Optional

Handler = Callable[..., Awaitable[None]]

# Every user-facing callback namespace (mirrors the pinned tuple in
# bot.py:on_callback — the architecture test asserts they stay in sync).
USER_FACING_PREFIXES: tuple[str, ...] = (
    "verify:", "copy:", "copy_id:", "plcopy:", "rngdl:", "rngbrowse:",
    "rngfile:", "rngmenu:", "rngclose", "start_home",
    "coldl:", "cobrowse:", "cofile:", "comenu:", "coclose", "cocopy:",
    "retrieve:", "help:back", "preview_retrieve",
    "refcheck:", "refhow:", "refwatch:",
    "wad:", "wadcheck:", "wadhow:", "retryfile:",
    "ptunlock:", "npts:", "nreg:", "nbot:",
)

# Feature namespaces handled by extracted modules (populated by
# registration at import time of the owning module).
_REGISTRY: Dict[str, Handler] = {}


def register(prefix: str, handler: Handler) -> None:
    if prefix in _REGISTRY and _REGISTRY[prefix] is not handler:
        raise RuntimeError(
            f"callback namespace collision: {prefix!r} already registered")
    _REGISTRY[prefix] = handler


async def dispatch(update: Any, context: Any, data: str) -> bool:
    """Delegate to the registered handler for `data`'s namespace.

    Returns True when a registered handler took the callback. Unregistered
    namespaces return False so the legacy chain continues to own them.
    """
    for prefix, handler in _REGISTRY.items():
        if data.startswith(prefix):
            await handler(update, context, data)
            return True
    return False


def registered_namespaces() -> tuple[str, ...]:
    return tuple(sorted(_REGISTRY))


def is_user_facing(data: str) -> bool:
    return data.startswith(USER_FACING_PREFIXES)
