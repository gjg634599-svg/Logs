"""Settings & protection — runtime setting getters, Protection V3, panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# SETTINGS HELPERS (runtime toggles, fall back to config)
# ============================================================


# ---------- BOTV13 Phase 3: Progressive Force Join ----------


# BOT6: no global _bot_ref. Every function that needs the bot receives it
# explicitly as a parameter (Access Engine, FJ checks, delivery). This removes
# the hidden global dependency that previously caused 'undefined bot' bugs.


async def auto_delete_active() -> bool:
    return await db.get_setting_bool("auto_delete_enabled", True)



async def auto_reindex_active() -> bool:
    return await db.get_setting_bool("auto_reindex_enabled", True)



async def one_time_default() -> int:
    return 1 if await db.get_setting_bool("one_time_links_default", False) else 0



async def welcome_returning_active() -> bool:
    return await db.get_setting_bool("welcome_returning_enabled", True)



async def analytics_active() -> bool:
    return await db.get_setting_bool("analytics_enabled", ENABLE_ANALYTICS)



async def auto_payload_active() -> bool:
    return await db.get_setting_bool("auto_payload_enabled", ENABLE_AUTO_PAYLOAD)



# ---- Issue 7: Request-to-Join policy setting ----
async def get_join_request_policy() -> str:
    """Return 'request' (ChatJoinRequest grants access) or 'approval' (admin
    must approve). Default: 'request' (Option 1)."""
    val = await db.get_setting("join_request_policy", JOIN_REQUEST_POLICY_REQUEST)
    if val in (JOIN_REQUEST_POLICY_REQUEST, JOIN_REQUEST_POLICY_APPROVAL):
        return val
    return JOIN_REQUEST_POLICY_REQUEST



async def set_join_request_policy(policy: str) -> None:
    if policy not in (JOIN_REQUEST_POLICY_REQUEST, JOIN_REQUEST_POLICY_APPROVAL):
        return
    await db.set_setting("join_request_policy", policy)



async def _prot_v3_get(key: str) -> bool:
    """Get a V3 protection toggle. Returns the default if not set.

    V26 Phase 6: the advanced "One-Time Links Default" toggle reads the
    REAL runtime key (``one_time_links_default`` — the same key the main
    panel's One-Time Links toggle and one_time_default() read). The old
    dead ``prot_v3_one_time_default`` key is never read again — two
    controls, one concept, ONE authoritative key.
    """
    if key == "one_time_default":
        return await db.get_setting_bool("one_time_links_default", False)
    default = PROTECTION_V3_DEFAULTS.get(key, True)
    return await db.get_setting_bool(f"prot_v3_{key}", default)



async def _prot_v3_set(key: str, value: bool) -> None:
    """Set a V3 protection toggle. The advanced one-time-default toggle
    writes the REAL runtime key (see _prot_v3_get)."""
    if key == "one_time_default":
        await db.set_setting("one_time_links_default",
                             "1" if value else "0")
        return
    await db.set_setting(f"prot_v3_{key}", "1" if value else "0")



async def resolve_protection_settings() -> Dict[str, Any]:
    """Protection Engine V3 — the ONE function all delivery routes call.

    Issue #41: Simplified. ONE protection toggle controls everything.
    Issue #42: Renamed to "forward_blocking" for clarity. When ON,
    protect_content=True for ALL user deliveries (single files, collections,
    albums, browse, download all, search, one-time, direct, payload links).
    When OFF, protect_content=False (users can forward/save/share normally).

    Returns:
        {
            "forward_blocking": bool,   # Issue #42: explicit forward blocking
            "protect_content": bool,    # = forward_blocking (all routes)
            "hide_source": bool,        # Hide source channel names
            "hide_internal_refs": bool, # ALWAYS True (not configurable)
            "auto_delete_seconds": int, # Global auto-delete timer
            "watermark": bool,          # Advanced: watermark
            "watermark_text": str,      # Advanced: watermark text
            "anti_leech": bool,         # Advanced: rate limiting
            "one_time_default": bool,   # Advanced: new links one-time
            "preview_protection": bool, # Advanced: protect admin previews
            "debug_logging": bool,      # Advanced: debug logs
        }
    """
    forward_blocking = await _prot_v3_get("forward_blocking")
    internal_bot_msgs = await _prot_v3_get("internal_bot_messages")
    hide_source = await _prot_v3_get("hide_source")
    # Advanced settings
    watermark = await _prot_v3_get("watermark")
    anti_leech = await _prot_v3_get("anti_leech")
    one_time_default = await _prot_v3_get("one_time_default")
    preview_prot = await _prot_v3_get("preview_protection")
    debug_logging = await _prot_v3_get("debug_logging")
    watermark_text = await db.get_setting("prot_v3_watermark_text") or ""
    auto_delete = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
    result = {
        "forward_blocking": forward_blocking,
        # protect_content = forward_blocking — applies to ALL file delivery routes
        "protect_content": forward_blocking,
        # Issue #43: internal_bot_messages controls bot-generated messages only
        "internal_bot_messages": internal_bot_msgs,
        "internal_protect_content": internal_bot_msgs,
        "hide_source": hide_source,
        # Issue #41: hide_internal_refs is ALWAYS True — not configurable
        "hide_internal_refs": True,
        "auto_delete_seconds": int(auto_delete) if auto_delete else 0,
        "watermark": watermark,
        "watermark_text": watermark_text,
        "anti_leech": anti_leech,
        "one_time_default": one_time_default,
        "preview_protection": preview_prot,
        "debug_logging": debug_logging,
    }
    if debug_logging:
        logger.debug("PROTECT V3: %s", result)
    return result



# ---- Backward-compat wrappers (old code still calls these) ----
# These delegate to the V3 engine so old call sites get the new behavior.

async def protect_requested_active() -> bool:
    """Backward compat -> forward_blocking."""
    return await _prot_v3_get("forward_blocking")



async def protect_internal_active() -> bool:
    """Backward compat -> internal_bot_messages (Issue #43).
    Controls protect_content for bot-generated messages (menus, notifications, etc).
    Does NOT affect file delivery — that's controlled by forward_blocking."""
    return await _prot_v3_get("internal_bot_messages")



async def hide_delivery_source_active() -> bool:
    """Backward compat -> hide_source (channel names/usernames)."""
    return await _prot_v3_get("hide_source")



async def allow_forward_requested_active() -> bool:
    """Backward compat -> NOT forward_blocking (inverted for old logic)."""
    return not await _prot_v3_get("forward_blocking")



async def watermark_active() -> bool:
    """Backward compat -> watermark (advanced)."""
    return await _prot_v3_get("watermark")



async def protect_random_active() -> bool:
    """DEPRECATED: Random Media Protection removed. No-op stub."""
    return False



async def resolve_delivery_protection(payload_row: Optional[aiosqlite.Row] = None) -> bool:
    """Backward compat — delegates to resolve_protection_settings().

    Returns the protect_content flag for delivery. All delivery routes
    should ideally call resolve_protection_settings() directly, but this
    wrapper keeps old code working.

    BOTV13 Phase 4: when a payload_row is provided, resolves the per-payload
    forward_blocking override (NULL = inherit global, 1 = ON, 0 = OFF).
    This is THE single effective-protection resolver — every delivery path
    that sends files must call this with the payload_row to get the correct
    protect_content value.
    """
    settings = await resolve_protection_settings()
    global_protect = settings["protect_content"]
    if payload_row is None:
        return global_protect
    # Per-payload three-state forward_blocking.
    fb = payload_row["forward_blocking"] if "forward_blocking" in payload_row.keys() else None
    if fb is None:
        return global_protect  # inherit global
    return bool(fb)  # explicit ON (1) or OFF (0)



# ---- Delivery message settings (no hardcoded delivery text in code) ----
async def delivery_message_active() -> bool:
    return await db.get_setting_bool("delivery_message_enabled", True)



async def get_delivery_message_text() -> str:
    return await db.get_setting("delivery_message_text") or (
        "\u2705 {filename} delivered successfully.\n\n"
        "\u26A0\uFE0F Save or forward this file now.\n"
        "\U0001F551 This file may be removed automatically."
    )



async def get_collection_delivery_message_text() -> str:
    return await db.get_setting("collection_delivery_message_text") or (
        "\u2705 {count} files delivered successfully.\n\n"
        "\u26A0\uFE0F Save important files.\n"
        "\U0001F551 Files may be removed automatically."
    )



async def get_delivery_message_buttons() -> Optional[InlineKeyboardMarkup]:
    return build_start_buttons(await db.get_setting("delivery_message_buttons"))



def _format_delivery_text(template: str, filename: str = "",
                          filesize: str = "", count: int = 0) -> str:
    """Substitute {filename}, {filesize}, {count} placeholders."""
    return (template
            .replace("{filename}", filename or "File")
            .replace("{filesize}", filesize or "-")
            .replace("{count}", str(count)))



async def resolve_delete_after(row: aiosqlite.Row) -> int:
    """Per-payload delete_after overrides the global default.
    NULL -> inherit global default. 0 -> never. >0 -> that many seconds.
    """
    da = row["delete_after"] if "delete_after" in row.keys() else None
    if da is not None:
        return int(da)
    return await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)



async def resolve_preview_timer(payload_id: Optional[int] = None,
                                 trace_id: Optional[str] = None) -> int:
    """GLOBAL PREVIEW TIMER ONLY. Reads preview_auto_delete. NEVER reads
    payload.delete_after or auto_delete_default. Logs BOT6_TIMER_RUNTIME +
    BOT6_PREVIEW_RUNTIME so the timer path is reconstructable."""
    delay = await db.get_setting_int("preview_auto_delete", GLOBAL_PREVIEW_TIMER_DEFAULT)
    if delay < 0:
        delay = GLOBAL_PREVIEW_TIMER_DEFAULT
    delivery_default = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
    logger.info(
        "BOT6_TIMER_RUNTIME trace_id=%s timer_type=preview effective_timer=%s "
        "source=global_preview payload_id=%s scheduler=preview_auto_delete",
        trace_id or "-", delay, payload_id if payload_id is not None else "-",
    )
    logger.info(
        "BOT6_PREVIEW_RUNTIME source=global_preview preview_timer=%s delivery_timer=%s (independent)",
        delay, delivery_default,
    )
    return delay



async def resolve_delivery_timer(payload_row: Optional[aiosqlite.Row],
                                  trace_id: Optional[str] = None) -> int:
    """EFFECTIVE PAYLOAD DELIVERY TIMER. payload.delete_after if set, else global.
    Logs BOT6_TIMER_RUNTIME with timer_type=delivery."""
    _pid = None
    if payload_row is not None:
        _pid = payload_row["id"] if "id" in payload_row.keys() else None
        da = payload_row["delete_after"] if "delete_after" in payload_row.keys() else None
        if da is not None:
            delay = int(da)
            logger.info(
                "BOT6_TIMER_RUNTIME trace_id=%s timer_type=delivery effective_timer=%s "
                "source=per_payload payload_id=%s scheduler=schedule_auto_delete",
                trace_id or "-", delay, _pid if _pid is not None else "-",
            )
            return delay
    delay = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
    logger.info(
        "BOT6_TIMER_RUNTIME trace_id=%s timer_type=delivery effective_timer=%s "
        "source=inherited_global payload_id=%s scheduler=schedule_auto_delete",
        trace_id or "-", delay, _pid if _pid is not None else "-",
    )
    return delay



async def resolve_retrieve_timer(payload_row: Optional[aiosqlite.Row],
                                  trace_id: Optional[str] = None) -> int:
    """Retrieve uses the SAME effective timer as delivery. Delegates to
    resolve_delivery_timer. NEVER calls resolve_preview_timer."""
    delay = await resolve_delivery_timer(payload_row, trace_id=trace_id)
    logger.info("BOT6_RETRIEVE_TIMER trace_id=%s effective_timer=%s",
                trace_id or "-", delay if delay > 0 else "never")
    return delay



# ============================================================
# PROTECTION PANEL  (merged from old bot's stable implementation)
# ============================================================
def _prot_state_label(on: bool) -> str:
    """Live colored state: green dot ON / red dot OFF."""
    return "\U0001F7E2 ON" if on else "\U0001F534 OFF"



async def protection_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Protection Center V3 — simplified, impossible to misconfigure.

    Issue #41: ONE protection toggle controls everything. No route-specific
    switches. No conflicts. Fits on one screen.
    Issue #42: Renamed "Protection" to "Forward Blocking" for clarity.
    Issue #43: Added "Internal Bot Messages" toggle. Fixed panel not opening
    by using safe_edit_text + try/except + debug logging + fail-safe.

    Menu:
      🛡 Protection Center
      📤 Forward Blocking
      🔒 Internal Bot Messages
      🙈 Hide Source
      🕒 Auto Delete
      ⚙ Advanced Settings
    """
    logger.debug("Protection panel: opening (user=%s)", update.effective_user.id if update.effective_user else "?")
    try:
        s = await resolve_protection_settings()
        fb_on = s["forward_blocking"]
        ibm_on = s["internal_bot_messages"]
        hide_src = s["hide_source"]
        auto_del = s["auto_delete_seconds"]
        auto_del_label = "OFF" if auto_del == 0 else f"{auto_del}s"
        fb_icon = "\U0001F7E2" if fb_on else "\U0001F534"
        ibm_icon = "\U0001F7E2" if ibm_on else "\U0001F534"
        src_icon = "\U0001F7E2" if hide_src else "\U0001F534"
        lines = [
            f"*\U0001F6E1 Protection Center*", "",
            f"{fb_icon} Forward Blocking: {'ON' if fb_on else 'OFF'}",
            f"{ibm_icon} Internal Bot Messages: {'ON' if ibm_on else 'OFF'}",
            f"{src_icon} Hide Source: {'ON' if hide_src else 'OFF'}",
            f"\U0001F551 Auto Delete: {auto_del_label}",
            f"\U0001F512 Internal IDs: Always Hidden",
            "",
            "Forward Blocking: protects delivered files.",
            "Internal Bot Messages: protects bot menus/notifications.",
        ]
        kb_rows: List[List[InlineKeyboardButton]] = [
            [InlineKeyboardButton(
                f"\U0001F4E4 Forward Blocking: {'ON' if fb_on else 'OFF'}",
                callback_data="prot3:forward_blocking",
            )],
            [InlineKeyboardButton(
                f"\U0001F512 Internal Bot Messages: {'ON' if ibm_on else 'OFF'}",
                callback_data="prot3:internal_bot_messages",
            )],
            [InlineKeyboardButton(
                f"{src_icon} Hide Source: {'ON' if hide_src else 'OFF'}",
                callback_data="prot3:hide_source",
            )],
            [InlineKeyboardButton(
                f"\U0001F551 Auto Delete: {auto_del_label}",
                callback_data="prot3:autodelete",
            )],
            [InlineKeyboardButton("\u2699 Advanced Settings",
                                  callback_data="prot3:advanced")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
        ]
        logger.debug("Protection panel: rendered, forwarding to edit_message_text")
        # Issue #43: use safe_edit_text instead of direct edit_message_text
        # so Markdown parse failures don't crash the panel.
        await safe_edit_text(update.callback_query, "\n".join(lines),
                             parse_mode=ParseMode.MARKDOWN,
                             reply_markup=InlineKeyboardMarkup(kb_rows))
        logger.debug("Protection panel: opened successfully")
    except Exception as e:
        logger.error("Protection panel: FAILED to open: %s", e, exc_info=True)
        # Issue #43: fail-safe — show an error instead of silently doing nothing.
        try:
            await safe_answer_callback(update.callback_query,
                                       "\u274C Unable to load Protection Center.",
                                       show_alert=True)
        except Exception:
            pass



async def protection_preview_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show how files will be delivered under current V3 settings."""
    s = await resolve_protection_settings()
    auto_del = s["auto_delete_seconds"]
    auto_del_label = "OFF" if auto_del == 0 else f"{auto_del}s"
    lines = [
        "*\U0001F441 Protection Preview*", "",
        "Here is how files will be delivered:", "",
        f"\U0001F4E4 Forward Blocking: {'ON' if s['forward_blocking'] else 'OFF'}",
        f"\U0001F512 protect_content (files): {'True' if s['protect_content'] else 'False'}",
        f"\U0001F512 Internal Bot Messages: {'ON' if s['internal_bot_messages'] else 'OFF'}",
        f"\U0001F648 Source hidden: {'Yes' if s['hide_source'] else 'No'}",
        f"\U0001F512 Internal IDs: Always Hidden",
        f"\U0001F551 Auto Delete: {auto_del_label}",
    ]
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:protection")]]
    )
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def toggle_protection(update: Update, context: ContextTypes.DEFAULT_TYPE, key: str) -> None:
    """Old toggle handler — maps old keys to V3 for backward compat."""
    old_to_v3 = {
        "protect_requested": "forward_blocking",
        "protect_internal_msgs": "forward_blocking",
        "hide_delivery_source": "hide_source",
        "allow_fwd_requested": None,  # inverted
        "watermark_enabled": "watermark",
    }
    v3_key = old_to_v3.get(key)
    if v3_key:
        cur = await _prot_v3_get(v3_key)
        await _prot_v3_set(v3_key, not cur)
    elif key == "allow_fwd_requested":
        # Inverted: allow_fwd ON = forward_blocking OFF
        cur = await _prot_v3_get("forward_blocking")
        await _prot_v3_set("forward_blocking", not cur)
    await protection_panel(update, context)



async def toggle_protection_v3(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                key: str) -> None:
    """V3 toggle handler — toggles a V3 protection setting."""
    if key == "autodelete":
        # Cycle through auto-delete presets.
        await cycle_delete_timer(update, context)
        await protection_panel(update, context)
        return
    if key == "advanced":
        await protection_advanced_panel(update, context)
        return
    if key in PROTECTION_V3_KEYS:
        cur = await _prot_v3_get(key)
        await _prot_v3_set(key, not cur)
        logger.info("Protection V3 toggle: %s -> %s", key, not cur)
    await protection_panel(update, context)



async def protection_advanced_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Advanced Settings sub-panel — expert options only.

    Issue #41: Only expert options here (Watermark, Anti-Leech, One-Time,
    Preview Protection, Debug). No route-specific toggles.
    """
    s = await resolve_protection_settings()
    adv_items = [
        ("watermark",          "\U0001F3A8 Watermark"),
        ("anti_leech",         "\U0001F9DE Anti-Leech"),
        ("one_time_default",   "\U0001F517 One-Time Links Default"),
        ("preview_protection", "\U0001F441 Preview Protection"),
        ("debug_logging",      "\U0001F41E Debug Logging"),
    ]
    lines = ["*\u2699 Advanced Settings*", ""]
    lines.append("Expert options (hidden from normal workflow):")
    for k, label in adv_items:
        on = s.get(k, False)
        icon = "\U0001F7E2" if on else "\U0001F534"
        lines.append(f"  {icon} {label}: {'ON' if on else 'OFF'}")
    lines.append("")
    lines.append("Tap to toggle:")
    kb_rows: List[List[InlineKeyboardButton]] = []
    for k, label in adv_items:
        on = s.get(k, False)
        icon = "\U0001F7E2" if on else "\U0001F534"
        short = label.split(" ", 1)[0]
        kb_rows.append([InlineKeyboardButton(
            f"{icon} {short}",
            callback_data=f"prot3:adv:{k}",
        )])
    kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:protection")])
    await safe_edit_text(update.callback_query, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(kb_rows)
    )



async def toggle_protection_advanced(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                     key: str) -> None:
    """Toggle an advanced V3 protection setting."""
    if key in PROTECTION_V3_ADVANCED_KEYS:
        cur = await _prot_v3_get(key)
        await _prot_v3_set(key, not cur)
        logger.info("Protection V3 advanced toggle: %s -> %s", key, not cur)
    await protection_advanced_panel(update, context)



# ---------- START MESSAGE PANEL ----------
async def show_startmsg_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    variant = context.user_data.get("sm_variant", "first")
    row = await db.get_start_message(variant)
    if row:
        mt = row["message_type"] or "text"
        cap_preview = (row["caption"] or "(no text)")[:60]
        has_buttons = bool(row["buttons_json"] and row["buttons_json"] != "[]")
    else:
        mt = "none"
        cap_preview = "(not set)"
        has_buttons = False
    text = (
        "*\U0001F3AD Start Message Builder*\n\n"
        f"*Editing:* {variant.title()}\n"
        f"*Current welcome message:*\n"
        f"  Type: {mt}\n"
        f"  Text: {cap_preview}\n"
        f"  Buttons: {'yes' if has_buttons else 'no'}"
    )
    has_media = mt not in ("none", "text") and row and row["file_id"]
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u270F\uFE0F Edit Text", callback_data="sm:edittext"),
         InlineKeyboardButton("\U0001F5BC Edit Media", callback_data="sm:media")],
        [InlineKeyboardButton("\U0001F518 Edit Buttons", callback_data="sm:buttons"),
         InlineKeyboardButton("\U0001F441 Preview", callback_data="sm:preview")],
        [InlineKeyboardButton("\u274C Remove Media", callback_data="sm:remmedia"),
         InlineKeyboardButton("\U0001F504 Reset", callback_data="sm:reset")],
        [InlineKeyboardButton(f"\U0001F501 Switch to {'Returning' if variant == 'first' else 'First'}",
                              callback_data="sm:switch")],
        [InlineKeyboardButton("\U0001F4E6 Delivery Message", callback_data="panel:deliverymsg")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query, 
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



# ---------- DELIVERY MESSAGE BUILDER ----------
async def delivery_message_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Builder for the configurable delivery / collection delivery messages."""
    enabled = await delivery_message_active()
    text_preview = (await get_delivery_message_text())[:80]
    coll_preview = (await get_collection_delivery_message_text())[:80]
    state_label = "\U0001F7E2 Enabled" if enabled else "\U0001F534 Disabled"
    text = (
        "*\U0001F4E6 Delivery Message Builder*\n\n"
        f"*Enabled state:* {state_label}\n\n"
        f"*Current delivery text:*\n  {text_preview}\n\n"
        f"*Current collection text:*\n  {coll_preview}\n\n"
        "Placeholders: `{filename}`, `{filesize}`, `{count}`"
    )
    toggle_icon = "\U0001F534" if enabled else "\U0001F7E2"
    toggle_label = "Disable" if enabled else "Enable"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u270F\uFE0F Edit Delivery Text", callback_data="dm:editsingle"),
         InlineKeyboardButton("\U0001F4E6 Edit Collection Text", callback_data="dm:editcoll")],
        [InlineKeyboardButton("\U0001F518 Edit Buttons", callback_data="dm:editbuttons"),
         InlineKeyboardButton("\U0001F441 Preview", callback_data="dm:preview")],
        [InlineKeyboardButton(f"{toggle_icon} {toggle_label}", callback_data="dm:toggle"),
         InlineKeyboardButton("\U0001F504 Reset", callback_data="dm:reset")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:startmsg")],
    ])
    await safe_edit_text(update.callback_query, 
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



# ---------- SETTINGS PANEL ----------
async def settings_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    ad = await auto_delete_active()
    ar = await auto_reindex_active()
    ot = bool(await one_time_default())
    fj = await force_join_active()
    wr = await welcome_returning_active()
    jr_policy = await get_join_request_policy()
    ad_default = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
    ad_default_label = "never" if ad_default == 0 else f"{ad_default}s"
    jr_label = "Request = Access" if jr_policy == JOIN_REQUEST_POLICY_REQUEST else "Approval = Access"
    # BOT7: show the REAL admin roster (DB admins table incl. owner), not just
    # the env-configured ADMIN_IDS list.
    try:
        _cur = await db.conn.execute("SELECT COUNT(*) AS c FROM admins WHERE is_active = 1")
        _r = await _cur.fetchone()
        _admin_count = int(_r["c"]) if _r else len(ADMIN_IDS)
    except Exception:  # noqa: BLE001
        _admin_count = len(ADMIN_IDS)
    text = (
        "*\u2699\uFE0F Settings*\n\n"
        f"\u23F0 Auto Delete: {'ON' if ad else 'OFF'} (default {ad_default_label})\n"
        f"\u26A1 Auto Reindex: {'ON' if ar else 'OFF'} (every {AUTO_REINDEX_INTERVAL}s)\n"
        f"\U0001F501 One Time Links (default): {'ON' if ot else 'OFF'}\n"
        f"\U0001F4E2 Force Join: {'ON' if fj else 'OFF'}\n"
        f"\U0001F3AD Welcome Returning: {'ON' if wr else 'OFF'}\n"
        f"\U0001F4CA Analytics: {'ON' if await analytics_active() else 'OFF'}\n"
        f"\U0001F517 Auto Payload: {'ON' if await auto_payload_active() else 'OFF'}\n"
        f"\U0001F500 Request-To-Join Policy: {jr_label}\n"
        f"\U0001F465 Active Admins: {_admin_count} (manage via \U0001F451 Admin Dashboard)\n"
    )
    # WATCH_AD (v25): global configuration summary + entry button.
    try:
        _wad_cfg = await get_watch_ads_global_config()
        _wad_stats = await db.watch_ad_global_stats()
        _url_ico = "✅" if _wad_cfg.get("url_ok") else "❌"
        _sdk_ico = "✅" if _wad_cfg.get("sdk_ok") else "❌"
        _payload_count = _wad_stats.get("payloads_enabled", 0)
        _wad_line = (
            f"🎬 Watch Ads: URL {_url_ico} "
            f"SDK {_sdk_ico} "
            f"({_payload_count} payload(s))"
        )
    except Exception:  # noqa: BLE001
        _wad_line = "🎬 Watch Ads: —"
    text += f"{_wad_line}\n"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"\u23F0 Auto Delete: {'ON' if ad else 'OFF'}", callback_data="set:toggle:auto_delete_enabled"),
         InlineKeyboardButton(f"Default {ad_default_label}", callback_data="set:timer")],
        [InlineKeyboardButton(f"\u26A1 Auto Reindex: {'ON' if ar else 'OFF'}", callback_data="set:toggle:auto_reindex_enabled")],
        [InlineKeyboardButton(f"\U0001F501 One Time Links: {'ON' if ot else 'OFF'}", callback_data="set:toggle:one_time_links_default")],
        [InlineKeyboardButton(f"\U0001F4E2 Force Join: {'ON' if fj else 'OFF'}", callback_data="set:toggle:force_join_enabled")],
        [InlineKeyboardButton(f"\U0001F3AD Welcome Returning: {'ON' if wr else 'OFF'}", callback_data="set:toggle:welcome_returning_enabled")],
        [InlineKeyboardButton(f"\U0001F517 Auto Payload: {'ON' if await auto_payload_active() else 'OFF'}", callback_data="set:toggle:auto_payload_enabled")],
        [InlineKeyboardButton(f"\U0001F4CA Analytics: {'ON' if await analytics_active() else 'OFF'}", callback_data="set:toggle:analytics_enabled")],
        [InlineKeyboardButton(f"\U0001F500 Request-To-Join: {jr_label}", callback_data="set:jrpolicy")],
        [InlineKeyboardButton("\U0001F3AC Watch Ads Settings", callback_data="panel:wadsettings")],
        [InlineKeyboardButton("\U0001F4E2 Force-Join Channels", callback_data="panel:fj")],
        [InlineKeyboardButton("\U0001F4E5 Retrieve System", callback_data="panel:retrieve")],
        [InlineKeyboardButton("\U0001F4BE Backup Database", callback_data="backup:db")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query, 
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def toggle_setting(update: Update, context: ContextTypes.DEFAULT_TYPE, key: str) -> None:
    cur = await db.get_setting_bool(key, False)
    await db.set_setting(key, "0" if cur else "1")
    await settings_panel(update, context)



async def cycle_delete_timer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cur = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
    options = [20, 30, 60, 120, 300, 0]
    try:
        idx = options.index(cur)
    except ValueError:
        idx = -1
    nxt = options[(idx + 1) % len(options)]
    await db.set_setting("auto_delete_default", str(nxt))
    await settings_panel(update, context)
