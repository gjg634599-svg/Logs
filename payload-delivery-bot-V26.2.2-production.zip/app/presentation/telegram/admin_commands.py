"""Admin CLI commands — @admin_only command handlers.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

from app.presentation.telegram.guards import admin_only



# ============================================================
# ADMIN COMMANDS  (existing + new)
# ============================================================
@admin_only
async def createpayload_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/createpayload INDEX_ID PAYLOAD`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    try:
        index_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "INDEX_ID must be a number.")
        return
    payload = context.args[1].lower()
    if not validate_payload(payload):
        await reply_protected(update, 
            "Invalid payload. Use lowercase letters, digits and underscores only (max 64)."
        )
        return

    file_row = await db.get_indexed_file_by_id(index_id)
    if not file_row:
        await reply_protected(update, f"File #{index_id} not found.")
        return

    if await db.get_payload(payload):
        await reply_protected(update, f"Payload {md_code_span(payload)} already exists.",
                                                  parse_mode=ParseMode.MARKDOWN)
        return

    one_time = await one_time_default()
    await db.create_payload(payload, index_id, status="active", one_time=one_time)
    await send_payload_created_message(update, payload)



@admin_only
async def deletepayload_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/deletepayload PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    payload = context.args[0].lower()
    row = await db.get_payload(payload)
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.delete_payload(row["id"])
    await reply_protected(update, f"\u274C Payload {md_code_span(payload)} deleted.",
                                             parse_mode=ParseMode.MARKDOWN)



@admin_only
async def disablepayload_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/disablepayload PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.update_payload_field(row["id"], "status", "disabled")
    await reply_protected(update, f"\u23F8 Payload {md_code_span(row['payload'])} disabled.",
                                              parse_mode=ParseMode.MARKDOWN)



@admin_only
async def enablepayload_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/enablepayload PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.update_payload_field(row["id"], "status", "active")
    await reply_protected(update, f"\u2705 Payload {md_code_span(row['payload'])} enabled.",
                                              parse_mode=ParseMode.MARKDOWN)



@admin_only
async def payloadinfo_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/payloadinfo PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await send_payload_info(update, row)



@admin_only
async def payloadlist_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.list_payloads(limit=50)
    if not rows:
        await reply_protected(update, "No payloads yet.")
        return
    lines = ["*Payloads (newest first):*", ""]
    for r in rows:
        lines.append(f"\u2022 {md_code_span(r['payload'])}  [{r['status']}]  clicks={r['current_clicks']}")
    await reply_protected(update, 
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN
    )



@admin_only
async def addalias_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/addalias PAYLOAD ALIAS`", parse_mode=ParseMode.MARKDOWN
        )
        return
    payload = context.args[0].lower()
    alias = context.args[1].lower()
    if not validate_payload(alias):
        await reply_protected(update, "Invalid alias format.")
        return
    row = await db.get_payload(payload)
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    if await db.get_payload(alias):
        await reply_protected(update, f"{md_code_span(alias)} is already a payload/alias.",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    ok = await db.add_alias(row["id"], alias)
    if ok:
        await reply_protected(update, 
            f"\u2705 Alias {md_code_span(alias)} -> {md_code_span(row['payload'])} added.",
            parse_mode=ParseMode.MARKDOWN,
        )
    else:
        await reply_protected(update, "Alias already exists.")



@admin_only
async def removealias_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/removealias ALIAS`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    alias = context.args[0].lower()
    ok = await db.remove_alias(alias)
    if ok:
        await reply_protected(update, f"\u274C Alias {md_code_span(alias)} removed.",
                                                 parse_mode=ParseMode.MARKDOWN)
    else:
        await reply_protected(update, "Alias not found.")



@admin_only
async def listaliases_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/listaliases PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    aliases = await db.list_aliases(row["id"])
    if not aliases:
        await reply_protected(update, "No aliases for this payload.")
        return
    lines = [f"*Aliases for {md_code_span(row['payload'])}:*", ""]
    for a in aliases:
        lines.append(f"\u2022 {md_code_span(a['alias'])}")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



@admin_only
async def setpassword_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/setpassword PAYLOAD PASSWORD`", parse_mode=ParseMode.MARKDOWN
        )
        return
    payload = context.args[0].lower()
    password = " ".join(context.args[1:])
    row = await db.get_payload(payload)
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.update_payload_field(row["id"], "password", hash_password(password))
    await reply_protected(update, 
        f"\U0001F510 Password set for {md_code_span(row['payload'])}.",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def removepassword_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/removepassword PAYLOAD`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.update_payload_field(row["id"], "password", None)
    await reply_protected(update, 
        f"\u2705 Password removed from {md_code_span(row['payload'])}.",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def expire_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/expire PAYLOAD YYYY-MM-DD`", parse_mode=ParseMode.MARKDOWN
        )
        return
    payload = context.args[0].lower()
    date_str = context.args[1]
    if not is_valid_date(date_str):
        await reply_protected(update, "Invalid date. Use YYYY-MM-DD (UTC).")
        return
    row = await db.get_payload(payload)
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    expires_at = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc).isoformat()
    await db.update_payload_field(row["id"], "expires_at", expires_at)
    await reply_protected(update, 
        f"\u23F3 {md_code_span(row['payload'])} expires on {date_str} (UTC).",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def maxclicks_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/maxclicks PAYLOAD NUMBER` (0 = unlimited)",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    payload = context.args[0].lower()
    try:
        n = int(context.args[1])
        if n < 0:
            raise ValueError
    except ValueError:
        await reply_protected(update, "NUMBER must be a non-negative integer.")
        return
    row = await db.get_payload(payload)
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    await db.update_payload_field(row["id"], "max_clicks", n)
    label = "unlimited" if n == 0 else str(n)
    await reply_protected(update, 
        f"\u2705 {md_code_span(row['payload'])} max clicks set to {label}.",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def settimer_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/settimer PAYLOAD SECONDS`\n(0=never, -1=inherit global default)",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    try:
        secs = int(context.args[1])
        if secs < -1:
            raise ValueError
    except ValueError:
        await reply_protected(update, "SECONDS must be a non-negative integer (or -1).")
        return
    await db.update_payload_field(row["id"], "delete_after", None if secs == -1 else secs)
    label = "inherit global" if secs == -1 else ("never" if secs == 0 else f"{secs}s")
    await reply_protected(update, 
        f"\u23F0 {md_code_span(row['payload'])} delete timer set to {label}.",
        parse_mode=ParseMode.MARKDOWN,
    )



@admin_only
async def onetime_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) < 2:
        await reply_protected(update, 
            "Usage: `/onetime PAYLOAD on|off`", parse_mode=ParseMode.MARKDOWN
        )
        return
    row = await db.get_payload(context.args[0].lower())
    if not row:
        await reply_protected(update, "Payload not found.")
        return
    flag = context.args[1].lower()
    if flag not in ("on", "off"):
        await reply_protected(update, "Use `on` or `off`.", parse_mode=ParseMode.MARKDOWN)
        return
    await db.update_payload_field(row["id"], "one_time", 1 if flag == "on" else 0)
    await reply_protected(update, 
        f"\u2705 {md_code_span(row['payload'])} one-time link {'enabled' if flag == 'on' else 'disabled'}.",
        parse_mode=ParseMode.MARKDOWN,
    )



# ---- storage channel commands ----
@admin_only
async def addstorage_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, 
            "Usage: `/addstorage CHANNEL_ID [TITLE]`", parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    title = " ".join(context.args[1:]) if len(context.args) > 1 else None
    # Try to fetch chat info for title/username.
    try:
        chat = await context.bot.get_chat(channel_id)
        if not title:
            title = chat.title
    except TelegramError as e:
        logger.warning("get_chat failed for storage channel %s: %s", channel_id, e)
    ok = await db.add_storage_channel(channel_id, title, None)
    if ok:
        await reply_protected(update, 
            f"\u2705 Storage channel {channel_id} added." + (f" ({title})" if title else "")
        )
    else:
        await reply_protected(update, "That channel is already registered.")



@admin_only
async def removestorage_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/removestorage CHANNEL_ID`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    ok = await db.remove_storage_channel(channel_id)
    await reply_protected(update, "\u2705 Removed." if ok else "Channel not found.")



@admin_only
async def enablestorage_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/enablestorage CHANNEL_ID`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    await db.set_storage_channel_active(channel_id, 1)
    await reply_protected(update, f"\u2705 Storage channel {channel_id} enabled.")



@admin_only
async def disablestorage_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/disablestorage CHANNEL_ID`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    await db.set_storage_channel_active(channel_id, 0)
    await reply_protected(update, f"\u23F8 Storage channel {channel_id} disabled.")



@admin_only
async def liststorage_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    channels = await db.list_storage_channels()
    if not channels:
        await reply_protected(update, "No storage channels configured.")
        return
    lines = ["*Storage Channels*", ""]
    for ch in channels:
        status = "\u2705" if ch["is_active"] else "\u23F8"
        lines.append(f"{status} {ch['channel_id']}  {ch['title'] or ''}  "
                     f"(files scanned: last {ch['last_scan'] or '-'})")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



# ---- force-join channel commands ----
@admin_only
async def addchannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, 
            "Usage: `/addchannel CHANNEL_ID [NAME]`", parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    name = " ".join(context.args[1:]) if len(context.args) > 1 else None
    ok = await db.add_force_channel(channel_id, name, title=name)
    if ok:
        await reply_protected(update, 
            f"\u2705 Force-join channel {channel_id} added."
        )
    else:
        await reply_protected(update, "That channel is already in the list.")



@admin_only
async def removechannel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, "Usage: `/removechannel CHANNEL_ID`",
                                                  parse_mode=ParseMode.MARKDOWN)
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    ok = await db.remove_force_channel(channel_id)
    await reply_protected(update, 
        "\u2705 Removed." if ok else "Channel not found."
    )



@admin_only
async def listchannels_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    channels = await db.list_force_channels()
    if not channels:
        await reply_protected(update, "No force-join channels configured.")
        return
    lines = ["*Force-join channels:*", ""]
    for ch in channels:
        label = _force_channel_label(ch)
        lines.append(f"\u2022 {ch['channel_id']}  {label}")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



# ---- start message command ----
@admin_only
async def startmsg_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data["sm_variant"] = "first"
    await show_startmsg_panel(update, context)



# ---- Issue 25: /forcejoin command opens the GUI Force-Join panel ----
@admin_only
async def forcejoin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Open the Force-Join panel (GUI-driven: Add/List/Edit/Remove)."""
    clear_wizard_states(context)
    # Send a fresh panel message (command, not callback).
    channels = await db.list_force_channels()
    text = (
        "\U0001F4E2 Force-Join Channels\n\n"
        f"Configured: {len(channels)}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2795 Add Channel", callback_data="fj:add"),
         InlineKeyboardButton("\U0001F4CB List Channels", callback_data="fj:list")],
        [InlineKeyboardButton("\u270F\uFE0F Edit Channel", callback_data="fj:editpick"),
         InlineKeyboardButton("\U0001F5D1 Remove Channel", callback_data="fj:rempick")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:settings")],
    ])
    await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



# ---- Issue #80: System Verification Command ----
@admin_only
async def admin_verify_system(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/admin_verify_system — comprehensive system health check.

    Checks: Force Join, Invite Links, Payloads, Collections, Branding,
    Recovery Records, Index Integrity, Retrieve System.
    """
    lines = ["*\U0001F50D System Verification Report*", ""]
    overall = "PASS"
    # 1. Force Join — PHASE 6 §9: three-state (valid / invalid / unverified);
    # a transient Telegram failure is NOT a failure of the configuration.
    fj_channels = await db.list_force_channels()
    fj_ok = True
    fj_unverified = 0
    for ch in fj_channels:
        valid = await _check_force_channel_valid(context.bot, ch["channel_id"])
        if valid is False:
            fj_ok = False
            break
        if valid is None:
            fj_unverified += 1
    if not fj_ok:
        fj_line = "\u26A0 WARNING \u2014 invalid channels"
        overall = "WARNING"
    elif fj_unverified:
        fj_line = (f"\u26A0 OK \u2014 {fj_unverified} channel(s) unverified "
                   "(Telegram rate limit, not invalid)")
    else:
        fj_line = "\u2705 PASS"
    lines.append(f"Force Join: {fj_line} ({len(fj_channels)} channels)")
    # 2. Invite Links
    invite_ok = True
    for ch in fj_channels:
        link = await db.get_force_invite_link(ch["channel_id"])
        if not link:
            invite_ok = False
            break
    lines.append(f"Invite Links: {'✅ PASS' if invite_ok else '⚠ WARNING — missing links'}")
    # 3. Payloads
    payload_count = await db.count_payloads()
    lines.append(f"Payloads: ✅ PASS ({payload_count} payloads)")
    # 4. Collections
    # FINAL-1 (honesty fix): the Collections line ALWAYS printed PASS
    # regardless of the actual count (a placeholder from the original
    # extraction). It now reports the real number (a zero is a zero, not
    # a PASS).
    coll_count = await db.count_pending_deletions()
    lines.append(f"Collections: ✅ OK ({coll_count} pending deletions)")
    # 5. Recovery Records
    rec_count = await db.get_stat("retrieve_success", 0)
    rec_fail = await db.get_stat("retrieve_failure", 0)
    lines.append(f"Retrieve System: ✅ PASS (success={rec_count}, failures={rec_fail})")
    # 6. Index Integrity
    channels = await db.list_storage_channels()
    idx_ok = True
    for ch in channels:
        indexed = await db.count_indexed_files_for_channel(ch["channel_id"])
        if indexed == 0 and ch["is_active"]:
            idx_ok = False
    lines.append(f"Index Integrity: {'✅ PASS' if idx_ok else '⚠ WARNING — empty active channels'} ({len(channels)} channels)")
    if not idx_ok:
        overall = "WARNING"
    # 7. Broadcast
    stale = await db.fix_stale_processing_broadcasts()
    lines.append(f"Broadcast: ✅ PASS (stale fixed={stale})")
    lines.append("")
    lines.append(f"*Overall: {overall}*")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



# ---- analytics ----
@admin_only
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    g = await db.global_view_stats()
    users = await db.total_users()
    files = await db.count_indexed_files()
    payloads = await db.count_payloads()
    storage = await db.list_storage_channels(active_only=True)
    text = (
        "*Global Statistics*\n\n"
        f"\U0001F4C1 Indexed files: {files}\n"
        f"\U0001F517 Payloads: {payloads}\n"
        f"\U0001F4C2 Active storage channels: {len(storage)}\n"
        f"\U0001F465 Users: {users}\n\n"
        f"\U0001F4CA Clicks (all payloads)\n"
        f"  Total: {g['total']}\n"
        f"  Unique users: {g['unique']}\n"
        f"  Today: {g['daily']}\n"
        f"  This week: {g['weekly']}\n"
        f"  This month: {g['monthly']}\n\n"
        f"\U0001F4E5 Downloads by type\n"
        f"  Payload: {await db.get_stat('payload_downloads', 0)}\n"
        f"  Message-ID: {await db.get_stat('msgid_downloads', 0)}\n"
        f"  Range: {await db.get_stat('range_downloads', 0)}\n\n"
        f"\U0001F4E3 Broadcasts sent: {await db.get_stat('broadcast_count', 0)}\n"
    )
    await reply_protected(update, text, parse_mode=ParseMode.MARKDOWN)



@admin_only
async def toppayloads_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = await db.top_payloads(limit=10)
    if not rows:
        await reply_protected(update, "No payload clicks recorded yet.")
        return
    lines = ["*Top Payloads*", ""]
    for i, r in enumerate(rows, 1):
        lines.append(f"{i}. {md_code_span(r['payload'])} - clicks={r['current_clicks']}  views={r['views']}")
    await reply_protected(update, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)



# ---- recent files ----
@admin_only
async def recentfiles_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await send_recent_files_panel(update, limit=10)



# ---- /recent (USER-FACING, 24h rolling window, max 4, payload names) ----
async def recent_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """User-facing /recent — show recent payloads (24h, max 4, payload names).

    Logs BOT6_RECENT_OPEN + BOT6_RECENT_RESULT so the /recent journey is
    reconstructable from logs."""
    import uuid as _uuid
    _trace_id = _uuid.uuid4().hex[:12]
    user = update.effective_user
    if not user:
        return
    chat_type = update.effective_chat.type if update.effective_chat else None
    if chat_type in ("group", "supergroup"):
        return
    logger.info("BOT6_RECENT_OPEN trace_id=%s user_id=%s", _trace_id, user.id)
    if not rate_limiter.check(user.id):
        await reply_protected(update, "⏳ Please wait a minute and try again.")
        logger.info("BOT6_RECENT_RESULT trace_id=%s result=rate_limited user_id=%s",
                    _trace_id, user.id)
        return
    await db.upsert_user(user.id, user.username, user.first_name)
    records = await db.get_recent_payload_deliveries_24h(user.id, limit=4)
    if not records:
        await reply_protected(update,
            "📁 Recent Files\n\nNo recent payloads in the last 24 hours.\n\n"
            "Open a delivery link to receive a payload — it will appear here "
            "for 24 hours so you can retrieve it if it was auto-deleted.")
        logger.info("BOT6_RECENT_RESULT trace_id=%s result=empty user_id=%s",
                    _trace_id, user.id)
        return
    lines = ["📁 Recent Files", ""]
    buttons = []
    shown = 0
    for rec in records:
        pcode = rec["payload_code"] or ""
        display_name = ""
        try:
            # V26 (message-872 identity fix): the CANONICAL predicates — a
            # payload named 'clip…'/'movie…' resolves to its REAL payload
            # name (the naive startswith rendered it as a phantom
            # Collection / File row in the retrieve list).
            if is_collection_link(pcode):
                code = rec["collection_code"] or parse_collection_link(pcode)
                items = await db.get_collection_items(code)
                display_name = f"Collection ({len(items)} files)" if items else "Collection"
            elif is_msg_link(pcode):
                display_name = "File"
            else:
                prow = await db.get_payload(pcode)
                if prow:
                    display_name = get_payload_display_name(
                        prow["payload"] if "payload" in prow.keys() else "",
                        display_name=_safe_row_get(prow, "display_name"))
                else:
                    display_name = get_payload_display_name(pcode)
        except Exception:
            display_name = get_payload_display_name(pcode) or "Payload"
        if not display_name:
            display_name = "Payload"
        shown += 1
        lines.append(f"{shown}. 📦 {truncate(display_name, 50)}")
        buttons.append([InlineKeyboardButton(
            "🔄 Retrieve", callback_data=f"retrieve:{rec['id']}")])
    lines.append("")
    lines.append("Tap 🔄 Retrieve to re-receive a payload. Access policy is re-checked.")
    kb = InlineKeyboardMarkup(buttons) if buttons else None
    await reply_protected(update, "\n".join(lines), reply_markup=kb)
    logger.info("BOT6_RECENT_RESULT trace_id=%s result=shown count=%s user_id=%s",
                _trace_id, shown, user.id)



# ---- /link MESSAGE_ID (direct link generator) ----
@admin_only
async def link_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, 
            "Usage: `/link MESSAGE_ID`", parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        message_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "MESSAGE_ID must be a number.")
        return
    file_row = await db.get_indexed_file_by_message_id(message_id)
    if not file_row:
        await reply_protected(update, 
            f"No indexed file found for message_id {md_code_span(message_id)}.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return
    link = build_msg_link(message_id)
    text = (
        f"*\U0001F517 Direct Link*\n\n"
        f"*Message ID:* {md_code_span(message_id)}\n"
        f"*File:* {md_code_span(file_row['file_name'])}\n\n"
        f"{md_code_span(link)}"
    )
    kb = InlineKeyboardMarkup(
        [[InlineKeyboardButton("\U0001F4CB Copy Link", callback_data=f"mlinkcopy:{message_id}")]]
    )
    await reply_protected(update, text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



# ---- reindex ----
@admin_only
async def reindex_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await reply_protected(update, 
            "Usage: `/reindex CHANNEL_ID [COUNT]`", parse_mode=ParseMode.MARKDOWN
        )
        return
    try:
        channel_id = int(context.args[0])
    except ValueError:
        await reply_protected(update, "CHANNEL_ID must be a number.")
        return
    count = None  # PHASE 8: unbounded (runaway-guarded) — the old 500 cap
                  # silently truncated scans and reported 'complete'.
    if len(context.args) > 1:
        try:
            count = int(context.args[1])
            if count <= 0:
                raise ValueError
        except ValueError:
            await reply_protected(update, "COUNT must be a positive integer.")
            return

    # Make sure the channel is reachable.
    try:
        await context.bot.get_chat(channel_id)
    except TelegramError as e:
        await reply_protected(update, f"Cannot access channel {channel_id}: {e}")
        return

    # Try to get channel title for user-friendly display
    ch_title = str(channel_id)
    try:
        chat_info = await context.bot.get_chat(channel_id)
        if chat_info and chat_info.title:
            ch_title = chat_info.title
    except TelegramError:
        pass

    status_msg = await reply_protected(update, 
        f"\U0001F504 Reindexing *{ch_title}*"
        + (f" (up to {count} messages)..." if count else " (full range)..."),
    )
    asyncio.create_task(
        run_reindex(context.bot, update.effective_user.id, channel_id, count, status_msg, ch_title)
    )


# ---- V26.2 (bot-41 §6): safe media identity repair ----
@admin_only
async def repairidentity_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/repairidentity [LIMIT] — deterministically backfill MISSING
    file_unique_id values on canonical indexed rows.

    For every affected row the AUTHORITATIVE Telegram metadata is fetched
    from its OWN (channel_id, message_id) through the existing internal
    fetch transport (copy into an admin chat, immediately deleted — never
    user-visible), conflict-checked, and written through the guarded
    db.repair_indexed_file_identity (fills only NULL/empty identity; never
    overwrites an existing identity; never fabricates a value when the
    source message is unreachable — the row stays honestly unstreamable).
    """
    limit = 50
    if context.args:
        try:
            limit = int(context.args[0])
            if limit <= 0 or limit > 500:
                raise ValueError
        except ValueError:
            await reply_protected(update,
                "LIMIT must be a positive integer (max 500).")
            return
    bot = context.bot
    admin_id = update.effective_user.id

    async def _fetch(admin_chat_id: int, channel_id: int, message_id: int):
        return await fetch_channel_media(
            bot, int(admin_chat_id), int(channel_id), int(message_id))

    async def _delete(chat_id: int, message_id: int) -> None:
        try:
            await bot.delete_message(int(chat_id), int(message_id))
        except Exception:  # noqa: BLE001 — best-effort cleanup
            pass

    from app.media.repair import make_media_repair_service
    svc = make_media_repair_service(
        db,
        fetch_source_media=_fetch,
        resolve_admin_chat_id=_recovery_admin_chat_id,
        delete_message=_delete)
    status = await reply_protected(
        update, "🩹 Repairing missing media identities (up to "
        f"{limit} rows)…")
    report = await svc.repair_missing_identities(limit)
    lines = [
        "🩺 *Media Identity Repair*",
        f"Scanned: {report['scanned']}",
        f"Repaired: {report['repaired']}",
        f"Already present: {report['already']}",
        f"Failed (honest — see log): {report['failed']}",
        f"Skipped (no transport): {report['skipped']}",
    ]
    reasons: dict = {}
    for row in report.get("rows", []):
        r = str(row.get("result") or "?")
        reasons[r] = reasons.get(r, 0) + 1
    if reasons:
        lines.append("Reasons: " + ", ".join(
            f"{k}×{v}" for k, v in sorted(reasons.items())))
    lines.append(
        "_Rows that stay unstreamable are reported honestly — run "
        "/reindex on the source channel after fixing the source._")
    try:
        await status.edit_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)
    except Exception:  # noqa: BLE001 — fall back to a fresh reply
        await reply_protected(update, "\n".join(lines))
