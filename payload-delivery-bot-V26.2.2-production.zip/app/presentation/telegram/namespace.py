"""Telegram presentation runtime namespace (ARCHITECTURE PROPER BREAKDOWN).

THE composition point of the Telegram presentation layer. This module
assembles the shared runtime namespace — the object that used to be the
bot.py module — from the REAL section modules extracted out of the
monolith:

    app/presentation/telegram/state.py      (imports, config, state)
    app/presentation/telegram/<section>.py  (handlers by responsibility)

Assembly contract
-----------------
1. ``state`` is imported first and its entire module surface becomes the
   foundation of the runtime namespace (configuration bindings, constants,
   locks, singletons — original order preserved).
2. Every section module is imported and each of its top-level functions is
   REBOUND into the shared namespace (``types.FunctionType`` with the
   namespace dict as ``__globals__``), so:
   - cross-section references resolve at CALL time through ONE namespace
     (exactly the late-binding contract the regression suites rely on),
   - monkey-patching ``runtime.<name>`` keeps working everywhere,
   - ``global`` statements inside functions mutate the shared namespace.
3. Decorated functions (``@admin_only``) get their CLOSURE CELLS patched to
   point at the rebound inner functions — the wrapper and the wrapped
   function both resolve through the shared namespace.
4. Classes are rebuilt with rebound methods.
5. ``_LEGACY_NS`` / ``_SVCS`` are bound on the namespace itself: the
   app/services/container.py service factories receive THIS namespace (the
   presentation runtime) — never a bot.py module.
6. The assembled namespace is registered as
   ``app.presentation.telegram.runtime`` (importable, inspectable) and is
   the single handler-provider object the composition root
   (app/bootstrap/application.py) builds the PTB Application from.

NOTHING imports bot.py. bot.py is no longer part of the architecture.
"""
from __future__ import annotations

import builtins as _builtins
import sys as _sys
import types as _types

from app.services.container import legacy_service_factories as _legacy_service_factories

from . import state as _state
from . import (
    access as _access,
    access_panels as _access_panels,
    admin_commands as _admin_commands,
    admin_panels as _admin_panels,
    broadcast as _broadcast,
    callbacks as _callbacks,
    collections as _collections,
    compat as _compat,
    deletion as _deletion,
    delivery as _delivery,
    files_panels as _files_panels,
    forcejoin as _forcejoin,
    guards as _guards,
    indexing as _indexing,
    lifecycle as _lifecycle,
    mediaops as _mediaops,
    messaging as _messaging,
    miniapp as _miniapp,
    network_wiring as _network_wiring,
    payloads_panels as _payloads_panels,
    referral as _referral,
    retrieve as _retrieve,
    search as _search,
    settings as _settings,
    start as _start,
    stats_panels as _stats_panels,
    storage_panels as _storage_panels,
    text_input as _text_input,
    watchads as _watchads,
    website_admin as _website_admin,
    wizard as _wizard,
)
from ._manifest import SECTION_MEMBERS as _SECTION_MEMBERS

RUNTIME_NAME = "app.presentation.telegram.runtime"

_SECTION_MODULES = {
    "guards": _guards,
    "compat": _compat,
    "messaging": _messaging,
    "delivery": _delivery,
    "mediaops": _mediaops,
    "indexing": _indexing,
    "forcejoin": _forcejoin,
    "settings": _settings,
    "deletion": _deletion,
    "access": _access,
    "referral": _referral,
    "watchads": _watchads,
    "retrieve": _retrieve,
    "start": _start,
    "admin_commands": _admin_commands,
    "search": _search,
    "text_input": _text_input,
    "collections": _collections,
    "broadcast": _broadcast,
    "admin_panels": _admin_panels,
    "storage_panels": _storage_panels,
    "payloads_panels": _payloads_panels,
    "access_panels": _access_panels,
    "files_panels": _files_panels,
    "stats_panels": _stats_panels,
    "callbacks": _callbacks,
    "lifecycle": _lifecycle,
    "miniapp": _miniapp,
    "website_admin": _website_admin,
    "network_wiring": _network_wiring,
    "wizard": _wizard,
}

_STATE_MODULE_ATTRS = {
    "__name__", "__doc__", "__package__", "__loader__", "__spec__",
    "__file__", "__builtins__", "__cached__",
}


def _make_cell(value):
    fn = (lambda: value)
    return fn.__closure__[0]


def _rebind_function(fn, ns_dict):
    """Recreate ``fn`` with the shared namespace as its globals."""
    new = _types.FunctionType(
        fn.__code__, ns_dict, fn.__name__, fn.__defaults__, fn.__closure__)
    new.__kwdefaults__ = fn.__kwdefaults__
    new.__doc__ = fn.__doc__
    new.__module__ = RUNTIME_NAME
    new.__qualname__ = fn.__qualname__
    new.__dict__.update(fn.__dict__)
    return new


def _patch_closure(fn, id_map, ns_dict):
    """Replace closure cells that hold pre-rebind section functions with
    their rebound counterparts (the @admin_only wrapper contract).

    Decorator wrappers (e.g. ``@admin_only``) close over the ORIGINAL
    section function — an object that never appears as a module attribute
    (the decorator replaced it). Those originals are rebound HERE, on first
    encounter, and cached in ``id_map`` so every wrapper shares one
    rebound instance.
    """
    if not fn.__closure__:
        return fn
    cells = []
    changed = False
    for cell in fn.__closure__:
        try:
            v = cell.cell_contents
        except ValueError:  # empty cell
            v = None
        if isinstance(v, _types.FunctionType):
            if id(v) in id_map:
                v = id_map[id(v)]
                changed = True
            else:
                rebound = _rebind_function(v, ns_dict)
                id_map[id(v)] = rebound
                v = rebound
                changed = True
        cells.append(_make_cell(v))
    if not changed:
        return fn
    new = _types.FunctionType(
        fn.__code__, fn.__globals__, fn.__name__, fn.__defaults__,
        tuple(cells))
    new.__kwdefaults__ = fn.__kwdefaults__
    new.__doc__ = fn.__doc__
    new.__module__ = fn.__module__
    new.__qualname__ = fn.__qualname__
    new.__dict__.update(fn.__dict__)
    return new


def _rebind_class(cls, ns_dict, id_map):
    """Rebuild a class whose methods resolve through the shared namespace."""
    new_dict = {}
    for key, value in vars(cls).items():
        if key in ("__dict__", "__weakref__"):
            continue  # slot descriptors cannot be passed through type()
        if isinstance(value, _types.FunctionType):
            value = _patch_closure(_rebind_function(value, ns_dict), id_map, ns_dict)
        elif isinstance(value, staticmethod):
            inner = value.__func__
            if isinstance(inner, _types.FunctionType):
                inner = _patch_closure(_rebind_function(inner, ns_dict), id_map, ns_dict)
            value = staticmethod(inner)
        elif isinstance(value, classmethod):
            inner = value.__func__
            if isinstance(inner, _types.FunctionType):
                inner = _patch_closure(_rebind_function(inner, ns_dict), id_map, ns_dict)
            value = classmethod(inner)
        elif isinstance(value, property):
            accessors = []
            for acc in (value.fget, value.fset, value.fdel):
                if isinstance(acc, _types.FunctionType):
                    acc = _patch_closure(_rebind_function(acc, ns_dict), id_map, ns_dict)
                accessors.append(acc)
            value = property(accessors[0], accessors[1], accessors[2],
                             doc=value.__doc__)
        new_dict[key] = value
    new_dict["__module__"] = RUNTIME_NAME
    return type(cls)(cls.__name__, cls.__bases__, new_dict)


def _assemble():
    ns = _types.ModuleType(RUNTIME_NAME)
    ns_dict = ns.__dict__
    ns_dict["__builtins__"] = _builtins
    ns_dict["__doc__"] = __doc__
    ns_dict["__package__"] = "app.presentation.telegram"
    ns_dict["__file__"] = _state.__file__
    ns_dict["_PRESENTATION_SECTION_MODULES"] = dict(_SECTION_MODULES)

    # 1. state foundation (config, constants, locks, singletons, imports)
    for key, value in vars(_state).items():
        if key in _STATE_MODULE_ATTRS:
            continue
        ns_dict[key] = value

    # 2. rebind every MANIFEST-OWNED section function/class into the shared
    #    namespace (the manifest is the authoritative name→section table
    #    generated from the original bot.py AST — nothing else is copied, so
    #    section-local imports can never shadow the shared namespace).
    id_map = {}
    for section, mod in _SECTION_MODULES.items():
        for name in _SECTION_MEMBERS[section]:
            value = getattr(mod, name)
            if isinstance(value, _types.FunctionType):
                rebound = _rebind_function(value, ns_dict)
                id_map[id(value)] = rebound
                ns_dict[name] = rebound
            else:
                ns_dict[name] = value  # classes rebuilt in step 4

    # 3. patch closures (decorators that captured pre-rebind functions).
    #    ONLY functions whose globals ARE the shared namespace (i.e. the
    #    products of step 2) are eligible — externally-owned functions
    #    re-exported from state keep their own module globals untouched.
    for name, value in list(ns_dict.items()):
        if isinstance(value, _types.FunctionType) and value.__globals__ is ns_dict:
            ns_dict[name] = _patch_closure(value, id_map, ns_dict)

    # 4. rebuild classes with rebound methods
    for section, mod in _SECTION_MODULES.items():
        for name in _SECTION_MEMBERS[section]:
            value = getattr(mod, name)
            if isinstance(value, type) and value.__module__ == mod.__name__:
                ns_dict[name] = _rebind_class(value, ns_dict, id_map)

    # 4b. module-level state that instantiates section classes (created
    #     from the REBUILT class so its methods resolve through the
    #     shared namespace — was `rate_limiter = RateLimiter()` in bot.py).
    ns_dict["rate_limiter"] = ns_dict["RateLimiter"]()

    # 5. the namespace IS the presentation runtime — bind the service
    #    factories to it (this used to be bot.py's _LEGACY_NS / _SVCS).
    ns_dict["_LEGACY_NS"] = ns
    ns_dict["_SVCS"] = _legacy_service_factories(ns)
    return ns


NS = _assemble()

# 6. publish: importable as app.presentation.telegram.runtime
_sys.modules[RUNTIME_NAME] = NS
_parent = _sys.modules.get(__package__)
if _parent is not None:
    setattr(_parent, "runtime", NS)


def _verify_manifest(ns) -> None:
    """Completeness gate: every name the original bot.py had must exist."""
    from ._manifest import SECTION_MEMBERS, STATE_NAMES
    missing = []
    for section, names in SECTION_MEMBERS.items():
        for name in names:
            if not hasattr(ns, name):
                missing.append(f"{section}:{name}")
    for name in STATE_NAMES:
        if not hasattr(ns, name):
            missing.append(f"state:{name}")
    if missing:
        raise RuntimeError(
            "runtime namespace incomplete — missing names: "
            + ", ".join(missing))


_verify_manifest(NS)
