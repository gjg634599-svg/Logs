"""Retrieve system — retrieve message, handler, panels.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations









async def render_retrieve_message(
    bot,
    chat_id: int,
    user_id: int,
    payload_code: str,
    delivery_type: str,
    collection_code: Optional[str] = None,
    reply_to_message_id: Optional[int] = None,
    existing_record_id: Optional[int] = None,
    existing_msg_id: Optional[int] = None,
) -> Optional[int]:
    """Issue #84: THE centralized retrieve message renderer.

    Sends a text message (with the Retrieve button) that REPLIES to the
    delivered content. For albums/collections it replies to the first delivered
    media item (Telegram cannot reply to an entire album).

    Returns the message_id of the retrieve message (or None on failure).

    Behaviour:
    - If retrieve_enabled is False globally, no message is created.
    - If existing_record_id is provided (retrieve flow), reuses that record.
    - If existing_msg_id is provided, EDITS the existing retrieve message
      in place (no duplicate). One delivery = one retrieve message.
    - The retrieve message is NEVER added to auto-delete schedules.
    """
    # Reuse existing delivery record if provided (retrieve flow).
    if existing_record_id:
        record_id = existing_record_id
    else:
        # Enforce global retrieve settings on new records (Issue #50).
        retrieve_on = await db.get_setting_bool("retrieve_enabled", True)
        if not retrieve_on:
            logger.debug("Retrieve message skipped: retrieve_enabled=False (payload=%s)",
                         payload_code)
            return None  # Retrieve disabled globally — no message, no record.
        max_ret = await db.get_setting_int("retrieve_limit", 0)        # 0 = unlimited
        win_hrs = await db.get_setting_int("retrieve_window_hours", 0)  # 0 = no limit
        record_id = await db.create_delivery_record(
            payload_code=payload_code,
            user_id=user_id,
            delivery_type=delivery_type,
            chat_id=chat_id,
            collection_code=collection_code,
            max_retrieves=max_ret,
            retrieve_window_hours=win_hrs,
        )

    # Build the retrieve message text (admin-configurable).
    raw_text = await get_retrieve_text()
    count = 0
    if delivery_type == "collection" and collection_code:
        try:
            coll = await db.get_collection(collection_code)
            if coll:
                count = coll["file_count"] or 0
        except Exception:  # noqa: BLE001
            pass
    # BOT5 FIX: resolve the EFFECTIVE delivery timer for the {timer} placeholder.
    _payload_row_for_timer = None
    try:
        _payload_row_for_timer = await db.get_payload(payload_code)
    except Exception:  # noqa: BLE001
        _payload_row_for_timer = None
    _effective_timer = await resolve_retrieve_timer(_payload_row_for_timer)
    msg_text = _format_retrieve_text(raw_text, count=count, timer_seconds=_effective_timer)
    logger.info(
        "BOT6_RETRIEVE_TIMER_TEXT payload=%s effective_timer=%s rendered_text=%s",
        payload_code, _effective_timer if _effective_timer > 0 else "never",
        msg_text[:100],
    )
    button_label = await get_retrieve_button()
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(button_label, callback_data=f"retrieve:{record_id}")],
    ])

    # Issue #81/#84/#89: If existing retrieve message exists, EDIT it in place.
    # Retrieve messages are always text (no media in the new architecture),
    # so edit_message_text is sufficient. Issue #89: log every failure path so
    # edit errors are never silently swallowed. Handle: deleted messages, old
    # messages (too old to edit), unchanged text (no-op), callback race
    # conditions. On any failure, fall through to send a new message.
    if existing_msg_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=existing_msg_id,
                text=msg_text, reply_markup=kb,
            )
            return existing_msg_id
        except BadRequest as e:
            err_lower = str(e).lower()
            if "not found" in err_lower or "message to edit not found" in err_lower:
                logger.debug("Retrieve msg %s: edit failed (deleted) — creating new", existing_msg_id)
            elif "message is not modified" in err_lower:
                # Text unchanged — no-op, the existing message is still valid.
                logger.debug("Retrieve msg %s: edit no-op (unchanged)", existing_msg_id)
                return existing_msg_id
            elif "too old" in err_lower or "can't edit" in err_lower:
                logger.debug("Retrieve msg %s: edit failed (too old) — creating new", existing_msg_id)
            else:
                logger.warning("Retrieve msg %s: edit BadRequest: %s — creating new",
                               existing_msg_id, e)
        except RetryAfter as e:
            logger.debug("Retrieve msg %s: edit RetryAfter %ss — creating new",
                         existing_msg_id, e.retry_after)
        except TelegramError as e:
            logger.warning("Retrieve msg %s: edit failed: %s — creating new", existing_msg_id, e)

    # Issue #90: Collection retrieve fallback. If reply_to_message_id is invalid
    # (partial delivery failure), the send below would still work — but if the
    # reply target was deleted, Telegram raises BadRequest. Fallback order:
    #   1. reply to first delivered media (reply_to_message_id)
    #   2. if that fails, send without reply (standalone retrieve message)
    # Retrieve must never fail.
    send_kwargs: Dict[str, Any] = {"reply_markup": kb}
    if reply_to_message_id:
        send_kwargs["reply_to_message_id"] = reply_to_message_id
    sent_msg = await safe_send_text(bot, chat_id, msg_text, **send_kwargs)
    if sent_msg is None and reply_to_message_id:
        # Reply failed (target deleted?) — retry as standalone (no reply).
        logger.warning("Retrieve msg: reply to %s failed — sending standalone",
                       reply_to_message_id)
        send_kwargs.pop("reply_to_message_id", None)
        sent_msg = await safe_send_text(bot, chat_id, msg_text, **send_kwargs)
    if sent_msg and sent_msg.message_id:
        await db.update_recovery_message_id(record_id, sent_msg.message_id)
        return sent_msg.message_id
    logger.error("Retrieve msg: failed to send (chat=%s record=%s)", chat_id, record_id)
    return None



async def handle_retrieve(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          record_id: int, user: User) -> None:
    """Issue #50/#51/#52/#53/#56/#65: Retrieve a delivery after auto-delete.

    Issue #65: Full validation engine — checks payload/collection existence,
    retrieve limits, retrieve windows, force-join, and permissions before
    rebuilding the delivery.
    Issue #78: Recovery cards are NEVER auto-deleted — only delivered media.
    """
    record = await db.get_delivery_record(record_id)
    if not record:
        await safe_answer_callback(update.callback_query,
            "\u274C This delivery record no longer exists.", show_alert=True)
        return

    # ---- Issue #65: Retrieve Validation Engine ----
    payload_code = record["payload_code"]
    delivery_type = record["delivery_type"]
    collection_code_val = record["collection_code"] if record["collection_code"] else None
    chat_id = record["chat_id"]

    # 1. Validate payload exists (if single file delivery).
    if delivery_type == "single" and not payload_code.startswith(MSG_LINK_PREFIX):
        payload_row = await db.get_payload(payload_code)
        if not payload_row:
            await safe_answer_callback(update.callback_query,
                "\u274C Payload Removed\n\nThis payload is no longer available.",
                show_alert=True)
            return
        if payload_row["status"] != "active":
            await safe_answer_callback(update.callback_query,
                "\u274C Payload Disabled\n\nThis payload has been disabled.",
                show_alert=True)
            return

    # 2. Validate collection exists (if collection delivery).
    # V26 (message-872 identity fix): the CANONICAL collection predicate
    # (is_collection_link — c + hex-only, the /start routing truth). A
    # single-file payload whose name begins with 'c' (e.g. payload 787
    # 'clipmatezone_…') is NOT a collection — the naive startswith made
    # its retrieve path fail with a phantom "Collection Removed".
    if delivery_type == "collection" or is_collection_link(payload_code):
        code = collection_code_val or parse_collection_link(payload_code)
        if code:
            coll = await db.get_collection(code)
            if not coll:
                await safe_answer_callback(update.callback_query,
                    "\u274C Collection Removed\n\nThis collection is no longer available.",
                    show_alert=True)
                return

    # 3. Validate retrieve limit.
    max_retrieves = record["max_retrieves"]
    if max_retrieves and max_retrieves > 0:
        if record["retrieve_count"] >= max_retrieves:
            await safe_answer_callback(update.callback_query,
                "\u274C Retrieve Limit Reached\n\n"
                f"Maximum retrieves: {max_retrieves}\n"
                f"Used: {record['retrieve_count']}",
                show_alert=True)
            return

    # 4. Validate retrieve window.
    window_hours = record["retrieve_window_hours"]
    if window_hours and window_hours > 0:
        try:
            delivered_at = datetime.fromisoformat(record["delivered_at"])
            elapsed = (datetime.now(timezone.utc) - delivered_at).total_seconds() / 3600
            if elapsed > window_hours:
                await safe_answer_callback(update.callback_query,
                    "\u274C Retrieval Window Expired\n\n"
                    f"Window: {window_hours} hours\n"
                    f"Elapsed: {elapsed:.1f} hours",
                    show_alert=True)
                return
        except (ValueError, TypeError):
            pass

    # 5. Access Engine V1: retrieve must respect the SAME authorization as the
    # original delivery. Force-join + referral unlock are both enforced here.
    # Issue #51/#66 successor: fresh check, never trust previous state.
    #
    # BOT6: recover the trace_id stashed by on_callback so the retrieve journey
    # (callback -> retrieve -> delivery) is correlated across logs.
    _trace_id = "-"
    try:
        _trace_id = context.user_data.get("_trace_id") or "-"
    except Exception:  # noqa: BLE001
        pass
    # BOT5 FIX: answer the callback BEFORE enforce_access so the spinner
    # dismisses even if access is denied.
    logger.info("BOT6_RETRIEVE_START trace_id=%s retrieve_id=%s user_id=%s payload_code=%s",
                _trace_id, record_id, user.id, payload_code)
    await safe_answer_callback(update.callback_query, "Retrieving files...")
    # V26 (message-872 identity fix): canonical predicates — a payload
    # named 'movie_…' / 'clip…' is a NAMED payload, not an m-link/c-link.
    is_msg = is_msg_link(payload_code)
    is_coll = is_collection_link(payload_code)
    if not is_msg and not is_coll:
        # Named payload — full policy resolution (OPEN/FORCE_JOIN/REFERRAL).
        payload_row = await db.get_payload(payload_code)
        if payload_row:
            if not await enforce_access(update, context, user,
                                        payload_id=payload_row["id"],
                                        payload_code=payload_code,
                                        link_arg=payload_code):
                return
        else:
            # Payload vanished between delivery and retrieve.
            await safe_answer_callback(update.callback_query,
                "\u274C Payload Removed\n\nThis payload is no longer available.",
                show_alert=True)
            return
    else:
        # m<link> / collection — FORCE_JOIN policy (no payload row).
        if not await enforce_access(update, context, user,
                                    payload_code=payload_code, link_arg=payload_code):
            return

    # ---- Validation passed — rebuild delivery ----
    # Issue #56: apply protection settings (global auto-delete timer).
    settings = await resolve_protection_settings()
    auto_del = settings["auto_delete_seconds"]
    # Increment retrieve count + retrieve analytics (retrieve-specific stats;
    # the delivery itself does NOT re-bump per-file or per-payload stats).
    await db.increment_retrieve_count(record_id)
    await db.increment_stat("retrieve_success")
    await db.increment_stat("retrieves")
    # Issue #53: rebuild delivery from source of truth.
    payload_code = record["payload_code"]
    delivery_type = record["delivery_type"]
    chat_id = record["chat_id"]
    await safe_answer_callback(update.callback_query, "Retrieving files...")
    # V26 (message-872 identity fix): canonical collection predicate —
    # a stored delivery_type of "collection" keeps driving collection
    # retrieval (the record is authoritative), but a NAMED payload code
    # that merely begins with 'c' is never misrouted.
    if delivery_type == "collection" or is_collection_link(payload_code):
        # Collection retrieve — delegate to the Unified Delivery Engine.
        code = record["collection_code"] or parse_collection_link(payload_code)
        files = await _load_collection_files(code)
        if not files:
            await safe_send_text(context.bot, chat_id,
                "\u274C This collection is no longer available.")
            return
        # Retrieve: no payload_row (don't re-bump per-payload stats or expire),
        # no per-file stats (bump_file_stats=False), use the global auto-delete
        # timer, and edit the existing retrieve message in place.
        await _deliver_files_core(
            context.bot, chat_id=chat_id, user_id=user.id,
            payload_row=None,
            payload_code=payload_code,
            files=files,
            delivery_type="collection",
            stat_key=None,
            bump_file_stats=False,
            delete_delay_override=auto_del,
            collection_code=code,
            existing_record_id=record_id,
            existing_msg_id=record["recovery_message_id"],
        )
    else:
        # Single file retrieve — delegate to the Unified Delivery Engine.
        if payload_code.startswith(MSG_LINK_PREFIX):
            msg_id = int(payload_code[1:])
            file_row = await db.get_indexed_file_by_message_id(msg_id)
        else:
            row = await db.get_payload(payload_code)
            if not row:
                await safe_send_text(context.bot, chat_id,
                    "\u274C This payload is no longer available.")
                return
            file_row = await db.get_indexed_file_by_id(row["index_id"])
        if not file_row:
            await safe_send_text(context.bot, chat_id,
                "\u274C This file is no longer available.")
            return
        # Retrieve: no payload_row, no per-file stats, global auto-delete timer,
        # edit the existing retrieve message in place.
        await _deliver_files_core(
            context.bot, chat_id=chat_id, user_id=user.id,
            payload_row=None,
            payload_code=payload_code,
            files=[file_row],
            delivery_type="single",
            stat_key=None,
            bump_file_stats=False,
            delete_delay_override=auto_del,
            existing_record_id=record_id,
            existing_msg_id=record["recovery_message_id"],
        )



# ============================================================
# ISSUE #84: UNIFIED RETRIEVE SETTINGS PANEL
# ============================================================
# Replaces the old Global Branding + Collection Branding panels. The retrieve
# message is now a reply attached to delivered content (not a standalone card),
# so the only admin-configurable fields are: the message text, the button label,
# enable/disable, limit, window, and a live preview. Branding UI is GONE.
# ============================================================
async def retrieve_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue #84: Unified Retrieve System dashboard."""
    enabled = await db.get_setting_bool("retrieve_enabled", True)
    limit = await db.get_setting_int("retrieve_limit", 0)
    window = await db.get_setting_int("retrieve_window_hours", 0)
    en_label = "\U0001F7E2 ON" if enabled else "\U0001F534 OFF"
    # Icon extracted to a variable BEFORE the f-string (Python <3.12 compat).
    rt_icon = "\U0001F7E2" if enabled else "\U0001F534"
    if limit and limit > 0:
        mode_label = f"\U0001F522 Limited ({limit} retrieves)"
    elif window and window > 0:
        mode_label = f"\u23F0 Time Window ({window}h)"
    else:
        mode_label = "\u267E Unlimited"
    total_del = await db.count_delivery_records()
    total_ret = await db.count_total_retrieves()
    # §36 markdown escaping: the retrieve text/button are ADMIN-CONFIGURED
    # free-form strings — a stray _ * ` [ in them broke ParseMode.MARKDOWN
    # ("can't find end of the entity" → safe_edit_text plain-fallback warning
    # in production). Escape the dynamic preview, keep the panel markup.
    text_preview = escape_md((await get_retrieve_text())[:100])
    btn_preview = escape_md(await get_retrieve_button())
    text = (
        "*\U0001F4E5 Retrieve System*\n\n"
        f"Status: {en_label}\n"
        f"Mode: {mode_label}\n\n"
        f"\U0001F4DD Text: {text_preview}\n"
        f"\U0001F518 Button: {btn_preview}\n\n"
        f"\U0001F4E4 Deliveries: {total_del}\n"
        f"\U0001F4E5 Total retrieves: {total_ret}\n\n"
        "Retrieve message is attached as a reply to delivered files."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"{rt_icon} Enable Retrieve", callback_data="rt:toggle")],
        [InlineKeyboardButton("\u270F\uFE0F Edit Retrieve Text", callback_data="rt:edittext"),
         InlineKeyboardButton("\U0001F518 Edit Button Text", callback_data="rt:editbutton")],
        [InlineKeyboardButton("\U0001F522 Set Limit (0=unlimited)", callback_data="rt:setlimit"),
         InlineKeyboardButton("\u23F0 Set Window Hours (0=none)", callback_data="rt:setwindow")],
        [InlineKeyboardButton("\U0001F441 Preview", callback_data="rt:preview"),
         InlineKeyboardButton("\u267B\uFE0F Reset", callback_data="rt:reset")],
        [InlineKeyboardButton("\U0001F4CA Most Retrieved", callback_data="rt:analytics")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:settings")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def retrieve_preview(bot, chat_id: int) -> None:
    """Issue #84: simulate a real retrieve message delivery.

    Sends a placeholder 'sample file' message, then sends the retrieve message
    as a reply to it — exactly as production delivery would. Preview matches
    production exactly.
    """
    # Send a stand-in 'sample file' message to reply to.
    sample = await safe_send_text(bot, chat_id,
        "\U0001F3AC Sample File\n\n(simulated delivered content)")
    reply_to = sample.message_id if sample else None
    raw_text = await get_retrieve_text()
    btn_label = await get_retrieve_button()
    # Issue #92: use a disabled preview callback so the preview button can
    # never touch a real delivery record. retrieve:0 would route to
    # handle_retrieve(record_id=0) which errors with "record not found".
    # preview_retrieve is a no-op callback that just answers the query.
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(btn_label, callback_data="preview_retrieve")],
    ])
    send_kwargs: Dict[str, Any] = {"reply_markup": kb}
    if reply_to:
        send_kwargs["reply_to_message_id"] = reply_to
    await safe_send_text(bot, chat_id, raw_text, **send_kwargs)



async def retrieve_analytics_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Issue #55: most-retrieved payloads + collections."""
    payloads = await db.most_retrieved_payloads(limit=8)
    collections = await db.most_retrieved_collections(limit=8)
    lines = ["*\U0001F4CA Retrieve Analytics*", ""]
    lines.append("*Top Payloads:*")
    if payloads:
        for i, r in enumerate(payloads, 1):
            # §36 markdown escaping: payload codes are admin-named free-form
            # strings — a backtick in one would close the span and break
            # ParseMode.MARKDOWN (md_code_span makes the span unbreakable).
            code = r["payload_code"] or "?"
            total = int(r["total"] or 0)
            lines.append(f"{i}. {md_code_span(code)} \u2014 {total}")
    else:
        lines.append("(no retrieves yet)")
    lines.append("")
    lines.append("*Top Collections:*")
    if collections:
        for i, r in enumerate(collections, 1):
            # §36: same escaping contract for collection codes.
            code = r["collection_code"] or "?"
            total = int(r["total"] or 0)
            lines.append(f"{i}. {md_code_span(code)} \u2014 {total}")
    else:
        lines.append("(no retrieves yet)")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:retrieve")],
    ])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
