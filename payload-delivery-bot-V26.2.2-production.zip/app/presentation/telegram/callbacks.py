"""Callback router — on_callback dispatcher + on_error.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# CALLBACK QUERY ROUTER
# ============================================================
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if not q:
        return
    # BOT6 CALLBACK AUDIT: every callback gets a trace_id, is logged on
    # receipt, answered promptly, and any exception is captured by on_error
    # with the same trace_id so the full journey (received -> answered ->
    # result/exception) is reconstructable from logs.
    import uuid as _uuid
    _trace_id = _uuid.uuid4().hex[:12]
    _t0 = time.time()
    data_peek = q.data or ""
    _cb_user = q.from_user.id if q.from_user else 0
    _cb_msg_id = q.message.message_id if q.message else 0
    logger.info(
        "BOT6_CALLBACK_RECEIVED trace_id=%s callback_data=%s user_id=%s message_id=%s",
        _trace_id, data_peek[:80], _cb_user, _cb_msg_id,
    )
    # V25 §10 (bot-34.log duplicate-callback forensics): Telegram
    # RE-DELIVERS a callback update when the answerCallbackQuery ack is
    # delayed (bot-34.log: 4x wspr:skipdp within 500ms — a human cannot
    # tap that fast). A re-delivery carries the SAME callback_query.id
    # (unique per physical press), so a short-TTL dedup keyed on that id
    # skips the DUPLICATE PROCESSING (e.g. skip-delay +4s instead of +1s)
    # while genuine rapid taps (distinct ids) pass through untouched.
    # The namespace-level cache is bounded and pruned; a missing/empty
    # id (test fakes) bypasses the guard.
    _cbq_cache = globals().get("_CBQ_DEDUP_CACHE")
    if not isinstance(_cbq_cache, dict):
        _cbq_cache = {}
        globals()["_CBQ_DEDUP_CACHE"] = _cbq_cache
    _now = time.time()
    if len(_cbq_cache) > 512:
        _cbq_cache = {k: v for k, v in _cbq_cache.items()
                      if _now - v < 15.0}
        globals()["_CBQ_DEDUP_CACHE"] = _cbq_cache
    _cbq_key = str(getattr(q, "id", "") or "")
    if _cbq_key:
        _seen_ts = _cbq_cache.get(_cbq_key)
        if _seen_ts is not None and _now - _seen_ts < 15.0:
            logger.info(
                "BOT6_CALLBACK_DUPLICATE_SKIPPED trace_id=%s "
                "callback_query_id=%s callback_data=%s user_id=%s "
                "message_id=%s (Telegram re-delivery of the same button "
                "press — answered and skipped; no duplicate state "
                "change, no duplicate send)",
                _trace_id, _cbq_key, data_peek[:60], _cb_user, _cb_msg_id)
            try:
                await safe_answer_callback(q)
            except Exception:  # noqa: BLE001 — answering a dup is best-effort
                pass
            return
        _cbq_cache[_cbq_key] = _now
    # v37 A13 + b10 §6: rapid double-tap guard for state-changing actions.
    # _cb_should_debounce (defined in state.py — the namespace foundation,
    # the same resolution discipline as _debounced: this REBOUND function
    # sees the shared runtime namespace, NOT callbacks.py module globals)
    # covers the v37 prefixes AND the exact-shape state-changing patterns
    # (nbot:<id>:enable|disable|remove|replace, dg: wizard entries, …)
    # while read-only navigation (nbot:<id>, panel:, pl:…) stays through.
    if _cb_should_debounce(data_peek) \
            and _cb_user and _debounced(_cb_user, data_peek):
        logger.info(
            "BOT6_CALLBACK_DEBOUNCED trace_id=%s callback_data=%s user_id=%s "
            "window=%ss (identical action already executing)",
            _trace_id, data_peek[:60], _cb_user, _CB_DEBOUNCE_SECONDS)
        await safe_answer_callback(
            q, "\u23F3 Already processing — one moment.")
        return
    # Stash trace_id on the context so downstream handlers / on_error can
    # correlate. context.user_data survives the handler call.
    try:
        context.user_data["_trace_id"] = _trace_id
        context.user_data["_cb_t0"] = _t0
    except Exception:  # noqa: BLE001
        pass
    # BOT6 FIX: do NOT blanket-answer retrieve: — handle_retrieve answers it
    # itself (with a meaningful message) so we don't double-answer.
    if not data_peek.startswith("retrieve:"):
        await safe_answer_callback(q)
        logger.info("BOT6_CALLBACK_ANSWER trace_id=%s callback_data=%s answered=True",
                    _trace_id, data_peek[:60])
    else:
        logger.info("BOT6_CALLBACK_ANSWER trace_id=%s callback_data=%s answered=False (deferred)",
                    _trace_id, data_peek[:60])
    user = q.from_user
    # Admin-only panel (verify/copy are allowed for everyone).
    data = q.data or ""
    # User-facing callbacks that non-admins are allowed to trigger. These cover
    # the full collection-delivery golden path (force-join verify, download
    # collection, browse files, deliver a single file from browse, return to the
    # collection menu, close the menu) plus link-copy. Without these, a normal
    # user opening /start rSTART_END could see the Collection menu but every
    # button would reply "Admins only." — breaking collection delivery entirely.
    USER_FACING_PREFIXES = (
        "verify:", "copy:", "copy_id:", "plcopy:", "rngdl:", "rngbrowse:", "rngfile:",
        "rngmenu:", "rngclose", "start_home",
        # Issue 2: new collection callbacks (user-facing golden path).
        "coldl:", "cobrowse:", "cofile:", "comenu:", "coclose", "cocopy:",
        # Issue #50: Retrieve button (user-facing).
        "retrieve:",
        # BOT7 FIX: the user-facing Help screen's Back button. The handler at
        # help:back already checks is_admin internally (admin -> panel, user ->
        # "Closed."), but this callback was missing from the allow-list so
        # normal users pressing Back on the Help screen got "Admins only."
        "help:back",
        # Issue #92: preview retrieve button (no-op, never touches real records).
        "preview_retrieve",
        # Issue #94: Referral Gate callbacks (user-facing).
        "refcheck:", "refhow:", "refwatch:",
        # WATCH_AD (v25): user-facing Watch Ad callbacks (session start +
        # access refresh after a verified reward).
        "wad:", "wadcheck:",
        # V5.2: WA How-It-Works (WA access screen) + per-file delivery retry.
        "wadhow:", "retryfile:",
        # NETWORK PLATFORM (v29): user-facing network callbacks — the atomic
        # point unlock, My Network / My Points, and the registration wizard.
        NET_PT_UNLOCK_CB, NET_PTS_CB, NET_REG_CB, NET_BOT_CB,
        # FILE DELIVERY v34: user-facing Delivery Group wizard + Create
        # Network Bot wizard (owner checks inside the handlers).
        NET_DG_CB, NET_CREATE_CB,
        # MANAGED BOTS v37 (Task 8): the managed create flow's Cancel/Back
        # buttons — user-facing (clears the pending state + returns to
        # My Network; no admin surface involved).
        NET_MANAGED_CB,
    )
    # BOTV13 Phase 2 fix: use the async is_admin() check so DB-stored admins
    # (not just env-based ADMIN_IDS) can access admin callbacks. This is the
    # master gate — every admin callback flows through here.
    if not await is_admin(user.id) and not data.startswith(USER_FACING_PREFIXES):
        await safe_answer_callback(q, "Admins only.", show_alert=True)
        _dt = int((time.time() - _t0) * 1000)
        logger.info("BOT6_CALLBACK_RESULT trace_id=%s callback_data=%s user_id=%s "
                    "message_id=%s success=False duration_ms=%s reason=admin_only_blocked",
                    _trace_id, data_peek[:60], _cb_user, _cb_msg_id, _dt)
        return
    # BOT7: structured auth trace for admin-side callbacks. q.from_user.id is
    # the AUTHORITATIVE acting identity (never q.message.chat.id — the message
    # may have been created in another user's context).
    if not data.startswith(USER_FACING_PREFIXES):
        logger.info("BOT6_ADMIN_AUTH user_id=%s entry_point=callback callback_data=%s "
                    "source=%s result=granted",
                    user.id, data_peek[:40],
                    "env" if user.id in ADMIN_IDS else "db")

    _cb_success = True
    try:
        # ---- v36 CONVERSATION INPUT STATE PURGE (root-cause fix for the
        # live bot-6.log File Delivery Bot failure) ----
        # A text-input conversation (FDB token add, managed create, rotate,
        # ncreate/nreg token, Monetag SDK paste) is ONLY valid while the
        # admin/user stays inside it. ANY other callback — every panel
        # navigation, Back, Cancel, unrelated button — ends it. Input-entry
        # callbacks are exempt: they re-set their state during dispatch,
        # which runs AFTER this purge.
        # This kills the exact bot-6.log sequence: ctl:managed:create →
        # navigate away (state kept) → ctl:fdb:add → typed token hijacked
        # by the stale await_owner/await_token states.
        if not _is_conversation_input_entry(data):
            clear_conversation_input_states(context)
        else:
            # b10 §1 (B10-B2): an input-ENTRY callback is STARTING a new
            # text-input conversation (nreg:token re-arms itself below,
            # ctl:fdb:add / ctl:managed:create / ncreate:token / nleg:token
            # arm their own). The durable token-input intent is retired
            # here so a NEWER flow can never be hijacked by an OLDER
            # pending token intent (the single-active-conversation rule,
            # applied to the durable side). Never logs token material.
            # The OLDER flow's still-visible "Send the Bot Token" prompt
            # is best-effort REPLACED with the honest closed notice (the
            # robust-combination belt-and-braces of spec §1: never leave
            # a prompt the platform would no longer process).
            _stale_intent = None
            try:
                _stale_intent = clear_pending_token_intent(int(user.id))
            except Exception:  # noqa: BLE001 — hygiene only, never breaks UX
                _stale_intent = None
            if _stale_intent:
                try:
                    await context.bot.edit_message_text(
                        int(_stale_intent.get("chat_id")),
                        int(_stale_intent.get("message_id")),
                        "⌛️ Token input closed — no token is being "
                        "accepted for this flow anymore.\n\n"
                        "Start the new input flow you just opened.")
                except Exception:  # noqa: BLE001 — best-effort UX cleanup
                    pass

        # ---- NETWORK PLATFORM (v29) callback dispatch ----
        # All network prefixes (verified non-colliding in the N0 audit) are
        # handled here in ONE place: user flows (ptunlock/npts/nreg/nbot)
        # are authorization-checked inside their handlers; admin flows
        # (net:/gpl:/nbc:) require the master admin gate above.
        if data.startswith(NET_PT_UNLOCK_CB):
            try:
                await handle_pt_unlock(update, context,
                                       int(data[len(NET_PT_UNLOCK_CB):]))
            except ValueError:
                await safe_answer_callback(q, "Invalid request.",
                                           show_alert=True)
        elif data.startswith(NET_PTS_CB):
            await _handle_net_points_callback(update, context, user,
                                              data[len(NET_PTS_CB):])
        elif data.startswith(NET_REG_CB):
            await _handle_net_reg_callback(update, context, user,
                                           data[len(NET_REG_CB):])
        elif data.startswith(NET_BOT_CB):
            await _handle_net_bot_callback(update, context, user,
                                           data[len(NET_BOT_CB):])
        elif data.startswith(NET_DG_CB):
            await handle_delivery_callback(update, context, user,
                                            data[len(NET_DG_CB):])
        elif data.startswith(NET_CREATE_CB):
            await handle_ncreate_callback(update, context, user,
                                           data[len(NET_CREATE_CB):])
        elif data.startswith(NET_MANAGED_CB):
            # MANAGED BOTS v37 (Task 8): user-facing managed create flow
            # navigation (nmg:cancel / nmg:back) — clears the pending
            # state + renders My Network.
            await _handle_net_managed_callback(update, context, user,
                                               data[len(NET_MANAGED_CB):])
        elif data.startswith(NET_LEGACY_CB):
            # MANAGED BOTS v37 (Task 8): the LEGACY manual token import —
            # ADMIN-ONLY (NOT in USER_FACING_PREFIXES; the master admin
            # gate above already blocked non-admins — the handler
            # re-checks for defense in depth).
            await _handle_net_legacy_callback(update, context, user,
                                              data[len(NET_LEGACY_CB):])
        elif data.startswith(CONTROL_CB):
            # Control Bot panel — server-side admin re-check inside.
            await handle_control_callback(update, context,
                                          data[len(CONTROL_CB):])
        elif data.startswith("panel:control"):
            await render_control_panel(update, context)
        elif data.startswith(NET_CB_PREFIX):
            # Admin Network Control Center — admin gate already passed.
            await _handle_net_admin_callback(update, context,
                                             data[len(NET_CB_PREFIX):])
        elif data.startswith(NET_GPL_CB):
            await _handle_gpl_admin_callback(update, context,
                                             data[len(NET_GPL_CB):])
        elif data.startswith(NET_BCAST_CB):
            await _handle_nbc_callback(update, context,
                                       data[len(NET_BCAST_CB):])
        elif data.startswith("panel:network"):
            await render_network_control(update, context)

        # ---- Clear stale wizard states when opening any panel or sub-panel ----
        # This prevents "Send start message text" persisting when admin
        # navigates to Storage, Links, etc.
        # Issue 14/20: also clear on pl:, fj:, file:, filedel:, bcastcancel:,
        # cobrowse:, coldl:, cofile:, comenu:, coclose, cocopy:, rng* (legacy).
        if data.startswith("panel:") or data.startswith("link:") or data.startswith("sm:") \
           or data.startswith("dm:") or data.startswith("bcast:") or data.startswith("set:") \
           or data.startswith("prot:") or data.startswith("ch:") or data.startswith("recent") \
           or data.startswith("pl:") or data.startswith("fj:") or data.startswith("file:") \
           or data.startswith("filedel:") or data.startswith("cobrowse:") \
           or data.startswith("coldl:") or data.startswith("cofile:") \
           or data.startswith("comenu:") or data == "coclose" or data.startswith("cocopy:") \
           or data.startswith("rng") or data == "coclose" \
           or data.startswith("rt:") or data.startswith("plg") \
           or data.startswith("plsearch:") or data.startswith("plsdetail:") \
           or data.startswith("plsback:") or data == "plsclear" \
           or data.startswith("sc:"):
            clear_wizard_states(context)

        # ---- main panels ----
        if data == "panel:main":
            await show_admin_panel(update, context)
        elif data == "panel:storage":
            await storage_panel(update, context)
        # ---- PHASE 7 (Task 1): Storage Center sections ----
        elif data == "sc:status":
            await storage_index_status_panel(update, context)
        elif data == "sc:stats":
            await storage_stats_panel(update, context)
        elif data == "sc:dups":
            await storage_duplicates_panel(update, context)
        elif data == "sc:test":
            await storage_channel_test_panel(update, context)
        elif data.startswith("sc:stop:"):
            try:
                _sc_cid = int(data.split(":", 2)[2])
            except (IndexError, ValueError):
                _sc_cid = 0
            if _sc_cid:
                await storage_stop_index(update, context, _sc_cid)
            else:
                await safe_answer_callback(q, "Invalid channel request.")
        elif data.startswith("sc:statusch:"):
            try:
                _sc_cid = int(data.split(":", 2)[2])
            except (IndexError, ValueError):
                _sc_cid = 0
            if _sc_cid:
                await storage_channel_test_run(update, context, _sc_cid)
            else:
                await safe_answer_callback(q, "Invalid channel request.")
        elif data.startswith("sc:testch:"):
            try:
                _sc_cid = int(data.split(":", 2)[2])
            except (IndexError, ValueError):
                _sc_cid = 0
            if _sc_cid:
                await storage_channel_test_run(update, context, _sc_cid)
            else:
                await safe_answer_callback(q, "Invalid channel request.")
        elif data == "panel:links":
            await links_panel(update, context)
        elif data == "panel:payloads":
            await payloads_panel(update, context)
        elif data == "panel:stats":
            await stats_panel(update, context)
        elif data == "panel:channels":
            await channels_panel(update, context)
        elif data == "panel:startmsg":
            await show_startmsg_panel(update, context)
        elif data == "panel:help":
            # BOT6 Phase 26: admin Help / User Guide editor.
            await show_help_panel(update, context)
        elif data == "panel:settings":
            await settings_panel(update, context)
        elif data == "panel:protection":
            logger.debug("Protection callback received: panel:protection")
            await protection_panel(update, context)
        elif data == "panel:broadcast":
            await broadcast_panel(update, context)
        elif data == "panel:access":
            await access_global_analytics_panel(update, context)
        elif data == "panel:dashedit":
            await safe_answer_callback(q)
            await dashboard_editor_panel(update, context)

        # ---- BOTV13 Phase 2: Admin Dashboard callbacks ----
        elif data == "panel:admin":
            await admin_dashboard_panel(update, context)
        # ---- WEBSITE PHASE 3: Admin Website Control — integrates into the
        # EXISTING Admin Control Center (NO second dashboard). panel:website
        # opens the Website Control panel; every wsite:* callback dispatches
        # to app/presentation/telegram/website_ui.py (admin-gated by the master gate
        # above — wsite: is NOT user-facing).
        elif data == "panel:website":
            await _handle_wsite_panel(update, context)
        elif data.startswith("wsite:"):
            await _handle_wsite_callback(update, context)
        # ---- GAP-CLOSURE: Website CATEGORY admin panels (spec §26-§29) —
        # dispatches to app/presentation/telegram/website_gap_ui.py. The
        # wsitecat: prefix does NOT collide with wsite: (the character
        # after 'wsite' is 'c', not ':') and is admin-gated by the master
        # admin gate above — wsitecat: is NOT user-facing.
        elif data.startswith("wsitecat:"):
            await _handle_wsitecat_callback(update, context)
        # ---- GAP-CLOSURE: centralized ADS PLATFORM admin panels (spec
        # §35-§56) — dispatches to the same website_gap_ui.py module. The
        # wsad: prefix never collides with the user-facing wad: Watch-Ads
        # namespace (w-s-a-d vs w-a-d) and is admin-gated by the master
        # admin gate above — wsad: is NOT user-facing.
        elif data.startswith("wsad:"):
            await _handle_wsad_callback(update, context)
        # ---- Task 9: VIDEO PRE-ROLL ADS admin panel — dispatches to
        # app/presentation/telegram/website_preroll_ui.py. The wspr:
        # prefix was verified collision-free across app/ (no other
        # handler dispatches it) and is admin-gated by the master admin
        # gate above — wspr: is NOT user-facing.
        elif data.startswith("wspr:"):
            await _handle_wspr_callback(update, context)
        # ---- BOT-11 (spec §2-§5): MAIN MINI APP admin panel — dispatches
        # to app/presentation/telegram/website_ui.py (the wsmain: actions:
        # panel / Change URL / Apply to All / Refresh; lives next to the
        # website_public_base_url editing surface). The wsmain: prefix was
        # verified collision-free across app/ and is admin-gated by the
        # master admin gate above — wsmain: is NOT user-facing.
        elif data.startswith("wsmain:"):
            await _handle_wsmain_callback(update, context)
        elif data == "admn:list":
            await admin_list_panel(update, context)
        elif data == "admn:add":
            await admin_add_prompt(update, context)
        elif data == "admn:activity":
            await admin_activity_panel(update, context)
        elif data == "admn:perms":
            await safe_answer_callback(q, "Use Admins list → select an admin to configure permissions.", show_alert=False)
            await admin_list_panel(update, context)
        elif data.startswith("admn:detail:"):
            target = int(data.split(":", 2)[2])
            await admin_detail_panel(update, context, target)
        elif data.startswith("admn:toggle:"):
            target = int(data.split(":", 2)[2])
            # Only admins with manage_admins can toggle.
            if not await has_permission(user.id, PERM_MANAGE_ADMINS):
                logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=toggle_admin "
                            "target=%s result=denied reason=missing_perm",
                            user.id, target)
                await safe_answer_callback(q, "You don't have permission to manage admins.", show_alert=True)
                return
            if target == _get_owner_id():
                await safe_answer_callback(q, "Cannot disable the owner.", show_alert=True)
                return
            cur = await db.conn.execute("SELECT is_active FROM admins WHERE user_id = ? OR user_id = ?",
                                        (target, str(target)))
            r = await cur.fetchone()
            if r:
                new_val = 0 if r["is_active"] else 1
                await db.conn.execute(
                    "UPDATE admins SET is_active = ?, updated_at = ? WHERE user_id = ? OR user_id = ?",
                    (new_val, _now_iso(), target, str(target)),
                )
                await db.conn.commit()
                await log_admin_action(user.id, "toggle_admin", "admin", target,
                                        f"active={new_val}")
                logger.info("BOT6_ADMIN_%s actor=%s target=%s is_active=%s",
                            "ENABLE" if new_val else "DISABLE", user.id, target, new_val)
            await admin_detail_panel(update, context, target)
        elif data.startswith("admn:remove:"):
            target = int(data.split(":", 2)[2])
            if not await has_permission(user.id, PERM_MANAGE_ADMINS):
                logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=remove_admin "
                            "target=%s result=denied reason=missing_perm",
                            user.id, target)
                await safe_answer_callback(q, "You don't have permission to remove admins.", show_alert=True)
                return
            if target == _get_owner_id():
                await safe_answer_callback(q, "Cannot remove the owner.", show_alert=True)
                return
            await db.conn.execute(
                "DELETE FROM admins WHERE user_id = ? OR user_id = ?",
                (target, str(target)))
            await db.conn.commit()
            await log_admin_action(user.id, "remove_admin", "admin", target)
            logger.info("BOT6_ADMIN_REMOVE actor=%s target=%s", user.id, target)
            await admin_list_panel(update, context)
        elif data.startswith("admn:editperms:"):
            target = int(data.split(":", 2)[2])
            if not await has_permission(user.id, PERM_MANAGE_PERMISSIONS):
                logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=edit_perms "
                            "target=%s result=denied reason=missing_perm",
                            user.id, target)
                await safe_answer_callback(q, "You don't have permission to edit permissions.", show_alert=True)
                return
            if target == _get_owner_id():
                await safe_answer_callback(q, "Owner permissions are always full.", show_alert=True)
                return
            # Show the permission editor (toggle each permission).
            await admin_permission_editor(update, context, target)
        elif data == "admn:noop":
            await safe_answer_callback(q)
        elif data.startswith("admnew:"):
            # BOT7 §9: post-add screen actions for a freshly added admin.
            parts = data.split(":", 2)
            target = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
            if not target:
                await safe_answer_callback(q, "This action has expired or is no longer valid.",
                                           show_alert=True)
                return
            action = parts[1]
            if action == "perms":
                if not await has_permission(user.id, PERM_MANAGE_PERMISSIONS):
                    await safe_answer_callback(q, "You don't have permission to edit permissions.",
                                               show_alert=True)
                    return
                await safe_answer_callback(q)
                await admin_permission_editor(update, context, target)
                return
            if action == "recommended":
                await _admnew_grant(update, context, target,
                                    list(RECOMMENDED_ADMIN_PERMISSIONS),
                                    "Recommended Access")
                return
            if action == "full":
                await _admnew_grant(update, context, target,
                                    list(ALL_PERMISSIONS), "Full Access")
                return
            if action == "disable":
                if not await has_permission(user.id, PERM_MANAGE_ADMINS):
                    await safe_answer_callback(q, "You don't have permission to manage admins.",
                                               show_alert=True)
                    return
                if target == _get_owner_id():
                    await safe_answer_callback(q, "Cannot disable the owner.", show_alert=True)
                    return
                await db.conn.execute(
                    "UPDATE admins SET is_active = 0, updated_at = ? WHERE user_id = ? OR user_id = ?",
                    (_now_iso(), target, str(target)),
                )
                await db.conn.commit()
                await log_admin_action(user.id, "disable_admin", "admin", target)
                logger.info("BOT6_ADMIN_DISABLE actor=%s target=%s", user.id, target)
                await safe_answer_callback(q, "\u23F8 Admin disabled.")
                await admin_list_panel(update, context)
                return
            await safe_answer_callback(q, "This action has expired or is no longer valid.",
                                       show_alert=True)
        elif data.startswith("admperm:"):
            # BOTV13 Phase 2: toggle a single permission for an admin.
            # Security: caller must have manage_permissions. Cannot grant a
            # permission the caller doesn't have (no self-escalation).
            parts = data.split(":", 2)
            target = int(parts[1])
            perm = parts[2]
            if not await has_permission(user.id, PERM_MANAGE_PERMISSIONS):
                logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=toggle_perm "
                            "target=%s perm=%s result=denied reason=missing_perm",
                            user.id, target, perm)
                await safe_answer_callback(q, "You don't have permission to edit permissions.", show_alert=True)
                return
            if target == _get_owner_id():
                await safe_answer_callback(q, "Owner permissions are always full.", show_alert=True)
                return
            # No self-escalation: cannot grant a permission you don't have.
            if not await has_permission(user.id, perm):
                logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=toggle_perm "
                            "target=%s perm=%s result=denied reason=no_self_grant",
                            user.id, target, perm)
                await safe_answer_callback(q, f"You cannot grant '{perm}' — you don't have it yourself.", show_alert=True)
                return
            cur = await db.conn.execute(
                "SELECT permissions FROM admins WHERE user_id = ? OR user_id = ?",
                (target, str(target)))
            r = await cur.fetchone()
            if not r:
                await safe_answer_callback(q, "Admin not found.", show_alert=True)
                return
            import json as _json
            perms = {}
            try:
                perms = _json.loads(r["permissions"]) if r["permissions"] else {}
            except (ValueError, TypeError):
                pass
            # Toggle.
            if perms.get(perm):
                del perms[perm]
                action_detail = f"removed {perm}"
            else:
                perms[perm] = True
                action_detail = f"granted {perm}"
            await db.conn.execute(
                "UPDATE admins SET permissions = ?, updated_at = ? WHERE user_id = ? OR user_id = ?",
                (_json.dumps(perms), _now_iso(), target, str(target)),
            )
            await db.conn.commit()
            await log_admin_action(user.id, "edit_permission", "admin", target, action_detail)
            logger.info("BOT6_ADMIN_PERMISSION_CHANGE actor=%s target=%s detail=%s",
                        user.id, target, action_detail)
            await admin_permission_editor(update, context, target)

        # ---- V11: Dashboard Editor callbacks (single template, auto-save) ----
        # New routes: dash:edit, dash:settings, dash:preview, dash:reset,
        # dash:toggle:<key>, dash:setbar:<style>.
        # Legacy routes (dash:cat:, dash:field:, dash:settheme:, dash:barstyle,
        # dash:edit:<key>, dash:save, dash:cancel, dash:back, dash:discard) are
        # kept as backward-compat aliases so any stale keyboard still resolves.
        elif data == "dash:edit":
            # V11: prompt for the complete template.
            await safe_answer_callback(q)
            await dashboard_editor_edit(update, context)
        elif data == "dash:settings":
            # V11: open the Settings submenu.
            await safe_answer_callback(q)
            await dashboard_editor_settings(update, context)
        elif data == "dash:media":
            # V14: open the Dashboard Media banner submenu.
            await safe_answer_callback(q)
            await dashboard_editor_media(update, context)
        elif data == "dash:mediaupload":
            # V14: prompt admin to upload a dashboard banner.
            await safe_answer_callback(q)
            context.user_data["dash_media_upload"] = True
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F4E4 Dashboard Banner\n\n"
                "Send a photo, video, or animation to use as the banner.\n"
                "This appears ABOVE the referral dashboard.\n\n"
                "Accepted: Photo, Video, Animation")
        elif data == "dash:mediaremove":
            # V14: remove the dashboard banner.
            await safe_answer_callback(q, "\u274C Banner removed.")
            await _dash_save_setting("dashboard_media_file_id", "")
            await _dash_save_setting("dashboard_media_type", "")
            await dashboard_editor_media(update, context)
        elif data.startswith("dash:toggle:"):
            # V11: toggle a boolean setting (auto-save) → return to Settings.
            await safe_answer_callback(q)
            key = data.split(":", 2)[2]
            settings = await _dash_load_settings(context)
            cur = settings.get(key, "0")
            new_val = "0" if cur == "1" else "1"
            await _dash_save_setting(key, new_val)
            await dashboard_editor_settings(update, context)
        elif data.startswith("dash:setbar:"):
            # V11: set progress bar style (auto-save) → return to Settings.
            await safe_answer_callback(q)
            sid = data.split(":", 2)[2]
            await _dash_save_setting("progress_bar_style", sid)
            await dashboard_editor_settings(update, context)
        elif data == "dash:preview":
            await dashboard_editor_preview(update, context)
        elif data == "dash:reset":
            # V11: reset DB to defaults (restores default template + settings).
            await safe_answer_callback(q)
            context.user_data.pop("dashboard_draft", None)
            context.user_data.pop("dash_edit_key", None)
            context.user_data.pop("dash_edit_template", None)
            await db.reset_dashboard_settings()
            await safe_answer_callback(q, "\u2705 Reset to defaults.")
            await dashboard_editor_panel(update, context)
        # ---- Legacy backward-compat aliases (stale keyboards still resolve) ----
        elif data.startswith("dash:cat:") or data.startswith("dash:field:") or \
             data.startswith("dash:settheme:") or data == "dash:barstyle" or \
             data.startswith("dash:edit:"):
            # V10 categorized routes → redirect to the V11 editor panel.
            await safe_answer_callback(q, "Dashboard editor updated. Redirecting...")
            await dashboard_editor_panel(update, context)
        elif data == "dash:save":
            # V10 save → flush any legacy draft, reopen editor.
            await safe_answer_callback(q)
            draft = context.user_data.pop("dashboard_draft", None)
            if draft:
                for k, v in draft.items():
                    await db.set_dashboard_setting(k, v)
            await safe_answer_callback(q, "\u2705 Saved.")
            await dashboard_editor_panel(update, context)
        elif data in ("dash:cancel", "dash:back", "dash:discard"):
            # V10 cancel/back/discard → return to main admin panel.
            await safe_answer_callback(q, "Back to admin panel.")
            context.user_data.pop("dashboard_draft", None)
            context.user_data.pop("dash_edit_key", None)
            context.user_data.pop("dash_edit_template", None)
            await show_admin_panel(update, context)

        # ---- Access Engine V1: Payload Creation Wizard callbacks ----
        elif data == "pcw:start":
            await safe_answer_callback(q)
            await pcw_start(update, context, index_id=None)
        elif data.startswith("pcw:startfile:"):
            await safe_answer_callback(q)
            await pcw_start(update, context, index_id=int(data.split(":", 2)[1]))
        elif data.startswith("pcw:edit:"):
            await safe_answer_callback(q)
            await pcw_start_edit(update, context, int(data.split(":", 2)[2]))
        elif data == "pcw:cancel":
            # V15: Cancel discards wizard state. In edit mode, return to the
            # Payload Details page (not the link generator / admin panel).
            await safe_answer_callback(q, "Wizard cancelled.")
            state = _pcw_get(context)
            edit_pid = state.get("edit_payload_id") if state else None
            if state:
                logger.info("BOT6_ADMIN_WIZARD_CANCEL wizard=pcw user_id=%s "
                            "mode=%s payload_id=%s reason=user_cancel",
                            user.id, state.get("mode"), edit_pid)
                await pcw_log_wizard_event("wizard_cancelled",
                    payload_id=edit_pid)
            _pcw_clear(context)
            if edit_pid is not None and await nav_return(update, context):
                return  # returned to payload details
            await links_panel(update, context)
        elif data.startswith("pcw:recreate:"):
            # BOT6 P13: Recreate — start a NEW collection wizard using the
            # existing collection's files as the starting point. The original
            # payload + routing slug remain unchanged. A NEW payload ID + slug
            # will be generated on completion.
            coll_code = data.split(":", 2)[2]
            coll = await db.get_collection(coll_code)
            if not coll:
                await safe_answer_callback(q, "Collection not found.", show_alert=True)
                return
            items = await db.get_collection_items(coll_code)
            if not items:
                await safe_answer_callback(q, "No files in this collection.", show_alert=True)
                return
            channel_id = int(coll["channel_id"])
            msg_ids = [int(it["message_id"]) for it in items]
            logger.info("BOT6_PAYLOAD_RECREATE old_collection_id=%s channel=%s file_count=%s",
                        coll_code, channel_id, len(msg_ids))
            await safe_answer_callback(q, "\u267B\uFE0F Starting Recreate — new payload will be created.")
            # Start a NEW collection wizard with the same files.
            await pcw_start_collection(update, context, channel_id, msg_ids)
        elif data == "pcw:home":
            # V15: Home returns to the main admin panel. In edit mode, prefer
            # returning to the Payload Details page if a nav context exists.
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                logger.info("BOT6_ADMIN_WIZARD_CANCEL wizard=pcw user_id=%s "
                            "mode=%s payload_id=%s reason=user_home",
                            user.id, state.get("mode"),
                            state.get("edit_payload_id"))
                await pcw_log_wizard_event("wizard_cancelled",
                    payload_id=state.get("edit_payload_id"))
            _pcw_clear(context)
            if await nav_return(update, context):
                return  # returned to payload details
            await show_admin_panel(update, context)
        elif data == "pcw:next":
            await safe_answer_callback(q)
            await pcw_go_next(update, context)
        elif data == "pcw:back":
            await safe_answer_callback(q)
            await pcw_go_back(update, context)
        elif data == "pcw:nameinput":
            # "Send Name" button — switch to awaiting_name so the next text
            # message is captured as the custom payload name.
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                state["step"] = "awaiting_name"
                await safe_send_text(context.bot, q.message.chat_id,
                    "\U0001F4DD Send the custom payload name now\n"
                    "Human-readable names are accepted (spaces, mixed case OK; max 128).")
        elif data == "pcw:nameskip":
            # V18 BUGFIX: only auto-generate if no custom name is set.
            await safe_answer_callback(q)
            state = _pcw_get(context)

            if not state:
                await safe_answer_callback(q, "Wizard session expired.", show_alert=True)
                return

            # GOOD CODE: Checks if a custom name already exists first
            if not state.get("name"):
                # No custom name set → auto-generate.
                auto_name = await pcw_auto_generate_name(state)
                state["name"] = auto_name
                logger.info("Wizard: [nameskip] auto-generated name='%s' (no custom name was set).", auto_name)
                await safe_answer_callback(q, f"✅ Auto-generated: {auto_name}")
            else:
                # Custom name already set → preserve it, just advance.
                logger.info("Wizard: [nameskip] preserving existing custom name='%s' (Skip does NOT overwrite).", state["name"])
                await safe_answer_callback(q, f"✅ Using: {state['name']}")

            if _pcw_has_file(state):
                await pcw_show_policy_step(update, context)
            else:
                await pcw_show_file_step(update, context)
        elif data.startswith("pcw:policy:"):
            await safe_answer_callback(q)
            new_p = data.split(":", 2)[2]
            state = _pcw_get(context)
            if state:
                # Future policies fall back to FORCE_JOIN at create time.
                state["access_policy"] = (new_p if new_p in ACCESS_POLICIES_IMPLEMENTED
                                          else ACCESS_POLICY_FORCE_JOIN)
                await safe_answer_callback(q, f"Policy: {state['access_policy']}")
                # Analytics: policy selected + referral enabled (if applicable).
                await pcw_log_wizard_event("policy_selected",
                    payload_id=state.get("edit_payload_id"))
                if state["access_policy"] == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
                    await pcw_log_wizard_event("referral_enabled",
                        payload_id=state.get("edit_payload_id"))
            await pcw_render_current_step(update, context)
        elif data.startswith("pcw:req:"):
            await safe_answer_callback(q)
            n = max(0, int(data.split(":", 2)[2]))
            state = _pcw_get(context)
            if state:
                state["required_referrals"] = n
                await safe_answer_callback(q, f"Required referrals: {n}")
            await pcw_render_current_step(update, context)
        elif data.startswith("pcw:wad:"):
            # WATCH_AD (v25): wizard Step 4 toggle (Back preserves state,
            # Cancel never touches the DB, Create persists it).
            await safe_answer_callback(q)
            try:
                flag = 1 if data.split(":", 2)[2] == "1" else 0
            except IndexError:
                flag = 0
            state = _pcw_get(context)
            if state:
                state["watch_ads_enabled"] = flag
                await safe_answer_callback(
                    q, "\U0001F3AC Watch Ads: Enabled" if flag
                    else "\U0001F3AC Watch Ads: Disabled")
                await pcw_log_wizard_event(
                    "watch_ads_" + ("enabled" if flag else "disabled"),
                    payload_id=state.get("edit_payload_id"))
            await pcw_render_current_step(update, context)
        elif data == "pcw:reqcustom":
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                state["step"] = "reqcustom"
                await safe_send_text(context.bot, q.message.chat_id,
                    "\U0001F522 Custom Required Referrals\n\nSend a number (0 = instant unlock).")
        elif data.startswith("pcw:preview:"):
            await safe_answer_callback(q)
            m = data.split(":", 2)[2]
            if m not in PREVIEW_MODES_ALL:
                m = PREVIEW_MODE_DISABLED
            state = _pcw_get(context)
            if state:
                state["preview_mode"] = m
                await safe_answer_callback(q, f"Preview mode: {m}")
                if m != PREVIEW_MODE_DISABLED:
                    await pcw_log_wizard_event("preview_enabled",
                        payload_id=state.get("edit_payload_id"))
                # V3: If "select" mode chosen, show the collection preview selector.
                if m == PREVIEW_MODE_SELECT and _pcw_is_collection(state):
                    await pcw_show_collection_preview_selector(update, context)
                    return
            await pcw_render_current_step(update, context)
        elif data == "pcw:prevmedia":
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                state["step"] = "prevmedia"
                # V14: set custom mode so the resolver knows to use the uploaded media.
                state["preview_mode"] = PREVIEW_MODE_CUSTOM
                await safe_send_text(context.bot, q.message.chat_id,
                    "\U0001F4E4 Upload Preview\n\n"
                    "Send a photo, video, or animation to use as the preview.\n\n"
                    "Accepted: Photo, Video, Animation\n"
                    "Rejected: Documents, Audio, Voice, Stickers")
        elif data == "pcw:prevmediause":
            # Confirm the uploaded preview media and return to preview step.
            await safe_answer_callback(q, "\u2705 Preview media saved.")
            state = _pcw_get(context)
            if state:
                state["step"] = "preview"
                await pcw_show_preview_step(update, context)
        elif data == "pcw:prevmediaremove":
            # Remove the uploaded preview media.
            await safe_answer_callback(q, "\u274C Preview media removed.")
            state = _pcw_get(context)
            if state:
                state["preview_media_file_id"] = None
                state["preview_media_type"] = None
                state["step"] = "preview"
                await pcw_show_preview_step(update, context)
        elif data == "pcw:prevmediaskip":
            # Skip preview media — set preview_mode to disabled and continue.
            await safe_answer_callback(q, "\u23ED\uFE0F Preview media skipped.")
            state = _pcw_get(context)
            if state:
                state["preview_media_file_id"] = None
                state["preview_media_type"] = None
                state["preview_mode"] = PREVIEW_MODE_DISABLED
                state["step"] = "preview"
                await pcw_show_preview_step(update, context)
        elif data == "pcw:prevdesc":
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                state["step"] = "prevdesc"
                await safe_send_text(context.bot, q.message.chat_id,
                    "\U0001F4DD Preview Text\n\nSend the preview text to show "
                    "locked users (shown above the locked screen).")
        elif data == "pcw:advdelivery":
            # V3: Advanced Delivery overlay.
            await safe_answer_callback(q)
            await pcw_show_advanced_delivery(update, context)
        elif data.startswith("pcw:prevselect:"):
            # V3: Collection preview file selection.
            await safe_answer_callback(q)
            idx = int(data.split(":", 2)[2])
            state = _pcw_get(context)
            if state:
                # Load the selected file's media info.
                frow = await db.get_indexed_file_by_id(idx)
                if frow and frow["media_type"] in PREVIEW_COMPATIBLE_TYPES:
                    state["preview_media_file_id"] = frow["file_id"]
                    state["preview_media_type"] = frow["media_type"]
                    state["preview_mode"] = PREVIEW_MODE_SELECT
                    state["preview_source"] = "select"
                await pcw_show_preview_step(update, context)
        elif data.startswith("pcw:timer:"):
            await safe_answer_callback(q)
            secs = int(data.split(":", 2)[2])
            val = None if secs == INHERIT_SENTINEL else secs
            state = _pcw_get(context)
            if state:
                state["delete_after"] = val
                await safe_answer_callback(q, f"Delete timer: {_delete_timer_label(val)}")
            await pcw_render_current_step(update, context)
        elif data == "pcw:onetimetoggle":
            await safe_answer_callback(q)
            state = _pcw_get(context)
            if state:
                state["one_time"] = 0 if state["one_time"] else 1
                await safe_answer_callback(q,
                    f"One-time: {'ON' if state['one_time'] else 'OFF'}")
            await pcw_render_current_step(update, context)
        elif data == "pcw:create":
            await create_payload_from_wizard(update, context)

        # ---- link generator wizards ----
        elif data == "link:single":
            context.user_data["awaiting_single_msgid"] = True
            await safe_send_text(context.bot, q.message.chat_id,
                "*\U0001F4C4 Single File*\n\nSend the *Message ID* of the "
                "indexed file (e.g. `8619`) — or the exact identity pair "
                "`channel_id:message_id` (e.g. `-1004460709020:872`) when "
                "the same message id exists in more than one channel.\n\n"
                "The Payload Configuration Wizard will open next so you can\n"
                "set access policy, referral, preview, and delivery.",
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data.startswith("pcwmsg:"):
            # V25 FINAL §12 (bot-35.log message 872): the EXACT
            # channel+message identity picked from the disambiguation
            # list — no heuristic, no cross-channel substitution.
            await safe_answer_callback(q)
            try:
                _, ch_s, mid_s = data.split(":", 2)
                ch_id, mid = int(ch_s), int(mid_s)
            except (ValueError, TypeError):
                await safe_answer_callback(
                    q, "Invalid selection.", show_alert=True)
                return
            frow = await db.get_indexed_file_by_channel_message(ch_id, mid)
            if not frow:
                await safe_send_text(
                    context.bot, q.message.chat_id,
                    f"\u274C No indexed file found for the exact pair "
                    f"{ch_id}:{mid} — it may have been removed. Reindex "
                    f"the storage channel and try again.")
                return
            clear_wizard_states(context)
            state = _pcw_new_state(index_id=int(frow["id"]))
            state["owner_id"] = q.from_user.id if q.from_user else 0
            context.user_data[PCW_KEY] = state
            logger.info(
                "BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s "
                "mode=create_single_msgid channel_id=%s message_id=%s "
                "file_pk=%s (exact identity picked from the "
                "disambiguation list)",
                state["owner_id"], ch_id, mid, int(frow["id"]))
            # Namespace-bound call (like every sibling pcw_* site in
            # this router): the module-level import bypassed the shared
            # namespace, whose rebound _pcw_get resolves PCW_KEY through
            # the NAMESPACE globals — wizard.py's own module globals
            # lack PCW_KEY (state.py owns it), so the module import
            # crashed with NameError at runtime (the §8 pcwmsg defect).
            await pcw_show_name_step(update, context)
        elif data == "link:fwd":
            # Forward File(s) — auto-detects single vs collection, then opens
            # the Payload Configuration Wizard (no immediate link generation).
            context.user_data["awaiting_fwd_batch"] = True
            context.user_data.pop("fwd_batch_multi", None)
            context.user_data.pop("fwd_batch_multi_timer", None)
            await safe_send_text(
                context.bot, q.message.chat_id,
                "\U0001F4E4 Forward File(s)\n\n"
                "Forward one or more files from a storage channel now (one by "
                "one or as an album).\n\n"
                "\u2022 1 file  \u2192 Single File wizard\n"
                "\u2022 2+ files \u2192 Collection wizard\n\n"
                "The bot auto-detects the type and opens the Payload Configuration "
                "Wizard so you can set access policy, referral, preview, and delivery.",
            )
        elif data == "link:range":
            # Offer two methods: manual IDs or forward first/last file.
            kb_range = InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4DD Enter IDs Manually", callback_data="link:rangemanual")],
                [InlineKeyboardButton("\U0001F4E4 Forward First + Last File", callback_data="link:fwdrange")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
            ])
            await safe_edit_text(q,
                "*\U0001F4E6 Collection Link*\n\nChoose how to define the collection:",
                parse_mode=ParseMode.MARKDOWN, reply_markup=kb_range
            )
        elif data.startswith("colsum:continue:"):
            # Collection summary "Continue" — launch the wizard with the
            # resolved message_ids. The collection is NOT created yet.
            msg_ids = context.user_data.pop("colsum_msg_ids", None)
            chan = context.user_data.pop("colsum_channel_id", None)
            if not msg_ids or chan is None:
                await safe_answer_callback(q, "Collection session expired. Please restart.", show_alert=True)
                await links_panel(update, context)
                return
            await safe_answer_callback(q)
            await pcw_start_collection(update, context, chan, msg_ids)
        elif data == "colsum:cancel":
            context.user_data.pop("colsum_msg_ids", None)
            context.user_data.pop("colsum_channel_id", None)
            await safe_answer_callback(q, "Cancelled.")
            await links_panel(update, context)
        elif data == "link:rangemanual":
            context.user_data["awaiting_range_start"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "*\U0001F4E6 Collection Link*\n\nSend the *Start Message ID* "
                "(e.g. `8619`).",
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data == "link:fwdrange":
            context.user_data["awaiting_fwd_range_first"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "*\U0001F4E4 Forward First File*\n\nForward the *first* file of the "
                "collection from a storage channel.",
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data == "link:search":
            context.user_data["awaiting_search_msgid"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "*\U0001F50D Search Message ID*\n\nSend the *Message ID* to look "
                "up (e.g. `8619`).",
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data == "link:recent":
            await recent_links_panel(update, context)
        elif data.startswith("rngcopy:"):
            # Legacy range copy — auto-migrate to collection link.
            parts = data.split(":")
            if len(parts) >= 3 and parts[1].isdigit() and parts[2].isdigit():
                sid, eid = int(parts[1]), int(parts[2])
                code = await _migrate_legacy_range_to_collection(sid, eid, user_id=user.id)
                if code:
                    await safe_send_text(
                        context.bot, q.message.chat_id,
                        f"\U0001F4CB Copy this collection link:\n{build_collection_link(code)}",
                    )
                else:
                    await safe_answer_callback(q, "Collection no longer available.", show_alert=True)
        # (fwdbatchcoll: / fwdbatchindiv: removed — dead: no button ever
        #  generated these callbacks. Multi-forward collection generation is
        #  handled automatically by _process_forward_batch_delayed.)
        elif data.startswith("linkpreview:m:"):
            # Admin Preview V2: shows ACTUAL media (photo/video/document/etc).
            message_id = int(data.split(":")[2])
            file_row = await db.get_indexed_file_by_message_id(message_id)
            if file_row:
                await _admin_preview_single(update, context, user, file_row)
            else:
                await safe_answer_callback(q, "File not found.", show_alert=True)
        elif data.startswith("linkpreview:c:"):
            # Admin Preview V2: collection preview — sends actual media via
            # album chunking (10+10+5...).
            code = data.split(":", 2)[2]
            files = await _load_collection_files(code)
            if files:
                await _admin_preview_collection(update, context, user, code, files)
            else:
                await safe_answer_callback(q, "No files in collection.", show_alert=True)
        # ---- BOT6 P14-18: Manage Files panel for existing collections ----
        elif data.startswith("managefiles:"):
            coll_code = data.split(":", 1)[1]
            await manage_files_panel(update, context, coll_code)
        elif data.startswith("mfadd:"):
            coll_code = data.split(":", 1)[1]
            await manage_files_add_prompt(update, context, coll_code)
        elif data.startswith("mfremove:"):
            parts = data.split(":", 2)
            coll_code = parts[1]
            msg_id = int(parts[2])
            await manage_files_remove_confirm(update, context, coll_code, msg_id)
        elif data.startswith("mfremoveyes:"):
            parts = data.split(":", 2)
            coll_code = parts[1]
            msg_id = int(parts[2])
            await manage_files_remove_execute(update, context, coll_code, msg_id)
        elif data.startswith("mfup:"):
            # V25 FINAL §15 — Manage Files REORDER (position-keyed swap).
            parts = data.split(":", 2)
            await manage_files_move(
                update, context, parts[1], int(parts[2]), "up")
        elif data.startswith("mfdown:"):
            parts = data.split(":", 2)
            await manage_files_move(
                update, context, parts[1], int(parts[2]), "down")
        elif data == "mffiles":
            await manage_files_panel(update, context, context.user_data.get("_mf_coll_code", ""))

        elif data.startswith("linkpreview:r:"):
            # Legacy range preview — auto-migrate to collection, then preview.
            parts = data.split(":")
            start_id, end_id = int(parts[2]), int(parts[3])
            code = await _migrate_legacy_range_to_collection(start_id, end_id, user_id=user.id)
            if code:
                files = await _load_collection_files(code)
            else:
                files = []
            if files:
                await safe_answer_callback(q, f"Preview: {len(files)} files")
                prev_protect = await resolve_delivery_protection()
                preview_ids: List[int] = []
                for f in files[:3]:
                    mid = await send_file(context.bot, user.id, f,
                                          protect_content=prev_protect)
                    if mid:
                        preview_ids.append(mid)
                    await asyncio.sleep(COLLECTION_SEND_DELAY)
                extra_msg = None
                if len(files) > 3:
                    extra_msg = await safe_send_text(
                        context.bot, user.id,
                        f"...and {len(files) - 3} more in this collection.",
                    )
                    if extra_msg and extra_msg.message_id:
                        preview_ids.append(extra_msg.message_id)
                if preview_ids:
                    asyncio.create_task(
                        schedule_admin_preview_delete(context.bot, user.id, preview_ids)
                    )
            else:
                await safe_answer_callback(q, "No files in range.", show_alert=True)
        elif data.startswith("filepreview:"):
            # Admin Preview V2: show actual media for a file by its DB id.
            fid = int(data.split(":", 1)[1])
            file_row = await db.get_indexed_file_by_id(fid)
            if file_row:
                await _admin_preview_single(update, context, user, file_row)
            else:
                await safe_answer_callback(q, "File not found.", show_alert=True)
        elif data.startswith("fwdindex:"):
            # Index a forwarded file on demand, then show its single-file link.
            parts = data.split(":")
            channel_id = int(parts[1])
            message_id = int(parts[2])
            info, fwd_mid = await fetch_channel_media(context.bot, user.id, channel_id, message_id)
            if fwd_mid:
                try:
                    await context.bot.delete_message(user.id, fwd_mid)
                except TelegramError:
                    pass
            if not info:
                await safe_answer_callback(q, "No media found in that message.", show_alert=True)
                return
            existing = await db.get_indexed_file_by_channel_msg(channel_id, message_id)
            if not existing:
                file_pk = await db.add_indexed_file(channel_id, message_id, info)
                if await auto_payload_active() and info.get("file_name"):
                    slug = sanitize_slug(info["file_name"])
                    if slug:
                        await create_unique_payload(slug, file_pk)
            await safe_answer_callback(q, "\u2705 Indexed!")
            await single_file_link_result(update, context, message_id)

        # ---- storage sub-panels ----
        elif data == "panel:recent":
            await send_recent_files_panel(update, sort="newest", page=0)
        elif data == "panel:idxhealth":
            await index_health_panel(update, context)
        elif data.startswith("idxhealthch:"):
            cid = int(data.split(":", 1)[1])
            ch = await db.get_storage_channel(cid)
            ch_title = ch['title'] if ch else f"Channel {cid}"
            status_msg = await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F50D Verifying integrity: {ch_title}...")
            asyncio.create_task(
                verify_index_integrity(context.bot, user.id, cid, status_msg)
            )
        elif data == "panel:reindex":
            await reindex_panel(update, context)
        # (panel:storagestats removed — dead: no button generated it; the
        #  Storage panel's Statistics button routes to panel:stats instead.)
        # ---- Issue #84: Unified Retrieve System panel (branding UI removed) ----
        elif data == "panel:retrieve":
            await retrieve_panel(update, context)
        elif data == "rt:toggle":
            await db.set_setting("retrieve_enabled",
                                 "0" if await db.get_setting_bool("retrieve_enabled", True) else "1")
            await retrieve_panel(update, context)
        elif data == "rt:edittext":
            context.user_data["awaiting_retrieve_text"] = True
            cur_text = await get_retrieve_text()
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Retrieve Text\n\n"
                "Send the new retrieve message text.\n"
                "Placeholder: {count} (file count, for collections)\n"
                "Send /skip to reset to default.\n\n"
                f"Current:\n{cur_text}")
        elif data == "rt:editbutton":
            context.user_data["awaiting_retrieve_button"] = True
            cur_btn = await get_retrieve_button()
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F518 Edit Button Text\n\n"
                "Send the new retrieve button label.\n\n"
                f"Current: {cur_btn}")
        elif data == "rt:setlimit":
            context.user_data["awaiting_retrieve_limit"] = True
            cur_lim = await db.get_setting_int("retrieve_limit", 0)
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F522 Set Retrieve Limit\n\n"
                "Send a number (0 = unlimited).\n"
                f"Current: {cur_lim}")
        elif data == "rt:setwindow":
            context.user_data["awaiting_retrieve_window"] = True
            cur_win = await db.get_setting_int("retrieve_window_hours", 0)
            await safe_send_text(context.bot, q.message.chat_id,
                "\u23F0 Set Retrieve Window (hours)\n\n"
                "Send a number (0 = no time limit).\n"
                f"Current: {cur_win}")
        elif data == "rt:preview":
            await retrieve_preview(context.bot, q.message.chat_id)
        elif data == "rt:reset":
            await db.set_setting("retrieve_message_text", DEFAULT_RETRIEVE_TEXT)
            await db.set_setting("retrieve_message_button", DEFAULT_RETRIEVE_BUTTON)
            await safe_answer_callback(q, "\u2705 Retrieve text + button reset to defaults.")
            await retrieve_panel(update, context)
        elif data == "rt:analytics":
            await retrieve_analytics_panel(update, context)
        # (panel:branding / br:* / cb:* / cbpanel: / coback: removed in Issue #84.
        #  Branding UI is gone; collection_branding_panel/preview functions deleted.)

        # ---- recent files: sort + pagination + search ----
        elif data.startswith("recentsort:"):
            skey = data.split(":", 1)[1]
            await send_recent_files_panel(update, sort=skey, page=0)
        elif data.startswith("recentpage:"):
            parts = data.split(":")
            await send_recent_files_panel(update, sort=parts[1], page=int(parts[2]))
        elif data == "recentsearch":
            context.user_data["awaiting_file_search"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send a file name (or part of it) to search:"
            )

        # ---- analytics sub-panels ----
        elif data == "panel:top":
            await top_panel(update, context)
        elif data == "panel:topdl":
            await top_downloads_panel(update, context)

        # ---- protection ----
        # (prot:status removed — dead: no button generated it. The live
        #  protection dashboard already shows every toggle's state.)
        elif data == "prot:preview":
            await protection_preview_panel(update, context)
        elif data.startswith("prot:toggle:"):
            key = data.split(":", 2)[2]
            await toggle_protection(update, context, key)

        # ---- Protection V3 (simplified engine) ----
        elif data.startswith("prot3:adv:"):
            key = data.split(":", 2)[2]
            logger.debug("Protection callback route: prot3:adv:%s", key)
            await toggle_protection_advanced(update, context, key)
        elif data.startswith("prot3:"):
            key = data.split(":", 1)[1]
            logger.debug("Protection callback route: prot3:%s", key)
            await toggle_protection_v3(update, context, key)

        # ---- broadcast (Issue 11: single Send Broadcast Message flow) ----
        elif data == "bcast:send":
            context.user_data["awaiting_broadcast"] = True
            context.user_data.pop("bcast_pending", None)  # clear stale confirm
            # BOT7 Broadcast UI upgrade: show the live recipient count and an
            # explicit Cancel button while composing.
            try:
                _rcpts = await db.all_user_ids()
                _n_rcpts = len(_rcpts)
            except Exception:  # noqa: BLE001
                _n_rcpts = 0
            await safe_send_text(
                context.bot, q.message.chat_id,
                "\U0001F4E3 COMPOSE BROADCAST\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"\U0001F465 Will be sent to: {_n_rcpts} user(s)\n"
                "\n"
                "Send ANY message now — text, photo, video, document,\n"
                "animation, audio, voice, sticker, video_note or an album.\n"
                "Every user will receive an exact copy.\n\n"
                "You will see a preview and confirm before anything is sent.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("\u274C Cancel", callback_data="bcast:compose_cancel")]]),
            )
        elif data == "bcast:confirm":
            # BOT7 Broadcast UI upgrade: preview confirmed -> execute.
            await _bcast_confirm_execute(update, context)
        elif data == "bcast:cancel":
            # BOT7 Broadcast UI upgrade: cancelled at the confirmation card.
            context.user_data.pop("bcast_pending", None)
            await safe_answer_callback(q, "Broadcast cancelled.")
            await safe_edit_text(
                q, "\u274C Broadcast cancelled — nothing was sent.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("\u2B05\uFE0F Back to Broadcast", callback_data="panel:broadcast")]]),
            )
        elif data == "bcast:compose_cancel":
            # BOT7 Broadcast UI upgrade: cancelled while composing. The
            # compose prompt (q.message) is re-rendered as the panel.
            context.user_data.pop("awaiting_broadcast", None)
            context.user_data.pop("bcast_pending", None)
            await safe_answer_callback(q, "Compose cancelled.")
            await broadcast_panel(update, context)
        elif data == "bcast:scheduled":
            await broadcast_scheduled_panel(update, context)
        elif data == "bcast:stats":
            await broadcast_stats_panel(update, context)
        elif data.startswith("bcastcancel:"):
            bcast_id = int(data.split(":", 1)[1])
            await db.cancel_scheduled_broadcast(bcast_id)
            await broadcast_scheduled_panel(update, context)

        # ---- collection links (Issue 2 Critical Fix: explicit storage) ----
        elif data.startswith("coldl:"):
            code = data.split(":", 1)[1]
            await download_collection_all(update, context, code, user)
        elif data.startswith("cobrowse:"):
            parts = data.split(":")
            await browse_collection_files(update, context, parts[1], int(parts[2]))
        elif data.startswith("cofile:"):
            parts = data.split(":")
            await deliver_collection_file(update, context, parts[1], int(parts[2]), user)
        elif data.startswith("comenu:"):
            code = data.split(":", 1)[1]
            await show_collection_menu(update, context, code)
        elif data == "coclose":
            # "Back" on the Collection menu — cancel any pending Browse Files
            # auto-delete timer, then silently remove the menu message.
            _cancel_browse_timer(context)
            try:
                await context.bot.delete_message(chat_id=q.message.chat_id,
                                                 message_id=q.message.message_id)
            except TelegramError:
                pass
        elif data.startswith("cocopy:"):
            code = data.split(":", 1)[1]
            await safe_send_text(
                context.bot, q.message.chat_id,
                f"\U0001F4CB Copy this collection link:\n{build_collection_link(code)}",
            )

        # ---- legacy range links (backward-compat: auto-migrate to collection) ----
        elif data.startswith("rngdl:") or data.startswith("rngbrowse:") \
             or data.startswith("rngfile:") or data.startswith("rngmenu:") \
             or data == "rngclose" or data.startswith("rngcopy:"):
            # Old r<link> callbacks. Migrate to a collection, then re-dispatch.
            parts = data.split(":")
            if len(parts) >= 3 and parts[1].isdigit() and parts[2].isdigit():
                sid, eid = int(parts[1]), int(parts[2])
                code = await _migrate_legacy_range_to_collection(sid, eid, user_id=user.id)
                if code:
                    if data.startswith("rngdl:"):
                        await download_collection_all(update, context, code, user)
                    elif data.startswith("rngbrowse:"):
                        page = int(parts[3]) if len(parts) > 3 else 0
                        await browse_collection_files(update, context, code, page)
                    elif data.startswith("rngfile:"):
                        # rngfile:<start>:<end>:<file_pk> -> cofile:<code>:<file_pk>
                        file_pk = int(parts[3]) if len(parts) > 3 else 0
                        await deliver_collection_file(update, context, code, file_pk, user)
                    elif data.startswith("rngmenu:"):
                        await show_collection_menu(update, context, code)
                    elif data.startswith("rngcopy:"):
                        await safe_send_text(
                            context.bot, q.message.chat_id,
                            f"\U0001F4CB Copy this collection link:\n{build_collection_link(code)}",
                        )
                    elif data == "rngclose":
                        _cancel_browse_timer(context)
                        try:
                            await context.bot.delete_message(chat_id=q.message.chat_id,
                                                             message_id=q.message.message_id)
                        except TelegramError:
                            pass
                else:
                    await safe_answer_callback(q, "Collection no longer available.", show_alert=True)
            elif data == "rngclose":
                _cancel_browse_timer(context)
                try:
                    await context.bot.delete_message(chat_id=q.message.chat_id,
                                                     message_id=q.message.message_id)
                except TelegramError:
                    pass

        # ---- force join (Issue 25: fully GUI-driven) ----
        elif data == "panel:fj":
            await fj_panel(update, context)
        elif data == "fj:mode":
            # BOT6: explicit mode selector panel (not a blind cycle).
            await fj_mode_selector_panel(update, context)
        elif data.startswith("fjsetmode:"):
            new_mode = data.split(":", 2)[2]
            if new_mode in (FJ_MODE_SHOW_ALL, FJ_MODE_PROGRESSIVE_RANDOM, FJ_MODE_FIXED_ORDER):
                await db.set_setting("fj_mode", new_mode)
                logger.info("BOT6_FJ_MODE_SET mode=%s admin_id=%s", new_mode, user.id)
                await safe_answer_callback(q, f"\u2705 Mode set to {new_mode}")
                await fj_panel(update, context)
        elif data == "fj:batch":
            # BOTV13 Phase 3 fix: prompt for a numeric batch size (1-50) instead
            # of the hard-coded cycle [3,5,7,2]. The admin enters a number.
            context.user_data["awaiting_fj_batch_size"] = True
            cur_bs = await get_fj_batch_size()
            await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F4E6 Batch Size: {cur_bs}\n\n"
                f"Send a new batch size (1\u201350).")
        elif data == "fj:add":
            # Issue 25: Add Channel wizard. Captures the NEXT message (text or
            # forwarded post). 5-minute timeout auto-cancels.
            context.user_data["awaiting_fj_add"] = True
            await safe_send_text(
                context.bot, q.message.chat_id,
                "\u2795 Add Force-Join Channel\n\n"
                "Send one of the following:\n"
                "\u2022 Channel ID (e.g. -1001234567890)\n"
                "\u2022 Channel username (e.g. @mychannel)\n"
                "\u2022 Forwarded message from the channel\n\n"
                "The wizard auto-cancels after 5 minutes.",
            )
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_add"))
        elif data == "fj:list":
            await fj_list_panel(update, context)
        elif data == "fj:editpick":
            await fj_edit_pick_panel(update, context)
        elif data == "fj:rempick":
            await fj_remove_pick_panel(update, context)
        elif data.startswith("fjeditname:"):
            # Issue 25: rename a force-join channel.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_fj_edit"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Force-Join Channel\n\nSend the new display name:")
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_edit"))
        elif data.startswith("fjeditjoin:"):
            # Issue #63: edit join text.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_fj_editjoin"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Join Text\n\nSend the new join message text:")
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_editjoin"))
        elif data.startswith("fjeditverify:"):
            # Issue #63: edit verify button text.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_fj_editverify"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Verify Button\n\nSend the new verify button text:")
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_editverify"))
        elif data.startswith("fjeditchanbtn:"):
            # Issue #63: edit channel button text.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_fj_editchanbtn"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Channel Button\n\nSend the new channel button text:")
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_editchanbtn"))
        elif data.startswith("fjsetmedia:"):
            # Issue #63: set force join media — prompt admin to send media.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_fj_media"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F5BC Set Force Join Media\n\nSend a photo, video, animation, or document.")
            asyncio.create_task(_fj_schedule_timeout(update, context, "awaiting_fj_media"))
        elif data.startswith("fjdelmedia:"):
            # Issue #63: remove force join media.
            cid = int(data.split(":", 1)[1])
            await db.update_force_join_media(cid, None, None)
            await safe_answer_callback(q, "\u2705 Media removed.")
            await fj_detail_panel(update, context, cid)
        elif data.startswith("fjpreview:"):
            # Issue #63: preview force join page.
            cid = int(data.split(":", 1)[1])
            await send_force_join_page(context.bot, q.message.chat_id, user.id, f"preview:{cid}")
        elif data.startswith("fjedit:"):
            cid = int(data.split(":", 1)[1])
            await fj_detail_panel(update, context, cid)
        # ---- PHASE 6 §12-§16: join-link management + channel test ----
        elif data.startswith("fjlinkcustom:"):
            cid = int(data.split(":", 1)[1])
            await fj_link_custom_prompt(update, context, cid)
        elif data.startswith("fjlinkcancel:"):
            cid_raw = data.split(":", 1)[1]
            context.user_data.pop("awaiting_fj_custom_link", None)
            await safe_answer_callback(q, "\u274C Cancelled. The link was not changed.")
            try:
                await fj_link_panel(update, context, int(cid_raw))
            except (ValueError, TypeError):
                await fj_list_panel(update, context)
        elif data.startswith("fjlinkauto:"):
            # §13: transactional invite rotation — create NEW link first,
            # persist, THEN revoke the old bot-created link.
            cid = int(data.split(":", 1)[1])
            await safe_answer_callback(q, "\U0001F504 Rotating the invite link…")
            ok, msg = await rotate_force_join_invite_link(context.bot, cid)
            await safe_answer_callback(q, "\u2705 Rotated." if ok else "\u274C Not changed.")
            await safe_send_text(context.bot, q.message.chat_id, msg)
            # §13 step 6: refresh the FJ dashboard.
            try:
                await fj_dashboard_refresh(context.bot, q.message.chat_id)
            except Exception:  # noqa: BLE001
                pass
            await fj_link_panel(update, context, cid)
        elif data.startswith("fjlink:"):
            # §12: Change Join Link panel. NOTE: 'fjlinkcustom:'/'fjlinkcancel:'
            # /'fjlinkauto:' are matched BEFORE this branch, so the plain
            # 'fjlink:' here can never shadow them.
            cid = int(data.split(":", 1)[1])
            await fj_link_panel(update, context, cid)
        elif data.startswith("fjtest:"):
            # §16: Test Channel — full diagnostic, never invalidates on a
            # transient Telegram rate limit.
            cid = int(data.split(":", 1)[1])
            await fj_channel_test_panel(update, context, cid)
        elif data.startswith("fjrevalidate:"):
            # Issue 37 + §9: re-check channel accessibility (three-state).
            cid = int(data.split(":", 1)[1])
            valid = await _check_force_channel_valid(context.bot, cid)
            if valid is True:
                await safe_answer_callback(q, "\u2705 Channel is now accessible.", show_alert=False)
            elif valid is False:
                await safe_answer_callback(q,
                    "\u274C Channel is still invalid. Bot cannot access it.",
                    show_alert=True)
            else:
                await safe_answer_callback(q,
                    "\u26A0\uFE0F Couldn't verify right now (Telegram rate "
                    "limit). The channel was NOT marked invalid — try again "
                    "in a moment.", show_alert=True)
            await fj_detail_panel(update, context, cid)
        elif data.startswith("fjrem:"):
            # Issue 25: confirm removal of a force-join channel (NOT the storage
            # channel — only the force_join_channels record).
            cid = int(data.split(":", 1)[1])
            ch = await db.get_force_channel(cid)
            if not ch:
                await safe_answer_callback(q, "Channel not found.", show_alert=True)
                return
            name = _force_channel_label(ch)
            await safe_edit_text(
                update.callback_query,
                f"\u26A0\uFE0F Remove this force-join channel?\n\n"
                f"Channel: {name}\n\n"
                f"This only removes the force-join record.\n"
                f"The storage channel is NOT removed.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2705 Confirm Removal",
                                          callback_data=f"fjremconfirm:{cid}"),
                     InlineKeyboardButton("\u274C Cancel",
                                          callback_data="fj:list")],
                ]),
            )
        elif data.startswith("fjremconfirm:"):
            cid = int(data.split(":", 1)[1])
            await db.remove_force_channel(cid)
            await safe_edit_text(
                update.callback_query,
                "\u2705 Force-join channel removed.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="fj:list")],
                ]),
            )
        # (fjdel: removed — replaced by fjrem:/fjremconfirm: confirm flow in
        #  Issue 25. Old one-tap delete was unsafe.)

        # ---- files ----
        elif data.startswith("file:"):
            await file_detail(update, context, int(data.split(":", 1)[1]))
        # (fileinfo: / mkpayload: removed — dead: no button generated them.
        #  file_detail already covers file info; payloads are auto-created on
        #  indexing or via the Links panel.)
        elif data.startswith("filedel:"):
            fid = int(data.split(":", 1)[1])
            row = await db.get_indexed_file_by_id(fid)
            if not row:
                await safe_answer_callback(q, "File not found.", show_alert=True)
                return
            name = row["file_name"] or f"file_{fid}"
            await safe_edit_text(q, 
                f"\u274C *Confirm Deletion*\n\n"
                f"Delete file {md_code_span(name)}?\n"
                f"This cannot be undone.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u274C Yes, Delete", callback_data=f"filedelconfirm:{fid}"),
                     InlineKeyboardButton("\u2B05\uFE0F Cancel", callback_data=f"file:{fid}")],
                ]),
            )
        elif data.startswith("filedelconfirm:"):
            fid = int(data.split(":", 1)[1])
            await db.delete_indexed_file(fid)
            await send_recent_files_panel(update, sort="newest", page=0)

        # ---- payloads ----
        # (pl:create removed — dead: no button generated it; it only re-showed
        #  the payloads panel. New links are created via the Links panel.)
        elif data == "pl:list":
            await payload_list_panel(update, context, page=0)
        elif data.startswith("plpage:"):
            # BOTV13 Phase 1A: paginated payload manager navigation.
            page = int(data.split(":", 1)[1])
            await payload_list_panel(update, context, page=page)
        elif data.startswith("plback:"):
            # PHASE 6 §7: Back from a payload detail -> THE SAME list page
            # (never page 1). Deterministic + restart-safe: the page number
            # travels in the callback data itself.
            try:
                page = max(0, int(data.split(":", 1)[1]))
            except ValueError:
                page = 0
            logger.info("PAYLOAD_LIST_RETURN page=%s source=back",
                        page + 1)
            await payload_list_panel(update, context, page=page)
        # ---- PHASE 7 (Task 3): search navigation (paginated, context-safe) ----
        elif data.startswith("plsearch:"):
            # plsearch:<qid>:<page> — navigate within the stored search.
            _parts = data.split(":")
            _qid = _parts[1] if len(_parts) > 1 else ""
            _page = 0
            try:
                _page = max(0, int(_parts[2]))
            except (IndexError, ValueError):
                _page = 0
            _q = await _pl_search_load_query(_qid)
            if _q is None:
                await safe_answer_callback(
                    q, "This search has expired. Start a new search.",
                    show_alert=True)
                await payload_list_panel(update, context, page=_page)
            else:
                await payload_search_results_panel(update, context, _q,
                                                   page=_page)
        elif data.startswith("plsdetail:"):
            # plsdetail:<qid>:<pid>:<page> — open the payload detail carrying
            # the SEARCH context so Back returns to the same result page.
            _parts = data.split(":")
            _qid = _parts[1] if len(_parts) > 1 else ""
            _pid = 0
            _page = 0
            try:
                _pid = int(_parts[2])
            except (IndexError, ValueError):
                _pid = 0
            try:
                _page = max(0, int(_parts[3]))
            except (IndexError, ValueError):
                _page = 0
            if not _pid:
                await safe_answer_callback(q, "Invalid payload request.")
            elif await _pl_search_load_query(_qid) is None:
                # Restart-safe degradation: search expired -> normal detail.
                await pm_payload_detail(update, context, _pid)
            else:
                await pm_payload_detail(update, context, _pid,
                                        list_page=_page, search_qid=_qid)
        elif data.startswith("plsback:"):
            # plsback:<qid>:<page> — Back from detail -> THE SAME search page.
            _parts = data.split(":")
            _qid = _parts[1] if len(_parts) > 1 else ""
            _page = 0
            try:
                _page = max(0, int(_parts[2]))
            except (IndexError, ValueError):
                _page = 0
            logger.info("PAYLOAD_SEARCH_RETURN qid=%s page=%s source=back",
                        _qid, _page + 1)
            _q = await _pl_search_load_query(_qid)
            if _q is None:
                await safe_answer_callback(
                    q, "This search has expired. Start a new search.",
                    show_alert=True)
                await payload_list_panel(update, context, page=_page)
            else:
                await payload_search_results_panel(update, context, _q,
                                                   page=_page)
        elif data == "plsclear":
            # Clear Search -> the NORMAL Payload Manager (page 1; its
            # behaviour is unchanged when no search is active).
            await payload_list_panel(update, context, page=0)
        elif data == "pl:find":
            context.user_data["awaiting_find_payload"] = True
            await safe_send_text(
                context.bot, q.message.chat_id,
                "🔍 Send a name to search (case-insensitive, punctuation and "
                "spacing tolerant — hashtags like #movie work, partial names "
                "too).\n\nExample: #movie")
        elif data.startswith("pldetail:"):
            # PHASE 6 §7: pldetail:<pid>:<page> (new) or pldetail:<pid>
            # (legacy/child-screen Back) — the page is preserved so Back
            # returns to the originating list page.
            _parts = data.split(":")
            _pid = 0
            _pg: Optional[int] = None
            try:
                _pid = int(_parts[1])
            except (IndexError, ValueError):
                _pid = 0
            if len(_parts) >= 3:
                try:
                    _pg = max(0, int(_parts[2]))
                except ValueError:
                    _pg = None
            if _pid:
                await pm_payload_detail(update, context, _pid, list_page=_pg)
            else:
                await safe_answer_callback(q, "Invalid payload request.")
        elif data.startswith("plrename:"):
            pid = int(data.split(":", 1)[1])
            context.user_data["awaiting_payload_rename"] = pid
            await safe_send_text(context.bot, q.message.chat_id, "Send the new payload name:")
        elif data.startswith("plotoggle:"):
            pid = int(data.split(":", 1)[1])
            row = await db.get_payload_by_id(pid)
            if row:
                await db.update_payload_field(pid, "one_time", 0 if row["one_time"] else 1)
            await pm_payload_detail(update, context, pid)
        elif data.startswith("pltoggle:"):
            pid = int(data.split(":", 1)[1])
            row = await db.get_payload_by_id(pid)
            if row:
                new_status = "disabled" if row["status"] == "active" else "active"
                await db.update_payload_field(pid, "status", new_status)
                await log_admin_action(user.id, "toggle_payload", "payload", pid,
                                      f"status={new_status}")
            await pm_payload_detail(update, context, pid)
        elif data.startswith("pldel:"):
            pid = int(data.split(":", 1)[1])
            row = await db.get_payload_by_id(pid)
            await db.delete_payload(pid)
            await log_admin_action(user.id, "delete_payload", "payload", pid,
                                  f"slug={row['payload'] if row else '?'}")
            await safe_edit_text(q, 
                f"\u274C Payload {md_code_span(row['payload'] if row else pid)} deleted.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")]]
                ),
            )
        elif data.startswith("pltimer:"):
            await payload_timer_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("pltset:"):
            parts = data.split(":")
            pid = int(parts[1])
            secs = int(parts[2])
            val = None if secs == INHERIT_SENTINEL else secs
            await db.update_payload_field(pid, "delete_after", val)
            await log_admin_action(user.id, "set_delete_timer", "payload", pid,
                                  f"timer={val}")
            await payload_timer_panel(update, context, pid)
        # BOTV13 Phase 4: custom delete timer (prompt for numeric input).
        elif data.startswith("pltcustom:"):
            pid = int(data.split(":", 1)[1])
            context.user_data["awaiting_custom_timer"] = pid
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\ufe0f Custom Delete Timer\n\n"
                "Send the custom delete time in seconds.\n"
                "Examples: 45, 120, 600\n"
                "Range: 1\u201386400 (max 24 hours). 0 = Never.")
        # BOTV13 Phase 4: per-payload forward blocking 3-state toggle.
        elif data.startswith("plfb:"):
            pid = int(data.split(":", 1)[1])
            row = await db.get_payload_by_id(pid)
            if row:
                fb = row["forward_blocking"] if "forward_blocking" in row.keys() else None
                # Cycle: NULL → 1 (ON) → 0 (OFF) → NULL (inherit)
                if fb is None:
                    new_fb = 1
                elif fb:
                    new_fb = 0
                else:
                    new_fb = None
                await db.update_payload_field(pid, "forward_blocking", new_fb)
                await log_admin_action(user.id, "set_forward_blocking", "payload", pid,
                                      f"fb={new_fb}")
            await payload_timer_panel(update, context, pid)

        # ---- BOT-13 §46/§48/§59: per-payload website delivery controls ----
        elif data.startswith("plgf:"):
            # ADMIN: 📥 Get File ON/OFF toggle — persists immediately
            # (update_payload_field → DB), takes effect on EVERY website
            # surface (detail/player render + the mint endpoint's
            # server-side denial) with no cache to invalidate (each page
            # and API call reads the row fresh).
            pid = int(data.split(":", 1)[1])
            row = await db.get_payload_by_id(pid)
            if row:
                current = row["show_get_file"] \
                    if "show_get_file" in row.keys() else 1
                new_val = 0 if (current is None or int(current)) else 1
                await db.update_payload_field(pid, "show_get_file", new_val)
                await log_admin_action(
                    user.id, "set_show_get_file", "payload", pid,
                    f"show_get_file={new_val}")
                logger.info("PAYLOAD_GET_FILE_TOGGLED payload_id=%s "
                            "show_get_file=%s by_user=%s", pid, new_val,
                            user.id)
                await safe_answer_callback(
                    q, "📥 Get File " + ("ON" if new_val else "OFF"))
            else:
                await safe_answer_callback(
                    q, "Payload no longer exists.", show_alert=True)
            await pm_payload_detail(update, context, pid)
        elif data.startswith("plvad:"):
            # BOT-16 — DEPRECATED CONTROL: the per-payload ad-destination
            # selector (Bot / Website Ads / None) was REMOVED from the
            # payload panel. Ad behavior is now SURFACE-BASED (Telegram
            # Watch Ads settings for the bot; Website ad settings for the
            # website). The callback answers honestly instead of acting,
            # so stale buttons on OLD rendered panels can never silently
            # mutate the deprecated payloads.video_ad_destination column.
            await safe_answer_callback(
                q, "Ad destination controls were removed — ads now follow "
                   "each surface's own settings (Telegram Ads / Website "
                   "Ads).", show_alert=True)
            pid = 0
            parts = data.split(":")
            if len(parts) >= 2:
                try:
                    pid = int(parts[1])
                except ValueError:
                    pid = 0
            if pid:
                await pm_payload_detail(update, context, pid)

        # ---- Access Engine V1: Admin Access Policy callbacks ----
        elif data.startswith("plgate:"):
            # V15: set nav context so sub-panels return to payload details.
            await safe_answer_callback(q)
            nav_set(context, "payload_details", payload_id=int(data.split(":", 1)[1]))
            await referral_gate_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgpolicy:"):
            await access_policy_select_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgsetpolicy:"):
            parts = data.split(":", 2)
            pid = int(parts[1])
            new_policy = parts[2]
            prow = await db.get_payload_by_id(pid)
            if prow and new_policy in ACCESS_POLICIES_ALL:
                # Enforce to an implemented policy (future policies fall back).
                eff = new_policy if new_policy in ACCESS_POLICIES_IMPLEMENTED else ACCESS_POLICY_FORCE_JOIN
                await db.set_access_policy(pid, eff)
                if eff == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
                    # Ensure a campaign exists for this payload.
                    camp = await db.get_referral_campaign_by_payload(pid)
                    if not camp:
                        await db.create_referral_campaign(pid, prow["payload"])
                else:
                    # Switching away from referral -> disable its campaign
                    # (history is preserved, never deleted).
                    camp = await db.get_referral_campaign_by_payload(pid)
                    if camp and camp["enabled"]:
                        await db.update_referral_campaign(camp["id"], enabled=0)
            await referral_gate_panel(update, context, pid)
        # Legacy "Enable Referral Gate" button -> set FORCE_JOIN_REFERRAL.
        elif data.startswith("plgenable:"):
            pid = int(data.split(":", 1)[1])
            prow = await db.get_payload_by_id(pid)
            if prow:
                await db.set_access_policy(pid, ACCESS_POLICY_FORCE_JOIN_REFERRAL)
                camp = await db.get_referral_campaign_by_payload(pid)
                if not camp:
                    await db.create_referral_campaign(pid, prow["payload"])
            await referral_gate_panel(update, context, pid)
        elif data.startswith("plgtoggle:"):
            pid = int(data.split(":", 1)[1])
            campaign = await db.get_referral_campaign_by_payload(pid)
            if campaign:
                await db.update_referral_campaign(campaign["id"],
                    enabled=0 if campaign["enabled"] else 1)
            await referral_gate_panel(update, context, pid)
        elif data.startswith("plgsetreq:"):
            await access_required_referrals_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgsetreqn:"):
            parts = data.split(":", 2)
            pid = int(parts[1])
            n = max(0, int(parts[2]))
            campaign = await db.get_referral_campaign_by_payload(pid)
            if campaign:
                await db.update_referral_campaign(campaign["id"], required_referrals=n)
            else:
                prow = await db.get_payload_by_id(pid)
                if prow:
                    await db.create_referral_campaign(pid, prow["payload"],
                                                       required_referrals=n)
            await access_required_referrals_panel(update, context, pid)
        elif data.startswith("plgsetreqcustom:"):
            pid = int(data.split(":", 1)[1])
            context.user_data["awaiting_refgate_reqcustom"] = pid
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F522 Custom Required Referrals\n\n"
                "Send a number (0 = instant unlock).")
        elif data.startswith("plgpreview:"):
            await access_preview_mode_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgreferral:"):
            # V15: dedicated Referral Settings panel.
            await safe_answer_callback(q)
            await referral_settings_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgresetconfirm:"):
            # V15: Payload Details Reset button → confirmation screen.
            await safe_answer_callback(q)
            await payload_reset_confirm(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgdopreset:"):
            # V15: confirmed payload reset — restore default config only.
            pid = int(data.split(":", 1)[1])
            await db.update_payload_field(pid, "delete_after", None)
            await db.update_payload_field(pid, "one_time", 0)
            await safe_answer_callback(q, "\u2705 Payload settings reset to defaults.")
            await pm_payload_detail(update, context, pid)
        elif data.startswith("plgsetprev:"):
            parts = data.split(":", 2)
            pid = int(parts[1])
            mode = parts[2] if len(parts) > 2 else PREVIEW_MODE_DISABLED
            if mode not in PREVIEW_MODES_ALL:
                mode = PREVIEW_MODE_DISABLED
            campaign = await db.get_referral_campaign_by_payload(pid)
            if campaign:
                # V5: When switching to a media-bearing mode, resolve the
                # effective preview in the SAME write so the campaign row is
                # never left with a mode but no file_id (the root cause of the
                # "auto preview saves but users never receive media" bug).
                if mode == PREVIEW_MODE_AUTO:
                    # Re-detect compatible media from the payload's files.
                    payload_row = await db.get_payload_by_id(pid)
                    detected = await _auto_detect_campaign_preview_media(campaign, payload_row)
                    await db.update_referral_campaign(
                        campaign["id"], preview_mode=mode,
                        preview_media_file_id=(detected["file_id"] if detected else None),
                        preview_media_type=(detected["media_type"] if detected else None),
                    )
                    if detected:
                        await safe_answer_callback(q,
                            f"\u2705 Auto Preview resolved: {detected['media_type']}", show_alert=False)
                    else:
                        await safe_answer_callback(q,
                            "\u26A0\uFE0F Auto Preview: no compatible media found in this payload.",
                            show_alert=True)
                elif mode in (PREVIEW_MODE_DISABLED, PREVIEW_MODE_DESCRIPTION):
                    # Non-media modes → clear any stale stored media so the
                    # resolver returns a clean disabled/description state.
                    await db.update_referral_campaign(
                        campaign["id"], preview_mode=mode,
                        preview_media_file_id=None, preview_media_type=None,
                    )
                else:
                    # custom / select / thumbnail — keep any existing stored
                    # media; the admin uploads/selects it separately.
                    await db.update_referral_campaign(campaign["id"], preview_mode=mode)
            await access_preview_mode_panel(update, context, pid)
        elif data.startswith("plgprevmedia:"):
            pid = int(data.split(":", 1)[1])
            context.user_data["awaiting_refgate_prevmedia"] = pid
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F4E4 Preview Media\n\nSend a photo/video/animation to use as "
                "the locked-screen preview. The protected payload file is NEVER used.")
        elif data.startswith("plgprevdesc:"):
            pid = int(data.split(":", 1)[1])
            context.user_data["awaiting_refgate_prevdesc"] = pid
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F4DD Preview Description\n\nSend the preview text to show "
                "locked users (shown above the locked screen).")
        elif data.startswith("plganalytics:"):
            await access_analytics_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("plgrefanalytics:"):
            # v26: Statistics opened FROM Referral Settings — Back returns to
            # the Referral Settings panel (same single analytics renderer).
            await access_analytics_panel(update, context,
                                         int(data.split(":", 1)[1]),
                                         back_to="plgreferral")
        # Destructive actions -> confirmation screen first.
        elif data.startswith("plgreset:"):
            await access_reset_confirm_panel(update, context,
                int(data.split(":", 1)[1]), action="progress")
        elif data.startswith("plgresetall:"):
            await access_reset_confirm_panel(update, context,
                int(data.split(":", 1)[1]), action="campaign")
        elif data.startswith("plgdisable:"):
            await access_reset_confirm_panel(update, context,
                int(data.split(":", 1)[1]), action="disable")
        elif data.startswith("plgdoreset:"):
            parts = data.split(":", 2)
            pid = int(parts[1])
            action = parts[2]
            campaign = await db.get_referral_campaign_by_payload(pid)
            if campaign:
                if action == "progress":
                    count = await db.reset_campaign_unlocks(campaign["id"])
                    await safe_answer_callback(q,
                        f"\u2705 Reset {count} unlock records. History preserved.")
                elif action == "campaign":
                    count = await db.reset_campaign_unlocks(campaign["id"])
                    await db.update_referral_campaign(campaign["id"], enabled=0)
                    await safe_answer_callback(q,
                        f"\u2705 Reset {count} records + campaign disabled. History preserved.")
                elif action == "disable":
                    await db.update_referral_campaign(campaign["id"], enabled=0)
                    await safe_answer_callback(q,
                        "\u2705 Campaign disabled. Progress + history preserved.")
            await referral_gate_panel(update, context, pid)

        # ---- storage channels ----
        elif data == "ch:add":
            context.user_data["awaiting_storage_add"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send the CHANNEL_ID (numeric) of the storage channel to add."
            )
        elif data.startswith("chdetail:"):
            await channel_detail_panel(update, context, int(data.split(":", 1)[1]))
        elif data.startswith("reidxmode:"):
            # Issue #48: show reindex mode selection.
            cid = int(data.split(":", 1)[1])
            await reindex_mode_panel(update, context, cid)
        elif data.startswith("reidxquick:"):
            # Issue #48: Quick Sync (incremental — auto-resumes interrupted
            # jobs; PHASE 8: unbounded within the requested range).
            cid = int(data.split(":", 1)[1])
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError:
                pass
            status_msg = await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F504 Quick Sync: {ch_title}...")
            asyncio.create_task(
                run_reindex(context.bot, user.id, cid, None, status_msg, ch_title)
            )
        elif data.startswith("reidxresume:"):
            # PHASE 8 (§6): Resume — continue the interrupted scan from its
            # persisted job record (never restart from zero).
            cid = int(data.split(":", 1)[1])
            job = await _index_job_load(cid)
            if job is None or job.get("status") not in (
                    _idx_engine.SCAN_RUNNING, _idx_engine.SCAN_STOPPED,
                    _idx_engine.SCAN_PARTIAL):
                await safe_answer_callback(q, "No interrupted scan to resume.")
                await reindex_mode_panel(update, context, cid)
            else:
                counters = job.get("counters", {})
                status_msg = await safe_send_text(context.bot, q.message.chat_id,
                    f"\u23ED\uFE0F Resuming scan: {job.get('mode', '-')}\n"
                    f"Continuing from message {job.get('resume_msg_id')} "
                    f"({counters.get('processed', 0)} already processed)…")
                asyncio.create_task(
                    run_reindex(context.bot, user.id, cid, None, status_msg,
                                resume=True)
                )
        elif data.startswith("reidxfull:"):
            # Issue #48 + PHASE 8: Full Reindex (reset cursor + job record,
            # then a FRESH UNBOUNDED full-history walk).
            cid = int(data.split(":", 1)[1])
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError:
                pass
            status_msg = await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F504 Full Reindex: {ch_title}…\n"
                f"Fresh full-history scan (cursor + old job record reset).")
            asyncio.create_task(
                run_full_reindex(context.bot, user.id, cid, status_msg, ch_title)
            )
        elif data.startswith("reidxfromfile:"):
            # Issue #48: Reindex From File — prompt admin to forward a file.
            cid = int(data.split(":", 1)[1])
            context.user_data["awaiting_reidx_fromfile"] = cid
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F4E5 Reindex From File\n\n"
                "Forward the latest file from the channel.\n"
                "The bot will use its message_id as the scan boundary.")
        elif data.startswith("reidxreconcile:"):
            # PHASE 8 (§4): Reconcile — verification + apply the SAFE repairs
            # (index missing, atomic file_id repair, mark unavailable,
            # recover). Nothing is ever deleted; payload refs never touched.
            cid = int(data.split(":", 1)[1])
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError:
                pass
            status_msg = await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F527 Verifying + reconciling: {ch_title}…")
            asyncio.create_task(
                verify_index_integrity(context.bot, user.id, cid, status_msg,
                                       reconcile=True)
            )
        elif data.startswith("reidxverify:"):
            # Issue #48 + PHASE 8: Verify Index — REAL read-only verification
            # (source walk + orphan probes + DB cross-matrix + payload refs).
            cid = int(data.split(":", 1)[1])
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError:
                pass
            status_msg = await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F50D Verifying integrity: {ch_title}…")
            asyncio.create_task(
                verify_index_integrity(context.bot, user.id, cid, status_msg)
            )
        elif data.startswith("chreindex:"):
            cid = int(data.split(":", 1)[1])
            # Resolve channel title for friendly display
            ch_title = str(cid)
            try:
                chat_info = await context.bot.get_chat(cid)
                if chat_info and chat_info.title:
                    ch_title = chat_info.title
            except TelegramError as e:
                await safe_send_text(context.bot, q.message.chat_id,
                                     f"Cannot access channel: {e}")
                return
            # Issue 9: no fake count in the status message. Plain text.
            status_msg = await safe_send_text(
                context.bot, q.message.chat_id,
                f"\U0001F504 Reindexing {ch_title}…",
            )
            asyncio.create_task(
                run_reindex(context.bot, user.id, cid, None, status_msg, ch_title)
            )
        elif data.startswith("chtoggle:"):
            cid = int(data.split(":", 1)[1])
            ch = await db.get_storage_channel(cid)
            if ch:
                await db.set_storage_channel_active(cid, 0 if ch["is_active"] else 1)
            await channel_detail_panel(update, context, cid)
        elif data.startswith("chrem:"):
            cid = int(data.split(":", 1)[1])
            await db.remove_storage_channel(cid)
            await channels_panel(update, context)
        # ---- Issue 23: Clear Indexed Files (channel-scoped) ----
        elif data.startswith("chclearidx:"):
            cid = int(data.split(":", 1)[1])
            ch = await db.get_storage_channel(cid)
            if not ch:
                await safe_answer_callback(q, "Channel not found.", show_alert=True)
                return
            cnt = await db.count_indexed_files_for_channel(cid)
            display_name = ch['title'] or f"Channel {cid}"
            # Confirmation screen — plain text so channel names never crash.
            await safe_edit_text(
                update.callback_query,
                f"\u26A0\uFE0F Remove all indexed files from this channel?\n\n"
                f"Channel: {display_name}\n"
                f"Indexed files: {cnt}\n\n"
                f"This only removes indexed records.\n"
                f"The storage channel itself will NOT be removed.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2705 Confirm",
                                          callback_data=f"chclearidxconfirm:{cid}"),
                     InlineKeyboardButton("\u274C Cancel",
                                          callback_data=f"chdetail:{cid}")],
                ]),
            )
        elif data.startswith("chclearidxconfirm:"):
            cid = int(data.split(":", 1)[1])
            ch = await db.get_storage_channel(cid)
            if not ch:
                await safe_answer_callback(q, "Channel not found.", show_alert=True)
                return
            display_name = ch['title'] or f"Channel {cid}"
            # Transaction-safe delete of ONLY this channel's indexed_files.
            ok, removed = await db.clear_indexed_files_for_channel(cid)
            if ok:
                # Issue 26: reset the incremental reindex cursor so the next
                # reindex does a full backward first-scan (re-indexing all content)
                # instead of skipping messages it thinks are already indexed.
                await db.reset_reindex_state(cid)
                await safe_edit_text(
                    update.callback_query,
                    f"\u2705 Channel Index Cleared\n\n"
                    f"Channel: {display_name}\n"
                    f"Removed: {removed} indexed files",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("\u2B05\uFE0F Back",
                                              callback_data=f"chdetail:{cid}")],
                    ]),
                )
            else:
                await safe_edit_text(
                    update.callback_query,
                    f"\u274C Failed to clear index for {display_name}.\n"
                    f"No records were removed (transaction rolled back).",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("\u2B05\uFE0F Back",
                                              callback_data=f"chdetail:{cid}")],
                    ]),
                )

        # ---- start message ----
        elif data == "sm:edittext":
            context.user_data["awaiting_start_text"] = True
            await safe_send_text(context.bot, q.message.chat_id, "Send the new start message text:")
        elif data == "sm:media":
            context.user_data["awaiting_media"] = "any"
            await safe_send_text(context.bot, q.message.chat_id,
                "Send a photo or video (with optional caption) to use as the "
                "start message media."
            )
        # BOTV13 Phase 5: Remove Media — clears file_id/file_type but preserves
        # text, entities, and buttons. If no text remains, show the empty state.
        elif data == "sm:remmedia":
            variant = context.user_data.get("sm_variant", "first")
            row = await db.get_start_message(variant)
            if row and row["file_id"]:
                # Clear media, keep text + buttons. Set type to 'text'.
                await db.conn.execute(
                    "UPDATE start_message SET file_id = NULL, message_type = 'text' "
                    "WHERE variant = ?",
                    (variant,),
                )
                await db.conn.commit()
                await log_admin_action(user.id, "remove_media", "start_message",
                                      None, f"variant={variant}")
                await safe_answer_callback(q, "\u2705 Media removed. Text and buttons preserved.")
            else:
                await safe_answer_callback(q, "No media to remove.", show_alert=True)
            await show_startmsg_panel(update, context)
        # (sm:photo / sm:video removed — dead: no button generated them. The
        #  sm:media button covers both photo and video via the "any" state.)
        elif data == "sm:buttons":
            context.user_data["awaiting_start_buttons"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send buttons in this format (one per line, `---` for new row):\n\n"
                "Main Channel | channel:@mychannel\n"
                "Get Spider | deeplink:spider_nwh\n"
                "---\n"
                "Premium | url:https://t.me/premium"
            )
        elif data == "sm:preview":
            variant = context.user_data.get("sm_variant", "first")
            sent = await send_start_message(context.bot, user.id, variant)
            # Issue 7: Start Message Preview auto-deletes after 20s (silent).
            if sent and getattr(sent, "message_id", None):
                asyncio.create_task(
                    schedule_admin_preview_delete(context.bot, user.id, [sent.message_id])
                )
        elif data == "sm:reset":
            variant = context.user_data.get("sm_variant", "first")
            await db.reset_start_message(variant)
            await show_startmsg_panel(update, context)
        elif data == "sm:switch":
            cur = context.user_data.get("sm_variant", "first")
            context.user_data["sm_variant"] = "returning" if cur == "first" else "first"
            await show_startmsg_panel(update, context)

        # ---- BOT6 Phase 25-26: Help / User Guide callbacks ----
        elif data == "help:back":
            # Back from the user-facing help screen -> previous screen.
            # If admin, return to main; otherwise close.
            if await is_admin(user.id):
                await show_admin_panel(update, context)
            else:
                await safe_answer_callback(q, "Closed.")
        elif data == "help:edittext":
            context.user_data["awaiting_help_text"] = True
            cur = await db.get_help_message("default")
            cur_text = cur["caption"] if cur and cur["caption"] else DEFAULT_HELP_TEXT
            await safe_send_text(context.bot, q.message.chat_id,
                "\u270F\uFE0F Edit Help Text\n\nSend the new help guide text.\n"
                "Send /skip to keep current.\n\nCurrent:\n" + cur_text[:500])
        elif data == "help:media":
            context.user_data["awaiting_help_media"] = True
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F5BC Send a photo/video/animation/file to use as the Help media.\n"
                "Send /skip to remove media.")
        elif data == "help:buttons":
            context.user_data["awaiting_help_buttons"] = True
            cur = await db.get_help_message("default")
            cur_btns = cur["buttons_json"] if cur and cur["buttons_json"] else "[]"
            await safe_send_text(context.bot, q.message.chat_id,
                "\U0001F518 Edit Help Buttons\n\nSend button rows as JSON.\n"
                "Format: [[\"Label\",\"url_or_callback\"],...]\n"
                f"Current: {cur_btns}")
        elif data == "help:preview":
            # Render the help screen as the user would see it.
            text, kb, entities = await render_help_screen()
            if entities:
                await safe_send_text(context.bot, q.message.chat_id, text,
                                     reply_markup=kb, entities=entities)
            else:
                await safe_send_text(context.bot, q.message.chat_id, text, reply_markup=kb)
        elif data == "help:toggle":
            cur = await db.get_help_message("default")
            new_en = 0 if (cur and cur["enabled"]) else 1
            await db.set_help_message("default", enabled=new_en)
            await show_help_panel(update, context)
        elif data == "help:reset":
            await db.set_help_message("default", message_type="text", file_id=None,
                                      caption=DEFAULT_HELP_TEXT, buttons_json=None,
                                      entities=None, enabled=1)
            await show_help_panel(update, context)

        # ---- delivery message builder ----
        elif data == "panel:deliverymsg":
            await delivery_message_panel(update, context)
        elif data == "dm:editsingle":
            context.user_data["awaiting_dm_single"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send the new *delivery message text*.\n\n"
                "Placeholders: `{filename}`, `{filesize}`"
            )
        elif data == "dm:editcoll":
            context.user_data["awaiting_dm_coll"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send the new *collection delivery message text*.\n\n"
                "Placeholders: `{count}`"
            )
        elif data == "dm:editbuttons":
            context.user_data["awaiting_dm_buttons"] = True
            await safe_send_text(context.bot, q.message.chat_id, 
                "Send delivery message buttons in this format "
                "(one per line, `---` for new row):\n\n"
                "Save | url:https://t.me/yourchannel\n"
                "---\n"
                "Support | url:https://t.me/support"
            )
        elif data == "dm:preview":
            text = _format_delivery_text(await get_delivery_message_text(),
                                         filename="Movie.mkv", filesize="1.0 GB")
            m1 = await safe_send_text(
                context.bot, q.message.chat_id,
                f"Preview (single file):\n\n{text}",
            )
            coll = _format_delivery_text(await get_collection_delivery_message_text(),
                                         count=7)
            m2 = await safe_send_text(
                context.bot, q.message.chat_id,
                f"Preview (collection):\n\n{coll}",
            )
            # Issue 7: Delivery Message Preview auto-deletes after 20s (silent).
            preview_ids: List[int] = []
            if m1 and m1.message_id:
                preview_ids.append(m1.message_id)
            if m2 and m2.message_id:
                preview_ids.append(m2.message_id)
            if preview_ids:
                asyncio.create_task(
                    schedule_admin_preview_delete(context.bot, user.id, preview_ids)
                )
        elif data == "dm:toggle":
            cur = await delivery_message_active()
            await db.set_setting("delivery_message_enabled", "0" if cur else "1")
            await delivery_message_panel(update, context)
        elif data == "dm:reset":
            await db.set_setting("delivery_message_text", (
                "\u2705 {filename} delivered successfully.\n\n"
                "\u26A0\uFE0F Save or forward this file now.\n"
                "\U0001F551 This file may be removed automatically."
            ))
            await db.set_setting("collection_delivery_message_text", (
                "\u2705 {count} files delivered successfully.\n\n"
                "\u26A0\uFE0F Save important files.\n"
                "\U0001F551 Files may be removed automatically."
            ))
            await db.set_setting("delivery_message_buttons", "[]")
            await delivery_message_panel(update, context)

        # ---- settings toggles ----
        elif data == "set:timer":
            await cycle_delete_timer(update, context)
        elif data == "set:jrpolicy":
            # Issue 7: cycle Request-To-Join policy between request <-> approval.
            cur = await get_join_request_policy()
            new = JOIN_REQUEST_POLICY_APPROVAL if cur == JOIN_REQUEST_POLICY_REQUEST else JOIN_REQUEST_POLICY_REQUEST
            await set_join_request_policy(new)
            logger.info("JoinRequest policy switched -> %s", new)
            await settings_panel(update, context)
        elif data.startswith("set:toggle:"):
            key = data.split(":", 2)[2]
            await toggle_setting(update, context, key)

        # ---- Issue #50: Retrieve button callback ----
        elif data.startswith("retrieve:"):
            record_id = int(data.split(":", 1)[1])
            await handle_retrieve(update, context, record_id, user)
        # ---- Issue #92: preview retrieve button (no-op, never touches real records) ----
        elif data == "preview_retrieve":
            await safe_answer_callback(q, "Preview button (non-functional).", show_alert=False)

        # ---- Issue #94: Referral Gate callbacks (user-facing) ----
        elif data.startswith("refcheck:"):
            # V9: Check Progress — edit the EXISTING dashboard in-place via the
            # Dashboard Controller. Mode-aware (editMessageCaption vs editMessageText).
            # Never sends a new message. If no stored dashboard exists, answer
            # with an alert so the user is never left with a stuck spinner.
            campaign_id = int(data.split(":", 1)[1])
            campaign = await db.get_referral_campaign_by_id(campaign_id)
            if not campaign:
                await safe_answer_callback(q, "\u274C Campaign not found.", show_alert=True)
                return
            # Refresh the unlock record from DB (never trust cached values).
            await db.get_or_create_unlock_record(
                campaign["payload_id"], campaign_id, user.id, campaign["required_referrals"]
            )
            settings = await db.get_all_dashboard_settings(campaign_id)
            link_preview = settings.get("link_preview_enabled", "0") == "1"
            disable_preview = not link_preview
            # Hand off to the single updater — mode-aware, no duplicate sends.
            ok = await dashboard_update(context.bot, campaign, user.id,
                                        disable_web_page_preview=disable_preview)
            if ok:
                await safe_answer_callback(q, "\u2705 Progress refreshed.")
            else:
                # No stored dashboard (e.g. very old session) — alert the user
                # rather than creating a duplicate dashboard message.
                await safe_answer_callback(q,
                    "Progress is shown on your referral dashboard. "
                    "Open the original link to view it.",
                    show_alert=True)
        elif data.startswith("refhow:"):
            # V12: How It Works — Edit dashboard text in-place with an explicit Back button.
            campaign_id = int(data.split(":", 1)[1])
            campaign = await db.get_referral_campaign_by_id(campaign_id)
            
            how_text = (
                "ℹ️ *How Unlock Works*\n\n"
                "1. Tap *Invite Friends* to share your unique link.\n"
                "2. When friends join the bot using your link, your progress increases.\n"
                "3. Once you reach the goal, the content unlocks automatically!"
            )
            # V2 (v26): when the payload ALSO has Watch Ads enabled, the OR
            # rule applies — either path unlocks. State it clearly (never
            # claim both are required).
            if campaign:
                _how_pid = _safe_row_get(campaign, "payload_id")
                if _how_pid:
                    _how_row = await db.get_payload_by_id(int(_how_pid))
                    if _how_row and _safe_row_get(_how_row, "watch_ads_enabled"):
                        how_text += (
                            "\n\n🎬 *No friends? Watch the ad instead!*\n"
                            "You can also unlock instantly by watching the\n"
                            "rewarded ad — either option unlocks the content."
                        )
            
            # The 'Back' button uses 'refcheck:' to trigger dashboard_update,
            # which re-renders the main referral dashboard menu seamlessly.
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data=f"refcheck:{campaign_id}")]
            ])
            
            await safe_answer_callback(q)
            
            if campaign:
                await dashboard_update(context.bot, campaign, user.id, text=how_text, keyboard=kb)
            else:
                await safe_edit_text(q, how_text, reply_markup=kb)
        elif data.startswith("refwatch:"):
            # V13: Watch Preview — send preview media on-demand.
            # Resolves the campaign's preview (self-healing auto-preview) and
            # sends the media with the preview description as caption. Never
            # creates another dashboard, never restarts the flow. If no preview
            # is available, shows a popup only.
            campaign_id = int(data.split(":", 1)[1])
            campaign = await db.get_referral_campaign_by_id(campaign_id)
            if not campaign:
                await safe_answer_callback(q, "\u274C Campaign not found.", show_alert=True)
                return
            sent = await send_watch_preview(context.bot, q.message.chat_id, user.id, campaign)
            if sent:
                await safe_answer_callback(q, "\U0001F3AC Preview sent below.")
            else:
                await safe_answer_callback(q, "No preview available.", show_alert=True)

        # ---- WATCH_AD (v25): user-facing + admin Watch Ad callbacks ----
        # ORDER MATTERS: the specific admin subroutes (wad:web*, wad:sdk*,
        # wad:window*) are matched BEFORE the generic numeric `wad:<payload_id>`
        # user handler, so nothing collides.
        elif data.startswith("wadcheck:"):
            # USER: refresh after (expected) reward: re-run the full delivery
            # path — Access Engine re-evaluates the rewarded unlock window.
            arg = data.split(":", 1)[1]
            # V26 (callback_data safety): resolve the compact reversible
            # 'i<payload_id>' form back to the canonical routing slug.
            if is_internal_id_ref(arg):
                try:
                    _wrow = await db.get_payload_by_id(int(arg[1:]))
                except Exception:  # noqa: BLE001
                    _wrow = None
                if _wrow is not None:
                    arg = str(_wrow["payload"] or arg)
                else:
                    arg = "-"
            await _dispatch_delivery_arg(update, context, user, arg)
        elif data.startswith("wadhow:"):
            # V5.2: USER: How It Works on the Watch Ads access screen (works
            # with or without a referral campaign). Explains the ad flow AND
            # the OR rule when a referral option also exists. Back re-renders
            # the access screen via the standard refresh dispatch.
            try:
                how_pid = int(data.split(":", 1)[1])
            except (TypeError, ValueError):
                how_pid = 0
            how_text = (
                "ℹ️ *How Watch Ads Unlock Works*\n\n"
                "1. Tap *Watch Ad* — a short rewarded ad plays\n"
                "   (creative and duration are set by the ad network).\n"
                "2. The ad network verifies your reward *server-side*.\n"
                "3. Once every required ad is verified, the payload\n"
                "   unlocks automatically — the button turns green."
            )
            _how_row = await db.get_payload_by_id(how_pid) if how_pid else None
            if _how_row:
                _how_campaign = await db.get_referral_campaign_by_payload(how_pid)
                if _how_campaign and _safe_row_get(_how_campaign, "enabled"):
                    _rem = max(0, int(_how_campaign["required_referrals"] or 0))
                    how_text += (
                        "\n\n📤 *No ads? Invite friends instead!*\n"
                        f"Inviting {_rem} friend{'s' if _rem != 1 else ''} also "
                        "unlocks this content — either option works."
                    )
            # V26 (callback_data safety): the Back button carries the
            # compact reversible id form (the _how_row is already in hand)
            # — 'wadcheck:' + a 64-char slug would exceed the 64-byte
            # callback_data limit.
            _how_back = (f"i{int(_how_row['id'])}" if _how_row else "-")
            await safe_answer_callback(q)
            await safe_send_text(
                context.bot,
                q.message.chat_id if q.message else user.id,
                how_text,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("⬅️ Back",
                                         callback_data=f"wadcheck:{_how_back}")
                ]]),
            )
        elif data.startswith("retryfile:"):
            # V5.2: USER: per-file delivery retry (transient network failure
            # exhausted its bounded retries). Re-enters the SAME pipeline:
            # fresh Access Engine authorization + _deliver_files_core.
            # V26 (callback_data safety): the button carries the compact
            # reversible 'i<payload_id>' form — resolve it back to the
            # canonical routing slug (the anti-tamper membership checks in
            # handle_retry_failed_file then run unchanged).
            parts = data.split(":")
            if len(parts) >= 3:
                _rarg = parts[1]
                if is_internal_id_ref(_rarg):
                    try:
                        _rrow = await db.get_payload_by_id(int(_rarg[1:]))
                    except Exception:  # noqa: BLE001
                        _rrow = None
                    if _rrow is not None:
                        _rarg = str(_rrow["payload"] or _rarg)
                    else:
                        _rarg = ""
                await handle_retry_failed_file(
                    update, context, _rarg, parts[2], user)
            else:
                await safe_answer_callback(q, "Invalid request.",
                                           show_alert=True)
        elif data == "panel:wadsettings":
            await safe_answer_callback(q)
            await watch_ads_settings_panel(update, context)
        elif data == "wadcfg:web":
            await watch_ads_website_panel(update, context)
        elif data in ("wadcfg:webadd", "wadcfg:webchange"):
            await watch_ads_website_prompt(update, context)
        elif data == "wadcfg:webdel":
            await watch_ads_website_delete_confirm(update, context)
        elif data == "wadcfg:webdelyes":
            await db.set_setting("watch_ads_mini_app_url", "")
            await log_admin_action(user.id, "delete_watch_ads_url", "setting", None, "")
            logger.info("Watch Ads Mini App URL deleted (admin=%s).", user.id)
            await safe_answer_callback(q, "\u2705 Mini App Website deleted.")
            await watch_ads_website_panel(update, context)
        elif data == "wadcfg:webcancel":
            # Cancel restores the previous state (nothing was saved — the
            # setting is only written after successful text validation).
            context.user_data.pop("awaiting_wad_url", None)
            await safe_answer_callback(q, "\u274C Cancelled. The URL was not changed.")
            await watch_ads_website_panel(update, context)
        elif data == "wadcfg:sdk":
            await watch_ads_sdk_panel(update, context)
        elif data in ("wadcfg:sdkadd", "wadcfg:sdkreplace"):
            await watch_ads_sdk_prompt(update, context)
        elif data == "wadcfg:sdkdel":
            await watch_ads_sdk_delete_confirm(update, context)
        elif data == "wadcfg:sdkdelyes":
            await db.set_setting("watch_ads_monetag_sdk", "")
            await log_admin_action(user.id, "delete_watch_ads_sdk", "setting", None, "")
            logger.info("Watch Ads Monetag SDK deleted (admin=%s).", user.id)
            await safe_answer_callback(q, "\u2705 Monetag SDK deleted.")
            await watch_ads_sdk_panel(update, context)
        elif data == "wadcfg:sdkcancel":
            # Cancel restores the previous state (failed validation never
            # overwrote the working SDK).
            context.user_data.pop("awaiting_wad_sdk", None)
            await safe_answer_callback(q, "\u274C Cancelled. The SDK was not changed.")
            await watch_ads_sdk_panel(update, context)
        # ---- v36 §18A: Monetag WEBSITE SDK (ad tag) management — a
        # SEPARATE surface from the Mini App TMA SDK above. The stored
        # tag is injected only into /site pages (website_monetag.py).
        elif data == "wadcfg:wsdk":
            await watch_ads_website_sdk_panel(update, context)
        elif data in ("wadcfg:wsdkadd", "wadcfg:wsdkreplace"):
            await watch_ads_website_sdk_prompt(update, context)
        elif data == "wadcfg:wsdkdel":
            await watch_ads_website_sdk_delete_confirm(update, context)
        elif data == "wadcfg:wsdkdelyes":
            await db.set_setting("website_monetag_ad_tag", "")
            await log_admin_action(user.id, "delete_website_monetag_sdk",
                                    "setting", None, "")
            logger.info("Website Monetag SDK deleted (admin=%s).", user.id)
            await safe_answer_callback(q, "\u2705 Website SDK deleted.")
            await watch_ads_website_sdk_panel(update, context)
        elif data == "wadcfg:wsdkcancel":
            # Cancel restores the previous state (nothing was saved — the
            # setting is only written after successful text validation).
            context.user_data.pop("awaiting_wsdk", None)
            await safe_answer_callback(q, "\u274C Cancelled. The Website SDK "
                                          "was not changed.")
            await watch_ads_website_sdk_panel(update, context)
        elif data == "wadcfg:window":
            await watch_ads_window_panel(update, context)
        elif data.startswith("wadcfg:windowset:"):
            try:
                secs = max(30, int(data.split(":", 2)[2]))
            except ValueError:
                secs = 0
            if secs:
                await db.set_setting("watch_ads_unlock_window", str(secs))
                await log_admin_action(user.id, "set_watch_ads_window", "setting",
                                       None, f"seconds={secs}")
                await safe_answer_callback(q, f"\u2705 Unlock window set to {secs}s.")
            await watch_ads_window_panel(update, context)
        # ---- BOTV13 PHASE 6 (§2-§3): Ads Unlock Message template admin ----
        elif data == "wadcfg:tpl":
            await safe_answer_callback(q)
            await watch_ads_template_panel(update, context)
        elif data == "wadcfg:tpledit":
            await watch_ads_template_edit_prompt(update, context)
        elif data == "wadcfg:tplcancel":
            context.user_data.pop("awaiting_wad_template", None)
            await safe_answer_callback(q,
                "\u274C Cancelled. The template was not changed.")
            await watch_ads_template_panel(update, context)
        elif data == "wadcfg:tplpreview":
            await safe_answer_callback(q)
            await watch_ads_template_preview_panel(update, context)
        elif data == "wadcfg:tpltest":
            await watch_ads_template_test_send(update, context)
        elif data == "wadcfg:tplreset":
            await safe_answer_callback(q)
            await watch_ads_template_reset_confirm(update, context)
        elif data == "wadcfg:tplresetyes":
            await db.set_setting(WATCH_AD_TEMPLATE_SETTING_KEY,
                                 WATCH_AD_UNLOCK_TEMPLATE_DEFAULT)
            await log_admin_action(user.id, "reset_watch_ads_template",
                                   "setting", None, "to=default")
            logger.info("WATCH_AD_TEMPLATE_RESET admin=%s", user.id)
            await safe_answer_callback(q, "\u2705 Default template restored.")
            await watch_ads_template_panel(update, context)
        elif data == "wadcfg:control":
            # ADMIN: V2 Ads Control mode chooser (Short / Two / Random / Three).
            await watch_ads_ad_control_panel(update, context)
        elif data.startswith("wadcfg:controlset:"):
            # ADMIN: persist the selected Ads Control mode (DB authoritative).
            mode = data.split(":", 2)[2].strip().lower()
            await watch_ads_ad_control_set(update, context, mode)
        elif data == "wadcfg:status":
            # ADMIN (V4 v27): Watch Ads Status & Monitoring panel.
            await safe_answer_callback(q)
            await watch_ads_status_panel(update, context)
        elif data == "wadcfg:globalon":
            # ADMIN (V4 v27): GLOBAL master switch ON (safe direction, no
            # confirmation needed — it only re-activates saved toggles).
            await watch_ads_global_toggle_set(update, context, True)
        elif data == "wadcfg:globaloff":
            # ADMIN (V4 v27): GLOBAL OFF is a dangerous action -> confirm.
            await safe_answer_callback(q)
            await watch_ads_global_toggle_confirm(update, context)
        elif data == "wadcfg:globaloffyes":
            # ADMIN (V4 v27): confirmed global disable (payload toggles kept).
            await watch_ads_global_toggle_set(update, context, False)
        elif data == "wadcfg:ttl":
            # ADMIN (V4 v27): session/verification timeout presets.
            await safe_answer_callback(q)
            await watch_ads_session_ttl_panel(update, context)
        elif data.startswith("wadcfg:ttlset:"):
            # ADMIN (V4 v27): persist the session timeout (clamped).
            try:
                secs = int(data.split(":", 2)[2])
            except ValueError:
                secs = 0
            if secs:
                await watch_ads_session_ttl_set(update, context, secs)
            else:
                await safe_answer_callback(q, "Invalid timeout value.")
                await watch_ads_session_ttl_panel(update, context)
        elif data == "wadcfg:reconcile":
            # ADMIN (V4 v27): reconcile stuck sessions -> confirmation panel.
            await safe_answer_callback(q)
            await watch_ads_reconcile_confirm(update, context)
        elif data == "wadcfg:reconcileyes":
            # ADMIN (V4 v27): confirmed reconcile execution.
            await watch_ads_reconcile_run(update, context)
        elif data.startswith("plgwad:"):
            # ADMIN: per-payload Watch Ads config panel.
            await safe_answer_callback(q)
            await watch_ads_payload_panel(update, context,
                                          int(data.split(":", 1)[1]))
        elif data.startswith("plgwadt:"):
            # ADMIN: toggle watch_ads_enabled (OFF -> ON / ON -> OFF).
            await watch_ads_payload_toggle(update, context,
                                           int(data.split(":", 1)[1]))
        elif data.startswith("plgwadm:"):
            # ADMIN (V4 v27): per-payload Ads Mode override chooser.
            await safe_answer_callback(q)
            await watch_ads_payload_mode_panel(update, context,
                                               int(data.split(":", 1)[1]))
        elif data.startswith("plgwadmset:"):
            # ADMIN (V4 v27): persist the per-payload ads-mode override
            # (plgwadmset:<pid>:<mode|global>). NOTE: 'plgwadmset:' does not
            # collide with the 'plgwad:'/'plgwadm:' prefixes above because the
            # character after 'plgwadm' is 's', not ':'.
            parts = data.split(":")
            _pid = 0
            if len(parts) == 3:
                try:
                    _pid = int(parts[1])
                except ValueError:
                    _pid = 0
            if _pid:
                await watch_ads_payload_mode_set(update, context, _pid,
                                                 parts[2].strip().lower())
            else:
                await safe_answer_callback(q, "Invalid ads mode request.")
        elif data.startswith("wad:") and data.split(":", 1)[1].isdigit():
            # USER: [🎬 Watch Ad] button press (callback fallback path):
            # creates/reuses a secure ad session and surfaces the Mini App
            # launch button. NEVER delivers the protected payload from here.
            await handle_watch_ad(update, context, int(data.split(":", 1)[1]))

        # ---- verify (force-join recheck) ----
        # Dispatch to the right delivery path based on the argument shape:
        #   verify:m8619       -> message-id link delivery
        #   verify:c7f3a9b2    -> collection delivery (new explicit format)
        #   verify:r8619_8625  -> legacy range (auto-migrate to collection)
        #   verify:<payload>   -> normal payload delivery
        # Issue 5 Critical Fix: legacy range links no longer call the deleted
        # deliver_range() function — they auto-migrate to an explicit collection
        # and then use deliver_collection(). No crashes, no undefined functions.
        elif data.startswith("verify:"):
            arg = data.split(":", 1)[1]
            # V26 (callback_data safety): the compact reversible internal
            # id form 'i<payload_id>' (emitted by the Join/Verify keyboard
            # for named payloads) resolves back to the canonical routing
            # slug HERE — the dispatch below is unchanged. m<id>/c<code>/
            # r-range forms pass through untouched.
            if is_internal_id_ref(arg):
                try:
                    _vrow = await db.get_payload_by_id(int(arg[1:]))
                except Exception:  # noqa: BLE001
                    _vrow = None
                if _vrow is not None:
                    arg = str(_vrow["payload"] or arg)
                    logger.debug("verify: internal id resolved -> %s", arg[:40])
                else:
                    arg = "-"
            # PHASE 6 §11: Verify debouncing — a fresh authoritative
            # get_chat_member check runs on every ACCEPTED tap; rapid
            # double-taps are absorbed (never hammer Telegram, never count
            # a transient failure as a membership state).
            if _fj_verify_debounced(user.id):
                logger.info("FORCE_JOIN_VERIFY user_id=%s arg=%s "
                            "debounced=1 (tap within %.1fs)",
                            user.id, arg[:40], FJ_VERIFY_DEBOUNCE_SECONDS)
                await safe_answer_callback(
                    q, "\u23F3 Checking membership\u2026 one moment.")
            else:
                logger.info("FORCE_JOIN_VERIFY user_id=%s arg=%s debounced=0",
                            user.id, arg[:40])
                await safe_answer_callback(q, "\u23F3 Checking membership\u2026")
                logger.debug("ForceJoin verify route: arg=%s user=%s", arg, user.id)
                if is_msg_link(arg):
                    message_id = parse_msg_link(arg)
                    await deliver_message_file(update, context, message_id, user)
                elif is_collection_link(arg):
                    collection_code = parse_collection_link(arg)
                    await deliver_collection(update, context, collection_code, user)
                elif is_range_link(arg):
                    # Issue 5: legacy range link — migrate to collection, then deliver.
                    start_id, end_id = parse_range_link(arg)
                    code = await _migrate_legacy_range_to_collection(start_id, end_id, user_id=user.id)
                    if code:
                        await deliver_collection(update, context, code, user)
                    else:
                        await safe_send_text(context.bot, update.effective_chat.id,
                                             "\u274C Invalid or expired link.")
                else:
                    # BOTV13 Part 1: try the full arg first, then extract routing ID.
                    full_row = await db.get_payload(arg)
                    if full_row:
                        await attempt_delivery(update, context, arg, user)
                    else:
                        routing_id, _ = await _resolve_routing_id(arg)
                        if routing_id:
                            if is_collection_link(routing_id):
                                collection_code = parse_collection_link(routing_id)
                                await deliver_collection(update, context, collection_code, user)
                            else:
                                await attempt_delivery(update, context, routing_id, user)
                        else:
                            await safe_send_text(context.bot, update.effective_chat.id,
                                                 "\u274C Invalid or expired link.")

        # ---- copy link (payload) ----
        # BOTV13 Phase 1B: plcopy:<id> is the canonical short callback for
        # copying a payload link. copy_id:<id> is kept as an alias. copy:<slug>
        # is legacy (may exceed 64-byte callback_data limit). All three resolve
        # the payload from the database and generate a human-friendly link with
        # 64-char Telegram start-parameter protection.
        elif data.startswith("plcopy:") or data.startswith("copy_id:"):
            try:
                pid = int(data.split(":", 1)[1])
            except ValueError:
                await safe_answer_callback(q, "Invalid payload.", show_alert=True)
                return
            p_row = await db.get_payload_by_id(pid)
            if not p_row:
                await safe_answer_callback(q, "Payload not found.", show_alert=True)
                return
            payload_slug = p_row["payload"]
            dn = p_row["display_name"] if "display_name" in p_row.keys() else None
            await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F4CB *Copy this link:*\n{md_code_span(build_link(payload_slug, display_name=dn))}",
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data.startswith("copy:"):
            payload = data.split(":", 1)[1]
            # BOTV13 Part 1: look up display_name for human-friendly links.
            p_row = await db.get_payload(payload)
            dn = p_row["display_name"] if p_row and "display_name" in p_row.keys() else None
            await safe_send_text(context.bot, q.message.chat_id,
                f"\U0001F4CB *Copy this link:*\n{md_code_span(build_link(payload, display_name=dn))}",
                parse_mode=ParseMode.MARKDOWN,
            )
        # ---- copy message-id direct link (m<link>) ----
        elif data.startswith("mlinkcopy:"):
            message_id = int(data.split(":", 1)[1])
            await safe_send_text(context.bot, q.message.chat_id, 
                f"\U0001F4CB *Copy this direct link:*\n{md_code_span(build_msg_link(message_id))}",
                parse_mode=ParseMode.MARKDOWN,
            )
        # ---- BOTV13 PART 8: Database Backup ----
        elif data == "backup:db":
            if not await is_admin(user.id):
                await safe_answer_callback(q, "Admins only.", show_alert=True)
                return
            await safe_answer_callback(q, "\U0001F4E6 Creating backup...")
            try:
                import zipfile, tempfile
                from datetime import datetime as _dt
                timestamp = _dt.now().strftime("%Y%m%d_%H%M%S")
                zip_name = f"botv13_backup_{timestamp}.zip"
                zip_path = os.path.join(tempfile.gettempdir(), zip_name)
                # Use the REAL configured database filename(s). Audit: this
                # project uses exactly ONE SQLite database (DATABASE_FILE,
                # default "payload_bot.db"). We do NOT invent a second DB.
                db_basename = os.path.basename(DATABASE_FILE) or "payload_bot.db"
                backup_db_path = os.path.join(tempfile.gettempdir(), f"_backup_{timestamp}.db")
                # BOTV13 Phase E: SQLite consistent backup API. This is the
                # correct way to snapshot a WAL-mode database — it performs
                # an online checkpoint so the snapshot includes all committed
                # pages without corruption. The resulting backup_db_path is a
                # standalone, independently-openable SQLite file.
                source_conn = sqlite3.connect(DATABASE_FILE)
                backup_conn = sqlite3.connect(backup_db_path)
                source_conn.backup(backup_conn)
                backup_conn.close()
                source_conn.close()
                # Phase E fix: include ONLY the consistent snapshot in the ZIP.
                # The live -wal / -shm files are NOT included separately — the
                # backup API already checkpointed them into the snapshot, and
                # including the live WAL/SHM could corrupt a restore.
                files_to_zip = [(backup_db_path, db_basename)]
                # Create the ZIP.
                with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                    for src, arcname in files_to_zip:
                        zf.write(src, arcname)
                # Send the ZIP to the requesting admin (private chat).
                with open(zip_path, 'rb') as f:
                    await context.bot.send_document(
                        chat_id=user.id,
                        document=f,
                        filename=zip_name,
                        caption=f"\U0001F4BE Database Backup\n\n"
                                f"File: {zip_name}\n"
                                f"Database: {db_basename}\n"
                                f"Created: {timestamp}\n\n"
                                f"Store this file safely. It contains all bot data.",
                    )
                await log_admin_action(user.id, "backup_database", "database", None,
                                      f"file={zip_name} db={db_basename}")
                logger.info("Backup: created and sent %s to admin %s (db=%s)",
                            zip_name, user.id, db_basename)
            except Exception as e:  # noqa: BLE001
                logger.error("Backup: failed: %s", e, exc_info=True)
                await safe_send_text(context.bot, q.message.chat_id,
                    f"\u274C Backup failed: {e}")
            finally:
                # Clean up ALL temporary files (snapshot DB + ZIP).
                try:
                    if os.path.exists(zip_path):
                        os.remove(zip_path)
                    if os.path.exists(backup_db_path):
                        os.remove(backup_db_path)
                except Exception:  # noqa: BLE001
                    pass
        # ---- user "Home" button from invalid link screen ----
        elif data == "start_home":
            user_obj = q.from_user
            # BOTV13 fix: use is_admin() so DB-stored admins get the panel too.
            if user_obj and await is_admin(user_obj.id):
                await show_admin_panel(update, context)
            else:
                await send_start_message(context.bot, user_obj.id, "first")
        else:
            await safe_answer_callback(q, "Unknown action.", show_alert=True)
    except BadRequest as e:
        if "not modified" in str(e).lower():
            return  # benign — UI already current; finally still logs RESULT
        _cb_success = False
        logger.error("Callback error (%s): %s", data, e)
        try:
            await safe_answer_callback(q, "\u26A0 An error occurred.", show_alert=True)
        except Exception:
            pass
    except TelegramError as e:
        _cb_success = False
        logger.error("Callback error (%s): %s", data, e)
        try:
            await safe_answer_callback(q, "\u26A0 An error occurred.", show_alert=True)
        except Exception:
            pass
    except Exception as e:
        # Issue #43: catch ALL exceptions so the callback never silently fails.
        _cb_success = False
        logger.error("Callback error (%s): %s", data, e, exc_info=True)
        try:
            await safe_answer_callback(q, "\u26A0 An error occurred.", show_alert=True)
        except Exception:
            pass
    finally:
        # BOT6 Phase 18/27: every callback MUST log its completion result so no
        # callback silently returns without evidence. Duration + success + the
        # same trace_id as RECEIVED/ANSWER so the full journey is reconstructable.
        _dt = int((time.time() - _t0) * 1000)
        logger.info(
            "BOT6_CALLBACK_RESULT trace_id=%s callback_data=%s user_id=%s "
            "message_id=%s success=%s duration_ms=%s",
            _trace_id, data_peek[:60], _cb_user, _cb_msg_id, _cb_success, _dt,
        )



# ============================================================
# ERROR HANDLER
# ============================================================
async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOT6: log the FULL exception with structured trace + trace_id, then answer
    the callback so the spinner stops, and send a friendly user message."""
    import traceback as _tb
    import uuid as _uuid
    _trace_id = _uuid.uuid4().hex[:12]
    # Try to recover the callback trace_id if this error came from on_callback.
    try:
        if context and getattr(context, "user_data", None):
            _trace_id = context.user_data.get("_trace_id") or _trace_id
    except Exception:  # noqa: BLE001
        pass
    _handler = "unknown"
    try:
        if update is not None:
            if getattr(update, "callback_query", None):
                _handler = "callback"
            elif getattr(update, "message", None):
                _handler = "message"
            elif getattr(update, "channel_post", None):
                _handler = "channel_post"
    except Exception:  # noqa: BLE001
        pass
    _tb_str = "".join(_tb.format_exception(type(context.error), context.error,
                                            context.error.__traceback__))
    logger.error(
        "BOT6_EXCEPTION trace_id=%s handler=%s error_type=%s error=%s\n%s",
        _trace_id, _handler, type(context.error).__name__, str(context.error)[:200], _tb_str,
    )
    logger.error("Exception while handling update: %s", context.error, exc_info=context.error)
    # Try to answer the callback query so the spinner stops.
    if update and hasattr(update, "callback_query") and update.callback_query:
        try:
            await update.callback_query.answer(
                "\u26A0 Something went wrong.\nPlease try again.", show_alert=True
            )
        except Exception:  # noqa: BLE001
            pass
    # Try to send a generic error message to the user.
    if update and hasattr(update, "effective_chat") and update.effective_chat:
        try:
            await safe_send_text(context.bot, update.effective_chat.id,
                "\u26A0 Something went wrong.\nPlease try again."
            )
        except Exception:  # noqa: BLE001
            pass
