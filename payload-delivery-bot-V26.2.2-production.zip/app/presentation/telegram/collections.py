"""Collections — collection delivery, browse, download.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations




# (_process_forward_album_delayed removed — Issue 21 unified all forwards into
#  the awaiting_fwd_batch path, which handles albums + standalone forwards
#  uniformly via _process_forward_batch_delayed + _finalize_forward_batch.)


# ============================================================
# COLLECTION SYSTEM  (Issue 2 Critical Fix: explicit storage)
# Replaces the unreliable rSTART_END range model. Each collection stores
# EVERY message_id explicitly in collection_items so delivery is always exact.
# ============================================================
async def _resolve_range_channel(start_id: int, end_id: int) -> Optional[int]:
    """Backward-compat: resolve the channel for an old r<link> range.
    Used only by the auto-migration shim that converts legacy ranges to
    explicit collections on first open."""
    return await db.resolve_channel_for_range(start_id, end_id)



async def _migrate_legacy_range_to_collection(start_id: int, end_id: int,
                                               user_id: Optional[int] = None) -> Optional[str]:
    """Issue 2 backward-compat: auto-migrate an old rSTART_END range link to an
    explicit collection. Reads the files in the range, stores every message_id
    explicitly, and returns the new collection code. Returns None on failure."""
    channel_id = await _resolve_range_channel(start_id, end_id)
    if channel_id is None:
        return None
    files = await db.files_in_message_range(start_id, end_id, channel_id=channel_id)
    if not files:
        return None
    msg_ids = [int(f["message_id"]) for f in files]
    # Generate a unique collection code (retry on collision).
    for _ in range(10):
        code = generate_collection_code()
        if not await db.collection_exists(code):
            ok = await db.create_collection(code, channel_id, msg_ids, created_by=user_id)
            if ok:
                logger.info("Migrated legacy range %s-%s -> collection %s (%d files)",
                            start_id, end_id, code, len(msg_ids))
                return code
    return None



async def deliver_collection(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             collection_code: str, user: User) -> None:
    """Force-join check + collection menu (Download All / Browse Files).

    Issue 2 Critical Fix: loads the EXPLICIT collection_items — never scans a
    range, never guesses. Delivery is always exact.
    """
    if not rate_limiter.check(user.id):
        await reply_protected(update, 
            "\u23F3 Too many requests. Please wait a minute and try again."
        )
        return
    coll = await db.get_collection(collection_code)
    if not coll:
        # Issue 16/22: clear, useful error. Type + Reason, no internal IDs.
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Delivery link unavailable.\n\n"
                             "Type: Collection\n\n"
                             "Reason: Collection removed by administrator.")
        return
    item_count = await db.count_collection_items(collection_code)
    if item_count == 0:
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Delivery link unavailable.\n\n"
                             "Type: Collection\n\n"
                             "Reason: Collection is empty or removed by administrator.")
        return

    # Access Engine V1: collections have no payload row -> FORCE_JOIN policy.
    # The verify callback re-enters via deliver_collection with the c<code> arg.
    c_arg = f"{COLLECTION_LINK_PREFIX}{collection_code}"
    if not await enforce_access(update, context, user,
                                payload_code=c_arg, link_arg=c_arg):
        return

    await db.increment_stat("range_downloads")
    await show_collection_menu(update, context, collection_code)



async def _collection_menu_payload(collection_code: str) -> Optional[Tuple[str, InlineKeyboardMarkup]]:
    """Build the Collection Ready menu text + keyboard (single source of truth).

    Shared by show_collection_menu (update-driven path) and the Watch Ads V2
    auto-resume delivery (bot-driven path) so there is exactly ONE collection
    menu renderer. Returns None when the collection no longer exists.
    Never exposes message ids, collection ids, channel ids or database ids.
    """
    coll = await db.get_collection(collection_code)
    if not coll:
        return None
    total = coll["file_count"] or 0
    # BOTV13 Part 1: try to get the display_name for human-friendly collection links.
    coll_display_name = None
    coll_payload = await db.get_payload(f"{COLLECTION_LINK_PREFIX}{collection_code}")
    if coll_payload and "display_name" in coll_payload.keys():
        coll_display_name = coll_payload["display_name"]
    text = (
        "\U0001F4E6 Collection Ready\n\n"
        f"This collection contains {total} files.\n"
        "Choose an option below."
    )
    share_url = f"https://t.me/share/url?url={build_collection_link(collection_code, display_name=coll_display_name)}"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4E5 Download Collection",
                              callback_data=f"coldl:{collection_code}")],
        [InlineKeyboardButton("\U0001F4C2 Browse Files",
                              callback_data=f"cobrowse:{collection_code}:0")],
        [InlineKeyboardButton("\U0001F4E4 Share Collection", url=share_url)],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="coclose")],
    ])
    return text, kb



async def show_collection_menu(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                collection_code: str) -> None:
    """Simplified Collection screen. Never exposes message ids, collection
    ids, channel ids or database ids. Plain text so filenames / special
    characters can never crash Telegram formatting. Returning to this menu
    cancels any pending Browse Files auto-delete timer."""
    _cancel_browse_timer(context, collection_code)
    built = await _collection_menu_payload(collection_code)
    if not built:
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Invalid or expired link.")
        return
    text, kb = built
    if update.callback_query:
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



async def _load_collection_files(collection_code: str) -> List[aiosqlite.Row]:
    """Load the full file rows for a collection from explicit storage.

    Issue 2 Critical Fix: reads collection_items (explicit message_ids), joins
    to indexed_files, and returns ONLY files that still exist (deleted source
    files are excluded — never delivered as errors).
    """
    rows = await db.get_collection_items(collection_code)
    # Filter to rows where indexed_files row exists (file_id present).
    files: List[aiosqlite.Row] = []
    for r in rows:
        # indexed_files columns are prefixed by the join; check file_id.
        if r["file_id"] is not None:
            files.append(r)
    return files



async def download_collection_all(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   collection_code: str, user: User) -> None:
    """Download Collection: album delivery (photo/video/animation in chunks of
    10+10+5) with sequential fallback for document/voice/sticker/video_note.
    Issue 2: files come from EXPLICIT collection_items — never a range scan.

    BOTV13: delegates the post-auth delivery to the Unified Delivery Engine
    (_deliver_files_core). The status-message edit + its 20s auto-delete remain
    here (UI-specific to the Download Collection button).
    Issue 36 Critical Fix: re-check force-join on EVERY download attempt —
    never trust the previous check at deliver_collection entry point.
    """
    # Access Engine V1 (Issue 36 successor): fresh re-authorization on EVERY
    # download attempt. A user on the collection menu may have left a channel
    # since — they must NOT download. Routed through the Access Engine so no
    # delivery path bypasses authorization.
    c_arg = f"{COLLECTION_LINK_PREFIX}{collection_code}"
    if not await enforce_access(update, context, user,
                                payload_code=c_arg, link_arg=c_arg):
        await safe_answer_callback(update.callback_query,
            "Please join the required channels first.", show_alert=True)
        return
    files = await _load_collection_files(collection_code)
    if not files:
        await safe_answer_callback(update.callback_query, "No files in this collection.", show_alert=True)
        return
    # Edit the collection menu message into a "Sending..." status message.
    status = await safe_edit_text(
        update.callback_query,
        f"\U0001F4E6 Collection — Download Collection\n\n"
        f"Sending {len(files)} files...\nProgress: 0/{len(files)}",
    )
    # Delegate the full delivery (protect, intro, album send, per-file stats,
    # BOT5 FIX: look up the named-payload row for this collection so the
    # per-payload forward_blocking AND delete_after are honoured.
    coll_payload_row = None
    try:
        coll_payload_row = await db.get_payload(
            f"{COLLECTION_LINK_PREFIX}{collection_code}")
    except Exception:  # noqa: BLE001
        coll_payload_row = None
    result = await _deliver_files_core(
        context.bot, chat_id=user.id, user_id=user.id,
        payload_row=coll_payload_row,
        payload_code=f"{COLLECTION_LINK_PREFIX}{collection_code}",
        files=files,
        delivery_type="collection",
        stat_key="range_downloads",
        bump_album_stat=True,
        collection_code=collection_code,
    )
    sent_count = result["sent_count"]
    # Issue 2 Critical Fix: collection menu cleanup — replace Download/Browse/
    # Share with ✅ Collection Delivered, auto-delete after 20 seconds.
    if status:
        try:
            await status.edit_text(
                f"\u2705 Collection Delivered\n\n"
                f"Files Delivered: {sent_count}/{len(files)}",
            )
        except TelegramError:
            pass
    # Auto-delete the status message after 20 seconds (Issue 2 spec).
    if status and status.message_id:
        asyncio.create_task(
            _auto_delete_status_msg(context.bot, status.chat_id, status.message_id, 20)
        )



async def _auto_delete_status_msg(bot, chat_id: int, message_id: int, delay: int) -> None:
    """Silently delete a status message after `delay` seconds.

    Issue 34: delegates to the persistent schedule_status_delete so it survives
    bot restart."""
    await schedule_status_delete(bot, chat_id, message_id, delay)



async def browse_collection_files(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   collection_code: str, page: int) -> None:
    """Browse Files: 4 Row × 2 Column grid layout (Issue #45).

    Shows 8 files per page in a compact grid. Shortened filenames (max 25 chars).
    No internal IDs exposed. Auto-deletes after 10 seconds.
    Issue 36: re-check force-join on every browse attempt.
    """
    q = update.callback_query
    # Access Engine V1 (Issue 36 successor): fresh re-authorization before browsing.
    user = q.from_user if q else None
    if user:
        c_arg = f"{COLLECTION_LINK_PREFIX}{collection_code}"
        if not await enforce_access(update, context, user,
                                    payload_code=c_arg, link_arg=c_arg):
            await safe_answer_callback(q, "Please join the required channels first.", show_alert=True)
            return
    files = await _load_collection_files(collection_code)
    chat_id = q.message.chat_id if q and q.message else (update.effective_chat.id if update.effective_chat else None)
    if not files:
        await safe_answer_callback(q, "No files to browse.", show_alert=True)
        return
    total = len(files)
    total_pages = max(1, (total + COLLECTION_BROWSE_PAGE_SIZE - 1) // COLLECTION_BROWSE_PAGE_SIZE)
    page = max(0, min(page, total_pages - 1))
    start_idx = page * COLLECTION_BROWSE_PAGE_SIZE
    page_files = files[start_idx:start_idx + COLLECTION_BROWSE_PAGE_SIZE]
    text = (
        "\U0001F4C2 Browse Files\n\n"
        f"Files {start_idx + 1}-{start_idx + len(page_files)} of {total}\n"
        f"Page {page + 1}/{total_pages}"
    )
    # Issue #45: 4×2 grid layout — 2 buttons per row, max 8 per page.
    buttons: List[List[InlineKeyboardButton]] = []
    current_row: List[InlineKeyboardButton] = []
    for f in page_files:
        # Shortened label: emoji + truncated filename (max 25 chars), no IDs.
        emoji = media_emoji(f['media_type'])
        fname = (f['file_name'] or media_type_label(f['media_type']))[:25]
        label = f"{emoji} {fname}"
        current_row.append(InlineKeyboardButton(
            label,
            callback_data=f"cofile:{collection_code}:{f['id']}",
        ))
        if len(current_row) == 2:
            buttons.append(current_row)
            current_row = []
    # Don't forget the last row if it has an odd number.
    if current_row:
        buttons.append(current_row)
    # Navigation row: ◀ Prev | Page X/Y | Next ▶
    nav: List[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("\u2B05\uFE0F Prev",
                                        callback_data=f"cobrowse:{collection_code}:{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}",
                                     callback_data=f"cobrowse:{collection_code}:{page}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Next \u27A1\uFE0F",
                                         callback_data=f"cobrowse:{collection_code}:{page + 1}"))
    buttons.append(nav)
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back to Collection",
                                          callback_data=f"comenu:{collection_code}")])
    kb = InlineKeyboardMarkup(buttons)

    browse_key = f"browse_msg_{collection_code}"
    prev = context.user_data.get(browse_key)
    msg_id = None
    if prev and prev.get("msg_id") and chat_id is not None:
        try:
            await safe_edit_text(context.bot, 
                chat_id=chat_id, message_id=prev["msg_id"],
                text=text, reply_markup=kb,
            )
            msg_id = prev["msg_id"]
        except TelegramError:
            msg_id = None
    if msg_id is None and chat_id is not None:
        sent = await safe_send_text(context.bot, chat_id, text, reply_markup=kb)
        if sent and sent.message_id:
            msg_id = sent.message_id
    if prev and prev.get("task"):
        try:
            prev["task"].cancel()
        except Exception:  # noqa: BLE001
            pass
    if msg_id is not None:
        task = asyncio.create_task(
            schedule_browse_delete(context.bot, chat_id, [msg_id])
        )
        context.user_data[browse_key] = {"msg_id": msg_id, "task": task}



async def deliver_collection_file(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   collection_code: str, file_pk: int, user: User) -> None:
    """Deliver a single file from a collection browse.

    BOTV13: delegates the post-auth delivery to the Unified Delivery Engine
    with use_browse_timer=True (fixed 10s auto-delete via schedule_browse_delete).
    Issue 6 Critical Fix: browse file delivery auto-deletes after exactly 10
    seconds (BROWSE_AUTO_DELETE_DELAY). No countdown, no warning, no notice.
    C2 Security Fix: verifies file_pk actually belongs to collection_code
    before delivery — prevents callback-data tampering.
    """
    file_row = await db.get_indexed_file_by_id(file_pk)
    if not file_row:
        await safe_answer_callback(update.callback_query, "File not found.", show_alert=True)
        return
    # C2 Security Fix: verify this file actually belongs to the collection.
    # Without this check, a user could tamper callback_data to
    # cofile:ANYCODE:ANYFILEPK and download any indexed file.
    items = await db.get_collection_items(collection_code)
    belongs = any(
        item["message_id"] == file_row["message_id"]
        and item["channel_id"] == file_row["channel_id"]
        for item in items
    )
    if not belongs:
        await safe_answer_callback(update.callback_query,
            "This file is not part of this collection.", show_alert=True)
        return
    # Access Engine V1: fresh authorization before delivering a browsed file.
    c_arg = f"{COLLECTION_LINK_PREFIX}{collection_code}"
    if not await enforce_access(update, context, user,
                                payload_code=c_arg, link_arg=c_arg):
        await safe_answer_callback(update.callback_query,
            "Please join the required channels first.", show_alert=True
        )
        return
    await safe_answer_callback(update.callback_query, "Sending file...")
    # Delegate to the Unified Delivery Engine with the browse timer (fixed 10s
    # auto-delete via schedule_browse_delete). No payload_row (browse delivers a
    # single indexed file, not a named payload). No stat_key (per-file stats are
    # bumped inside the helper; browse has no route-level counter).
    await _deliver_files_core(
        context.bot, chat_id=user.id, user_id=user.id,
        payload_row=None,
        payload_code=f"{MSG_LINK_PREFIX}{file_row['message_id']}",
        files=[file_row],
        delivery_type="single",
        stat_key=None,
        use_browse_timer=True,
    )
