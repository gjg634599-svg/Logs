"""Auto-delete — deletion timers, pending deletion recovery.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

from app.presentation.telegram.state import BROWSE_AUTO_DELETE_DELAY



def _fj_user_msg_get(chat_id: int, user_id: int) -> Optional[int]:
    return _fj_user_messages.get((chat_id, user_id))



def _fj_user_msg_set(chat_id: int, user_id: int, message_id: int) -> None:
    _fj_user_messages[(chat_id, user_id)] = message_id



def _fj_user_msg_clear(chat_id: int, user_id: int) -> None:
    _fj_user_messages.pop((chat_id, user_id), None)



def determine_fj_message_action(
    event_source: str,
    remaining: int,
    callback_message_id: Optional[int],
    tracked_message_id: Optional[int],
) -> str:
    """BOT6 centralized FJ message lifecycle decision.

    Returns one of: CREATE, EDIT, ALLOW, NOOP.

    Rules (per the spec):
    1. remaining == 0 → ALLOW (no FJ message needed).
    2. Fresh /start (event_source=START) + remaining > 0 → CREATE, even if a
       tracked message exists. A fresh payload open must produce a fresh FJ
       message (the user may have blocked the bot, left channels, etc).
    3. Verify from the current FJ message (event_source=VERIFY) + remaining > 0
       + callback_message_id == tracked_message_id → EDIT.
    4. Verify from a different message or no tracked message → CREATE.
    5. If tracked message is missing → CREATE.
    """
    if remaining == 0:
        return "ALLOW"
    if event_source == FJ_EVENT_VERIFY:
        # Verify callback — edit ONLY if it comes from the tracked FJ message.
        if callback_message_id and tracked_message_id and callback_message_id == tracked_message_id:
            return "EDIT"
        # Verify from a different message, or no tracked message → CREATE.
        return "CREATE"
    # FJ_EVENT_START or FJ_EVENT_REFRESH — fresh payload open → CREATE.
    # Do NOT edit the old message even if tracked, because the user may have
    # blocked the bot / lost context / left channels.
    return "CREATE"



async def _delete_message_safe(bot, chat_id: int, message_id: int) -> bool:
    """Delete a message, returning True on success. Handles BadRequest
    (already deleted) gracefully — never raises."""
    try:
        await bot.delete_message(chat_id, message_id)
        return True
    except BadRequest as e:
        err_lower = str(e).lower()
        if "not found" in err_lower or "message to delete not found" in err_lower:
            logger.debug("delete_message %s/%s: already gone", chat_id, message_id)
            return True  # treat as success — the message is gone
        logger.debug("delete_message %s/%s: BadRequest: %s", chat_id, message_id, e)
        return False
    except TelegramError as e:
        logger.debug("delete_message %s/%s: %s", chat_id, message_id, e)
        return False



async def _execute_pending_deletion(bot, row_id: int, chat_id: int,
                                     message_id: int) -> None:
    """Delete a single message and remove its pending_deletions row.

    Called by both the in-memory timer and the startup recovery loop. Always
    removes the DB row (even if the message was already deleted) so no stale
    entries remain.
    """
    await _delete_message_safe(bot, chat_id, message_id)
    try:
        await db.remove_pending_deletion_by_id(row_id)
    except Exception as e:  # noqa: BLE001
        logger.error("remove_pending_deletion(%s) failed: %s", row_id, e)
    # Clean up the in-memory task tracker.
    _pending_deletion_tasks.pop((chat_id, message_id), None)



async def schedule_auto_delete(bot, chat_id: int, message_ids: List[int],
                                delay: int) -> None:
    """Schedule delivery messages for deletion after `delay` seconds.

    Issue 34 Critical Fix: persists every deletion to the pending_deletions
    table so it survives bot restart. The in-memory asyncio task handles the
    normal case; the DB row handles recovery.
    """
    if delay <= 0 or not message_ids:
        return
    delete_at = int(time.time()) + int(delay)
    for mid in message_ids:
        # H2 Fix: cancel any existing task for this (chat_id, message_id)
        # before creating a new one, to prevent orphaned DB rows.
        existing = _pending_deletion_tasks.get((chat_id, mid))
        if existing and not existing.done():
            existing.cancel()
        try:
            row_id = await db.add_pending_deletion(chat_id, mid, delete_at, DELETION_TYPE_DELIVERY)
        except Exception as e:  # noqa: BLE001
            logger.error("add_pending_deletion failed: %s", e)
            continue
        task = asyncio.create_task(_delayed_deletion(bot, row_id, chat_id, mid, delay))
        _pending_deletion_tasks[(chat_id, mid)] = task



async def _delayed_deletion(bot, row_id: int, chat_id: int,
                             message_id: int, delay: int) -> None:
    """In-memory timer that deletes a message after `delay` seconds, then
    removes its DB row. If the task is cancelled (e.g. bot shutdown), the
    DB row remains and will be processed on next startup."""
    try:
        await asyncio.sleep(delay)
        await _execute_pending_deletion(bot, row_id, chat_id, message_id)
    except asyncio.CancelledError:
        # Bot is shutting down — leave the DB row for startup recovery.
        pass



async def schedule_browse_delete(bot, chat_id: int, message_ids: List[int],
                                 delay: int = BROWSE_AUTO_DELETE_DELAY) -> None:
    """Silently delete Browse Files content after `delay` seconds.

    Issue 34: persists to DB for restart recovery. Only touches the browse
    message id(s) passed in — never delivered files or albums.
    """
    if delay <= 0 or not message_ids:
        return
    delete_at = int(time.time()) + int(delay)
    for mid in message_ids:
        # H2 Fix: cancel existing task before creating new one.
        existing = _pending_deletion_tasks.get((chat_id, mid))
        if existing and not existing.done():
            existing.cancel()
        try:
            row_id = await db.add_pending_deletion(chat_id, mid, delete_at, DELETION_TYPE_BROWSE)
        except Exception as e:  # noqa: BLE001
            logger.error("add_pending_deletion(browse) failed: %s", e)
            continue
        task = asyncio.create_task(_delayed_deletion(bot, row_id, chat_id, mid, delay))
        _pending_deletion_tasks[(chat_id, mid)] = task



def _cancel_browse_timer(context: ContextTypes.DEFAULT_TYPE,
                         key_part1: Optional[str] = None,
                         key_part2: Optional[str] = None) -> None:
    """Cancel any pending Browse Files in-memory auto-delete timer.

    Note (Issue 34): this only cancels the in-memory asyncio task. The DB row
    remains and will still fire on startup recovery if the bot restarts before
    the cancellation would have taken effect. This is acceptable — browse
    messages should be deleted regardless.
    """
    keys_to_clear: List[str] = []
    if key_part1 is not None and key_part2 is not None:
        keys_to_clear.append(f"browse_msg_{key_part1}_{key_part2}")
    elif key_part1 is not None:
        keys_to_clear.append(f"browse_msg_{key_part1}")
    else:
        keys_to_clear = [k for k in list(context.user_data.keys()) if k.startswith("browse_msg_")]
    for k in keys_to_clear:
        entry = context.user_data.pop(k, None)
        if entry and isinstance(entry, dict):
            task = entry.get("task")
            if task:
                try:
                    task.cancel()
                except Exception:  # noqa: BLE001
                    pass



async def schedule_admin_preview_delete(bot, chat_id: int, message_ids: List[int],
                                        delay: Optional[int] = None) -> None:
    """Silently delete admin preview messages after `delay` seconds.
    BOT5: when delay is None, resolves from resolve_preview_timer() (global
    preview timer only — NEVER payload delivery timer)."""
    if delay is None:
        delay = await resolve_preview_timer()
    if delay <= 0 or not message_ids:
        return
    delete_at = int(time.time()) + int(delay)
    for mid in message_ids:
        # H2 Fix: cancel existing task before creating new one.
        existing = _pending_deletion_tasks.get((chat_id, mid))
        if existing and not existing.done():
            existing.cancel()
        try:
            row_id = await db.add_pending_deletion(chat_id, mid, delete_at, DELETION_TYPE_ADMIN_PREVIEW)
        except Exception as e:  # noqa: BLE001
            logger.error("add_pending_deletion(admin_preview) failed: %s", e)
            continue
        task = asyncio.create_task(_delayed_deletion(bot, row_id, chat_id, mid, delay))
        _pending_deletion_tasks[(chat_id, mid)] = task



async def schedule_status_delete(bot, chat_id: int, message_id: int,
                                  delay: int = 20) -> None:
    """Schedule a status message (e.g. ✅ Collection Delivered) for deletion.

    Issue 34: persists to DB for restart recovery.
    """
    if delay <= 0:
        return
    # H2 Fix: cancel existing task before creating new one.
    existing = _pending_deletion_tasks.get((chat_id, message_id))
    if existing and not existing.done():
        existing.cancel()
    delete_at = int(time.time()) + int(delay)
    try:
        row_id = await db.add_pending_deletion(chat_id, message_id, delete_at, DELETION_TYPE_STATUS)
    except Exception as e:  # noqa: BLE001
        logger.error("add_pending_deletion(status) failed: %s", e)
        return
    task = asyncio.create_task(_delayed_deletion(bot, row_id, chat_id, message_id, delay))
    _pending_deletion_tasks[(chat_id, message_id)] = task



async def recover_pending_deletions(bot) -> Tuple[int, int]:
    """Issue 34: startup recovery. Called from post_init.

    1. Delete all due messages immediately (delete_at <= now).
    2. Re-schedule all upcoming messages (delete_at > now).

    Returns (immediately_deleted, rescheduled).
    """
    now_ts = int(time.time())
    # 1. Due deletions — delete now.
    due = await db.due_pending_deletions(now_ts)
    immediate_count = 0
    for row in due:
        await _delete_message_safe(bot, row["chat_id"], row["message_id"])
        try:
            await db.remove_pending_deletion_by_id(row["id"])
        except Exception as e:  # noqa: BLE001
            logger.error("startup remove_pending_deletion(%s) failed: %s", row["id"], e)
        immediate_count += 1
    # 2. Upcoming deletions — re-schedule in-memory timers.
    upcoming = await db.upcoming_pending_deletions(now_ts)
    rescheduled = 0
    for row in upcoming:
        remaining_delay = max(1, int(row["delete_at"]) - now_ts)
        task = asyncio.create_task(_delayed_deletion(
            bot, row["id"], row["chat_id"], row["message_id"], remaining_delay
        ))
        _pending_deletion_tasks[(row["chat_id"], row["message_id"])] = task
        rescheduled += 1
    if immediate_count or rescheduled:
        logger.info("Pending deletions: %d deleted immediately, %d re-scheduled",
                    immediate_count, rescheduled)
    return immediate_count, rescheduled
