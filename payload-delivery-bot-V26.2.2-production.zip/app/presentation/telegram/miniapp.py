"""Watch Ads Mini App — aiohttp mini app pages, postback, webapp auth.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def _wad_page_html(title: str, body: str, *, extra_head: str = "",
                   show_back: bool = False) -> str:
    """Minimal error/info page for the Watch Ads Mini App (no secrets)."""
    back_btn = ('<button class="btn ghost" onclick="try{Telegram.WebApp.close()}'
                'catch(e){history.back()}">Return to Telegram</button>') if show_back else ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title}</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
{extra_head}
<style>
:root {{ color-scheme: dark; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #17212b; color: #f5f5f5; min-height: 100vh; min-height: 100dvh;
  display: flex; align-items: center; justify-content: center; padding: 24px;
}}
.card {{
  max-width: 420px; width: 100%; background: #232e3c; border-radius: 20px;
  padding: 28px 24px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,.35);
}}
h1 {{ font-size: 20px; margin-bottom: 12px; }}
p {{ font-size: 15px; line-height: 1.55; color: #b8c4ce; margin-bottom: 10px; }}
.icon {{ font-size: 42px; margin-bottom: 14px; }}
.btn {{
  display: block; width: 100%; border: none; border-radius: 14px; padding: 15px 16px;
  font-size: 16px; font-weight: 600; cursor: pointer; margin-top: 14px;
  background: #2ea6ff; color: #fff; transition: transform .12s ease, opacity .12s ease;
}}
.btn:active {{ transform: scale(.98); }}
.btn[disabled] {{ opacity: .55; cursor: default; }}
.btn.success {{ background: #31c48d; }}
.btn.ghost {{ background: transparent; border: 1px solid #3a4756; color: #b8c4ce; }}
.small {{ font-size: 12.5px; color: #7e8b98; margin-top: 12px; }}
.spinner {{
  width: 26px; height: 26px; margin: 14px auto 4px; border-radius: 50%;
  border: 3px solid #3a4756; border-top-color: #2ea6ff;
  animation: spin 1s linear infinite; display: none;
}}
.spinner.on {{ display: block; }}
@keyframes spin {{ to {{ transform: rotate(360deg); }} }}
</style>
</head>
<body>
<div class="card">{body}{back_btn}</div>
</body>
</html>"""



def _wad_mini_app_page(token: str, payload_title: str, sdk_code: str,
                       sdk_fn: Optional[str], unlock_window: int,
                       required_ads: int = 1) -> str:
    """THE Watch Ads Mini App page (V2 v26 — multi-ad + auto-close).

    Serves the MINIMUM information the frontend needs: the session token, the
    payload display name and the server-decided required ad count. NO
    BOT_TOKEN, no DB credentials, no private Monetag credentials, no server
    secrets ever reach this page.

    The admin-supplied Monetag SDK tag is embedded VERBATIM below <head>
    (per Monetag's official integration instructions). The app JS calls
    window[sdk_fn]({ymid: <ymid-for-ad>, type: 'end'}) — the Promise resolves
    when the ad UI finishes, but the frontend is NEVER treated as proof of
    reward: ONLY the Monetag S2S postback (validated server-side) advances
    completed_ads, and the page polls the identity-verified status endpoint
    until the server says the required reward count is reached.

    State machine (all display-only; the backend stays authoritative):
      INITIAL       "Watch Ad to Unlock"
      LOADING       "Loading ad…"
      WATCHING      "Watch the ad to unlock."
      MULTI-AD      "Ad 1 of 3" / "Reward verified — preparing the next ad…"
      VERIFICATION  "Ad completed — verifying reward…" — held while the S2S
                    postback is DELAYED (waiting state with live server
                    progress "X/N"; NEVER "verification failed"). Only after
                    VERIFY_GRACE (30s) does the per-ad retry button return.
      SUCCESS       "Your payload is unlocked." — the page AUTOMATICALLY
                    switches to this state when the server confirms ALL
                    required rewards, shows "Rewards verified: N/N" and
                    provides the [✅ Continue to Telegram] button. The app
                    NEVER closes itself on a timer — the ONLY close is the
                    user's Continue tap (or their own X), and the button is
                    reachable ONLY in the server-confirmed rewarded state.
      ERROR         safe user-facing message (no internals) — only for a
                    genuinely unloadable ad SDK, never for a pending reward.
      EXPIRED       "Ad session expired. Return to Telegram and start again."

    Poll answers that are transient (rate_limited / error / unauthorized /
    invalid / forbidden) are IGNORED as states — the app keeps waiting for
    the server's authoritative answer (never a frontend-declared failure).

    Multi-ad: ONE Mini App session hosts up to required_ads sequential
    rewarded ads. Ad 1 uses ymid=token; ad N>=2 uses ymid=token_N (the
    backend maps both to this session and counts each DISTINCT ymid once).
    After each server-verified reward the app auto-advances to the next ad;
    if the provider SDK cannot re-run programmatically, a per-ad button is
    shown instead (still ONE Telegram Watch Ad click per session).

    Preload (docs.monetag.com — SDK Reference / Rewarded Interstitial): the
    app best-effort warms the NEXT ad with show_XXX({type:'preload', ymid})
    (the documented pattern; timeout applies to preload only) so the next
    show call is fast. Failures are ignored — the show call loads on demand.
    Preloading NEVER affects reward semantics.

    Auto-close (V5.1): the server-confirmed rewarded state renders the
    unlocked screen + [✅ Continue to Telegram]; close() runs ONLY on that
    button tap. If the postback is delayed the app keeps polling and never
    shows failure. Telegram.WebApp.close() is therefore only ever called
    after status == rewarded AND completed_ads >= required_ads.
    """
    safe_title = (payload_title or "Exclusive Content").replace("&", "&amp;") \
        .replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    token_js = json.dumps(token)
    sdk_fn_js = json.dumps(sdk_fn or "")
    req_ads_js = int(required_ads) if required_ads and int(required_ads) > 0 else 1
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Watch Ad</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<!-- Admin-supplied Monetag SDK / ad-tag code (stored in bot_settings) -->
{sdk_code}
<style>
:root {{ color-scheme: dark; }}
* {{ box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #17212b; color: #f5f5f5; min-height: 100vh; min-height: 100dvh;
  display: flex; align-items: center; justify-content: center; padding: 24px;
}}
.card {{
  max-width: 420px; width: 100%; background: #232e3c; border-radius: 20px;
  padding: 28px 24px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,.35);
}}
.icon {{ font-size: 44px; margin-bottom: 12px; }}
h1 {{ font-size: 20px; margin-bottom: 10px; }}
.payload {{ font-size: 15px; color: #9fb2c1; margin-bottom: 18px; word-break: break-word; }}
p {{ font-size: 14.5px; line-height: 1.55; color: #b8c4ce; margin-bottom: 8px; }}
.btn {{
  display: block; width: 100%; border: none; border-radius: 14px; padding: 16px;
  font-size: 16px; font-weight: 700; cursor: pointer; margin-top: 12px;
  background: #2ea6ff; color: #fff; transition: transform .12s ease, opacity .2s ease;
}}
.btn:active {{ transform: scale(.98); }}
.btn[disabled] {{ opacity: .55; cursor: default; }}
.btn.success {{ background: #31c48d; }}
.btn.ghost {{ background: transparent; border: 1px solid #3a4756; color: #b8c4ce; font-weight: 500; }}
.state {{ min-height: 24px; font-size: 14.5px; color: #b8c4ce; margin-top: 6px; }}
.spinner {{
  width: 24px; height: 24px; margin: 12px auto 0; border-radius: 50%;
  border: 3px solid #3a4756; border-top-color: #2ea6ff;
  animation: spin 1s linear infinite; display: none;
}}
.spinner.on {{ display: block; }}
@keyframes spin {{ to {{ transform: rotate(360deg); }} }}
.steps {{ margin: 10px 0 2px; }}
.step {{
  display: inline-block; width: 10px; height: 10px; border-radius: 50%;
  background: #3a4756; margin: 0 4px; transition: background .25s ease;
}}
.step.done {{ background: #31c48d; }}
.step.cur {{ background: #2ea6ff; }}
.pill {{
  display: inline-block; margin-top: 14px; padding: 6px 12px; border-radius: 999px;
  background: #1c2836; color: #8fa3b5; font-size: 12px;
}}
</style>
</head>
<body>
<div class="card" id="card">
  <div class="icon" id="icon">🎬</div>
  <h1 id="headline">Watch Ad to Unlock</h1>
  <div class="payload" id="payload">{safe_title}</div>
  <p id="desc">Watch the rewarded ad{("s" if req_ads_js > 1 else "")} to unlock.
  Your unlock stays active for {unlock_window} seconds after verification.</p>
  <div class="steps" id="steps" style="display:none"></div>
  <button class="btn" id="watchBtn">▶️ Watch Ad</button>
  <div class="state" id="state"></div>
  <div class="spinner" id="spinner"></div>
  <button class="btn ghost" id="retryBtn" style="display:none">🔄 Try Again</button>
  <button class="btn success" id="doneBtn" style="display:none">✅ Continue to Telegram</button>
  <div class="pill">Rewarded ad · verification required</div>
</div>
<script>
(function () {{
  "use strict";
  var TOKEN = {token_js};
  var SDK_FN = {sdk_fn_js};
  var REQUIRED = {req_ads_js};
  var $ = function (id) {{ return document.getElementById(id); }};
  var tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {{ try {{ tg.ready(); tg.expand(); }} catch (e) {{}} }}

  // ---- Server-side truth mirror (updated ONLY from the status endpoint) ----
  var completed = 0;          // server-verified rewards so far
  var finished = false;       // session rewarded (all required ads verified)
  var adRunning = false;      // an SDK ad call is in flight
  var pollTimer = null;
  var pollStart = Date.now();  // when this app instance started polling
  var lastProgressAt = 0;      // last server-confirmed progress timestamp
  var adFinishedAt = 0;        // when the current ad's UI finished (waiting for
                               // its S2S postback — a delay is NOT a failure)
  var VERIFY_GRACE = 30000;    // ms to stay in the verifying state before
                               // re-enabling the manual per-ad button
  // V5.2 (bot.log 18, session 22 @ 03:38): the ad-index REGRESSION guard.
  // A reloaded page starts with completed=0; if the initial status poll was
  // rate_limited the local mirror is STALE — invoking the SDK then re-ran
  // AD 1 (base ymid) while the server was already on ad 3 (duplicate
  // postback, wasted ad, mixed UI). Three invariants now hold:
  var serverSynced = false;    // a REAL status answer (pending/rewarded/…)
                               // has been received — NEVER rate_limited/error
  var adFloor = 0;             // monotonic: the highest ad index this page
                               // instance ever invoked or the server assigned
  var pendingAdvance = false;  // server progress seen while an ad was still
                               // running — advance when it settles
  var bootRendered = false;    // initial/resume screen rendered from a REAL
                               // server answer (reload recovery)
  var advanceTimer = null;     // V5.2: the single pending auto-advance timer

  function setBusy(msg) {{
    $("state").textContent = msg || "";
    $("spinner").classList.add("on");
  }}
  function setIdle(msg) {{
    $("state").textContent = msg || "";
    $("spinner").classList.remove("on");
  }}
  function renderSteps() {{
    var box = $("steps");
    if (REQUIRED < 2) {{ box.style.display = "none"; return; }}
    box.style.display = "block";
    var html = "";
    for (var i = 1; i <= REQUIRED; i++) {{
      var cls = "step" + (i <= completed ? " done" : (i === completed + 1 && !finished ? " cur" : ""));
      html += '<span class="' + cls + '"></span>';
    }}
    box.innerHTML = html;
  }}
  function setWatchButton(nextAd) {{
    var btn = $("watchBtn");
    if (REQUIRED < 2 || !nextAd) {{
      btn.textContent = "▶️ Watch Ad";
    }} else {{
      btn.textContent = "▶️ Watch Ad " + nextAd + " of " + REQUIRED;
    }}
  }}
  function showInitial(nextAd) {{
    $("icon").textContent = "🎬";
    $("headline").textContent = "Watch Ad to Unlock";
    $("desc").textContent = REQUIRED > 1
      ? "Watch " + REQUIRED + " short ads to unlock. Your unlock stays active for " + {unlock_window} + " seconds after verification."
      : "Watch a short rewarded ad. Once the reward is verified, your unlock stays active for " + {unlock_window} + " seconds.";
    $("watchBtn").style.display = "block";
    $("watchBtn").disabled = false;
    $("retryBtn").style.display = "none";
    setWatchButton(nextAd);
    renderSteps();
    setIdle(completed > 0 && !finished
      ? "Rewards verified: " + completed + "/" + REQUIRED : "");
  }}
  function showSuccess() {{
    if (finished) return;
    finished = true;
    if (pollTimer) {{ clearInterval(pollTimer); pollTimer = null; }}
    if (advanceTimer) {{ clearTimeout(advanceTimer); advanceTimer = null; }}
    $("icon").textContent = "🎉";
    $("headline").textContent = "Your payload is unlocked!";
    $("desc").textContent = "Rewards verified: " + REQUIRED + "/" + REQUIRED
      + ". Your access stays active for " + {unlock_window}
      + " seconds — tap Continue when you're ready.";
    $("watchBtn").style.display = "none";
    $("retryBtn").style.display = "none";
    $("doneBtn").style.display = "block";
    renderSteps();
    setIdle("");
    // V5.1: NO timer close. The ONLY programmatic close is the Continue
    // button below (bound in the init section) — reachable ONLY here, i.e.
    // ONLY after the SERVER-confirmed rewarded status (status=="rewarded"
    // with completed_ads>=REQUIRED). A resolved SDK promise, a finished ad
    // UI, an elapsed timer, or a pending poll NEVER reaches this state.
  }}
  function showExpired(msg) {{
    if (pollTimer) {{ clearInterval(pollTimer); pollTimer = null; }}
    // V5.2: terminal state — no further ads may run and the boot render
    // must never overwrite the expired screen (an expired session cannot
    // produce new rewards; a NEW session requires a new Telegram click).
    finished = true;
    $("icon").textContent = "⌛";
    $("headline").textContent = "Session Expired";
    $("desc").textContent = msg || "This ad session has expired. Return to Telegram and start again.";
    $("watchBtn").style.display = "none";
    $("retryBtn").style.display = "none";
    setIdle("");
  }}
  function showUnavailable(msg) {{
    $("icon").textContent = "⚠️";
    $("headline").textContent = "Ad Unavailable";
    $("desc").textContent = msg || "The ad could not be loaded. Please try again.";
    $("watchBtn").style.display = "none";
    $("retryBtn").style.display = "block";
    setIdle("");
  }}
  $("retryBtn").addEventListener("click", function () {{ location.reload(); }});

  function findSdkFn() {{
    if (SDK_FN && typeof window[SDK_FN] === "function") return SDK_FN;
    // Fallback: scan for the Monetag show_XXX global.
    for (var k in window) {{
      if (/^show_\\d+$/.test(k) && typeof window[k] === "function") return k;
    }}
    return null;
  }}

  // ---- Start one ad. ymid is UNIQUE PER AD inside this session ----
  // (ad 1 -> TOKEN, ad N>=2 -> TOKEN_N; the backend counts each DISTINCT
  // ymid exactly once via its per-ad reward ledger).
  function ymidForAd(n) {{ return n <= 1 ? TOKEN : (TOKEN + "_" + n); }}

  // ---- Monetag documented preload pattern (docs.monetag.com — SDK
  // Reference / Rewarded Interstitial / Developer FAQ): warm the NEXT ad
  // with show_XXX(type:'preload', ymid, timeout) in the background; the
  // later show call passes the SAME ymid and displays the warmed creative
  // (lower latency, better UX). 'timeout' applies to PRELOAD ONLY (per the
  // official docs it has no effect on 'end'/'start'/'pop'/'inApp').
  // Best-effort ONLY: failures are silently ignored (the show call loads
  // on demand anyway) and this NEVER affects reward semantics — rewards
  // stay 100% server-side S2S-verified.
  function preloadAd(n) {{
    try {{
      if (finished) return;
      var fn = findSdkFn();
      if (!fn) return;
      var p = window[fn]({{ ymid: ymidForAd(n), type: "preload", timeout: 5 }});
      if (p && typeof p.catch === "function") p.catch(function () {{}});
    }} catch (e) {{}}
  }}

  // ---- V5 §34: display-only lifecycle signal to the server log ----
  // NEVER authoritative: rewards are granted ONLY by the Monetag S2S
  // postback verified server-side; this ONLY makes the real ad sequence
  // observable in the production log (WATCH_AD_AD_START / _AD_FINISH /
  // _REWARD_WAIT / _NEXT_AD, source=frontend). Fire-and-forget — it
  // never blocks the UI, never retries, never affects rewards/access.
  function reportEvent(type, adNo) {{
    try {{
      if (!tg || !tg.initData) return;
      fetch("/api/watch-ad/ad-event", {{
        method: "POST",
        headers: {{ "Content-Type": "application/json" }},
        body: JSON.stringify({{ token: TOKEN, initData: tg.initData,
                                type: type, ad_index: adNo || 0 }})
      }}).catch(function () {{}});
    }} catch (e) {{}}
  }}

  function startAd(auto) {{
    if (finished || adRunning) return;
    if (!serverSynced) {{
      // V5.2: NEVER invoke the provider from a stale local mirror. Until a
      // REAL server answer has arrived the ad index is unknown — running
      // now could re-invoke ad 1 (base ymid) on a session the server has
      // already advanced (the log-18 regression). The sync retry loop below
      // is fetching the authoritative state; the button re-enables then.
      setBusy("Syncing with server…");
      return;
    }}
    var fn = findSdkFn();
    if (!fn) {{
      showUnavailable("The ad could not be loaded. Please try again.");
      return;
    }}
    var adNo = completed + 1;
    // V5.2 monotonic guard: the ad index NEVER regresses — neither below
    // the server's assigned next ad (adFloor) nor below any ad this page
    // instance already invoked. A later ad -> earlier ad transition is
    // structurally impossible now.
    if (adNo < adFloor) adNo = adFloor;
    adFloor = adNo;
    adRunning = true;
    $("watchBtn").disabled = true;
    $("watchBtn").style.display = "none";
    setBusy(REQUIRED > 1 ? ("Loading ad " + adNo + " of " + REQUIRED + "…")
                         : "Loading ad…");
    renderSteps();
    var settled = false;
    try {{
      var p = window[fn]({{ ymid: ymidForAd(adNo), type: "end" }});
      // V5 §34: the ad was invoked — report the start + switch to the
      // WATCHING state (the provider SDK overlays its own ad UI now; the
      // provider controls the actual creative and duration).
      reportEvent("ad_start", adNo);
      setBusy(REQUIRED > 1 ? ("Watching ad " + adNo + " of " + REQUIRED + "…")
                           : "Watching ad…");
      if (p && typeof p.then === "function") {{
        p.then(function () {{
          if (settled || finished) return;
          settled = true;
          adRunning = false;
          adFinishedAt = Date.now();  // now waiting for the S2S postback
          reportEvent("ad_finish", adNo);
          reportEvent("reward_wait", adNo);
          if (pendingAdvance && !finished && completed < REQUIRED) {{
            // V5.2: the server verified a NEWER reward while this (stale)
            // ad was still running — its ymid postback was already deduped
            // by the server ledger; advance to the server's next ad NOW
            // (was: wait for VERIFY_GRACE + a manual retry tap).
            pendingAdvance = false;
            adFinishedAt = 0;
            startAd(true);
            return;
          }}
          // Frontend completion is NOT proof of reward — verification is
          // server-side (Monetag S2S postback). Switch to fast polling.
          setBusy(REQUIRED > 1
            ? ("Ad " + adNo + " completed — verifying reward…")
            : "Ad completed — verifying reward…");
          pollSoon();
        }}).catch(function () {{
          if (settled || finished) return;
          settled = true;
          adRunning = false;
          adFinishedAt = Date.now();
          if (pendingAdvance && !finished && completed < REQUIRED) {{
            pendingAdvance = false;
            adFinishedAt = 0;
            startAd(true);
            return;
          }}
          if (auto) {{
            // Provider SDK could not auto-advance — surface the per-ad button
            // (still ONE Telegram Watch Ad click per session).
            showInitial(completed + 1);
            setIdle("Ready for ad " + (completed + 1) + " of " + REQUIRED + " — tap to continue.");
          }} else {{
            showUnavailable("The ad could not be loaded. Please try again.");
          }}
        }});
      }} else {{
        // SDK returned no promise: keep polling for the postback.
        settled = true;
        adRunning = false;
        adFinishedAt = Date.now();
        setBusy("Ad started — waiting for verification…");
        pollSoon();
      }}
    }} catch (e) {{
      settled = true;
      adRunning = false;
      adFinishedAt = Date.now();
      if (auto) {{
        showInitial(completed + 1);
        setIdle("Ready for ad " + (completed + 1) + " of " + REQUIRED + " — tap to continue.");
      }} else {{
        showUnavailable("The ad could not be loaded. Please try again.");
      }}
    }}
  }}

  // ---- Status polling (identity-verified). The backend decides the ----
  // ---- state — this NEVER unlocks anything by itself.             ----
  function onStatus(j) {{
    if (!j || finished) return;
    if (j.status === "rewarded") {{
      serverSynced = true;
      showSuccess();
      return;
    }}
    if (j.status === "expired" || j.status === "rejected") {{
      serverSynced = true;
      showExpired("This ad session has expired. Return to Telegram and start again.");
      return;
    }}
    // Transient answers (rate_limited / error / unauthorized / invalid /
    // forbidden) are NEVER a verification failure AND never mark the local
    // mirror synced: they carry NO session state. Keep waiting — the next
    // poll (and the initial-sync retry loop) re-checks.
    if (j.status !== "pending" && j.status !== "in_progress") {{
      return;
    }}
    serverSynced = true;
    var srvCompleted = (typeof j.completed_ads === "number") ? j.completed_ads : completed;
    // V5.2: the server's authoritative NEXT ad (completed+1, clamped) — the
    // local mirror may only ever RUN this ad or a later one, never earlier.
    var srvNext = (typeof j.next_ad_index === "number" && j.next_ad_index >= 1)
      ? j.next_ad_index : (srvCompleted + 1);
    if (srvCompleted > completed) {{
      // The server verified a NEW reward for this session.
      completed = srvCompleted;
      lastProgressAt = Date.now();
      adFinishedAt = 0;
      if (srvNext > adFloor) adFloor = srvNext;
      renderSteps();
      var wasBooted = bootRendered;
      if (completed >= REQUIRED) {{
        showSuccess();
      }} else if (!wasBooted) {{
        // First REAL answer after page load = mid-session reload resume:
        // render the resume screen with the SERVER's next ad — the user
        // taps to continue (never an unattended auto-start on boot).
        renderBoot();
      }} else if (adRunning) {{
        // V5.2: progress arrived while an older ad is STILL running (the
        // log-18 shape: a stale re-invoked ad after reload). Mark the
        // advance — it fires as soon as the running ad settles; the stale
        // ad's ymid postback is already deduped by the server ledger.
        pendingAdvance = true;
        setBusy("Reward verified — preparing the next ad…");
      }} else {{
        // Reward verified — preparing the next ad, then AUTO-ADVANCE inside
        // the SAME session (no extra Telegram button clicks). Warm the next
        // ad in the background first (Monetag's documented preload pattern).
        // V5.2: exactly ONE pending advance at a time — a newer progress
        // answer REPLACES the scheduled advance (two back-to-back rewards
        // could otherwise both fire and re-invoke the same ad twice).
        preloadAd(srvNext);
        reportEvent("next_ad", srvNext);
        setBusy("Reward verified — preparing the next ad…");
        if (advanceTimer) {{ clearTimeout(advanceTimer); }}
        advanceTimer = setTimeout(function () {{
          advanceTimer = null;
          if (!finished) startAd(true);
        }}, 1300);
      }}
      return;
    }}
    if (srvNext > adFloor) adFloor = srvNext;  // keep the floor at server truth
    if (!bootRendered) {{
      // First REAL answer with unchanged progress (fresh session / reload
      // at the same ad): render the initial screen now.
      renderBoot();
      return;
    }}
    // Server still pending: WAITING state (never a declared failure).
    // While the ad UI finished but its S2S postback has not landed yet, show
    // the verifying state with the live server progress; only after
    // VERIFY_GRACE re-enable the manual per-ad button (retry path).
    if (!adRunning && $("watchBtn").style.display === "none"
        && $("retryBtn").style.display === "none"
        && $("headline").textContent !== "Session Expired") {{
      var since = (adFinishedAt || lastProgressAt || pollStart);
      var waited = Math.round((Date.now() - since) / 1000);
      if (adFinishedAt && waited * 1000 < VERIFY_GRACE) {{
        setBusy("Verifying reward… " + completed + "/" + REQUIRED
                + (waited > 15 ? " (waiting for confirmation… " + waited + "s)" : ""));
      }} else {{
        showInitial(completed + 1);
        if (adFinishedAt) {{
          setIdle("No confirmation yet — you can retry ad " + (completed + 1)
                  + " of " + REQUIRED + ".");
        }}
      }}
    }}
  }}
  function pollStatus(cb) {{
    if (!tg || !tg.initData) {{
      // V25 FINAL §27 (bot-35.log session 137): NO Telegram identity →
      // the poll can NEVER run. The OLD behavior left the page stuck at
      // "Syncing with server…" FOREVER. Now the bounded sync timeout
      // below converts this into the actionable unavailable state.
      if (cb) cb(null);
      return;
    }}
    fetch("/api/watch-ad/status", {{
      method: "POST",
      headers: {{ "Content-Type": "application/json" }},
      body: JSON.stringify({{ token: TOKEN, initData: tg.initData }})
    }}).then(function (r) {{ return r.json(); }}).then(function (j) {{
      onStatus(j);
      if (cb) cb(j);
    }}).catch(function () {{ if (cb) cb(null); }});
  }}
  function pollSoon() {{
    // Burst-poll while a reward is being verified (postback may be delayed).
    for (var i = 1; i <= 8; i++) {{
      setTimeout(function () {{ if (!finished) pollStatus(null); }}, i * 1500);
    }}
  }}

  // Initial state: if the reward was already fully verified, show the
  // unlocked screen (the Continue button closes on the user's tap); if a
  // multi-ad session is mid-way, resume it. Warm the ad the user is about
  // to watch (Monetag's documented preload pattern).
  // V5.2 (log-18 session 22): the initial state-recovery poll can be
  // RATE-LIMITED (the per-token limiter is shared across page reloads) or
  // transiently fail — such answers carry NO state. The old code left the
  // local mirror at completed=0 and an ENABLED button: the user's tap then
  // re-invoked AD 1 (base ymid) on a server-advanced session. Now: the
  // button stays disabled ("Syncing with server…") until a REAL answer
  // renders the boot screen (renderBoot — the initial or RESUME screen with
  // the server's next ad), the sync RETRIES (<=6 x 900ms; the 3s interval
  // poll is the backup), and startAd additionally refuses to run before
  // serverSynced. A reloaded page therefore ALWAYS recovers the server's
  // next ad before any SDK call — a later-ad -> earlier-ad transition is
  // structurally impossible.
  function renderBoot() {{
    if (bootRendered || finished) {{ bootRendered = true; return; }}
    bootRendered = true;
    var nextAd = (adFloor > completed + 1) ? adFloor : (completed + 1);
    showInitial(nextAd);
    if (completed > 0 && completed < REQUIRED) {{
      setIdle("Resuming — ad " + nextAd + " of " + REQUIRED);
    }}
    preloadAd(completed + 1);
  }}
  $("watchBtn").disabled = true;
  setBusy("Syncing with server…");
  var syncTries = 0;
  // V25 FINAL §27 (bot-35.log): the sync is BOUNDED — a page that can
  // never sync (no Telegram initData — opened in a plain browser) or a
  // server that never answers shows the ACTIONABLE unavailable state
  // with a Retry button after 20s; NEVER a permanent spinner.
  var syncDeadline = setTimeout(function () {{
    if (finished || serverSynced || bootRendered) {{ return; }}
    showUnavailable("This ad session could not reach the server" +
      (!tg || !tg.initData
        ? " — open it inside Telegram (the Watch Ad button in the " +
          "bot's message)."
        : ". Check your connection and retry, or return to " +
          "Telegram and press Watch Ad again."));
  }}, 20000);
  function syncOnce() {{
    if (finished || serverSynced) {{ renderBoot(); return; }}
    pollStatus(function (j) {{
      if (finished || serverSynced) {{ renderBoot(); return; }}
      if (j && (j.status === "pending" || j.status === "in_progress"
                || j.status === "rewarded" || j.status === "expired"
                || j.status === "rejected")) {{
        clearTimeout(syncDeadline);
        return;  // a REAL answer — onStatus + renderBoot handled it
      }}
      syncTries += 1;
      if (syncTries <= 6) setTimeout(syncOnce, 900);
      // Exhausted: the 20s syncDeadline + the 3s interval poll render
      // the boot screen (or the actionable state) as soon as anything
      // REAL arrives — never a permanent spinner.
    }});
  }}
  syncOnce();
  pollTimer = setInterval(function () {{ pollStatus(null); }}, 3000);

  $("watchBtn").addEventListener("click", function () {{ startAd(false); }});
  // V5.1: THE Return / Continue button — the ONLY programmatic close path.
  // It is displayed exclusively by showSuccess(), which runs exclusively
  // from the server-confirmed rewarded state; the tap therefore always
  // happens AFTER status=="rewarded" AND completed_ads>=REQUIRED. There is
  // NO timer close anywhere (never close prematurely; 1/3 and 2/3 states
  // can never even see this button).
  $("doneBtn").addEventListener("click", function () {{
    if (tg) {{ try {{ tg.close(); }} catch (e) {{}} }}
  }});
}})();
</script>
</body>
</html>"""


async def _wad_handle_page(request) -> "object":
    """GET /watch-ad/<token> — serve the Mini App page for a VALID session.

    Invalid / expired / cross-... tokens get a safe error page (no internals).
    A valid pending session also logs the ad_watch_started analytics event.
    """
    if _aiohttp_web is None:  # pragma: no cover
        return _aiohttp_web.Response(status=503, text="Mini App disabled")
    token = request.match_info.get("token", "")
    try:
        session = await db.get_watch_ad_session_by_token(token)
    except Exception:  # noqa: BLE001
        session = None
    if not session:
        html = _wad_page_html("Invalid Session", """
        <div class="icon">⛔</div><h1>Invalid Ad Session</h1>
        <p>This ad session link is invalid or has expired.</p>
        <p class="small">Return to Telegram and press Watch Ad again.</p>""",
                              show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    now_iso = datetime.now(timezone.utc).isoformat()
    status = session["status"]
    if status in (WATCH_AD_STATUS_EXPIRED, WATCH_AD_STATUS_REJECTED):
        html = _wad_page_html("Session Expired", """
        <div class="icon">⌛</div><h1>Session Expired</h1>
        <p>This ad session has expired.</p>
        <p class="small">Return to Telegram and press Watch Ad again.</p>""",
                              show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    if status == WATCH_AD_STATUS_REWARDED:
        # V2 (v26) / V5.1: serve the FULL Mini App page so it can detect the
        # verified status via polling, automatically show "Your payload is
        # unlocked." + [✅ Continue to Telegram] and close ONLY on the user's
        # Continue tap (never on a timer — never prematurely).
        payload_row = await db.get_payload_by_id(int(session["payload_id"]))
        if payload_row and payload_row["status"] == "active" \
                and _safe_row_get(payload_row, "watch_ads_enabled"):
            cfg = await get_watch_ads_global_config()
            if cfg["sdk_ok"]:
                title = get_payload_display_name(
                    payload_row["payload"],
                    display_name=_safe_row_get(payload_row, "display_name"))
                parsed = _parse_monetag_sdk_tag(cfg["sdk_code"])
                html = _wad_mini_app_page(
                    token, title, cfg["sdk_code"], parsed.get("sdk_fn"),
                    cfg["unlock_window"],
                    int(_safe_row_get(session, "required_ads") or 1))
                return _aiohttp_web.Response(text=html, content_type="text/html")
        # Fall back to the static verified page (payload/SDK no longer
        # available) — still auto-free of internals.
        html = _wad_page_html("Reward Verified", """
        <div class="icon">🎉</div><h1>Reward Verified!</h1>
        <p>Your unlock is active. Return to Telegram.</p>""", show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    if session["expires_at"] and session["expires_at"] <= now_iso:
        # Pending but TTL elapsed — lazily expire + require a new session.
        await db.mark_watch_ad_session_status(int(session["id"]),
                                              WATCH_AD_STATUS_EXPIRED)
        html = _wad_page_html("Session Expired", """
        <div class="icon">⌛</div><h1>Session Expired</h1>
        <p>This ad session has expired.</p>
        <p class="small">Return to Telegram and press Watch Ad again.</p>""",
                              show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    # Valid pending session: analytics + serve the full Mini App page.
    payload_row = await db.get_payload_by_id(int(session["payload_id"]))
    if not payload_row or payload_row["status"] != "active" \
            or not _safe_row_get(payload_row, "watch_ads_enabled"):
        html = _wad_page_html("Unavailable", """
        <div class="icon">⚠️</div><h1>Watch Ads Unavailable</h1>
        <p>Watch Ads is temporarily unavailable. Please try again later.</p>""",
                              show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    await db.log_access_event("ad_watch_started",
                              payload_id=int(session["payload_id"]),
                              user_id=int(session["user_id"]))
    # WATCH_AD V5 (§34): structured page-open event — the Mini App is about
    # to start (or resume mid-way at) ad completed_ads+1. ad_index here is
    # the ad the frontend will run, derived from SERVER progress (the
    # per-ad ymid the Mini App computes for it: token / token_N).
    _req_n = max(1, int(_safe_row_get(session, "required_ads") or 1))
    _com_n = max(0, int(_safe_row_get(session, "completed_ads") or 0))
    _next_ad = _com_n + 1
    logger.info(
        "WATCH_AD_AD_START session=%s token=%s… user_id=%s payload_id=%s "
        "ad_index=%s ymid=%s required_ads=%s completed_ads=%s mode=%s "
        "source=page_open",
        int(session["id"]), token[:6], session["user_id"],
        session["payload_id"], _next_ad,
        token[:6] + ("_" + str(_next_ad) if _next_ad > 1 else ""),
        _req_n, _com_n,
        _safe_row_get(session, "ad_control_mode") or "-")
    logger.info("Watch Ad session opened (page served) for user %s / payload %s "
                "(token=%s…)", session["user_id"], session["payload_id"],
                token[:6])
    cfg = await get_watch_ads_global_config()
    if not cfg["sdk_ok"]:
        # No SDK stored: users get the generic unavailable message (never a
        # fake/demo ad and never configuration details).
        html = _wad_page_html("Unavailable", """
        <div class="icon">⚠️</div><h1>Watch Ads Unavailable</h1>
        <p>Watch Ads is temporarily unavailable. Please try again later.</p>""",
                              show_back=True)
        return _aiohttp_web.Response(text=html, content_type="text/html")
    title = get_payload_display_name(
        payload_row["payload"],
        display_name=_safe_row_get(payload_row, "display_name"))
    parsed = _parse_monetag_sdk_tag(cfg["sdk_code"])
    html = _wad_mini_app_page(token, title, cfg["sdk_code"],
                              parsed.get("sdk_fn"), cfg["unlock_window"],
                              int(_safe_row_get(session, "required_ads") or 1))
    return _aiohttp_web.Response(text=html, content_type="text/html")



async def _wad_validate_init_data_multi(init_data: str
                                        ) -> Optional[Dict[str, Any]]:
    """V26 (Network Bot Watch Ads) — multi-token initData validation.

    PRODUCTION EVIDENCE (the uploaded PDF page 2 + bot-36/bot-37.log): a
    Watch Ad Mini App opened from a NETWORK bot's [🎬 Watch Ad] button
    signs its initData with THAT bot's token. The status/ad-event
    endpoints validated against the MAIN bot token only → 401 on every
    poll → the Mini App's bounded sync (6 × 900 ms + the 20 s deadline)
    expired → the user saw EXACTLY "Ad Unavailable — This ad session
    could not reach the server. Check your connection and retry, or
    return to Telegram and press Watch Ad again." although the session,
    the server and the reward pipeline were perfectly healthy.

    Resolution — the SAME multi-token contract the public Website has
    used since WEBSITE PHASE 3 §11 (app/web/site/auth.py):
      1. the MAIN bot token FIRST (existing behavior byte-identical —
         main-bot launches never change);
      2. then every ACTIVE network bot token, decrypted through the
         EXISTING credential registry provider
         (``_website_network_bot_tokens`` — tokens never leave this
         boundary, never logged), validated with the SAME canonical
         single-token HMAC validator (``_validate_webapp_init_data``
         — NO second HMAC implementation, NO bypass).

    Security contract (unchanged in every dimension):
      * the HMAC-SHA256 signature is still enforced for EVERY token;
      * auth_date freshness is still enforced (same max age);
      * the cross-user check runs AFTER this in every caller — a network
        bot's user still cannot poll another user's session token;
      * the Monetag S2S postback remains the ONLY reward authority (this
        endpoint family never grants/advances/unlocks anything).

    Returns {"user_id": int, "user": {...}, "via": "main"|"network",
    "bot_id": int|None, "auth_date": int|None} or None on ANY failure
    (fail closed — never raises).
    """
    if not init_data:
        return None
    # 1. Main bot first — the canonical single-token validator (the exact
    #    function the endpoints used before V26; byte-identical semantics).
    try:
        v = validate_telegram_init_data(init_data)
    except Exception:  # noqa: BLE001 — fail closed
        v = None
    if v:
        uid = int(v.get("user_id") or 0)
        if uid:
            user_obj: Dict[str, Any] = {}
            try:
                _raw = v.get("raw") or {}
                user_obj = json.loads(_raw.get("user") or "{}") \
                    if hasattr(_raw, "get") else {}
            except Exception:  # noqa: BLE001
                user_obj = {}
            return {"user_id": uid, "user": user_obj, "via": "main",
                    "bot_id": None, "auth_date": None}
    # 2. ACTIVE network bots (Mini Apps launched from a network bot).
    provider = _website_network_bot_tokens
    try:
        candidates = await provider() if callable(provider) else []
    except Exception:  # noqa: BLE001 — degrade to main-token-only
        candidates = []
        logger.debug("watch-ad multi-token provider unavailable — "
                     "main-bot validation only", exc_info=True)
    for nb in candidates or []:
        tok = (nb or {}).get("token") or ""
        if not tok:
            continue
        try:
            v2 = _validate_webapp_init_data(init_data, tok,
                                            WATCH_AD_INITDATA_MAX_AGE)
        except Exception:  # noqa: BLE001 — fail closed
            v2 = None
        if v2:
            uid2 = int((v2.get("user") or {}).get("id") or 0)
            if uid2:
                bot_id = int((nb or {}).get("bot_id") or 0)
                logger.info(
                    "WATCH_AD_AUTH_VIA_NETWORK bot_id=%s user_id=%s "
                    "(Watch Ads Mini App launched from a NETWORK bot — "
                    "multi-token initData validation)",
                    bot_id or "-", uid2)
                return {"user_id": uid2, "user": v2.get("user") or {},
                        "via": "network", "bot_id": bot_id or None,
                        "auth_date": v2.get("auth_date")}
    return None


def _wad_auth_check_log(endpoint: str, token: str, init_data: str,
                        verified: Optional[Dict[str, Any]],
                        session: Any = None) -> None:
    """V26 WATCH_AD_AUTH_CHECK — the safe structured authentication
    telemetry line for the Watch Ads status/ad-event endpoints.

    ALLOWED FIELDS ONLY (the standing safe-field contract):
      session token PREFIX (6 chars), init_data_present, init_data
      length, hash_present, auth_date age, validated, validator source
      (main/network/none), network bot match, the Telegram user_id, and
      the session owner match.
    NEVER LOGGED: bot tokens, raw initData (its full contents), hashes,
    session tokens beyond the prefix, or any secret material.
    """
    try:
        id_present = 1 if init_data else 0
        id_len = len(init_data or "")
        hash_present = 1 if (init_data and "hash=" in init_data) else 0
        via = str((verified or {}).get("via") or "none")
        validated = 1 if verified else 0
        uid = int((verified or {}).get("user_id") or 0) or None
        auth_age = -1
        _ad = (verified or {}).get("auth_date")
        if isinstance(_ad, (int, float)) and _ad > 0:
            auth_age = max(0, int(time.time() - int(_ad)))
        bot_id = (verified or {}).get("bot_id")
        owner = None
        launch_bot = None
        owner_match = None
        if session is not None:
            try:
                owner = int(session["user_id"] or 0) or None
            except Exception:  # noqa: BLE001
                owner = None
            try:
                launch_bot = int(session["launch_network_bot_id"] or 0)                     if "launch_network_bot_id" in session.keys() else None
            except Exception:  # noqa: BLE001
                launch_bot = None
            if owner is not None and uid is not None:
                owner_match = 1 if uid == owner else 0
        net_match = None
        if bot_id is not None and launch_bot is not None:
            net_match = 1 if int(bot_id) == int(launch_bot) else 0
        logger.info(
            "WATCH_AD_AUTH_CHECK endpoint=%s token_prefix=%s "
            "init_data_present=%s init_data_len=%s hash_present=%s "
            "auth_age_s=%s validated=%s validator=%s network_bot_match=%s "
            "user_id=%s owner_match=%s",
            endpoint, (token[:6] if token else "-"), id_present, id_len,
            hash_present, auth_age, validated, via,
            ("na" if net_match is None else int(net_match)),
            ("-" if uid is None else uid),
            ("na" if owner_match is None else int(owner_match)))
    except Exception:  # noqa: BLE001 — telemetry must never break auth
        logger.debug("WATCH_AD_AUTH_CHECK log failure", exc_info=True)


async def _wad_handle_status(request) -> "object":
    """POST /api/watch-ad/status — identity-verified session status poll.

    The Telegram user identity is validated from initData (HMAC with
    BOT_TOKEN) and MUST match the session owner — cross-user session usage is
    rejected. Returns ONLY the minimum state (status + unlock expiry).
    """
    if _aiohttp_web is None:  # pragma: no cover
        return _aiohttp_web.json_response({"status": "error"}, status=503)
    # Light per-token rate limit (>= 1s between polls).
    now_ts = time.time()
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"status": "error"}, status=400)
    token = str((body or {}).get("token") or "")
    init_data = str((body or {}).get("initData") or "")
    last = _wad_status_ratelimit.get(token, 0.0)
    if now_ts - last < 1.0:
        return _aiohttp_web.json_response({"status": "rate_limited"})
    _wad_status_ratelimit[token] = now_ts
    if len(_wad_status_ratelimit) > 5000:  # prune occasionally (in place)
        cutoff = now_ts - 120
        for stale_key in [k for k, v in _wad_status_ratelimit.items()
                          if v <= cutoff]:
            _wad_status_ratelimit.pop(stale_key, None)
    # V26 (Network Bot Watch Ads): multi-token validation — the MAIN bot
    # token first (byte-identical main-bot behavior), then every ACTIVE
    # network bot token (a Mini App launched from a network bot signs its
    # initData with THAT bot's token — the PDF page 2 "Ad Unavailable —
    # this ad session could not reach the server" root cause). The HMAC,
    # the freshness window and the cross-user check below are ALL still
    # enforced — this only widens WHICH bot's signature is accepted.
    verified = await _wad_validate_init_data_multi(init_data)
    if not verified:
        return _aiohttp_web.json_response({"status": "unauthorized"}, status=401)
    session = await db.get_watch_ad_session_by_token(token)
    if not session:
        logger.info("WATCH_AD_SESSION_INVALID token=%s… reason=status_poll_unknown_token",
                    token[:6] if token else "-")
        _wad_auth_check_log("status", token, init_data, verified, None)
        return _aiohttp_web.json_response({"status": "invalid"}, status=404)
    # V26: the safe structured auth-check telemetry line.
    _wad_auth_check_log("status", token, init_data, verified, session)
    # Cross-user protection: User B polling User A's token is rejected.
    if int(verified["user_id"]) != int(session["user_id"]):
        logger.warning(
            "WATCH_AD_CROSS_USER token=%s… owner=%s requester=%s "
            "reason=status_poll_telegram_id_mismatch — rejected 403",
            token[:6], session["user_id"], verified["user_id"])
        return _aiohttp_web.json_response({"status": "forbidden"}, status=403)
    now_iso = datetime.now(timezone.utc).isoformat()
    status = session["status"]
    if status == WATCH_AD_STATUS_PENDING and session["expires_at"] \
            and session["expires_at"] <= now_iso:
        await db.mark_watch_ad_session_status(int(session["id"]),
                                              WATCH_AD_STATUS_EXPIRED)
        status = WATCH_AD_STATUS_EXPIRED
        logger.info("WATCH_AD_STATUS session=%s token=%s… user_id=%s "
                    "payload_id=%s status=%s reason=session_ttl_elapsed",
                    int(session["id"]), token[:6], session["user_id"],
                    session["payload_id"], status)
    # V2 (v26): expose the server-side multi-ad progress so the Mini App can
    # render "Ad X of Y" and request the correct next ad ymid. The frontend
    # NEVER derives authorization from these values — status stays 'pending'
    # until ALL required rewards are server-verified.
    required_ads = max(1, int(_safe_row_get(session, "required_ads") or 1))
    completed_ads = max(0, int(_safe_row_get(session, "completed_ads") or 0))
    ad_control_mode = _safe_row_get(session, "ad_control_mode") \
        or WATCH_AD_AD_CONTROL_DEFAULT
    # V5.2 (log-18 frontend regression fix): the server's AUTHORITATIVE next
    # ad index. The Mini App uses this to recover the correct ad after a
    # page reload/re-entry and as its monotonic floor — the frontend may run
    # THIS ad or a later one, NEVER an earlier one (an earlier ymid postback
    # is already deduped by the per-ad ledger anyway).
    if status == WATCH_AD_STATUS_REWARDED:
        next_ad_index = required_ads
    else:
        next_ad_index = max(1, min(completed_ads + 1, required_ads))
    if status == WATCH_AD_STATUS_PENDING and completed_ads >= required_ads:
        # Defensive sync: progress full but status not yet flipped (a reward
        # race) — report rewarded so the Mini App auto-closes correctly.
        status = WATCH_AD_STATUS_REWARDED
        logger.info("WATCH_AD_STATUS session=%s token=%s… user_id=%s "
                    "payload_id=%s status=%s reason=defensive_progress_sync",
                    int(session["id"]), token[:6], session["user_id"],
                    session["payload_id"], status)
    logger.debug("WATCH_AD_STATUS session=%s token=%s… status=%s "
                 "completed_ads=%s required_ads=%s mode=%s",
                 int(session["id"]), token[:6], status, completed_ads,
                 required_ads, ad_control_mode)
    return _aiohttp_web.json_response({
        "status": status,
        "unlock_expires_at": session["unlock_expires_at"] or None,
        "required_ads": required_ads,
        "completed_ads": completed_ads,
        "next_ad_index": next_ad_index,
        "ad_control_mode": ad_control_mode,
    })



async def _wad_handle_ad_event(request) -> "object":
    """POST /api/watch-ad/ad-event — Mini App lifecycle signal (V5 §34).

    Body: {token, initData, type: ad_start|ad_finish|next_ad|reward_wait,
           ad_index: int}. Identity-verified (same as the status endpoint:
    initData HMAC + cross-user rejection). Best-effort and fire-and-forget:
    the answer is always generic {ok} — the frontend never blocks on it and
    this endpoint can NEVER grant/advance/unlock anything.
    """
    if _aiohttp_web is None:  # pragma: no cover
        return _aiohttp_web.json_response({"ok": False}, status=503)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False}, status=400)
    token = str((body or {}).get("token") or "")
    init_data = str((body or {}).get("initData") or "")
    evt_type = str((body or {}).get("type") or "").strip().lower()
    try:
        ad_index = int((body or {}).get("ad_index") or 0)
    except (TypeError, ValueError):
        ad_index = 0
    if evt_type not in _WATCH_AD_AD_EVENT_TYPES:
        return _aiohttp_web.json_response({"ok": False}, status=400)
    # Identity FIRST (bad tokens/foreign users always see their real status
    # code — the rate limiter below only throttles VALID observers).
    # V26 (Network Bot Watch Ads): multi-token validation (main bot first,
    # then ACTIVE network bots) — same HMAC, same freshness, same
    # cross-user rejection; never a bypass.
    verified = await _wad_validate_init_data_multi(init_data)
    if not verified:
        return _aiohttp_web.json_response({"ok": False}, status=401)
    session = await db.get_watch_ad_session_by_token(token)
    if not session:
        _wad_auth_check_log("ad_event", token, init_data, verified, None)
        return _aiohttp_web.json_response({"ok": False}, status=404)
    # V26: the safe structured auth-check telemetry line.
    _wad_auth_check_log("ad_event", token, init_data, verified, session)
    if int(verified["user_id"]) != int(session["user_id"]):
        logger.warning(
            "WATCH_AD_CROSS_USER token=%s… owner=%s requester=%s "
            "reason=ad_event_telegram_id_mismatch — rejected 403",
            token[:6], session["user_id"], verified["user_id"])
        return _aiohttp_web.json_response({"ok": False}, status=403)
    # Light per-(token, event-type) rate limit — lifecycle events are a few
    # per ad; bursts are silently dropped (display-only, never retried).
    now_ts = time.time()
    rl_key = token + ":evt:" + evt_type
    last = _wad_status_ratelimit.get(rl_key, 0.0)
    if now_ts - last < 0.5:
        return _aiohttp_web.json_response({"ok": True})
    _wad_status_ratelimit[rl_key] = now_ts
    if len(_wad_status_ratelimit) > 5000:  # prune in place
        cutoff = now_ts - 120
        for stale_key in [k for k, v in _wad_status_ratelimit.items()
                          if v <= cutoff and k.endswith((":evt:ad_start",
                                                         ":evt:ad_finish",
                                                         ":evt:next_ad",
                                                         ":evt:reward_wait"))]:
            _wad_status_ratelimit.pop(stale_key, None)
    sid = int(session["id"])
    required_ads = max(1, int(_safe_row_get(session, "required_ads") or 1))
    completed_ads = max(0, int(_safe_row_get(session, "completed_ads") or 0))
    ad_idx = ad_index if 1 <= ad_index <= 99 else 0
    ymid_prefix = token[:6] + ("_" + str(ad_idx) if ad_idx > 1 else "")
    # V5.2 (log-18 session 22 @ 03:38:53): the server's authoritative next ad.
    # A frontend ad_index BELOW it is a REGRESSION (the stale-frontend-state
    # bug: page reload -> rate-limited recovery poll -> local mirror at 0 ->
    # ad 1 re-invoked with the base ymid on a 2/3-completed session). Log it
    # LOUDLY and explicitly — the display-only event never changes reward
    # state either way (the per-ad ymid ledger already dedupes its postback).
    server_next_ad = completed_ads + 1
    if ad_idx and ad_idx < server_next_ad and evt_type in (
            "ad_start", "ad_finish", "next_ad"):
        logger.warning(
            "WATCH_AD_AD_INDEX_REGRESSION session=%s token=%s… user_id=%s "
            "payload_id=%s requested_ad_index=%s server_next_ad_index=%s "
            "server_completed_ads=%s required_ads=%s mode=%s source=frontend "
            "reason=frontend_ad_index_behind_server — rejected (display-only; "
            "reward state untouched; the per-ad ymid ledger dedupes its postback)",
            sid, token[:6], session["user_id"], session["payload_id"],
            ad_idx, server_next_ad, completed_ads, required_ads,
            _safe_row_get(session, "ad_control_mode") or "-")
    extra = ""
    if evt_type == "ad_finish":
        extra = " waiting_for=s2s_postback"
    elif evt_type == "ad_start":
        extra = " provider=monetag_sdk"
    logger.info(
        "%s session=%s token=%s… user_id=%s payload_id=%s ad_index=%s "
        "ymid=%s required_ads=%s completed_ads=%s server_next_ad=%s mode=%s "
        "source=frontend%s",
        _WATCH_AD_AD_EVENT_CODES[evt_type], sid, token[:6],
        session["user_id"], session["payload_id"],
        ad_idx or "-", ymid_prefix, required_ads, completed_ads,
        server_next_ad,
        _safe_row_get(session, "ad_control_mode") or "-", extra)
    return _aiohttp_web.json_response({"ok": True})



async def _auto_resume_watch_ad_delivery(bot, user_id: int, payload_id: int) -> None:
    """WATCH_AD V2 (v26): re-enter the Access Engine after a COMPLETED,
    server-verified Watch Ads reward and — when authorized — continue through
    the EXISTING delivery pipeline.

    This is the "auto-return from Mini App" server side:
      Mini App shows "Your payload is unlocked." + Continue (frontend)
        -> the user taps Continue and is back in Telegram
        -> THIS function has ALREADY re-run the Access Engine
        -> authorized -> existing delivery flow continues

    Authorization path (single source of truth — the Access Engine):
      * Force Join is re-checked (mandatory prerequisite, never bypassed).
      * Admin/premium exemptions apply exactly as everywhere else.
      * REFERRAL OR WATCH ADS: the just-verified ad unlock authorizes by
        itself; referral completion is NOT required.

    Delivery path (existing pipeline ONLY — no Watch-Ads-specific delivery,
    NO "Get File" button, no second delivery implementation):
      * When the user has a stored referral dashboard for this payload, it is
        edited to the SAME unlocked/ready screen the referral flow uses
        (_edit_dashboard_to_unlocked via the Dashboard Controller).
      * Otherwise (Watch Ads only): single-file payloads run the exact
        _deliver_files_core call finalize_delivery makes after enforce_access
        passes; collection payloads receive the same Collection Ready menu
        (single renderer: _collection_menu_payload).
    """
    if not bot or not user_id or not payload_id:
        return
    try:
        payload_row = await db.get_payload_by_id(int(payload_id))
        if not payload_row or payload_row["status"] != "active":
            # Reward cannot produce a usable delivery for a gone payload.
            logger.info("Watch Ads auto-resume skipped: payload %s "
                        "missing/inactive.", payload_id)
            return
        # V26.2 (bot-41 §16-§24): the recheck carries the payload's GATE
        # KEY so the Force-Join slice is the per-gate pinned batch (the
        # same progressive-batching verdict that admitted the user to the
        # watch-ad step in the first place).
        _gk = f"b|p|{int(payload_id)}"
        res = await access_engine(bot, int(user_id), payload_id=int(payload_id),
                                  gate_key=_gk)
        logger.info(
            "WATCH_AD_ACCESS_RECHECK user_id=%s payload_id=%s authorized=%s "
            "reason=%s gate_key=%s (Access Engine re-entry after verified "
            "reward — single authorization layer, Force Join still enforced)",
            user_id, payload_id, bool(res and res.authorized),
            res.reason if res else "none", _gk)
        if not res or not res.authorized:
            # Never bypass the Access Engine. If Force Join regressed, show
            # the existing FJ page so the user is never left stuck; any other
            # denial re-renders when the user re-opens the payload link.
            if res and res.reason == "force_join_required":
                await send_force_join_page(bot, int(user_id), int(user_id),
                                           payload_row["payload"],
                                           gate_channels=list(res.not_joined or []))
            else:
                logger.info(
                    "Watch Ads auto-resume not authorized (user=%s payload=%s "
                    "reason=%s) — the user will see the requirement screen on "
                    "the next payload open.", user_id, payload_id,
                    res.reason if res else "none")
            return
        code = payload_row["payload"]
        # 1) Stored referral dashboard -> the EXISTING unlock screen via the
        #    Dashboard Controller edit (same flow as referral completion).
        #    V5 (§23): source="watch_ad" — the SAME single renderer with the
        #    honest Watch-Ads wording (never "you reached the referral goal"
        #    for an ad unlock). Buttons stay identical (Open File / Invite
        #    Friends; collection: Download / Browse / Share / Back).
        campaign = await db.get_referral_campaign_by_payload(int(payload_id))
        saved = await db.get_dashboard_msg(int(payload_id), int(user_id)) \
            if campaign else None
        if campaign and saved:
            logger.info(
                "WATCH_AD_DASHBOARD_RENDER user_id=%s payload_id=%s "
                "kind=referral_combined_unlocked source=watch_ad "
                "path=dashboard_update",
                user_id, payload_id)
            await _edit_dashboard_to_unlocked(bot, campaign, int(user_id), code,
                                              source="watch_ad")
            logger.info(
                "WATCH_AD_DELIVERY_RESUME user_id=%s payload_id=%s "
                "path=_edit_dashboard_to_unlocked (existing dashboard, "
                "source=watch_ad)",
                user_id, payload_id)
            return
        # 2) No dashboard (Watch Ads only): deliver through the existing
        #    pipeline — the exact same calls finalize_delivery makes after
        #    enforce_access passes.
        if is_collection_link(code):
            collection_code = parse_collection_link(code)
            if not collection_code:
                return
            built = await _collection_menu_payload(collection_code)
            if built:
                text, kb = built
                await safe_send_text(bot, int(user_id), text, reply_markup=kb)
            return
        file_row = await db.get_indexed_file_by_id(payload_row["index_id"])
        if not file_row:
            logger.info("Watch Ads auto-resume: file missing for payload %s.",
                        payload_id)
            return
        await _deliver_files_core(
            bot, chat_id=int(user_id), user_id=int(user_id),
            payload_row=payload_row,
            payload_code=code,
            files=[file_row],
            delivery_type="single",
            stat_key="payload_downloads",
        )
        logger.info(
            "WATCH_AD_DELIVERY_RESUME user_id=%s payload_id=%s "
            "path=_deliver_files_core (existing pipeline)",
            user_id, payload_id)
    except Exception as e:  # noqa: BLE001
        logger.warning(
            "WATCH_AD_AUTO_RESUME_FAILED user=%s payload=%s exc=%s.%s reason=%s",
            user_id, payload_id, type(e).__module__, type(e).__name__, e,
            exc_info=True)



async def _wad_reward_delivery_bot(result: Dict[str, Any]):
    """V26 (Network Bot Watch Ads): resolve the bot the reward notification
    + auto-resume should run through.

    The session records its launch context (``launch_network_bot_id`` —
    the network bot whose [🎬 Watch Ad] button produced the Mini App URL;
    NULL/0 = the main bot). When the launch happened from a NETWORK bot,
    the user clicked THAT bot's payload link — the main bot may have no
    chat with them at all (its DM would fail Forbidden and the user would
    never see the reward result). Resolution:
      1. the launch network bot's LIVE worker client, when its worker is
         running (``_net_workers.get_bot_client`` — the SAME client that
         serves the user's other messages from that bot);
      2. the MAIN bot (``_mini_app_bot``) otherwise — legacy sessions,
         main-bot launches, a stopped/removed network bot, or any lookup
         failure. The pre-V26 behavior is preserved exactly for them.
    Delivery authorization is NEVER decided here — the Access Engine
    re-entry in _auto_resume_watch_ad_delivery remains the single
    authorization layer for the unlock (Force Join, admin/premium
    exemptions, unlock window — all unchanged)."""
    launch_nid = result.get("launch_network_bot_id")
    try:
        launch_nid = int(launch_nid) if launch_nid else 0
    except (TypeError, ValueError):
        launch_nid = 0
    if launch_nid > 0:
        try:
            manager = _net_workers
            client = manager.get_bot_client(launch_nid) if manager else None
            if client is not None:
                logger.info(
                    "WATCH_AD_REWARD_ROUTE network_bot_id=%s user_id=%s "
                    "(reward notification/auto-resume through the NETWORK "
                    "bot the user is talking to)",
                    launch_nid, result.get("user_id"))
                return client
            logger.warning(
                "WATCH_AD_REWARD_ROUTE network_bot_id=%s user_id=%s "
                "reason=worker_not_running — falling back to the MAIN bot "
                "(the user re-opens the payload link to re-enter delivery)",
                launch_nid, result.get("user_id"))
        except Exception:  # noqa: BLE001 — any lookup failure degrades
            logger.debug("watch-ad reward route lookup failed",
                         exc_info=True)
    return _mini_app_bot


async def _notify_watch_ad_reward(token: str, result: Dict[str, Any]) -> None:
    """After the FINAL verified reward (result complete=True), tell the user
    the reward was verified (NO "Get File" button — that flow was removed in
    v26) and auto-resume the existing access/delivery flow.

    The Mini App closes itself (Telegram.WebApp.close) once its polling sees
    the verified status; the bot side re-enters the Access Engine here and
    continues the existing delivery pipeline. The unlock itself remains
    consumable ONLY through the Access Engine (never delivered directly from
    the Monetag callback).

    V26 (Network Bot Watch Ads): when the session was launched from a
    NETWORK bot, the notification + auto-resume run through THAT bot's
    client (the bot the user is actually talking to); main-bot sessions
    keep the exact pre-V26 main-bot routing."""
    if result.get("result") != "rewarded" or not result.get("complete"):
        return
    bot = await _wad_reward_delivery_bot(result)
    user_id = result.get("user_id")
    payload_id = result.get("payload_id")
    if not bot or not user_id or not payload_id:
        return
    try:
        payload_row = await db.get_payload_by_id(int(payload_id))
        if not payload_row:
            return
        title = get_payload_display_name(
            payload_row["payload"],
            display_name=_safe_row_get(payload_row, "display_name"))
        # Short, button-free confirmation. The Mini App is simultaneously
        # showing "Your payload is unlocked." + its Continue button; the
        # dashboard/access side continues by itself through the Access Engine.
        await safe_send_text(bot, int(user_id),
            "\U0001F3AC Ad reward verified!\n\n"
            f"Unlocking {title} — tap Continue in the ad window when you're ready.")
        logger.info("Watch Ad reward notification sent to user %s (payload=%s).",
                    user_id, payload_id)
    except Exception:  # noqa: BLE001
        logger.warning("Watch Ad reward notification failed (user=%s payload=%s).",
                       user_id, payload_id, exc_info=True)
    # Re-enter the Access Engine + existing delivery pipeline (always runs,
    # even if the short notification above failed).
    await _auto_resume_watch_ad_delivery(bot, int(user_id), int(payload_id))



async def _wad_handle_postback(request) -> "object":
    """GET /api/watch-ad/postback — THE Monetag server-side reward endpoint.

    This is where Monetag reward information ENTERS the backend. Configure in
    the Monetag SSP zone settings (Postback URL), e.g.:

      https://<your-domain>/api/watch-ad/postback
        ?ymid={ymid}&event={event_type}&value={reward_event_type}
        &price={estimated_price}&telegram_id={telegram_id}
        &zone={zone_id}&sub={sub_zone_id}&source={request_var}

    Validation + mapping (inside process_watch_ad_reward):
      ymid             -> watch_ad_sessions.token (session lookup). V2 (v26):
                          the Mini App passes ymid=token for ad 1 and
                          ymid=token_N for ads N>=2 inside ONE session; the
                          suffix is stripped here for the session lookup and
                          the FULL ymid keys the per-ad reward ledger
                          (watch_ad_reward_events) so retries/replays of the
                          same ad can never double-count.
      telegram_id      -> must match the session owner (cross-user reject)
      reward_event_type-> only 'valued' grants the unlock (non_valued is
                          unpaid/fraud traffic and is ignored)
      The session maps 1:1 to (Telegram user ID, payload ID).
    Replay / duplicates: idempotent (counted, never double-unlocked).
    Monetag retries until 200 OK — always answer 200 for processed/ignored.
    """
    if _aiohttp_web is None:  # pragma: no cover
        return _aiohttp_web.Response(status=503, text="Mini App disabled")
    q = request.query
    ymid_raw = (q.get("ymid") or q.get("token") or "").strip()
    event_type = (q.get("event") or q.get("event_type") or "").strip()
    reward_event_type = (q.get("value") or q.get("reward_event_type") or "").strip()
    price_raw = (q.get("price") or q.get("estimated_price")
                 or q.get("amount") or "").strip()
    tg_id_raw = (q.get("telegram_id") or q.get("tg_id") or "").strip()
    zone_id = (q.get("zone") or q.get("zone_id") or "").strip()
    sub_zone_id = (q.get("sub") or q.get("sub_zone_id") or "").strip()
    request_var = (q.get("source") or q.get("request_var") or "").strip()
    estimated_price: Optional[float] = None
    if price_raw:
        try:
            estimated_price = float(price_raw)
        except ValueError:
            estimated_price = None
    telegram_id: Optional[int] = None
    if tg_id_raw.isdigit():
        telegram_id = int(tg_id_raw)
    # V2 (v26): split the per-ad suffix (token or token_N) — the token is
    # always 32 lowercase hex chars, so a single '_' separator is unambiguous.
    token = ymid_raw
    ad_index: Optional[int] = None
    m = re.fullmatch(r"([0-9a-f]{32})(?:_(\d{1,3}))?", ymid_raw)
    if not m:
        # Unknown/foreign ymid — 200 so Monetag stops retrying.
        logger.info("WATCH_AD_SESSION_INVALID ymid=%s reason=postback_foreign_ymid "
                    "(not a session token pattern)", (ymid_raw or "-")[:12])
        await db.log_watch_ad_postback(ymid_prefix=(ymid_raw or "-")[:10],
                                       result="foreign", http_status=200,
                                       event_type=event_type,
                                       reward_event_type=reward_event_type)
        return _aiohttp_web.Response(text="IGNORED", status=200)
    token = m.group(1)
    if m.group(2):
        ad_index = int(m.group(2))
    logger.info("WATCH_AD_POSTBACK_RECEIVED token=%s… ymid=%s event=%s "
                "value=%s zone=%s sub=%s price=%s tg_id=%s ad_index=%s",
                token[:6], (ymid_raw or "-")[:12], event_type,
                reward_event_type, zone_id or "-", sub_zone_id or "-",
                estimated_price, tg_id_raw or "-", ad_index)
    result = await db.process_watch_ad_reward(
        token, event_type=event_type, reward_event_type=reward_event_type,
        estimated_price=estimated_price, telegram_id=telegram_id,
        zone_id=zone_id or None, sub_zone_id=sub_zone_id or None,
        request_var=request_var or None, ymid_raw=ymid_raw, ad_index=ad_index)
    # Fire-and-forget auto-resume ONLY on the FINAL verified reward (the
    # required ad count has been reached — partial multi-ad rewards simply
    # keep the session pending for the next ad).
    if result.get("result") == "rewarded" and result.get("complete"):
        asyncio.create_task(_notify_watch_ad_reward(token, result))
        await db.log_watch_ad_postback(
            ymid_prefix=ymid_raw[:10], result="rewarded", http_status=200,
            user_id=result.get("user_id"), payload_id=result.get("payload_id"),
            ad_index=ad_index, event_type=event_type,
            reward_event_type=reward_event_type)
        return _aiohttp_web.Response(text="OK", status=200)
    if result.get("result") == "error":
        # WATCH_AD V3 (production fix, spec §8): an INTERNAL error (database
        # OperationalError, transaction failure, unexpected exception) is NOT
        # an invalid reward. The live production failure answered HTTP 200
        # "OK" here — Monetag stopped retrying and the genuine reward was
        # silently discarded while the user stayed locked. Answer HTTP 500 so
        # the provider retries (Monetag retries postbacks until 200 OK); the
        # next attempt lands on a repaired schema and the reward commits.
        logger.error(
            "WATCH_AD_REWARD_DB_ERROR token=%s… result=error — answered "
            "HTTP 500 so the provider can retry (the reward was NOT "
            "processed; never acknowledge an internal failure as done)",
            token[:6])
        await db.log_watch_ad_postback(
            ymid_prefix=ymid_raw[:10], result="error", http_status=500,
            user_id=result.get("user_id"), payload_id=result.get("payload_id"),
            ad_index=ad_index, event_type=event_type,
            reward_event_type=reward_event_type)
        return _aiohttp_web.Response(text="DB_ERROR", status=500)
    if result.get("result") == "unknown":
        # Deterministic invalid postback (foreign/unknown token): rejecting
        # with 200 is correct — Monetag stops retrying an event that can
        # never become valid.
        logger.info("WATCH_AD_POSTBACK_REJECTED token=%s… result=unknown — "
                    "answered OK so Monetag stops retrying (invalid session "
                    "reference)", token[:6])
        await db.log_watch_ad_postback(
            ymid_prefix=ymid_raw[:10], result="unknown", http_status=200,
            ad_index=ad_index, event_type=event_type,
            reward_event_type=reward_event_type)
        return _aiohttp_web.Response(text="OK", status=200)
    # Deterministic outcomes — rewarded (200 above), duplicate (idempotent),
    # non_valued / expired / rejected / inactive (session-level rejections
    # that can never become valid on retry): answer 200 so Monetag does not
    # hammer the endpoint. The structured cause was already logged inside
    # process_watch_ad_reward.
    if result.get("result") in ("non_valued", "expired", "rejected", "inactive"):
        logger.info("WATCH_AD_POSTBACK_REJECTED token=%s… result=%s — "
                    "answered OK so Monetag stops retrying (deterministic "
                    "session-level rejection)", token[:6], result.get("result"))
    await db.log_watch_ad_postback(
        ymid_prefix=ymid_raw[:10],
        result=str(result.get("result") or "unknown"), http_status=200,
        user_id=result.get("user_id"), payload_id=result.get("payload_id"),
        ad_index=ad_index, event_type=event_type,
        reward_event_type=reward_event_type)
    return _aiohttp_web.Response(text="OK", status=200)



async def _wad_handle_health(request) -> "object":
    return _aiohttp_web.json_response({"ok": True, "service": "watch-ad-mini-app"})



async def _net_handle_webapp_auth(request) -> "object":
    """POST /api/network/auth — validate WebApp initData server-side.

    Body: {"init_data": "...", "payload_code": "..."} (all optional except
    init_data). NEVER trusts browser identity: the user comes ONLY from
    the HMAC-verified initData. Returns the authenticated telegram user,
    their points balance, and the access verdict for the requested payload
    (evaluated by the SHARED Access Engine — spec §49/§51)."""
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")
    payload_code = str((body or {}).get("payload_code") or "").strip()
    # V26 (Network Bot Watch Ads / network Mini App auth): multi-token
    # validation — the MAIN bot token first (existing behavior preserved),
    # then every ACTIVE network bot token (a Mini App launched from a
    # network bot signs its initData with THAT bot's token — main-token-
    # only validation produced exactly the "network Mini App can never
    # authenticate" failure class). Same canonical HMAC validator, same
    # freshness window, same fail-closed contract — no bypass.
    verified = await _wad_validate_init_data_multi(init_data)
    if verified is None:
        logger.info("NETWORK_WEBAPP_AUTH_REJECTED (invalid signature or "
                    "stale auth_date — no main-bot OR active-network-bot "
                    "token matched)")
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    tg_user = verified.get("user") or {}
    uid = int(tg_user.get("id") or 0)
    if not uid:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "no_user"}, status=401)
    resp: Dict[str, Any] = {
        "ok": True,
        "user": {"id": uid,
                 "username": tg_user.get("username"),
                 "first_name": tg_user.get("first_name")},
        "via": verified.get("via") or "main",
        "auth_age_seconds": int(
            time.time() - (verified.get("auth_date") or int(time.time()))),
    }
    try:
        resp["points"] = await db.points_balance(uid)
    except Exception:  # noqa: BLE001
        resp["points"] = None
    if payload_code:
        try:
            prow = await db.get_payload(payload_code.lower())
            if prow is None:
                resp["payload"] = {"found": False}
            else:
                res = await access_engine(None, uid,
                                          payload_id=int(prow["id"]))
                resp["payload"] = {
                    "found": True,
                    "code": payload_code,
                    "authorized": bool(res.authorized),
                    "reason": res.reason,
                    "points_eligible": bool(res.points_eligible),
                    "point_cost": int(res.point_cost or 0),
                }
        except Exception:  # noqa: BLE001
            resp["payload"] = {"found": False, "error": "engine_error"}
    logger.info("NETWORK_WEBAPP_AUTH_OK user_id=%s payload_code=%s via=%s",
                uid, (payload_code or "-")[:40], verified.get("via") or "main")
    return _aiohttp_web.json_response(resp)
