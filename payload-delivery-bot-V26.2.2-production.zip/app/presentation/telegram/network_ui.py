"""Network Platform UI/handler glue (bot adapter layer): Global Payload
Link routing entry, the atomic point-unlock callback, My Network,
the registration wizard, the Network Control Center, the Broadcast
Center and the network callback dispatchers. The pinned worker
lifecycle glue (_build_network_bot_application,
_network_callback_guard, _network_send_file_by_source,
init_network_services, network_startup/shutdown) remains in bot.py
as the bootstrap wiring (docs/BOT_COMPATIBILITY.md).

b10 (bot-10.log §4/§5 — Wave 1, B10-B1): the Global Link caller now
resolves the MAIN bot's username and renders the terminal
deliver_via_main redirect; My Network and the nbot:<id> management
callbacks treat REMOVED bots as gone (panel filter + truthful stale
callback answers + idempotent remove).
"""
from __future__ import annotations

import re

import logging
from datetime import datetime, timezone
from types import SimpleNamespace

from app.core.constants import NET_BCAST_CB
from app.core.constants import NET_BOT_CB
from app.core.constants import NET_CB_PREFIX
from app.core.constants import NET_CREATE_CB
from app.core.constants import NET_DEFAULT_MAX_BOTS
from app.core.constants import NET_DEFAULT_POINTS_PER_BOT
from app.core.constants import NET_DEFAULT_POINT_COST
from app.core.constants import NET_DG_CB
from app.core.constants import NET_PTS_CB
from app.core.constants import NET_REG_CB
from app.core.constants import NET_SETTING_BCAST_CONFIRM
from app.core.constants import NET_SETTING_BCAST_RATE
from app.core.constants import NET_SETTING_ENABLED
from app.core.constants import NET_SETTING_MAX_BOTS
from app.core.constants import NET_SETTING_MAX_REWARD
from app.core.constants import NET_SETTING_POINTS_ACCESS
from app.core.constants import NET_SETTING_POINTS_PER_BOT
from app.core.constants import NET_SETTING_POINT_COST
from app.core.payload.service import get_payload_display_name
from app.network.broadcast import classify_send_error as _net_classify_send_error
from app.network.credentials import mask_token as _mask_token
from app.network.registry import STATUS_REMOVED as _NET_STATUS_REMOVED
from app.network.registry import token_format_ok as _net_token_format_ok
# BOT-11 (B11-B — spec §8/§12/§16): the ONE centralized random selection +
# the targeted mint (routing.py is a standalone module — no circularity).
from app.network.routing import LinkSigningUnavailableError as _LinkSigningUnavailableError
from app.network.routing import mint_targeted_link as _net_mint_targeted_link
from app.network.routing import select_random_delivery_bot as _net_select_random_delivery_bot
from app.storage.dbutil import safe_row_get as _safe_row_get
from telegram import CopyTextButton
from telegram import InlineKeyboardButton
from telegram import InlineKeyboardMarkup
from telegram import Update
from telegram import User
from telegram.ext import ContextTypes
from typing import Any, Dict, List, Optional
import asyncio
import json
import time

try:
    from aiohttp import web as _aiohttp_web
    import aiohttp as _aiohttp_client
    AIOHTTP_AVAILABLE = True
except Exception:
    _aiohttp_web = None
    _aiohttp_client = None
    AIOHTTP_AVAILABLE = False

logger = logging.getLogger("payload-bot")


def _now_iso_str() -> str:
    """UTC ISO-8601 timestamp (the b11 §6 change-token row updates)."""
    return datetime.now(timezone.utc).isoformat()


_NET_LINK_RE = re.compile(r"^g([A-Za-z0-9]{12})-([0-9a-f]{6})(?:_rk(\d{1,3}))?$")

_NET_REG_STATE_KEY = "net_reg_state"


def _is_removed_bot(row) -> bool:
    """b10 §5: True when a network_bot row represents a REMOVED bot.

    Covers the NEW distinct terminal status (status=REMOVED) AND the
    LEGACY shape produced by the pre-b10 removal scheme
    (status=DISABLED + last_error_code=REMOVED). A removed bot never
    renders in My Network, never offers a management button, and any
    stale action on it answers truthfully. DISABLED without the
    REMOVED error code stays VISIBLE (admin/owner pause — the historical
    note in the panel keeps showing paused bots)."""
    try:
        status = str((row or {}).get("status") or "")
        if status == _NET_STATUS_REMOVED:
            return True
        return (status == "DISABLED"
                and str((row or {}).get("last_error_code") or "").upper()
                == "REMOVED")
    except Exception:  # noqa: BLE001 — pure predicate, never raises
        return False


def make_network_ui(db, BOT_USERNAME=None, _point_access_active=None, _point_cost=None, access_engine=None, finalize_delivery=None, is_admin=None, safe_answer_callback=None, safe_edit_text=None, safe_send_text=None, _net_registry=None, _net_points=None, _net_router=None, _net_links=None, _net_broadcast=None, _net_workers=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    # v36 state helpers — imported INSIDE the factory (state.py imports
    # this module in its import zone, so a module-level import would be
    # circular; the factory runs post-initialization).
    from app.presentation.telegram.state import (
        clear_conversation_input_states,
        stamp_conversation_state,
        set_net_wizard_origin,
        clear_net_wizard_origin,
        _conversation_state_expired,
        # b10 §1 (B10-B2): the durable per-user token-input intent —
        # survives unrelated callback navigation; only the token text
        # handler, an explicit Back/Cancel, a newer input flow or the
        # 10-minute TTL clears it. NEVER holds token material.
        set_pending_token_intent,
        get_pending_token_intent,
        update_pending_token_intent,
        consume_pending_token_intent,
        clear_pending_token_intent,
    )
    async def network_enabled() -> bool:
        try:
            return await db.get_setting_bool(NET_SETTING_ENABLED, True)
        except Exception:  # noqa: BLE001
            return False

    def _net_context_id(context) -> Optional[int]:
        """The network_bot_id when this handler call runs inside a NETWORK
        worker application (None = the main bot / tests)."""
        try:
            bd = getattr(context, "application", None)
            bd = getattr(bd, "bot_data", None) if bd is not None else None
            if not bd:
                return None
            nid = bd.get("network_bot_id")
            return int(nid) if nid is not None else None
        except Exception:  # noqa: BLE001
            return None

    async def _net_validate_token_via_telegram(token: str) -> Dict[str, Any]:
        """Direct getMe call with the candidate token.

        Returns {"ok": bool, "bot": {"id","username","first_name"}|None,
                 "reason": str}. Transport failures are TRANSIENT
        (reason=telegram_unreachable — never 'invalid_token')."""
        if AIOHTTP_AVAILABLE and _aiohttp_client is not None:
            try:
                url = f"https://api.telegram.org/bot{token}/getMe"
                timeout = _aiohttp_client.ClientTimeout(total=15)
                async with _aiohttp_client.ClientSession(timeout=timeout) as sess:
                    async with sess.get(url) as resp:
                        data = await resp.json(content_type=None)
                if data.get("ok"):
                    r = data.get("result") or {}
                    return {"ok": True, "bot": {
                        "id": int(r.get("id") or 0),
                        "username": str(r.get("username") or ""),
                        "first_name": str(r.get("first_name") or "")}, "reason": ""}
                desc = str(data.get("description") or "").lower()
                if "unauthorized" in desc:
                    return {"ok": False, "bot": None, "reason": "invalid_token"}
                return {"ok": False, "bot": None, "reason": "telegram_rejected"}
            except asyncio.TimeoutError:
                return {"ok": False, "bot": None, "reason": "telegram_unreachable"}
            except Exception as exc:  # noqa: BLE001 — transport-level failure
                logger.info("NETWORK_BOT_VALIDATE transport_error=%s (token "
                            "masked=%s)", type(exc).__name__,
                            _mask_token(token))
                return {"ok": False, "bot": None, "reason": "telegram_unreachable"}
        # No aiohttp (tests): use the main bot's HTTP transport? Not safe —
        # the main bot's ApiClient is bound to ITS token. Report unreachable
        # honestly; tests inject their own validate_token through the service.
        return {"ok": False, "bot": None, "reason": "telegram_unreachable"}

    async def _net_probe_storage_access(token: str) -> Dict[str, Any]:
        """Registration-time capability probe: can a bot with THIS token see
        the active storage channels? Uses get_chat per channel through a
        temporary per-token session (never the main bot context, never logged
        token). Result: {'mode': 'full'|'partial'|'none', 'channels': [...]}."""
        try:
            channels = await db.list_storage_channels(active_only=True)
        except Exception:  # noqa: BLE001
            channels = []
        if not channels:
            return {"mode": "none", "channels": []}
        ok_ids: List[int] = []
        if AIOHTTP_AVAILABLE and _aiohttp_client is not None:
            try:
                timeout = _aiohttp_client.ClientTimeout(total=15)
                async with _aiohttp_client.ClientSession(timeout=timeout) as sess:
                    for ch in channels:
                        cid = int(ch["channel_id"])
                        try:
                            url = (f"https://api.telegram.org/bot{token}"
                                   f"/getChat?chat_id={cid}")
                            async with sess.get(url) as resp:
                                data = await resp.json(content_type=None)
                            if data.get("ok"):
                                ok_ids.append(cid)
                        except Exception:  # noqa: BLE001
                            continue
            except Exception:  # noqa: BLE001
                pass
        if len(ok_ids) == len(channels):
            mode = "full"
        elif ok_ids:
            mode = "partial"
        else:
            mode = "none"
        return {"mode": mode, "channels": ok_ids}

    async def _network_media_guard(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE) -> None:
        """Media input inside NETWORK workers: admin media configuration and
        broadcast capture are main-bot flows; politely refuse here."""
        user = update.effective_user
        if user and await is_admin(user.id):
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u26A0\uFE0F Media configuration and broadcast "
                                 "capture are managed in the main bot.")

    async def _network_record_start(network_bot_id: int, user_id: int) -> None:
        """Membership upsert when a user starts a network worker (spec §15 —
        the reachability foundation)."""
        try:
            await db.upsert_membership(int(network_bot_id), int(user_id))
        except Exception as exc:  # noqa: BLE001 — never break /start
            logger.warning("NETWORK_MEMBERSHIP_UPSERT_FAILED bot=%s user=%s: %s",
                           network_bot_id, user_id, exc)

    async def _net_get_bot_client(network_bot_id: int):
        """Bot client for broadcasts/delivery (worker manager)."""
        if _net_workers is None:
            return None
        return _net_workers.get_bot_client(int(network_bot_id))

    def is_global_payload_link(arg: str) -> bool:
        return bool(arg) and arg.startswith("g") and len(arg) >= 14 \
            and _NET_LINK_RE.match(arg) is not None

    def _net_serving_bot_username(context) -> str:
        """The username of the bot SERVING this request (network worker or
        main) — deep links generated in this context point back to it."""
        nid = _net_context_id(context)
        if nid is None:
            return BOT_USERNAME or ""
        try:
            bd = context.application.bot_data
            return str(bd.get("bot_username") or BOT_USERNAME or "")
        except Exception:  # noqa: BLE001
            return BOT_USERNAME or ""

    def _net_main_bot_username(context) -> str:
        """b10 §4: the MAIN bot's username — the terminal Global-Link
        delivery context (the deliver_via_main deep link target).

        Honest resolution chain (first non-empty wins):
          (b) the LIVE Telegram identity, but ONLY when this handler runs
              in the MAIN bot context (``_net_context_id(context) is
              None`` — inside a network worker context.bot.username is
              the WORKER's, never the main bot's);
          (a) the injected BOT_USERNAME factory param (the container
              wires ns.BOT_USERNAME; post_init refreshes it from
              get_me() and the compat facades rebuild this service per
              call, so it is fresh in production);
          (c) the shared runtime namespace attribute (lazy import —
              state.py imports THIS module at load time, so a module-
              level import would be circular).
        Returns "" when nothing resolves — the router then keeps the
        honest "unavailable" path (a fabricated username would produce
        a DEAD button; never fabricated).
        """
        try:
            if _net_context_id(context) is None:
                live = getattr(getattr(context, "bot", None), "username", None)
                if live:
                    return str(live).lstrip("@")
        except Exception:  # noqa: BLE001
            pass
        if BOT_USERNAME:
            return str(BOT_USERNAME).lstrip("@")
        try:
            from app.presentation.telegram import runtime as _rt
            _u = getattr(_rt, "BOT_USERNAME", None)
            if _u:
                return str(_u).lstrip("@")
        except Exception:  # noqa: BLE001 — namespace not assembled yet
            pass
        return ""

    async def handle_global_payload_link(update: Update,
                                         context: ContextTypes.DEFAULT_TYPE,
                                         user: User, arg: str) -> None:
        """Global Payload Link entry (any network bot OR the main bot).

        Routing (spec §18/§19/§20): the CURRENT bot delivers whenever it is
        routable + payload-eligible (loop-free by construction); a strictly
        better reachable bot gets ONE controlled deep-link button; no
        eligible bot → friendly temporary-unavailable.

        v37 (bot-8 A6): every stage emits a structured diagnostic so a
        failing link can be root-caused from the log alone (never the
        token/signing secret)."""
        logger.info("GLOBAL_LINK_START_RECEIVED user_id=%s network_bot_id=%s "
                    "serving=@%s arg_len=%s", user.id,
                    _net_context_id(context) or 0,
                    _net_serving_bot_username(context), len(arg or ""))
        parsed = _net_links.parse(arg) if _net_links else None
        if parsed is None:
            logger.warning(
                "GLOBAL_LINK_PARSE_FAILED user_id=%s reason=%s (format or "
                "signature invalid — codes are case-sensitive)",
                user.id, "links_service_unavailable"
                if _net_links is None else "format_or_signature")
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C Invalid or expired link.")
            return
        logger.info("GLOBAL_LINK_PARSE_OK user_id=%s code=%s rk=%s",
                    user.id, parsed["code"][:8], parsed["fallback_count"])
        public_code = parsed["code"]
        fallback_count = int(parsed["fallback_count"])
        link_row = await db.get_global_payload_link(public_code)
        if not link_row:
            logger.warning("GLOBAL_LINK_DB_MISS user_id=%s code=%s",
                           user.id, public_code[:8])
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C This link is no longer available.")
            return
        if not int(link_row["active"] or 0):
            logger.warning("GLOBAL_LINK_INACTIVE user_id=%s code=%s",
                           user.id, public_code[:8])
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C This link is no longer available.")
            return
        logger.info("GLOBAL_LINK_DB_LOOKUP_OK user_id=%s code=%s "
                    "payload_id=%s", user.id, public_code[:8],
                    link_row["payload_id"])
        # BOT-11 (B11-B — spec §12/§16): the link's PERSISTED delivery
        # target. target > 0 → deterministic routing to that network bot
        # ('random'/'bot' modes); == 0 with target_mode 'main' → the
        # explicit MAIN target; anything else (legacy pre-v35 rows:
        # target 0 + mode '') → link_target None = the EXACT legacy
        # untargeted behavior, byte-identical (zero regression).
        try:
            _link_target_id = int(link_row.get("target_network_bot_id") or 0)
            _link_target_mode = str(link_row.get("target_mode") or "")
        except Exception:  # noqa: BLE001 — malformed row = legacy shape
            _link_target_id, _link_target_mode = 0, ""
        _link_target: Optional[int] = None
        if _link_target_id > 0:
            _link_target = _link_target_id
        elif _link_target_mode == "main":
            _link_target = 0
        if _link_target is not None:
            logger.info("GLOBAL_LINK_TARGET_INFO user_id=%s code=%s "
                        "target_network_bot_id=%s target_mode=%s",
                        user.id, public_code[:8], _link_target,
                        _link_target_mode or "legacy")
        await db.bump_global_link_click(public_code)
        payload_id = int(link_row["payload_id"])
        payload_row = await db.get_payload_by_id(payload_id)
        if not payload_row or payload_row["status"] != "active":
            logger.warning("GLOBAL_LINK_PAYLOAD_MISSING user_id=%s "
                           "payload_id=%s status=%s", user.id, payload_id,
                           # get_payload_by_id returns an aiosqlite.Row —
                           # Row has no .get(); key access (the None case
                           # logs None honestly).
                           (payload_row["status"] if payload_row else None))
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C This content is no longer available.")
            return
        # V25 FINAL §9 (spec §11 — expired links must remain invalid):
        # the g-link surface enforces the SAME payload lifecycle gates
        # as the payload-link surface BEFORE any routing/delivery — the
        # old path skipped expires_at/max_clicks entirely (KD2: an
        # intentionally EXPIRED payload still delivered through a
        # g-link).
        if payload_row["expires_at"]:
            try:
                _exp = datetime.fromisoformat(str(payload_row["expires_at"]))
                if datetime.now(timezone.utc) > _exp:
                    logger.warning(
                        "GLOBAL_LINK_PAYLOAD_EXPIRED user_id=%s "
                        "payload_id=%s (the payload's expires_at is past — "
                        "distinct from link-inactive and payload-missing)",
                        user.id, payload_id)
                    await safe_send_text(
                        context.bot, update.effective_chat.id,
                        "\u274C This content is no longer available.")
                    return
            except ValueError:
                pass  # malformed stamp — never blocks on a parse error
        _mc = payload_row["max_clicks"]
        if _mc and int(_mc) > 0 \
                and int(payload_row["current_clicks"] or 0) >= int(_mc):
            logger.warning(
                "GLOBAL_LINK_PAYLOAD_MAX_CLICKS user_id=%s payload_id=%s "
                "(the payload reached max_clicks — distinct state)",
                user.id, payload_id)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This content is no longer available.")
            return
        payload_code = str(payload_row["payload"])
        logger.info("GLOBAL_LINK_PAYLOAD_OK user_id=%s payload_id=%s",
                    user.id, payload_id)
        logger.info("GLOBAL_PAYLOAD_RESOLVE user_id=%s payload_id=%s code=%s "
                    "fallback_count=%s network_bot_id=%s serving=@%s",
                    user.id, payload_id, public_code[:8], fallback_count,
                    _net_context_id(context) or 0, _net_serving_bot_username(context))

        decision = await _net_router.resolve_request(
            int(user.id), public_code,
            current_network_bot_id=_net_context_id(context),
            current_bot_username=_net_serving_bot_username(context),
            fallback_count=fallback_count,
            main_bot_username=_net_main_bot_username(context),
            link_target_network_bot_id=_link_target,
            raw_arg=arg)
        action = str(decision.get("action"))
        # b10 §4 diagnostics: the selection funnel counts travel WITH the
        # decision so GLOBAL_LINK_ROUTE_DECISION alone explains a refusal
        # (routable=0 → fleet unhealthy; ready=0 → no verified Delivery
        # Group; reachable=0 → user started no bot).
        logger.info("GLOBAL_LINK_ROUTE_DECISION user_id=%s action=%s "
                    "reason=%s selected_network_bot_id=%s routable=%s "
                    "ready=%s reachable=%s",
                    user.id, action, decision.get("reason"),
                    (decision.get("bot") or {}).get("network_bot_id") or 0,
                    decision.get("routable"), decision.get("delivery_ready"),
                    decision.get("reachable"))

        if action == "deliver_current":
            # The current context serves the payload — shared Access Engine +
            # shared Delivery Engine (the SAME path /start <payload> uses).
            # b10 §4: this is also the MAIN bot's terminal decision — it
            # owns the payload file references and never redirects.
            # BOT-11 §12: a TARGETED link that ARRIVED at its persisted
            # target resolves here too (terminal, stable) — the resolution
            # is logged before delivery for the audit trail.
            if int(decision.get("target_network_bot_id") or 0) > 0:
                logger.info("GLOBAL_LINK_TARGET_RESOLVED user_id=%s "
                            "code=%s target_network_bot_id=%s "
                            "via=arrival_at_target",
                            user.id, public_code[:8],
                            int(decision.get("target_network_bot_id")))
            logger.info("GLOBAL_LINK_DELIVERY_OK user_id=%s payload_id=%s "
                        "via=current_context", user.id, payload_id)
            await finalize_delivery(update, context, payload_code, user)
            return

        if action == "deliver_via_target":
            # BOT-11 §12 (B11-B): a targeted link arriving anywhere EXCEPT
            # its persisted target — ONE deterministic deep-link button to
            # the PERSISTED target. NEVER a re-roll, NEVER a health-based
            # substitution; the deep link carries the ORIGINAL raw /start
            # argument (case-preserved — the signature survives intact).
            bot_row = decision.get("bot") or {}
            uname = (bot_row.get("username") or "").lstrip("@")
            deep_arg = str(decision.get("deep_arg") or arg)
            target_id = int(decision.get("target_network_bot_id") or 0)
            logger.info("GLOBAL_LINK_TARGET_RESOLVED user_id=%s code=%s "
                        "target_network_bot_id=%s via=deliver_via_target",
                        user.id, public_code[:8], target_id)
            if uname:
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\U0001F517 Continue to receive this payload through "
                    f"@{uname}:",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(
                            f"Continue in @{uname}",
                            url=f"https://t.me/{uname}?start={deep_arg}")
                    ]]))
                return
            # No usable username → serve in the current context after all
            # (never a button with a fabricated username).
            await finalize_delivery(update, context, payload_code, user)
            return

        if action == "target_unavailable":
            # BOT-11 §13 (B11-B): the persisted delivery target is gone
            # (REMOVED), paused/invalid (DISABLED/TOKEN_INVALID), unknown,
            # or — only when the user actually ARRIVED at it — not
            # delivery-ready. ONE honest message; the user returns to the
            # website and presses Get File again. Never a re-roll.
            reason = str(decision.get("reason") or "")
            log_event = {
                "target_removed": "GLOBAL_LINK_TARGET_REMOVED",
                "target_inactive": "GLOBAL_LINK_TARGET_INACTIVE",
                "target_not_found": "GLOBAL_LINK_TARGET_NOT_FOUND",
                "target_not_ready": "GLOBAL_LINK_TARGET_NOT_READY",
            }.get(reason, "GLOBAL_LINK_TARGET_UNAVAILABLE")
            logger.warning("%s user_id=%s code=%s reason=%s",
                           log_event, user.id, public_code[:8], reason)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u26A0\uFE0F This delivery bot is no longer available.\n\n"
                "Please return to the website and press Get File again.")
            return

        if action == "deliver_via":
            bot_row = decision.get("bot") or {}
            uname = (bot_row.get("username") or "").lstrip("@")
            deep_arg = str(decision.get("deep_arg") or arg)
            if uname:
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\U0001F517 Continue to receive this payload through "
                    f"@{uname}:",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(
                            f"Continue in @{uname}",
                            url=f"https://t.me/{uname}?start={deep_arg}")
                    ]]))
                return
            # No usable username → serve in the current context after all.
            await finalize_delivery(update, context, payload_code, user)
            return

        if action == "deliver_via_main":
            # b10 §4: the arrival is at a NETWORK bot that cannot serve
            # and no eligible network bot exists — ONE terminal deep-link
            # button to the MAIN bot (mirrors deliver_via; the MAIN bot
            # always delivers, so this can never dead-end).
            uname = (decision.get("main_username") or "").lstrip("@")
            deep_arg = str(decision.get("deep_arg") or arg)
            if uname:
                logger.info("GLOBAL_LINK_REDIRECT_MAIN user_id=%s "
                            "payload_id=%s via_main=@%s",
                            user.id, payload_id, uname)
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\U0001F517 Continue to receive this payload through "
                    f"@{uname}:",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(
                            f"Continue in @{uname}",
                            url=f"https://t.me/{uname}?start={deep_arg}")
                    ]]))
                return
            # Unresolvable main username (router already guarantees this
            # is near-impossible) → fall through to the honest unavailable
            # message; NEVER a button with a fabricated username.
            logger.warning("GLOBAL_LINK_REDIRECT_MAIN user_id=%s "
                           "payload_id=%s via_main=@%s "
                           "reason=missing_main_username",
                           user.id, payload_id, uname)

        # unavailable — friendly temporary-unavailable (spec §19), never raw
        # internal routing errors.
        logger.warning("GLOBAL_LINK_NO_ELIGIBLE_NETWORK user_id=%s "
                       "payload_id=%s reason=%s", user.id, payload_id,
                       decision.get("reason"))
        logger.info("GLOBAL_PAYLOAD_ROUTE_FAILED user_id=%s payload_id=%s "
                    "reason=%s", user.id, payload_id, decision.get("reason"))
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u26A0\uFE0F This content is temporarily unavailable.\n"
            "Please try again in a few minutes.")

    async def generate_global_payload_link(payload_id: int) -> Optional[str]:
        """Mint + persist a Global Payload Link for a payload (admin).

        GAP-CLOSURE spec §4: fails CLOSED (returns None) when the dedicated
        persistent NETWORK_GLOBAL_LINK_SIGNING_KEY is missing — never
        silently signs with a rotating BOT_TOKEN-derived key.

        v37 (bot-8 A6): mint + persist each emit a structured diagnostic."""
        try:
            code = _net_links.mint_code()
        except Exception as exc:  # noqa: BLE001 — LinkSigningUnavailableError
            logger.warning(
                "GLOBAL_LINK_MINT_REFUSED payload_id=%s reason=%s",
                payload_id, type(exc).__name__)
            return None
        logger.info("GLOBAL_LINK_MINT_OK payload_id=%s code=%s",
                    payload_id, code[:8])
        await db.create_global_payload_link(int(payload_id), code)
        logger.info("GLOBAL_LINK_PERSIST_OK payload_id=%s code=%s",
                    payload_id, code[:8])
        return code

    async def handle_pt_unlock(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               payload_id: int) -> None:
        """[⭐ Unlock with N Points] — atomic debit + unlock + re-delivery.

        The transaction (db.points_purchase_transaction) guarantees:
          * BEGIN IMMEDIATE (serialized against concurrent unlocks)
          * existing unlock → ok WITHOUT a second debit (idempotent)
          * balance < cost → ROLLBACK → no unlock, no debit
          * debit + unlock row commit TOGETHER
        Access eligibility is re-verified BEFORE spending: admins bypass,
        Force Join must pass, and the payload must actually be gated (never
        spend points on an already-authorized OPEN payload)."""
        q = update.callback_query
        user = q.from_user if q else None
        if not q or not user:
            return
        try:
            pid = int(payload_id)
        except (TypeError, ValueError):
            await safe_answer_callback(q, "Invalid request.", show_alert=True)
            return
        payload_row = await db.get_payload_by_id(pid)
        if not payload_row or payload_row["status"] != "active":
            await safe_answer_callback(q, "Payload not found.", show_alert=True)
            return
        payload_code = str(payload_row["payload"])
        # Re-run the authoritative engine: FJ first, then the gate state.
        res = await access_engine(context.bot, user.id, payload_id=pid)
        if res.authorized:
            # Already unlockable (referral done / ad verified / admin) — NEVER
            # spend points (spec §9: do not consume points when unlock would
            # succeed anyway).
            await safe_answer_callback(
                q, "You already have access — no points needed.")
            await finalize_delivery(update, context, payload_code, user)
            return
        if res.reason == "force_join_required":
            await safe_answer_callback(
                q, "Join the required channels first.", show_alert=True)
            return
        if not await _point_access_active():
            await safe_answer_callback(
                q, "Point access is currently disabled.", show_alert=True)
            return
        cost = await _point_cost()
        purchase = await db.points_purchase_transaction(pid, int(user.id), cost)
        if purchase.get("ok"):
            logger.info("POINTS_DEBITED user_id=%s event=PAYLOAD_UNLOCK "
                        "amount=-%s ref=PAYLOAD:%s (atomic transaction "
                        "committed; debited=%s)", user.id, cost, pid,
                        purchase.get("debited"))
            await safe_answer_callback(
                q, f"Unlocked with {cost} point{'s' if cost != 1 else ''}!")
            # Re-deliver through the standard path — the Access Engine now
            # sees the valid point unlock (reason=points_unlocked).
            await finalize_delivery(update, context, payload_code, user)
            return
        reason = str(purchase.get("reason"))
        if reason == "insufficient_points":
            bal = int(purchase.get("balance") or 0)
            await safe_answer_callback(
                q, f"Not enough points (you have {bal}, need {cost}).\n"
                   "Register bots to earn +5 each!", show_alert=True)
            return
        if reason == "already_unlocked":
            await safe_answer_callback(q, "Already unlocked with points.")
            await finalize_delivery(update, context, payload_code, user)
            return
        await safe_answer_callback(
            q, "Unlock failed — nothing was charged.", show_alert=True)

    async def network_command(update: Update,
                              context: ContextTypes.DEFAULT_TYPE) -> None:
        """🌐 My Network — user entry: registered bots, points, how it works.

        v37 (Part Q1/Q2): this is the USER-FACING Main Bot command (normal
        authenticated users manage their OWN bots — no admin gate). It is
        registered on the MAIN application's command table AND the command
        menu; /setup (Delivery Group) lives on the NETWORK bot plane —
        these two command planes never mix (Q13). The panel is fully
        reconstructable from persistent DB state (Q3/Q11) — no in-memory
        registration state is required."""
        user = update.effective_user
        if not user:
            return
        chat_type = update.effective_chat.type if update.effective_chat else None
        if chat_type in ("group", "supergroup"):
            return
        logger.info("NETWORK_COMMAND_RECEIVED user_id=%s chat_id=%s",
                    user.id, update.effective_chat.id)
        try:
            await db.upsert_user(user.id, user.username, user.first_name)
        except Exception as exc:  # noqa: BLE001 — never block the panel
            logger.warning("NETWORK_COMMAND_RESULT result=failure "
                           "reason=upsert_failed detail=%s", str(exc)[:80])
        # v36: /network is an explicit navigation — it ends every pending
        # input conversation (a stale ncreate/nreg token prompt dies here)
        # and resets the wizard origin to the USER surface.
        clear_conversation_input_states(context)
        clear_net_wizard_origin(context)
        # b10 §1 (B10-B2): /network also kills the DURABLE token-input
        # intent (explicit navigation reset — same semantics as Back) and
        # marks the stale prompt best-effort.
        _stale_intent = clear_pending_token_intent(int(user.id))
        if _stale_intent is not None:
            await _net_reg_mark_stale_prompt(context, _stale_intent)
        if not await network_enabled():
            logger.info("NETWORK_COMMAND_RESULT result=failure "
                        "reason=network_disabled user_id=%s", user.id)
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\U0001F310 The Network is currently disabled.")
            return
        try:
            await _render_my_network(update, context, user)
            logger.info("NETWORK_COMMAND_RESULT result=success "
                        "reason=- user_id=%s", user.id)
        except Exception as exc:  # noqa: BLE001 — honest failure log
            logger.warning("NETWORK_COMMAND_RESULT result=failure "
                           "reason=render_error detail=%s", str(exc)[:120])
            raise

    async def _render_my_network(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 user: User) -> None:
        # v36 (spec §4): arriving at My Network consumes the wizard
        # origin — this IS the user-surface root for the network wizards.
        clear_net_wizard_origin(context)
        """v37 note: the persistent Network Bot Management panel body lives
        in _render_my_network_panel below (kept as a separate render so
        callback re-entry — nreg:back / Refresh / post-registration return
        — reuses the exact same persistent view)."""
        await _render_my_network_panel(update, context, user)

    async def _render_my_network_panel(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE,
                                       user: User) -> None:
        """The persistent Network Bot Management panel (Part Q3/Q5/Q8/Q9).

        Reconstructed ENTIRELY from DB state (list_network_bots_for_owner)
        — it survives restarts, callback navigation, message edits and
        re-opening /network. Every owned bot gets a management button
        (nbot:<id> — the same persistent management view "Manage Bot"
        opens); the create flow remains reachable without hiding the
        existing bot list; the +5 note states the REAL rule
        (DELIVERY_READY only).

        b10 §5: REMOVED bots (status=REMOVED, plus the legacy
        DISABLED+REMOVED shape) are EXCLUDED from the rendered list, the
        nbot:<id> buttons AND the Registered-bots count — a removed bot
        is gone (the bot-10.log showed a removed bot still rendered and
        clickable). DISABLED (admin/owner pause) stays visible on
        purpose: paused bots are re-enableable history."""
        max_bots = await db.get_setting_int(NET_SETTING_MAX_BOTS,
                                            NET_DEFAULT_MAX_BOTS)
        my_bots = await db.list_network_bots_for_owner(int(user.id))
        # b10 §5: one filter feeds BOTH the rendered lines and the
        # nbot:<id> buttons (plus the count) — removed bots vanish.
        visible_bots = [b for b in my_bots if not _is_removed_bot(b)]
        active = [b for b in visible_bots if str(b["status"]) != "DISABLED"]
        balance = await db.points_balance(int(user.id))
        lines = ["\U0001F4E1 Network Bot Management", ""]
        if not visible_bots:
            lines.append("You don't have a Network Bot yet.")
        lines.append(f"\U0001F916 Registered bots: {len(active)}/{max_bots}")
        for b in visible_bots[:10]:
            st = str(b["status"])
            icon = {"ACTIVE": "\U0001F7E2", "PENDING": "\u26A0\uFE0F",
                    "DEGRADED": "\U0001F7E1"}.get(st, "\U0001F534")
            # v34: delivery readiness is the meaningful user-facing state.
            group = await db.get_delivery_group_for_bot(int(b["id"]))
            gs = str((group or {}).get("status") or "")
            dmark = " \u2705" if gs == "DELIVERY_READY" else (
                " \U0001F4C1" if not group else " \u26A0\uFE0F")
            mode = (" \U0001F916" if str(b.get("management_mode"))
                    == "PLATFORM_MANAGED" else "")
            lines.append(f"  {icon} @{b['username']}{dmark}{mode} — {st}")
        lines.append("")
        lines.append(f"\u2B50 Points: {balance}")
        # FILE DELIVERY v34 (spec §60): +5 only after the complete verified
        # Delivery Channel setup — never for registration alone.
        lines.append("\U0001F4E1 +5 points when your Network Bot completes "
                     f"Delivery Channel setup (max {max_bots}).")
        kb_rows = []
        # Q5/Q8: every VISIBLE owned bot is directly manageable from the
        # persistent panel (same view "Manage Bot" opens); 0/1/2+ bots all
        # supported — b10 §5: removed bots never get a button.
        for b in visible_bots[:10]:
            kb_rows.append([InlineKeyboardButton(
                f"\U0001F916 @{b['username']}",
                callback_data=f"{NET_BOT_CB}{int(b['id'])}")])
        kb_rows.append([InlineKeyboardButton("\u2795 Add Existing Bot",
                                             callback_data=f"{NET_REG_CB}start"),
                        InlineKeyboardButton("\U0001F916 Create Network Bot",
                                             callback_data=f"{NET_CREATE_CB}start")])
        kb_rows.append([InlineKeyboardButton("\U0001F4C1 Delivery (Channel-Only)",
                                             callback_data=f"{NET_DG_CB}main"),
                        InlineKeyboardButton("\U0001F504 Refresh",
                                             callback_data=f"{NET_REG_CB}back")])
        kb_rows.append([InlineKeyboardButton("\u2B50 My Points",
                                             callback_data=f"{NET_PTS_CB}main"),
                        InlineKeyboardButton("\u2139\uFE0F How It Works",
                                             callback_data=f"{NET_REG_CB}how")])
        # b10 §8 (B10-B2): every REGISTERED bot's /network panel carries
        # the visible Open Main App button — pointing at the ONE
        # canonical MAIN Mini App URL (never a per-bot URL). Rendered
        # ONLY inside a network worker (the MAIN bot's own panel is the
        # app itself) and only when the canonical URL resolves.
        if _net_context_id(context) is not None:
            _ma_url = await _net_main_app_url_safe()
            if _ma_url:
                kb_rows.append([InlineKeyboardButton(
                    "\U0001F310 Open Main App", url=_ma_url)])
        kb = InlineKeyboardMarkup(kb_rows)
        text = "\n".join(lines)
        q = getattr(update, "callback_query", None)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    def _net_reg_get(context) -> Optional[Dict[str, Any]]:
        return context.user_data.get(_NET_REG_STATE_KEY)

    def _net_reg_clear(context) -> None:
        context.user_data.pop(_NET_REG_STATE_KEY, None)

    # ---------------------------------------------------------------
    # b10 §1 (B10-B2): token-input intent + stale-prompt cleanup
    # ---------------------------------------------------------------
    async def _net_reg_mark_stale_prompt(context, intent) -> None:
        """Best-effort: when the token-input intent dies while its
        "Send the Bot Token" prompt is still on screen, try to REPLACE
        the prompt text with an honest closed notice so the user is
        never misled into pasting a token nobody will process (the
        robust-combination belt-and-braces of spec §1). Never raises,
        never includes token material."""
        if not intent:
            return
        chat_id = intent.get("chat_id")
        message_id = intent.get("message_id")
        if chat_id is None or message_id is None:
            return
        try:
            await context.bot.edit_message_text(
                int(chat_id), int(message_id),
                "⌛️ Token input closed — no token is being accepted for "
                "this flow anymore.\n\nStart again from My Network → "
                "Add Existing Bot (or /network).")
        except Exception:  # noqa: BLE001 — best-effort UX cleanup
            pass

    def _net_reg_cancel_intent(context, user) -> Optional[dict]:
        """Explicit Back/Cancel: drop the durable token intent too (the
        ONLY navigation-class action allowed to kill it, per spec §1)."""
        uid = int(getattr(user, "id", 0) or 0)
        return clear_pending_token_intent(uid) if uid else None

    async def _net_reg_cancel(update, context, user) -> None:
        """Back/Cancel of the Add Existing Bot flow: purge the wizard
        state, kill the durable intent and mark the stale prompt."""
        intent = _net_reg_cancel_intent(context, user)
        _net_reg_clear(context)
        await _net_reg_mark_stale_prompt(context, intent)

    # ------------------------------------------------------------------
    # BOT-11 §6 (B11-D2): Change Token on an existing registered bot.
    # ------------------------------------------------------------------
    async def _net_change_token_prompt(update, context, nid: int) -> None:
        """[🔑 Change Token] on a registered bot — arm the change-token
        input window (the §6 prompt) + the durable intent."""
        q = update.callback_query
        row = await db.get_network_bot(nid) if nid else None
        if not row:
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        uname = str(row.get("username") or "").lstrip("@") or "?"
        # Arm BOTH the conversation state and the durable intent (the
        # b10 §1 discipline — survives callback navigation, TTL-bounded,
        # consumed exactly once). NEVER token material in the logs.
        context.user_data[_NET_REG_STATE_KEY] = stamp_conversation_state(
            {"step": "await_change_token", "existing_nid": int(nid)})
        set_pending_token_intent(
            int(getattr(getattr(update, "effective_user", None), "id", 0)
                or 0), "net_change",
            chat_id=(getattr(update.effective_chat, "id", None)
                     if getattr(update, "effective_chat", None) else None),
            message_id=(getattr(getattr(update, "callback_query", None),
                                "message", None)
                        and getattr(update.callback_query.message,
                                    "message_id", None)))
        logger.info("BOT_TOKEN_INPUT_STARTED user_id=%s flow=net_change "
                    "network_bot_id=%s (change-token window armed; the "
                    "token itself is NEVER logged)",
                    int(getattr(getattr(update, "effective_user", None),
                                "id", 0) or 0), int(nid))
        await safe_answer_callback(q)
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\U0001F511 Change Token — @" + uname + "\n\n"
            "Send the new BotFather token.\n"
            "The token will be validated before replacing the current "
            "credential.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u274C Cancel",
                                      callback_data=f"{NET_REG_CB}changecancel")]]))

    async def _net_change_token_text(update, context, user,
                                     token: str) -> None:
        """A token submitted during the change-token window (§6/§7).

        Validation is ALWAYS Telegram getMe FIRST; the stored credential
        is replaced ONLY after validation. An identity change requires an
        explicit confirmation (never silently rebinds the row)."""
        state = _net_reg_get(context)
        nid = int((state or {}).get("existing_nid") or 0)
        row = await db.get_network_bot(nid) if nid else None
        if not row or _is_removed_bot(row):
            _net_reg_clear(context)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This bot is no longer available — the token was "
                "NOT changed.")
            return
        logger.info("BOT_TOKEN_RECEIVED user_id=%s flow=net_change "
                    "length=%s (content never logged)",
                    int(user.id), len(token))
        if not _net_token_format_ok(token):
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_change "
                        "reason=bad_token_format (retry kept)", int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C That doesn't look like a bot token.\n"
                "Format: 123456789:ABCdef... (from @BotFather)\n\n"
                "Try again, or Cancel.")
            return
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u23F3 Verifying the new token with Telegram...")
        logger.info("BOT_TOKEN_VALIDATION_STARTED user_id=%s "
                    "flow=net_change (getMe identity validation)",
                    int(user.id))
        val = await _net_validate_token_via_telegram(token)
        ok = bool(val.get("ok"))
        bot_info = val.get("bot") or {}
        new_tg_id = int(bot_info.get("id") or 0)
        new_uname = str(bot_info.get("username") or "").lstrip("@")
        logger.info("BOT_TOKEN_VALIDATION_RESULT user_id=%s "
                    "flow=net_change ok=%s reason=%s",
                    int(user.id), ok, val.get("reason"))
        if not ok or not new_tg_id or not new_uname:
            reason = str(val.get("reason") or "unknown")
            retryable = reason in ("telegram_unreachable",)
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_change "
                        "reason=%s (%s)", int(user.id), reason,
                        "retry kept" if retryable else "input closed")
            if not retryable:
                _net_reg_clear(context)
                clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Token invalid (" + reason + ").\n\n"
                "The existing bot token was not changed."
                + ("" if retryable else " Start again from the bot's panel."),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F510 Try again",
                                          callback_data=(
                                              f"{NET_BOT_CB}{nid}"
                                              ":changetoken"))]])
                if not retryable else None)
            return
        if new_tg_id == int(row["telegram_bot_id"]):
            # SAME bot identity — the safe replace (§6 happy path).
            await _net_change_token_apply(
                update, context, user, nid, token, new_tg_id, new_uname)
            return
        # DIFFERENT bot identity — explicit confirmation required (§6).
        state["step"] = "await_change_confirm"
        state["token"] = token
        state["new_tg_id"] = new_tg_id
        state["new_username"] = new_uname
        stamp_conversation_state(state)
        update_pending_token_intent(int(user.id), step="await_change_confirm")
        cur_uname = str(row.get("username") or "").lstrip("@") or "?"
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u26A0\uFE0F This token belongs to @" + new_uname + ".\n\n"
            "Replace @" + cur_uname + " with @" + new_uname + "?\n"
            "The registered bot's identity will change to the new bot.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2705 Yes, Replace Identity",
                                      callback_data=(
                                          f"{NET_REG_CB}changeconfirm"))],
                [InlineKeyboardButton("\u274C Cancel",
                                      callback_data=(
                                          f"{NET_REG_CB}changecancel"))]]))

    async def _net_change_token_apply(update, context, user, nid: int,
                                      token: str, new_tg_id: int,
                                      new_uname: str) -> None:
        """Apply a VALIDATED change-token: re-encrypt + replace the
        credential (identity optionally updated), restart the worker,
        truthful §6 result. The old credential is only replaced AFTER
        validation succeeded (never before)."""
        state = _net_reg_get(context)
        row = await db.get_network_bot(nid) if nid else None
        if not row:
            _net_reg_clear(context)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This bot is no longer available — nothing was "
                "changed.")
            return
        identity_changed = int(row["telegram_bot_id"]) != int(new_tg_id)
        if identity_changed:
            # Explicit confirmation already given (await_change_confirm).
            await db.conn.execute(
                "UPDATE network_bots SET telegram_bot_id=?, username=?, "
                "display_name=COALESCE(display_name, ?), updated_at=? "
                "WHERE id=?",
                (int(new_tg_id), str(new_uname), str(new_uname),
                 _now_iso_str(), int(nid)))
            await db.conn.commit()
        if _net_registry is not None and _net_registry.vault is not None:
            enc = _net_registry.vault.encrypt(token)
            await db.upsert_network_bot_credential(
                int(nid), encrypted_token=enc,
                key_version=int(getattr(_net_registry.vault, "key_version",
                                        1)))
        # Same-bot replace resets any token-invalid state.
        if str(row.get("status")) == "TOKEN_INVALID":
            await db.update_network_bot_status(int(nid), "PENDING")
        _net_reg_clear(context)
        consume_pending_token_intent(int(user.id))
        logger.info("BOT_TOKEN_PERSISTED user_id=%s flow=net_change "
                    "network_bot_id=%s identity_changed=%s",
                    int(user.id), int(nid), identity_changed)
        # Worker restart: stop any stale worker for the OLD identity and
        # start fresh (the credential changed underneath it).
        worker_started = False
        if _net_workers is not None:
            try:
                await _net_workers.stop_worker(int(nid))
            except Exception:  # noqa: BLE001 — best-effort stop
                pass
            try:
                worker = await _net_workers.start_worker(
                    int(nid), int(new_tg_id), str(new_uname), token)
                worker_started = worker is not None
            except Exception as exc:  # noqa: BLE001 — honest report
                logger.warning("change-token worker start failed bot=%s: %s",
                               nid, exc)
        if worker_started and _net_registry is not None:
            await _net_registry.mark_active(int(nid))
        status_line = ("\U0001F7E2 Worker restarting..."
                       if worker_started else
                       "\u26A0\uFE0F Worker could not restart now — it "
                       "will start at the next platform restart.")
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 Token updated\n\n"
            f"Bot: @{new_uname}\n"
            f"Telegram ID: {int(new_tg_id)}\n\n{status_line}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u2699\uFE0F Manage Bot",
                                      callback_data=f"{NET_BOT_CB}{nid}")]]))

    async def _net_change_confirm(update, context, user) -> None:
        """[Yes, Replace Identity] — apply the held change-token with the
        confirmed NEW identity."""
        state = _net_reg_get(context)
        if not state or str(state.get("step")) != "await_change_confirm":
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The confirmation window has closed — no token is "
                "being held anymore. Start again from the bot's panel.")
            return
        if _conversation_state_expired(state):
            _net_reg_clear(context)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The change-token confirmation expired — nothing "
                "was saved.")
            return
        nid = int(state.get("existing_nid") or 0)
        token = str(state.get("token") or "")
        new_tg_id = int(state.get("new_tg_id") or 0)
        new_uname = str(state.get("new_username") or "")
        if not nid or not token or not new_tg_id or not new_uname:
            _net_reg_clear(context)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The held token expired. Start again.")
            return
        await _net_change_token_apply(
            update, context, user, nid, token, new_tg_id, new_uname)

    async def _net_change_cancel(update, context, user) -> None:
        """[Cancel] of the change-token flow — purge everything honestly."""
        intent = clear_pending_token_intent(int(user.id))
        _net_reg_clear(context)
        await _net_reg_mark_stale_prompt(context, intent)
        q = update.callback_query
        await safe_answer_callback(q, "Cancelled — no token was changed.")
        await _render_my_network(update, context, user)

    async def _net_main_app_url_safe() -> str:
        """b10 §8 (B10-B2): THE canonical Main Mini App URL, resolved
        through the runtime namespace facade (website_public_base_url +
        /site, HTTPS-validated). '' when not configured / not https /
        namespace unavailable — the callers then render NO button (never
        a fabricated link, never a second invented URL)."""
        try:
            from app.presentation.telegram import runtime as _rt_ma
            _url = await _rt_ma._net_main_app_url()
            return str(_url or "")
        except Exception:  # noqa: BLE001 — the link is optional UX
            return ""

    async def _render_net_reg_start(update, context, user) -> None:
        # v36 fail-fast: never invite a token the platform cannot encrypt
        # (fail-closed stays — this only changes WHEN we tell the user).
        if _net_registry is None or not getattr(
                _net_registry, "can_encrypt_tokens", True):
            await safe_edit_text(
                getattr(update, "callback_query", None),
                "\u2795 Add a Bot to the Network\n\n"
                "\u26D4\uFE0F Temporarily unavailable.\n\n"
                "The platform's encryption key is not configured — ask the "
                "platform admin to set NETWORK_TOKEN_ENCRYPTION_KEY and "
                "restart.\n\n"
                "No token was collected (bot tokens are only accepted when "
                "they can be stored encrypted).",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back",
                                          callback_data=f"{NET_REG_CB}back")]]))
            return
        max_bots = await db.get_setting_int(NET_SETTING_MAX_BOTS,
                                            NET_DEFAULT_MAX_BOTS)
        cur = await db.count_network_bots_for_owner(int(user.id))
        text = (
            "\u2795 Add a Bot to the Network\n\n"
            "Register a Telegram bot you OWN to earn points and expand the "
            "network.\n\n"
            f"\U0001F916 Your bots: {cur}/{max_bots}\n"
            "\u2B50 Reward: +5 points when the bot completes Delivery "
            "Group setup\n\n"
            "You will need:\n"
            "1\u20E3 The bot token (from @BotFather)\n"
            "2\u20E3 The bot must NOT be running elsewhere\n"
            "3\u20E3 Your confirmation that you own it\n\n"
            "\u2139\uFE0F The token is stored ENCRYPTED and never displayed "
            "again.\n"
            "\u26A0\uFE0F Remove the bot from other servers first — Telegram "
            "allows only one connection per bot."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 I have the token — Continue",
                                  callback_data=f"{NET_REG_CB}token")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"{NET_REG_CB}back")],
        ])
        q = getattr(update, "callback_query", None)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_net_reg_token(update, context) -> None:
        # v36: single active conversation + freshness stamp + an explicit
        # Cancel button (in addition to /network).
        clear_conversation_input_states(context)
        text = (
            "\U0001F511 Send the Bot Token\n\n"
            "Paste the token from @BotFather now.\n"
            "Format: 123456789:ABCdef...\n\n"
            "\U0001F512 The token is encrypted immediately and never shown or "
            "logged again.\n"
            "\u23F3 The input times out after 10 minutes."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel",
                                  callback_data=f"{NET_REG_CB}back")],
        ])
        q = getattr(update, "callback_query", None)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _net_reg_consent_keyboard(token_preview_masked: str
                                        ) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(
                "\u2705 I own this bot and authorize the platform to operate it",
                callback_data=f"{NET_REG_CB}consent")],
            [InlineKeyboardButton("\u274C Cancel", callback_data=f"{NET_REG_CB}back")],
        ])

    # ---------------------------------------------------------------
    # BOT-11 (B11-B — spec §5-§7): duplicate-bot RECOVERY (was a dead-end:
    # a removed same-owner bot blocked re-registration forever).
    # ---------------------------------------------------------------
    async def _net_reg_duplicate_recovery(update, context, user, token,
                                          val) -> None:
        """duplicate_bot + same_owner → honest RECOVERY options instead of
        the flat refusal (the bot-11.log root cause 4). The validated
        token is held SERVER-SIDE ONLY (net_reg_state — never in
        callback_data, never logged) for the [♻ Reactivate Bot]
        confirmation; the durable token-input intent is consumed exactly
        once here (the recovery is button-driven)."""
        ex_nid = int(val.get("existing_bot_id") or 0)
        ex_row = await db.get_network_bot(ex_nid) if ex_nid else None
        logger.info(
            "BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_reg "
            "reason=duplicate_bot same_owner=True network_bot_id=%s "
            "(recovery options offered)", int(user.id), ex_nid)
        clear_pending_token_intent(int(user.id))
        if ex_row is None:
            _net_reg_clear(context)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This bot is already registered on the platform.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                    "\u2B05\uFE0F Back to My Network",
                    callback_data=f"{NET_REG_CB}back")]]))
            return
        uname = str(ex_row.get("username") or "").lstrip("@") or "?"
        status = str(ex_row.get("status") or "?")
        removed = _is_removed_bot(ex_row)
        active = status == "ACTIVE" and not removed
        if active:
            text = (
                "\u2705 This bot is already registered.\n\n"
                f"@{uname} (Network Bot #{ex_nid}) is ACTIVE and serving "
                "right now.\n\n"
                "You can manage it below — or, if you rotated its token "
                "in @BotFather, change the token from the bot's panel.")
            rows = [
                [InlineKeyboardButton("\u2699\uFE0F Manage Bot",
                                      callback_data=f"{NET_BOT_CB}{ex_nid}")],
                [InlineKeyboardButton("\U0001F511 Change Token instead",
                                      callback_data=f"{NET_BOT_CB}{ex_nid}")],
            ]
        else:
            if removed:
                headline = "\u267B\uFE0F This bot was previously removed " \
                           "from your network."
                detail = ("Reactivate it with the token you just entered — "
                          "its history is preserved and no new bot slot "
                          "is used.")
            else:
                headline = (f"\u2139\uFE0F This bot is already registered "
                            f"(status: {status}).")
                detail = ("Reactivating stores the token you just entered "
                          "and restarts the bot's worker.")
            text = (
                f"{headline}\n\n"
                f"@{uname} (Network Bot #{ex_nid})\n\n{detail}")
            rows = [
                [InlineKeyboardButton("\u267B\uFE0F Reactivate Bot",
                                      callback_data=f"{NET_REG_CB}reactivate")],
                [InlineKeyboardButton("\U0001F511 Change Token instead",
                                      callback_data=f"{NET_BOT_CB}{ex_nid}")],
            ]
        # Hold the token SERVER-SIDE for the Reactivate confirmation
        # (10-minute conversation TTL; consumed exactly once there).
        state = _net_reg_get(context) or {}
        state["step"] = "await_reactivate"
        state["token"] = token
        state["existing_nid"] = ex_nid
        stamp_conversation_state(state)
        context.user_data[_NET_REG_STATE_KEY] = state
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             reply_markup=InlineKeyboardMarkup(rows))

    async def _net_reg_reactivate(update, context, user) -> None:
        """[\u267B\uFE0F Reactivate Bot] — restore a previously
        removed/invalid same-owner bot with the token the owner just
        supplied: validate with Telegram (getMe), re-persist the encrypted
        credential, restart the worker, honest status. Tries agent-A's
        lifecycle facade `reactivate_network_bot` first (defensive getattr
        — falls back to the local db+registry+workers path when the facade
        has not landed yet)."""
        state = _net_reg_get(context)
        if not state or str(state.get("step")) != "await_reactivate":
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The reactivation window has closed — no token is "
                "being held anymore. Start again from My Network \u2192 "
                "Add Existing Bot.")
            return
        if _conversation_state_expired(state):
            _net_reg_clear(context)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The reactivation expired (10 min) — nothing was "
                "saved. Start again from My Network \u2192 Add Existing Bot.")
            return
        nid = int(state.get("existing_nid") or 0)
        token = str(state.get("token") or "")
        _net_reg_clear(context)  # the held token is consumed exactly once
        row = await db.get_network_bot(nid) if nid else None
        if not row:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This bot no longer exists on the platform.")
            return
        if int(row["owner_user_id"]) != int(user.id) \
                and not await is_admin(user.id):
            logger.warning("NETWORK_BOT_REACTIVATE_REJECTED "
                           "network_bot_id=%s user_id=%s reason=not_owner",
                           nid, int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C You can only reactivate your own bots.")
            return
        if str(row["status"]) == "ACTIVE" and not _is_removed_bot(row):
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u2705 This bot is already registered and ACTIVE — "
                "nothing to reactivate.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2699\uFE0F Manage Bot",
                                          callback_data=f"{NET_BOT_CB}{nid}")]]))
            return
        logger.info("BOT_TOKEN_VALIDATION_STARTED user_id=%s flow=reactivate "
                    "network_bot_id=%s (getMe identity validation)",
                    int(user.id), nid)
        val = await _net_validate_token_via_telegram(token)
        if not val.get("ok"):
            reason = str(val.get("reason") or "unknown")
            logger.info("BOT_TOKEN_VALIDATION_RESULT user_id=%s "
                        "flow=reactivate ok=False reason=%s",
                        int(user.id), reason)
            friendly = {"invalid_token": "Telegram rejected this token.",
                        "telegram_unreachable": "Could not reach "
                                                "Telegram. Try again "
                                                "shortly."}.get(
                            reason, f"Reactivation failed ({reason}).")
            await safe_send_text(
                context.bot, update.effective_chat.id,
                f"\u274C {friendly}\n\nNo changes were made — the stored "
                "credential is untouched.")
            return
        bot_info = val.get("bot") or {}
        if int(bot_info.get("id") or 0) != int(row["telegram_bot_id"]):
            logger.warning("NETWORK_BOT_REACTIVATE_REJECTED "
                           "network_bot_id=%s user_id=%s "
                           "reason=token_identity_mismatch", nid, int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C This token belongs to a different bot "
                f"(@{str(bot_info.get('username') or '?').lstrip('@')}). "
                "Reactivation needs the current token for "
                f"@{str(row.get('username') or '?').lstrip('@')}.")
            return
        # 1) Agent-A's lifecycle facade FIRST (defensive getattr — the
        # facade owns the canonical state machine when it has landed).
        # Proper signature: reactivate_network_bot(ns, owner_user_id,
        # token, ...) — the ns shim carries THIS closure's injected
        # registry/workers. The facade RESULT is inspected: only an
        # ok=True facade run counts (a refusal/fake-registry mismatch
        # falls through to the local path below).
        via_facade = False
        try:
            from app.network import lifecycle as _net_lifecycle
            fn = getattr(_net_lifecycle, "reactivate_network_bot", None)
            if callable(fn) and _net_registry is not None:
                _ns_shim = SimpleNamespace(
                    _net_registry=_net_registry,
                    _net_workers=_net_workers, logger=logger)
                try:
                    _fac = await fn(_ns_shim, int(user.id), token,
                                    consent_confirmed=True)
                    via_facade = bool(_fac and _fac.get("ok"))
                except Exception:  # noqa: BLE001 — facade drift/fake registry
                    via_facade = False
        except Exception:  # noqa: BLE001 — module import issues: local path
            via_facade = False
        # 2) Local reactivation (facade not landed yet — B11-A in flight):
        #    re-persist the encrypted credential (remove_bot DELETED the
        #    row), move the status out of REMOVED, then restart the worker.
        if not via_facade and _net_registry is not None:
            enc = _net_registry.vault.encrypt(token)
            await db.upsert_network_bot_credential(
                nid, encrypted_token=enc,
                key_version=int(getattr(_net_registry.vault,
                                        "key_version", 1)))
            await _net_registry.enable_bot(nid)
        # 3) Worker restart (both paths): idempotent — only start when no
        #    running worker holds this bot.
        worker = None
        if _net_workers is not None:
            try:
                existing = _net_workers.get(nid)
                if existing is not None and getattr(existing, "running",
                                                    False):
                    worker = existing
                else:
                    worker = await _net_workers.start_worker(
                        nid, int(row["telegram_bot_id"]),
                        str(row.get("username") or ""), token)
            except Exception as exc:  # noqa: BLE001 — honest report below
                logger.warning("reactivate worker start failed bot=%s: %s",
                               nid, exc)
                worker = None
        if worker is not None and _net_registry is not None:
            await _net_registry.mark_active(nid)
            status_line = "\U0001F7E2 ACTIVE — the bot is coming online now."
        else:
            if _net_registry is not None:
                await _net_registry.mark_health(
                    nid, "TEMPORARILY_UNAVAILABLE",
                    error_code="WORKER_START_FAILED")
            status_line = ("\u26A0\uFE0F Reactivated, but the worker could "
                           "not start yet (is the bot running elsewhere?). "
                           "It will be retried at the next restart.")
        logger.info("NETWORK_BOT_REACTIVATED network_bot_id=%s user_id=%s "
                    "via=%s", nid, int(user.id),
                    "lifecycle_facade" if via_facade else "network_ui_local")
        uname = str(row.get("username") or "").lstrip("@") or "?"
        kb_rows = []
        try:
            group = await db.get_delivery_group_for_bot(nid)
        except Exception:  # noqa: BLE001
            group = None
        gs = str((group or {}).get("status") or "")
        # V25 §1: delivery is CHANNEL-ONLY — the per-bot panel is shown
        # unconditionally (no group state gate, no setup entry).
        kb_rows.append([InlineKeyboardButton(
            "\U0001F4C1 Delivery (Channel-Only)",
            callback_data=f"{NET_DG_CB}bot:{nid}")])
        kb_rows.append([InlineKeyboardButton("\U0001F310 My Network",
                                             callback_data=f"{NET_REG_CB}back")])
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u267B\uFE0F Bot reactivated!\n\n"
            f"\U0001F916 @{uname}\n{status_line}",
            reply_markup=InlineKeyboardMarkup(kb_rows))

    async def handle_network_registration_text(update: Update,
                                               context: ContextTypes.DEFAULT_TYPE,
                                               user: User, text: str) -> None:
        """Token submission during the registration wizard (text input path).

        b10 §1 (B10-B2): the flow is now INTENT-GATED — the durable
        per-user token-input intent (state.py) survives the v36
        callback-navigation purge that killed the old net_reg_state,
        so a token pasted while looking at a still-visible "Send the
        Bot Token" prompt is processed even after unrelated
        navigation. A token is ONLY accepted while the intent is live
        (accepted exactly once — consumed on the definitive outcomes).
        Stage logs: BOT_TOKEN_RECEIVED / _VALIDATION_STARTED /
        _VALIDATION_RESULT / _FLOW_FAILED (never the token itself)."""
        state = _net_reg_get(context)
        intent = get_pending_token_intent(int(user.id))
        if not state:
            if intent and intent.get("flow") == "net_reg" \
                    and str(intent.get("step")) == "await_token":
                # The b10 §1 root-cause recovery: the wizard state was
                # purged by callback navigation, the durable intent was
                # not. Rebuild the minimal state and KEEP PROCESSING.
                state = stamp_conversation_state({"step": "await_token"})
                logger.info(
                    "BOT_TOKEN_INPUT_RECOVERED user_id=%s flow=net_reg "
                    "(state purged by navigation; durable intent honored)",
                    int(user.id))
            elif intent and intent.get("flow") == "net_change":
                # b11 §6: the change-token state was purged by navigation
                # — the target bot is not recoverable from the intent, so
                # answer HONESTLY (never silently ignore the paste).
                clear_pending_token_intent(int(user.id))
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u23F3 The change-token window closed (navigation) — "
                    "no token was changed. Start again from the bot's "
                    "panel.")
                return
            else:
                return
        if str(state.get("step")) == "await_consent":
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u2139\uFE0F Please confirm with the \u2705 button (or cancel "
                "via /network). Text input is not used at this step.")
            return
        # BOT-11 §6 (B11-D2): the change-token flows own their token text.
        if str(state.get("step")) in ("await_change_token",
                                      "await_change_confirm"):
            if _conversation_state_expired(state):
                _net_reg_clear(context)
                clear_pending_token_intent(int(user.id))
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u23F3 The change-token window timed out — the "
                    "existing credential was NOT changed. Start again "
                    "from the bot's panel.")
                return
            if str(state.get("step")) == "await_change_confirm":
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u2139\uFE0F Please confirm with the \u2705 button (or "
                    "cancel). Text input is not used at this step.")
                return
            await _net_change_token_text(update, context, user,
                                         text.strip())
            return
        if str(state.get("step")) != "await_token":
            # Durable-intent recovery for the CHANGE flow (state purged by
            # navigation — the b10 §1 discipline applied to net_change).
            if intent and intent.get("flow") == "net_change" \
                    and str(intent.get("step")) == "await_token":
                row_nid = int(intent.get("chat_id") or 0) or None
                # The intent does NOT carry the nid (chat_id is the CHAT);
                # a purged change state cannot be rebuilt safely — answer
                # honestly instead of guessing the target bot.
                _ = row_nid
                clear_pending_token_intent(int(user.id))
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u23F3 The change-token window closed (navigation) — "
                    "no token was changed. Start again from the bot's "
                    "panel.")
                return
            return
        if _conversation_state_expired(state):
            _net_reg_clear(context)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u23F3 The token input timed out (10 min) — nothing was "
                "saved. Start again from My Network \u2192 Add Existing Bot.")
            return
        token = text.strip()
        # NEVER echo the token back; never log it. Length only (b10 §1).
        logger.info("BOT_TOKEN_RECEIVED user_id=%s flow=net_reg length=%s "
                    "(content never logged)", int(user.id), len(token))
        if not _net_token_format_ok(token):
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_reg "
                        "reason=bad_token_format (retry kept — nothing "
                        "was saved)", int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C That doesn't look like a bot token.\n"
                "Format: 123456789:ABCdef... (from @BotFather)\n\n"
                "Try again, or /network to cancel.")
            return
        # Validate with Telegram + resolve identity (spec §2).
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u23F3 Verifying the bot with Telegram...")
        logger.info("BOT_TOKEN_VALIDATION_STARTED user_id=%s flow=net_reg "
                    "(getMe identity validation)", int(user.id))
        val = await _net_registry.attempt_registration(
            int(user.id), token, consent_confirmed=False)
        if not val.get("ok") and val.get("reason") == "ownership_not_confirmed":
            # Valid bot — require the explicit ownership consent (spec §57).
            logger.info("BOT_TOKEN_VALIDATION_RESULT user_id=%s flow=net_reg "
                        "ok=True username=@%s consent=pending",
                        int(user.id), val.get("username"))
            state["step"] = "await_consent"
            state["token"] = token
            state["username"] = val.get("username") or ""
            stamp_conversation_state(state)
            # The intent survives at the consent step (a stale consent
            # tap is answered honestly by _net_complete_registration).
            update_pending_token_intent(int(user.id), step="await_consent")
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u2705 Telegram verified the bot: @"
                f"{val.get('username')}\n\n"
                "\u26A0\uFE0F Confirm ownership & authorization:\n"
                "\u201CI own/control this Telegram bot and authorize this "
                "platform to operate it using the provided bot token.\u201D",
                reply_markup=await _net_reg_consent_keyboard(
                    _mask_token(token)))
            return
        reason = str(val.get("reason") or "unknown")
        logger.info("BOT_TOKEN_VALIDATION_RESULT user_id=%s flow=net_reg "
                    "ok=%s reason=%s", int(user.id),
                    bool(val.get("ok")), reason)
        # BOT-11 (B11-B — spec §5-§7): a SAME-OWNER duplicate is a
        # RECOVERY point (reactivate / manage / change token), never the
        # flat dead-end refusal that blocked re-registering a removed
        # bot (bot-11.log root cause 4). A DIFFERENT owner keeps the
        # existing honest refusal below.
        if reason == "duplicate_bot" and val.get("same_owner"):
            await _net_reg_duplicate_recovery(
                update, context, user, token, val)
            return
        friendly = {
            "invalid_token": "Telegram rejected this token. Check it and retry.",
            "telegram_unreachable": "Could not reach Telegram. Try again shortly.",
            "bad_token_format": "That doesn't look like a bot token.",
            "duplicate_bot": "This bot is already registered on the platform.",
            "registration_limit_reached": "You reached the maximum registered "
                                          "bots limit.",
            "network_disabled": "The Network is currently disabled.",
        }.get(reason, f"Registration failed ({reason}). Nothing was saved.")
        # Transient/retryable failures KEEP the intent (spec §1 retry:
        # invalid token → friendly retry, state preserved). Definitive
        # failures consume it (accepted exactly once).
        if reason in ("invalid_token", "telegram_unreachable"):
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_reg "
                        "reason=%s (retry kept — state preserved)",
                        int(user.id), reason)
        else:
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_reg "
                        "reason=%s (input closed)", int(user.id), reason)
            clear_pending_token_intent(int(user.id))
        _net_reg_clear(context)
        await safe_send_text(context.bot, update.effective_chat.id,
                             f"\u274C {friendly}",
                             reply_markup=InlineKeyboardMarkup([[
                                 InlineKeyboardButton(
                                     "\u2B05\uFE0F Back to My Network",
                                     callback_data=f"{NET_REG_CB}back")]]))

    async def _net_complete_registration(update, context, user) -> None:
        """Consent given → finish the verified activation + start worker.

        FILE DELIVERY v34 (spec §60): NO points here — the +5 reward is
        awarded ONLY when the bot completes its Delivery Group setup
        (DELIVERY_READY), by the delivery UI's verification flow."""
        state = _net_reg_get(context)
        if not state or state.get("step") != "await_consent":
            # b10 §1: a stale ✅ tap AFTER the consent state was purged
            # by navigation (the token is NEVER stored in the durable
            # intent, so it cannot be reconstructed) — answer honestly
            # instead of silently doing nothing (dead button class).
            intent = get_pending_token_intent(int(getattr(user, "id", 0) or 0))
            if intent and intent.get("flow") == "net_reg" \
                    and str(intent.get("step")) == "await_consent":
                clear_pending_token_intent(int(user.id))
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u23F3 The registration expired — the token is no "
                    "longer held. Start again from My Network → Add "
                    "Existing Bot.")
            return
        token = str(state.get("token") or "")
        _net_reg_clear(context)
        consume_pending_token_intent(int(user.id))  # accepted exactly once
        if not token:
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C Registration expired. Start again.")
            return
        logger.info("BOT_TOKEN_VALIDATION_STARTED user_id=%s flow=net_reg "
                    "(consent confirmed — persisting)", int(user.id))
        val = await _net_registry.attempt_registration(
            int(user.id), token, consent_confirmed=True)
        if not val.get("ok"):
            reason = str(val.get("reason") or "unknown")
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=net_reg "
                        "reason=%s (consent confirmed)", int(user.id),
                        reason)
            friendly = {
                "invalid_token": "Telegram rejected this token.",
                "telegram_unreachable": "Could not reach Telegram. Try again.",
                "duplicate_bot": "This bot is already registered.",
                "registration_limit_reached": "You reached the bot limit.",
            }.get(reason, f"Registration failed ({reason}).")
            await safe_send_text(context.bot, update.effective_chat.id,
                                 f"\u274C {friendly}")
            return
        nid = int(val["network_bot_id"])
        username = str(val.get("username") or "")
        tg_id = int(val.get("telegram_bot_id") or 0)
        # b10 §1 stage log: the credential is now PERSISTED (encrypted by
        # the registry inside attempt_registration — never plaintext).
        logger.info("BOT_TOKEN_PERSISTED user_id=%s flow=net_reg "
                    "network_bot_id=%s telegram_bot_id=%s username=@%s "
                    "storage=encrypted", int(user.id), nid, tg_id, username)
        # Worker start + health check → ACTIVE (failure keeps PENDING and is
        # honestly reported).
        worker = await _net_workers.start_worker(nid, tg_id, username, token)
        if worker is not None:
            await _net_registry.mark_active(nid)
            status_line = "\U0001F7E2 ACTIVE — the bot is now serving users."
        else:
            await _net_registry.mark_health(
                nid, "TEMPORARILY_UNAVAILABLE", error_code="WORKER_START_FAILED")
            status_line = ("\u26A0\uFE0F Registered, but the worker could not "
                           "start (is the bot running elsewhere?). It will be "
                           "retried at the next restart.")
        # v34: next step — Delivery Channel setup (where the +5 happens).
        pts_line = ("\n\U0001F4C1 Next: connect a private Delivery Channel to "
                    "activate delivery — and earn +5 points when the "
                    "setup is verified.")
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 Bot registered!\n\n"
            f"\U0001F916 @{username}\n{status_line}{pts_line}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4C1 Delivery (Channel-Only)",
                                     callback_data=f"{NET_DG_CB}bot:{nid}")],
                [InlineKeyboardButton("\U0001F310 My Network",
                                     callback_data=f"{NET_REG_CB}back")]]))

    async def render_network_control(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> None:
        """🌐 Network Control — the admin entry."""
        # v36 (spec §4): arriving at the admin Network Control panel
        # consumes the wizard origin (Back landed where it belongs).
        clear_net_wizard_origin(context)
        bots = await db.list_network_bots()
        active = sum(1 for b in bots if str(b["status"]) == "ACTIVE")
        disabled = sum(1 for b in bots if str(b["status"]) == "DISABLED")
        degraded = sum(1 for b in bots if str(b["status"]) in ("DEGRADED",
                                                               "TOKEN_INVALID",
                                                               "ERROR"))
        reachable = await db.count_reachable_users()
        totals = await db.points_totals()
        bcasts = await db.list_broadcasts(limit=100)
        running = sum(1 for b in bcasts if str(b["status"]) == "RUNNING")
        # FILE DELIVERY v34: relay-plane snapshot (safe booleans only).
        fdb = None
        try:
            from app.presentation.telegram import runtime as _rt
            fdb = getattr(_rt, "_fdb", None)
        except Exception:  # noqa: BLE001
            fdb = None
        fdb_line = ""
        if fdb is not None:
            snap = await fdb.status_snapshot()
            st = str(snap.get("status") or "UNCONFIGURED")
            fdb_line = (f"\U0001F4E6 File Delivery Bot: {st} "
                        f"(storage: {snap.get('storage_access')})\n"
                        f"\U0001F4C1 Delivery Channels ready: "
                        f"{await db.count_delivery_groups(True)}/"
                        f"{await db.count_delivery_groups()}\n")
        # MANAGED BOTS v37 (Task 8): truthful capability status — the
        # main bot's own User.can_manage_bots flag (True/False/None;
        # None = Telegram did not report it).
        managed_line = ""
        try:
            from app.presentation.telegram import runtime as _rt_cap
            cap = await _rt_cap.managed_bot_capability_status(context.bot)
            _cmb = cap.get("can_manage_bots")
            if _cmb is True:
                managed_line = "\U0001F916 Managed Bots: READY\n"
            elif _cmb is False:
                managed_line = ("\U0001F916 Managed Bots: NOT READY "
                                "(this bot cannot manage bots)\n")
            else:
                managed_line = ("\U0001F916 Managed Bots: NOT READY "
                                "(capability not reported by Telegram)\n")
        except Exception:  # noqa: BLE001 — diagnostic only, never blocks
            managed_line = ""
        text = (
            "\U0001F310 Network Control\n\n"
            f"\U0001F916 Bots: {len(bots)} (\U0001F7E2 {active} \u26A0\uFE0F "
            f"{degraded} \U0001F534 {disabled})\n"
            f"{fdb_line}"
            f"{managed_line}"
            f"\U0001F464 Reachable users: {reachable}\n"
            f"\u2B50 Points awarded: {totals['awarded']} | spent: "
            f"{totals['spent']}\n"
            f"\U0001F4E2 Broadcasts: {len(bcasts)} ({running} running)\n"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F916 Registered Bots",
                                  callback_data=f"{NET_CB_PREFIX}bots"),
             InlineKeyboardButton("\U0001F7E2 Bot Health",
                                  callback_data=f"{NET_CB_PREFIX}health")],
            [InlineKeyboardButton("\u2B50 Points Settings",
                                  callback_data=f"{NET_CB_PREFIX}points"),
             InlineKeyboardButton("\U0001F517 Global Links",
                                  callback_data=f"{NET_CB_PREFIX}links")],
            [InlineKeyboardButton("\U0001F4E2 Broadcast Center",
                                  callback_data=f"{NET_BCAST_CB}main"),
             InlineKeyboardButton("\U0001F4CA Analytics",
                                  callback_data=f"{NET_CB_PREFIX}stats")],
            # v36 (spec §4): admin entries into the shared wizards with
            # explicit ORIGIN — Back from Create Network Bot / Delivery
            # Groups returns HERE (admin Network Control), never to the
            # unrelated user-facing My Network.
            [InlineKeyboardButton("\U0001F916 Create Network Bot",
                                  callback_data=f"{NET_CB_PREFIX}ncreate"),
             InlineKeyboardButton("\U0001F4C1 Delivery Channels",
                                  callback_data=f"{NET_CB_PREFIX}dg")],
            [InlineKeyboardButton("\u2699\uFE0F Network Settings",
                                  callback_data=f"{NET_CB_PREFIX}settings"),
             InlineKeyboardButton("\U0001F6E1\uFE0F Platform Control",
                                  callback_data="panel:control")],
            # b10 §8E (B10-B2): the admin bulk action — reapply the Main
            # Mini App link (menu button) to every ACTIVE registered bot
            # (state-changing: debounced via ^net:miniapp$ in state.py).
            [InlineKeyboardButton("\U0001F310 Apply Main App Link to All",
                                  callback_data=f"{NET_CB_PREFIX}miniapp")],
            [InlineKeyboardButton("\u2B05\uFE0F Main Panel",
                                  callback_data="panel:main")],
        ])
        q = getattr(update, "callback_query", None)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_net_stats(update, context) -> None:
        """\U0001F4CA Network Analytics (GAP-CLOSURE spec §8) — REAL
        aggregated metrics from the routing/delivery ledgers (never
        fabricated): routing attempts/successes/failures, fallback depth,
        per-bot distribution, global-link clicks, broadcast delivery
        outcomes, FloodWait counts and recent error reasons."""
        q = getattr(update, "callback_query", None)
        try:
            s = await db.network_analytics_summary(days=7)
        except Exception as exc:  # noqa: BLE001 — the panel always renders
            s = {"days": 7, "error": type(exc).__name__}
        rate = s.get("routing_success_rate")
        rate_txt = f"{int(rate * 100)}%" if rate is not None else "-"
        lines = [
            "\U0001F4CA Network Analytics (last 7 days)",
            "",
            f"Routing attempts: {s.get('routing_attempts', 0)}",
            f"Routed successfully: {s.get('routing_successes', 0)} "
            f"({rate_txt})",
            f"Routing failures: {s.get('routing_failures', 0)}",
            f"Max fallback depth: {s.get('max_fallback_depth', 0)}",
            f"Global Link clicks (total): "
            f"{s.get('global_link_clicks_total', 0)} across "
            f"{s.get('global_links', 0)} link(s)",
            f"Broadcast deliveries sent: "
            f"{s.get('broadcast_deliveries_sent', 0)}",
            f"FloodWait events: {s.get('floodwait_events', 0)}",
        ]
        top = s.get("top_bots") or []
        if top:
            lines.append("")
            lines.append("Payload distribution (top bots):")
            for t in top[:6]:
                lines.append(f"  @{t['username']} — {t['routed']} routed")
        errs = s.get("recent_errors") or []
        if errs:
            lines.append("")
            lines.append("Recent routing errors:")
            for e in errs[:6]:
                lines.append(f"  {e['count']}× {e['reason']}")
        bf = s.get("broadcast_failures") or []
        if bf:
            lines.append("")
            lines.append("Broadcast failure classes:")
            for e in bf[:6]:
                lines.append(f"  {e['count']}× {e['classification']}")
        if not top and not errs:
            lines.append("")
            lines.append("No routing activity recorded yet — metrics "
                         "appear as real traffic flows.")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F504 Refresh",
                                  callback_data=f"{NET_CB_PREFIX}stats")],
            [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                  callback_data=f"{NET_CB_PREFIX}main")],
        ])
        if q:
            await safe_edit_text(q, "\n".join(lines), reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\n".join(lines), reply_markup=kb)

    async def _render_net_bots(update, context) -> None:
        """BOT-11 (B11-B — spec §1): the admin Registered Bots list now
        shows the TRUTHFUL per-bot badge lines (management capability,
        Mini App apply state, Delivery readiness) from the v35 schema
        columns — never fabricated: NULL can_manage_bots renders ❓
        UNKNOWN, empty mini_app_last_apply_status renders ⚪ NOT APPLIED,
        and the Delivery-Group status comes straight from the DG row."""
        bots = await db.list_network_bots()
        # BOT-16: the admin "Registered Bots" list is the ACTIVE view —
        # the v37 repo default already excludes REMOVED rows (both the
        # terminal status and the legacy DISABLED+REMOVED shape); the
        # header says so and a collapsed hint notes the hidden removed
        # audit trail when one exists (the PDF page-2 leak: @imagedux_bot
        # still listed with Status: REMOVED).
        removed_hint = 0
        archived_lines: list = []
        try:
            _all_rows = await db.list_network_bots(include_removed=True)
            _removed_rows = [b for b in _all_rows if _is_removed_bot(b)]
            removed_hint = len(_removed_rows)
            # B17 FINAL VERIFICATION: a real ARCHIVED section (Phase 26 —
            # removed bots' history is browsable, not just a count). Each
            # archived row lists @username, registry id, owner and the
            # removal timestamp from the v37 removed_at audit column.
            for b in _removed_rows[:20]:
                ra = str(b.get("removed_at") or "unknown date")
                archived_lines.append(
                    f"  \u267B\uFE0F @{b.get('username') or '?'} — "
                    f"#{int(b.get('network_bot_id') or 0)} "
                    f"(owner={b.get('owner_user_id')}, removed {ra})")
        except Exception:  # noqa: BLE001 — hint is optional, never breaks
            removed_hint = 0
        if not bots:
            text = "\U0001F916 Registered Bots (active)\n\nNo bots registered yet."
            if archived_lines:
                text += ("\n\n\U0001F4E6 Archived (removed — terminal):\n"
                         + "\n".join(archived_lines))
        else:
            lines = ["\U0001F916 Registered Bots (active)", ""]
            for b in bots[:50]:
                icon = {"ACTIVE": "\U0001F7E2", "PENDING": "\u26A0\uFE0F",
                        "DEGRADED": "\U0001F7E1"}.get(str(b["status"]),
                                                      "\U0001F534")
                nid = int(b["network_bot_id"])
                health = str(b.get("health") or "UNKNOWN")
                lines.append(f"{icon} @{b['username']} — #{nid}")
                lines.append(f"    Status: {icon} {b['status']} "
                             f"(health: {health})")
                # Bot Management capability (spec §1): 1/0/NULL — truthful.
                try:
                    can_val = b.get("can_manage_bots")
                except Exception:  # noqa: BLE001 — pre-v35 row shape
                    can_val = None
                if can_val is None:
                    mgmt = "\u2753 UNKNOWN (use Refresh Bot Capabilities)"
                elif int(can_val) == 1:
                    mgmt = "\u2705 ENABLED"
                else:
                    mgmt = "\u26A0\uFE0F NOT ENABLED"
                lines.append(f"    Bot Management: {mgmt}")
                # Mini App apply state (spec §9/§10).
                ma_status = str(b.get("mini_app_last_apply_status") or "")
                lines.append("    Mini App: \u2705 CONFIGURED"
                             if ma_status == "applied" else
                             "    Mini App: \u26AA NOT APPLIED")
                # Delivery readiness (the authoritative DG row).
                try:
                    group = await db.get_delivery_group_for_bot(nid)
                except Exception:  # noqa: BLE001 — panel never breaks
                    group = None
                gs = str((group or {}).get("status") or "")
                lines.append("    Delivery: \u2705 READY" if gs == "DELIVERY_READY"
                             else "    Delivery: \u26A0\uFE0F SETUP REQUIRED")
                lines.append(f"    owner={b['owner_user_id']} "
                             f"caps={b.get('capabilities') or '-'}")
            if removed_hint:
                lines.append("")
                # B17 FINAL VERIFICATION: the Archived section (browsable
                # history) + the terminal-removal note.
                lines.append(f"\U0001F5D1 {removed_hint} removed bot(s) — "
                             "removal is terminal; full history below.")
                lines.append("\U0001F4E6 Archived (removed — terminal):")
                lines.extend(archived_lines or ["  (no archived rows)"])
            text = "\n".join(lines)
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F504 Refresh Bot Capabilities",
                                  callback_data=f"{NET_CB_PREFIX}caps"),
             InlineKeyboardButton("\U0001F504 Refresh",
                                  callback_data=f"{NET_CB_PREFIX}bots")],
            [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                  callback_data=f"{NET_CB_PREFIX}main")],
        ])
        await safe_edit_text(update.callback_query, text, reply_markup=kb)

    async def _render_net_health(update, context) -> None:
        bots = await db.list_network_bots()
        lines = ["\U0001F7E2 Bot Health", ""]
        if not bots:
            lines.append("No bots registered yet.")
        for b in bots[:50]:
            w = _net_workers.get(int(b["id"])) if _net_workers else None
            running = "running" if (w and w.running) else "stopped"
            lines.append(
                f"@{b['username']}: status={b['status']} health="
                f"{b.get('health') or 'UNKNOWN'} worker={running} "
                f"last_check={str(b.get('last_health_check') or '-')[:19]} "
                f"last_error={b.get('last_error_code') or '-'}")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F504 Refresh & Re-check",
                                  callback_data=f"{NET_CB_PREFIX}healthcheck")],
            [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                  callback_data=f"{NET_CB_PREFIX}main")],
        ])
        await safe_edit_text(update.callback_query, "\n".join(lines),
                             reply_markup=kb)

    async def _net_run_health_checks(update, context) -> None:
        """Manual health re-check: getChat probe per bot through its worker
        client (transient failures never flip to permanent invalid — §14)."""
        await safe_answer_callback(update.callback_query,
                                   "Health check running...")
        bots = await db.list_network_bots()
        for b in bots:
            nid = int(b["id"])
            # BOT-16: NEVER write health onto a REMOVED row — the repo
            # default already excludes them, this guard protects callers
            # that pass include_removed=True (a removed bot is terminal;
            # TEMPORARILY_UNAVAILABLE on a gone bot is the PDF page-2
            # evidence's health: TEMPORARILY_UNAVAILABLE).
            if _is_removed_bot(b):
                logger.info("NETWORK_BOT_HEALTH_SKIPPED network_bot_id=%s "
                            "reason=removed (no health writes onto a "
                            "REMOVED bot)", nid)
                continue
            client = _net_workers.get_bot_client(nid) if _net_workers else None
            if client is None:
                await db.update_network_bot_health(
                    nid, "TEMPORARILY_UNAVAILABLE",
                    error_code="WORKER_STOPPED")
                continue
            try:
                await client.get_me()
                await _net_registry.mark_health(nid, "HEALTHY")
            except Exception as exc:  # noqa: BLE001
                name = type(exc).__name__
                if "InvalidToken" in name or "Unauthorized" in str(exc):
                    await _net_registry.mark_token_invalid(nid)
                else:
                    await _net_registry.mark_health(
                        nid, "TEMPORARILY_UNAVAILABLE",
                        error_code=f"HEALTH_{name}")
        await _render_net_health(update, context)

    async def _net_refresh_capabilities(update, context) -> None:
        """BOT-11 (B11-B — spec §1): [🔄 Refresh Bot Capabilities] — getMe
        on every ACTIVE registered bot through the worker manager client;
        the truth from Telegram (can_manage_bots) is persisted via
        db.set_network_bot_capability (True→1/False→0). Bots without a running
        worker are marked UNKNOWN (NULL + checked_at=now) with the reason
        logged — NEVER a fabricated capability. The callback is debounced
        (^net:caps$ in state.py): a double-tap never runs the bulk twice."""
        q = update.callback_query
        await safe_answer_callback(
            q, "\u23F3 Refreshing bot capabilities (getMe per bot)...")
        bots = await db.list_network_bots()
        active = [b for b in bots if str(b.get("status")) == "ACTIVE"]
        logger.info("MANAGED_BOT_CAPABILITY_REFRESH start total=%s "
                    "active=%s (getMe can_manage_bots per bot)",
                    len(bots), len(active))
        set_cap = getattr(db, "set_network_bot_capability", None)
        for b in bots:
            nid = int(b["network_bot_id"])
            # BOT-16: NEVER write capability state onto a REMOVED row —
            # the repo default excludes them; this guard protects
            # include_removed=True callers (the PDF page-2 evidence:
            # "Bot Management: UNKNOWN (use Refresh Bot Capabilities)" on
            # a REMOVED bot, caused by exactly this write).
            if _is_removed_bot(b):
                logger.info("MANAGED_BOT_CAPABILITY_SKIPPED "
                            "network_bot_id=%s reason=removed (no "
                            "capability writes onto a REMOVED bot)", nid)
                continue
            if str(b.get("status")) != "ACTIVE":
                # No worker is expected for non-ACTIVE bots — honest NULL.
                if callable(set_cap):
                    await set_cap(nid, None)
                logger.info("MANAGED_BOT_CAPABILITY_RESULT "
                            "network_bot_id=%s can=None "
                            "reason=not_active (status=%s)",
                            nid, b.get("status"))
                continue
            client = _net_workers.get_bot_client(nid) if _net_workers else None
            if client is None:
                if callable(set_cap):
                    await set_cap(nid, None)
                logger.info("MANAGED_BOT_CAPABILITY_RESULT "
                            "network_bot_id=%s can=None "
                            "reason=no_running_worker", nid)
                continue
            try:
                me = await client.get_me()
            except Exception as exc:  # noqa: BLE001 — honest unknown, never fabricated
                if callable(set_cap):
                    await set_cap(nid, None)
                logger.warning("MANAGED_BOT_CAPABILITY_RESULT "
                               "network_bot_id=%s can=None reason=getMe_"
                               "failed detail=%s", nid, type(exc).__name__)
                continue
            can = getattr(me, "can_manage_bots", None)
            if callable(set_cap):
                await set_cap(nid, None if can is None else bool(can))
            logger.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                        "can=%s", nid,
                        "None" if can is None else ("True" if can else "False"))
        await _render_net_bots(update, context)

    async def _render_net_points_settings(update, context) -> None:
        enabled = await db.get_setting_bool(NET_SETTING_POINTS_ACCESS, True)
        cost = await db.get_setting_int(NET_SETTING_POINT_COST,
                                        NET_DEFAULT_POINT_COST)
        ppb = await db.get_setting_int(NET_SETTING_POINTS_PER_BOT,
                                       NET_DEFAULT_POINTS_PER_BOT)
        maxb = await db.get_setting_int(NET_SETTING_MAX_BOTS,
                                        NET_DEFAULT_MAX_BOTS)
        maxr = await db.get_setting_int(NET_SETTING_MAX_REWARD,
                                        maxb * ppb)
        totals = await db.points_totals()
        text = (
            "\u2B50 Points Settings\n\n"
            f"Point access: {'ON' if enabled else 'OFF'}\n"
            f"Cost per payload unlock: {cost}\n"
            f"Reward per verified bot registration: +{ppb}\n"
            f"Max registered bots per user: {maxb}\n"
            f"Max registration reward per user: {maxr}\n\n"
            f"Network totals — awarded: {totals['awarded']}, "
            f"spent: {totals['spent']}\n\n"
            "\u2139\uFE0F Changing settings never rewrites the ledger "
            "(history is append-only)."
        )
        rows = [[InlineKeyboardButton(
            "\U0001F7E2 Disable Point Access" if enabled else
            "\U0001F534 Enable Point Access",
            callback_data=f"{NET_CB_PREFIX}pttoggle")]]
        rows.append([InlineKeyboardButton(
            f"Cost: {cost} \u2192 {cost + 1}",
            callback_data=f"{NET_CB_PREFIX}ptcostup")])
        rows.append([InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                          callback_data=f"{NET_CB_PREFIX}main")])
        await safe_edit_text(update.callback_query, text,
                             reply_markup=InlineKeyboardMarkup(rows))

    async def _render_net_links(update, context) -> None:
        links = await db.list_global_payload_links(limit=20)
        lines = ["\U0001F517 Global Payload Links", ""]
        if not links:
            lines.append("No global links created yet.\nUse the Payload "
                         "Manager → Global Link on any payload — or the "
                         "Create button below.")
        for l in links[:20]:
            status = "\U0001F7E2" if int(l["active"] or 0) else "\u274C"
            lines.append(f"{status} {l['public_code']} → payload "
                         f"{l['payload_id']} (clicks: {l['clicks']})")
        # Signing-key diagnostic (spec §3 — the booleans only, never the key):
        signing_ok = bool(getattr(_net_links, "uses_dedicated_key", False))
        lines.append("")
        lines.append(("\u2705 Signing key configured — new links can be "
                       "created." if signing_ok else
                       "\u26A0\uFE0F NETWORK_GLOBAL_LINK_SIGNING_KEY not "
                       "configured — creating new links is refused "
                       "(existing links keep verifying)."))
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2795 Create Global Link",
                                  callback_data=f"{NET_CB_PREFIX}links:new")],
            [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                  callback_data=f"{NET_CB_PREFIX}main")],
        ])
        await safe_edit_text(update.callback_query, "\n".join(lines),
                             reply_markup=kb)

    async def _render_net_settings(update, context) -> None:
        enabled = await network_enabled()
        maxb = await db.get_setting_int(NET_SETTING_MAX_BOTS,
                                        NET_DEFAULT_MAX_BOTS)
        rate = await db.get_setting_int(NET_SETTING_BCAST_RATE, 25)
        confirm = await db.get_setting_int(NET_SETTING_BCAST_CONFIRM, 1000)
        text = (
            "\u2699\uFE0F Network Settings\n\n"
            f"Network: {'ENABLED' if enabled else 'DISABLED'}\n"
            f"Max registered bots per user: {maxb}\n"
            f"Broadcast rate per bot: {rate} msg/s\n"
            f"Large-broadcast confirmation threshold: {confirm} users\n\n"
            "\u2139\uFE0F Workers restart automatically after server restart."
        )
        rows = [[InlineKeyboardButton(
            "\U0001F7E2 Disable Network" if enabled else "\U0001F534 Enable Network",
            callback_data=f"{NET_CB_PREFIX}toggle")]]
        rows.append([InlineKeyboardButton(
            f"Max bots: {maxb} \u2192 {maxb + 1 if maxb < 50 else 50}",
            callback_data=f"{NET_CB_PREFIX}maxup")])
        rows.append([InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                          callback_data=f"{NET_CB_PREFIX}main")])
        await safe_edit_text(update.callback_query, text,
                             reply_markup=InlineKeyboardMarkup(rows))

    async def _render_broadcast_center(update, context) -> None:
        bcasts = await db.list_broadcasts(limit=15)
        lines = ["\U0001F4E2 Network Broadcast Center", ""]
        if not bcasts:
            lines.append("No network broadcasts yet.")
        for b in bcasts:
            icon = {"RUNNING": "\u25B6\uFE0F", "PENDING": "\u23F3",
                    "PAUSED": "\u23F8", "COMPLETED": "\u2705",
                    "CANCELLED": "\u274C", "FAILED": "\u26A0\uFE0F"}.get(
                str(b["status"]), "\u2753")
            lines.append(f"{icon} #{b['id']} {b['method']} — {b['status']}")
        lines.append("")
        lines.append("\u2795 New Broadcast options:")
        kb_rows = [
            [InlineKeyboardButton("\U0001F4DD Text",
                                  callback_data=f"{NET_BCAST_CB}new:TEXT"),
             InlineKeyboardButton("\U0001F4CB Copy Message",
                                  callback_data=f"{NET_BCAST_CB}new:COPY")],
            [InlineKeyboardButton("\u21AA\uFE0F Forward",
                                  callback_data=f"{NET_BCAST_CB}new:FORWARD"),
             InlineKeyboardButton("\U0001F3A5 Payload Announcement",
                                  callback_data=f"{NET_BCAST_CB}new:PAYLOAD_ANNOUNCEMENT")],
            [InlineKeyboardButton("\u23F3 Active Jobs",
                                  callback_data=f"{NET_BCAST_CB}jobs"),
             InlineKeyboardButton("\U0001F4DC History",
                                  callback_data=f"{NET_BCAST_CB}main")],
            [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                  callback_data=f"{NET_CB_PREFIX}main")],
        ]
        await safe_edit_text(update.callback_query, "\n".join(lines),
                             reply_markup=InlineKeyboardMarkup(kb_rows))

    async def _render_bcast_new(update, context, method: str) -> None:
        """Wizard step 1: describe the method + ask for the source/text."""
        _bcast_state = context.user_data.setdefault("net_bcast_state", {})
        _bcast_state["step"] = "await_content"
        _bcast_state["method"] = method
        guide = {
            "TEXT": "Send the TEXT message to broadcast now.",
            "COPY": ("Forward a message from your storage channel now — it "
                     "will be COPIED (clean, no source attribution) to every "
                     "reachable user through every eligible bot."),
            "FORWARD": ("Forward a message now — it will be FORWARDED "
                        "(Telegram shows the original source) exactly as-is."),
            "PAYLOAD_ANNOUNCEMENT": ("Send the payload NAME (e.g. the payload "
                                     "slug) to announce. Users get a poster "
                                     "message with a Global Payload Link "
                                     "button — never the giant files."),
        }.get(method, "Send the broadcast content now.")
        text = (f"\U0001F4E2 New Broadcast — {method}\n\n{guide}\n\n"
                "\u2B05\uFE0F Cancel with the button below.")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u274C Cancel",
                                  callback_data=f"{NET_BCAST_CB}main")]])
        await safe_edit_text(update.callback_query, text, reply_markup=kb)

    async def handle_network_broadcast_text(update, context, user, text) -> None:
        """Wizard content input for TEXT broadcasts (spec §27 method TEXT)."""
        state = context.user_data.get("net_bcast_state") or {}
        if str(state.get("step")) != "await_content":
            return
        method = str(state.get("method") or "TEXT")
        if method == "TEXT":
            state["text"] = text.strip()[:4000]
            await _render_bcast_preview(update, context)
        elif method == "PAYLOAD_ANNOUNCEMENT":
            payload_row = await db.get_payload(text.strip().lower())
            if not payload_row:
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u274C Payload not found. Send the exact payload name "
                    "(slug), or cancel below.")
                return
            state["payload_id"] = int(payload_row["id"])
            await _render_bcast_preview(update, context)
        else:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u26A0\uFE0F For Copy/Forward broadcasts use the Forward "
                "button flow (forward a message from the storage channel). "
                "Text input is used for TEXT and Payload Announcement methods.")

    async def _render_bcast_preview(update, context) -> None:
        """Broadcast preview (spec §44): audience + method + explicit start."""
        state = context.user_data.get("net_bcast_state") or {}
        method = str(state.get("method") or "TEXT")
        bots = await db.list_network_bots()
        eligible = [b for b in bots if str(b["status"]) in ("ACTIVE", "DEGRADED")
                    and int(b.get("enabled") or 0) == 1]
        reachable = await db.count_reachable_users(
            [int(b["id"]) for b in eligible] or None)
        body = ""
        if method == "TEXT":
            body = str(state.get("text") or "")[:600]
        elif method == "PAYLOAD_ANNOUNCEMENT":
            pid = int(state.get("payload_id") or 0)
            row = await db.get_payload_by_id(pid) if pid else None
            body = (f"\U0001F3A5 NEW PAYLOAD AVAILABLE\n\n"
                    f"{get_payload_display_name(row['payload'], display_name=_safe_row_get(row, 'display_name')) if row else '?'}\n\n"
                    "\U0001F525 Watch now — button: Global Payload Link") \
                if row else "?"
        confirm_threshold = await db.get_setting_int(NET_SETTING_BCAST_CONFIRM,
                                                     1000)
        text = (
            "\U0001F4E2 Broadcast Preview\n\n"
            f"{body}\n\n"
            "\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\n"
            f"Method: {method}\n"
            f"Active bots: {len(eligible)}\n"
            f"Reachable users: {reachable}\n"
        )
        if reachable >= confirm_threshold:
            text += ("\n\u26A0\uFE0F LARGE NETWORK BROADCAST — explicit "
                     "confirmation required.")
        kb_rows = [
            [InlineKeyboardButton("\U0001F680 Start Broadcast",
                                  callback_data=f"{NET_BCAST_CB}start")],
            [InlineKeyboardButton("\u274C Cancel",
                                  callback_data=f"{NET_BCAST_CB}cancel")],
        ]
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             reply_markup=InlineKeyboardMarkup(kb_rows))

    async def _net_broadcast_start(update, context) -> None:
        """Create the durable broadcast + start the engine (spec §38/§39)."""
        user = update.effective_user
        state = context.user_data.get("net_bcast_state") or {}
        method = str(state.get("method") or "TEXT")
        created = await _net_broadcast.create_broadcast(
            method=method, created_by=int(user.id),
            text=state.get("text"),
            source_chat_id=state.get("source_chat_id"),
            source_message_ids=state.get("source_message_ids"),
            payload_id=state.get("payload_id"),
            target_mode="ALL_BOTS")
        context.user_data.pop("net_bcast_state", None)
        started = await _net_broadcast.start(int(created["broadcast_id"]))
        await safe_edit_text(
            update.callback_query,
            f"\U0001F680 Broadcast #{created['broadcast_id']} started.\n\n"
            f"Bots: {created['bot_count']}\nUsers: {created['user_count']}\n\n"
            "Progress is DURABLE — it resumes automatically after any restart. "
            "Statistics are available in the Broadcast Center.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4E2 Broadcast Center",
                                      callback_data=f"{NET_BCAST_CB}main")]]))

    async def _render_bcast_jobs(update, context) -> None:
        running = await db.list_broadcast_ids_by_status("RUNNING")
        paused = await db.list_broadcast_ids_by_status("PAUSED")
        lines = ["\u23F3 Active Broadcast Jobs", ""]
        if not running and not paused:
            lines.append("No active jobs.")
        for bid in (running + paused)[:20]:
            stats = await db.broadcast_stats(int(bid))
            pct = (100 * stats["sent"] // stats["total"]) if stats["total"] else 0
            lines.append(f"#{bid}: {stats['sent']}/{stats['total']} sent "
                         f"({pct}%) failed={stats['failed']} "
                         f"blocked={stats['blocked']}")
        kb_rows = []
        for bid in (running + paused)[:5]:
            kb_rows.append([
                InlineKeyboardButton(f"#{bid} \u23F8 Pause",
                                     callback_data=f"{NET_BCAST_CB}pause:{bid}"),
                InlineKeyboardButton(f"#{bid} \u274C Cancel",
                                     callback_data=f"{NET_BCAST_CB}cancel:{bid}"),
            ])
        kb_rows.append([InlineKeyboardButton("\u2B05\uFE0F Broadcast Center",
                                             callback_data=f"{NET_BCAST_CB}main")])
        await safe_edit_text(update.callback_query, "\n".join(lines),
                             reply_markup=InlineKeyboardMarkup(kb_rows))

    def _bcast_source_ids(brow) -> List[int]:
        """Parse the broadcast's durable central source message ids (JSON)."""
        try:
            raw = json.loads(brow.get("source_message_ids") or "[]")
            return [int(x) for x in raw if int(x) > 0]
        except Exception:  # noqa: BLE001
            return []

    async def _net_broadcast_send_one(bot, method: str, brow, target_user_id: int
                                      ) -> Dict[str, Any]:
        """The per-user send implementation (spec §27/§28/§29/§30).

        Copy/Forward semantics are EXPLICIT per job — never silently changed.
        Media transports use the NATIVE Telegram operations (copy_message /
        forward_message of the central source message) through the SERVING
        bot — no cross-bot file_id reuse, no downloads."""
        kw: Dict[str, Any] = {}
        try:
            if int(brow.get("protect_content") or 0):
                kw["protect_content"] = True
        except Exception:  # noqa: BLE001
            pass
        try:
            if method == "TEXT":
                msg = await bot.send_message(int(target_user_id),
                                             str(brow.get("text_content")
                                                 or "Broadcast"), **kw)
                return {"ok": True, "message_id": msg.message_id, "error": None}
            if method == "COPY":
                ids = _bcast_source_ids(brow)
                msg = await bot.copy_message(
                    int(target_user_id), int(brow["source_chat_id"]),
                    int(ids[0]), **kw)
                return {"ok": True, "message_id": msg.message_id, "error": None}
            if method == "FORWARD":
                ids = _bcast_source_ids(brow)
                msg = await bot.forward_message(
                    int(target_user_id), int(brow["source_chat_id"]),
                    int(ids[0]), **kw)
                return {"ok": True, "message_id": msg.message_id, "error": None}
            if method == "PAYLOAD_ANNOUNCEMENT":
                pid = int(brow.get("payload_id") or 0)
                prow = await db.get_payload_by_id(pid) if pid else None
                if not prow:
                    return {"ok": False, "message_id": None,
                            "error": None,
                            "classification": "SOURCE_UNAVAILABLE"}
                # Poster + title + Global Payload Link button (spec §36/§67).
                # GAP-CLOSURE spec §5: the button uses the STABLE MAIN-BOT
                # front door (the resolver picks a healthy worker at click
                # time) — never a baked-in worker username.
                glink = (await db.get_global_links_for_payload(pid)
                         or [None])[0]
                link_url = None
                if glink and int(glink["active"] or 0):
                    if BOT_USERNAME:
                        link_url = (f"https://t.me/{BOT_USERNAME}?start="
                                    f"g{glink['public_code']}")
                title = get_payload_display_name(
                    prow["payload"],
                    display_name=_safe_row_get(prow, "display_name"))
                kb = InlineKeyboardMarkup([[
                    InlineKeyboardButton("\u25B6\uFE0F WATCH NOW", url=link_url)
                ]]) if link_url else None
                text = (f"\U0001F3A5 NEW PAYLOAD AVAILABLE\n\n"
                        f"{title}\n\n"
                        f"\U0001F525 Watch now")
                msg = await bot.send_message(int(target_user_id), text,
                                             reply_markup=kb, **kw)
                return {"ok": True, "message_id": msg.message_id, "error": None}
            # COPY_MULTI / FORWARD_MULTI / media types: send each source id.
            ids = _bcast_source_ids(brow)
            if not ids:
                # TEXT fallback content.
                msg = await bot.send_message(
                    int(target_user_id),
                    str(brow.get("text_content") or "Broadcast"), **kw)
                return {"ok": True, "message_id": msg.message_id, "error": None}
            last_mid = None
            for mid in ids[:10]:
                if method.startswith("FORWARD"):
                    msg = await bot.forward_message(
                        int(target_user_id), int(brow["source_chat_id"]),
                        int(mid), **kw)
                else:
                    msg = await bot.copy_message(
                        int(target_user_id), int(brow["source_chat_id"]),
                        int(mid), **kw)
                last_mid = getattr(msg, "message_id", None)
            return {"ok": True, "message_id": last_mid, "error": None}
        except Exception as exc:  # noqa: BLE001 — classify per spec §42
            cls, _retry = _net_classify_send_error(exc)
            return {"ok": False, "message_id": None, "error": exc,
                    "classification": cls}

    async def _handle_net_points_callback(update, context, user, arg: str) -> None:
        """My Points + history (spec §65). The ledger is authoritative."""
        q = update.callback_query
        balance = await db.points_balance(int(user.id))
        history = await db.points_history(int(user.id), limit=15)
        lines = [f"\u2B50 Points: {balance}", "", "History:"]
        if not history:
            lines.append("(no activity yet)")
        label = {"BOT_REGISTERED": "Bot registered",
                 "PAYLOAD_UNLOCK": "Payload unlock",
                 "ADMIN_CREDIT": "Admin credit",
                 "ADMIN_DEBIT": "Admin debit"}
        for h in history:
            amt = int(h["amount"])
            sign = "+" if amt > 0 else "-"
            when = str(h["created_at"] or "")[:16].replace("T", " ")
            lines.append(f"{sign}{abs(amt)} {label.get(str(h['event_type']), str(h['event_type']))} — {when}")
        lines.append("")
        lines.append("\U0001F4E1 Register bots in My Network to earn +5 each.")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\U0001F310 My Network",
                                  callback_data=f"{NET_REG_CB}back")],
        ])
        await safe_edit_text(q, "\n".join(lines), reply_markup=kb)

    async def _handle_net_reg_callback(update, context, user, arg: str) -> None:
        """Registration wizard navigation (spec §2/§57)."""
        q = update.callback_query
        if arg == "start":
            await _render_net_reg_start(update, context, user)
            return
        if arg == "token":
            # Render FIRST: _render_net_reg_token opens the input by
            # clearing every OTHER conversation-input state (the v36
            # single-active-conversation discipline) — arming THIS
            # wizard's state before that call would purge it
            # immediately (the exact bot-10.log §1 failure shape).
            await _render_net_reg_token(update, context)
            context.user_data[_NET_REG_STATE_KEY] = stamp_conversation_state(
                {"step": "await_token"})
            # b10 §1 (B10-B2): arm the DURABLE token-input intent — it
            # survives the v36 navigation purge that killed the wizard
            # state (the bot-10.log root cause). The prompt location is
            # recorded for the best-effort stale-prompt cleanup. NEVER
            # token material. BOT_TOKEN_INPUT_STARTED is logged here.
            set_pending_token_intent(
                int(user.id), "net_reg",
                chat_id=(getattr(update.effective_chat, "id", None)
                         if getattr(update, "effective_chat", None)
                         else None),
                message_id=(getattr(getattr(update, "callback_query",
                                            None), "message", None)
                            and getattr(update.callback_query.message,
                                       "message_id", None)))
            return
        if arg == "consent":
            await _net_complete_registration(update, context, user)
            return
        if arg == "reactivate":
            # BOT-11 (B11-B — spec §5-§7): the duplicate-bot recovery
            # confirmation (the token lives SERVER-SIDE in net_reg_state).
            await _net_reg_reactivate(update, context, user)
            return
        if arg == "changeconfirm":
            # BOT-11 §6 (B11-D2): [Yes, Replace Identity] — apply the held
            # change-token with the CONFIRMED new bot identity.
            await _net_change_confirm(update, context, user)
            return
        if arg == "changecancel":
            # BOT-11 §6: [Cancel] — purge the change-token flow honestly.
            await _net_change_cancel(update, context, user)
            return
        if arg == "how":
            await safe_edit_text(
                q,
                "\U0001F310 How the Network Works\n\n"
                "\u2795 Register Telegram bots you OWN (+5 points each, max 5)\n"
                "\U0001F916 Every registered bot serves the SAME payloads with "
                "the SAME rules\n"
                "\U0001F517 Global Payload Links work from ANY network bot\n"
                "\u2B50 Points unlock payloads instantly (alternative to ads / "
                "referrals)\n"
                "\U0001F4E2 Broadcasts reach users through every eligible bot\n\n"
                "\U0001F512 Your bot token is stored encrypted, never shown "
                "again, and revocable anytime.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\u2B05\uFE0F Back",
                                          callback_data=f"{NET_REG_CB}back")]]))
            return
        # back / anything else -> My Network
        # b10 §1: Back/Cancel is one of the ONLY intent-clearing events
        # (explicit exit of this flow) — the stale prompt is marked.
        await _net_reg_cancel(update, context, user)
        await _render_my_network(update, context, user)

    async def _handle_net_bot_callback(update, context, user, arg: str) -> None:
        """My registered bots management (spec §58/§63/§64).

        b10 §5: a REMOVED bot is GONE — every stale action on it (view /
        enable / disable / remove / replace, typically from a rendered
        panel that predates the removal) answers truthfully and
        re-renders My Network; a repeated remove is idempotent."""
        q = update.callback_query
        parts = arg.split(":")
        if not parts or not parts[0]:
            await _render_my_network(update, context, user)
            return
        try:
            nid = int(parts[0])
        except ValueError:
            await safe_answer_callback(q, "Invalid request.", show_alert=True)
            return
        bot_row = await db.get_network_bot(nid)
        if not bot_row:
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        # Ownership check (spec §63: users manage their OWN bots only).
        if int(bot_row["owner_user_id"]) != int(user.id) \
                and not await is_admin(user.id):
            await safe_answer_callback(
                q, "You can only manage your own bots.", show_alert=True)
            return
        action = parts[1] if len(parts) > 1 else "view"
        # b10 §5: stale callbacks on a REMOVED bot (the bot-10.log showed
        # `nbot:1` still opening and `nbot:1:enable` "succeeding" AFTER
        # NETWORK_BOT_REMOVED). The removed row (new REMOVED status or
        # the legacy DISABLED+REMOVED shape) is gone for every action.
        if _is_removed_bot(bot_row):
            if action == "remove":
                # Idempotent: no registry re-run, no second
                # NETWORK_BOT_REMOVED (bot-10.log showed it 4×).
                logger.info("NETWORK_BOT_REMOVE_IDEMPOTENT "
                            "network_bot_id=%s user_id=%s", nid, user.id)
                await safe_answer_callback(q, "Bot already removed.")
                await _render_my_network(update, context, user)
                return
            logger.info("NETWORK_BOT_STALE_CALLBACK network_bot_id=%s "
                        "action=%s user_id=%s", nid, action, user.id)
            await safe_answer_callback(
                q, "This Network Bot was removed. Register it again "
                   "to use it.", show_alert=True)
            await _render_my_network(update, context, user)
            return
        # FILE DELIVERY v34 (spec §30/§31/§64 — NON-NEGOTIABLE):
        # platform-managed bots cannot be removed by the owner. Backend
        # enforcement — NOT just hidden buttons.
        managed = str(bot_row.get("management_mode")) == "PLATFORM_MANAGED"
        if action == "changetoken":
            # BOT-11 §6 (B11-D2): the change-token window for a USER-OWNED
            # registered bot (managed bots use the admin Replace flow).
            if managed:
                await safe_answer_callback(
                    q, "Managed bots use the admin token-replacement flow.",
                    show_alert=True)
                return
            await _net_change_token_prompt(update, context, nid)
            return
        if action == "remove":
            if managed:
                logger.warning(
                    "MANAGED_BOT_DEREGISTER_REJECTED network_bot_id=%s "
                    "user_id=%s (platform-managed)", nid, user.id)
                await safe_answer_callback(
                    q, "This Network Bot is managed by the Payload Network. "
                       "It cannot be deregistered from the network by "
                       "the owner.", show_alert=True)
                return
            # Remove: stop worker + revoke credential + REMOVED status
            # (b10 §5: distinct terminal status; history kept; the
            # registry itself is idempotent-safe for racing taps).
            # BOT-16: the worker STOP is passed INTO the registry
            # orchestrator as a callable (atomic-ish ordering + honest
            # MANAGED_BOT_WORKER_STOPPED/STOP_FAILED logs) so no future
            # caller can forget it — removal retires every side-effect
            # (enabled, memberships, targeted links, capability state,
            # removed_at) in one place.
            _stop_fn = ((lambda n: _net_workers.stop_worker(n))
                        if _net_workers is not None else None)
            rem = await _net_registry.remove_bot(nid, stop_worker=_stop_fn)
            if not (isinstance(rem, dict) and rem.get("already")):
                logger.info("NETWORK_BOT_REMOVED network_bot_id=%s "
                            "by_user=%s", nid, user.id)
            await safe_answer_callback(q, "Bot removed. History preserved.")
            await _render_my_network(update, context, user)
            return
        if action == "disable":
            if _net_workers is not None:
                await _net_workers.stop_worker(nid)
            await _net_registry.disable_bot(nid)
            await safe_answer_callback(q, "Bot disabled.")
            await _render_my_network(update, context, user)
            return
        if action == "enable":
            # Re-enable requires the credential (removed bots cannot re-enable
            # without re-registration — spec §58 're-enable where possible').
            cred = await db.get_network_bot_credential(nid)
            if not cred:
                await safe_answer_callback(
                    q, "Credential revoked — please register the bot again.",
                    show_alert=True)
                return
            await _net_registry.enable_bot(nid)
            try:
                token = _net_registry.decrypt_credential(cred["encrypted_token"])
                worker = await _net_workers.start_worker(
                    nid, int(bot_row["telegram_bot_id"]),
                    str(bot_row["username"] or ""), token)
                if worker is not None:
                    await _net_registry.mark_active(nid)
            except Exception as exc:  # noqa: BLE001
                logger.warning("re-enable worker start failed bot=%s: %s", nid, exc)
            await safe_answer_callback(q, "Bot re-enabled.")
            await _render_my_network(update, context, user)
            return
        # MANAGED BOTS v37 (Task 8): admin-only managed token replacement
        # for PLATFORM_MANAGED bots with a stored credential — the
        # ownership check above already passed (owner OR admin); replace
        # additionally requires the ADMIN role.
        if action == "replace":
            if not await is_admin(user.id):
                logger.info(
                    "MANAGED_BOT_TOKEN_REPLACE_REJECTED network_bot_id=%s "
                    "user_id=%s reason=admin_only", nid, user.id)
                await safe_answer_callback(q, "Admins only.",
                                           show_alert=True)
                return
            from app.presentation.telegram import runtime as _rt
            await _rt.replace_managed_bot_token(update, context, nid,
                                                int(user.id))
            return
        # view: bot detail
        group = await db.get_delivery_group_for_bot(nid)
        gs = str((group or {}).get("status") or "DELIVERY_SETUP_REQUIRED")
        # Q5/Q18: truthful worker status (DB row + live worker manager).
        worker_running = bool(
            _net_workers is not None and _net_workers.get(nid) is not None
            and _net_workers.get(nid).running)
        worker_line = ("\U0001F6E1 Worker: \U0001F7E2 running"
                       if worker_running else
                       "\U0001F6E1 Worker: \u26A0\uFE0F not running")
        if not worker_running and str(bot_row["status"]) == "TOKEN_INVALID":
            err = str(bot_row.get("last_error_code") or "TOKEN_INVALID")
            worker_line += f" (reason: {err})"
        last_err = str(bot_row.get("last_error_code") or "") or ""
        lines = [
            f"\U0001F916 @{bot_row['username']}",
            f"Status: {bot_row['status']}" + (
                f" ({last_err})" if last_err and str(bot_row["status"]) not in
                ("ACTIVE",) else ""),
            f"Health: {bot_row.get('health') or 'UNKNOWN'}",
            worker_line,
            f"Registered: {str(bot_row['created_at'] or '')[:19]}",
            ("Management: Platform Managed\nCredential: \U0001F510 Protected"
             if managed else
             f"Capabilities: {bot_row.get('capabilities') or '-'}"),
            "Delivery: \u2705 Channel-Only (V25 \u00A71)",
        ]
        kb_rows = []
        # V25 §1: delivery is CHANNEL-ONLY — the per-bot panel is shown
        # unconditionally (no group state gate, no setup entry).
        kb_rows.append([InlineKeyboardButton(
            "\U0001F4C1 Delivery (Channel-Only)",
            callback_data=f"{NET_DG_CB}bot:{nid}")])
        # A token-invalid bot the user can repair by re-registering it
        # (user-owned) — honest, actionable, never fabricated.
        if str(bot_row["status"]) == "TOKEN_INVALID" and not managed:
            kb_rows.append([InlineKeyboardButton(
                "\U0001F511 Re-register this bot",
                callback_data=f"{NET_REG_CB}start")])
        if str(bot_row["status"]) == "ACTIVE":
            kb_rows.append([InlineKeyboardButton(
                "\u23F8 Disable", callback_data=f"{NET_BOT_CB}{nid}:disable")])
        elif str(bot_row["status"]) in ("DISABLED",):
            kb_rows.append([InlineKeyboardButton(
                "\u25B6\uFE0F Re-enable",
                callback_data=f"{NET_BOT_CB}{nid}:enable")])
        # BOT-11 §6: Change Token on a USER-OWNED registered bot (the
        # validation-before-replace flow; managed bots keep the admin
        # Replace Managed Bot Token button below).
        if not managed:
            kb_rows.append([InlineKeyboardButton(
                "\U0001F511 Change Token",
                callback_data=f"{NET_BOT_CB}{nid}:changetoken")])
        # Platform-managed: NO Remove button for the owner (spec §31) —
        # the backend rejects the action anyway; the button never appears.
        if not managed:
            kb_rows.append([InlineKeyboardButton(
                "\u274C Remove Bot", callback_data=f"{NET_BOT_CB}{nid}:remove")])
        # MANAGED BOTS v37 (Task 8): ADMIN-only managed token replacement
        # (PLATFORM_MANAGED bots with a stored credential — the backend
        # re-checks both; the owner never sees this button).
        if managed and await is_admin(user.id):
            _mcred = await db.get_network_bot_credential(nid)
            if _mcred:
                kb_rows.append([InlineKeyboardButton(
                    "\U0001F501 Replace Managed Bot Token",
                    callback_data=f"{NET_BOT_CB}{nid}:replace")])
        kb_rows.append([InlineKeyboardButton(
            "\u2B05\uFE0F My Network", callback_data=f"{NET_REG_CB}back")])
        await safe_edit_text(q, "\n".join(lines),
                             reply_markup=InlineKeyboardMarkup(kb_rows))

    async def _handle_net_admin_callback(update, context, arg: str) -> None:
        """Admin Network Control Center views (spec §43/§63)."""
        if arg in ("", "main"):
            await render_network_control(update, context)
            return
        if arg == "miniapp":
            # b10 §8E (B10-B2): "Apply Main App Link to All Registered
            # Bots" — iterate every ACTIVE network bot and reapply the
            # canonical Main Mini App menu button (best-effort per bot,
            # truthful per-bot outcomes, audit event, summary panel).
            q = update.callback_query
            await safe_answer_callback(
                q, "\u23F3 Applying the Main App link to all registered "
                   "bots...")
            from app.presentation.telegram import runtime as _rt_ma
            try:
                summary = await _rt_ma._net_apply_main_app_link_all()
            except Exception:  # noqa: BLE001 — honest failure panel
                summary = {"url": "", "total": 0, "applied": 0,
                           "skipped": 0, "failed": 0, "offline": 0,
                           "outcomes": [],
                           "reason": "action_failed"}
            url = str(summary.get("url") or "")
            if not url:
                await safe_edit_text(
                    q,
                    "\U0001F310 MAIN MINI APP LINK\n\n\u26A0\uFE0F The "
                    "canonical Main Mini App URL is not configured (or "
                    "is not HTTPS).\n\nSet the public Website base URL "
                    "(website_public_base_url) first — an https:// URL. "
                    "Nothing was applied.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                              callback_data=(f"{NET_CB_PREFIX}"
                                                             "main"))]]))
                return
            lines = [
                "\U0001F310 MAIN MINI APP LINK — APPLY TO ALL",
                "",
                f"Canonical URL: {url}",
                f"Bots processed: {int(summary.get('total') or 0)}",
                f"\u2705 Applied: {int(summary.get('applied') or 0)}",
                f"\u23ED Preserved (policy): {int(summary.get('skipped') or 0)}",
                f"\U0001F4A4 Offline (worker not running): "
                f"{int(summary.get('offline') or 0)}",
                f"\u274C Failed: {int(summary.get('failed') or 0)}",
                "",
            ]
            for o in (summary.get("outcomes") or [])[:25]:
                icon = {"applied": "\u2705", "skipped_preserve": "\u23ED",
                        "skipped_no_client": "\U0001F4A4"}.get(
                            str(o.get("outcome")), "\u274C")
                lines.append(f"{icon} @{o.get('username')} "
                             f"(#{o.get('network_bot_id')}): "
                             f"{o.get('outcome')}")
            if not (summary.get("outcomes") or []):
                lines.append("(no ACTIVE registered bots)")
            lines.append("")
            lines.append("The menu button is also (re)applied "
                         "automatically on every bot start (mode: auto "
                         "— configurable via the "
                         "network_bots_menu_button_mode setting).")
            try:
                await db.insert_control_audit_event(
                    "NETWORK_BOTS_MAINAPP_APPLIED",
                    actor_user_id=int(getattr(
                        getattr(update, "effective_user", None), "id", 0)
                        or 0),
                    detail=(f"url={url} applied={summary.get('applied')} "
                            f"total={summary.get('total')} "
                            f"failed={summary.get('failed')}"))
            except Exception:  # noqa: BLE001 — audit is best-effort
                pass
            await safe_edit_text(
                q, "\n".join(lines),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F504 Apply Again",
                                          callback_data=(f"{NET_CB_PREFIX}"
                                                         "miniapp"))],
                    [InlineKeyboardButton("\u2B05\uFE0F Network Control",
                                          callback_data=(f"{NET_CB_PREFIX}"
                                                         "main"))]]))
            return
        if arg == "bots":
            await _render_net_bots(update, context)
            return
        if arg == "caps":
            # BOT-11 (B11-B — spec §1): refresh the persisted per-bot
            # management capability (getMe.can_manage_bots) on every
            # registered bot through the worker manager clients.
            await _net_refresh_capabilities(update, context)
            return
        if arg == "health":
            await _render_net_health(update, context)
            return
        if arg == "healthcheck":
            await _net_run_health_checks(update, context)
            return
        if arg == "points":
            await _render_net_points_settings(update, context)
            return
        if arg == "pttoggle":
            cur = await db.get_setting_bool(NET_SETTING_POINTS_ACCESS, True)
            await db.set_setting(NET_SETTING_POINTS_ACCESS,
                                 "0" if cur else "1")
            logger.info("NETWORK_SETTING points_access=%s (admin)",
                        "OFF" if cur else "ON")
            await _render_net_points_settings(update, context)
            return
        if arg == "ptcostup":
            cost = await db.get_setting_int(NET_SETTING_POINT_COST,
                                            NET_DEFAULT_POINT_COST)
            await db.set_setting(NET_SETTING_POINT_COST, str(min(50, cost + 1)))
            await _render_net_points_settings(update, context)
            return
        if arg == "links":
            await _render_net_links(update, context)
            return
        if arg == "ncreate":
            # v36 (spec §4): admin entry into the Create Network Bot
            # wizard — Back returns to the admin Network Control panel.
            set_net_wizard_origin(context, f"{NET_CB_PREFIX}main")
            from app.presentation.telegram import runtime as _rt
            await _rt.handle_ncreate_callback(
                update, context, update.effective_user, "start")
            return
        if arg == "dg":
            # v36 (spec §4): admin entry into the Delivery Group center.
            set_net_wizard_origin(context, f"{NET_CB_PREFIX}main")
            from app.presentation.telegram import runtime as _rt
            await _rt.render_delivery_center(update, context)
            return
        if arg == "links:new":
            # v34 spec §4: Global Links overview → ➕ Create Global Link.
            # The SAME canonical mint flow (gpl:gen:<pid>) — no second
            # Global Link implementation; this is just the payload picker.
            rows = await db.list_payloads(limit=15)
            kb_rows = []
            for r in rows[:15]:
                try:
                    name = get_payload_display_name(
                        r["payload"],
                        display_name=_safe_row_get(r, "display_name"))
                except Exception:  # noqa: BLE001
                    name = str(r["payload"])
                kb_rows.append([InlineKeyboardButton(
                    f"🔗 {name[:40]} (#{r['id']})",
                    callback_data=f"gpl:gen:{int(r['id'])}")])
            kb_rows.append([InlineKeyboardButton(
                "⬅️ Links Overview", callback_data=f"{NET_CB_PREFIX}links")])
            await safe_edit_text(
                update.callback_query,
                "➕ CREATE GLOBAL LINK\n\nPick a payload — the link is "
                "minted through the same canonical signing flow.",
                reply_markup=InlineKeyboardMarkup(kb_rows))
            return
        if arg == "stats":
            await _render_net_stats(update, context)
            return
        if arg == "settings":
            await _render_net_settings(update, context)
            return
        if arg == "toggle":
            cur = await network_enabled()
            await db.set_setting(NET_SETTING_ENABLED, "0" if cur else "1")
            logger.info("NETWORK_SETTING network_enabled=%s (admin)",
                        "OFF" if cur else "ON")
            await _render_net_settings(update, context)
            return
        if arg == "maxup":
            maxb = await db.get_setting_int(NET_SETTING_MAX_BOTS,
                                            NET_DEFAULT_MAX_BOTS)
            await db.set_setting(NET_SETTING_MAX_BOTS,
                                 str(min(50, maxb + 1)))
            await _render_net_settings(update, context)
            return
        await render_network_control(update, context)

    # ------------------------------------------------------------------
    # BOT-11 (B11-B — spec §16): the admin Global Link TARGET PICKER.
    # ------------------------------------------------------------------
    _GPL_SEL_KEY = "gpl_target_sel"           # user_data selection state
    _gpl_mint_last: Dict[int, float] = {}     # per-user 2s mint guard (§26)

    def _gpl_read_selection(context, pid: int) -> Dict[str, Any]:
        """The admin's chosen target for THIS payload (default: main)."""
        sel = context.user_data.get(_GPL_SEL_KEY) or {}
        if int(sel.get("pid") or 0) != int(pid):
            return {"pid": int(pid), "mode": "main", "bot_id": None}
        return {"pid": int(pid),
                "mode": str(sel.get("mode") or "main"),
                "bot_id": (int(sel["bot_id"])
                           if sel.get("bot_id") is not None else None)}

    async def _render_gpl_target_picker(update, context, pid: int,
                                        note: str = "") -> None:
        """§16 panel: pick the delivery target BEFORE minting — Main /
        Random Registered Bot / one of the ACTIVE network bots (with the
        honest per-bot Delivery-Group state). The selection is persisted
        in admin user_data and re-rendered with a ● marker."""
        q = update.callback_query
        prow = await db.get_payload_by_id(pid)
        if not prow:
            await safe_answer_callback(q, "Payload not found.",
                                       show_alert=True)
            return
        try:
            name = get_payload_display_name(
                prow["payload"],
                display_name=_safe_row_get(prow, "display_name"))
        except Exception:  # noqa: BLE001
            name = str(prow["payload"])
        sel = _gpl_read_selection(context, pid)
        lines = [
            "\U0001F517 Global Link",
            f"Payload: {name}",
            "",
            "Target:",
        ]
        kb_rows: List[List[InlineKeyboardButton]] = []

        def _marker(kind: str, bot_id: Optional[int] = None) -> str:
            if sel["mode"] == kind and (kind != "bot"
                                        or sel["bot_id"] == bot_id):
                return "\u25CF "
            return "\u25CB "

        kb_rows.append([InlineKeyboardButton(
            f"{_marker('main')}Main Bot",
            callback_data=f"gpl:t:main:{int(pid)}")])
        kb_rows.append([InlineKeyboardButton(
            f"{_marker('random')}Random Registered Bot",
            callback_data=f"gpl:t:random:{int(pid)}")])
        # ONLY ACTIVE bots are listed (§16), each with its honest
        # Delivery-Group state (✅ DELIVERY_READY / ⚠️ setup required).
        bots = [b for b in (await db.list_network_bots())
                if str(b.get("status")) == "ACTIVE"]
        for b in bots[:25]:
            nid = int(b["network_bot_id"])
            uname = str(b.get("username") or "").lstrip("@") or "?"
            try:
                group = await db.get_delivery_group_for_bot(nid)
            except Exception:  # noqa: BLE001 — panel never breaks
                group = None
            gs = str((group or {}).get("status") or "")
            dg_icon = "\u2705" if gs == "DELIVERY_READY" else "\u26A0\uFE0F"
            kb_rows.append([InlineKeyboardButton(
                f"{_marker('bot', nid)}Network Bot #{nid} @{uname} {dg_icon}",
                callback_data=f"gpl:t:bot:{nid}:{int(pid)}")])
        if not bots:
            lines.append("(no ACTIVE network bots — Main or Random "
                         "targets only)")
        lines.append("")
        if sel["mode"] == "main":
            lines.append("Selected: Main Bot")
        elif sel["mode"] == "random":
            lines.append("Selected: Random Registered Bot — a random "
                         "eligible delivery bot will be selected and "
                         "locked in at creation.")
        elif sel["bot_id"] is not None:
            lines.append(f"Selected: Network Bot #{sel['bot_id']}")
        if note:
            lines.append("")
            lines.append(note)
        kb_rows.append([InlineKeyboardButton(
            "\U0001F517 Create Link", callback_data=f"gpl:create:{int(pid)}")])
        kb_rows.append([InlineKeyboardButton(
            "\u2B05\uFE0F Links Overview",
            callback_data=f"{NET_CB_PREFIX}links")])
        await safe_answer_callback(q)
        await safe_edit_text(q, "\n".join(lines),
                             reply_markup=InlineKeyboardMarkup(kb_rows))

    async def _gpl_mint_targeted(update, context, pid: int) -> None:
        """§16 [Create Link]: mint + persist WITH the selected target.
        random → ONE eligible bot selected at CREATION time and locked in
        (spec §8/§12 — never re-rolled at click). No eligible bot → an
        honest refusal, NO link minted. Rapid double-taps are guarded by
        the gpl:create debounce (state.py) + the per-user 2s mint guard."""
        q = update.callback_query
        uid = int(getattr(getattr(update, "effective_user", None), "id", 0)
                  or 0)
        now = time.monotonic()
        last = _gpl_mint_last.get(uid)
        if last is not None and (now - last) < 2.0:
            logger.info("GLOBAL_LINK_MINT_GUARDED user_id=%s payload_id=%s "
                        "(rapid double-tap — one mint only, spec §26)",
                        uid, pid)
            await safe_answer_callback(q, "Already creating the link...")
            return
        _gpl_mint_armed = now  # armed only on SUCCESS below (a refused
        # mint creates nothing — an immediate retry must never be blocked)
        prow = await db.get_payload_by_id(pid)
        if not prow:
            await safe_answer_callback(q, "Payload not found.",
                                       show_alert=True)
            return
        try:
            name = get_payload_display_name(
                prow["payload"],
                display_name=_safe_row_get(prow, "display_name"))
        except Exception:  # noqa: BLE001
            name = str(prow["payload"])
        sel = _gpl_read_selection(context, pid)
        mode = sel["mode"]
        target_id = 0
        target_uname = ""
        if mode == "random":
            # ONE centralized unbiased selection (spec §8) — resolved at
            # CREATION time and PERSISTED (the link's target is stable).
            if _net_router is not None:
                pick = await _net_router.select_random_delivery_bot()
            else:
                pick = await _net_select_random_delivery_bot(db)
            if pick.get("selected") is None:
                logger.info("GLOBAL_LINK_NO_ELIGIBLE_BOT user_id=%s "
                            "payload_id=%s mode=random reason=%s "
                            "(no link minted)",
                            uid, pid, pick.get("reason"))
                await safe_answer_callback(q)
                await safe_edit_text(
                    q,
                    "\u26A0\uFE0F Global Link — Random target\n\n"
                    "No delivery bot is currently available.\n\n"
                    "No link was created. A registered bot must be ACTIVE "
                    "with a verified Delivery Channel first; then try again.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("\U0001F504 Choose another target",
                                              callback_data=f"gpl:gen:{int(pid)}")],
                        [InlineKeyboardButton("\U0001F517 Links Overview",
                                              callback_data=f"{NET_CB_PREFIX}links")]]))
                return
            row = pick["selected"]
            target_id = int(row["network_bot_id"])
            target_uname = (str(row.get("username") or "").lstrip("@"))
        elif mode == "bot":
            target_id = int(sel.get("bot_id") or 0)
            brow = await db.get_network_bot(target_id) if target_id else None
            if not brow or str(brow.get("status")) != "ACTIVE":
                await safe_answer_callback(
                    q, "That bot is no longer active — pick another target.",
                    show_alert=True)
                await _render_gpl_target_picker(update, context, pid)
                return
            target_uname = str(brow.get("username") or "").lstrip("@")
        else:  # main
            target_id = 0
            target_uname = str(BOT_USERNAME or "").lstrip("@")
        # Mint + persist WITH the target (LinkSigningUnavailableError fails
        # CLOSED with operator guidance — spec §4).
        try:
            code = await _net_mint_targeted_link(
                db, _net_links, int(pid),
                target_network_bot_id=int(target_id),
                target_mode=str(mode))
        except _LinkSigningUnavailableError:
            from app.network.routing import LINK_SIGNING_KEY_MISSING_GUIDANCE
            logger.warning("GLOBAL_LINK_MINT_REFUSED payload_id=%s "
                           "reason=LinkSigningUnavailableError", pid)
            await safe_answer_callback(q, "Signing key required.",
                                       show_alert=True)
            await safe_edit_text(
                q,
                "\u26A0\uFE0F Global Link signing is not configured.\n\n"
                + LINK_SIGNING_KEY_MISSING_GUIDANCE,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F517 Links Overview",
                                          callback_data=f"{NET_CB_PREFIX}links")]]))
            return
        logger.info("GLOBAL_LINK_MINT_OK payload_id=%s code=%s "
                    "target_network_bot_id=%s target_mode=%s",
                    pid, code[:8], target_id, mode)
        _gpl_mint_last[uid] = _gpl_mint_armed  # success-armed (spec §26)
        if mode == "random":
            logger.info("GLOBAL_LINK_RANDOM_LOCKED payload_id=%s code=%s "
                        "target_network_bot_id=%s (locked at creation — "
                        "never re-rolled)", pid, code[:8], target_id)
        base = (f"https://t.me/{target_uname}?start=g{code}"
                if (target_id > 0 and target_uname)
                else f"https://t.me/{BOT_USERNAME}?start=g{code}")
        await safe_answer_callback(q, "Global link created.")
        target_label = (f"Network Bot #{target_id} @{target_uname}"
                        if target_id > 0 else "Main Bot")
        copy_row: List[InlineKeyboardButton] = []
        try:
            copy_row = [InlineKeyboardButton(
                "\U0001F4CB Copy Link",
                copy_text=CopyTextButton(text=base))]
        except Exception:  # noqa: BLE001 — older PTB without copy buttons
            copy_row = []
        result_rows: List[List[InlineKeyboardButton]] = []
        # The admin can OPEN the freshly minted link directly (t.me/<target>)
        # — the URL button doubles as the visible target proof (§4 result).
        result_rows.append([InlineKeyboardButton(
            "\U0001F517 Open Link", url=base)])
        if copy_row:
            result_rows.append(copy_row)
        result_rows.append([InlineKeyboardButton(
            "\U0001F517 Create another",
            callback_data=f"gpl:gen:{int(pid)}")])
        result_rows.append([InlineKeyboardButton(
            "\U0001F517 Links Overview",
            callback_data=f"{NET_CB_PREFIX}links")])
        target_note = (
            "\u2705 Deterministic target: this link always opens "
            f"@{target_uname} — the bot chosen at creation (never "
            "re-rolled). If that bot later becomes unavailable, users "
            "get an honest notice to request the file again."
            if target_id > 0 else
            "\u2705 Stable front door: this link always opens the MAIN "
            "bot, which delivers in its own context.")
        await safe_edit_text(
            q,
            "\U0001F517 Global Payload Link\n\n"
            f"Payload: {name}\n"
            f"Target: {target_label}\n"
            f"Code: {code}\n\n{base}\n\n"
            f"{target_note}",
            reply_markup=InlineKeyboardMarkup(result_rows))

    async def _handle_gpl_admin_callback(update, context, arg: str) -> None:
        """Admin Global Payload Link management (spec §17/§63).

        GAP-CLOSURE spec §5: legacy untargeted links point at the MAIN
        bot — the stable front door whose Global Link Resolver +
        NetworkRouter pick a healthy network bot AT CLICK TIME.

        BOT-11 (B11-B — spec §16): minting now goes through the TARGET
        PICKER first (gplt:main / gplt:random / gplt:bot:<nid> persist
        the selection; gpl:create mints through the ONE canonical
        targeted flow with the persisted target). The legacy
        generate_global_payload_link (untargeted) stays available for
        its existing callers."""
        q = update.callback_query
        parts = arg.split(":")
        # BOT-11 dispatch note: the picker buttons emit gpl:t:<sel>:<pid>
        # (dispatched via NET_GPL_CB='gpl:' → stripped arg 't:<sel>:<pid>').
        # 'gplt:<sel>:<pid>' parses identically (direct-call compat):
        # parts[0] is just the namespace marker in both shapes.
        if parts and parts[0] in ("gplt", "t"):
            # §16 target selection — persisted in admin user_data, then
            # the picker re-renders with the ● marker.
            if len(parts) >= 3 and parts[1] in ("main", "random"):
                try:
                    pid = int(parts[2])
                except ValueError:
                    await safe_answer_callback(q, "Invalid request.",
                                               show_alert=True)
                    return
                context.user_data[_GPL_SEL_KEY] = {
                    "pid": pid, "mode": parts[1], "bot_id": None}
                await _render_gpl_target_picker(update, context, pid)
                return
            if len(parts) >= 4 and parts[1] == "bot":
                try:
                    nid = int(parts[2])
                    pid = int(parts[3])
                except ValueError:
                    await safe_answer_callback(q, "Invalid request.",
                                               show_alert=True)
                    return
                context.user_data[_GPL_SEL_KEY] = {
                    "pid": pid, "mode": "bot", "bot_id": nid}
                await _render_gpl_target_picker(update, context, pid)
                return
            await safe_answer_callback(q, "Invalid request.",
                                       show_alert=True)
            return
        if parts and parts[0] == "create":
            try:
                pid = int(parts[1])
            except (IndexError, ValueError):
                await safe_answer_callback(q, "Invalid request.",
                                           show_alert=True)
                return
            await _gpl_mint_targeted(update, context, pid)
            return
        if parts and parts[0] == "gen":
            # §16: the mint entry now renders the TARGET PICKER (the
            # same entry point the payload-detail "Global Link" button
            # and links:new payload picker already route to).
            try:
                pid = int(parts[1])
            except (IndexError, ValueError):
                await safe_answer_callback(q, "Invalid request.",
                                           show_alert=True)
                return
            prow = await db.get_payload_by_id(pid)
            if not prow:
                await safe_answer_callback(q, "Payload not found.",
                                           show_alert=True)
                return
            await _render_gpl_target_picker(update, context, pid)
            return
        await _render_net_links(update, context)

    async def _handle_nbc_callback(update, context, arg: str) -> None:
        """Admin Network Broadcast Center actions (spec §43/§44/§45)."""
        q = update.callback_query
        if arg in ("", "main"):
            await _render_broadcast_center(update, context)
            return
        if arg.startswith("new:"):
            await _render_bcast_new(update, context, arg[4:])
            return
        if arg == "start":
            await _net_broadcast_start(update, context)
            return
        if arg == "cancel":
            context.user_data.pop("net_bcast_state", None)
            await safe_edit_text(q, "Broadcast cancelled.",
                                 reply_markup=InlineKeyboardMarkup([[
                                     InlineKeyboardButton(
                                         "\U0001F4E2 Broadcast Center",
                                         callback_data=f"{NET_BCAST_CB}main")]]))
            return
        if arg == "jobs":
            await _render_bcast_jobs(update, context)
            return
        if arg.startswith("pause:"):
            try:
                bid = int(arg[6:])
            except ValueError:
                return
            await _net_broadcast.pause(bid)
            await safe_answer_callback(q, f"Broadcast #{bid} paused.")
            await _render_bcast_jobs(update, context)
            return
        if arg.startswith("cancel:"):
            try:
                bid = int(arg[7:])
            except ValueError:
                return
            await _net_broadcast.cancel(bid)
            await safe_answer_callback(q, f"Broadcast #{bid} cancelled.")
            await _render_bcast_jobs(update, context)
            return
        if arg.startswith("resume:"):
            try:
                bid = int(arg[7:])
            except ValueError:
                return
            await _net_broadcast.resume(bid)
            await safe_answer_callback(q, f"Broadcast #{bid} resumed.")
            await _render_bcast_jobs(update, context)
            return
        await _render_broadcast_center(update, context)

    return SimpleNamespace(
        network_enabled=network_enabled,
        _net_context_id=_net_context_id,
        _net_validate_token_via_telegram=_net_validate_token_via_telegram,
        _net_probe_storage_access=_net_probe_storage_access,
        _network_media_guard=_network_media_guard,
        _network_record_start=_network_record_start,
        _net_get_bot_client=_net_get_bot_client,
        is_global_payload_link=is_global_payload_link,
        _net_serving_bot_username=_net_serving_bot_username,
        _net_main_bot_username=_net_main_bot_username,
        handle_global_payload_link=handle_global_payload_link,
        generate_global_payload_link=generate_global_payload_link,
        handle_pt_unlock=handle_pt_unlock,
        network_command=network_command,
        _render_my_network=_render_my_network,
        _render_my_network_panel=_render_my_network_panel,
        _net_reg_get=_net_reg_get,
        _net_reg_clear=_net_reg_clear,
        _render_net_reg_start=_render_net_reg_start,
        _render_net_reg_token=_render_net_reg_token,
        _net_reg_consent_keyboard=_net_reg_consent_keyboard,
        handle_network_registration_text=handle_network_registration_text,
        _net_complete_registration=_net_complete_registration,
        render_network_control=render_network_control,
        _render_net_bots=_render_net_bots,
        _render_net_health=_render_net_health,
        _net_run_health_checks=_net_run_health_checks,
        _render_net_points_settings=_render_net_points_settings,
        _render_net_links=_render_net_links,
        _render_net_settings=_render_net_settings,
        _render_broadcast_center=_render_broadcast_center,
        _render_bcast_new=_render_bcast_new,
        handle_network_broadcast_text=handle_network_broadcast_text,
        _render_bcast_preview=_render_bcast_preview,
        _net_broadcast_start=_net_broadcast_start,
        _render_bcast_jobs=_render_bcast_jobs,
        _bcast_source_ids=_bcast_source_ids,
        _net_broadcast_send_one=_net_broadcast_send_one,
        _handle_net_points_callback=_handle_net_points_callback,
        _handle_net_reg_callback=_handle_net_reg_callback,
        _handle_net_bot_callback=_handle_net_bot_callback,
        _handle_net_admin_callback=_handle_net_admin_callback,
        _net_refresh_capabilities=_net_refresh_capabilities,
        _handle_gpl_admin_callback=_handle_gpl_admin_callback,
        _handle_nbc_callback=_handle_nbc_callback,
    )
