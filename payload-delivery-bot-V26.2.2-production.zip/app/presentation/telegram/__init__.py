"""Telegram presentation package (ARCHITECTURE PROPER BREAKDOWN).

THE home of the Telegram-facing presentation layer — everything that was
the bot.py monolith now lives here as real modules with real
responsibilities:

``state.py``        import zone, configuration bindings, constants, locks,
                    caches and singletons (verbatim from bot.py, original
                    order)
``<section>.py``    handlers grouped by responsibility (delivery, force
                    join, watch ads, admin panels, callbacks, mini app,
                    website admin, network wiring, ...)
``namespace.py``   assembles the shared runtime namespace from the sections
``registration.py`` the PTB handler registration grammar (data-driven)
``keyboards.py``    keyboard builders (injected dependencies)
``network_ui.py``   the Network Platform user/admin UI handlers
``website_ui.py``   the Website admin control handlers (wsite: namespace)
``website_gap_ui.py`` the GAP-CLOSURE admin panels: Website categories
                    (wsitecat: namespace) + the centralized ads platform
                    (wsad: namespace)
``router.py``       the extracted-callback dispatch registry
``runtime``        (assembled object, importable as
                    ``from app.presentation.telegram import runtime``)

Dependency direction: this package depends DOWNWARD on application
services (app/services), domain rules (app/core), ports and
infrastructure (app/storage, app/media, app/network, app/web). It owns
NO business policy, NO SQL schema, NO migrations, NO composition of the
application — the composition root is app/bootstrap/application.py.

Importing this package triggers the runtime assembly (via namespace.py),
which is the single handler-provider object handed to the bootstrap.
"""
from __future__ import annotations

from . import namespace  # noqa: F401  — assembles + publishes `runtime`

__all__ = ["namespace", "runtime"]


def __getattr__(name):  # pragma: no cover — plain re-export
    if name == "runtime":
        from .namespace import NS
        return NS
    raise AttributeError(name)
