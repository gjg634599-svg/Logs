"""Recent files panels — recent files, file detail.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

from app.presentation.telegram.state import RECENT_PAGE_SIZE



async def send_recent_files_panel(update: Update, limit: int = RECENT_PAGE_SIZE,
                                  sort: str = "newest", page: int = 0) -> None:
    """Recent Files panel with 4×2 grid layout (Issue #45).

    Shows 8 files per page in a compact grid. Shortened filenames (max 25 chars).
    No internal IDs exposed. Sort buttons preserved.
    """
    total = await db.count_indexed_files()
    if total == 0:
        if update.callback_query:
            await safe_edit_text(update.callback_query,
                "*\U0001F4C4 Recent Files*\n\nNo files indexed yet.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")]]
                ),
            )
        else:
            await reply_protected(update, "No files indexed yet.")
        return
    offset = page * limit
    rows = await db.get_files_sorted(sort=sort, limit=limit, offset=offset)
    total_pages = max(1, (total + limit - 1) // limit)
    sort_label = RECENT_SORT_LABELS.get(sort, "Newest")
    header = (
        f"*\U0001F4C4 Recent Files*\n\n"
        f"Sort: {sort_label} | Page {page + 1}/{total_pages} | {total} files total"
    )
    # Issue #45: 4×2 grid layout — 2 buttons per row, max 8 per page.
    buttons: List[List[InlineKeyboardButton]] = []
    current_row: List[InlineKeyboardButton] = []
    for r in rows:
        # Shortened label: emoji + truncated filename (max 25 chars), no IDs.
        emoji = media_emoji(r['media_type'])
        fname = (r["file_name"] or media_type_label(r['media_type']))[:25]
        label = f"{emoji} {fname}"
        current_row.append(InlineKeyboardButton(
            label,
            callback_data=f"file:{r['id']}",
        ))
        if len(current_row) == 2:
            buttons.append(current_row)
            current_row = []
    if current_row:
        buttons.append(current_row)
    # Sort buttons
    sort_row: List[InlineKeyboardButton] = []
    for skey, slabel in RECENT_SORT_LABELS.items():
        mark = "\u2713 " if skey == sort else ""
        sort_row.append(InlineKeyboardButton(
            f"{mark}{slabel}",
            callback_data=f"recentsort:{skey}",
        ))
    buttons.append(sort_row)
    # Pagination nav
    nav: List[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("\u2B05\uFE0F Prev",
                                        callback_data=f"recentpage:{sort}:{page - 1}"))
    nav.append(InlineKeyboardButton(f"{page + 1}/{total_pages}",
                                     callback_data=f"recentpage:{sort}:{page}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Next \u27A1\uFE0F",
                                         callback_data=f"recentpage:{sort}:{page + 1}"))
    buttons.append(nav)
    buttons.append([InlineKeyboardButton("\U0001F50D Search by Name", callback_data="recentsearch")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:storage")])
    kb = InlineKeyboardMarkup(buttons)
    if update.callback_query:
        await safe_edit_text(update.callback_query,
            header, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
        )
    else:
        await reply_protected(update, 
            header, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
        )



async def file_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, file_id_pk: int) -> None:
    row = await db.get_indexed_file_by_id(file_id_pk)
    if not row:
        await safe_answer_callback(update.callback_query, "File not found.", show_alert=True)
        return
    direct_link = build_msg_link(row["message_id"])
    # Escape the filename so Markdown specials (_ * [ ` ~ |) in it can never
    # crash Telegram formatting (Issue 1).
    safe_name = escape_md(row["file_name"] or "file")
    text = (
        f"{media_emoji(row['media_type'])} *{safe_name}*\n\n"
        f"*Message ID:* `{row['message_id']}`\n"
        f"*Type:* {row['media_type'].title()}\n"
        f"*Size:* {format_size(row['file_size'])}\n"
        f"*Duration:* {format_duration(row['duration'])}\n\n"
        f"*\U0001F517 Direct Link:*\n`{direct_link}`"
    )
    buttons = [
        [InlineKeyboardButton("\U0001F517 Copy Link", callback_data=f"mlinkcopy:{row['message_id']}"),
         InlineKeyboardButton("\U0001F441 Preview", callback_data=f"filepreview:{file_id_pk}")],
        [InlineKeyboardButton("\u274C Delete File", callback_data=f"filedel:{file_id_pk}")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:recent")],
    ]
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup(buttons))



async def file_info_callback(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              file_id_pk: int) -> None:
    # Same as file_detail but with a Copy-link friendly layout.
    await file_detail(update, context, file_id_pk)



async def make_payload_for_file(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  file_id_pk: int) -> None:
    """Launch the Payload Configuration Wizard with this file pre-selected.

    The name is NOT pre-seeded — the admin chooses a custom name or taps Skip
    to auto-generate one at Step 1.
    """
    # BOT7: server-side permission enforcement.
    _uid = update.effective_user.id if update.effective_user else None
    if _uid is None or not await has_permission(_uid, PERM_PAYLOAD_CREATE):
        logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=make_payload_for_file "
                    "result=denied reason=missing_perm perm=%s", _uid,
                    PERM_PAYLOAD_CREATE)
        await _perm_denied_notice(update, context, "create payloads")
        return
    row = await db.get_indexed_file_by_id(file_id_pk)
    if not row:
        await update.callback_query.answer("File not found.", show_alert=True)
        return
    clear_wizard_states(context)
    state = _pcw_new_state(index_id=file_id_pk)
    state["owner_id"] = update.effective_user.id if update.effective_user else None
    context.user_data[PCW_KEY] = state
    logger.info("BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s mode=create_from_file",
                state["owner_id"])
    await pcw_log_wizard_event("wizard_started")
    await pcw_show_name_step(update, context)
