"""Telegram handler registration grammar (ARCHITECTURE DECOUPLING).

The registration table previously embedded in bot.py's
``build_application`` — expressed as DATA. The composition
(app/bootstrap/application.py) applies it to any handler-provider
module; the legacy bot.py namespace today, extracted handler modules
tomorrow. Registration ORDER is preserved EXACTLY from the Phase 5
``build_application`` (PTB dispatch within a group is order-sensitive).

The handler functions themselves stay in the provider module — this
registry only binds names → PTB handler instances at call time
(late-bound through the module namespace, monkey-patch friendly).
"""
from __future__ import annotations

from typing import Any, List

from telegram.ext import (
    CallbackQueryHandler,
    ChatJoinRequestHandler,
    CommandHandler,
    ManagedBotUpdatedHandler,
    MessageHandler,
    filters,
)

# (command name, module attribute) — registration order preserved verbatim
# from the Phase 5 build_application.
_COMMAND_TABLE: List[List[str]] = [
    ["start", "start_command"],
    ["recent", "recent_command"],
    ["help", "help_command"],
    # NETWORK PLATFORM (v29): user-facing My Network entry (/network).
    ["network", "network_command"],
    # payload management
    ["createpayload", "createpayload_command"],
    ["deletepayload", "deletepayload_command"],
    ["disablepayload", "disablepayload_command"],
    ["enablepayload", "enablepayload_command"],
    ["payloadinfo", "payloadinfo_command"],
    ["payloadlist", "payloadlist_command"],
    ["addalias", "addalias_command"],
    ["removealias", "removealias_command"],
    ["listaliases", "listaliases_command"],
    ["setpassword", "setpassword_command"],
    ["removepassword", "removepassword_command"],
    ["expire", "expire_command"],
    ["maxclicks", "maxclicks_command"],
    ["settimer", "settimer_command"],
    ["onetime", "onetime_command"],
    # storage channels
    ["addstorage", "addstorage_command"],
    ["removestorage", "removestorage_command"],
    ["enablestorage", "enablestorage_command"],
    ["disablestorage", "disablestorage_command"],
    ["liststorage", "liststorage_command"],
    # force-join channels
    ["addchannel", "addchannel_command"],
    ["removechannel", "removechannel_command"],
    ["listchannels", "listchannels_command"],
    # Issue 25: GUI-driven Force-Join panel command.
    ["forcejoin", "forcejoin_command"],
    # start message
    ["startmsg", "startmsg_command"],
    # analytics / files / reindex
    ["stats", "stats_command"],
    ["admin_verify_system", "admin_verify_system"],
    ["toppayloads", "toppayloads_command"],
    ["recentfiles", "recentfiles_command"],
    ["reindex", "reindex_command"],
    # V26.2 (bot-41 §6): safe media identity repair.
    ["repairidentity", "repairidentity_command"],
    # message-id direct links
    ["link", "link_command"],
    # broadcast
    ["schedulebroadcast", "schedule_broadcast_command"],
    ["cancelbroadcast", "cancelscheduled_command"],
    ["broadcastlist", "broadcastlist_command"],
]


def build_handler_registry(mod: Any) -> List[Any]:
    """Build the PTB handler instances from a handler-provider module.

    ``mod`` is the legacy bot.py namespace today (the compatibility
    facade). Attributes are resolved at CALL time so test patching
    semantics keep working unchanged.
    """
    entries: List[Any] = []
    # ---- command handlers ----
    for name, attr in _COMMAND_TABLE:
        entries.append(CommandHandler(name, getattr(mod, attr)))

    # ---- channel posts (auto indexing) ----
    entries.append(MessageHandler(filters.UpdateType.CHANNEL_POST,
                                  mod.on_channel_post))
    entries.append(MessageHandler(filters.UpdateType.EDITED_CHANNEL_POST,
                                  mod.on_edited_channel_post))

    # ---- Issue 7: ChatJoinRequest handler (Request-to-Join channels) ----
    # Must be registered so the bot receives join-request updates and stores
    # them in the in-memory cache for the verify callback to check.
    entries.append(ChatJoinRequestHandler(mod.on_chat_join_request))

    # ---- MANAGED BOTS v37 (Task 8): Telegram managed-bot lifecycle ----
    # MANAGED_BOT_CREATED service messages and Update.managed_bot arrive
    # at the MANAGER — the MAIN bot here, and (b10 §7 / B10-B2) ALSO any
    # registered NETWORK bot whose worker has the can_manage_bots
    # capability (the worker builder app/network/lifecycle.py registers
    # the SAME facades in handler group 1). Both map to namespace facades
    # in network_wiring.py → app/network/managed_bots.py.
    entries.append(MessageHandler(
        filters.StatusUpdate.MANAGED_BOT_CREATED,
        mod.handle_managed_bot_created_message))
    entries.append(ManagedBotUpdatedHandler(mod.handle_managed_bot_update))

    # ---- callback (inline panel + verify + copy) ----
    entries.append(CallbackQueryHandler(mod.on_callback))

    # ---- media input (admin setting start photo/video OR sending a broadcast) ----
    entries.append(MessageHandler(
        (filters.PHOTO | filters.VIDEO | filters.Document.ALL
         | filters.AUDIO | filters.VOICE | filters.ANIMATION)
        & ~filters.COMMAND, mod.on_media_input))

    # ---- text (password capture / admin states / broadcast / fallback) ----
    entries.append(MessageHandler(filters.TEXT & ~filters.COMMAND,
                                  mod.text_handler))
    return entries
