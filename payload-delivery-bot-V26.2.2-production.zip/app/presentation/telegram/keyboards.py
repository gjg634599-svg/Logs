"""Telegram keyboard builders (bot adapter layer)."""
from __future__ import annotations

from enum import Enum

from types import SimpleNamespace

from app.core.force_join.service import MemberCheckResult
from app.storage.dbutil import safe_row_get as _safe_row_get
from telegram import InlineKeyboardButton
from telegram import InlineKeyboardMarkup
from typing import List, Optional, Tuple
import aiosqlite
import json


def make_keyboards(db, BOT_USERNAME=None, _force_channel_label=None, _get_or_create_invite_link=None, build_link=None):
    """Bind the verbatim implementations to explicit
    dependencies (call-time late binding - no globals)."""
    def build_start_buttons(buttons_json: Optional[str]) -> Optional[InlineKeyboardMarkup]:
        if not buttons_json:
            return None
        try:
            rows_data = json.loads(buttons_json)
        except (json.JSONDecodeError, TypeError):
            return None
        rows: List[List[InlineKeyboardButton]] = []
        for row in rows_data:
            btns: List[InlineKeyboardButton] = []
            for b in row:
                try:
                    btype = b.get("type", "url")
                    label = b.get("text", "")
                    value = b.get("value", "")
                    if btype == "url":
                        btns.append(InlineKeyboardButton(label, url=value))
                    elif btype == "channel":
                        v = value.lstrip("@")
                        btns.append(InlineKeyboardButton(label, url=f"https://t.me/{v}"))
                    elif btype == "deeplink":
                        btns.append(InlineKeyboardButton(label, url=build_link(value)))
                except (TypeError, KeyError):
                    continue
            if btns:
                rows.append(btns)
        return InlineKeyboardMarkup(rows) if rows else None

    async def build_force_join_keyboard(bot, payload: str,
                                         unjoined: Optional[List[aiosqlite.Row]] = None,
                                         statuses: Optional[List[Tuple[aiosqlite.Row, "MemberCheckResult"]]] = None) -> InlineKeyboardMarkup:
        """BOT6 redesigned Join + Verify keyboard.

        Renders one Join button per NOT-joined channel (so the user sees exactly
        what to do), then a single Verify Membership button. Joined channels get
        no button (they're already done). Bot-fault channels get no Join button
        either — joining won't help; the admin must fix the configuration.

        Accepts either `unjoined` (legacy: a list of channel rows) or `statuses`
        (BOT6: a list of (row, MemberCheckResult) tuples from
        build_force_join_block_message). When `statuses` is provided, only
        NOT_MEMBER rows get a Join button.
        """
        buttons: List[List[InlineKeyboardButton]] = []
        # Build the (row, result) list to iterate.
        if statuses is not None:
            items = statuses
        elif unjoined is not None:
            items = [(ch, MemberCheckResult.NOT_MEMBER) for ch in unjoined]
        else:
            all_channels = await db.list_force_channels()
            items = [(ch, MemberCheckResult.NOT_MEMBER) for ch in all_channels]

        for ch, res in items:
            cid = _safe_row_get(ch, "channel_id")
            if cid is None:
                continue
            # Only render a Join button for genuinely-not-joined channels.
            # Joined / admin / creator / bot-fault channels get no button.
            if res != MemberCheckResult.NOT_MEMBER:
                continue
            label = _force_channel_label(ch)
            # Issue #47: use persistent invite link (no create/revoke loop).
            url = await _get_or_create_invite_link(bot, cid)
            if not url:
                uname = _safe_row_get(ch, "channel_name")
                if uname:
                    url = f"https://t.me/{uname.lstrip('@')}"
            if url:
                btn_text = _safe_row_get(ch, "channel_button_text") or f"\U0001F4E2 Join: {label}"
                buttons.append([InlineKeyboardButton(btn_text, url=url)])
        # Issue #47: customizable verify button text (read from first channel).
        verify_text = "\U0001F504 VERIFY MEMBERSHIP"
        all_channels = await db.list_force_channels()
        if all_channels:
            verify_text = _safe_row_get(all_channels[0], "verify_button_text") or verify_text
        # V26 (callback_data safety): named payload slugs are up to 64
        # chars — 'verify:' + slug can exceed Telegram's 64-byte
        # callback_data limit (Button_data_invalid kills the WHOLE gate
        # message; production payload 787's 54-char slug was 6 bytes from
        # it). Structurally short link forms (m<id> / c<code> / r-range)
        # pass through; a named slug becomes the compact reversible
        # internal id 'i<payload_id>' (the verify: handler resolves it
        # back to the canonical slug server-side).
        verify_arg = payload
        try:
            if payload and not (payload[:1] in ("m", "c", "r")
                                and len(payload) <= 16):
                _row = await db.get_payload(payload)                     if hasattr(db, "get_payload") else None
                if _row is not None:
                    verify_arg = f"i{int(_row['id'])}"
        except Exception:  # noqa: BLE001 — fall back to the raw arg
            verify_arg = payload
        buttons.append(
            [InlineKeyboardButton(verify_text,
                                  callback_data=f"verify:{verify_arg}")]
        )
        return InlineKeyboardMarkup(buttons)

    return SimpleNamespace(
        build_start_buttons=build_start_buttons,
        build_force_join_keyboard=build_force_join_keyboard,
    )
