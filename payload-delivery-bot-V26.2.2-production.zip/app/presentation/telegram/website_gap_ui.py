"""GAP-CLOSURE v33 — Website CATEGORY + ADS admin panels (bot adapter layer).

Two admin control surfaces that extend the EXISTING Website Control panel
(``panel:website``) through two FREE admin callback namespaces:

  ``wsitecat:``  the Website CATEGORY manager (spec §26-§29) — categories
                 (name / slug / icon / order / enabled / visible / 18+ /
                 description), per-category payload membership management
                 (assignments REFERENCE existing ``website_payloads``
                 listings — media is NEVER duplicated) and the New
                 Category wizard (name → slug → icon → order).
  ``wsad:``      the centralized ADS PLATFORM manager (spec §35-§56) —
                 master ``ads_enabled`` switch, backend-controlled
                 exempt users (spec §46), campaigns (name / status /
                 priority / schedule / frequency caps), creatives (all 5
                 kinds, every URL write validated through
                 ``validate_ad_url`` — HTTPS ONLY, javascript:/data:/
                 file: rejected), the full placement registry toggles
                 (spec §49), the 7-day analytics summary (spec §51) and
                 honest admin-chat creative previews.

Security invariants (mirrors the wsite: panels):
  * both prefixes are ADMIN-ONLY: they are NOT in USER_FACING_PREFIXES so
    the master admin gate in on_callback (``is_admin``) blocks every
    non-admin tap before dispatch — exactly like ``wsite:``.
  * every creative URL write is validated locally with
    ``validate_ad_url`` (clear admin error, nothing saved) AND the repo
    re-validates on write; render-time re-validation happens in the
    preview path (a creative whose URL became invalid previews NOTHING
    rather than a broken ad).
  * ``html`` creatives are previewed through ``sanitize_ad_html`` (strict
    whitelist) as PLAIN TEXT — never parsed.
  * URLs/tokens are NEVER logged (admin action logs carry kinds, counts
    and lengths only).

The module NEVER imports bot.py: every dependency (db, safe send/edit
helpers, admin logger) is injected per call by the website_admin facades
(the same ``_wsite_deps()`` snapshot the wsite: panels use).
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from app.ads.service import sanitize_ad_html
from app.storage.repositories.ads import (
    AD_CREATIVE_KINDS,
    AD_PLACEMENT_KEYS,
    validate_ad_url,
)

logger = logging.getLogger("payload-bot")

# Wizard / editor state keys (registered in ALL_WIZARD_STATES so
# clear_wizard_states purges them on any panel navigation).
WSITECAT_WIZARD_KEY = "wsitecat_wizard"
WSITECAT_EDIT_KEY = "wsitecat_edit"
WSAD_WIZARD_KEY = "wsad_wizard"
WSAD_EDIT_KEY = "wsad_edit"

# List pagination (Telegram message limits — 10 entries per page).
GAP_ADMIN_PAGE_SIZE = 10

# spec §49 placement registry labels (render order = AD_PLACEMENT_KEYS).
AD_PLACEMENT_LABELS: Dict[str, str] = {
    "AD_TOP": "Top Banner",
    "AD_HOME_HERO": "Home Hero",
    "AD_HOME_BETWEEN_CONTENT": "Between Cards",
    "AD_CATEGORY_TOP": "Category Top",
    "AD_CATEGORY_BETWEEN": "Category Between",
    "AD_PAYLOAD_DETAIL": "Payload Detail",
    "AD_VIDEO_BEFORE": "Pre-roll",
    "AD_VIDEO_MIDROLL": "Mid-roll",
    "AD_VIDEO_END": "Post-roll",
    "AD_SIDEBAR": "Sidebar",
    "AD_FOOTER": "Footer",
}

AD_CAMPAIGN_STATUSES = ("draft", "active", "paused", "ended")

AD_CREATIVE_KIND_LABELS: Dict[str, str] = {
    "video": "\U0001F3AC Video ad",
    "banner_image": "\U0001F5BC Banner (image)",
    "banner_responsive": "\U0001F5BC Banner (responsive)",
    "html": "\U0001F4DD HTML creative",
    "provider": "\U0001F517 Ad-network provider zone",
}

# Per-kind text-input step sequences for the New Creative wizard. Every
# *_url step is validated through validate_ad_url before it is accepted.
_CREATIVE_STEPS: Dict[str, Tuple[str, ...]] = {
    "video": ("video_url", "click_url", "title", "alt",
              "duration", "skip", "skip_after"),
    "banner_image": ("image_desktop_url", "image_mobile_url", "click_url",
                     "title", "alt"),
    "banner_responsive": ("image_desktop_url", "image_mobile_url",
                          "click_url", "title", "alt"),
    "html": ("html_content", "click_url", "title"),
    "provider": ("provider_zone", "click_url", "title"),
}


def _kb(rows: List[List[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(rows)


def _btn(label: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(label, callback_data=data)


# ---------------------------------------------------------- state helpers
def _cat_wiz_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSITECAT_WIZARD_KEY)
    return st if isinstance(st, dict) and st.get("step") else None


def _cat_wiz_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSITECAT_WIZARD_KEY, None)


def _cat_edit_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSITECAT_EDIT_KEY)
    return st if isinstance(st, dict) and st.get("field") else None


def _cat_edit_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSITECAT_EDIT_KEY, None)


def _ad_wiz_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSAD_WIZARD_KEY)
    return st if isinstance(st, dict) and st.get("step") else None


def _ad_wiz_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSAD_WIZARD_KEY, None)


def _ad_edit_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    st = context.user_data.get(WSAD_EDIT_KEY)
    return st if isinstance(st, dict) and st.get("field") else None


def _ad_edit_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop(WSAD_EDIT_KEY, None)


def _slug_normalize(raw: str) -> str:
    """Same normalization the category repo applies (spec §26): lowercase,
    non [a-z0-9-] → dashes, trimmed, 40 chars max."""
    s = str(raw or "").strip().lower()
    s = re.sub(r"[^a-z0-9-]+", "-", s).strip("-")
    return s[:40]


def _slug_valid(slug: str) -> bool:
    return bool(re.match(r"^[a-z0-9][a-z0-9-]{1,40}$", str(slug).strip()))


def _pages(total: int, size: int = GAP_ADMIN_PAGE_SIZE) -> int:
    return max(1, (total + size - 1) // size)


def _yn(flag: bool) -> str:
    return "yes" if flag else "no"


def _truncate(value: Any, limit: int) -> str:
    return str(value if value is not None else "").strip()[:limit]


# ============================================================
# 🗂 CATEGORIES panel (spec §26-§29)
# ============================================================

async def categories_panel(update: Update,
                           context: ContextTypes.DEFAULT_TYPE,
                           deps: Any, page: int = 1) -> None:
    """The Website Categories main panel — list with per-category Manage /
    On-Off / Delete, plus the New Category wizard entry."""
    db = deps.db
    cats = await db.list_website_categories(include_disabled=True)
    counts = await db.category_payload_counts()
    page = max(1, int(page or 1))
    pages = _pages(len(cats))
    page = min(page, pages)
    chunk = cats[(page - 1) * GAP_ADMIN_PAGE_SIZE:
                 (page - 1) * GAP_ADMIN_PAGE_SIZE + GAP_ADMIN_PAGE_SIZE]
    lines = [
        "\U0001F5C2 WEBSITE CATEGORIES",
        "",
    ]
    if not chunk:
        lines.append("No categories yet.")
        lines.append("Use New Category to create the first one.")
    for c in chunk:
        icon = _truncate(c["icon"], 8) or "\U0001F4C2"
        en = "\U0001F7E2" if int(c["enabled"]) else "\U0001F534"
        vis = "\U0001F441" if int(c["visible"]) else "\U0001F6E1"
        adult = "\U0001F51E 18+" if int(c["age_restricted"]) else "18+ no"
        lines.append(
            f"#{int(c['id'])} {icon} {_truncate(c['name'], 40)} "
            f"({_truncate(c['slug'], 40)}, order {int(c['sort_order'])})\n"
            f"    {en} enabled · {vis} visible · {adult} · "
            f"{int(counts.get(int(c['id']), 0))} listing(s)")
    lines += ["", f"Page {page}/{pages} — {len(cats)} categor"
              + ("y" if len(cats) == 1 else "ies") + " (memberships never "
              "duplicate media — they reference existing listings)."]
    rows: List[List[InlineKeyboardButton]] = []
    for c in chunk:
        cid = int(c["id"])
        icon = _truncate(c["icon"], 8) or "\U0001F4C2"
        rows.append([
            _btn(f"{icon} {_truncate(c['name'], 24)}",
                 f"wsitecat:view:{cid}"),
            _btn("\U0001F7E2" if int(c["enabled"]) else "\U0001F534",
                 f"wsitecat:tgl:{cid}"),
            _btn("\U0001F5D1", f"wsitecat:del:{cid}"),
        ])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsitecat:page:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsitecat:page:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [
        [_btn("\u2795 New Category", "wsitecat:new")],
        [_btn("\u2B05\uFE0F Back to Website Control", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _category_get(db: Any, cid: int):
    try:
        return await db.get_website_category(int(cid))
    except Exception:  # noqa: BLE001
        return None


async def category_view(update: Update,
                        context: ContextTypes.DEFAULT_TYPE,
                        deps: Any, cid: int) -> None:
    db = deps.db
    c = await _category_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Category not found.")
        await categories_panel(update, context, deps)
        return
    counts = await db.category_payload_counts()
    n = int(counts.get(int(cid), 0))
    lines = [
        "\U0001F5C2 CATEGORY",
        "",
        f"Name: {_truncate(c['name'], 60)}",
        f"Slug: {_truncate(c['slug'], 40)}",
        f"Icon: {_truncate(c['icon'], 8) or '(none)'}",
        f"Order: {int(c['sort_order'])}",
        f"Enabled: {'\U0001F7E2' if int(c['enabled']) else '\U0001F534'} "
        f"{_yn(bool(int(c['enabled'])))}",
        f"Visible: {'\U0001F441' if int(c['visible']) else '\U0001F6E1'} "
        f"{_yn(bool(int(c['visible'])))}",
        f"Age 18+: {'\U0001F51E yes' if int(c['age_restricted']) else 'no'}",
        f"Description: {_truncate(c['description'], 120) or '(none)'}",
        f"Listings: {n}",
        "",
        "Memberships REFERENCE existing website listings —",
        "media is never duplicated (spec §27).",
    ]
    rows = [
        [_btn("\u270F\uFE0F Name", f"wsitecat:ename:{cid}"),
         _btn("\u270F\uFE0F Icon", f"wsitecat:eicon:{cid}"),
         _btn("\u270F\uFE0F Order", f"wsitecat:eorder:{cid}")],
        [_btn("\u270F\uFE0F Description", f"wsitecat:edesc:{cid}")],
        [_btn(("\U0001F7E2 Enabled: ON" if int(c["enabled"])
               else "\U0001F534 Enabled: OFF"), f"wsitecat:ten:{cid}"),
         _btn(("\U0001F441 Visible: ON" if int(c["visible"])
               else "\U0001F6E1 Visible: OFF"), f"wsitecat:tvis:{cid}"),
         _btn(("\U0001F51E 18+: ON" if int(c["age_restricted"])
               else "\U0001F51E 18+: OFF"), f"wsitecat:tage:{cid}")],
        [_btn(f"\U0001F4E6 Manage Payloads ({n})",
              f"wsitecat:payloads:{cid}")],
        [_btn("\U0001F5D1 Delete Category", f"wsitecat:del:{cid}")],
        [_btn("\u2B05\uFE0F Back to Categories", "wsitecat:main")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _category_flag_toggle(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any, cid: int, flag: str,
                                back_to_view: bool) -> None:
    """REAL toggle over a whitelisted boolean category field."""
    db = deps.db
    c = await _category_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Category not found.")
        await categories_panel(update, context, deps)
        return
    new_val = 0 if int(c[flag]) else 1
    ok = await db.update_website_category_fields(
        int(cid), {flag: new_val})
    await deps.log_admin_action(
        int(update.effective_user.id), "website_category_toggle",
        "website_category", int(cid), f"field={flag} value={new_val}")
    label = {"enabled": "enabled", "visible": "visible",
             "age_restricted": "age 18+"}[flag]
    await deps.safe_answer_callback(
        update.callback_query,
        f"Category {label} {'ON' if new_val else 'OFF'}."
        if ok else "Nothing changed.")
    if back_to_view:
        await category_view(update, context, deps, int(cid))
    else:
        await categories_panel(update, context, deps)


async def category_delete_confirm(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  deps: Any, cid: int) -> None:
    db = deps.db
    c = await _category_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Category not found.")
        await categories_panel(update, context, deps)
        return
    counts = await db.category_payload_counts()
    n = int(counts.get(int(cid), 0))
    rows = [
        [_btn("\u274C YES, delete category", f"wsitecat:delconfirm:{cid}")],
        [_btn("\u2B05\uFE0F Cancel (keep category)",
              f"wsitecat:view:{cid}")],
    ]
    await deps.safe_edit_text(
        update.callback_query,
        "\u26A0\uFE0F DELETE CATEGORY\n\n"
        f"#{int(cid)} {_truncate(c['name'], 40)} ({_truncate(c['slug'], 40)})\n\n"
        f"This deletes the category and its {n} membership link(s) ONLY.\n"
        "The website listings, their canonical Payloads and all media are\n"
        "NEVER deleted (spec §27 — memberships are references).\n\n"
        "Continue?",
        reply_markup=_kb(rows))


async def category_delete_execute(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  deps: Any, cid: int) -> None:
    db = deps.db
    ok = await db.delete_website_category(int(cid))
    await deps.log_admin_action(
        int(update.effective_user.id), "website_category_delete",
        "website_category", int(cid),
        "memberships-only deletion; listings untouched")
    await deps.safe_answer_callback(
        update.callback_query,
        "Category deleted (listings and media untouched)."
        if ok else "Could not delete the category.")
    await categories_panel(update, context, deps)


# -------------------------------------------------- payloads membership
async def _category_member_rows(db: Any, cid: int
                                ) -> List[Dict[str, Any]]:
    """Current member listings of one category (title + opaque, ordered)."""
    ids = await db.list_website_listing_ids_for_category(int(cid))
    out: List[Dict[str, Any]] = []
    for lid in ids:
        row = await db.get_website_payload_by_dbid(int(lid))
        if row is None:
            continue  # membership outlived its listing — hidden, honest
        out.append({"lid": int(row["id"]),
                    "title": _truncate(
                        row["title"] or row["collection_id"]
                        or f"listing #{int(row['id'])}", 48),
                    "opaque": _truncate(row["opaque_id"], 16),
                    "published": int(row["published"] or 0)})
    return out


async def category_payloads_panel(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  deps: Any, cid: int, page: int = 1) -> None:
    db = deps.db
    c = await _category_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Category not found.")
        await categories_panel(update, context, deps)
        return
    members = await _category_member_rows(db, cid)
    page = max(1, int(page or 1))
    pages = _pages(len(members))
    page = min(page, pages)
    chunk = members[(page - 1) * GAP_ADMIN_PAGE_SIZE:
                    (page - 1) * GAP_ADMIN_PAGE_SIZE + GAP_ADMIN_PAGE_SIZE]
    lines = [
        f"\U0001F4E6 CATEGORY PAYLOADS — {_truncate(c['name'], 40)}",
        "",
    ]
    if not chunk:
        lines.append("No listings in this category yet.")
        lines.append("Use Add Existing Payload to assign one.")
    for m in chunk:
        pub = "\U0001F7E2" if m["published"] else "\u26A0\uFE0F"
        lines.append(f"\u2022 {m['title']} — {m['opaque']} {pub}")
    lines += ["", f"Page {page}/{pages} — {len(members)} listing(s). "
              "Removing a membership never deletes the listing."]
    rows: List[List[InlineKeyboardButton]] = []
    for m in chunk:
        rows.append([_btn(f"\u2716 {m['title'][:30]}",
                          f"wsitecat:premove:{cid}:{m['lid']}")])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsitecat:ppage:{cid}:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsitecat:ppage:{cid}:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [
        [_btn("\u2795 Add Existing Payload", f"wsitecat:padd:{cid}")],
        [_btn("\u2B05\uFE0F Back to Category", f"wsitecat:view:{cid}")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _unassigned_listing_rows(db: Any, cid: int
                                   ) -> List[Dict[str, Any]]:
    """Website listings NOT yet assigned to this category (bounded sweep
    over the admin listing pages — references only, never media)."""
    member_ids: set = set()
    try:
        member_ids = set(await db.list_website_listing_ids_for_category(
            int(cid)))
    except Exception:  # noqa: BLE001
        member_ids = set()
    out: List[Dict[str, Any]] = []
    for page in range(1, 11):  # bounded: first 500 listings max
        rows, _total = await db.list_website_payloads_admin(
            page=page, page_size=50)
        if not rows:
            break
        for r in rows:
            if int(r["wdbid"]) in member_ids:
                continue
            out.append({"lid": int(r["wdbid"]),
                        "title": _truncate(r["eff_title"] or
                                           f"listing #{int(r['wdbid'])}", 48),
                        "opaque": _truncate(r["opaque_id"], 16),
                        "published": int(r["published"] or 0)})
        if len(rows) < 50:
            break
    return out[:500]


async def category_add_payload_panel(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE,
                                     deps: Any, cid: int,
                                     page: int = 1) -> None:
    db = deps.db
    c = await _category_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Category not found.")
        await categories_panel(update, context, deps)
        return
    unassigned = await _unassigned_listing_rows(db, cid)
    page = max(1, int(page or 1))
    pages = _pages(len(unassigned))
    page = min(page, pages)
    chunk = unassigned[(page - 1) * GAP_ADMIN_PAGE_SIZE:
                       (page - 1) * GAP_ADMIN_PAGE_SIZE + GAP_ADMIN_PAGE_SIZE]
    lines = [
        f"\u2795 ADD EXISTING PAYLOAD — {_truncate(c['name'], 40)}",
        "",
        "Listings not yet in this category:",
        "",
    ]
    if not chunk:
        lines.append("No unassigned listings available.")
        lines.append("Create a Website listing first (Add Website Payload).")
    for m in chunk:
        pub = "\U0001F7E2" if m["published"] else "\u26A0\uFE0F"
        lines.append(f"\u2022 {m['title']} — {m['opaque']} {pub}")
    lines += ["", f"Page {page}/{pages} — {len(unassigned)} listing(s). "
              "Assigning REFERENCES the existing listing — media is never "
              "duplicated (spec §27)."]
    rows: List[List[InlineKeyboardButton]] = []
    for m in chunk:
        rows.append([_btn(f"\u2795 {m['title'][:30]}",
                          f"wsitecat:paddgo:{cid}:{m['lid']}")])
    nav = []
    if page > 1:
        nav.append(_btn("\u2190 Prev", f"wsitecat:papage:{cid}:{page-1}"))
    if page < pages:
        nav.append(_btn("Next \u2192", f"wsitecat:papage:{cid}:{page+1}"))
    if nav:
        rows.append(nav)
    rows += [
        [_btn("\u2B05\uFE0F Back to Category Payloads",
              f"wsitecat:payloads:{cid}")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def category_add_payload_execute(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int, lid: int) -> None:
    """Assign an EXISTING listing to the category (a reference, never a
    media copy — spec §27)."""
    db = deps.db
    listing = await db.get_website_payload_by_dbid(int(lid))
    if listing is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Listing not found.")
        await category_add_payload_panel(update, context, deps, int(cid))
        return
    ok = await db.add_website_payload_to_category(int(lid), int(cid))
    await deps.log_admin_action(
        int(update.effective_user.id),
        "website_category_add_payload", "website_category", int(cid),
        f"listing={int(lid)} reference_only")
    await deps.safe_answer_callback(
        update.callback_query,
        "Listing added to the category (reference only — media never "
        "duplicated)." if ok else
        "Already in this category (or assignment failed).")
    await category_payloads_panel(update, context, deps, int(cid))


async def category_remove_payload(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int, lid: int) -> None:
    db = deps.db
    ok = await db.remove_website_payload_from_category(int(lid), int(cid))
    await deps.log_admin_action(
        int(update.effective_user.id),
        "website_category_remove_payload", "website_category", int(cid),
        f"listing={int(lid)}")
    await deps.safe_answer_callback(
        update.callback_query,
        "Listing removed from the category (the listing itself is "
        "untouched)." if ok else "Not in this category.")
    await category_payloads_panel(update, context, deps, int(cid))


# ------------------------------------------- New Category wizard (§26)
async def category_wizard_start(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    """Step 1/4 — NAME."""
    _cat_wiz_clear(context)
    context.user_data[WSITECAT_WIZARD_KEY] = {
        "step": "name", "name": None, "slug": None,
        "icon": None, "order": None,
    }
    rows = [[_btn("\u274C Cancel", "wsitecat:wcancel")]]
    await deps.safe_edit_text(
        update.callback_query,
        "\u2795 NEW CATEGORY — Step 1/4: Name\n\n"
        "Send the category NAME (1-60 chars, or cancel).\n\n"
        "Next: slug (auto-normalized) \u2192 icon \u2192 order.",
        reply_markup=_kb(rows))


async def category_wizard_ask(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, step: str,
                              extra: str = "") -> None:
    prompts = {
        "slug": ("Step 2/4: Slug\n\n"
                 "Send the category slug (used in URLs and category "
                 "filters).\nIt is AUTO-NORMALIZED: lowercase, anything "
                 "other than\nletters/digits/dashes becomes a dash "
                 "(e.g. 'Sci Fi!' \u2192 'sci-fi').\nSend '-' to derive it "
                 "from the name. Or cancel."),
        "icon": ("Step 3/4: Icon\n\n"
                 "Send the category ICON (a single emoji, or '-' for "
                 "none).\nOr cancel."),
        "order": ("Step 4/4: Order\n\n"
                  "Send the sort ORDER, a whole number 0+ (lower shows "
                  "first;\n'-' = 0). Or cancel."),
    }
    rows = [[_btn("\u274C Cancel", "wsitecat:wcancel")]]
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2795 NEW CATEGORY — " + prompts[step] + extra,
        reply_markup=_kb(rows))


async def category_wizard_finish(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    """Create the category from the collected wizard state."""
    db = deps.db
    st = _cat_wiz_get(context)
    if not st or st.get("step") != "create":
        await category_wizard_start(update, context, deps)
        return
    name = str(st.get("name") or "").strip()
    slug = str(st.get("slug") or "").strip()
    icon = str(st.get("icon") or "")
    order = int(st.get("order") or 0)
    new_id = await db.create_website_category(
        name=name, slug=slug, icon=icon, sort_order=order,
        enabled=1, visible=1, description="",
        age_restricted=0)
    if new_id is None:
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Could not create the category (duplicate slug or "
            "invalid name/slug). Nothing was saved. Send a different "
            "slug, or cancel.",
            reply_markup=_kb([[_btn("\u274C Cancel", "wsitecat:wcancel")]]))
        st["step"] = "slug"
        return
    _cat_wiz_clear(context)
    await deps.log_admin_action(
        int(update.effective_user.id), "website_category_create",
        "website_category", int(new_id),
        f"slug={_slug_normalize(slug)} order={order}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Category created.\n\n"
        f"ID: {int(new_id)}\nName: {name[:40]}\n"
        f"Slug: {_slug_normalize(slug)}\n"
        "Assign listings from the category's Manage Payloads.",
        reply_markup=_kb([
            [_btn("\U0001F5C2 Open category", f"wsitecat:view:{int(new_id)}"),
             _btn("\U0001F5C2 All categories", "wsitecat:main")]]))


async def category_wizard_cancel(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE,
                                 deps: Any) -> None:
    _cat_wiz_clear(context)
    await deps.safe_answer_callback(
        update.callback_query, "Wizard cancelled — nothing was saved.")
    await categories_panel(update, context, deps)


# --------------------------------------------- per-category text editors
async def category_edit_prompt(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, field: str, cid: int) -> None:
    prompts = {
        "name": "Send the new category NAME (1-60 chars, or cancel):",
        "icon": ("Send the new category ICON (a single emoji, or '-' for "
                 "none; or cancel):"),
        "order": ("Send the new sort ORDER, whole number 0+ (lower shows "
                  "first; or cancel):"),
        "description": ("Send the new DESCRIPTION (or '-' to clear it; "
                        "or cancel):"),
    }
    if field not in prompts:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown editor.")
        return
    context.user_data[WSITECAT_EDIT_KEY] = {"field": field, "cid": int(cid)}
    await deps.safe_edit_text(
        update.callback_query, "\u270F\uFE0F " + prompts[field],
        reply_markup=_kb([[_btn("\u274C Cancel",
                                f"wsitecat:view:{int(cid)}")]]))


async def _category_edit_text(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, ed: Dict[str, Any],
                              text: str) -> bool:
    db = deps.db
    cid = int(ed.get("cid") or 0)
    field = str(ed.get("field") or "")
    if text.lower() in ("/cancel", "cancel"):
        _cat_edit_clear(context)
        await deps.reply_protected(update,
                                   "\u274C Cancelled — not changed.")
        return True
    value = text.strip()
    fields: Dict[str, Any]
    if field == "order":
        try:
            fields = {"sort_order": max(0, min(100000, int(value)))}
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Order must be a whole number (0+). Send again, "
                "or cancel.")
            return True
    elif field == "icon":
        fields = {"icon": "" if value == "-" else value[:16]}
    elif field == "description":
        fields = {"description": "" if value == "-" else value[:500]}
    elif field == "name":
        if not value:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The name cannot be empty. Send again, or cancel.")
            return True
        fields = {"name": value[:60]}
    else:
        return False
    ok = await db.update_website_category_fields(cid, fields)
    _cat_edit_clear(context)
    await deps.log_admin_action(
        int(update.effective_user.id), "website_category_edit",
        "website_category", cid, f"field={field}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Saved." if ok else "\u26A0\uFE0F Nothing changed.",
        reply_markup=_kb([[_btn("\u2B05\uFE0F Back to category",
                                f"wsitecat:view:{cid}")]]))
    return True


# ============================================================
# 📢 ADS panel (spec §35-§56)
# ============================================================

async def ads_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                    deps: Any) -> None:
    """The Ads Management main panel — master switch, exempt users,
    campaigns, placements, analytics."""
    db = deps.db
    try:
        master = await db.get_setting_bool("ads_enabled", False)
    except Exception:  # noqa: BLE001
        master = False
    camps = await db.list_ad_campaigns(include_disabled=True)
    creatives = await db.list_ad_creatives(None, include_disabled=True)
    active = sum(1 for c in camps
                 if str(c["status"]) == "active" and int(c["enabled"]))
    try:
        exempt_n = len(await db.list_ad_exempt_users())
    except Exception:  # noqa: BLE001
        exempt_n = 0
    lines = [
        "\U0001F4E2 ADS MANAGEMENT (GAP-CLOSURE \u00A735-\u00A756)",
        "",
        f"Master switch: {'\U0001F7E2 ON' if master else '\U0001F534 OFF'} "
        "(ads_enabled)",
        f"Exempt users: {exempt_n} (admins are always exempt — \u00A746)",
        f"Campaigns: {len(camps)} total, {active} active",
        f"Creatives: {len(creatives)}",
        "",
        "Ads NEVER block content (\u00A744): every ad failure degrades to",
        "'no ad'. Frequency is stored server-side keyed by the",
        "authenticated Telegram identity (\u00A752).",
    ]
    rows = [
        [_btn(("\U0001F7E2 Ads ON — turn OFF" if master
               else "\U0001F534 Ads OFF — turn ON"), "wsad:master")],
        [_btn(f"\U0001F465 Exempt Users ({exempt_n})", "wsad:exempt")],
        [_btn(f"\U0001F4CB Campaigns ({len(camps)})", "wsad:camps")],
        [_btn("\u2795 New Campaign", "wsad:cnew")],
        [_btn("\U0001F4CD Placements", "wsad:placements")],
        [_btn("\U0001F4CA Analytics (7d)", "wsad:analytics")],
        [_btn("\u2B05\uFE0F Back to Website Control", "panel:website")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_master_toggle(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any) -> None:
    """REAL toggle: the ads_enabled master switch (spec §38)."""
    db = deps.db
    try:
        cur = await db.get_setting_bool("ads_enabled", False)
    except Exception:  # noqa: BLE001
        cur = False
    await db.set_setting("ads_enabled", "false" if cur else "true")
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_master_toggle", "setting", None,
        f"ads_enabled={'false' if cur else 'true'}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Ads {'disabled' if cur else 'enabled'} "
        "(placements still apply individually).")
    await ads_panel(update, context, deps)


# ------------------------------------------------------- exempt users
async def ads_exempt_panel(update: Update,
                           context: ContextTypes.DEFAULT_TYPE,
                           deps: Any) -> None:
    db = deps.db
    try:
        ids = await db.list_ad_exempt_users()
    except Exception:  # noqa: BLE001
        ids = []
    lines = [
        "\U0001F465 ADS-EXEMPT USERS",
        "",
        "Exempt users NEVER see ads. The list is backend-controlled",
        "(spec §46 — never localStorage); admins are always exempt.",
        "",
    ]
    if not ids:
        lines.append("(no exempt users yet)")
    for uid in ids[:GAP_ADMIN_PAGE_SIZE * 3]:
        lines.append(f"\u2022 {int(uid)}")
    if len(ids) > GAP_ADMIN_PAGE_SIZE * 3:
        lines.append(f"\u2022 … {len(ids) - GAP_ADMIN_PAGE_SIZE * 3} more")
    lines += ["", f"{len(ids)} user(s)."]
    rows: List[List[InlineKeyboardButton]] = []
    for uid in ids[:GAP_ADMIN_PAGE_SIZE * 3]:
        rows.append([_btn(f"\u2716 Remove {int(uid)}",
                          f"wsad:exdel:{int(uid)}")])
    rows += [
        [_btn("\u2795 Add Exempt User ID", "wsad:exadd")],
        [_btn("\u2B05\uFE0F Back to Ads Management", "wsad:main")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _ads_exempt_write(db: Any, ids: List[int]) -> None:
    await db.set_setting("ads_exempt_user_ids",
                         json.dumps(sorted(set(int(i) for i in ids))))


async def ads_exempt_remove(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any, uid: int) -> None:
    db = deps.db
    ids = await db.list_ad_exempt_users()
    ids = [i for i in ids if int(i) != int(uid)]
    await _ads_exempt_write(db, ids)
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_exempt_remove", "setting", None,
        f"users={len(ids)}")
    await deps.safe_answer_callback(update.callback_query,
                                    "User removed from the exempt list.")
    await ads_exempt_panel(update, context, deps)


# --------------------------------------------------------- campaigns
async def ads_campaigns_panel(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    db = deps.db
    camps = await db.list_ad_campaigns(include_disabled=True)
    chunk = camps[:GAP_ADMIN_PAGE_SIZE]
    lines = ["\U0001F4CB AD CAMPAIGNS", ""]
    if not chunk:
        lines.append("No campaigns yet.")
        lines.append("Use New Campaign (a draft is created first).")
    for c in chunk:
        enabled = "\U0001F7E2" if int(c["enabled"]) else "\U0001F534"
        creatives = await db.list_ad_creatives(int(c["id"]),
                                               include_disabled=True)
        lines.append(
            f"#{int(c['id'])} {_truncate(c['name'], 40)} — "
            f"{str(c['status'])}, priority {int(c['priority'])}, "
            f"{enabled} enabled, {len(creatives)} creative(s)")
    if len(camps) > len(chunk):
        lines.append(f"\u2022 … {len(camps) - len(chunk)} more "
                     "(showing the first "
                     f"{GAP_ADMIN_PAGE_SIZE})")
    lines += ["", f"{len(camps)} campaign(s) — priority order decides "
              "which campaign wins a placement."]
    rows: List[List[InlineKeyboardButton]] = []
    for c in chunk:
        rows.append([_btn(f"#{int(c['id'])} {_truncate(c['name'], 30)}",
                          f"wsad:cview:{int(c['id'])}")])
    rows += [
        [_btn("\u2795 New Campaign", "wsad:cnew")],
        [_btn("\u2B05\uFE0F Back to Ads Management", "wsad:main")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _campaign_get(db: Any, cid: int):
    try:
        return await db.get_ad_campaign(int(cid))
    except Exception:  # noqa: BLE001
        return None


async def _campaign_view_lines(db: Any, c: Any) -> List[str]:
    creatives = await db.list_ad_creatives(int(c["id"]), include_disabled=True)
    start = _truncate(c["start_at"], 16) or "(not set)"
    end = _truncate(c["end_at"], 16) or "(not set)"
    return [
        f"\U0001F4CB CAMPAIGN #{int(c['id'])} — {_truncate(c['name'], 40)}",
        "",
        f"Name: {_truncate(c['name'], 80)}",
        f"Status: {str(c['status'])}",
        f"Priority: {int(c['priority'])}",
        f"Enabled: {'\U0001F7E2' if int(c['enabled']) else '\U0001F534'} "
        f"{_yn(bool(int(c['enabled'])))}",
        f"Schedule: {start} \u2192 {end} (YYYY-MM-DDTHH:MM)",
        f"Frequency cap: {int(c['frequency_cap_per_user'])} per user / "
        f"{int(c['frequency_cap_hours'])}h window (0 = unlimited)",
        f"Creatives: {len(creatives)}",
    ]


async def ads_campaign_view(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    lines = await _campaign_view_lines(db, c)
    rows = [
        [_btn("\u270F\uFE0F Name", f"wsad:cename:{cid}")],
        [_btn(f"\U0001F4CB Status: {str(c['status'])}",
              f"wsad:cstatus:{cid}")],
        [_btn("\u270F\uFE0F Priority", f"wsad:ceprio:{cid}"),
         _btn("\u270F\uFE0F Freq Cap", f"wsad:cecap:{cid}"),
         _btn("\u270F\uFE0F Freq Window", f"wsad:cewin:{cid}")],
        [_btn("\u270F\uFE0F Start At", f"wsad:cestart:{cid}"),
         _btn("\u270F\uFE0F End At", f"wsad:ceend:{cid}")],
        [_btn(("\U0001F7E2 Enabled: ON" if int(c["enabled"])
               else "\U0001F534 Enabled: OFF"), f"wsad:cetoggle:{cid}")],
        [_btn("\U0001F3AC Creatives", f"wsad:creatives:{cid}")],
        [_btn("\U0001F5D1 Delete Campaign", f"wsad:cdel:{cid}")],
        [_btn("\u2B05\uFE0F Back to Campaigns", "wsad:camps")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_campaign_status_chooser(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    lines = [
        f"\U0001F4CB CAMPAIGN STATUS — {_truncate(c['name'], 40)}",
        "",
        f"Current: {str(c['status'])}",
        "",
        "Only 'active' campaigns serve ads (schedule + enabled still",
        "apply). Choose the new status:",
    ]
    rows = [
        [_btn("\U0001F4DD Draft", f"wsad:cstatusset:{cid}:draft"),
         _btn("\u25B6\uFE0F Active", f"wsad:cstatusset:{cid}:active")],
        [_btn("\u23F8 Paused", f"wsad:cstatusset:{cid}:paused"),
         _btn("\U0001F3C1 Ended", f"wsad:cstatusset:{cid}:ended")],
        [_btn("\u2B05\uFE0F Back to campaign", f"wsad:cview:{cid}")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_campaign_status_set(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int, status: str) -> None:
    if status not in AD_CAMPAIGN_STATUSES:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown status.")
        await ads_campaign_view(update, context, deps, int(cid))
        return
    db = deps.db
    ok = await db.update_ad_campaign_fields(int(cid), {"status": status})
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_campaign_status",
        "ad_campaign", int(cid), f"status={status}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Status set to {status}." if ok else "Nothing changed.")
    await ads_campaign_view(update, context, deps, int(cid))


async def ads_campaign_toggle(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    new_val = 0 if int(c["enabled"]) else 1
    ok = await db.update_ad_campaign_fields(int(cid),
                                            {"enabled": new_val})
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_campaign_toggle",
        "ad_campaign", int(cid), f"enabled={new_val}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Campaign {'enabled' if new_val else 'disabled'}."
        if ok else "Nothing changed.")
    await ads_campaign_view(update, context, deps, int(cid))


async def ads_campaign_delete_confirm(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    creatives = await db.list_ad_creatives(int(cid), include_disabled=True)
    rows = [
        [_btn("\u274C YES, delete campaign", f"wsad:cdelyes:{cid}")],
        [_btn("\u2B05\uFE0F Cancel (keep campaign)", f"wsad:cview:{cid}")],
    ]
    await deps.safe_edit_text(
        update.callback_query,
        "\u26A0\uFE0F DELETE CAMPAIGN\n\n"
        f"#{int(cid)} {_truncate(c['name'], 40)}\n\n"
        f"This deletes the campaign and its {len(creatives)} "
        "creative(s).\n"
        "Recorded ad events stay (analytics/audit trail).\n"
        "No content and no canonical Payload is ever touched.\n\n"
        "Continue?",
        reply_markup=_kb(rows))


async def ads_campaign_delete_execute(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int) -> None:
    db = deps.db
    ok = await db.delete_ad_campaign(int(cid))
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_campaign_delete",
        "ad_campaign", int(cid), "campaign+creatives")
    await deps.safe_answer_callback(
        update.callback_query,
        "Campaign deleted." if ok else "Could not delete the campaign.")
    await ads_campaigns_panel(update, context, deps)


async def ads_campaign_edit_prompt(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, field: str, cid: int) -> None:
    prompts = {
        "cname": "Send the new campaign NAME (1-80 chars, or cancel):",
        "cprio": ("Send the new PRIORITY, whole number 0+ (higher wins "
                  "the placement; or cancel):"),
        "cstart": ("Send the START date/time as YYYY-MM-DDTHH:MM\n"
                   "(e.g. 2026-01-31T09:00), or '-' to clear it, "
                   "or cancel:"),
        "cend": ("Send the END date/time as YYYY-MM-DDTHH:MM\n"
                 "(e.g. 2026-03-01T23:59), or '-' to clear it, "
                 "or cancel:"),
        "ccap": ("Send the FREQUENCY CAP per user, whole number 0+ "
                 "(0 = unlimited; or cancel):"),
        "cwin": ("Send the frequency-cap WINDOW in hours, whole number "
                 "1-8760 (default 24; or cancel):"),
        "exadd": ("Send the Telegram USER ID to exempt from ads\n"
                  "(a whole number; or cancel):"),
    }
    if field not in prompts:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown editor.")
        return
    context.user_data[WSAD_EDIT_KEY] = {"field": field, "cid": int(cid)}
    back = "wsad:main" if field == "exadd" else f"wsad:cview:{int(cid)}"
    await deps.safe_edit_text(
        update.callback_query, "\u270F\uFE0F " + prompts[field],
        reply_markup=_kb([[_btn("\u274C Cancel", back)]]))


async def _campaign_edit_text(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, ed: Dict[str, Any],
                              text: str) -> bool:
    db = deps.db
    field = str(ed.get("field") or "")
    cid = int(ed.get("cid") or 0)
    if text.lower() in ("/cancel", "cancel"):
        _ad_edit_clear(context)
        await deps.reply_protected(update, "\u274C Cancelled — not changed.")
        return True
    value = text.strip()
    fields: Dict[str, Any]
    if field == "cname":
        if not value:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The name cannot be empty. Send again, or cancel.")
            return True
        fields = {"name": value[:80]}
    elif field == "cprio":
        try:
            fields = {"priority": max(0, min(1000000, int(value)))}
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Priority must be a whole number (0+). Send again, "
                "or cancel.")
            return True
    elif field in ("cstart", "cend"):
        if value == "-":
            fields = {"start_at" if field == "cstart" else "end_at": None}
        else:
            try:
                dt = datetime.fromisoformat(value)
                fields = {
                    "start_at" if field == "cstart" else "end_at":
                    dt.strftime("%Y-%m-%dT%H:%M")}
            except ValueError:
                await deps.safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u274C Not a valid date/time. Use YYYY-MM-DDTHH:MM "
                    "(e.g. 2026-01-31T09:00), or '-' to clear. Send "
                    "again, or cancel.")
                return True
    elif field == "ccap":
        try:
            fields = {"frequency_cap_per_user": max(0, min(1000, int(value)))}
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The cap must be a whole number (0 = unlimited). "
                "Send again, or cancel.")
            return True
    elif field == "cwin":
        try:
            fields = {"frequency_cap_hours": max(1, min(8760, int(value)))}
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The window must be whole hours (1-8760). Send "
                "again, or cancel.")
            return True
    else:
        return False
    ok = await db.update_ad_campaign_fields(cid, fields)
    _ad_edit_clear(context)
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_campaign_edit", "ad_campaign",
        cid, f"field={field}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Saved." if ok else "\u26A0\uFE0F Nothing changed.",
        reply_markup=_kb([[_btn("\u2B05\uFE0F Back to campaign",
                                f"wsad:cview:{cid}")]]))
    return True


async def ads_exempt_add_text(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, text: str) -> bool:
    """The [Add Exempt User ID] text input (spec §46 — backend list)."""
    db = deps.db
    if text.lower() in ("/cancel", "cancel"):
        _ad_edit_clear(context)
        await deps.reply_protected(update, "\u274C Cancelled — not changed.")
        return True
    value = text.strip().replace("@", "")
    if not value.isdigit():
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Send a numeric Telegram user ID (e.g. 8370454312), "
            "or cancel.")
        return True
    uid = int(value)
    ids = await db.list_ad_exempt_users()
    if uid in ids:
        _ad_edit_clear(context)
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2139\uFE0F That user is already exempt.",
            reply_markup=_kb([[_btn("\U0001F465 Exempt Users",
                                    "wsad:exempt")]]))
        return True
    ids.append(uid)
    await _ads_exempt_write(db, ids)
    _ad_edit_clear(context)
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_exempt_add", "setting", None,
        f"users={len(ids)}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 User added to the ads-exempt list (they will never see "
        "ads).",
        reply_markup=_kb([[_btn("\U0001F465 Exempt Users", "wsad:exempt")]]))
    return True


# --------------------------------------------------------- creatives
async def ads_creatives_panel(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    creatives = await db.list_ad_creatives(int(cid), include_disabled=True)
    chunk = creatives[:GAP_ADMIN_PAGE_SIZE]
    lines = [
        f"\U0001F3AC CAMPAIGN CREATIVES — {_truncate(c['name'], 40)}",
        "",
    ]
    if not chunk:
        lines.append("No creatives yet.")
        lines.append("Use New Creative (kind \u2192 fields \u2192 validate).")
    for cr in chunk:
        enabled = "\U0001F7E2" if int(cr["enabled"]) else "\U0001F534"
        title = _truncate(cr["title"], 32) or "(untitled)"
        lines.append(f"#{int(cr['id'])} {str(cr['kind'])} — "
                     f"{title} {enabled}")
    if len(creatives) > len(chunk):
        lines.append(f"\u2022 … {len(creatives) - len(chunk)} more")
    lines += ["", f"{len(creatives)} creative(s). Every creative URL is "
              "validated HTTPS-only on every write (\u00A748)."]
    rows: List[List[InlineKeyboardButton]] = []
    for cr in chunk:
        title = _truncate(cr["title"], 24) or "(untitled)"
        rows.append([_btn(f"#{int(cr['id'])} {str(cr['kind'])} — {title}",
                          f"wsad:crview:{int(cr['id'])}")])
    rows += [
        [_btn("\u2795 New Creative", f"wsad:crnew:{int(cid)}")],
        [_btn("\u2B05\uFE0F Back to campaign", f"wsad:cview:{int(cid)}")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def _creative_get(db: Any, crid: int):
    try:
        return await db.get_ad_creative(int(crid))
    except Exception:  # noqa: BLE001
        return None


def _url_line(label: str, raw: Any) -> str:
    """Render a creative URL honestly: validated HTTPS, invalid, or unset.
    Render-time re-validation — a forged/expired URL shows as INVALID."""
    if raw is None or not str(raw).strip():
        return f"{label}: (not set)"
    val = validate_ad_url(str(raw))
    if val is None:
        return f"{label}: \u26A0\uFE0F INVALID (rejected — not HTTPS)"
    return f"{label}: \u2705 {_truncate(val, 60)}"


async def ads_creative_view(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any, crid: int) -> None:
    db = deps.db
    cr = await _creative_get(db, crid)
    if cr is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Creative not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    kind = str(cr["kind"])
    lines = [
        f"\U0001F3AC CREATIVE #{int(cr['id'])} (campaign "
        f"#{int(cr['campaign_id'])})",
        "",
        f"Kind: {kind}",
        f"Title: {_truncate(cr['title'], 60) or '(none)'}",
        f"Alt text: {_truncate(cr['alt_text'], 60) or '(none)'}",
        _url_line("Click URL", cr["click_url"]),
        f"Duration: {int(cr['duration_seconds'])}s",
        f"Skippable: {_yn(bool(int(cr['skip_enabled'])))}"
        + (f", after {int(cr['skip_after_seconds'])}s"
           if int(cr["skip_enabled"]) else ""),
        f"Enabled: {'\U0001F7E2' if int(cr['enabled']) else '\U0001F534'} "
        f"{_yn(bool(int(cr['enabled'])))}",
    ]
    if kind == "video":
        lines.insert(5, _url_line("Video URL", cr["video_url"]))
    if kind in ("banner_image", "banner_responsive"):
        lines.insert(5, _url_line("Desktop image", cr["image_desktop_url"]))
        lines.insert(6, _url_line("Mobile image", cr["image_mobile_url"]))
    if kind == "html":
        html_len = len(str(cr["html_content"] or ""))
        lines.insert(5, f"HTML content: {html_len} char(s) "
                        "(preview shows the SANITIZED source)")
    if kind == "provider":
        lines.insert(5, f"Provider zone: {_truncate(cr['provider_zone'], 64)}"
                        )
    rows = [
        [_btn("\U0001F441 Preview", f"wsad:crpreview:{int(cr['id'])}")],
        [_btn(("\U0001F7E2 Enabled: ON" if int(cr["enabled"])
               else "\U0001F534 Enabled: OFF"),
              f"wsad:crtoggle:{int(cr['id'])}")],
        [_btn("\U0001F5D1 Delete Creative", f"wsad:crdel:{int(cr['id'])}")],
        [_btn("\u2B05\uFE0F Back to creatives",
              f"wsad:creatives:{int(cr['campaign_id'])}")],
    ]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_creative_toggle(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any, crid: int) -> None:
    db = deps.db
    cr = await _creative_get(db, crid)
    if cr is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Creative not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    new_val = 0 if int(cr["enabled"]) else 1
    ok = await db.update_ad_creative_fields(int(crid),
                                            {"enabled": new_val})
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_creative_toggle",
        "ad_creative", int(crid), f"enabled={new_val}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"Creative {'enabled' if new_val else 'disabled'}."
        if ok else "Nothing changed.")
    await ads_creative_view(update, context, deps, int(crid))


async def ads_creative_delete_confirm(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, crid: int) -> None:
    db = deps.db
    cr = await _creative_get(db, crid)
    if cr is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Creative not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    rows = [
        [_btn("\u274C YES, delete creative", f"wsad:crdelyes:{int(crid)}")],
        [_btn("\u2B05\uFE0F Cancel (keep creative)",
              f"wsad:crview:{int(crid)}")],
    ]
    await deps.safe_edit_text(
        update.callback_query,
        "\u26A0\uFE0F DELETE CREATIVE\n\n"
        f"#{int(crid)} {str(cr['kind'])} — "
        f"{_truncate(cr['title'], 40) or '(untitled)'}\n\n"
        "Recorded ad events stay (analytics/audit trail).\n\n"
        "Continue?",
        reply_markup=_kb(rows))


async def ads_creative_delete_execute(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, crid: int) -> None:
    db = deps.db
    cr = await _creative_get(db, crid)
    campaign_id = int(cr["campaign_id"]) if cr is not None else 0
    ok = await db.delete_ad_creative(int(crid))
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_creative_delete",
        "ad_creative", int(crid), None)
    await deps.safe_answer_callback(
        update.callback_query,
        "Creative deleted." if ok else "Could not delete the creative.")
    if campaign_id:
        await ads_creatives_panel(update, context, deps, campaign_id)
    else:
        await ads_campaigns_panel(update, context, deps)


# --------------------------------------------- New Creative wizard (§36)
async def ads_creative_kind_chooser(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int) -> None:
    db = deps.db
    c = await _campaign_get(db, cid)
    if c is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Campaign not found.")
        await ads_campaigns_panel(update, context, deps)
        return
    lines = [
        "\u2795 NEW CREATIVE — choose the kind (spec \u00A736)",
        "",
        "video            \u2192 video_url (required)",
        "banner_image     \u2192 desktop/mobile image URL(s)",
        "banner_responsive \u2192 responsive image URLs",
        "html             \u2192 sanitized whitelist HTML",
        "provider         \u2192 ad-network provider zone",
        "",
        "EVERY URL must be HTTPS — http/javascript:/data:/file: are",
        "rejected before anything is saved (\u00A748).",
    ]
    rows: List[List[InlineKeyboardButton]] = []
    for kind in AD_CREATIVE_KINDS:
        rows.append([_btn(AD_CREATIVE_KIND_LABELS[kind],
                          f"wsad:crkind:{int(cid)}:{kind}")])
    rows.append([_btn("\u2B05\uFE0F Back to creatives",
                      f"wsad:creatives:{int(cid)}")])
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_creative_wizard_start(
        update: Update, context: ContextTypes.DEFAULT_TYPE,
        deps: Any, cid: int, kind: str) -> None:
    if kind not in AD_CREATIVE_KINDS:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown creative kind.")
        await ads_creative_kind_chooser(update, context, deps, int(cid))
        return
    _ad_wiz_clear(context)
    context.user_data[WSAD_WIZARD_KEY] = {
        "mode": "creative", "campaign_id": int(cid), "kind": kind,
        "step": _CREATIVE_STEPS[kind][0], "fields": {},
    }
    await _ads_creative_ask(update, context, deps)


async def _ads_creative_ask(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any) -> None:
    st = _ad_wiz_get(context)
    if not st:
        return
    step = str(st.get("step") or "")
    prompts = {
        "video_url": "Send the VIDEO URL (HTTPS ONLY — http/, javascript:,"
                     "\ndata:, file: are rejected), or cancel:",
        "image_desktop_url": "Send the DESKTOP image URL (HTTPS only — "
                             "required for this kind), or cancel:",
        "image_mobile_url": "Send the MOBILE image URL (HTTPS only, or '-' "
                            "to skip), or cancel:",
        "click_url": "Send the CLICK/landing URL (HTTPS only, or '-' to "
                     "skip), or cancel:",
        "title": "Send the creative TITLE (or '-' for none), or cancel:",
        "alt": "Send the ALT text (or '-' for none), or cancel:",
        "duration": "Send the DURATION in seconds (0-600, or '-' for 0), "
                    "or cancel:",
        "skip": "Should the video ad be skippable? Send 'yes' or 'no':",
        "skip_after": "Skip becomes available after how many seconds "
                      "(0-60, default 5)? Send the number, or cancel:",
        "html_content": "Send the HTML CONTENT for the creative. It is\n"
                        "stored as-is and SANITIZED at render (strict\n"
                        "whitelist — scripts/styles/iframes are dropped),"
                        "\nor cancel:",
        "provider_zone": "Send the ad-network PROVIDER ZONE identifier\n"
                         "(from your Monetag/provider dashboard), or "
                         "cancel:",
    }
    label = {
        "video_url": "\U0001F3AC New video creative — video URL",
        "image_desktop_url": "\U0001F5BC New banner — desktop image URL",
        "image_mobile_url": "\U0001F5BC New banner — mobile image URL",
        "click_url": "\U0001F517 Click / landing URL",
        "title": "\U0001F4DD Title",
        "alt": "\U0001F4DD Alt text",
        "duration": "\u23F1 Duration",
        "skip": "\u23ED Skippable?",
        "skip_after": "\u23ED Skip after seconds",
        "html_content": "\U0001F4DD New html creative — content",
        "provider_zone": "\U0001F517 New provider creative — zone",
    }.get(step, step)
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2795 " + label + "\n\n" + prompts.get(step, ""),
        reply_markup=_kb([[_btn("\u274C Cancel", "wsad:wcancel")]]))


async def _ads_creative_advance(update: Update,
                                context: ContextTypes.DEFAULT_TYPE,
                                deps: Any) -> None:
    """Move the creative wizard to its next step (or finish it)."""
    st = _ad_wiz_get(context)
    if not st:
        return
    steps = _CREATIVE_STEPS[str(st.get("kind"))]
    idx = steps.index(str(st.get("step")))
    if idx + 1 < len(steps):
        st["step"] = steps[idx + 1]
        await _ads_creative_ask(update, context, deps)
        return
    await _ads_creative_finish(update, context, deps)


async def _ads_creative_finish(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    """Create the creative from the collected (pre-validated) fields."""
    db = deps.db
    st = _ad_wiz_get(context)
    if not st:
        return
    f = st.get("fields") or {}
    campaign_id = int(st.get("campaign_id") or 0)
    kind = str(st.get("kind"))
    new_id = await db.create_ad_creative(
        campaign_id=campaign_id, kind=kind,
        title=str(f.get("title") or ""),
        video_url=f.get("video_url"),
        image_desktop_url=f.get("image_desktop_url"),
        image_mobile_url=f.get("image_mobile_url"),
        html_content=f.get("html_content"),
        click_url=f.get("click_url"),
        alt_text=str(f.get("alt") or ""),
        duration_seconds=int(f.get("duration") or 0),
        skip_enabled=1 if f.get("skip") == "yes" else 0,
        skip_after_seconds=int(f.get("skip_after") or 0),
        provider_zone=f.get("provider_zone"),
        enabled=1,
    )
    _ad_wiz_clear(context)
    if new_id is None:
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Could not create the creative (invalid data — nothing "
            "was saved). Start again from New Creative.",
            reply_markup=_kb([[_btn("\U0001F3AC Creatives",
                                    f"wsad:creatives:{campaign_id}")]]))
        return
    url_count = sum(1 for k in ("video_url", "image_desktop_url",
                                 "image_mobile_url", "click_url")
                    if f.get(k))
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_creative_create",
        "ad_creative", int(new_id),
        f"campaign={campaign_id} kind={kind} urls_validated={url_count}")
    await deps.safe_send_text(
        context.bot, update.effective_chat.id,
        "\u2705 Creative created (all URLs validated HTTPS-only).\n\n"
        f"Campaign: #{campaign_id}\nKind: {kind}\nCreative ID: "
        f"{int(new_id)}",
        reply_markup=_kb([
            [_btn("\U0001F3AC Open creative", f"wsad:crview:{int(new_id)}"),
             _btn("\U0001F3AC All creatives",
                  f"wsad:creatives:{campaign_id}")]]))


async def _ads_creative_text(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             deps: Any, st: Dict[str, Any],
                             text: str) -> bool:
    """One text step of the New Creative wizard. EVERY URL is validated
    through validate_ad_url before it is accepted (spec §48)."""
    step = str(st.get("step") or "")
    f: Dict[str, Any] = st.setdefault("fields", {})
    if text.lower() in ("/cancel", "cancel"):
        _ad_wiz_clear(context)
        await deps.reply_protected(
            update, "\u274C Cancelled — nothing was saved.")
        return True
    value = text.strip()
    url_steps = ("video_url", "image_desktop_url", "image_mobile_url",
                 "click_url")
    if step in url_steps:
        optional = step in ("image_mobile_url", "click_url")
        if optional and value == "-":
            f[step] = None
            await _ads_creative_advance(update, context, deps)
            return True
        val = validate_ad_url(value)
        if val is None:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C That is not a valid HTTPS URL. javascript:, data:,\n"
                "file: and plain http:// are REJECTED (spec \u00A748).\n"
                "Send an https://… URL"
                + (", or '-' to skip" if optional else "")
                + ", or cancel — nothing was saved.")
            return True
        f[step] = val
        await _ads_creative_advance(update, context, deps)
        return True
    if step in ("title", "alt"):
        f[step] = "" if value == "-" else value[:200]
        await _ads_creative_advance(update, context, deps)
        return True
    if step == "duration":
        if value == "-":
            value = "0"
        try:
            f["duration"] = max(0, min(600, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Duration must be whole seconds (0-600). Send "
                "again, or cancel.")
            return True
        await _ads_creative_advance(update, context, deps)
        return True
    if step == "skip":
        if value.lower() in ("yes", "y", "on", "true"):
            f["skip"] = "yes"
        elif value.lower() in ("no", "n", "off", "false"):
            f["skip"] = "no"
        else:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Send 'yes' or 'no', or cancel.")
            return True
        if f["skip"] == "no":
            f["skip_after"] = 0
            # jump PAST the skip_after prompt (nothing to ask)
            st["step"] = "skip_after"
            await _ads_creative_advance(update, context, deps)
            return True
        await _ads_creative_advance(update, context, deps)
        return True
    if step == "skip_after":
        if value == "-":
            value = "5"
        try:
            f["skip_after"] = max(0, min(60, int(value)))
        except ValueError:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Skip-after must be whole seconds (0-60). Send "
                "again, or cancel.")
            return True
        await _ads_creative_advance(update, context, deps)
        return True
    if step == "html_content":
        if not value:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The HTML content is required for html creatives. "
                "Send it again, or cancel.")
            return True
        f["html_content"] = value[:20000]
        await _ads_creative_advance(update, context, deps)
        return True
    if step == "provider_zone":
        if not value:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The provider zone is required. Send it again, "
                "or cancel.")
            return True
        f["provider_zone"] = value[:64]
        await _ads_creative_advance(update, context, deps)
        return True
    return False


# -------------------------------------------------- honest preview (§36)
async def ads_creative_preview(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, crid: int) -> None:
    """Send an HONEST preview of the creative to the ADMIN chat.

    The Bot API cannot upload arbitrary external media by URL, so the
    preview is a message with the title/metadata plus INLINE URL BUTTONS
    to the media/click URLs (never a fabricated upload). html creatives
    are sent as the SANITIZED source in plain text; provider creatives
    show the zone. Render-time URL re-validation: an invalid URL never
    renders a button.
    """
    db = deps.db
    cr = await _creative_get(db, crid)
    if cr is None:
        await deps.safe_answer_callback(update.callback_query,
                                        "Creative not found.")
        return
    kind = str(cr["kind"])
    chat_id = update.effective_chat.id
    buttons: List[List[InlineKeyboardButton]] = []
    media_url = validate_ad_url(str(cr["video_url"] or "")) \
        if kind == "video" else None
    if kind in ("banner_image", "banner_responsive"):
        media_url = (validate_ad_url(str(cr["image_desktop_url"] or ""))
                     or validate_ad_url(str(cr["image_mobile_url"] or "")))
    click_url = validate_ad_url(str(cr["click_url"] or ""))
    lines = [
        f"\U0001F441 CREATIVE PREVIEW #{int(cr['id'])} (admin-only)",
        "",
        f"Kind: {kind}",
        f"Title: {_truncate(cr['title'], 60) or '(none)'}",
        f"Alt text: {_truncate(cr['alt_text'], 60) or '(none)'}",
    ]
    if kind == "video":
        lines += [f"Duration: {int(cr['duration_seconds'])}s",
                  f"Skippable: {_yn(bool(int(cr['skip_enabled'])))}"
                  + (f" after {int(cr['skip_after_seconds'])}s"
                     if int(cr["skip_enabled"]) else "")]
    if kind == "provider":
        lines.append(f"Provider zone: {_truncate(cr['provider_zone'], 64)}")
    if media_url is None and kind in ("video", "banner_image",
                                      "banner_responsive"):
        lines += ["", "\u26A0\uFE0F This creative has NO valid HTTPS media "
                  "URL stored —", "it serves nothing at render time "
                  "(honest no-ad)."]
    lines += ["", "External media cannot be re-uploaded through the Bot "
              "API —", "open the URL button to check the real asset."]
    if media_url is not None:
        buttons.append([InlineKeyboardButton("\U0001F5BC Open media URL",
                                             url=media_url)])
    if click_url is not None:
        buttons.append([InlineKeyboardButton("\U0001F517 Open click URL",
                                             url=click_url)])
    if kind == "html":
        safe_html = sanitize_ad_html(str(cr["html_content"] or ""))
        lines += ["", "Sanitized HTML (strict whitelist — shown as source, "
                  "never parsed here):", safe_html[:2500]]
    buttons.append([_btn("\u2B05\uFE0F Back to creative",
                         f"wsad:crview:{int(crid)}")])
    await deps.safe_send_text(context.bot, chat_id, "\n".join(lines),
                              reply_markup=_kb(buttons))
    await deps.safe_answer_callback(update.callback_query,
                                    "Preview sent to this chat.")


# ------------------------------------------------------- placements (§49)
async def ads_placements_panel(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    db = deps.db
    state = {str(r["key"]): bool(int(r["enabled"]))
             for r in await db.list_ad_placements()}
    lines = [
        "\U0001F4CD AD PLACEMENTS (spec \u00A749)",
        "",
    ]
    for key in AD_PLACEMENT_KEYS:
        on = state.get(key, False)
        lines.append(f"{AD_PLACEMENT_LABELS.get(key, key)} — "
                     f"{'\U0001F7E2 ON' if on else '\U0001F534 OFF'}")
    lines += ["", "Placements default OFF (ads are strictly opt-in). A",
              "disabled slot collapses completely — never a placeholder",
              "(\u00A737). Toggles are live on the next ad decision."]
    rows: List[List[InlineKeyboardButton]] = []
    row: List[InlineKeyboardButton] = []
    for key in AD_PLACEMENT_KEYS:
        on = state.get(key, False)
        row.append(_btn(
            (f"\U0001F7E2 {AD_PLACEMENT_LABELS.get(key, key)}: ON" if on
             else f"\U0001F534 {AD_PLACEMENT_LABELS.get(key, key)}: OFF"),
            f"wsad:ptgl:{key}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([_btn("\u2B05\uFE0F Back to Ads Management", "wsad:main")])
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


async def ads_placement_toggle(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any, key: str) -> None:
    if key not in AD_PLACEMENT_KEYS:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown placement.")
        await ads_placements_panel(update, context, deps)
        return
    db = deps.db
    cur = await db.get_ad_placement_enabled(key)
    ok = await db.set_ad_placement_enabled(key, not cur)
    await deps.log_admin_action(
        int(update.effective_user.id), "ads_placement_toggle", "setting",
        None, f"placement={key} enabled={not cur}")
    await deps.safe_answer_callback(
        update.callback_query,
        f"{AD_PLACEMENT_LABELS.get(key, key)} "
        f"{'ON' if not cur else 'OFF'}."
        if ok else "Nothing changed.")
    await ads_placements_panel(update, context, deps)


# ------------------------------------------------------- analytics (§51)
async def ads_analytics_panel(update: Update,
                              context: ContextTypes.DEFAULT_TYPE,
                              deps: Any) -> None:
    db = deps.db
    s = await db.ad_analytics_summary(days=7)
    ctr = s.get("ctr")
    lines = [
        "\U0001F4CA AD ANALYTICS — last 7 days (spec \u00A751)",
        "",
        f"Impressions: {int(s.get('impressions') or 0)}",
        f"Clicks: {int(s.get('clicks') or 0)}",
        f"CTR: {(f'{float(ctr) * 100:.2f}%' if ctr is not None
                else '(no impressions yet)')}",
        f"Video starts: {int(s.get('video_starts') or 0)}",
        f"Completions: {int(s.get('completions') or 0)}",
        f"Skips: {int(s.get('skips') or 0)}",
        f"Failures: {int(s.get('failures') or 0)}",
    ]
    per = s.get("per_creative") or []
    if per:
        lines += ["", "Top creatives (impressions):"]
        for row in per[:GAP_ADMIN_PAGE_SIZE]:
            lines.append(f"#{int(row.get('creative_id'))} — "
                         f"{int(row.get('impressions') or 0)} impression(s)"
                         f", {int(row.get('clicks') or 0)} click(s)")
    else:
        lines += ["", "No impression/click events recorded yet."]
    rows = [[_btn("\u2B05\uFE0F Back to Ads Management", "wsad:main")]]
    await deps.safe_edit_text(update.callback_query, "\n".join(lines),
                              reply_markup=_kb(rows))


# --------------------------------------------------- New Campaign wizard
async def ads_campaign_wizard_start(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    deps: Any) -> None:
    _ad_wiz_clear(context)
    context.user_data[WSAD_WIZARD_KEY] = {"mode": "campaign", "step": "name"}
    await deps.safe_edit_text(
        update.callback_query,
        "\u2795 NEW CAMPAIGN — Name\n\n"
        "Send the campaign NAME (1-80 chars, or cancel).\n\n"
        "The campaign is created as a DRAFT — set status, schedule,\n"
        "frequency caps and creatives from its manage view.",
        reply_markup=_kb([[_btn("\u274C Cancel", "wsad:wcancel")]]))


async def ads_wizard_cancel(update: Update,
                            context: ContextTypes.DEFAULT_TYPE,
                            deps: Any) -> None:
    _ad_wiz_clear(context)
    await deps.safe_answer_callback(
        update.callback_query, "Wizard cancelled — nothing was saved.")
    await ads_panel(update, context, deps)


async def _ads_wizard_text(update: Update,
                           context: ContextTypes.DEFAULT_TYPE,
                           deps: Any, st: Dict[str, Any],
                           text: str) -> bool:
    if text.lower() in ("/cancel", "cancel"):
        _ad_wiz_clear(context)
        await deps.reply_protected(
            update, "\u274C Cancelled — nothing was saved.")
        return True
    if st.get("mode") == "campaign" and st.get("step") == "name":
        name = text.strip()
        if not name:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C The name cannot be empty. Send again, or cancel.")
            return True
        db = deps.db
        new_id = await db.create_ad_campaign(
            name=name[:80], status="draft", priority=0,
            frequency_cap_per_user=0, frequency_cap_hours=24, enabled=1)
        _ad_wiz_clear(context)
        if new_id is None:
            await deps.safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Could not create the campaign (invalid name). "
                "Nothing was saved. Send a different name, or cancel.")
            context.user_data[WSAD_WIZARD_KEY] = {
                "mode": "campaign", "step": "name"}
            return True
        await deps.log_admin_action(
            int(update.effective_user.id), "ads_campaign_create",
            "ad_campaign", int(new_id), "status=draft")
        await deps.safe_send_text(
            context.bot, update.effective_chat.id,
            "\u2705 Campaign created as a DRAFT.\n\n"
            f"Campaign ID: {int(new_id)}\nName: {name[:80]}\n"
            "Add creatives, then set the status to active when ready.",
            reply_markup=_kb([
                [_btn("\U0001F4CB Open campaign", f"wsad:cview:{int(new_id)}"),
                 _btn("\U0001F4CB All campaigns", "wsad:camps")]]))
        return True
    if st.get("mode") == "creative":
        return await _ads_creative_text(update, context, deps, st, text)
    return False


# ============================================================
# Text-input entrypoint (called by the website_admin facade)
# ============================================================

async def website_gap_text(update: Update,
                           context: ContextTypes.DEFAULT_TYPE,
                           deps: Any, text: str) -> bool:
    """text_handler hook for the category + ads panels. Returns True when
    the text was consumed by one of the wizard/editor states."""
    st = _cat_wiz_get(context)
    if st and st.get("step"):
        step = str(st["step"])
        if text.lower() in ("/cancel", "cancel"):
            _cat_wiz_clear(context)
            await deps.reply_protected(
                update, "\u274C Cancelled — nothing was saved.")
            return True
        if step == "name":
            name = text.strip()
            if not name:
                await deps.safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u274C The name cannot be empty. Send again, or "
                    "cancel.")
                return True
            st["name"] = name[:60]
            st["step"] = "slug"
            await category_wizard_ask(update, context, deps, "slug")
            return True
        if step == "slug":
            if text.strip() == "-":
                base = _slug_normalize(str(st.get("name") or ""))
            else:
                base = _slug_normalize(text)
            if not _slug_valid(base):
                await deps.safe_send_text(
                    context.bot, update.effective_chat.id,
                    "\u274C That slug normalizes to nothing usable\n"
                    "(need at least 2 chars of a-z/0-9/dashes).\n"
                    "Send a different slug, or cancel.")
                return True
            st["slug"] = base
            st["step"] = "icon"
            await category_wizard_ask(
                update, context, deps, "icon",
                extra=f"\n\n(Auto-normalized slug: {base})")
            return True
        if step == "icon":
            st["icon"] = "" if text.strip() == "-" else text.strip()[:16]
            st["step"] = "order"
            await category_wizard_ask(update, context, deps, "order")
            return True
        if step == "order":
            if text.strip() == "-":
                st["order"] = 0
            else:
                try:
                    st["order"] = max(0, min(100000, int(text.strip())))
                except ValueError:
                    await deps.safe_send_text(
                        context.bot, update.effective_chat.id,
                        "\u274C Order must be a whole number (0+). Send "
                        "again, or cancel.")
                    return True
            st["step"] = "create"
            await category_wizard_finish(update, context, deps)
            return True
        return True
    ed = _cat_edit_get(context)
    if ed and ed.get("field"):
        return await _category_edit_text(update, context, deps, ed, text)
    awz = _ad_wiz_get(context)
    if awz and awz.get("step"):
        return await _ads_wizard_text(update, context, deps, awz, text)
    aed = _ad_edit_get(context)
    if aed and aed.get("field"):
        field = str(aed.get("field") or "")
        if field == "exadd":
            return await ads_exempt_add_text(update, context, deps, text)
        return await _campaign_edit_text(update, context, deps, aed, text)
    return False


# ============================================================
# Dispatchers
# ============================================================

async def handle_wsitecat_callback(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE,
                                   deps: Any) -> None:
    """Dispatch every ``wsitecat:`` admin callback (called from
    on_callback — admin-gated there by the master admin gate, exactly
    like ``wsite:``; wsitecat: is NOT user-facing)."""
    data = str(update.callback_query.data or "")
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""
    arg = parts[2] if len(parts) > 2 else ""
    arg2 = parts[3] if len(parts) > 3 else ""

    def _int(v: str) -> int:
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0

    if action in ("", "main"):
        await categories_panel(update, context, deps)
    elif action == "page":
        await categories_panel(update, context, deps, page=_int(arg))
    elif action == "view" and _int(arg):
        await category_view(update, context, deps, _int(arg))
    elif action == "tgl" and _int(arg):
        await _category_flag_toggle(update, context, deps, _int(arg),
                                    "enabled", back_to_view=False)
    elif action == "ten" and _int(arg):
        await _category_flag_toggle(update, context, deps, _int(arg),
                                    "enabled", back_to_view=True)
    elif action == "tvis" and _int(arg):
        await _category_flag_toggle(update, context, deps, _int(arg),
                                    "visible", back_to_view=True)
    elif action == "tage" and _int(arg):
        await _category_flag_toggle(update, context, deps, _int(arg),
                                    "age_restricted", back_to_view=True)
    elif action == "del" and _int(arg):
        await category_delete_confirm(update, context, deps, _int(arg))
    elif action == "delconfirm" and _int(arg):
        await category_delete_execute(update, context, deps, _int(arg))
    elif action in ("ename", "eicon", "eorder", "edesc") and _int(arg):
        field = {"ename": "name", "eicon": "icon", "eorder": "order",
                 "edesc": "description"}[action]
        await category_edit_prompt(update, context, deps, field, _int(arg))
    elif action == "payloads" and _int(arg):
        await category_payloads_panel(update, context, deps, _int(arg))
    elif action == "ppage" and _int(arg):
        await category_payloads_panel(update, context, deps, _int(arg),
                                      page=_int(arg2))
    elif action == "premove" and _int(arg) and _int(arg2):
        await category_remove_payload(update, context, deps, _int(arg),
                                      _int(arg2))
    elif action == "padd" and _int(arg):
        await category_add_payload_panel(update, context, deps, _int(arg))
    elif action == "papage" and _int(arg):
        await category_add_payload_panel(update, context, deps, _int(arg),
                                         page=_int(arg2))
    elif action == "paddgo" and _int(arg) and _int(arg2):
        await category_add_payload_execute(update, context, deps,
                                           _int(arg), _int(arg2))
    elif action == "new":
        await category_wizard_start(update, context, deps)
    elif action == "wcancel":
        await category_wizard_cancel(update, context, deps)
    else:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown categories action.")


async def handle_wsad_callback(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               deps: Any) -> None:
    """Dispatch every ``wsad:`` admin callback (called from on_callback —
    admin-gated there by the master admin gate, exactly like ``wsite:``;
    wsad: is NOT user-facing and never collides with the user-facing
    ``wad:`` Watch-Ads namespace)."""
    data = str(update.callback_query.data or "")
    parts = data.split(":")
    action = parts[1] if len(parts) > 1 else ""
    arg = parts[2] if len(parts) > 2 else ""
    arg2 = parts[3] if len(parts) > 3 else ""

    def _int(v: str) -> int:
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0

    if action in ("", "main"):
        await ads_panel(update, context, deps)
    elif action == "master":
        await ads_master_toggle(update, context, deps)
    elif action == "exempt":
        await ads_exempt_panel(update, context, deps)
    elif action == "exadd":
        await ads_campaign_edit_prompt(update, context, deps, "exadd", 0)
    elif action == "exdel" and _int(arg):
        await ads_exempt_remove(update, context, deps, _int(arg))
    elif action == "camps":
        await ads_campaigns_panel(update, context, deps)
    elif action == "cnew":
        await ads_campaign_wizard_start(update, context, deps)
    elif action == "cview" and _int(arg):
        await ads_campaign_view(update, context, deps, _int(arg))
    elif action == "cstatus" and _int(arg):
        await ads_campaign_status_chooser(update, context, deps, _int(arg))
    elif action == "cstatusset" and _int(arg):
        await ads_campaign_status_set(update, context, deps, _int(arg),
                                      str(arg2).strip().lower())
    elif action == "cetoggle" and _int(arg):
        await ads_campaign_toggle(update, context, deps, _int(arg))
    elif action == "cdel" and _int(arg):
        await ads_campaign_delete_confirm(update, context, deps, _int(arg))
    elif action == "cdelyes" and _int(arg):
        await ads_campaign_delete_execute(update, context, deps, _int(arg))
    elif action in ("cename", "ceprio", "cestart", "ceend", "ccap",
                    "cwin") and _int(arg):
        await ads_campaign_edit_prompt(update, context, deps, action,
                                       _int(arg))
    elif action == "creatives" and _int(arg):
        await ads_creatives_panel(update, context, deps, _int(arg))
    elif action == "crnew" and _int(arg):
        await ads_creative_kind_chooser(update, context, deps, _int(arg))
    elif action == "crkind" and _int(arg):
        await ads_creative_wizard_start(update, context, deps, _int(arg),
                                        str(arg2).strip().lower())
    elif action == "crview" and _int(arg):
        await ads_creative_view(update, context, deps, _int(arg))
    elif action == "crtoggle" and _int(arg):
        await ads_creative_toggle(update, context, deps, _int(arg))
    elif action == "crdel" and _int(arg):
        await ads_creative_delete_confirm(update, context, deps, _int(arg))
    elif action == "crdelyes" and _int(arg):
        await ads_creative_delete_execute(update, context, deps, _int(arg))
    elif action == "crpreview" and _int(arg):
        await ads_creative_preview(update, context, deps, _int(arg))
    elif action == "placements":
        await ads_placements_panel(update, context, deps)
    elif action == "ptgl":
        await ads_placement_toggle(update, context, deps, str(arg))
    elif action == "analytics":
        await ads_analytics_panel(update, context, deps)
    elif action == "wcancel":
        await ads_wizard_cancel(update, context, deps)
    else:
        await deps.safe_answer_callback(update.callback_query,
                                        "Unknown ads action.")
