"""Lifecycle — post_init/post_shutdown, cleanup loop, entry facades.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



async def cleanup_loop(bot) -> None:
    """Background loop that deletes broadcast messages whose delete_at has passed.

    Adapted from the old bot's reliable, idempotent, restart-safe deletion worker.
    """
    logger.info("Cleanup loop started (interval=%ss).", CLEANUP_LOOP_INTERVAL)
    while True:
        try:
            now_str = _now_iso()
            expired = await db.expired_pending_deletions(now_str)
            for row in expired:
                chat_id = row["chat_id"]
                message_id = row["message_id"]
                try:
                    await bot.delete_message(chat_id=chat_id, message_id=message_id)
                except asyncio.CancelledError:
                    raise
                except BadRequest as e:
                    if "not found" in str(e).lower():
                        try:
                            await db.remove_pending_deletion(chat_id, message_id)
                        except Exception as db_err:  # noqa: BLE001
                            logger.error("cleanup: remove row failed: %s", db_err)
                    else:
                        logger.warning("cleanup: BadRequest chat=%s msg=%s: %s",
                                        chat_id, message_id, e)
                except RetryAfter as e:
                    new_dt = (datetime.now(timezone.utc) + timedelta(seconds=e.retry_after + 1)).isoformat()
                    try:
                        await db.defer_pending_deletion(chat_id, message_id, new_dt)
                    except Exception as db_err:  # noqa: BLE001
                        logger.error("cleanup: defer failed: %s", db_err)
                except (TimedOut, NetworkError):
                    new_dt = (datetime.now(timezone.utc) + timedelta(seconds=60)).isoformat()
                    try:
                        await db.defer_pending_deletion(chat_id, message_id, new_dt)
                    except Exception as db_err:  # noqa: BLE001
                        logger.error("cleanup: defer (net) failed: %s", db_err)
                except TelegramError as e:
                    logger.error("cleanup: delete error chat=%s msg=%s: %s",
                                  chat_id, message_id, e)
                else:
                    try:
                        await db.remove_pending_deletion(chat_id, message_id)
                    except Exception as db_err:  # noqa: BLE001
                        logger.error("cleanup: remove after delete failed: %s", db_err)
            # Issue 4: periodic RateLimiter prune (keeps memory stable).
            try:
                rate_limiter.prune_now()
            except Exception:  # noqa: BLE001
                pass
            # Issue 7: periodic join-request cache prune.
            try:
                _prune_join_requests()
            except Exception:  # noqa: BLE001
                pass
            # Issue 34: process pending_deletions (delivery/browse/admin/status).
            # This is a safety net — the in-memory timers handle the normal case,
            # but if any timer was cancelled or missed, this loop ensures the
            # messages still get deleted.
            try:
                now_ts = int(time.time())
                due = await db.due_pending_deletions(now_ts)
                for row in due:
                    await _delete_message_safe(bot, row["chat_id"], row["message_id"])
                    try:
                        await db.remove_pending_deletion_by_id(row["id"])
                    except Exception as e:  # noqa: BLE001
                        logger.error("cleanup: pending_deletions remove failed: %s", e)
            except Exception as e:  # noqa: BLE001
                logger.error("cleanup: pending_deletions sweep error: %s", e)
            # WATCH_AD V4 (v27): periodic postback-log prune (7d / 5000 rows).
            # Throttled to once per 10 minutes (CLEANUP_LOOP_INTERVAL is 10s —
            # the prune itself is cheap, but no need to run it every sweep).
            try:
                now_ts = int(time.time())
                if now_ts - getattr(cleanup_loop, "_last_wad_pb_prune", 0) > 600:
                    cleanup_loop._last_wad_pb_prune = now_ts  # type: ignore[attr-defined]
                    await db.prune_watch_ad_postback_log(days=7, keep_max=5000)
            except Exception:  # noqa: BLE001
                pass
        except asyncio.CancelledError:
            logger.info("Cleanup loop cancelled.")
            break
        except Exception as e:  # noqa: BLE001
            logger.error("Cleanup loop error: %s", e)
        await asyncio.sleep(CLEANUP_LOOP_INTERVAL)



# ============================================================
# LIFECYCLE HOOKS
# ============================================================
async def post_init(app: Application) -> None:
    global db, auto_reindex_task, broadcast_scheduler_task, cleanup_task, startup_reindex_task
    global BOT_USERNAME, INDEX_GLOBAL_LOCK
    # BOT6 STARTUP BANNER
    import hashlib as _hashlib
    # V5.1 (§50): RUNTIME_BUILD_ID = SHA-256 of THIS source file's content —
    # a stable deployment identity (same file copy → same id; any edit → new
    # id). Logged with PID + DB path + schema version so every later log line
    # (WATCH_AD_MODE_RESOLVED carries the same build id) can be attributed to
    # the exact running build.
    BUILD_ID = RUNTIME_BUILD_ID
    print("=" * 60)
    print("BOT6 ACTIVE")
    print(f"BUILD_ID={BUILD_ID}")
    print("=" * 60)
    logger.info("BOT6_STARTUP BUILD_ID=%s pid=%s db=%s (build id = sha256 of "
                "the running source file content)",
                BUILD_ID, os.getpid(), DATABASE_FILE)
    # BOT6: global indexing lock (single concurrent indexing op across ALL channels).
    INDEX_GLOBAL_LOCK = asyncio.Lock()
    # BOT6: no _bot_ref — bot is always passed explicitly.
    _ = app.bot  # app.bot is used by handlers via context.bot at call time
    # ---- Startup health check ----
    health_ok = True
    # 1. Bot username auto-detection (do not hardcode).
    _startup_me = None  # PHASE 7 HOTFIX: kept for the file_id epoch check
    try:
        me = await app.bot.get_me()
        _startup_me = me
        BOT_USERNAME = (me.username or "").lstrip("@")
        # MANAGED BOTS v37 (Task 8): cache the main bot's own User on the
        # namespace + the truthful capability startup line — User.
        # can_manage_bots is None when Telegram did not report the flag.
        try:
            global _MAIN_BOT_ME
            _MAIN_BOT_ME = me
            _managed_bots.log_managed_bots_ready(
                logger, getattr(me, "can_manage_bots", None))
        except Exception as _mb_exc:  # noqa: BLE001 — diagnostic only
            logger.warning("MANAGED_BOTS_READY check failed: %s", _mb_exc)
        logger.info("Startup health: bot username auto-detected -> @%s", BOT_USERNAME)
    except TelegramError as e:
        logger.error("Startup health: FAILED to detect bot username via get_me(): %s", e)
        if not BOT_USERNAME:
            logger.error("Startup health: no BOT_USERNAME fallback set. Deep links will be broken.")
            health_ok = False
        else:
            logger.warning("Startup health: using BOT_USERNAME env fallback: @%s", BOT_USERNAME)
    # BOT5: Register command menu with Telegram.
    # v37 (Part Q12): /network is a REAL user-facing Main Bot command — it
    # must appear in the command menu AND have a CommandHandler (both are
    # verified by the v37 tests; the menu alone is not sufficient).
    try:
        user_commands = [
            BotCommand("start", "Open the bot / open a delivery link"),
            BotCommand("network", "Manage your Network Bots"),
            BotCommand("recent", "Your recent files (last 24h)"),
            BotCommand("help", "Show help"),
        ]
        await app.bot.set_my_commands(user_commands, scope=BotCommandScopeDefault())
        admin_commands = list(user_commands) + [
            BotCommand("panel", "Open the admin panel"),
            BotCommand("stats", "Show bot statistics"),
            BotCommand("recentfiles", "Admin: indexed-files panel"),
        ]
        for _aid in ADMIN_IDS:
            try:
                await app.bot.set_my_commands(admin_commands, scope=BotCommandScopeChat(chat_id=_aid))
            except TelegramError as e:
                logger.warning("set_my_commands(admin %s) failed: %s", _aid, e)
        logger.info("BOT6: command menu registered.")
    except TelegramError as e:
        logger.warning("BOT6: set_my_commands failed: %s", e)
    # 2. Database connection + schema.
    try:
        db = Database(DATABASE_FILE)
        await db.connect()
        await db.init_schema()
        logger.info("Startup health: database OK (%s)", DATABASE_FILE)
    except Exception as e:  # noqa: BLE001
        logger.error("Startup health: database FAILED: %s", e)
        raise  # cannot continue without DB
    # PHASE 7 HOTFIX: file_id epoch check — MUST run after the DB is up.
    # Detects a bot-token change (bot identity swap): every stored file_id
    # was issued to the OLD bot and is potentially invalid (bot.log 22:
    # token change -> every delivery failed with "Wrong file identifier/
    # http url specified"). Arms proactive validation + self-recovery.
    if _startup_me is not None:
        await _apply_file_id_epoch(int(getattr(_startup_me, "id", 0) or 0))
    # 3. Required tables check.
    try:
        cur = await db.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN "
            "('users','indexed_files','payloads','storage_channels','bot_settings')"
        )
        required = [r[0] for r in await cur.fetchall()]
        missing = [t for t in ("users", "indexed_files", "payloads", "storage_channels", "bot_settings") if t not in required]
        if missing:
            logger.error("Startup health: missing required tables: %s", missing)
            health_ok = False
        else:
            logger.info("Startup health: required tables present")
    except Exception as e:  # noqa: BLE001
        logger.error("Startup health: table check FAILED: %s", e)
        health_ok = False
    # BOT7: the DB is up now — register the ADMIN command menu for every ACTIVE
    # DB admin too (the env-based registration above ran before the DB existed).
    # Cosmetic only (command hints); authorization is enforced server-side.
    try:
        _cur = await db.conn.execute(
            "SELECT user_id FROM admins WHERE is_active = 1 AND user_id NOT IN "
            f"({','.join('?' * len(ADMIN_IDS)) or '0'})",
            ADMIN_IDS or [0],
        ) if ADMIN_IDS else await db.conn.execute(
            "SELECT user_id FROM admins WHERE is_active = 1")
        _db_admins = [int(r["user_id"]) for r in await _cur.fetchall()]
        for _aid in _db_admins:
            try:
                await app.bot.set_my_commands(
                    [
                        BotCommand("start", "Open the bot / open a delivery link"),
                        BotCommand("network", "Manage your Network Bots"),
                        BotCommand("recent", "Your recent files (last 24h)"),
                        BotCommand("help", "Show help"),
                        BotCommand("panel", "Open the admin panel"),
                        BotCommand("stats", "Show bot statistics"),
                        BotCommand("recentfiles", "Admin: indexed-files panel"),
                    ],
                    scope=BotCommandScopeChat(chat_id=_aid))
            except TelegramError as e:
                logger.debug("set_my_commands(db admin %s) failed: %s", _aid, e)
        if _db_admins:
            logger.info("BOT6: admin command menu registered for %d DB admin(s).",
                        len(_db_admins))
    except Exception as e:  # noqa: BLE001
        logger.debug("DB admin command menu registration skipped: %s", e)
    # 4. Storage channels status.
    try:
        channels = await db.list_storage_channels()
        active = [c for c in channels if c["is_active"]]
        if not channels:
            logger.warning("Startup health: no storage channels configured (indexing disabled)")
        else:
            logger.info("Startup health: %d storage channel(s), %d active",
                        len(channels), len(active))
    except Exception as e:  # noqa: BLE001
        logger.warning("Startup health: storage channel check error: %s", e)
    # 5. Auto reindex status.
    try:
        ar = await auto_reindex_active()
        logger.info("Startup health: auto reindex = %s", ar)
    except Exception as e:  # noqa: BLE001
        logger.warning("Startup health: auto reindex check error: %s", e)
    # Seed default settings if missing.
    defaults = {
        "auto_delete_enabled": "1",
        "auto_delete_default": str(AUTO_DELETE_DEFAULT),
        "auto_reindex_enabled": "1",
        "one_time_links_default": "0",
        "force_join_enabled": "1" if ENABLE_FORCE_JOIN else "0",
        "welcome_returning_enabled": "1",
        "analytics_enabled": "1" if ENABLE_ANALYTICS else "0",
        "auto_payload_enabled": "1" if ENABLE_AUTO_PAYLOAD else "0",
        # BOTV13 Phase 3: Progressive Force Join defaults.
        "fj_mode": FJ_MODE_DEFAULT,
        "fj_batch_size": str(FJ_BATCH_SIZE_DEFAULT),
        # Protection defaults (secure-by-default, mirrors old bot).
        # Issue 1 Critical Fix: protect_random REMOVED (feature deleted).
        "protect_requested": "1",
        "watermark_enabled": "1",
        "protect_internal_msgs": "1",
        "hide_delivery_source": "1",
        "allow_fwd_requested": "0",
        # Protection V2 seeds (new centralized engine).
        # Protection V3 seeds (simplified — one toggle controls everything).
        "prot_v3_forward_blocking": "1",
        "prot_v3_internal_bot_messages": "1",
        "prot_v3_hide_source": "1",
        "prot_v3_watermark": "0",
        "prot_v3_anti_leech": "1",
        "prot_v3_one_time_default": "0",
        "prot_v3_preview_protection": "1",
        "prot_v3_debug_logging": "0",
        # Issue #91: Branding settings REMOVED. The branding system was deleted
        # in Issue #84 (reply-based retrieve replaced it). These keys are no
        # longer seeded. resolve_branding() is a no-op stub. Any pre-existing
        # rows in bot_settings are harmless (never read) and can be cleaned up
        # manually. retrieve_text is the successor to branding_text.
        # Issue #50: Retrieve system defaults.
        "retrieve_enabled": "1",
        "retrieve_limit": "0",         # 0 = unlimited
        "retrieve_window_hours": "0",  # 0 = no time limit
        # Issue #84/#91: Reply-based retrieve message text + button.
        "retrieve_message_text": DEFAULT_RETRIEVE_TEXT,
        "retrieve_message_button": DEFAULT_RETRIEVE_BUTTON,
        # BOT5: Global Preview timer — ISOLATED from delivery timer.
        "preview_auto_delete": str(GLOBAL_PREVIEW_TIMER_DEFAULT),
        # Issue 7: Request-to-Join policy default (request = access immediately).
        "join_request_policy": JOIN_REQUEST_POLICY_REQUEST,
        # Delivery message defaults (no hardcoded delivery text in code).
        "delivery_message_enabled": "1",
        "delivery_message_text": (
            "\u2705 {filename} delivered successfully.\n\n"
            "\u26A0\uFE0F Save or forward this file now.\n"
            "\U0001F551 This file may be removed automatically."
        ),
        "collection_delivery_message_text": (
            "\u2705 {count} files delivered successfully.\n\n"
            "\u26A0\uFE0F Save important files.\n"
            "\U0001F551 Files may be removed automatically."
        ),
        "delivery_message_buttons": "[]",
        # WATCH_AD (v25): global Watch Ads defaults. The Mini App URL / SDK
        # start EMPTY (the admin adds them from Telegram); the unlock window
        # seeds from the environment default.
        "watch_ads_unlock_window": str(WATCH_AD_UNLOCK_WINDOW),
    }
    for k, v in defaults.items():
        cur = await db.get_setting(k)
        if cur is None:
            await db.set_setting(k, v)
    # WATCH_AD (v25): MINI_APP_BASE_URL is ONLY an optional seed — applied
    # once when the database key is ABSENT, validated server-side. The
    # database value is authoritative and is NEVER overwritten by the
    # environment on restart.
    try:
        existing_wad_url = await db.get_setting("watch_ads_mini_app_url")
        if not existing_wad_url and MINI_APP_BASE_URL:
            seeded, seed_err = validate_watch_ads_mini_app_url(MINI_APP_BASE_URL)
            if seeded:
                await db.set_setting("watch_ads_mini_app_url", seeded)
                logger.info("WATCH_AD: seeded Mini App URL from MINI_APP_BASE_URL "
                            "env (one-time, DB now authoritative): %s", seeded)
            else:
                logger.warning("WATCH_AD: MINI_APP_BASE_URL env value rejected "
                               "(%s). Set the URL via Settings → Watch Ads.", seed_err)
    except Exception as e:  # noqa: BLE001
        logger.warning("WATCH_AD: Mini App URL seeding skipped: %s", e)
    # Reset any 'Processing' broadcasts from a previous crashed run -> 'Pending'.
    try:
        # Issue #48b: mark stale Processing broadcasts as FAILED (never resend).
        # Old code reset Processing→Pending (causing duplicates). Now we mark
        # them as Failed so they're never automatically resent.
        stale = await db.fix_stale_processing_broadcasts()
        if stale:
            logger.warning("Issue #48b: marked %d stale Processing broadcasts as Failed", stale)
    except aiosqlite.Error as e:
        logger.warning("Could not fix stale broadcasts: %s", e)
    logger.info("=" * 60)
    logger.info("Payload Delivery Bot initialised (v6)")
    logger.info("Bot username   : @%s", BOT_USERNAME)
    logger.info("Admins         : %s", ADMIN_IDS)
    logger.info("Force-join     : %s", await force_join_active())
    logger.info("Analytics      : %s", await analytics_active())
    logger.info("Auto payload   : %s", await auto_payload_active())
    logger.info("Auto delete    : %s (default %ss)", await auto_delete_active(),
                await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT))
    logger.info("Auto reindex   : %s (every %ss)", await auto_reindex_active(), AUTO_REINDEX_INTERVAL)
    # Protection V3: log the simplified engine status.
    pv3 = await resolve_protection_settings()
    logger.info("Protection V3  : forward_blocking=%s internal_msgs=%s hide_source=%s auto_del=%ss "
                "watermark=%s anti_leech=%s one_time=%s preview=%s",
                pv3["forward_blocking"], pv3["internal_bot_messages"], pv3["hide_source"],
                pv3["auto_delete_seconds"], pv3["watermark"],
                pv3["anti_leech"], pv3["one_time_default"],
                pv3["preview_protection"])
    logger.info("Delivery msg   : enabled=%s", await db.get_setting_bool("delivery_message_enabled", True))
    logger.info("JoinReq policy : %s", await get_join_request_policy())
    # Issue 7: Startup validation — check if the bot can receive ChatJoinRequest
    # updates. If force-join channels include request-to-join channels, the bot
    # needs permission to manage join requests. We validate by checking the bot's
    # admin status in each force-join channel.
    # Issue 37 + PHASE 6 §9 + PHASE 8 (§11/§12): the startup Force-Join pass
    # now uses the LINK-HEALTH SERVICE — one structured line per channel on
    # STATE CHANGE only (persisted in force_join_channels.link_health, v28)
    # plus ONE aggregate summary. The old behavior (raw 'INVALID (Chat not
    # found)' warnings repeated on every restart — bot.log 22 @ 03:23 +
    # 03:25) is gone: a transient Telegram failure is NEVER an invalid
    # verdict, and real configuration problems are reported with their exact
    # health state instead of a flood of identical warnings.
    try:
        # B18: the loop is EXTRACTED into fj_startup_health_pass
        # (forcejoin.py) — the exact same behavior, now a testable unit
        # (the bot-19.log Phase-5 remove/re-add regression drives it with
        # a real DB + a fake bot in tests/test_bot18_fj_remove_readd.py).
        # FINAL-1 PRODUCTION FIX (bot-20.log 11:31:11): this call site said
        # ``_fj_startup_health_pass`` — a name that EXISTS NOWHERE (the
        # function was renamed to the public, manifest-owned
        # ``fj_startup_health_pass`` during the B18 extraction). The
        # NameError was swallowed by this except-block, so the ENTIRE B18
        # startup FJ health pass silently never ran in production. The
        # regression suite test_final1_postinit_wiring.py now drives
        # post_init itself and AST-scans every section function for
        # unresolvable free names — this exact class of bug can never
        # ship silently again.
        agg = await fj_startup_health_pass(app.bot)
        health_counts = {"healthy": agg["healthy"],
                         "unverifiable": agg["unverifiable"],
                         "temporary_error": agg["temporary"],
                         "channel_invalid": agg["channel_invalid"]}
        dead_link_channels = agg["dead_link_channels"]
        rtj_unavailable = agg["rtj_unavailable"]
        force_channels_count = agg["channels"]
        if dead_link_channels:
            logger.warning(
                "\u26A0\uFE0F Force-join invite link problem(s) detected.\n"
                "Channels with Telegram-confirmed dead links: %s\n"
                "(expired / revoked / invalid). Users see a friendly "
                "'temporarily unavailable' notice instead of dead Join "
                "buttons; auto-repair runs when the bot has invite rights. "
                "Use Force Join \u2192 channel \u2192 Auto Change Link to fix now.",
                dead_link_channels)
        _chan_invalid = health_counts.get(_fj_health.CHANNEL_INVALID, 0)
        if _chan_invalid:
            logger.warning(
                "\u26A0\uFE0F %d force-join channel(s) are inaccessible to the bot "
                "(deleted / bot removed / wrong ID).\n"
                "Remove or replace them in Force Join Settings. Users are never "
                "blamed for these — membership checks report 'unavailable'.",
                _chan_invalid)
        if health_counts.get(_fj_health.TEMPORARY_ERROR, 0):
            logger.info(
                "\u26A0\uFE0F Could not verify %d force-join channel(s)/link(s) right now "
                "(Telegram rate limit / network). NOT marked invalid — "
                "re-verified on the next user request.",
                health_counts.get(_fj_health.TEMPORARY_ERROR, 0))
        # FINAL-1 PRODUCTION FIX: this condition referenced ``force_channels``
        # — a local of fj_startup_health_pass that does NOT exist in this
        # scope (only force_channels_count is set here). A latent NameError
        # that would have fired on the FIRST run with rtj_unavailable
        # channels (also swallowed by the except below).
        if rtj_unavailable and force_channels_count:
            logger.warning("\u26A0 Request-to-Join verification is unavailable for channels: %s. "
                           "Grant the bot permission to manage join requests.",
                           rtj_unavailable)
    except Exception as e:  # noqa: BLE001
        logger.warning("Startup validation: join-request check error: %s", e)
    logger.info("Startup health : %s", "OK" if health_ok else "DEGRADED (see logs)")
    logger.info("=" * 60)
    # Issue 34: recover pending deletions before starting background loops.
    # Deletes all due messages immediately, then re-schedules upcoming ones.
    try:
        imm, resched = await recover_pending_deletions(app.bot)
        if imm or resched:
            logger.info("Recovered pending deletions: %d immediate, %d re-scheduled",
                        imm, resched)
    except Exception as e:  # noqa: BLE001
        logger.error("Startup: pending_deletions recovery failed: %s", e)
    # Start background loops.
    auto_reindex_task = asyncio.create_task(auto_reindex_loop(app.bot))
    broadcast_scheduler_task = asyncio.create_task(broadcast_scheduler_loop(app.bot))
    cleanup_task = asyncio.create_task(cleanup_loop(app.bot))
    # WATCH_AD (v25): start the Mini App HTTP server INSIDE this same process
    # / event loop (bot + Mini App + reward verification in ONE application).
    # A bind failure is logged loudly but never crashes the bot — Watch Ads
    # then safely reports "temporarily unavailable" to users.
    if MINI_APP_ENABLED:
        try:
            await start_mini_app_server(app.bot)
        except Exception as e:  # noqa: BLE001
            logger.error("WATCH_AD: Mini App HTTP server failed to start on port "
                         "%s: %s. Watch Ads will be unavailable until fixed. "
                         "The Telegram bot continues to run.",
                         MINI_APP_PORT, e, exc_info=True)
    else:
        logger.info("WATCH_AD: Mini App HTTP server disabled "
                    "(MINI_APP_ENABLED=false).")
    # NETWORK PLATFORM (v29): initialize the network services, restart the
    # ACTIVE bots' workers, and resume durable RUNNING broadcasts. Isolated
    # per bot — a failing worker never breaks the main bot (spec §59).
    # b11 §2 (MAIN BOT FORCE-JOIN VERIFIER): publish the MAIN bot client on
    # the shared namespace BEFORE network startup — every Force-Join
    # membership check performed on behalf of a user arriving through a
    # NETWORK worker resolves this client (the MAIN bot holds the channel
    # admin rights; registered bots need none — spec "Registered bots do
    # not need Force Join channel admin rights").
    global _MAIN_BOT_CLIENT
    _MAIN_BOT_CLIENT = app.bot
    try:
        await network_startup(app.bot)
    except Exception as e:  # noqa: BLE001
        logger.error("NETWORK_PLATFORM startup failed (main bot continues "
                     "normally): %s", e, exc_info=True)
    # FILE DELIVERY v34 (spec §21): the dedicated CONTROL BOT (in-process,
    # CONTROL_BOT_TOKEN). Isolated — the control panel also remains
    # available inside the main bot's admin area (panel:control).
    try:
        from app.network.control_bot import start_control_bot
        await start_control_bot(_LEGACY_NS)
    except Exception as e:  # noqa: BLE001
        logger.error("CONTROL_BOT startup failed (main bot continues "
                     "normally): %s", e, exc_info=True)
    # Auto reindex on startup (one-shot scan of all active storage channels).
    if AUTO_REINDEX_ON_STARTUP and ADMIN_IDS:
        startup_reindex_task = asyncio.create_task(
            startup_reindex_all_channels(app.bot, ADMIN_IDS[0])
        )



async def startup_reindex_all_channels(bot, admin_id: int) -> None:
    """One-shot auto reindex of all active storage channels on startup."""
    try:
        await asyncio.sleep(5)  # let the bot settle
        channels = await db.list_storage_channels(active_only=True)
        for ch in channels:
            try:
                s, i, d = await scan_channel_for_new(bot, ch, admin_id)
                if i or d:
                    logger.info("Startup reindex %s: scanned=%d indexed=%d dup=%d",
                                ch["channel_id"], s, i, d)
            except Exception as e:  # noqa: BLE001
                logger.error("Startup reindex error for %s: %s", ch["channel_id"], e)
    except asyncio.CancelledError:
        pass
    except Exception as e:  # noqa: BLE001
        logger.error("Startup reindex loop error: %s", e)



async def post_shutdown(app: Application) -> None:
    global auto_reindex_task, broadcast_scheduler_task, cleanup_task, startup_reindex_task
    global _website_gateway_singleton, _website_gateway_failed, _website_net_token_cache
    # NETWORK PLATFORM (v29): stop all network workers + broadcast engines
    # (isolated per bot) BEFORE the shared DB closes.
    try:
        await network_shutdown()
    except Exception as e:  # noqa: BLE001
        logger.debug("Network shutdown error: %s", e)
    # FILE DELIVERY v34: stop the dedicated Control Bot.
    try:
        from app.network.control_bot import stop_control_bot
        await stop_control_bot(_LEGACY_NS)
    except Exception as e:  # noqa: BLE001
        logger.debug("Control bot stop error: %s", e)
    # WATCH_AD (v25): stop the Mini App HTTP server before teardown.
    try:
        await stop_mini_app_server()
    except Exception as e:  # noqa: BLE001
        logger.debug("Mini App server stop error: %s", e)
    # WEBSITE PHASE 4 (ARCHITECTURE PROPER BREAKDOWN §15): release the
    # media gateway's HTTP session — no dangling aiohttp ClientSession.
    try:
        _gw = _website_gateway_singleton
        if _gw is not None and getattr(_gw, "stack", None) is not None:
            await _gw.stack.close()
        _website_gateway_singleton = None
        _website_gateway_failed = False
        _website_net_token_cache = {"ts": 0.0, "tokens": []}
    except Exception as e:  # noqa: BLE001
        logger.debug("Media gateway close error: %s", e)
    for task in (auto_reindex_task, broadcast_scheduler_task, cleanup_task, startup_reindex_task):
        if task:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    auto_reindex_task = None
    broadcast_scheduler_task = None
    cleanup_task = None
    startup_reindex_task = None
    if db:
        await db.close()



# ----------------------------------------------------------------------
# NETWORK callback handlers (wired into on_callback's dispatch block)
# ----------------------------------------------------------------------


# ============================================================
# MAIN ENTRY POINT
# ============================================================
def build_application() -> Application:
    """Facade → app/bootstrap/application.py (the REAL composition root —
    ARCHITECTURE DECOUPLING §3/§16). Fail-closed guards and handler
    registration order are preserved verbatim there."""
    return _app_bootstrap.build_application(_LEGACY_NS)



def main() -> None:
    """Facade → app/bootstrap/application.py run_production (identical
    Phase 5 behavior: same startup log, composition, polling)."""
    _app_bootstrap.run_production(_LEGACY_NS)
