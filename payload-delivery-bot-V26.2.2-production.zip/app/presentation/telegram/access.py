"""Access Engine V1 — authorization, watch-ad gate, referral unlock.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# ACCESS ENGINE V1 — CENTRAL AUTHORIZATION LAYER
# ============================================================
# The Access Engine is the SINGLE authorization layer for ALL payload
# delivery. No delivery function may bypass it. It replaces the scattered
# per-delivery force-join + referral checks with one resolver.
#
# Flow for EVERY payload/collection/message access:
#   Link → Access Engine → Policy Resolution → Authorized?
#     YES → Deliver Payload
#     NO  → Access Requirement Screen (Force Join / Referral)
#
# Supported policies (this build implements the first three):
#   OPEN                 — no gate, deliver immediately
#   FORCE_JOIN           — require force-join channels only
#   FORCE_JOIN_REFERRAL  — force-join + referral unlock campaign
#   PASSWORD / COUPON / PAYMENT / VIP / CUSTOM — architecture-ready (future)
#
# Backward compatibility:
#   - Existing payloads migrate to FORCE_JOIN (their exact prior behaviour).
#   - Existing referral campaigns migrate their payload to FORCE_JOIN_REFERRAL.
#   - Existing payload links do NOT change behaviour.
# ============================================================


def _fj_verifier_bot(bot):
    """b11 §2 — THE MAIN BOT IS THE FORCE-JOIN VERIFICATION AUTHORITY.

    Registered Network Bots are generally NOT administrators in the Force
    Join channels; the MAIN bot holds the channel access. When the Access
    Engine runs inside a NETWORK worker context (``bot`` is a network bot
    client), the actual Telegram membership checks (getChatMember) are
    performed through the MAIN bot's identity, while the network bot stays
    the REQUESTING/DELIVERY context.

    Resolution contract (late-binding through the shared namespace):
      * ``_is_network_bot_client(bot)`` False (main bot / tests) → ``bot``
        unchanged — ZERO behavior change for the main-bot paths.
      * network client + ``_MAIN_BOT_CLIENT`` published (post_init) → the
        MAIN bot client (FORCE_JOIN_MAIN_VERIFIER_START/RESULT logged by
        the callers).
      * network client + no main client resolvable (degraded/test env) →
        ``bot`` (honest degrade — the membership check itself classifies
        BOT_NOT_ADMIN truthfully instead of crashing).
    """
    try:
        if bot is None:
            return bot
        if not _is_network_bot_client(bot):
            return bot
        main_client = globals().get("_MAIN_BOT_CLIENT")
        if main_client is not None:
            return main_client
        return bot
    except Exception:  # noqa: BLE001 — never break authorization
        return bot


async def _fj_slice_for(user_id: int, payload_id: Optional[int],
                         *, gate_key: Optional[str],
                         bot=None) -> list:
    """V26.2 (bot-41 §16-§24): the Force-Join slice the Access Engine
    enforces for THIS authorization.

    * ``gate_key`` present → the PER-GATE progressive-batching view: the
      pinned batch this gated content presented (satisfied = the pinned
      batch is live-verified joined — the operator's progressive unlock:
      gated file 1 requires batch 1, gated file 2 requires batch 2, …;
      future batches are never enforced on THIS gate's verdict).
    * ``gate_key`` absent → the LEGACY full-requirement view
      (_unjoined_for_access) — unchanged for admin surfaces, diagnostics
      and every legacy caller.
    Both are server-authoritative live membership checks — the key only
    selects the persisted presentation row, never the membership verdict.
    """
    if gate_key:
        try:
            return await fj_gate_unjoined(
                user_id, str(gate_key), payload_id=payload_id, bot=bot)
        except Exception:  # noqa: BLE001 — fall through to legacy slice
            logger.warning("FJ_GATE_VIEW_ERROR user_id=%s gate_key=%s "
                           "(falling back to the full-requirement slice)",
                           user_id, str(gate_key)[:64], exc_info=True)
    return await _unjoined_for_access(user_id, payload_id=payload_id,
                                      bot=bot)


async def access_engine(bot, user_id: int, *,
                         payload_id: Optional[int] = None,
                         payload_code: Optional[str] = None,
                         check_force_join: bool = True,
                         gate_key: Optional[str] = None) -> AccessResult:
    """THE central authorization resolver.

    Resolves the access policy for a payload (or a generic FORCE_JOIN policy
    when no payload row applies, e.g. m<link> / collection deliveries) and
    decides whether `user_id` is authorized to receive the content.

    For named payloads the policy is read from payloads.access_policy. For
    message-id links and collections (which have no payload row) the engine
    applies FORCE_JOIN semantics — exactly the pre-Access-Engine behaviour.

    V25 §9 (Force-Join completion persistence): the FJ verdict is derived
    from the user's LIVE verified memberships of the configured channels
    through the stable active-batch state machine (_get_fj_batch). Completing
    the active batch re-evaluates the FULL requirement: the access ALLOWs
    only when every required channel is genuinely joined (COMPLETE), so a
    completed state persists across payload re-clicks / refresh / browser
    reopen / navigation and is never reset by dashboard-user edits, while
    membership removal or a newly added required channel correctly
    re-presents only the genuinely missing channels.

    V26.2 (bot-41 §16-§24): ``gate_key`` switches the Force-Join slice to
    the PER-GATE progressive-batching view (fj_gate_unjoined — the pinned
    batch this gated content presented; satisfied = that batch is
    live-verified joined). The Website passes per-video keys
    ("w|{listing}|{file_pk}"); the bot delivery paths (enforce_access)
    pass the canonical payload/link identity ("b|p|{payload_id}" /
    "b|a|{link_arg}") — NEVER the ephemeral delivery message id. Without a
    gate key the legacy full-requirement verdict applies unchanged.

    The engine NEVER delivers content and NEVER sends UI. It only returns an
    AccessResult. Callers use enforce_access() to render the requirement
    screen, or inspect the result directly.
    """
    # BOT6: Admin/creator exemption is the VERY FIRST check — before any DB
    # access or policy resolution. ANY active admin (env-based OR DB-stored,
    # per the canonical is_admin()) must NEVER be blocked by Force Join (they
    # own/manage the bot). This also means admin access works even if the DB
    # is momentarily unavailable, and avoids any hidden dependency on
    # payload_row resolution for the admin fast-path.
    if await is_admin(user_id):
        logger.info(
            "BOT6_FJ_DECISION user_id=%s payload_id=%s decision=ALLOW "
            "reason=admin_exempt (admin bypass, source=%s)",
            user_id, payload_id, "env" if user_id in ADMIN_IDS else "db",
        )
        return AccessResult(authorized=True, policy=ACCESS_POLICY_OPEN,
                            payload_id=payload_id, payload_code=payload_code,
                            reason="admin_exempt")

    # --- Resolve payload row (if any) ---
    payload_row: Optional[aiosqlite.Row] = None
    if payload_id is not None:
        payload_row = await db.get_payload_by_id(payload_id)
    elif payload_code is not None:
        payload_row = await db.get_payload(payload_code)
        if payload_row:
            payload_id = int(payload_row["id"])

    if payload_id is None or payload_row is None:
        # No payload row (m<link> / collection / message links). Apply the
        # generic FORCE_JOIN policy — the legacy behaviour for these paths.
        res = AccessResult(authorized=True, policy=ACCESS_POLICY_FORCE_JOIN,
                           payload_id=None, payload_code=payload_code, reason="open")
        if check_force_join and await force_join_active():
            # V25 §9: the stable active-batch state machine gates delivery —
            # the full requirement must be live-verified before ALLOW. For
            # m<link>/collection there is no payload_id, so the completion
            # record is not written (authorization is identical either way).
            # b11 §2: the MAIN bot performs the membership checks when the
            # request arrived through a NETWORK worker.
            verifier = _fj_verifier_bot(bot)
            if verifier is not bot:
                logger.info("FORCE_JOIN_MAIN_VERIFIER_START user_id=%s "
                            "payload_id=None context=network_worker",
                            user_id)
            not_joined = await _fj_slice_for(user_id, None,
                                         gate_key=gate_key, bot=verifier)
            if verifier is not bot:
                logger.info("FORCE_JOIN_MAIN_VERIFIER_RESULT user_id=%s "
                            "payload_id=None unjoined=%s",
                            user_id, len(not_joined) if not_joined else 0)
            if not_joined:
                res.authorized = False
                res.reason = "force_join_required"
                res.not_joined = not_joined
        return res

    # --- Named payload: read its access_policy ---
    policy = payload_row["access_policy"] if "access_policy" in payload_row.keys() else None
    if not policy:
        policy = await db.get_access_policy(payload_id)
    # Future policies fall back to FORCE_JOIN until implemented.
    if policy not in ACCESS_POLICIES_IMPLEMENTED:
        policy = ACCESS_POLICY_FORCE_JOIN
    # BOT6 Phase 24: log the current policy so policy-edit-live is verifiable.
    logger.info(
        "BOT6_POLICY_RUNTIME payload_id=%s current_policy=%s policy_source=db "
        "access_policy_column=%s",
        payload_id, policy,
        payload_row["access_policy"] if "access_policy" in payload_row.keys() else None,
    )

    pid = int(payload_id)
    pcode = payload_row["payload"]

    # OPEN — no gate at all.
    if policy == ACCESS_POLICY_OPEN:
        res = AccessResult(authorized=True, policy=policy,
                           payload_id=pid, payload_code=pcode, reason="open")
        return await _apply_watch_ad_gate(res, payload_row, user_id)

    # FORCE_JOIN — require channels only.
    if policy == ACCESS_POLICY_FORCE_JOIN:
        res = AccessResult(authorized=True, policy=policy,
                           payload_id=pid, payload_code=pcode, reason="open")
        if check_force_join and await force_join_active():
            # V25 §9: the stable active-batch state machine gates delivery;
            # pid is passed so the full-completion record is written when
            # the WHOLE requirement is live-verified satisfied (diagnostics
            # only — the live checks are the authorization).
            # b11 §2: the MAIN bot performs the membership checks when the
            # request arrived through a NETWORK worker.
            verifier = _fj_verifier_bot(bot)
            if verifier is not bot:
                logger.info("FORCE_JOIN_MAIN_VERIFIER_START user_id=%s "
                            "payload_id=%s context=network_worker",
                            user_id, pid)
            not_joined = await _fj_slice_for(user_id, pid,
                                         gate_key=gate_key, bot=verifier)
            if verifier is not bot:
                logger.info("FORCE_JOIN_MAIN_VERIFIER_RESULT user_id=%s "
                            "payload_id=%s unjoined=%s",
                            user_id, pid, len(not_joined) if not_joined else 0)
            if not_joined:
                res.authorized = False
                res.reason = "force_join_required"
                res.not_joined = not_joined
                return res  # FJ is a prerequisite — Watch Ads is never evaluated
                           # before Force Join passes.
        return await _apply_watch_ad_gate(res, payload_row, user_id)

    # FORCE_JOIN_REFERRAL — force-join THEN referral unlock.
    # Step 1: force join (must pass before referral state is even considered).
    if check_force_join and await force_join_active():
        # V25 §9: the stable active-batch state machine gates delivery (the
        # full requirement must be live-verified before ALLOW).
        # b11 §2: the MAIN bot performs the membership checks when the
        # request arrived through a NETWORK worker.
        verifier = _fj_verifier_bot(bot)
        if verifier is not bot:
            logger.info("FORCE_JOIN_MAIN_VERIFIER_START user_id=%s "
                        "payload_id=%s context=network_worker",
                        user_id, pid)
        not_joined = await _fj_slice_for(user_id, pid,
                                     gate_key=gate_key, bot=verifier)
        if verifier is not bot:
            logger.info("FORCE_JOIN_MAIN_VERIFIER_RESULT user_id=%s "
                        "payload_id=%s unjoined=%s",
                        user_id, pid, len(not_joined) if not_joined else 0)
        if not_joined:
            return AccessResult(authorized=False, policy=policy,
                                payload_id=pid, payload_code=pcode,
                                reason="force_join_required", not_joined=not_joined)

    campaign = await db.get_referral_campaign_by_payload(pid)
    # V4 (v27): the Watch Ads gate is active only when the payload flag AND
    # the GLOBAL master switch are both ON (global OFF = base policy only).
    wad_flag = await _watch_ads_gate_active(payload_row)
    if not campaign or not campaign["enabled"]:
        # V2 (v26) — REFERRAL OR WATCH ADS: the referral requirement is
        # unavailable (no campaign / campaign disabled = referral OFF). When
        # the payload has Watch Ads enabled, the verified-ad requirement
        # becomes the SOLE requirement (watch-ads-only payload): apply the
        # Watch Ads gate to a base-authorized result. NO fake referral
        # campaign is created and the referral dashboard is never rendered.
        if wad_flag:
            res = AccessResult(authorized=True, policy=policy,
                               payload_id=pid, payload_code=pcode, reason="open")
            return await _apply_watch_ad_gate(res, payload_row, user_id)
        # V5.1 FIX (production incident, bot.log 17 @ 15:56 / 16:29):
        # policy says referral but the campaign is missing/disabled AND the
        # Watch Ads gate is inactive (global OFF or payload flag OFF). The
        # OLD fail-safe DENIED here — the user had completed Force Join and
        # then hit a permanent dead end: "❌ This content is not available
        # right now." with NO unlock path (they re-pressed Verify 4×). The
        # referral requirement being unavailable must NOT wall off the
        # payload: Force Join has ALREADY been enforced above (the policy is
        # FORCE_JOIN_REFERRAL — its FJ part stands), so the honest fallback
        # is the BASE policy, exactly like FORCE_JOIN would behave. Global
        # Watch Ads OFF therefore never disables Referral, and a disabled
        # campaign never manufactures a dead end. Admins still get a loud
        # warning to fix the configuration.
        logger.warning(
            "Access Engine: payload %s has FORCE_JOIN_REFERRAL but no active "
            "campaign (campaign=%s enabled=%s) and the Watch Ads gate is "
            "inactive — falling back to the BASE policy (Force Join only). "
            "Referral unlocked=nothing to satisfy; delivery proceeds. Fix the "
            "campaign or switch the payload policy.",
            pid, "missing" if not campaign else int(campaign["id"]),
            _safe_row_get(campaign, "enabled") if campaign else "-")
        return AccessResult(authorized=True, policy=policy,
                            payload_id=pid, payload_code=pcode,
                            reason="referral_inactive", campaign=None,
                            required_referrals=0, completed_referrals=0)

    required = int(campaign["required_referrals"])
    rec = await db.get_or_create_unlock_record(pid, campaign["id"], user_id, required)

    # required == 0 means instant unlock (spec: "0 = unlocked instantly").
    if required <= 0 and not rec["unlocked"]:
        await db.increment_unlock_progress(pid, campaign["id"], user_id)
        rec = await db.get_or_create_unlock_record(pid, campaign["id"], user_id, required)

    completed = int(rec["completed_referrals"])
    if rec["unlocked"]:
        res = AccessResult(authorized=True, policy=policy,
                           payload_id=pid, payload_code=pcode, reason="unlocked",
                           campaign=campaign, unlock_record=rec,
                           required_referrals=required, completed_referrals=completed)
        # V2 (v26) — REFERRAL OR WATCH ADS: the referral goal being reached
        # authorizes the payload BY ITSELF (OR semantics — the user is never
        # pushed into a Watch Ad step after completing referrals). A valid
        # Watch Ads unlock, if present, is only stamped informationally.
        if wad_flag:
            res.watch_ads_enabled = True
            ad_ok, ad_exp = await db.watch_ad_unlock_valid(
                int(user_id), int(payload_row["id"]))
            res.watch_ads_satisfied = ad_ok
            res.watch_ad_unlock_expires = ad_exp
        return res

    # Referral NOT completed yet. V2 (v26) — REFERRAL OR WATCH ADS: a valid
    # server-verified Watch Ads unlock authorizes the payload BY ITSELF,
    # WITHOUT requiring referral completion (reason stays "watch_ad_unlocked"
    # so callers/analytics can distinguish the unlock path).
    if wad_flag:
        ad_ok, ad_exp = await db.watch_ad_unlock_valid(
            int(user_id), int(payload_row["id"]))
        if ad_ok:
            res = AccessResult(authorized=True, policy=policy,
                               payload_id=pid, payload_code=pcode,
                               reason=WATCH_AD_REASON_UNLOCKED,
                               campaign=campaign, unlock_record=rec,
                               required_referrals=required,
                               completed_referrals=completed)
            res.watch_ads_enabled = True
            res.watch_ads_satisfied = True
            res.watch_ad_unlock_expires = ad_exp
            return res

    # NETWORK POINTS (v29, spec §51): Referral OR Watch Ads OR Points — a
    # valid point unlock authorizes the payload BY ITSELF (never AND).
    _pt_res = AccessResult(authorized=False, policy=policy,
                           payload_id=pid, payload_code=pcode,
                           reason="referral_required", campaign=campaign,
                           unlock_record=rec,
                           required_referrals=required,
                           completed_referrals=completed)
    if await _point_unlock_allows(_pt_res, user_id, payload_row):
        _pt_res.campaign = campaign
        _pt_res.unlock_record = rec
        _pt_res.required_referrals = required
        _pt_res.completed_referrals = completed
        if wad_flag:
            _pt_res.watch_ads_enabled = True
            _pt_res.watch_ads_satisfied, _pt_res.watch_ad_unlock_expires = \
                await db.watch_ad_unlock_valid(int(user_id),
                                               int(payload_row["id"]))
        return _pt_res

    # Locked — NEITHER referral NOR Watch Ads NOR Points completed. (The
    # referral dashboard rendered by enforce_access will ALSO surface the
    # [🎬 Watch Ad] button as the FIRST button when the payload has
    # watch_ads_enabled — see the renderer — with explicit OR wording: the
    # user unlocks by completing ANY path. The NETWORK renderer adds the
    # [⭐ Unlock with N Points] button when point access is enabled.)
    _locked = AccessResult(authorized=False, policy=policy,
                           payload_id=pid, payload_code=pcode,
                           reason="referral_required", campaign=campaign,
                           unlock_record=rec,
                           required_referrals=required, completed_referrals=completed)
    return await _stamp_point_context(_locked, user_id, pid)



async def _apply_watch_ad_gate(res: AccessResult,
                               payload_row: Optional[aiosqlite.Row],
                               user_id: int) -> AccessResult:
    """WATCH_AD (v25/v26): apply the payload-level Watch Ads requirement to a
    BASE-AUTHORIZED AccessResult whose access policy has NO active referral
    requirement (OPEN / FORCE_JOIN, or FORCE_JOIN_REFERRAL whose campaign is
    unavailable — the watch-ads-only case).

    V2 (v26) semantics — for these policies Watch Ads is the sole optional
    requirement on top of the base policy:

        existing access policy (OPEN / FORCE_JOIN)
          + watch_ads_enabled (if enabled)
          = authorized

    For FORCE_JOIN_REFERRAL payloads with an ACTIVE campaign the OR logic is
    handled directly inside access_engine() (referral completed OR watch ads
    completed) — this gate is deliberately NOT applied on top of a satisfied
    referral unlock (never AND semantics).

    Rules (mirroring the required access order):
      * Force Join is ALWAYS evaluated BEFORE this gate (callers only invoke
        it once the base policy — including FJ — has authorized).
      * Admins never reach this gate (access_engine exempts them first).
      * watch_ads_enabled = 0  -> result unchanged (exact legacy behaviour).
      * watch_ads_enabled = 1  -> the user must hold a server-verified rewarded
        unlock that is still inside its validity window. Otherwise
        authorized=False / reason="watch_ad_required".
      * A satisfied ad unlock keeps authorization and stamps
        watch_ads_satisfied + reason="watch_ad_unlocked" (informational).
    The engine NEVER delivers content and NEVER sends UI here — it only flips
    the authoritative `authorized` bit.
    """
    if res is None or not payload_row:
        return res
    # V4 (v27): the GLOBAL master switch is honored here too — global OFF
    # makes every payload behave exactly as if watch_ads_enabled=0.
    if not await _watch_ads_gate_active(payload_row):
        return res  # Watch Ads inactive for this payload -> exact legacy behaviour.
    res.watch_ads_enabled = True
    if not res.authorized:
        # Base policy already denied (e.g. force_join_required upstream) —
        # never override the earlier requirement with the ad screen.
        return res
    ok, unlock_exp = await db.watch_ad_unlock_valid(
        int(user_id), int(payload_row["id"]))
    res.watch_ads_satisfied = ok
    res.watch_ad_unlock_expires = unlock_exp
    if not ok:
        # NETWORK POINTS (v29, spec §51): Watch Ads OR Points — before the
        # ad gate denies, a valid point unlock authorizes BY ITSELF.
        if await _point_unlock_allows(res, user_id, payload_row):
            return res
        res.authorized = False
        res.reason = WATCH_AD_REASON_REQUIRED
        return await _stamp_point_context(res, user_id,
                                          res.payload_id)
    elif res.reason in ("open", "unlocked"):
        res.reason = WATCH_AD_REASON_UNLOCKED
    return res



async def enforce_access(update: Update, context: ContextTypes.DEFAULT_TYPE,
                          user: User, *,
                          payload_id: Optional[int] = None,
                          payload_code: Optional[str] = None,
                          link_arg: Optional[str] = None) -> bool:
    """THE single chokepoint every delivery path MUST call before delivering.

    Returns True if the caller may proceed with delivery, False if the Access
    Engine has already rendered a requirement screen (force-join page or
    referral preview) and the caller must abort.

    `link_arg` is the deep-link argument used to re-enter this delivery after
    the user completes force-join (e.g. "m8619", "c7f3a9b2", "<payload>").

    V26.2 (bot-41 §16-§20): the Force-Join gate for the BOT / File Delivery
    Bot is keyed on the CANONICAL content identity — the resolved
    payload_id when the delivery is a named payload, else the canonical
    deep-link argument (the same identity the Verify button re-enters
    through). NEVER the ephemeral delivery chat message id. Progressive
    batching: the first gated file presents the current batch; after a
    successful Verify the file is delivered; the NEXT gated file presents
    the NEXT batch; the Website and the bot share the SAME global
    requirement state (neither resets the other, §21).
    """
    # V26.2: resolve the canonical gate identity for this delivery.
    _gate_pid = payload_id
    if _gate_pid is None and payload_code:
        try:
            _row = await db.get_payload(str(payload_code))
            if _row is not None:
                _gate_pid = int(_row["id"])
        except Exception:  # noqa: BLE001 — engine resolves it again anyway
            _gate_pid = None
    gate_key = None
    if _gate_pid is not None:
        gate_key = f"b|p|{int(_gate_pid)}"
    elif link_arg:
        gate_key = f"b|a|{str(link_arg)[:48]}"
    res = await access_engine(context.bot, user.id,
                              payload_id=payload_id, payload_code=payload_code,
                              gate_key=gate_key)
    # Analytics: a campaign_view is logged every time a referral payload is
    # resolved (regardless of outcome). payload_open is logged only on success.
    if res.policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL and res.campaign is not None:
        await db.log_access_event("campaign_view",
                                  payload_id=res.payload_id,
                                  campaign_id=res.campaign["id"],
                                  user_id=user.id)
    if res.authorized:
        if res.policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL and res.campaign is not None:
            await db.log_access_event("payload_open",
                                      payload_id=res.payload_id,
                                      campaign_id=res.campaign["id"],
                                      user_id=user.id)
        # PHASE 6 §21: an authorized Verify tap — the user pressed Verify and
        # the fresh authoritative check now grants access.
        _q_auth = getattr(update, "callback_query", None)
        if _q_auth and (_q_auth.data or "").startswith("verify:"):
            logger.info("FORCE_JOIN_VERIFY_RESULT user_id=%s arg=%s "
                        "decision=ALLOW reason=%s",
                        user.id, (link_arg or res.payload_code or "")[:40],
                        res.reason)
        return True

    if res.reason == "force_join_required":
        arg = link_arg or res.payload_code or ""
        # BOT6 Message Lifecycle Decision: determine CREATE vs EDIT.
        # Fresh /start → CREATE. Verify from the current FJ message → EDIT.
        _chat_id = update.effective_chat.id
        _tracked_mid = _fj_user_msg_get(_chat_id, user.id)
        q = getattr(update, "callback_query", None)
        _cb_msg_id = None
        _event_source = FJ_EVENT_START  # default: fresh /start
        if q and q.message and q.message.message_id:
            _cb_msg_id = q.message.message_id
            # If the callback is "verify:" from the FJ message, it's a VERIFY event.
            if (q.data or "").startswith("verify:"):
                _event_source = FJ_EVENT_VERIFY
            else:
                _event_source = FJ_EVENT_REFRESH
        # PHASE 6 §11/§21: the Verify outcome — a verify tap re-entered the
        # Access Engine and was still denied. (Authorized verify taps are
        # logged below with decision=ALLOW.) The per-channel states are in
        # the BOT6_FJ_CHECK lines of this same tap.
        if _event_source == FJ_EVENT_VERIFY:
            logger.info("FORCE_JOIN_VERIFY_RESULT user_id=%s arg=%s "
                        "decision=DENY reason=%s remaining=%s",
                        user.id, arg[:40], res.reason,
                        len(res.not_joined) if res.not_joined else 0)
        _remaining = len(res.not_joined) if res.not_joined else 0
        _decision = determine_fj_message_action(
            event_source=_event_source,
            remaining=_remaining,
            callback_message_id=_cb_msg_id,
            tracked_message_id=_tracked_mid,
        )
        logger.info(
            "BOT6_FJ_MESSAGE_DECISION user_id=%s payload=%s event_source=%s "
            "remaining=%s tracked_message_id=%s callback_message_id=%s decision=%s",
            user.id, arg[:40], _event_source, _remaining,
            _tracked_mid, _cb_msg_id, _decision,
        )
        # EDIT only if the decision says so.
        _edit_mid = _tracked_mid if _decision == "EDIT" else None
        # V26.2 (bot-41 §16-§20): render EXACTLY the engine's per-gate
        # slice (the pinned batch for THIS gated delivery) — the bot page
        # shows the current batch only, never a future batch.
        await send_force_join_page(context.bot, _chat_id, user.id, arg,
                                   edit_message_id=_edit_mid,
                                   gate_channels=list(res.not_joined or [])
                                   if gate_key else None)
        return False

    if res.reason == "referral_required":
        await show_referral_preview_screen(
            context.bot, update.effective_chat.id, user.id,
            res.payload_code or "", res.campaign, res.unlock_record
        )
        return False

    # WATCH_AD (v25): base policy authorized but the payload requires a
    # verified rewarded ad. Render the Watch Ads access UI (standalone screen
    # when referral is OFF/completed; the referral dashboard carries the
    # [🎬 Watch Ad] button FIRST when referral is still pending). The
    # protected payload is NEVER delivered from this branch — the user must
    # re-enter the delivery path so the Access Engine re-evaluates.
    if res.reason == WATCH_AD_REASON_REQUIRED:
        await show_watch_ad_access_screen(
            context.bot, update.effective_chat.id, user, res,
            link_arg=link_arg,
        )
        return False

    # payload_missing / policy_unknown — generic denial.
    await safe_send_text(context.bot, update.effective_chat.id,
        "\u274C This content is not available right now.")
    return False



# ----------------------------------------------------------------
# Backward-compat shim: legacy callers used check_referral_gate().
# It now delegates to the Access Engine so all paths converge.
# ----------------------------------------------------------------


async def _edit_dashboard_to_unlocked(bot, campaign, user_id: int,
                                      payload_code: str,
                                      source: str = "referral") -> None:
    """BOTV13 Seamless Unlock: Edit the saved referral dashboard into the
    congratulations / ready screen (mode-aware via dashboard_update).

    WATCH_AD V5 (§23): `source` selects the unlock wording — "referral"
    (the inviter reached the referral goal) or "watch_ad" (the user
    completed the required verified ad rewards). The BUTTONS and the
    single Dashboard Controller edit are IDENTICAL for both sources (one
    renderer, no second implementation) — only the headline honestly says
    HOW the payload was unlocked, so a Watch-Ads unlock never claims "you
    reached the referral goal".

    Collection payload → "Collection Ready" menu:
        📥 Download Collection  (coldl:<code>)
        📂 Browse Files          (cobrowse:<code>:0)
        📤 Share Collection      (URL)
        🔙 Back                  (coclose)

    Single-file payload → "File Ready" screen:
        📂 Open File             (URL → /start <routing_id>)
        📤 Invite Friends        (URL → share referral link)

    No new message is sent. No files are auto-delivered. No duplicate
    dashboard is created. The existing stored dashboard message
    (dashboard_chat_id, dashboard_msg_id) is edited in place via the
    Dashboard Controller (dashboard_update), which picks the correct API
    (editMessageCaption for CAPTION dashboards, editMessageText for TEXT).
    """
    if not campaign or not payload_code:
        return
    try:
        # V5 (§23): source-aware unlock wording (single renderer — only the
        # headline differs; buttons/layout identical).
        if source == "watch_ad":
            congrats_line = ("\U0001F3AC Ad reward verified — Watch Ads "
                             "unlock complete!")
        else:
            congrats_line = ("\U0001F389 Congratulations — you reached the "
                             "referral goal.")
        # Resolve display_name for human-friendly links + dashboard title.
        payload_row = await db.get_payload_by_id(int(campaign["payload_id"])) if campaign else None
        display_name = None
        if payload_row and "display_name" in payload_row.keys():
            display_name = payload_row["display_name"]
        # Build the human-friendly payload link (display_name + routing_id).
        payload_link = build_link(payload_code, display_name=display_name)

        if is_collection_link(payload_code):
            # =========================================================
            # COLLECTION — edit dashboard into the Collection Ready menu.
            # Reuses the exact same buttons/callbacks as show_collection_menu
            # (coldl:, cobrowse:, share URL, coclose). No files are sent.
            # =========================================================
            code = parse_collection_link(payload_code) or ""
            coll = await db.get_collection(code) if code else None
            total = (coll["file_count"] if coll else 0) or 0
            coll_link = build_collection_link(code, display_name=display_name)
            share_url = f"https://t.me/share/url?url={coll_link}"
            text = (
                "\U0001F513 Unlocked!\n\n"
                f"{congrats_line}\n"
                f"\U0001F4E6 Collection Ready ({total} files)\n\n"
                "Choose an option below."
            )
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4E5 Download Collection",
                                      callback_data=f"coldl:{code}")],
                [InlineKeyboardButton("\U0001F4C2 Browse Files",
                                      callback_data=f"cobrowse:{code}:0")],
                [InlineKeyboardButton("\U0001F4E4 Share Collection", url=share_url)],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="coclose")],
            ])
        else:
            # =========================================================
            # SINGLE FILE — edit dashboard into the File Ready screen.
            # Open File links to the /start <routing_id> deep link (user
            # taps it to receive the file via the normal delivery flow).
            # Invite Friends shares the user's referral link.
            # =========================================================
            text = (
                "\U0001F513 Unlocked!\n\n"
                f"{congrats_line}\n"
                "\U0001F4C4 File Ready\n\n"
                "Tap \U0001F4C2 Open File to receive your content."
            )
            # Build the referral share link for Invite Friends.
            token = await db.get_or_create_referral_token(
                campaign["id"] if campaign and "id" in campaign.keys() else 0, user_id)
            invite_url = f"https://t.me/share/url?url={build_referral_link(token)}"
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4C2 Open File", url=payload_link)],
                [InlineKeyboardButton("\U0001F4E4 Invite Friends", url=invite_url)],
            ])
        ok = await dashboard_update(bot, campaign, user_id,
                                    text=text, keyboard=kb)
        if ok:
            logger.info("Unlock Seamless: dashboard edited to ready state for user %s (collection=%s source=%s).",
                         user_id, is_collection_link(payload_code), source)
        else:
            logger.debug("Unlock Seamless: dashboard edit skipped for user %s.", user_id)
    except Exception:  # noqa: BLE001
        logger.exception("Unlock Seamless: dashboard edit failed for user %s.", user_id)



async def auto_deliver_unlocked_payload(bot, inviter_user_id: int,
                                         payload_id: int) -> None:
    """BOTV13 Seamless Unlock: Edit the existing referral dashboard into the
    congratulations / ready screen. NO files are auto-sent. NO new message is
    created. NO duplicate dashboard is sent.

    This replaces the old auto-deliver behavior that spammed the chat with a
    congrats message + delivered files. Now the user sees a single edited
    dashboard with a button to open/download their content when they choose.

    The dashboard edit is performed by `_edit_dashboard_to_unlocked` which
    reuses the stored dashboard message (dashboard_chat_id, dashboard_msg_id)
    via the Dashboard Controller (dashboard_update).

    Analytics: the `unlock` event is still logged so analytics/tracking are
    preserved. Referral history continues recording (handled by
    qualify_referral_atomic). Preview/timers/dashboard controller are unchanged.
    """
    payload_row = await db.get_payload_by_id(payload_id)
    if not payload_row or payload_row["status"] != "active":
        logger.info("Auto-deliver: payload %s missing/inactive — skipping.", payload_id)
        return

    # Re-check force join (fresh, never trust stale).
    # BOTV13 Phase A: only the CURRENT ACTIVE BATCH gates delivery. The inviter
    # already completed their active batch when they unlocked (active_batch is
    # now []), so this re-check passes. Completed/past batches do NOT re-block
    # an already-unlocked payload — consistent with "future batches must NOT
    # block the current payload." Pass payload_id so the unlocked fast-path
    # applies (the inviter's payload is in unlocked_payload_ids).
    if await force_join_active():
        # b11 §2: the MAIN bot performs the membership check when the
        # unlock flows through a NETWORK worker.
        not_joined = await _unjoined_for_access(inviter_user_id, payload_id=payload_id, bot=_fj_verifier_bot(bot))
        if not_joined:
            logger.info("Auto-deliver: inviter %s has unjoined active-batch channels — skipping.",
                        inviter_user_id)
            return

    # WATCH_AD V2 (v26) — REFERRAL OR WATCH ADS: the referral goal being
    # reached authorizes the payload BY ITSELF. The user is NEVER pushed into
    # an extra Watch Ad step after completing referrals (the old v25 AND
    # behavior — "referral complete -> watch ad still required" — is replaced
    # by OR semantics in the Access Engine). No ad state is consulted here.
    try:
        payload_code = payload_row["payload"]
        campaign = await db.get_referral_campaign_by_payload(payload_id)

        # Edit the existing dashboard into the congratulations / ready screen.
        # No new message, no auto-send, no duplicate dashboard.
        await _edit_dashboard_to_unlocked(bot, campaign, inviter_user_id, payload_code)

        # Analytics: unlock event for the inviter (preserves tracking).
        await db.log_access_event("unlock",
                                  payload_id=payload_id,
                                  campaign_id=campaign["id"] if campaign else None,
                                  user_id=inviter_user_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("Auto-deliver: failed for inviter %s: %s", inviter_user_id, e)
