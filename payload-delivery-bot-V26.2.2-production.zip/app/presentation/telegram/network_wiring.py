"""Network wiring — network singletons, lifecycle facades.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def _is_network_bot_client(bot) -> bool:
    """Facade → app/network/lifecycle.py (§7 network wiring)."""
    return _net_lifecycle.is_network_bot_client(bot, _LEGACY_NS)



async def init_network_services(main_bot_tg_id: Optional[int]) -> None:
    """Facade → app/network/lifecycle.py (§7/§9 worker lifecycle)."""
    await _net_lifecycle.init_network_services(main_bot_tg_id, _LEGACY_NS)



# ----------------------------------------------------------------------
# Token validation transport (spec §2 — validate with Telegram directly).
# NEVER uses the main bot's API context; the candidate token is NEVER
# logged (mask only).
# ----------------------------------------------------------------------


async def _net_worker_error(network_bot_id: int, exc: Exception) -> None:
    """Facade → app/network/lifecycle.py (§9 worker lifecycle)."""
    await _net_lifecycle.net_worker_error(network_bot_id, exc, _LEGACY_NS)



async def _network_callback_guard(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE) -> None:
    """Facade → app/network/lifecycle.py (§7 network wiring)."""
    await _net_lifecycle.network_callback_guard(update, context, _LEGACY_NS)



    # Non-admin media messages in network bots are ignored (same as the
    # main bot's behavior for unconfigured states).


async def _build_network_bot_application(token: str, network_bot_id: int,
                                         username: str):
    """Facade → app/network/lifecycle.py (§7/§9 worker lifecycle)."""
    return await _net_lifecycle.build_network_bot_application(
        token, network_bot_id, username, _LEGACY_NS)



async def _net_setup_command(update: Update,
                            context: ContextTypes.DEFAULT_TYPE) -> None:
    """Facade → app/network/lifecycle.py (v37 bot-8 A5: the explicit
    /setup command on NETWORK workers — deterministic Delivery Group
    setup entry, same real verification chain)."""
    await _net_lifecycle.network_setup_command(update, context, _LEGACY_NS)



async def _net_delivery_group_guard(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE) -> None:
    """Facade → app/network/lifecycle.py (v34 spec §41/§73 Delivery Group
    detection hook on network workers — handler group 1, post-shared)."""
    await _net_lifecycle.network_delivery_group_guard(update, context,
                                                      _LEGACY_NS)



async def _net_delivery_channel_guard(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE) -> None:
    """Facade → app/network/lifecycle.py (A.2.4 bot-25: Delivery CHANNEL
    detection — channel posts AND (super)group messages both dispatch to
    the EXISTING detection handler chain via the module-level named shim;
    never a partial or inline lambda)."""
    await _net_lifecycle.network_delivery_channel_guard(update, context,
                                                        _LEGACY_NS)



# ----------------------------------------------------------------------
# NETWORK delivery transport (spec §22/§23/§30): NATIVE SOURCE COPY.
# A network bot delivers payload files by copy_message from the storage
# channel (the one transport that is bot-scoped correct by construction).
# NEVER a cross-bot file_id reuse; NEVER file_unique_id in send APIs.
# ----------------------------------------------------------------------
async def _network_send_file_by_source(bot, chat_id: int, file_row,
                                       protect_content: bool = False,
                                       payload_code: Optional[str] = None
                                       ) -> Optional[int]:
    """Facade → app/network/lifecycle.py (§7 network delivery transport)."""
    return await _net_lifecycle.network_send_file_by_source(
        bot, chat_id, file_row, protect_content, payload_code, _LEGACY_NS)


async def _network_send_files_by_source(bot, chat_id: int, file_rows,
                                        protect_content: bool = False,
                                        payload_code: Optional[str] = None
                                        ) -> "tuple[list, int]":
    """Facade → lifecycle.network_send_files_by_source (V25 FINAL §6/§7:
    multi-file/ALBUM delivery through the two-stage Delivery Channel
    architecture — real Telegram media-group albums via copyMessages)."""
    return await _net_lifecycle.network_send_files_by_source(
        _LEGACY_NS, bot, chat_id, file_rows,
        protect_content, payload_code)



# ----------------------------------------------------------------------
# Global Payload Links (spec §17-§20/§55) — /start g<code>
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Points unlock callback (spec §10 — the atomic transaction)
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# My Network — the USER panel (spec §64/§65)
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# MANAGED BOTS v37 (Task 8) — Telegram managed-bot creation. Facades →
# app/network/managed_bots.py (standalone module; every collaborator is
# resolved through the shared runtime namespace at CALL time — the same
# late-binding contract as the lifecycle facades above).
# ----------------------------------------------------------------------
async def begin_managed_bot_creation(update, context, user) -> None:
    """Facade → app/network/managed_bots.py begin_managed_creation (the
    PRIMARY Create Network Bot path: reply-keyboard request + pending
    state; fail-closed without NETWORK_TOKEN_ENCRYPTION_KEY)."""
    await _managed_bots.begin_managed_creation(_LEGACY_NS, update, context,
                                               user)


async def handle_managed_bot_created_message(update, context) -> None:
    """Facade → app/network/managed_bots.py handle_managed_bot_created
    (Message.managed_bot_created service message — registered on the MAIN
    bot AND, since b10 §7 (B10-B2), on every NETWORK worker: a worker with
    the can_manage_bots capability is the manager of the bots it creates,
    so its own MANAGED_BOT_CREATED updates arrive at the worker)."""
    await _managed_bots.handle_managed_bot_created(_LEGACY_NS, update,
                                                   context)


async def handle_managed_bot_update(update, context) -> None:
    """Facade → app/network/managed_bots.py handle_managed_bot_updated
    (Update.managed_bot / telegram.ManagedBotUpdatedHandler)."""
    await _managed_bots.handle_managed_bot_updated(_LEGACY_NS, update,
                                                   context)


async def replace_managed_bot_token(update, context, network_bot_id,
                                    admin_user_id) -> None:
    """Facade → app/network/managed_bots.py replace_managed_bot_token_atomic
    (ADMIN managed-bot token replacement — atomic, failure-safe)."""
    await _managed_bots.replace_managed_bot_token_atomic(
        _LEGACY_NS, update, context, int(network_bot_id),
        int(admin_user_id))


async def managed_bot_capability_status(bot=None) -> dict:
    """Facade → app/network/managed_bots.py capability_status (the
    truthful User.can_manage_bots diagnostic: True/False/None)."""
    return await _managed_bots.capability_status(_LEGACY_NS, bot)


async def worker_managed_bot_capability_status(bot=None) -> dict:
    """Facade → app/network/managed_bots.py worker_capability_status
    (b10 §7: a NETWORK WORKER bot's own can_manage_bots capability —
    fresh getMe on the worker's client; never touches the main-bot
    cache)."""
    return await _managed_bots.worker_capability_status(_LEGACY_NS, bot)


# ----------------------------------------------------------------------
# MAIN MINI APP LINK (b10 §8/§29 — B10-B2) — facades →
# app/network/bot_miniapp.py: the canonical Main Mini App URL, the
# best-effort menu-button applier, the worker-start reapply hook and
# the admin apply-to-all action (all ns-late-bound, same discipline).
# ----------------------------------------------------------------------
async def _net_main_app_url() -> str:
    """Facade → app/network/bot_miniapp.py canonical_main_app_url (THE
    canonical Main Mini App URL: website_public_base_url + /site,
    HTTPS-validated; '' when not configured)."""
    return await _bot_miniapp.canonical_main_app_url(_LEGACY_NS.db)


async def _net_menu_button_mode() -> str:
    """Facade → app/network/bot_miniapp.py menu_button_mode (auto |
    preserve — the explicit operator policy for menu buttons)."""
    return await _bot_miniapp.menu_button_mode(_LEGACY_NS.db)


async def _net_on_worker_started(network_bot_id: int) -> None:
    """Facade → app/network/bot_miniapp.py on_worker_started (the
    BotWorkerManager post-start hook: reapply the Main Mini App link on
    every worker start — new registrations AND restarts, spec §8C)."""
    await _bot_miniapp.on_worker_started(_LEGACY_NS, int(network_bot_id))


async def _net_apply_main_app_link_all() -> dict:
    """Facade → app/network/bot_miniapp.py apply_main_app_link_to_all
    (the ADMIN 'Apply Main App Link to All Registered Bots' action).

    BOT-11 (spec §2-§5): the production applier now returns the §4
    TRUTHFUL STRUCTURED result (applied/failed/skipped id lists + the
    main-bot outcome). The B11-B network_ui net:miniapp surface (FINAL)
    consumes the LEGACY aggregate count keys — derived HERE so the
    frozen consumer keeps its exact rendering contract while the
    network module owns the task-specified structured shape."""
    _res = await _bot_miniapp.apply_main_app_link_to_all(_LEGACY_NS)
    return {
        "url": _res.get("url"),
        "reason": _res.get("reason"),
        "total": _res.get("total"),
        "applied": _res.get("applied_count"),
        "skipped": _res.get("skipped_count"),
        "failed": _res.get("failed_count"),
        "offline": _res.get("offline_count"),
        "outcomes": _res.get("outcomes"),
    }


# ----------------------------------------------------------------------
# Admin Network Control Center (spec §43/§63)
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Network Broadcast Center (spec §43/§44/§45/§46)
# ----------------------------------------------------------------------


# ----------------------------------------------------------------------
# Network startup / shutdown lifecycle (spec §39/§59)
# ----------------------------------------------------------------------
async def network_startup(app_bot) -> None:
    """Facade → app/network/lifecycle.py (§9 explicit worker lifecycle)."""
    await _net_lifecycle.network_startup(app_bot, _LEGACY_NS)



async def _net_health_loop(interval: int) -> None:
    """Facade → app/network/lifecycle.py (§9 worker lifecycle)."""
    await _net_lifecycle.net_health_loop(interval, _LEGACY_NS)



async def network_shutdown() -> None:
    """Facade → app/network/lifecycle.py (§9 explicit worker lifecycle)."""
    await _net_lifecycle.network_shutdown(_LEGACY_NS)
