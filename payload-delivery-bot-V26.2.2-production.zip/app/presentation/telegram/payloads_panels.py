"""Payload panels — payloads, links, search results.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ---------- PAYLOADS PANEL ----------
async def payloads_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Payload Manager — for managing *existing* payloads only.

    Creation happens exclusively via the Link Generator (Single File / Forward
    File(s) / Collection Link), all of which open the Payload Configuration
    Wizard. This panel focuses on Search, Recent, Edit, and lifecycle actions.
    """
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4CB Payload List", callback_data="pl:list"),
         InlineKeyboardButton("\U0001F50D Find Payload", callback_data="pl:find")],
        [InlineKeyboardButton("\U0001F3C6 Top Payloads", callback_data="panel:top")],
        [InlineKeyboardButton("\U0001F517 Link Generator", callback_data="panel:links")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query,
        "*\U0001F5C2 Payload Manager*\n\n"
        "Manage existing delivery links and payloads.\n\n"
        "To *create* a new payload, use the Link Generator\n"
        "(\U0001F4C4 Single File / \U0001F4E4 Forward File(s) / \U0001F4E6 Collection Link).\n\n"
        "Supported here:\n"
        "\u2022 Search & edit existing payloads\n"
        "\u2022 Enable / Disable / Delete\n"
        "\u2022 Analytics & Access Policy",
        parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



# ============================================================
# LINK GENERATOR PANEL  (visual, wizard-driven)
# ============================================================
async def links_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Link Generator — clean 2-column x 3-row layout, the single entry point
    for payload creation. All three creation flows funnel into the same Payload
    Configuration Wizard.
    """
    total_payloads = await db.count_payloads()
    total_files = await db.count_indexed_files()
    text = (
        "*\U0001F517 Link Generator*\n\n"
        f"\U0001F4C1 Files: {total_files}  |  \U0001F517 Payloads: {total_payloads}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001F4C4 Single File", callback_data="link:single"),
         InlineKeyboardButton("\U0001F4E4 Forward File(s)", callback_data="link:fwd")],
        [InlineKeyboardButton("\U0001F4E6 Collection Link", callback_data="link:range"),
         InlineKeyboardButton("\U0001F50D Search Message ID", callback_data="link:search")],
        [InlineKeyboardButton("\U0001F4CB Recent Links", callback_data="link:recent"),
         InlineKeyboardButton("\U0001F5C2 Payload Manager", callback_data="panel:payloads")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query,
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb
    )



async def single_file_link_result(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                    message_id: int) -> None:
    """Show the generated m<link> with Copy / Preview / Share / Back buttons.

    Issue 7: no Message ID / payload id / channel id is displayed. Only the
    type, the direct link, and action buttons are shown. IDs stay internal.
    """
    link = build_msg_link(message_id)
    # Plain text — no Markdown, no IDs exposed (Issue 7).
    text = (
        "✅ Link Generated\n\n"
        "Type: Single File\n\n"
        f"Direct Link:\n{link}"
    )
    share_url = f"https://t.me/share/url?url={link}"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 Copy Link", callback_data=f"mlinkcopy:{message_id}"),
         InlineKeyboardButton("👁 Preview", callback_data=f"linkpreview:m:{message_id}")],
        [InlineKeyboardButton("📤 Share", url=share_url)],
        [InlineKeyboardButton("⬅️ Back", callback_data="panel:links")],
    ])
    if update.callback_query:
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



# ============================================================
# ADMIN PREVIEW SYSTEM V2
# Shows ACTUAL media (photo/video/document/audio/etc) — not just text.
# Preview auto-deletes after 20 seconds via the persistent pending_deletions
# system (survives restart). Admin-only — users never see preview buttons.
# ============================================================

async def _admin_preview_single(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                 user: User, file_row: aiosqlite.Row) -> None:
    """Admin Preview V2: send the ACTUAL media file with a preview header.

    Shows photo/video/document/audio/animation/voice/video_note/sticker.
    Auto-deletes after 20 seconds via persistent pending_deletions.
    """
    settings = await resolve_protection_settings()
    protect = settings["protect_content"] and settings.get("preview_protection", False)
    mtype = media_type_label(file_row["media_type"])
    link = build_msg_link(file_row["message_id"])
    header = (
        "\U0001F441 Admin Preview\n\n"
        f"Type: Single\n"
        f"Media: {mtype}\n"
        f"Link:\n{link}"
    )
    # Send the header first.
    header_msg = await safe_send_text(context.bot, user.id, header)
    # Send the actual media.
    sent_mid = await send_file(context.bot, user.id, file_row, protect_content=protect)
    await safe_answer_callback(update.callback_query, "Preview sent.")
    # Schedule persistent auto-delete for both messages.
    preview_ids: List[int] = []
    if header_msg and header_msg.message_id:
        preview_ids.append(header_msg.message_id)
    if sent_mid:
        preview_ids.append(sent_mid)
    if preview_ids:
        await schedule_admin_preview_delete(context.bot, user.id, preview_ids)



async def _admin_preview_collection(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                     user: User, collection_code: str,
                                     files: List[aiosqlite.Row]) -> None:
    """Admin Preview V2: send actual collection media via album chunking.

    Albums: 1-10 files = 1 album, 11-20 = 2 albums, 21-30 = 3 albums, etc.
    Documents/voice/etc are sent individually. Auto-deletes after 20 seconds.
    """
    settings = await resolve_protection_settings()
    protect = settings["protect_content"] and settings.get("preview_protection", False)
    link = build_collection_link(collection_code)
    header = (
        "\U0001F441 Admin Preview\n\n"
        f"Type: Collection\n"
        f"Files: {len(files)}\n"
        f"Link:\n{link}"
    )
    header_msg = await safe_send_text(context.bot, user.id, header)
    await safe_answer_callback(update.callback_query, f"Preview: {len(files)} files")
    # Send actual media via send_album (handles 10+10+5 chunking + sequential
    # fallback for documents/voice/etc).
    all_msg_ids, sent_count = await send_album(
        context.bot, user.id, files,
        caption=None, protect_content=protect,
    )
    # Schedule persistent auto-delete for header + all media.
    preview_ids: List[int] = list(all_msg_ids)
    if header_msg and header_msg.message_id:
        preview_ids.append(header_msg.message_id)
    if preview_ids:
        await schedule_admin_preview_delete(context.bot, user.id, preview_ids)



async def collection_link_result(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  collection_code: str) -> None:
    """Show the generated c<link> with Copy / Preview / Share / Back buttons.

    Issue 2 Critical Fix: uses the explicit collection code. No Range / message
    IDs are displayed. Only the type, file count, direct link, and action buttons.
    """
    coll = await db.get_collection(collection_code)
    count = coll["file_count"] if coll else 0
    link = build_collection_link(collection_code)
    text = (
        "✅ Link Generated\n\n"
        "Type: Collection\n\n"
        f"Files in collection: {count}\n\n"
        f"Direct Link:\n{link}"
    )
    share_url = f"https://t.me/share/url?url={link}"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 Copy Link",
                              callback_data=f"cocopy:{collection_code}"),
         InlineKeyboardButton("👁 Preview Collection",
                              callback_data=f"linkpreview:c:{collection_code}")],
        [InlineKeyboardButton("📤 Share", url=share_url)],
        [InlineKeyboardButton("⬅️ Back", callback_data="panel:links")],
    ])
    if update.callback_query:
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



# Backward-compat alias: old code may call range_link_result.
async def range_link_result(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              start_id: int, end_id: int) -> None:
    """Issue 2 backward-compat: auto-migrate an old range to an explicit
    collection, then show the new collection link result."""
    admin_id = update.effective_user.id if update.effective_user else None
    code = await _migrate_legacy_range_to_collection(start_id, end_id, user_id=admin_id)
    if not code:
        await safe_send_text(context.bot, update.effective_chat.id,
                             "❌ No files found in that range.")
        return
    await collection_link_result(update, context, code)



async def recent_links_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Visual list of recent indexed files, each with a one-tap Direct Link."""
    rows = await db.get_recent_files(limit=10)
    if not rows:
        await safe_edit_text(update.callback_query,
            "\U0001F4CB Recent Links\n\n"
            "No indexed files.\n"
            "Add a storage channel first.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F4E2 Channels", callback_data="panel:channels")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
            ]),
        )
        return
    lines = ["*\U0001F4CB Recent Links*", "", "Tap a file to copy or preview its direct link:"]
    buttons: List[List[InlineKeyboardButton]] = []
    for r in rows:
        name = (r["file_name"] or f"file_{r['id']}")[:32]
        buttons.append([
            InlineKeyboardButton(
                f"{media_emoji(r['media_type'])} m{r['message_id']} {name}",
                callback_data=f"file:{r['id']}",
            ),
        ])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")])
    await safe_edit_text(update.callback_query,
        "\n".join(lines), parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup(buttons)
    )



async def _page_for_payload(payload_id: int) -> int:
    """PHASE 6 §7: deterministic, restart-safe list page for a payload.

    The list is ORDER BY id DESC, so the payload's 0-based list position is
    the number of payloads with a HIGHER id. Page = position // PER_PAGE.
    Used when a detail is opened without an explicit page (legacy callback
    or after a restart) so Back always returns to a sensible page.
    """
    try:
        cur = await db.conn.execute(
            "SELECT COUNT(*) AS c FROM payloads WHERE id > ?", (int(payload_id),))
        row = await cur.fetchone()
        higher = int(row["c"]) if row else 0
    except Exception:  # noqa: BLE001
        return 0
    return higher // PAYLOADS_PER_PAGE



async def payload_list_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              page: int = 0) -> None:
    """BOTV13 Phase 1A: Paginated Payload Manager — 10 payloads per page.

    Edits the existing manager message in-place (no duplicate messages).
    Shows display_name as the label, status indicator, and one-line-per-payload
    buttons. Navigation via plpage:<page> callbacks. Search via pl:find.

    PHASE 6 §6: full Start/End navigation —
      ⏮ Start  ◀ Previous  X/XX  Next ▶  End ⏭
    First page hides Start/Previous; last page hides Next/End.
    PHASE 6 §7: every payload button carries the originating page
    (pldetail:<id>:<page>) so the detail's Back returns to THE SAME page.
    """
    total = await db.count_payloads()
    if total == 0:
        await safe_edit_text(update.callback_query,
            "\U0001F4CB Payload Manager\n\n"
            "No payloads yet.\n"
            "Create one from the Link Generator.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F517 Link Generator", callback_data="panel:links")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
            ]),
        )
        return
    total_pages = max(1, (total + PAYLOADS_PER_PAGE - 1) // PAYLOADS_PER_PAGE)
    page = max(0, min(page, total_pages - 1))
    offset = page * PAYLOADS_PER_PAGE
    rows = await db.list_payloads(limit=PAYLOADS_PER_PAGE, offset=offset)
    start = offset + 1
    end = offset + len(rows)
    # Build header.
    header = (
        f"\U0001F4CB Payload Manager\n\n"
        f"Showing {start}\u2013{end} of {total} payloads\n"
    )
    logger.info("PAYLOAD_LIST_RENDER page=%s total_pages=%s payloads=%s "
                "showing=%s-%s", page + 1, total_pages, total, start, end)
    # Build buttons — one per payload (§7: the originating page travels in
    # the callback so Back returns to exactly this page).
    buttons: List[List[InlineKeyboardButton]] = []
    for idx, r in enumerate(rows):
        ot = " \U0001F511" if r["one_time"] else ""
        status_icon = "\U0001F7E2" if r["status"] == "active" else "\U0001F534"
        # BOTV13: show display_name (human-readable) on the button label.
        dn = r["display_name"] if "display_name" in r.keys() else None
        label_name = dn if dn else r["payload"]
        display_idx = start + idx
        buttons.append([InlineKeyboardButton(
            f"{display_idx}. {label_name} {status_icon}{ot}",
            callback_data=f"pldetail:{r['id']}:{page}",
        )])
    # PHASE 6 §6: pagination row — ⏮ Start / ◀ Previous / X/XX / Next ▶ / End ⏭
    # First page: hide Start + Previous. Last page: hide Next + End.
    nav_row: List[InlineKeyboardButton] = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("\u23EE\uFE0F Start",
                                            callback_data="plpage:0"))
        nav_row.append(InlineKeyboardButton("\u25C0\uFE0F Previous",
                                            callback_data=f"plpage:{page - 1}"))
    nav_row.append(InlineKeyboardButton(f"{page + 1}/{total_pages}",
                                         callback_data=f"plpage:{page}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("Next \u27A1\uFE0F",
                                            callback_data=f"plpage:{page + 1}"))
        nav_row.append(InlineKeyboardButton("End \u23ED\uFE0F",
                                            callback_data=f"plpage:{total_pages - 1}"))
    buttons.append(nav_row)
    # Action row.
    buttons.append([
        InlineKeyboardButton("\U0001F50D Search Payload", callback_data="pl:find"),
        InlineKeyboardButton("\u2795 Create Payload", callback_data="pcw:start"),
    ])
    buttons.append([InlineKeyboardButton("\U0001F3E0 Home", callback_data="panel:main")])
    await safe_edit_text(update.callback_query, header,
                         reply_markup=InlineKeyboardMarkup(buttons))



def _pl_search_qid(query: str) -> str:
    """Deterministic 8-hex search id for a query (crc32). Callback-safe."""
    return format(zlib.crc32((query or "").strip().lower().encode("utf-8"))
                  & 0xFFFFFFFF, "08x")



async def _pl_search_store_query(query: str) -> str:
    """Persist the search query under its qid (bot_settings KV, upsert) and
    opportunistically prune the oldest entries (keep the last N)."""
    q = (query or "").strip()[:PL_SEARCH_QUERY_MAX_LEN]
    qid = _pl_search_qid(q)
    await db.set_setting(f"pl_search:{qid}", q)
    try:
        cur = await db.conn.execute(
            "SELECT key, value FROM bot_settings WHERE key LIKE 'pl\\_search\\:%' "
            "ESCAPE '\\' ORDER BY rowid DESC")
        rows = await cur.fetchall()
        if rows and len(rows) > PL_SEARCH_HISTORY_KEEP:
            for stale in rows[PL_SEARCH_HISTORY_KEEP:]:
                await db.conn.execute(
                    "DELETE FROM bot_settings WHERE key = ?", (stale["key"],))
            await db.conn.commit()
    except Exception as e:  # noqa: BLE001 — pruning is best-effort
        logger.debug("pl_search prune failed: %s", e)
    return qid



async def _pl_search_load_query(qid: str) -> Optional[str]:
    """Resolve a qid back to its query (restart-safe; None when expired)."""
    if not qid or not re.fullmatch(r"[0-9a-f]{8}", qid):
        return None
    try:
        return await db.get_setting(f"pl_search:{qid}")
    except Exception:  # noqa: BLE001
        return None



async def _pl_search_render(update: Update,
                           context: ContextTypes.DEFAULT_TYPE,
                           text: str, kb: InlineKeyboardMarkup) -> None:
    """Render search UI: edit the callback message when invoked from a
    button; otherwise (text-input entry) send a NEW message."""
    if update.callback_query is not None:
        sent = await safe_edit_text(update.callback_query, text, reply_markup=kb)
        if sent is not None:
            return
    chat_id = (update.effective_chat.id if update.effective_chat
               else (update.callback_query.message.chat_id
                     if update.callback_query and update.callback_query.message
                     else None))
    if chat_id is not None and context.bot is not None:
        await safe_send_text(context.bot, chat_id, text, reply_markup=kb)



async def payload_search_results_panel(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE,
                                       query: str, page: int = 0) -> None:
    """PHASE 7 (Task 3): render ONE page of fuzzy search results.

    Same shape as payload_list_panel: 10 rows, ⏮/◀/X/XX/▶/⏭ navigation with
    first/last-page rules, one button per payload carrying the search
    context, plus Clear (back to the normal Payload Manager — whose behavior
    is unchanged when no search is active). Works from BOTH entry points:
    callback navigation (edits the panel message) and the text-input search
    entry (sends a fresh message).
    """
    query = (query or "").strip()[:PL_SEARCH_QUERY_MAX_LEN]
    qid = _pl_search_qid(query)
    # One ranked fetch (deterministic order) — pagination slices it.
    all_rows, total = await db.search_payloads_fuzzy(query, limit=100000,
                                                     offset=0)
    if total == 0:
        await _pl_search_render(update, context,
            "\U0001F50D Payload Search\n\n"
            f"No payloads match \u201C{query[:60]}\u201D.\n\n"
            "Try a shorter term or part of the name.",
            InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F50D New Search", callback_data="pl:find")],
                [InlineKeyboardButton("\u2B05\uFE0F Back to Payloads",
                                      callback_data="panel:payloads")],
            ]))
        return
    # Paginate over the RANKED result set (deterministic).
    total_pages = max(1, (total + PAYLOADS_PER_PAGE - 1) // PAYLOADS_PER_PAGE)
    page = max(0, min(int(page), total_pages - 1))
    page_rows = all_rows[page * PAYLOADS_PER_PAGE:
                         (page + 1) * PAYLOADS_PER_PAGE]
    start = page * PAYLOADS_PER_PAGE + 1
    end = start + len(page_rows) - 1
    header = (
        "\U0001F50D Payload Search\n\n"
        f"Query: {query[:60]}\n"
        f"Showing {start}\u2013{end} of {total} results\n"
    )
    logger.info("PAYLOAD_SEARCH_RENDER qid=%s query_len=%s page=%s "
                "total_pages=%s results=%s showing=%s-%s",
                qid, len(query), page + 1, total_pages, total, start, end)
    buttons: List[List[InlineKeyboardButton]] = []
    for idx, r in enumerate(page_rows):
        ot = " \U0001F511" if r["one_time"] else ""
        status_icon = "\U0001F7E2" if r["status"] == "active" else "\U0001F534"
        dn = r["display_name"] if "display_name" in r.keys() else None
        label_name = dn if dn else r["payload"]
        display_idx = start + idx
        buttons.append([InlineKeyboardButton(
            f"{display_idx}. {label_name} {status_icon}{ot}",
            callback_data=f"plsdetail:{qid}:{r['id']}:{page}",
        )])
    # Navigation row — identical rules to the Payload Manager list.
    nav_row: List[InlineKeyboardButton] = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("\u23EE\uFE0F Start",
                                            callback_data=f"plsearch:{qid}:0"))
        nav_row.append(InlineKeyboardButton("\u25C0\uFE0F Previous",
                                            callback_data=f"plsearch:{qid}:{page - 1}"))
    nav_row.append(InlineKeyboardButton(f"{page + 1}/{total_pages}",
                                        callback_data=f"plsearch:{qid}:{page}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("Next \u27A1\uFE0F",
                                            callback_data=f"plsearch:{qid}:{page + 1}"))
        nav_row.append(InlineKeyboardButton("End \u23ED\uFE0F",
                                            callback_data=f"plsearch:{qid}:{total_pages - 1}"))
    buttons.append(nav_row)
    buttons.append([
        InlineKeyboardButton("\U0001F50D New Search", callback_data="pl:find"),
        InlineKeyboardButton("\u274C Clear Search", callback_data="plsclear"),
    ])
    buttons.append([InlineKeyboardButton("\U0001F3E0 Home", callback_data="panel:main")])
    await _pl_search_render(update, context, header,
                            InlineKeyboardMarkup(buttons))
