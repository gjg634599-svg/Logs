"""Delivery engine — core delivery, retries, albums, recovery, forward batches.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations


async def _deliver_files_core(
    bot,
    chat_id: int,
    user_id: int,
    *,
    payload_row: Optional[aiosqlite.Row] = None,
    payload_code: str,
    files: List[aiosqlite.Row],
    delivery_type: str = "single",
    stat_key: Optional[str] = None,
    bump_album_stat: bool = False,
    bump_file_stats: bool = True,
    delete_delay_override: Optional[int] = None,
    use_browse_timer: bool = False,
    collection_code: Optional[str] = None,
    existing_record_id: Optional[int] = None,
    existing_msg_id: Optional[int] = None,
    expire_one_time: bool = True,
) -> Dict[str, Any]:
    """BOTV13 Unified Delivery Engine - THE single post-enforce_access helper.

    Handles (in order):
      1. Protection resolution (resolve_delivery_protection).
      2. Configurable intro/delivery message (single or collection text).
      3. File delivery via send_file (single) or send_album (collection).
      4. Per-file stats: increment_file_downloads + increment_file_views
         (for every successfully sent file) — SKIPPED when bump_file_stats=False
         (used by the retrieve flow, which must not re-count the original
         delivery's stats).
      5. Per-payload stats: increment_clicks + record_view (only when
         payload_row is provided — named payloads only; m<link> has no row).
      6. Route stat counter: increment_stat(stat_key) and, for collections
         with bump_album_stat, increment_stat("album_messages_sent", N).
      7. One-time expiry: update_payload_field(status, "expired") when
         payload_row["one_time"] is truthy and expire_one_time is True.
      8. Auto-delete scheduling (schedule_auto_delete, or
         schedule_browse_delete when use_browse_timer). Respects
         auto_delete_active() and delay > 0. Retrieve message is NEVER
         added to the auto-delete schedule — it persists.
      9. Retrieve message rendering (reply-based, replies to first delivered
         media for collections; to the file for single). Edits in place
         when existing_record_id/existing_msg_id are set (retrieve flow).

    Delay resolution priority:
      1. delete_delay_override (if not None) — browse (10s) / retrieve (global).
      2. elif use_browse_timer -> BROWSE_AUTO_DELETE_DELAY.
      3. elif payload_row is not None -> resolve_delete_after(payload_row)
         (per-payload override -> global default).
      4. else -> db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
         (global default; used by m<link> and collection links).

    Returns:
        {"msg_ids": List[int], "sent_count": int, "intro_msg_id": Optional[int]}
    """
    is_collection = (delivery_type == "collection")
    # PHASE 7 (Task 2): LAST-LINE Watch Ads delivery gate — BEFORE any
    # message (intro included) is sent. A Watch-Ads-gated payload with
    # completed_ads < required_ads, no valid unlock window and no completed
    # referral unlock can NEVER pass through this engine, no matter which
    # caller invoked it. This makes the bypass structurally impossible at the
    # single point every delivery path shares.
    _gate_ok, _gate_reason = await _watch_ads_delivery_gate(
        int(user_id), payload_row, payload_code or "")
    if not _gate_ok:
        logger.warning(
            "WATCH_AD_BYPASS_BLOCKED user_id=%s payload_id=%s payload_code=%s "
            "gate_reason=%s delivery_type=%s files=%s — content NOT sent; "
            "completed_ads<required_ads (or no valid unlock) can never deliver",
            user_id,
            (payload_row["id"] if (payload_row is not None
                                   and "id" in payload_row.keys()) else "-"),
            (payload_code or "-")[:40], _gate_reason, delivery_type, len(files))
        return {"msg_ids": [], "sent_count": 0, "intro_msg_id": None,
                "watch_ads_blocked": True}
    # BOTV13 Phase 4: resolve per-payload forward_blocking (NULL=inherit, 1=ON, 0=OFF).
    protect = await resolve_delivery_protection(payload_row=payload_row)

    # --- 2. Configurable intro/delivery message ---
    intro = None
    if await delivery_message_active():
        if is_collection:
            coll_text = _format_delivery_text(
                await get_collection_delivery_message_text(),
                count=len(files),
            )
            intro = await safe_send_text(
                bot, chat_id, coll_text,
                protect_content=await protect_internal_active(),
                reply_markup=await get_delivery_message_buttons(),
            )
        else:
            file_row = files[0] if files else None
            if file_row:
                fname = file_row["file_name"] or "File"
                fsize = format_size(file_row["file_size"])
            else:
                fname, fsize = "File", ""
            text = _format_delivery_text(
                await get_delivery_message_text(),
                filename=fname, filesize=fsize,
            )
            intro = await safe_send_text(
                bot, chat_id, text,
                protect_content=await protect_internal_active(),
                reply_markup=await get_delivery_message_buttons(),
            )

    # --- 3. File delivery ---
    all_msg_ids: List[int] = []
    sent_count = 0
    if is_collection:
        album_caption = None
        if await delivery_message_active():
            album_caption = _format_delivery_text(
                await get_collection_delivery_message_text(),
                count=len(files),
            )
        logger.debug("Delivery Engine: collection files=%d protect=%s code=%s",
                     len(files), protect, collection_code or payload_code)
        all_msg_ids, sent_count = await send_album(
            bot, chat_id, files,
            caption=album_caption, protect_content=protect,
            payload_code=payload_code,
        )
    else:
        if files:
            file_row = files[0]
            logger.debug("Delivery Engine: single protect=%s file_id=%s",
                         protect, file_row["file_id"])
            mid = await send_file(bot, chat_id, file_row,
                                  protect_content=protect,
                                  payload_code=payload_code)
            if mid:
                all_msg_ids.append(mid)
                sent_count = 1

    # --- 4. Per-file stats (downloads + views) for every sent file ---
    # Skipped for the retrieve flow (bump_file_stats=False) so the original
    # delivery's counts are not inflated on every retrieve.
    if bump_file_stats:
        if is_collection:
            for f in files[:sent_count]:
                fid = f["id"] if "id" in f.keys() else None
                if fid is not None:
                    await db.increment_file_downloads(fid)
                    await db.increment_file_views(fid)
        else:
            if files and sent_count > 0:
                f = files[0]
                fid = f["id"] if "id" in f.keys() else None
                if fid is not None:
                    await db.increment_file_downloads(fid)
                    await db.increment_file_views(fid)

    # --- 5. Per-payload stats (named payloads only) ---
    if payload_row is not None:
        await db.increment_clicks(payload_row["id"])
        await db.record_view(payload_row["id"], user_id)

    # --- 6. Route stat counter ---
    if stat_key:
        await db.increment_stat(stat_key)
    if is_collection and bump_album_stat and all_msg_ids:
        await db.increment_stat("album_messages_sent", len(all_msg_ids))

    # --- 7. One-time expiry ---
    if payload_row is not None and expire_one_time and payload_row["one_time"]:
        await db.update_payload_field(payload_row["id"], "status", "expired")
        logger.info("One-time payload %s expired after delivery.",
                    payload_row["payload"])

    # --- 8. Auto-delete scheduling ---
    # use_browse_timer: browse delivery ALWAYS auto-deletes after the fixed
    # 10s delay (Issue 6 guarantee) — bypasses the auto_delete_active() toggle.
    # All other paths respect the global auto_delete_active() setting.
    should_schedule = use_browse_timer or await auto_delete_active()
    if should_schedule:
        if delete_delay_override is not None:
            delay = int(delete_delay_override)
        elif use_browse_timer:
            delay = BROWSE_AUTO_DELETE_DELAY
        elif payload_row is not None:
            delay = await resolve_delete_after(payload_row)
        else:
            delay = await db.get_setting_int("auto_delete_default", AUTO_DELETE_DEFAULT)
        if delay and delay > 0:
            ids: List[int] = list(all_msg_ids)
            if intro and intro.message_id:
                ids.append(intro.message_id)
            if ids:
                if use_browse_timer:
                    asyncio.create_task(
                        schedule_browse_delete(bot, chat_id, ids, delay)
                    )
                else:
                    asyncio.create_task(
                        schedule_auto_delete(bot, chat_id, ids, delay)
                    )
            # --- 9. Retrieve message (reply-based, never auto-deleted) ---
            reply_target = None
            if all_msg_ids:
                reply_target = all_msg_ids[0] if all_msg_ids[0] else (
                    all_msg_ids[-1] if all_msg_ids[-1] else None)
            await render_retrieve_message(
                bot, chat_id=chat_id, user_id=user_id,
                payload_code=payload_code,
                delivery_type="collection" if is_collection else "single",
                collection_code=collection_code if is_collection else None,
                reply_to_message_id=reply_target,
                existing_record_id=existing_record_id,
                existing_msg_id=existing_msg_id,
            )

    intro_msg_id = intro.message_id if intro and intro.message_id else None
    return {
        "msg_ids": all_msg_ids,
        "sent_count": sent_count,
        "intro_msg_id": intro_msg_id,
    }



def is_wrong_file_id_error(exc: BaseException) -> bool:
    """True when a Telegram error proves the file_id used is NOT sendable by
    the current bot (wrong/foreign/expired identifier). Only unambiguous
    identifier rejections match — everything else (network, flood, 'file is
    too big', chat errors) stays on the normal delivery error paths."""
    s = str(exc).lower()
    return any(marker in s for marker in _WRONG_FILE_ID_MARKERS)



async def _file_id_probe(bot, file_id: str) -> str:
    """Lightweight file_id validation via the Bot API getFile call.

    Returns 'valid' | 'invalid' | 'unknown':
      * valid   — getFile accepted the identifier (current bot may send it);
      * invalid — getFile failed with the SAME wrong-identifier BadRequest
                  class a send would produce (definitively NOT sendable);
      * unknown — anything else ('File is too big' for >20MB files, network
                  errors, ...). The probe NEVER concludes 'invalid' on an
                  ambiguous error: a wrong conclusion would trigger needless
                  recovery. Reactive delivery-time recovery remains the
                  always-armed safety net for 'unknown'.
    """
    if not file_id:
        return "unknown"
    cached = _FILE_ID_PROBE_CACHE.get(file_id)
    if cached:
        return cached
    result = "unknown"
    try:
        await bot.get_file(file_id)
        result = "valid"
    except BadRequest as e:
        result = "invalid" if is_wrong_file_id_error(e) else "unknown"
    except TelegramError:
        result = "unknown"
    except Exception:  # noqa: BLE001 — probe must never raise
        result = "unknown"
    _FILE_ID_PROBE_CACHE[file_id] = result
    return result



async def _apply_file_id_epoch(bot_user_id: int) -> None:
    """PHASE 7 HOTFIX: detect a bot-identity (token) change at startup.

    Persists the owning bot's user id in bot_settings (file_id_owner_bot_id).
    When it CHANGES, every previously stored file_id became potentially
    invalid (bot-scoped identifiers) — FILE_IDS_STALE_EPOCH is armed for this
    process so delivery validates file_ids proactively and re-indexing
    refreshes them. First run on a database records the identity with no
    staleness. Runs after the DB is connected (post_init).
    """
    global FILE_IDS_STALE_EPOCH
    try:
        bot_id = int(bot_user_id)
    except (TypeError, ValueError):
        return
    try:
        prev_raw = await db.get_setting("file_id_owner_bot_id")
        prev: Optional[int] = None
        if prev_raw:
            try:
                prev = int(prev_raw)
            except (TypeError, ValueError):
                prev = None
        if prev is None:
            await db.set_setting("file_id_owner_bot_id", str(bot_id))
            logger.info(
                "BOT6_FILE_ID_EPOCH_INIT bot_id=%s (first observation for this "
                "database — stored file_ids treated as authoritative)", bot_id)
            return
        if prev == bot_id:
            logger.info(
                "BOT6_FILE_ID_EPOCH_VERIFY bot_id=%s changed=False (stored "
                "file_ids remain authoritative)", bot_id)
            return
        # Bot identity CHANGED — all stored file_ids are suspect.
        await db.set_setting("file_id_owner_bot_id", str(bot_id))
        FILE_IDS_STALE_EPOCH = True
        logger.warning(
            "BOT6_FILE_ID_EPOCH_CHANGE old_bot_id=%s new_bot_id=%s — stored "
            "file_ids are potentially INVALID (bot token changed; file ids are "
            "bot-scoped). Delivery will validate + self-recover from source "
            "channels; Reindex refreshes canonical file_ids in place.",
            prev, bot_id)
    except Exception as e:  # noqa: BLE001 — epoch tracking must never crash startup
        logger.warning(
            "BOT6_FILE_ID_EPOCH_CHECK_FAILED error=%s (continuing — reactive "
            "delivery-time recovery remains armed)", e)



def _transient_delivery_error(exc: BaseException) -> bool:
    """True for TRANSIENT delivery errors worth retrying (timeouts, network
    resets, flood-control windows). False for deterministic API rejections
    (BadRequest) and permission errors (Forbidden) — retrying those is
    pointless and would only duplicate traffic."""
    if isinstance(exc, RetryAfter):
        return True   # flood control — retry after the mandated sleep
    return isinstance(exc, (TimedOut, NetworkError))



async def _send_with_retries(desc: str, fn):
    """Run an async send callable with bounded exponential backoff on
    TRANSIENT Telegram/network errors.

    Returns (result, error) — exactly one is non-None on a completed send
    attempt cycle:
      * success            -> (fn()-result, None)
      * deterministic error -> (None, exc) with NO retry
      * transient errors    -> up to DELIVERY_TRANSIENT_ATTEMPTS total
        attempts (backoff 1s/2s/4s capped at DELIVERY_RETRY_MAX_DELAY);
        RetryAfter sleeps the flood window (capped) first.
    The generic TelegramError catch-all is treated as deterministic (the
    legacy behaviour logged it and moved on). A fn() that returns None
    without raising yields (None, None) — callers treat that as 'not sent'.

    Duplicate-safety: this only ever re-runs a send that RAISED — a send
    that returned a message is never re-invoked, so successfully delivered
    files are never duplicated.
    """
    last_exc: Optional[BaseException] = None
    for attempt in range(1, DELIVERY_TRANSIENT_ATTEMPTS + 1):
        try:
            res = await fn()
            return res, None
        except RetryAfter as e:
            last_exc = e
            try:
                _flood = float(e.retry_after or 1.0)
            except (TypeError, ValueError):
                _flood = 1.0
            sleep_s = min(max(_flood, 0.5), DELIVERY_FLOOD_SLEEP_CAP)
            logger.warning(
                "BOT6_DELIVERY_RETRY %s attempt=%s/%s result=flood_wait "
                "sleep=%ss error=%s",
                desc, attempt, DELIVERY_TRANSIENT_ATTEMPTS, sleep_s, e)
            await asyncio.sleep(sleep_s)
        except (BadRequest, Forbidden) as e:
            logger.error(
                "BOT6_DELIVERY_RETRY %s attempt=%s/%s "
                "result=deterministic_error (no retry) error=%s",
                desc, attempt, DELIVERY_TRANSIENT_ATTEMPTS, e)
            return None, e
        except (TimedOut, NetworkError) as e:
            last_exc = e
            if attempt < DELIVERY_TRANSIENT_ATTEMPTS:
                delay = min(DELIVERY_RETRY_BASE_DELAY * (2 ** (attempt - 1)),
                            DELIVERY_RETRY_MAX_DELAY)
                logger.warning(
                    "BOT6_DELIVERY_RETRY %s attempt=%s/%s "
                    "result=transient_error error=%s — retrying in %.1fs",
                    desc, attempt, DELIVERY_TRANSIENT_ATTEMPTS,
                    type(e).__name__, delay)
                await asyncio.sleep(delay)
            else:
                logger.error(
                    "BOT6_DELIVERY_RETRY %s attempt=%s/%s "
                    "result=transient_exhausted error=%s",
                    desc, attempt, DELIVERY_TRANSIENT_ATTEMPTS,
                    type(e).__name__)
        except TelegramError as e:
            # Other Telegram errors (rare, non-transient per PTB taxonomy):
            # legacy behaviour — log once, treat as final.
            logger.error(
                "BOT6_DELIVERY_RETRY %s attempt=%s/%s "
                "result=telegram_error (no retry) error=%s",
                desc, attempt, DELIVERY_TRANSIENT_ATTEMPTS, e)
            return None, e
    return None, last_exc



def build_input_media(file_row: aiosqlite.Row, caption: Optional[str] = None):
    """Build the appropriate InputMedia object for send_media_group based on
    the file's media_type. Returns None for album-ineligible types
    (document / audio / voice / sticker / video_note)."""
    file_id = file_row["file_id"]
    media_type = file_row["media_type"]
    if media_type not in ALBUM_ELIGIBLE_TYPES:
        return None  # document/voice/sticker/video_note can't go in albums
    try:
        if media_type == "photo":
            return InputMediaPhoto(media=file_id, caption=caption)
        elif media_type == "video":
            return InputMediaVideo(media=file_id, caption=caption)
        elif media_type == "animation":
            return InputMediaAnimation(media=file_id, caption=caption)
    except Exception as e:  # noqa: BLE001
        logger.error("build_input_media failed for type=%s: %s", media_type, e)
        return None



async def send_album(bot, chat_id: int, files: List[aiosqlite.Row],
                     caption: Optional[str] = None,
                     protect_content: bool = False, *,
                     payload_code: Optional[str] = None
                     ) -> Tuple[List[int], int]:
    """Send files as Telegram media groups (albums).

    Album rules (Issue 3):
      - Only photo / video / animation are grouped (chunks of 10: 10+10+5...).
      - document / audio / voice / sticker / video_note are sent individually
        via send_file() (sequential fallback). This avoids Telegram's
        "Document can't be mixed with other media types" rejection.
      - Caption is applied only to the first item of the first album chunk.
    Returns (list_of_all_sent_message_ids, count_sent).

    V5.2 (bot.log 18 @ 03:40:39 "Album send failed (chunk 0): Timed out"):
    TRANSIENT chunk errors are retried with bounded exponential backoff
    BEFORE falling back to sequential. Only the FAILED chunk falls back;
    chunks already delivered are never re-sent (no duplicates). Each
    attempt/result is logged (BOT6_DELIVERY_ALBUM / BOT6_DELIVERY_RETRY).
    """
    all_msg_ids: List[int] = []
    sent_count = 0

    # NETWORK PLATFORM (V25 FINAL §6/§7): albums through a NETWORK bot
    # go through the two-stage Delivery Channel architecture with REAL
    # album semantics — Stage A copies every storage master into the
    # Delivery Channel (per-file durable jobs), Stage B delivers the
    # collection via the Network Bot's copyMessages (≤10-file ordered
    # chunks — a genuine Telegram media-group album), with an honest
    # sequential fallback. The main-bot-scoped file_ids in
    # build_input_media are NOT bot-portable (never reused across bot
    # identities) — the Delivery Channel is the correct transport.
    if _is_network_bot_client(bot):
        try:
            ids, count = await _network_send_files_by_source(
                bot, chat_id, files, protect_content=protect_content,
                payload_code=payload_code)
            if ids:
                all_msg_ids.extend(ids)
                sent_count += count
            return all_msg_ids, sent_count
        except NameError:
            # Namespace-not-yet-wired (isolated test harness): fall
            # through to per-file delivery below — never crash.
            pass
        for f in files:
            mid = await _network_send_file_by_source(
                bot, chat_id, f, protect_content=protect_content,
                payload_code=payload_code)
            if mid:
                all_msg_ids.append(mid)
                sent_count += 1
            await asyncio.sleep(0.3)
        return all_msg_ids, sent_count

    # Partition: album-eligible vs must-be-sequential.
    album_files = [f for f in files if f["media_type"] in ALBUM_ELIGIBLE_TYPES]
    unsupported = [f for f in files if f["media_type"] not in ALBUM_ELIGIBLE_TYPES]

    if album_files:
        # Chunk into groups of ALBUM_MAX_ITEMS (10): 10 + 10 + 5 ...
        chunks = [album_files[i:i + ALBUM_MAX_ITEMS]
                  for i in range(0, len(album_files), ALBUM_MAX_ITEMS)]
        for chunk_idx, chunk in enumerate(chunks):
            media_list = []
            chunk_rows = []  # keep source rows for sequential fallback
            for i, f in enumerate(chunk):
                cap = caption if (chunk_idx == 0 and i == 0) else None
                im = build_input_media(f, caption=cap)
                if im:
                    media_list.append(im)
                    chunk_rows.append(f)
            if not media_list:
                continue
            kw = {"protect_content": bool(protect_content)}

            async def _send_chunk() -> list:
                # Issue 4: always pass protect_content explicitly (True or
                # False) so album delivery honors the resolved protection.
                return await bot.send_media_group(chat_id=chat_id,
                                                  media=media_list, **kw)

            messages, chunk_err = await _send_with_retries(
                f"album chunk={chunk_idx} files={len(media_list)} chat={chat_id}",
                _send_chunk)
            if messages:
                for m in messages:
                    mid = getattr(m, "message_id", None)
                    if mid:
                        all_msg_ids.append(mid)
                sent_count += len(media_list)
                logger.info("BOT6_DELIVERY_ALBUM chunk=%s files=%s "
                            "result=ok messages=%s",
                            chunk_idx, len(media_list), len(messages))
                continue
            logger.warning("Album send failed (chunk %d): %s. Falling back "
                           "to sequential.", chunk_idx, chunk_err)
            for f in chunk_rows:
                mid = await send_file(bot, chat_id, f,
                                      protect_content=protect_content,
                                      payload_code=payload_code)
                if mid:
                    all_msg_ids.append(mid)
                    sent_count += 1
                await asyncio.sleep(0.3)

    # Send unsupported media individually (document/voice/sticker/video_note/audio).
    for f in unsupported:
        mid = await send_file(bot, chat_id, f, protect_content=protect_content,
                              payload_code=payload_code)
        if mid:
            all_msg_ids.append(mid)
            sent_count += 1
        await asyncio.sleep(0.3)

    return all_msg_ids, sent_count



# ============================================================
# DELIVERY ENGINE
# ============================================================
def _source_confirmed_unavailable(file_row) -> bool:
    """V25 FINAL §10 (bot-35.log file_pk=688): TRUE when the indexed
    file's source is CONFIRMED unavailable (source_status='unavailable'
    — written ONLY after the recovery probe proved the storage message
    deleted). Deliveries must NOT re-execute the dead operation (the
    stale file_id send + source recovery re-probe loop the log shows at
    06:29:06 → 06:31:18); they skip straight to the actionable state.
    A re-upload re-points the canonical row and clears the flag
    (BOT6_INDEX_CANONICAL_REPOINT), making delivery retryable again."""
    try:
        return str(_safe_row_get(file_row, "source_status") or "").lower() \
            == "unavailable"
    except Exception:  # noqa: BLE001 — gate must never crash delivery
        return False


async def _send_source_unavailable_notice(
        bot, chat_id: int, file_row: aiosqlite.Row,
        payload_code: Optional[str]) -> None:
    """V25 FINAL §10 — the actionable state for a CONFIRMED-unavailable
    source: the user is told the file is gone (an admin must re-upload
    it) instead of a retry button that can never succeed. NO dead
    operation is re-executed; the notice is honest, never a spinner."""
    file_pk = file_row["id"] if "id" in file_row.keys() else None
    text = ("\u26a0\ufe0f This file's source is no longer available.\n"
            "It was removed from storage — an admin must re-upload it "
            "before it can be delivered again.")
    logger.error(
        "BOT6_DELIVERY_SOURCE_UNAVAILABLE_SKIP file_pk=%s media=%s "
        "chat=%s payload_code=%s (source CONFIRMED unavailable — the "
        "dead send/recovery operation is NOT re-executed; the "
        "actionable notice was sent instead)",
        file_pk, _safe_row_get(file_row, "media_type"), chat_id,
        payload_code or "-")
    try:
        await safe_send_text(bot, chat_id, text)
    except TelegramError:
        pass


async def _send_delivery_failure(bot, chat_id: int, file_row: aiosqlite.Row,
                                 payload_code: Optional[str]) -> None:
    """V5.2: the FINAL per-file failure notice — an actionable
    [🔄 Retry Failed File] button (when the delivery context is known)
    instead of only the generic text. The retry callback re-enters the SAME
    delivery pipeline (fresh Access Engine authorization via
    handle_retry_failed_file -> _deliver_files_core) — never a bypass."""
    file_pk = file_row["id"] if "id" in file_row.keys() else None
    text = "\u274C Failed to deliver this file."
    kb: Optional[InlineKeyboardMarkup] = None
    if payload_code and file_pk:
        text += "\nTap Retry below to try this file again."
        # V26 (callback_data safety): 'retryfile:' + a raw payload slug +
        # ':<file_pk>' exceeded Telegram's 64-byte callback_data limit for
        # the PRODUCTION payload-787 slug (54 chars -> 70 bytes ->
        # Button_data_invalid kills the whole failure notice). Named
        # payloads embed the compact reversible 'i<payload_id>' form
        # (the retryfile handler resolves it back to the canonical slug
        # server-side); structurally short link forms pass through.
        _rarg = str(payload_code)
        try:
            if _rarg and not (_rarg[:1] in ("m", "c", "r")
                              and len(_rarg) <= 16):
                _prow = await db.get_payload(_rarg) \
                    if hasattr(db, "get_payload") else None
                if _prow is not None:
                    _rarg = f"i{int(_prow['id'])}"
        except Exception:  # noqa: BLE001 — fall back to the raw arg
            _rarg = str(payload_code)
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(
                "\U0001F504 Retry Failed File",
                callback_data=f"retryfile:{_rarg}:{int(file_pk)}")
        ]])
    else:
        text += "\nPlease try again later."
    try:
        await safe_send_text(bot, chat_id, text, reply_markup=kb)
    except TelegramError:
        pass



# ============================================================
# PHASE 7 HOTFIX — STALE file_id RECOVERY (bot-token change)
# ============================================================
# bot.log 22 (03:33 token change @Moviefilven_bot -> @Imagedux_bot):
# every delivery failed with "Wrong file identifier/http url specified"
# because stored file_ids were issued to the OLD bot, and re-indexing
# skipped them as exact file_unique_id duplicates (discarding the fresh
# valid ids). The helpers below implement the recovery contract:
#   * file_id            -> the CURRENT bot's sendable identifier;
#   * file_unique_id     -> dedup/identity ONLY, never sent to Telegram;
#   * channel_id/message_id -> source recovery reference (unchanged).


async def _recover_file_id_from_source(bot, file_row) -> Optional[Dict[str, Any]]:
    """Recover a fresh, current-bot file_id for a canonical indexed file from
    its ORIGINAL storage-channel message, then atomically repair the DB row.

    Contract (hotfix spec):
      * The fetch is INTERNAL: copy/forward lands in an ADMIN chat, is
        deleted immediately, and never reaches the recipient — therefore
        hide_delivery_source can NOT and does NOT block this recovery.
      * Identity discipline: the recovered media's file_unique_id must match
        the stored one (or, for NULL-identity rows, must not belong to a
        DIFFERENT row) and the media type must match — otherwise the source
        message now hosts a different file and the canonical record is left
        untouched (no repair, delivery fails honestly).
      * Only the file_id column is repaired (atomic UPDATE under the write
        lock); the canonical row (pk, source refs, payload references) is
        always preserved.
    Returns the fresh media info dict on success (DB already repaired), else
    None (every failure is logged).
    """
    file_pk = _safe_row_get(file_row, "id")
    src_channel = _safe_row_get(file_row, "channel_id")
    src_msg = _safe_row_get(file_row, "message_id")
    stored_unique = _safe_row_get(file_row, "file_unique_id")
    stored_type = _safe_row_get(file_row, "media_type")
    if file_pk is None or src_channel is None or src_msg is None:
        logger.error("BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                     "reason=missing_source_ref (cannot recover)", file_pk)
        return None
    admin_chat = await _recovery_admin_chat_id()
    if not admin_chat:
        logger.error("BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                     "reason=no_admin_chat (no internal fetch target available)",
                     file_pk)
        return None
    logger.info(
        "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s channel_id=%s message_id=%s "
        "admin_chat=%s result=started reason=file_id_stale "
        "hide_source_bypassed=True (internal fetch — never user-visible)",
        file_pk, src_channel, src_msg, admin_chat)
    try:
        info, fwd_mid = await fetch_channel_media(
            bot, admin_chat, int(src_channel), int(src_msg))
        try:
            if fwd_mid:
                await bot.delete_message(admin_chat, fwd_mid)
        except TelegramError:
            pass
        if not info or not info.get("file_id"):
            logger.error(
                "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s channel_id=%s "
                "message_id=%s result=failed reason=source_fetch_failed "
                "(message deleted / inaccessible)", file_pk, src_channel, src_msg)
            # V25 S6 (bot-31.log file_pk=665): distinguish DELETED from
            # INACCESSIBLE with the tri-state probe so the row's state is
            # honest. CONFIRMED deleted -> source_status='unavailable' (the
            # row, payload refs and historical metadata are preserved —
            # only the state flips, and the SAME file being re-sent later
            # re-points the canonical row and restores 'available').
            _iso_now = None
            try:
                import datetime as _dtmod
                _iso_now = lambda: _dtmod.datetime.now(  # noqa: E731
                    _dtmod.timezone.utc).isoformat()
            except Exception:  # noqa: BLE001
                _iso_now = lambda: ""  # noqa: E731
            try:
                # Late-binding: resolve through the composed namespace in
                # production (a local module import would bypass the
                # namespace's collaborators); direct module calls have the
                # name injected by the harness.
                verdict = await _probe_message_exists(  # noqa: F821
                    bot, admin_chat, int(src_channel), int(src_msg))
                if verdict is False:
                    await db.mark_indexed_file_source_status(
                        int(file_pk), "unavailable",
                        note=(f"delivery recovery: source message "
                              f"{src_channel}/{src_msg} confirmed deleted "
                              f"@ {_iso_now()}"))
                    logger.info(
                        "BOT6_DELIVERY_SOURCE_MARKED_UNAVAILABLE file_pk=%s "
                        "channel_id=%s message_id=%s probe=confirmed_deleted "
                        "(row preserved; a re-upload of the same file "
                        "re-points the canonical reference and restores "
                        "availability)", file_pk, src_channel, src_msg)
                elif verdict is None:
                    logger.info(
                        "BOT6_DELIVERY_SOURCE_UNVERIFIABLE file_pk=%s "
                        "channel_id=%s message_id=%s (transient — source "
                        "status NOT changed)", file_pk, src_channel, src_msg)
            except Exception as e:  # noqa: BLE001 — state marking is best-effort
                logger.debug("source-status probe failed for file #%s: %s",
                             file_pk, e)
            return None
        # --- identity discipline: same file or NO repair ---
        fresh_unique = info.get("file_unique_id")
        if stored_unique and fresh_unique != stored_unique:
            logger.error(
                "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                "reason=identity_mismatch stored_unique_id=%s fresh_unique_id=%s "
                "(source message now hosts a DIFFERENT file — canonical record "
                "NOT modified)", file_pk, stored_unique, fresh_unique)
            return None
        if not stored_unique and fresh_unique:
            other = await db.get_indexed_file_by_unique_id(fresh_unique)
            if other is not None and _safe_row_get(other, "id") is not None \
                    and int(_safe_row_get(other, "id")) != int(file_pk):
                logger.error(
                    "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                    "reason=identity_conflict fresh_unique_id=%s belongs_to="
                    "%s (different canonical row — NOT modified)",
                    file_pk, fresh_unique, _safe_row_get(other, "id"))
                return None
        if info.get("media_type") != stored_type:
            logger.error(
                "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                "reason=media_type_mismatch stored=%s fresh=%s (canonical "
                "record NOT modified)", file_pk, stored_type,
                info.get("media_type"))
            return None
        # --- atomic repair of the canonical row's file_id ONLY ---
        repaired = await db.repair_indexed_file_file_id(
            int(file_pk), str(info["file_id"]))
        if repaired:
            # PHASE 5 security hardening: file_id values are download
            # capabilities — logged REDACTED (prefix+length), never verbatim.
            from app.media.repair import redact_file_id as _redact_fid
            logger.info(
                "BOT6_DELIVERY_FILE_ID_REPAIRED file_pk=%s result=ok "
                "old_file_id=%s new_file_id=%s atomic=True "
                "canonical_row_preserved=True source_ref_unchanged=%s/%s",
                file_pk, _redact_fid(_safe_row_get(file_row, "file_id")),
                _redact_fid(info["file_id"]), src_channel, src_msg)
        else:
            logger.info(
                "BOT6_DELIVERY_FILE_ID_REPAIRED file_pk=%s "
                "result=already_current (stored==fresh; identity verified "
                "against source)", file_pk)
        return info
    except Exception as e:  # noqa: BLE001 — recovery must never raise into delivery
        logger.error(
            "BOT6_DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
            "reason=exception exc=%s.%s", file_pk, type(e).__module__,
            type(e).__name__)
        return None



async def _maybe_pre_repair_stale_file_id(bot, file_row, desc: str
                                          ) -> Optional[aiosqlite.Row]:
    """PHASE 7 HOTFIX (proactive): ONLY while FILE_IDS_STALE_EPOCH is armed
    (bot-token change detected at startup). Probes the stored file_id with
    getFile; on a definitive invalid result, recovers + repairs from the
    source BEFORE the send attempt so the user never sees a failed delivery.
    Ambiguous probe results ('unknown', e.g. files > 20MB) proceed to the
    normal send — reactive recovery still guards. Returns a re-read DB row
    when a repair happened, else None (caller keeps the original row)."""
    if not FILE_IDS_STALE_EPOCH:
        return None
    try:
        file_pk = _safe_row_get(file_row, "id")
        stored = _safe_row_get(file_row, "file_id")
        if file_pk is None or not stored:
            return None
        probe = await _file_id_probe(bot, stored)
        if probe != "invalid":
            return None
        logger.error(
            "BOT6_DELIVERY_FILE_ID_INVALID %s reason=getfile_probe_invalid "
            "epoch_stale=True (stored file_id is not sendable by THIS bot — "
            "recovering from source BEFORE the send attempt)", desc)
        fresh = await _recover_file_id_from_source(bot, file_row)
        if fresh and fresh.get("file_id"):
            fresh_row = await db.get_indexed_file_by_id(int(file_pk))
            if fresh_row is not None and fresh_row["file_id"] != stored:
                return fresh_row
        return None
    except Exception as e:  # noqa: BLE001 — proactive path must never raise
        logger.warning("BOT6_DELIVERY_FILE_ID_INVALID %s reason=probe_error "
                       "exc=%s (falling back to send attempt)", desc, e)
        return None



def _build_media_sender(bot, chat_id: int, row, kw: Dict[str, Any]):
    """PHASE 7 HOTFIX: the SINGLE media-send dispatch factory. The primary
    send and the post-recovery retry use the SAME dispatch (the retry just
    binds a row whose file_id was repaired), so a repaired delivery is
    byte-for-byte identical to a normal one — same caption, duration,
    protection and send method for the row's media_type."""
    media_type = row["media_type"]
    caption = truncate(_safe_row_get(row, "caption"), 1024)
    duration = _safe_row_get(row, "duration")

    async def _send() -> Message:
        if media_type == "video":
            return await bot.send_video(
                chat_id, row["file_id"], caption=caption,
                duration=duration, **kw)
        if media_type == "document":
            return await bot.send_document(
                chat_id, row["file_id"], caption=caption, **kw)
        if media_type == "photo":
            return await bot.send_photo(
                chat_id, row["file_id"], caption=caption, **kw)
        if media_type == "audio":
            return await bot.send_audio(
                chat_id, row["file_id"], caption=caption,
                duration=duration, **kw)
        if media_type == "voice":
            return await bot.send_voice(
                chat_id, row["file_id"], caption=caption,
                duration=duration, **kw)
        if media_type == "animation":
            return await bot.send_animation(
                chat_id, row["file_id"], caption=caption,
                duration=duration, **kw)
        if media_type == "video_note":
            return await bot.send_video_note(
                chat_id, row["file_id"], **kw)
        return await bot.send_sticker(chat_id, row["file_id"], **kw)

    return _send



async def _recover_and_retry_once(bot, chat_id: int, file_row,
                                  kw: Dict[str, Any], desc: str
                                  ) -> Optional[int]:
    """PHASE 7 HOTFIX (reactive): the stored file_id was REJECTED by Telegram
    ("Wrong file identifier/http url specified"). The SAME id is NEVER
    re-sent: recover a fresh, current-bot file_id from the original storage
    message, atomically repair the DB, then retry the delivery exactly ONCE.
    A failed retry or a failed recovery is terminal for this file (the
    actionable Retry Failed File button re-enters the full pipeline later).
    Returns the sent message_id or None."""
    try:
        file_pk = _safe_row_get(file_row, "id")
        stale_fid = _safe_row_get(file_row, "file_id")
        fresh_info = await _recover_file_id_from_source(bot, file_row)
        if not (fresh_info and fresh_info.get("file_id")):
            logger.error(
                "BOT6_DELIVERY_RECOVERY_FAILED %s reason=source_recovery_failed "
                "(delivery NOT retried — the rejected file_id is never re-sent)",
                desc)
            return None
        fresh_row = await db.get_indexed_file_by_id(int(file_pk)) \
            if file_pk is not None else None
        if fresh_row is None or fresh_row["file_id"] == stale_fid:
            logger.error(
                "BOT6_DELIVERY_RECOVERY_FAILED %s reason=repair_did_not_apply "
                "(DB row not re-readable or unchanged — NOT retrying the "
                "rejected id)", desc)
            return None
        retry_sender = _build_media_sender(bot, chat_id, fresh_row, kw)
        sent2, _err2 = await _send_with_retries(
            f"{desc} file_id_state=repaired", retry_sender)
        if sent2 and getattr(sent2, "message_id", None):
            logger.info(
                "BOT6_DELIVERY_FILE %s result=ok file_id=repaired msg_id=%s "
                "(self-recovered from the source channel; single retry)",
                desc, sent2.message_id)
            return sent2.message_id
        logger.error(
            "BOT6_DELIVERY_RECOVERY_FAILED %s reason=retry_failed_after_repair "
            "error=%s (single-retry policy — no further attempts with any id)",
            desc, _err2)
        return None
    except Exception as e:  # noqa: BLE001 — recovery retry must never raise
        logger.error(
            "BOT6_DELIVERY_RECOVERY_FAILED %s reason=exception exc=%s.%s",
            desc, type(e).__module__, type(e).__name__)
        return None



async def send_file(bot, chat_id: int, file_row: aiosqlite.Row,
                    protect_content: bool = False, *,
                    payload_code: Optional[str] = None) -> Optional[int]:
    """Deliver an indexed file by file_id, never exposing the source channel.

    Returns the message_id of the sent message (for auto-delete) or None on failure.

    V5.2 (bot.log 18 @ 03:40:47): TRANSIENT Telegram/network errors are now
    RETRIED with bounded exponential backoff (1s/2s, 3 total attempts) —
    only the FAILED file, never the already-delivered ones. Deterministic
    rejections (BadRequest) and permission errors (Forbidden) are not
    retried. When every attempt fails, the user receives the actionable
    [🔄 Retry Failed File] button (see _send_delivery_failure) instead of
    only the generic failure text.

    Issue 4 — protection enforcement:
      * `protect_content` is ALWAYS passed explicitly (True or False) to every
        send_* / copy_message call so Telegram content protection is applied
        consistently (forwards disabled where supported) across single files,
        collections, albums and previews.
      * The copy_message fallback (from the storage channel) is GUARDED by
        hide_delivery_source: when hiding is ON, the bot never copies from the
        source channel (which could leak it); instead it reports failure. This
        keeps the source channel invisible under all protection configs.

    PHASE 7 HOTFIX (bot.log 22 — token-change incident):
      * PROACTIVE: while FILE_IDS_STALE_EPOCH is armed (bot identity changed
        at startup), the stored file_id is probed via getFile first and, when
        definitively invalid, recovered + repaired from the source channel
        BEFORE the send attempt (internal fetch — hide_delivery_source never
        blocks recovery).
      * REACTIVE: when the send is rejected with "Wrong file identifier/http
        url specified", the same id is NEVER re-sent — the file_id is
        recovered from the original storage message, the DB row is atomically
        repaired (only file_id changes; the canonical row and every payload
        reference are preserved), and the delivery is retried exactly ONCE.
        Transient-error retry semantics are unchanged.
    """
    media_type = file_row["media_type"]
    # Issue 4: always pass protect_content explicitly (True or False) so every
    # delivery path honors the resolved protection setting.
    kw = {"protect_content": bool(protect_content)}
    file_pk = file_row["id"] if "id" in file_row.keys() else None
    desc = f"file_pk={file_pk if file_pk is not None else '-'} media={media_type} chat={chat_id}"

    # NETWORK PLATFORM (v29, spec §22/§23/§30): when the SERVING bot is a
    # NETWORK worker, the stored file_id (main-bot-scoped) is NEVER used.
    # Delivery goes through the NATIVE SOURCE COPY transport (the file's
    # durable channel+message reference) — the one transport that is
    # bot-scoped correct by construction. No cross-bot file_id reuse, no
    # file_unique_id in send APIs, no downloads.
    if _is_network_bot_client(bot):
        return await _network_send_file_by_source(
            bot, chat_id, file_row, protect_content=protect_content,
            payload_code=payload_code)

    known_type = media_type in ("video", "document", "photo", "audio",
                                "voice", "animation", "video_note", "sticker")
    # V25 FINAL §10 (bot-35.log file_pk=688): a CONFIRMED-unavailable
    # source is never re-attempted — no stale file_id send, no repeated
    # recovery probe. The actionable notice replaces the dead operation.
    if _source_confirmed_unavailable(file_row):
        await _send_source_unavailable_notice(
            bot, chat_id, file_row, payload_code)
        return None
    sent: Optional[Message] = None
    if known_type:
        # PHASE 7 HOTFIX (proactive): stale epoch -> validate/repair the
        # stored file_id before attempting delivery. A returned row replaces
        # this one (same canonical record; only file_id repaired).
        _pre_row = await _maybe_pre_repair_stale_file_id(bot, file_row, desc)
        if _pre_row is not None:
            file_row = _pre_row
        _primary_send = _build_media_sender(bot, chat_id, file_row, kw)

        sent, _err = await _send_with_retries(desc, _primary_send)
        if sent and getattr(sent, "message_id", None):
            logger.info("BOT6_DELIVERY_FILE %s result=ok msg_id=%s",
                        desc, sent.message_id)
            return sent.message_id
        if _err is not None:
            if is_wrong_file_id_error(_err):
                # PHASE 7 HOTFIX (reactive): Telegram rejected the stored
                # file_id — self-recover from the source, repair the DB,
                # retry once. The user-visible copy fallback below is NOT
                # used after a wrong-file-id rejection (the source message
                # either hosts the same file — recovery handles it — or a
                # different one, which copy would misdeliver).
                logger.error(
                    "BOT6_DELIVERY_FILE_ID_INVALID %s error=%s epoch_stale=%s "
                    "(stored file_id is not sendable by THIS bot — recovering "
                    "from the original source message)",
                    desc, _err, FILE_IDS_STALE_EPOCH)
                _recovered_mid = await _recover_and_retry_once(
                    bot, chat_id, file_row, kw, desc)
                if _recovered_mid:
                    return _recovered_mid
                await _send_delivery_failure(bot, chat_id, file_row,
                                             payload_code)
                return None
            logger.error("Delivery failed after retries (media=%s): %s",
                         media_type, _err)
    else:
        # Unknown type: only copy from source if hide_delivery_source is OFF.
        if await hide_delivery_source_active():
            logger.warning("send_file: unknown media_type=%s; refusing "
                           "copy_message fallback (hide_delivery_source ON)",
                           media_type)

    # Fallback: copy_message straight from the storage channel.
    # Issue 4: when hide_delivery_source is ON, NEVER copy from the source
    # channel (it could expose the source). Fail gracefully instead.
    if await hide_delivery_source_active():
        logger.warning("send_file: primary delivery failed for media=%s; "
                       "skipping source copy fallback (hide_delivery_source ON)",
                       media_type)
        await _send_delivery_failure(bot, chat_id, file_row, payload_code)
        return None
    try:
        async def _copy_send() -> Message:
            return await bot.copy_message(chat_id, file_row["channel_id"],
                                          file_row["message_id"], **kw)
        sent, _err = await _send_with_retries(f"{desc} fallback=source_copy",
                                              _copy_send)
        if sent and getattr(sent, "message_id", None):
            logger.info("BOT6_DELIVERY_FILE %s result=ok fallback=source_copy "
                        "msg_id=%s", desc, sent.message_id)
            return sent.message_id
        if _err is not None:
            logger.error("Fallback copy_message failed: %s", _err)
    except TelegramError as e:
        logger.error("Fallback copy_message failed: %s", e)
    await _send_delivery_failure(bot, chat_id, file_row, payload_code)
    return None



# ============================================================
# BOTV13 UNIFIED DELIVERY ENGINE
# ============================================================
# THE single post-enforce_access delivery helper. Every delivery subsystem
# (finalize_delivery, deliver_message_file, download_collection_all,
# deliver_collection_file, auto_deliver_unlocked_payload, handle_retrieve)
# calls this ONE function. This eliminates the 7x duplicated delivery
# boilerplate found in BOTV12 and the entire class of "forgot collection
# routing" bugs.
#
# CONTRACT:
#   - The caller MUST have already called enforce_access() (or, for
#     auto_deliver_unlocked_payload, completed the equivalent force-join
#     re-check). This helper NEVER calls enforce_access.
#   - PHASE 7 (Task 2): in addition to the caller-side Access Engine check,
#     this helper runs the LAST-LINE Watch Ads delivery gate
#     (_watch_ads_delivery_gate) so that a Watch-Ads-gated payload can NEVER
#     reach actual content delivery without a server-verified unlock (or a
#     completed referral unlock — the OR semantics — or an admin exemption).
#     This is defense in depth: even an unknown/future caller path that skips
#     enforce_access cannot deliver a WA-gated payload.
#   - The caller MUST pass the correct `files` list:
#       * Single file delivery -> [file_row]
#       * Collection delivery  -> _load_collection_files(code)  (ALL files)
#     This helper NEVER loads files itself — it trusts the caller's list.
# ============================================================


async def _watch_ads_delivery_gate(user_id: int, payload_row: Optional[aiosqlite.Row],
                                   payload_code: str = ""
                                   ) -> Tuple[bool, str]:
    """PHASE 7 (Task 2): LAST-LINE Watch Ads authorization defense.

    Evaluated inside _deliver_files_core immediately BEFORE any content is
    sent. Returns (allowed, reason). `allowed` is False ONLY when ALL of
    these hold:
      * the payload has Watch Ads enabled AND the global master switch is ON
        (exactly the access_engine gate definition — payloads with WA off, or
        global OFF, behave exactly as before), AND
      * the recipient is NOT an admin (access_engine exempts admins first), AND
      * the recipient holds NO server-verified rewarded unlock inside its
        validity window (db.watch_ad_unlock_valid), AND
      * the recipient has NOT completed the referral unlock for this payload
        (REFERRAL OR WATCH ADS — a completed referral always authorizes; the
        gate must never create AND semantics), AND
      * the referral requirement is not trivially satisfied (required<=0
        with an active campaign means instant unlock, exactly like
        access_engine).

    NOTHING here may send UI: the caller renders the denial (the standard
    requirement screen path already ran — a False here means an abnormal
    caller and is logged as WATCH_AD_BYPASS_BLOCKED for forensics).
    """
    try:
        if payload_row is None:
            # Fallback resolution for callers that legitimately deliver without
            # a payload row (retrieve passes None to skip stats re-bumps). The
            # Watch Ads gate still applies to NAMED payload codes (m<link> /
            # c<code> / r-ranges have no payload row and no WA flag — the
            # lookup returns nothing, exactly like before).
            _code = (payload_code or "").strip()
            if _code and not _code.startswith((MSG_LINK_PREFIX,
                                               COLLECTION_LINK_PREFIX)) \
                    and not is_range_link(_code) and not is_msg_link(_code):
                payload_row = await db.get_payload(_code)
        if payload_row is None:
            return True, "no_payload_row"
        if "id" not in payload_row.keys() or not payload_row["id"]:
            return True, "no_payload_id"
        # Global OFF / payload flag OFF -> exact legacy behaviour.
        if not await _watch_ads_gate_active(payload_row):
            return True, "watch_ads_inactive"
        # Admins are exempt exactly like access_engine (its FIRST check).
        if await is_admin(int(user_id)):
            return True, "admin_exempt"
        pid = int(payload_row["id"])
        # 1) Server-verified rewarded unlock (status='rewarded', window open).
        ad_ok, ad_exp = await db.watch_ad_unlock_valid(int(user_id), pid)
        if ad_ok:
            logger.info(
                "WATCH_AD_ACCESS_DECISION user_id=%s payload_id=%s allowed=True "
                "reason=delivery_gate_unlock_valid unlock_expires=%s "
                "path=_deliver_files_core (defense gate)",
                user_id, pid, (ad_exp or "-")[:19])
            return True, "unlock_valid"
        # 2) Referral OR path: a completed referral unlock authorizes by itself.
        campaign = await db.get_referral_campaign_by_payload(pid)
        if campaign and _safe_row_get(campaign, "enabled"):
            required = int(campaign["required_referrals"] or 0)
            if required <= 0:
                return True, "referral_instant_unlock"
            rec = await db.get_or_create_unlock_record(
                pid, int(campaign["id"]), int(user_id), required)
            if rec and _safe_row_get(rec, "unlocked"):
                return True, "referral_unlocked"
        # 2b) NETWORK POINTS OR path (v29, spec §51): a valid point unlock
        # authorizes by itself — the delivery gate must never create AND
        # semantics between Points and the other alternatives.
        if await _point_access_active() and \
                await db.point_unlock_valid(pid, int(user_id)):
            return True, "points_unlocked"
        # 3) Locked: completed_ads < required_ads and no referral unlock and
        #    no point unlock — the payload must NOT be delivered here.
        return False, "watch_ad_locked"
    except Exception as e:  # noqa: BLE001
        # Fail CLOSED is wrong here for admin delivery? No — fail closed for
        # content, but never crash the engine. A gate error blocks delivery
        # (security first) and is logged loudly for repair.
        logger.error(
            "WATCH_AD_ACCESS_DECISION user_id=%s payload_id=%s allowed=False "
            "reason=gate_error exc=%s.%s (delivery blocked — investigate)",
            user_id,
            (payload_row["id"] if (payload_row is not None
                                   and "id" in payload_row.keys()) else "-"),
            type(e).__module__, type(e).__name__)
        return False, "gate_error"



async def handle_retry_failed_file(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    code: str, file_pk: int,
                                    user: User) -> None:
    """V5.2: [🔄 Retry Failed File] — re-deliver ONE file whose (retried)
    primary delivery ultimately failed (bot.log 18 @ 03:40:47).

    Re-enters the SAME pipeline — never a bypass:
      * fresh Access Engine authorization via enforce_access (the single
        chokepoint: Force Join re-checked; an expired Watch Ads unlock
        window re-renders the requirement screen);
      * delivery via _deliver_files_core (protection, delivery message,
        per-file stats, auto-delete scheduling — the single engine).

    Anti-tamper: the file must belong to the delivery context encoded in
    the callback (named payload / collection / m<link>), mirroring
    deliver_collection_file's C2 membership check — a user cannot tamper
    callback_data into delivering arbitrary indexed files.
    """
    q = update.callback_query
    if not q:
        return
    try:
        file_pk_i = int(file_pk)
    except (TypeError, ValueError):
        await safe_answer_callback(q, "Invalid request.", show_alert=True)
        return
    file_row = await db.get_indexed_file_by_id(file_pk_i)
    if not file_row:
        await safe_answer_callback(q, "File not found.", show_alert=True)
        return
    # Resolve + verify the delivery context.
    payload_row: Optional[aiosqlite.Row] = None
    resolved: bool = False
    try:
        payload_row = await db.get_payload(code)
    except Exception:  # noqa: BLE001
        payload_row = None
    if payload_row and _safe_row_get(payload_row, "index_id"):
        # Named single-file payload: the file must be its indexed file.
        if int(_safe_row_get(payload_row, "index_id")) == file_pk_i:
            resolved = True
    if not resolved and is_collection_link(code):
        # Collection delivery: verify membership (C2-style anti-tamper).
        # V26 (message-872 identity fix): the CANONICAL predicate — a
        # single-file payload named 'clip…' is never misrouted into the
        # collection-membership branch (its named-payload resolution above
        # already matched it; the naive startswith could never be reached
        # for it, but a 'c<non-hex>' slug must not re-enter here either).
        collection_code = parse_collection_link(code)
        items = await db.get_collection_items(collection_code)
        belongs = any(
            item["message_id"] == file_row["message_id"]
            and item["channel_id"] == file_row["channel_id"]
            for item in items
        )
        if belongs:
            resolved = True
            # Collection payloads may have a "c<code>" row (display name,
            # delete_after) — pass it through so timers/protection match.
            if payload_row is None:
                try:
                    payload_row = await db.get_payload(code)
                except Exception:  # noqa: BLE001
                    payload_row = None
    if not resolved and code.startswith(MSG_LINK_PREFIX) \
            and code[1:].isdigit():
        # m<link> direct delivery: the file must be that indexed message.
        if int(code[1:]) == int(file_row["message_id"]):
            resolved = True
            payload_row = None
    if not resolved:
        await safe_answer_callback(
            q, "This file is not part of this delivery.", show_alert=True)
        logger.warning(
            "BOT6_DELIVERY_RETRY file_pk=%s code=%s user_id=%s "
            "result=rejected reason=context_mismatch",
            file_pk_i, (code or "-")[:40], user.id if user else 0)
        return
    # Fresh authorization — the Access Engine is the single chokepoint. When
    # not authorized it has ALREADY rendered the requirement screen (FJ page
    # / Watch Ads / referral dashboard) — never deliver past it.
    if not await enforce_access(update, context, user,
                                payload_code=code, link_arg=code):
        logger.info(
            "BOT6_DELIVERY_RETRY file_pk=%s code=%s user_id=%s "
            "result=not_authorized (requirement screen rendered)",
            file_pk_i, (code or "-")[:40], user.id if user else 0)
        return
    await safe_answer_callback(q, "Retrying file delivery…")
    logger.info("BOT6_DELIVERY_RETRY file_pk=%s code=%s user_id=%s "
                "result=retry_started", file_pk_i, (code or "-")[:40],
                user.id if user else 0)
    chat_id = q.message.chat_id if q.message else user.id
    res = await _deliver_files_core(
        context.bot, chat_id=chat_id, user_id=user.id,
        payload_row=payload_row,
        payload_code=code,
        files=[file_row],
        delivery_type="single",
        stat_key=None,
        bump_file_stats=True,
    )
    delivered = bool(res and res.get("sent_count"))
    logger.info("BOT6_DELIVERY_RETRY file_pk=%s code=%s user_id=%s result=%s",
                file_pk_i, (code or "-")[:40], user.id if user else 0,
                "delivered" if delivered else "failed_again")



async def finalize_delivery(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             payload_str: str, user: User) -> None:
    """Run the Access Engine then deliver the file & bump stats + auto-delete.

    BOTV13: Unified Delivery Engine. Routes collection payloads to the
    collection menu (never sends a single file via index_id). Single-file
    payloads use _deliver_files_core. Fixes the BOTV12 regression where
    collection payload unlock sent only one file.
    """
    row = await db.get_payload(payload_str)
    if not row:
        # Issue 16/22: clear, useful error. Never expose internal IDs.
        await reply_protected(update,
            "\u274C Delivery link unavailable.\n\n"
            "Reason: This link has been removed or expired."
        )
        return

    # Access Engine V1: THE single authorization chokepoint. Replaces the old
    # scattered force-join + referral-gate checks. No delivery may bypass it.
    # For named payloads this resolves OPEN / FORCE_JOIN / FORCE_JOIN_REFERRAL
    # and renders the correct requirement screen if denied.
    if not await enforce_access(update, context, user,
                                payload_id=row["id"], payload_code=payload_str,
                                link_arg=payload_str):
        return

    # ================================================================
    # BOTV13 COLLECTION ROUTING (Phase 3/4 fix)
    # ================================================================
    # If this payload is a collection payload (payload name is a c<code> link),
    # NEVER use row["index_id"] (which is only the FIRST file — nominal).
    # Instead, bump named-payload stats + show the collection menu, reusing
    # the proven BOTV10 collection delivery path (Download/Browse/Share).
    # Fresh re-authorization happens when the user clicks Download/Browse
    # (Issue 36). This fixes the regression where collection payload unlock
    # sent only one file via finalize_delivery -> get_indexed_file_by_id.
    # ================================================================
    if is_collection_link(payload_str):
        collection_code = parse_collection_link(payload_str)
        if not collection_code:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C Invalid collection link.",
            )
            return
        # Bump named-payload stats (this IS a named payload row).
        await db.increment_clicks(row["id"])
        await db.record_view(row["id"], user.id)
        await db.increment_stat("range_downloads")
        # One-time collection payload: expire after first access.
        if row["one_time"]:
            await db.update_payload_field(row["id"], "status", "expired")
            logger.info("One-time collection payload %s expired after access.",
                        row["payload"])
        # Reuse the proven BOTV10 collection menu (Download/Browse/Share/Back).
        await show_collection_menu(update, context, collection_code)
        return

    # ================================================================
    # SINGLE-FILE PATH — delegate to the Unified Delivery Engine.
    # ================================================================
    file_row = await db.get_indexed_file_by_id(row["index_id"])
    if not file_row:
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C The file linked to this payload is missing from storage.",
        )
        return

    await _deliver_files_core(
        context.bot, chat_id=user.id, user_id=user.id,
        payload_row=row,
        payload_code=payload_str,
        files=[file_row],
        delivery_type="single",
        stat_key="payload_downloads",
    )



async def deliver_message_file(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                message_id: int, user: User) -> None:
    """Delivery path for m<link> direct links: bypass payload lookup entirely,
    resolve by indexed_files.message_id, respect force-join + rate limit + stats.

    BOTV13: delegates the post-auth delivery to the Unified Delivery Engine.
    """
    if not rate_limiter.check(user.id):
        await reply_protected(update, 
            "\u23F3 Too many requests. Please wait a minute and try again."
        )
        return

    file_row = await db.get_indexed_file_by_message_id(message_id)
    if not file_row:
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "\u274C Invalid or expired link.",
        )
        return

    # Access Engine V1: m<link> deliveries have no payload row, so the engine
    # applies FORCE_JOIN semantics (the legacy behaviour). No delivery bypasses it.
    m_arg = f"{MSG_LINK_PREFIX}{message_id}"
    if not await enforce_access(update, context, user,
                                payload_code=m_arg, link_arg=m_arg):
        return

    # Delegate to the Unified Delivery Engine. No payload_row (m<link> has none),
    # so per-payload stats + one-time expiry are skipped; the global default
    # delete timer is used (helper falls back to auto_delete_default).
    await _deliver_files_core(
        context.bot, chat_id=user.id, user_id=user.id,
        payload_row=None,
        payload_code=f"{MSG_LINK_PREFIX}{message_id}",
        files=[file_row],
        delivery_type="single",
        stat_key="msgid_downloads",
    )



async def attempt_delivery(update: Update, context: ContextTypes.DEFAULT_TYPE,
                            payload_str: str, user: User) -> None:
    """Resolve payload -> run auth checks -> hand off to finalize_delivery."""
    if not rate_limiter.check(user.id):
        await reply_protected(update, 
            "\u23F3 Too many requests. Please wait a minute and try again."
        )
        return

    row = await db.get_payload(payload_str)
    if not row:
        # Issue 16/22: clear, useful error.
        await reply_protected(update, 
            "\u274C Delivery link unavailable.\n\n"
            "Reason: This link has been removed or expired."
        )
        return

    if row["status"] != "active":
        await reply_protected(update, 
            "\u274C Delivery link unavailable.\n\n"
            "Reason: This link has been disabled or expired."
        )
        return

    if row["expires_at"]:
        try:
            exp = datetime.fromisoformat(row["expires_at"])
            if datetime.now(timezone.utc) > exp:
                await reply_protected(update, 
                    "\u274C Delivery link unavailable.\n\n"
                    "Reason: This link has expired."
                )
                return
        except ValueError:
            pass

    if row["max_clicks"] and row["max_clicks"] > 0 and row["current_clicks"] >= row["max_clicks"]:
        await reply_protected(update, 
            "\u274C Delivery link unavailable.\n\n"
            "Reason: This link has reached its maximum number of uses."
        )
        return

    # Password gate.
    if row["password"]:
        verified: Set[str] = set(context.user_data.get("pw_verified", []))
        if payload_str.lower() not in verified:
            context.user_data["awaiting_password"] = payload_str.lower()
            await reply_protected(update, 
                "\U0001F512 This payload is password protected.\n\n"
                "Please reply with the password."
            )
            return

    await finalize_delivery(update, context, payload_str, user)



async def _resolve_forwarded_file_row(msg: Message) -> Tuple[Optional[int], Optional[int], Optional[aiosqlite.Row]]:
    """Resolve a forwarded message to (channel_id, message_id, indexed_row).

    Issue 6 lookup order (returns first valid match):
      1. forward_origin message id  -> indexed_files(channel_id, message_id)
      2. indexed_files.message_id   (global, for stripped-origin forwards)
      3. file_unique_id             (fingerprint, for copied messages)
      4. file_id                    (last resort, for protected channels)
    Never fails if the file already exists in indexed_files.
    """
    channel_id, message_id = extract_forward_origin(msg)

    # Priority 1: forward_origin -> exact (channel_id, message_id) match.
    if channel_id and message_id:
        row = await db.get_indexed_file_by_channel_msg(channel_id, message_id)
        if row:
            return channel_id, message_id, row

    # Priority 2: indexed_files.message_id (global). Handles the case where
    # forward origin is stripped but the message_id happens to match an indexed
    # file (common when admin forwards from a channel whose posts are indexed).
    if message_id:
        row = await db.get_indexed_file_by_message_id(message_id)
        if row:
            return row["channel_id"], message_id, row

    # Priority 3 + 4: media fingerprint by file_unique_id then file_id.
    fwd_info = extract_media(msg)
    if fwd_info:
        fuid = fwd_info.get("file_unique_id")
        if fuid:
            row = await db.get_indexed_file_by_unique_id(fuid)
            if row:
                return row["channel_id"], row["message_id"], row
        fid = fwd_info.get("file_id")
        if fid:
            # file_id last-resort lookup.
            cur = await db.conn.execute(
                "SELECT * FROM indexed_files WHERE file_id = ? LIMIT 1", (fid,)
            )
            row = await cur.fetchone()
            if row:
                return row["channel_id"], row["message_id"], row

    return channel_id, message_id, None



async def _message_identity_trace(channel_id: int, message_id: int,
                                   payload_row=None) -> None:
    """V26 MESSAGE_IDENTITY_TRACE — the safe structured identity trace for
    a storage-channel MESSAGE (the message-872 class of defects).

    The CANONICAL lookup is (channel_id, message_id) — NEVER message_id
    alone (message 872 exists in OTHER channels too; only the exact pair
    is this file's identity). The trace walks the full relation chain:

        channel_id -> message_id
          -> indexed_files row (file_pk, file_id, file_unique_id,
             media_type, file_name, file_size, upload_date)
          -> payloads relation (id, routing slug, index_id, status)
          -> website publication (opaque_id, published)
          -> Network Bot delivery (global public_code)

    Safe fields only: NO captions/filenames are logged verbatim beyond a
    bounded prefix (they can embed user text); file_id/file_unique_id are
    Telegram media identifiers (not secrets — they are unusable without
    the bot). Every hop logs 'present'/'absent' honestly so a broken link
    in the chain is visible from the log alone.
    """
    try:
        frow = None
        try:
            frow = await db.get_indexed_file_by_channel_msg(
                int(channel_id), int(message_id))
        except Exception:  # noqa: BLE001 — repo may lack the method
            frow = None
        if frow is None:
            logger.info(
                "MESSAGE_IDENTITY_TRACE channel_id=%s message_id=%s "
                "indexed_file=absent "
                "(no indexed_files row for the EXACT (channel, message) "
                "pair — the canonical identity lookup is the pair, never "
                "message_id alone)",
                channel_id, message_id)
            return
        _fpk = int(frow["id"]) if "id" in frow.keys() else 0
        _fname = str(frow["file_name"] or "")[:24]
        _fsize = int(frow["file_size"] or 0) if "file_size" in frow.keys() else 0
        _mtype = str(frow["media_type"] or "-")
        prowd = payload_row
        if prowd is None:
            try:
                prowd = await db.find_single_payload_by_channel_message(
                    int(channel_id), int(message_id))
            except Exception:  # noqa: BLE001
                prowd = None
        site = "-"
        net = "-"
        if prowd is not None:
            _pid = int(prowd["id"])
            try:
                wrow = await db.find_website_payload_for_canonical(
                    payload_id=_pid)
                if wrow is not None:
                    site = f"{wrow['opaque_id']} published={int(wrow['published'])}"
            except Exception:  # noqa: BLE001
                site = "lookup_failed"
            try:
                cur = await db.conn.execute(
                    "SELECT public_code FROM global_payload_links "
                    "WHERE payload_id = ? ORDER BY id DESC LIMIT 1",
                    (_pid,))
                g = await cur.fetchone()
                if g is not None:
                    net = str(g["public_code"])
            except Exception:  # noqa: BLE001
                net = "lookup_failed"
        logger.info(
            "MESSAGE_IDENTITY_TRACE channel_id=%s message_id=%s "
            "file_pk=%s file_unique_id=%s media_type=%s file_name=%s "
            "file_size=%s payload_id=%s payload_code=%s index_id=%s "
            "payload_status=%s website=%s network_link=%s "
            "(canonical identity = the (channel_id, message_id) pair)",
            channel_id, message_id, _fpk,
            str(frow["file_unique_id"] or "-")[:12], _mtype, _fname,
            _fsize,
            int(prowd["id"]) if prowd is not None else "-",
            str(prowd["payload"] or "-")[:40] if prowd is not None else "-",
            int(prowd["index_id"] or 0) if prowd is not None else "-",
            str(prowd["status"] or "-") if prowd is not None else "-",
            site, net)
    except Exception:  # noqa: BLE001 — the trace must never break delivery
        logger.debug("MESSAGE_IDENTITY_TRACE failure", exc_info=True)


async def _finalize_forward_batch(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  batch: List[Message]) -> None:
    """Issue 2 Critical Fix: store EVERY forwarded message_id explicitly in a
    new collection. Never infers from a range (start=min, end=max is GONE).

    Works with 2..100+ files, albums, mixed media, and delayed arrivals.
    Each message_id is stored in collection_items with its position so
    delivery is always exact — no gaps, no extra files, no missing files.
    """
    if not batch:
        return

    # Resolve every forwarded message to an indexed_files row.
    resolved_msg_ids: List[int] = []
    channel_set: Set[int] = set()
    unresolved: List[Message] = []
    for m in batch:
        ch_id, msg_id, row = await _resolve_forwarded_file_row(m)
        if row:
            resolved_msg_ids.append(int(row["message_id"]))
            channel_set.add(int(row["channel_id"]))
        elif ch_id and msg_id:
            resolved_msg_ids.append(int(msg_id))
            channel_set.add(int(ch_id))
        else:
            unresolved.append(m)

    if not resolved_msg_ids:
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "❌ Cannot identify source files.\n\n"
            "Forward information may be stripped or protected.\n"
            "Please forward files directly from a storage channel.",
        )
        return

    if len(channel_set) > 1:
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "❌ Files from multiple channels detected.\n"
            "All files must come from the same storage channel.",
        )
        return

    channel_id = channel_set.pop()

    # BOT6 P10/P12: semantic duplicate detection. Instead of silently skipping
    # when the same message_ids are forwarded again, check if an existing
    # collection/payload already references these files. If yes → show the
    # existing payload manager. If no → start the wizard. NEVER silently skip.
    existing_coll = await db.find_collection_by_message_ids(channel_id, resolved_msg_ids)
    # V26 (bot-37.log message-872 identity fix): SINGLE-FILE payload
    # detection by the EXACT channel+message identity. Production evidence:
    # message 872 (channel -1004460709020, file_pk 1174) was payload 787's
    # canonical file, yet every re-forward produced
    # "existing_collection_id=None decision=create_wizard" (17:26, 17:27,
    # 00:49, 01:29 — four wizards for one file) because the duplicate
    # detection was COLLECTION-ONLY. A single-file forward now resolves its
    # payload by exact identity FIRST (collections still win when the file
    # is a collection member — collection detection runs first above).
    existing_single = None
    if not existing_coll and len(resolved_msg_ids) == 1:
        existing_single = await db.find_single_payload_by_channel_message(
            channel_id, resolved_msg_ids[0])
    logger.info(
        "BOT6_PAYLOAD_DETECT source_message_ids=%s existing_collection_id=%s "
        "existing_payload_id=%s active_wizard=%s decision=%s",
        resolved_msg_ids,
        existing_coll["collection_id"] if existing_coll else None,
        int(existing_single["id"]) if existing_single else None,
        bool(_pcw_get(context)),
        "existing_payload" if (existing_coll or existing_single)
        else "create_wizard",
    )
    if existing_coll:
        # P12: show existing payload found screen with Edit/Recreate/Manage Files.
        coll_code = existing_coll["collection_id"]
        coll_payload_code = f"{COLLECTION_LINK_PREFIX}{coll_code}"
        # Look up the named payload (if any) for this collection link.
        prow = await db.get_payload(coll_payload_code)
        display_name = ""
        if prow:
            display_name = get_payload_display_name(
                prow["payload"] if "payload" in prow.keys() else "",
                display_name=_safe_row_get(prow, "display_name"))
        file_count = int(existing_coll["file_count"] or 0)
        text = (
            f"\U0001F4E6 Existing Payload Found\n\n"
            f"Payload: {display_name or '(unnamed)'}\n"
            f"Routing ID: {coll_payload_code}\n"
            f"Files: {file_count}\n"
            f"Status: Active\n\n"
            f"These files already belong to an existing payload."
        )
        # BOT7 FIX (NoneType crash): a raw collection may have NO named payload
        # row (prow is None) — the Edit button requires a payload id, so it is
        # only rendered when the named payload exists. Recreate / Manage Files
        # work either way.
        edit_btn = (InlineKeyboardButton("\u270F\uFE0F Edit",
                                          callback_data=f"pcw:edit:{prow['id']}")
                    if prow else
                    InlineKeyboardButton("\u270F\uFE0F Edit",
                                          callback_data="admn:noop"))
        kb = InlineKeyboardMarkup([
            [edit_btn,
             InlineKeyboardButton("\u267B\uFE0F Recreate", callback_data=f"pcw:recreate:{coll_code}")],
            [InlineKeyboardButton("\U0001F441 Preview", callback_data=f"linkpreview:c:{coll_code}"),
             InlineKeyboardButton("\U0001F4C1 Manage Files", callback_data=f"managefiles:{coll_code}")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
        ])
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)
        logger.info("BOT6_PAYLOAD_EXISTS collection_id=%s payload_code=%s",
                    coll_code, coll_payload_code)
        return

    if existing_single:
        # V26 MESSAGE_IDENTITY_TRACE: trace the full identity chain for the
        # exact (channel_id, message_id) pair — the message-872 class.
        await _message_identity_trace(channel_id, resolved_msg_ids[0],
                                       existing_single)
        # V26 (message-872 identity fix): the EXACT-identity single-file
        # payload screen — the same P12 "Existing Payload Found" UX as the
        # collection branch, with the payload's OWN manager buttons (the
        # detail panel, its file preview, the preview screen). The admin
        # lands on the payload they already built instead of a wizard that
        # would silently mint a duplicate.
        sprow = existing_single
        s_display = get_payload_display_name(
            sprow["payload"] if "payload" in sprow.keys() else "",
            display_name=_safe_row_get(sprow, "display_name"))
        s_status = str(sprow["status"] or "active").title()
        text = (
            f"\U0001F4E6 Existing Payload Found\n\n"
            f"Payload: {s_display or '(unnamed)'}\n"
            f"Routing ID: {sprow['payload']}\n"
            f"Files: 1 (message {resolved_msg_ids[0]} in {channel_id})\n"
            f"Status: {s_status}\n\n"
            f"This file already belongs to an existing payload."
        )
        _sp_id = int(sprow["id"])
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u270F\uFE0F Edit",
                                  callback_data=f"pcw:edit:{_sp_id}"),
             InlineKeyboardButton("\U0001F4CB Manage",
                                  callback_data=f"pldetail:{_sp_id}:0")],
            [InlineKeyboardButton("\U0001F4C1 File",
                                  callback_data=f"filepreview:{sprow['index_id']}"),
             InlineKeyboardButton("\U0001F441 Preview",
                                  callback_data=(
                                      f"linkpreview:m:{resolved_msg_ids[0]}"))],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:payloads")],
        ])
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             reply_markup=kb)
        logger.info(
            "BOT6_PAYLOAD_EXISTS payload_id=%s payload_code=%s "
            "source_message_ids=%s channel_id=%s identity=exact_single_file "
            "(V26 message-872 duplicate-detection fix)",
            _sp_id, sprow["payload"], resolved_msg_ids, channel_id)
        return

    # Check if a wizard is already active for this admin.
    # BOT7 FIX (wrong key): the old code checked the non-existent
    # `pcw_state` user_data key, so this guard NEVER fired and a second
    # forward silently replaced the running wizard. Use the real PCW_KEY.
    if _pcw_get(context):
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u23F3 Payload creation is already in progress.\n\n"
            "Complete or cancel the current wizard first.")
        return

    logger.info("Forward batch resolved: %d files -> explicit collection (channel=%s)",
                len(resolved_msg_ids), channel_id)

    # Auto-detect single vs collection. 1 file -> launch the Payload Creation
    # Wizard (Access Engine V1) so the admin configures access policy / referral
    # / preview BEFORE the payload is generated. The old behavior (immediate
    # m<link> with no configuration) is removed per spec. A quick m<link> is
    # still available via the "Single File Link" button in the Link Generator.
    if len(resolved_msg_ids) == 1:
        only_id = resolved_msg_ids[0]
        row = await db.get_indexed_file_by_channel_msg(channel_id, only_id)
        if not row:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "\u274C File not indexed.\n\nThis file is in a storage channel "
                "but hasn't been indexed yet.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001F504 Reindex Channel",
                                          callback_data=f"chreindex:{channel_id}")],
                    [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
                ]),
            )
            return
        # Transition directly into the wizard (no extra "Launching" message).
        await pcw_start(update, context, index_id=int(row["id"]))
        return

    # 2+ files: verify ALL files are indexed (each must have an indexed_files row).
    indexed_count = 0
    for mid in resolved_msg_ids:
        row = await db.get_indexed_file_by_channel_msg(channel_id, mid)
        if row:
            indexed_count += 1
    if indexed_count == 0:
        await safe_send_text(
            context.bot, update.effective_chat.id,
            f"\u274C Files not indexed.\n\n"
            f"Detected {len(resolved_msg_ids)} files.\n"
            f"None are indexed yet. Reindex the channel first.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F504 Reindex Channel",
                                      callback_data=f"chreindex:{channel_id}")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
            ]),
        )
        return
    if indexed_count < len(resolved_msg_ids):
        await safe_send_text(
            context.bot, update.effective_chat.id,
            f"\u274C Some forwarded files are not indexed.\n\n"
            f"Forwarded: {len(resolved_msg_ids)} files\n"
            f"Indexed: {indexed_count} files\n\n"
            f"Reindex the channel to ensure all files are available.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001F504 Reindex Channel",
                                      callback_data=f"chreindex:{channel_id}")],
                [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:links")],
            ]),
        )
        return

    # Access Engine V1: multi-file forward launches the Payload Creation Wizard
    # with the collection pre-selected. The collection is NOT created until the
    # admin confirms in the wizard. This gives identical UX whether 1 file or
    # 100 files are forwarded — the admin always configures policy/referral/
    # preview/delivery before anything is committed.
    await pcw_start_collection(update, context, channel_id, resolved_msg_ids)



async def _process_forward_batch_delayed(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                         batch_key: str) -> None:
    """Wait FORWARD_BATCH_FINALIZE_WAIT after the last forwarded message, then
    finalize the batch. Each new forward resets the timer (debounce), so
    slightly-delayed arrivals are all captured before processing."""
    await asyncio.sleep(FORWARD_BATCH_FINALIZE_WAIT)
    timer_key = f"{batch_key}_timer"
    # If a newer message arrived, it set its own timer; only the latest fires.
    if not context.user_data.get(timer_key):
        return
    context.user_data.pop(timer_key, None)
    batch = context.user_data.pop(batch_key, [])
    context.user_data.pop("awaiting_fwd_batch", None)
    if not batch:
        return
    logger.info("Processing forward batch: %d files (batch_key=%s)",
                len(batch), batch_key)
    await _finalize_forward_batch(update, context, batch)
