"""Admin panels — permissions, admin management, dashboard editor.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def _get_owner_id() -> int:
    """The first ADMIN_IDS entry is the owner (immutable, full access)."""
    return ADMIN_IDS[0] if ADMIN_IDS else 0


# ... existing code ...
async def is_admin(user_id: int) -> bool:
    """BOTV13 Phase 2: Check if a user is an active admin (owner or admins table)."""
    # 1. Force integer conversion for the config check
    try:
        uid = int(user_id)
    except (TypeError, ValueError):
        return False
    if uid in ADMIN_IDS:
        return True

    # 2. Check the database for BOTH integer and string formats safely.
    #    BOT7 hardening: if the DB is momentarily unavailable, fail safe — env
    #    admins still authenticate (check above), DB admins simply cannot be
    #    verified until the DB recovers (they cannot be spoofed either).
    try:
        row = await db.conn.execute(
            "SELECT is_active FROM admins WHERE user_id = ? OR user_id = ?",
            (uid, str(user_id))
        )
        r = await row.fetchone()
        return bool(r and r["is_active"])
    except Exception as e:  # noqa: BLE001
        logger.warning("BOT6_ADMIN_AUTH db_lookup_failed user_id=%s error=%s", user_id, e)
        return False

# ... existing code ...

async def is_owner(user_id: int) -> bool:
    """BOTV13 Phase 2: Check if a user is the owner (immutable full-access)."""
    return user_id == _get_owner_id()



async def get_admin_permissions(user_id: int) -> set:
    """BOTV13 Phase 2: Get the set of permission strings for a user.
    Owner always gets ALL permissions. Returns an empty set for non-admins."""
    if user_id == _get_owner_id():
        return set(ALL_PERMISSIONS)
    if user_id in ADMIN_IDS:
        # Env-based admins (legacy) get full access too (backward compat).
        return set(ALL_PERMISSIONS)
    try:
        row = await db.conn.execute(
            "SELECT permissions, is_active FROM admins WHERE user_id = ? OR user_id = ?",
            (int(user_id), str(user_id))
        )
        r = await row.fetchone()
    except Exception as e:  # noqa: BLE001
        logger.warning("BOT6_ADMIN_PERMISSION db_lookup_failed user_id=%s error=%s", user_id, e)
        return set()
    if not r or not r["is_active"]:
        return set()
    import json as _json
    try:
        perms = _json.loads(r["permissions"]) if r["permissions"] else {}
        return {k for k, v in perms.items() if v}
    except (ValueError, TypeError):
        return set()



async def has_permission(user_id: int, permission: str) -> bool:
    """BOTV13 Phase 2: Check if a user has a specific permission.
    Owner always has ALL permissions (server-side enforcement)."""
    if user_id == _get_owner_id():
        return True
    if user_id in ADMIN_IDS:
        return True  # legacy env-based admins have full access
    perms = await get_admin_permissions(user_id)
    return permission in perms



async def log_admin_action(admin_id: int, action: str, target_type: str = None,
                           target_id: int = None, details: str = None) -> None:
    """BOTV13 Phase 2: Record an admin action in the activity log (append-only)."""
    try:
        await db.conn.execute(
            """INSERT INTO admin_activity (admin_id, action, target_type, target_id, details, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (admin_id, action, target_type, target_id, details, _now_iso()),
        )
        await db.conn.commit()
    except Exception as e:  # noqa: BLE001
        logger.warning("Admin activity log: failed to record action %s by %s: %s", action, admin_id, e)



def main_panel_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("\U0001F4C2 Storage", callback_data="panel:storage"),
         InlineKeyboardButton("\U0001F517 Links", callback_data="panel:links")],
        [InlineKeyboardButton("\U0001F4CA Statistics", callback_data="panel:stats"),
         InlineKeyboardButton("\U0001F4E2 Channels", callback_data="panel:channels")],
        [InlineKeyboardButton("\U0001F3AD Start Message", callback_data="panel:startmsg"),
         InlineKeyboardButton("\U0001F4DA Help / User Guide", callback_data="panel:help")],
        [InlineKeyboardButton("\U0001F512 Protection", callback_data="panel:protection"),
         InlineKeyboardButton("\U0001F4E3 Broadcast", callback_data="panel:broadcast")],
        [InlineKeyboardButton("\U0001F510 Referral Dashboard", callback_data="panel:dashedit"),
         InlineKeyboardButton("\U0001F4CB Payload Manager", callback_data="pl:list")],
        [InlineKeyboardButton("\u2699\uFE0F Settings", callback_data="panel:settings"),
         InlineKeyboardButton("\U0001F451 Admin Dashboard", callback_data="panel:admin")],
        [InlineKeyboardButton("\U0001F310 Network Control", callback_data="panel:network"),
         InlineKeyboardButton("\U0001F6E1\uFE0F Platform Control", callback_data="panel:control")],
        [InlineKeyboardButton("\U0001F5A5\uFE0F Website", callback_data="panel:website")],
    ]
    return InlineKeyboardMarkup(rows)



async def show_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    channels = await db.list_storage_channels()
    storage_warning = ""
    if not channels:
        storage_warning = (
            "\n\u26A0\uFE0F *No storage channels configured.*\n"
            "Indexing is disabled until you add one.\n"
        )
    # Protection V3 status on the admin dashboard (simplified).
    pv3 = await resolve_protection_settings()
    fb_icon = "\U0001F7E2" if pv3["forward_blocking"] else "\U0001F534"
    ibm_icon = "\U0001F7E2" if pv3["internal_bot_messages"] else "\U0001F534"
    src_icon = "\U0001F7E2" if pv3["hide_source"] else "\U0001F534"
    pv3_ad = f"{pv3['auto_delete_seconds']}s" if pv3["auto_delete_seconds"] else "OFF"
    bot_display = escape_md(BOT_USERNAME) if BOT_USERNAME else "(detecting...)"
    text = (
        "*\U0001F916 Payload Delivery Bot - Admin Panel*\n\n"
        f"\U0001F517 Bot: @{bot_display}\n"
        f"\U0001F4C1 Files indexed: {await db.count_indexed_files()}\n"
        f"\U0001F517 Payloads: {await db.count_payloads()}\n"
        f"\U0001F4C2 Storage channels: {len(channels)}\n"
        f"\U0001F465 Users: {await db.total_users()}\n"
        f"\U0001F4E3 Broadcasts sent: {await db.get_stat('broadcast_count', 0)}\n\n"
        f"*\U0001F6E1 Protection Status*\n"
        f"Forward Blocking: {fb_icon} {'ON' if pv3['forward_blocking'] else 'OFF'}\n"
        f"Internal Bot Msgs: {ibm_icon} {'ON' if pv3['internal_bot_messages'] else 'OFF'}\n"
        f"Hide Source: {src_icon} {'ON' if pv3['hide_source'] else 'OFF'}\n"
        f"Auto Delete: {pv3_ad}\n"
        f"{storage_warning}"
    )
    if update.callback_query:
        await safe_edit_text(update.callback_query, text,
                             parse_mode=ParseMode.MARKDOWN,
                             reply_markup=main_panel_keyboard())
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             parse_mode=ParseMode.MARKDOWN,
                             reply_markup=main_panel_keyboard())



def back_to_main_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("\u2B05\uFE0F Back to Main", callback_data="panel:main")]]
    )



# ---------- BOTV13 PHASE 2: ADMIN DASHBOARD ----------
def _admin_status_badge(a) -> str:
    """Render a compact status badge for an admins-table row."""
    if a["is_owner"]:
        return "\U0001F451 OWNER"
    if a["is_active"]:
        return "\U0001F7E2 ACTIVE"
    return "\U0001F534 DISABLED"



def _count_perms(a) -> int:
    """Number of granted permissions for an admins-table row (owner = all)."""
    if a["is_owner"]:
        return len(ALL_PERMISSIONS)
    import json as _json
    try:
        perms = _json.loads(a["permissions"]) if a["permissions"] else {}
        return sum(1 for v in perms.values() if v)
    except (ValueError, TypeError):
        return 0



async def admin_dashboard_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOTV13 Phase 2 + BOT7 UX + PHASE 6 §5: Admin Control Center — manage
    admins, permissions, activity. Compact and Telegram-friendly.

    PHASE 6 §5 (duplicate-buttons fix): the Control Center previously ALSO
    carried five navigation buttons (Bot Settings, Payload Management, Force
    Join, Referral Dashboard, Analytics) that duplicate the MAIN panel's
    canonical controls — the admin saw the same controls twice (the reported
    "five duplicate buttons"). Root cause: overlapping navigation sets, not
    a render loop. Fix: this panel is admin-management ONLY; every feature
    control lives exactly once on the Main Panel (panel:main).
    """
    cur = await db.conn.execute("SELECT COUNT(*) AS c FROM admins WHERE is_active = 1")
    r = await cur.fetchone()
    active_count = int(r["c"]) if r else 0
    cur = await db.conn.execute("SELECT COUNT(*) AS c FROM admins WHERE is_active = 0 AND is_owner = 0")
    r = await cur.fetchone()
    disabled_count = int(r["c"]) if r else 0
    cur = await db.conn.execute("SELECT COUNT(*) AS c FROM admin_activity")
    r = await cur.fetchone()
    activity_count = int(r["c"]) if r else 0
    owner_id = _get_owner_id()
    owner_row = None
    if owner_id:
        cur = await db.conn.execute("SELECT * FROM admins WHERE user_id = ?", (owner_id,))
        owner_row = await cur.fetchone()
    if owner_row and owner_row["username"]:
        owner_display = f"@{owner_row['username']}"
    elif owner_row and owner_row["first_name"]:
        owner_display = owner_row["first_name"]
    else:
        owner_display = f"ID: {owner_id}"
    sep = "\u2500" * 12
    text = (
        "\U0001F451 ADMIN CONTROL CENTER\n\n"
        f"\U0001F464 Owner: {owner_display}\n"
        f"\U0001F7E2 Active Administrators: {active_count}\n"
        f"\U0001F534 Disabled Administrators: {disabled_count}\n\n"
        f"\U0001F6E1 Permission System: ACTIVE\n"
        f"\U0001F4CB Audit Log: {activity_count} entries\n"
        f"{sep}\n"
        "\n\u2139\uFE0F Feature controls (Settings, Payload Manager,\n"
        "Force Join, Referral, Analytics) live on the Main Panel\n"
        "(\u2B05\uFE0F Back) — exactly once each."
    )
    kb_rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\U0001F465 Manage Admins", callback_data="admn:list"),
         InlineKeyboardButton("\U0001F510 Permissions", callback_data="admn:perms")],
        [InlineKeyboardButton("\U0001F4CB Activity Log", callback_data="admn:activity"),
         InlineKeyboardButton("\u2795 Add Administrator", callback_data="admn:add")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ]
    # §5 regression guard: the Control Center must contain EXACTLY ONE
    # instance of each intended button. If a future edit ever introduces a
    # duplicate callback, it is logged loudly and deduplicated here so the
    # admin can never see a doubled keyboard.
    _seen: set = set()
    _dedup_rows: List[List[InlineKeyboardButton]] = []
    for row in kb_rows:
        _dedup_row = [b for b in row if b.callback_data
                      and not (b.callback_data in _seen or _seen.add(b.callback_data))]
        if _dedup_row:
            _dedup_rows.append(_dedup_row)
    if len(_dedup_rows) != len(kb_rows):
        logger.error("ADMIN_CONTROL_CENTER_BUTTON_COUNT duplicates detected — "
                     "deduplicated %d -> %d rows",
                     len(kb_rows), len(_dedup_rows))
    kb = InlineKeyboardMarkup(_dedup_rows)
    _flat_cbs = [b.callback_data for row in _dedup_rows for b in row]
    logger.info("ADMIN_CONTROL_CENTER_RENDER chat_id=%s buttons=%d "
                "unique_callbacks=%d",
                (update.effective_chat.id if update.effective_chat else 0),
                len(_flat_cbs), len(set(_flat_cbs)))
    logger.info("ADMIN_CONTROL_CENTER_BUTTON_COUNT count=%d unique=%d",
                len(_flat_cbs), len(set(_flat_cbs)))
    if update.callback_query:
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



async def admin_list_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOTV13 Phase 2 + BOT7 §11: list all admins with REAL status.

    User ID is the canonical identity (usernames can change); each entry shows
    status badge, @username, ID, and granted permission count."""
    cur = await db.conn.execute(
        "SELECT * FROM admins ORDER BY is_owner DESC, created_at ASC"
    )
    admins = await cur.fetchall()
    if not admins:
        text = "\U0001F465 Admins\n\nNo admins configured."
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2795 Add Admin", callback_data="admn:add")],
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:admin")],
        ])
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
        return
    lines = ["\U0001F465 Admins\n"]
    buttons: List[List[InlineKeyboardButton]] = []
    for a in admins:
        badge = _admin_status_badge(a)
        uname = f"@{a['username']}" if a["username"] else "(no username)"
        perm_count = _count_perms(a)
        lines.append(f"{badge}")
        lines.append(f"{uname}")
        lines.append(f"ID: {a['user_id']}")
        lines.append(f"Permissions: {perm_count}")
        lines.append("")
        btn_label = f"{badge.split()[0]} {uname} ({perm_count})"
        buttons.append([InlineKeyboardButton(
            btn_label,
            callback_data=f"admn:detail:{a['user_id']}",
        )])
    text = "\n".join(lines).rstrip()
    buttons.append([InlineKeyboardButton("\u2795 Add Admin", callback_data="admn:add")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:admin")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(buttons))



async def admin_add_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOTV13 Phase 2: Prompt for the new admin's Telegram user ID."""
    context.user_data["awaiting_admin_add"] = True
    logger.info("BOT6_ADMIN_WIZARD_START wizard=admin_add user_id=%s",
                update.effective_user.id if update.effective_user else None)
    text = (
        "\u2795 Add Admin\n\n"
        "Send the Telegram user ID of the new admin.\n"
        "They must have started the bot first.\n\n"
        "You can find a user's ID by forwarding their message to @userinfobot."
    )
    await safe_send_text(context.bot, update.effective_chat.id, text,
                         reply_markup=InlineKeyboardMarkup([
                             [InlineKeyboardButton("\u274C Cancel", callback_data="admn:list")],
                         ]))



async def admin_added_screen(update: Update, context: ContextTypes.DEFAULT_TYPE,
                             target_id: int) -> None:
    """BOT7 §9: post-add screen — the owner explicitly chooses what the new
    admin can access (Configure / Recommended / Full / Disable / Back)."""
    cur = await db.conn.execute(
        "SELECT * FROM admins WHERE user_id = ? OR user_id = ?",
        (int(target_id), str(target_id)))
    a = await cur.fetchone()
    if not a:
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Admin not found (add failed).")
        return
    uname = f"@{a['username']}" if a["username"] else f"ID:{a['user_id']}"
    perm_count = _count_perms(a)
    perms_label = f"{perm_count} granted" if perm_count else "\u2699\uFE0F Not configured"
    text = (
        "\U0001F464 New Admin Added\n\n"
        f"User: {uname} / ID: {a['user_id']}\n"
        f"Status: \U0001F7E2 Active\n\n"
        f"Permissions: {perms_label}\n\n"
        "Choose what this admin can access:"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2699\uFE0F Configure Permissions",
                              callback_data=f"admnew:perms:{a['user_id']}")],
        [InlineKeyboardButton("\U0001F4CB Grant Recommended Access",
                              callback_data=f"admnew:recommended:{a['user_id']}"),
         InlineKeyboardButton("\U0001F513 Grant Full Access",
                              callback_data=f"admnew:full:{a['user_id']}")],
        [InlineKeyboardButton("\u23F8 Disable", callback_data=f"admnew:disable:{a['user_id']}"),
         InlineKeyboardButton("\u21A9\uFE0F Back", callback_data="admn:list")],
    ])
    await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



async def _admnew_grant(update: Update, context: ContextTypes.DEFAULT_TYPE,
                        target_id: int, perm_list: List[str], label: str) -> None:
    """BOT7 §9 helper: grant a permission preset to an admin (server-side
    authorized). Cannot touch the owner."""
    q = update.callback_query
    user = q.from_user if q else update.effective_user
    if not await has_permission(user.id, PERM_MANAGE_PERMISSIONS):
        await safe_answer_callback(q, "You don't have permission to edit permissions.", show_alert=True)
        return
    if int(target_id) == _get_owner_id():
        await safe_answer_callback(q, "Owner permissions are always full.", show_alert=True)
        return
    # No escalation: the granter cannot grant permissions they don't have.
    for p in perm_list:
        if not await has_permission(user.id, p):
            await safe_answer_callback(q,
                f"You cannot grant '{p}' — you don't have it yourself.", show_alert=True)
            return
    import json as _json
    new_perms = {p: True for p in perm_list}
    await db.conn.execute(
        "UPDATE admins SET permissions = ?, updated_at = ? WHERE user_id = ? OR user_id = ?",
        (_json.dumps(new_perms), _now_iso(), int(target_id), str(target_id)),
    )
    await db.conn.commit()
    await log_admin_action(user.id, "edit_permission", "admin", int(target_id),
                           f"preset={label} count={len(perm_list)}")
    logger.info("BOT6_ADMIN_PERMISSION_CHANGE actor=%s target=%s preset=%s "
                "granted=%s", user.id, target_id, label, len(perm_list))
    await safe_answer_callback(q, f"\u2705 {label} applied ({len(perm_list)} permissions).")
    await admin_added_screen(update, context, int(target_id))



async def admin_detail_panel(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              target_user_id: int) -> None:
    """BOTV13 Phase 2: Admin detail + permissions configuration."""
    cur = await db.conn.execute(
        "SELECT * FROM admins WHERE user_id = ? OR user_id = ?",
        (int(target_user_id), str(target_user_id)))
    admin = await cur.fetchone()
    if not admin:
        await safe_answer_callback(update.callback_query, "Admin not found.", show_alert=True)
        return
    import json as _json
    perms = {}
    try:
        perms = _json.loads(admin["permissions"]) if admin["permissions"] else {}
    except (ValueError, TypeError):
        pass
    uname = f"@{admin['username']}" if admin["username"] else f"ID:{admin['user_id']}"
    badge = _admin_status_badge(admin)
    lines = [f"\U0001F464 {uname} — {badge}",
             f"ID: {admin['user_id']}",
             f"Permissions: {_count_perms(admin)}", "",
             "Permissions"]
    for group, perm_list in PERMISSION_GROUPS.items():
        lines.append(f"\n{group}")
        for p in perm_list:
            short = p.split(".")[-1].replace("_", " ").title()
            icon = "\u2705" if perms.get(p) else "\u274C"
            lines.append(f"  {icon} {short}")
    text = "\n".join(lines)
    buttons: List[List[InlineKeyboardButton]] = []
    if not admin["is_owner"]:
        can_manage = await has_permission(update.effective_user.id, PERM_MANAGE_PERMISSIONS)
        if can_manage:
            buttons.append([InlineKeyboardButton("\U0001F510 Configure Permissions",
                                                 callback_data=f"admn:editperms:{admin['user_id']}")])
        can_toggle = await has_permission(update.effective_user.id, PERM_MANAGE_ADMINS)
        if can_toggle:
            toggle_label = ("\U0001F7E2 Enable" if not admin["is_active"]
                            else "\u23F8 Disable")
            buttons.append([InlineKeyboardButton(toggle_label,
                                                 callback_data=f"admn:toggle:{admin['user_id']}")])
            buttons.append([InlineKeyboardButton("\U0001F5D1 Remove Admin",
                                                 callback_data=f"admn:remove:{admin['user_id']}")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="admn:list")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(buttons))



async def admin_activity_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """BOTV13 Phase 2: Recent admin activity log."""
    cur = await db.conn.execute(
        "SELECT * FROM admin_activity ORDER BY created_at DESC LIMIT 20"
    )
    entries = await cur.fetchall()
    if not entries:
        text = "\U0001F4CB Admin Activity\n\nNo activity recorded yet."
    else:
        lines = ["\U0001F4CB Admin Activity (last 20)\n"]
        for e in entries:
            ts = e["created_at"][:19].replace("T", " ") if e["created_at"] else ""
            action = e["action"]
            tgt = f" {e['target_type']}:{e['target_id']}" if e["target_type"] else ""
            lines.append(f"\u2022 [{ts}] admin:{e['admin_id']} {action}{tgt}")
        text = "\n".join(lines)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:admin")],
    ])
    await safe_edit_text(update.callback_query, text, reply_markup=kb)



async def admin_permission_editor(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   target_user_id: int) -> None:
    """BOTV13 Phase 2 + BOT7 §12: permission toggle editor for a specific admin.

    The message body shows the full grouped ✅/❌ matrix; buttons toggle each
    permission. Server-side has_permission() remains authoritative — hiding a
    button is NOT security."""
    cur = await db.conn.execute(
        "SELECT * FROM admins WHERE user_id = ? OR user_id = ?",
        (int(target_user_id), str(target_user_id)))
    admin = await cur.fetchone()
    if not admin:
        await safe_answer_callback(update.callback_query, "Admin not found.", show_alert=True)
        return
    import json as _json
    perms = {}
    try:
        perms = _json.loads(admin["permissions"]) if admin["permissions"] else {}
    except (ValueError, TypeError):
        pass
    uname = f"@{admin['username']}" if admin["username"] else f"ID:{admin['user_id']}"
    lines = [f"\U0001F510 Permissions for {uname}",
             f"ID: {admin['user_id']} — granted {len([1 for v in perms.values() if v])}",
             "", "Tap a permission below to toggle:"]
    for group, perm_list in PERMISSION_GROUPS.items():
        lines.append(f"\n\U0001F4E6 {group}")
        for p in perm_list:
            short = p.split(".")[-1].replace("_", " ").title()
            icon = "\u2705" if perms.get(p) else "\u274C"
            lines.append(f"  {icon} {short}")
    text = "\n".join(lines)
    buttons: List[List[InlineKeyboardButton]] = []
    for group, perm_list in PERMISSION_GROUPS.items():
        buttons.append([InlineKeyboardButton(f"--- {group} ---", callback_data="admn:noop")])
        row: List[InlineKeyboardButton] = []
        for p in perm_list:
            short = p.split(".")[-1].replace("_", " ").title()
            icon = "\u2705" if perms.get(p) else "\u274C"
            row.append(InlineKeyboardButton(
                f"{icon} {short}",
                callback_data=f"admperm:{admin['user_id']}:{p}",
            ))
            if len(row) == 2:
                buttons.append(row)
                row = []
        if row:
            buttons.append(row)
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data=f"admn:detail:{admin['user_id']}")])
    await safe_edit_text(update.callback_query, text, reply_markup=InlineKeyboardMarkup(buttons))



async def _dash_load_settings(context: ContextTypes.DEFAULT_TYPE) -> Dict[str, str]:
    """Load current dashboard settings from the DB (auto-save: no draft)."""
    return await db.get_all_dashboard_settings()



async def _dash_save_setting(key: str, value: str) -> None:
    """Auto-save a single setting to the DB (global scope)."""
    await db.set_dashboard_setting(key, value)



async def _dash_refresh_preview(bot, chat_id: int, context: ContextTypes.DEFAULT_TYPE,
                                 settings: Dict[str, str]) -> None:
    """Edit the SINGLE live preview message in-place. Creates it on first call.

    Tracks the preview message id in context.user_data['dash_preview_msg_id'] so
    subsequent refreshes edit the same message — never spams the chat. Uses the
    PRODUCTION renderer (render_referral_dashboard) so the preview exactly
    matches what end users receive.
    """
    class _MockCampaign:
        def __getitem__(self, key):
            if key == "id": return 0
            if key == "required_referrals": return 5
            if key == "payload_id": return 0
            if key == "payload_code": return "preview_payload"
            return None
        def keys(self):
            return ["id", "required_referrals", "payload_id", "payload_code"]

    class _MockUnlock:
        def __getitem__(self, key):
            if key == "completed_referrals": return 2
            if key == "unlocked": return 0
            return None
        def keys(self):
            return ["completed_referrals", "unlocked"]

    class _MockUser:
        def __init__(self):
            self.id = 0
            self.username = "admin"
            self.first_name = "Admin"

    rendered = await render_referral_dashboard(
        _MockCampaign(), _MockUnlock(), _MockUser(), settings_override=settings)
    text = rendered["text"]
    kb = rendered["keyboard"]
    preview_text = (
        f"\U0001F441 Live Preview\n"
        f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
        f"{text}"
    )
    msg_id = context.user_data.get("dash_preview_msg_id")
    if msg_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id, message_id=msg_id,
                text=preview_text, reply_markup=kb)
            return
        except TelegramError as e:
            logger.debug("Dash preview edit failed (%s) — sending new.", e)
    msg = await safe_send_text(bot, chat_id, preview_text, reply_markup=kb)
    if msg and msg.message_id:
        context.user_data["dash_preview_msg_id"] = msg.message_id



async def dashboard_editor_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V14: Main Dashboard Editor — Edit / Media / Preview / Settings / Reset."""
    settings = await _dash_load_settings(context)
    cap_on = settings.get("preview_caption_enabled", "1") == "1"
    link_on = settings.get("link_preview_enabled", "0") == "1"
    bar_label = next((lbl for sid, lbl in PROGRESS_BAR_STYLES
                      if sid == settings.get("progress_bar_style", "block")),
                     PROGRESS_BAR_STYLES[0][1])
    has_banner = bool(settings.get("dashboard_media_file_id"))
    banner_label = "\u2705 Banner set" if has_banner else "\U0001F5BC Dashboard Media"
    text = (
        f"*\U0001F4CA Referral Dashboard*\n\n"
        f"*Current Template*\n"
        f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
        f"Settings: Caption {'ON' if cap_on else 'OFF'} \u00B7 "
        f"Link Preview {'ON' if link_on else 'OFF'} \u00B7 {bar_label}\n"
        f"Banner: {'set' if has_banner else 'none'}\n\n"
        f"Edit the template, configure banner, or adjust settings."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u270F\uFE0F Edit Dashboard", callback_data="dash:edit")],
        [InlineKeyboardButton(banner_label, callback_data="dash:media")],
        [InlineKeyboardButton("\U0001F441 Live Preview", callback_data="dash:preview"),
         InlineKeyboardButton("\u2699\uFE0F Settings", callback_data="dash:settings")],
        [InlineKeyboardButton("\u267B\uFE0F Reset to Default", callback_data="dash:reset")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:main")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def dashboard_editor_edit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V12: Prompt the admin to send the complete dashboard template."""
    template = await db.get_dashboard_template()
    context.user_data["dash_edit_template"] = True
    # §36 markdown escaping: the template is ADMIN-CONFIGURED free-form text.
    # A backtick inside it would close the ``` pre-block and turn the rest
    # into raw Markdown ("can't find end of the entity" — the exact
    # safe_edit_text plain-fallback signature from production). Same
    # convention as md_code_span: backticks are neutralized for DISPLAY.
    template_display = str(template).replace("`", "'")
    text = (
        f"*\u270F\uFE0F Edit Dashboard*\n\n"
        f"Send the complete referral dashboard template.\n\n"
        f"*Variables (auto-filled at render time):*\n"
        f"`{{payload_name}}` `{{current}}` `{{required}}` `{{remaining}}`\n"
        f"`{{progress_bar}}` `{{referral_link}}` `{{user_name}}` `{{first_name}}`\n"
        f"`{{percentage}}` `{{dots}}` `{{motivation}}` `{{unlock_count}}`\n\n"
        f"`{{percentage}}` = 0-100 \u00B7 `{{dots}}` = \u25CF\u25CF\u25CB\u25CB\u25CB \u00B7 "
        f"`{{motivation}}` = dynamic message \u00B7 `{{unlock_count}}` = social proof\n\n"
        f"*Current template:*\n"
        f"```\n{template_display}\n```\n\n"
        f"The next message you send replaces the entire template.\n"
        f"It saves immediately — no Save button."
    )
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup([
                             [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:dashedit")],
                         ]))



async def dashboard_editor_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V11: Settings submenu — only non-template options."""
    settings = await _dash_load_settings(context)
    cap_on = settings.get("preview_caption_enabled", "1") == "1"
    link_on = settings.get("link_preview_enabled", "0") == "1"
    cur_bar = settings.get("progress_bar_style", "block")
    lines = [
        "*\u2699\uFE0F Dashboard Settings*",
        "",
        "Options that cannot be represented by template text.",
        "",
        f"\u2022 Preview Caption: {'ON' if cap_on else 'OFF'}",
        f"\u2022 Telegram Link Preview: {'ON' if link_on else 'OFF'}",
        f"\u2022 Progress Bar Style: {next((l for s, l in PROGRESS_BAR_STYLES if s == cur_bar), PROGRESS_BAR_STYLES[0][1])}",
    ]
    buttons: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton(f"\U0001F4DC Preview Caption: {'ON' if cap_on else 'OFF'}",
                              callback_data="dash:toggle:preview_caption_enabled"),
         InlineKeyboardButton(f"\U0001F517 Link Preview: {'ON' if link_on else 'OFF'}",
                              callback_data="dash:toggle:link_preview_enabled")],
    ]
    for sid, label in PROGRESS_BAR_STYLES:
        mark = "\u2713 " if sid == cur_bar else ""
        buttons.append([InlineKeyboardButton(f"{mark}{label}",
                                             callback_data=f"dash:setbar:{sid}")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:dashedit")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup(buttons))



async def dashboard_editor_media(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V14: Dashboard Media banner submenu — upload / remove / view status.

    This media is COMPLETELY SEPARATE from Preview Media. It's a decorative
    banner sent BEFORE the dashboard text. It has no buttons and is never
    edited — it stays visible while the dashboard below carries the keyboard.
    """
    settings = await _dash_load_settings(context)
    has_banner = bool(settings.get("dashboard_media_file_id"))
    banner_type = settings.get("dashboard_media_type", "")
    lines = [
        "*\U0001F5BC Dashboard Media*",
        "",
        "A decorative banner shown above the referral dashboard.",
        "Completely separate from Preview Media.",
        "",
        f"Status: {'set (' + banner_type + ')' if has_banner else 'none'}",
    ]
    buttons: List[List[InlineKeyboardButton]] = []
    if has_banner:
        buttons.append([InlineKeyboardButton("\U0001F504 Replace Banner",
                                             callback_data="dash:mediaupload")])
        buttons.append([InlineKeyboardButton("\u274C Remove Banner",
                                             callback_data="dash:mediaremove")])
    else:
        buttons.append([InlineKeyboardButton("\U0001F4E4 Upload Banner",
                                             callback_data="dash:mediaupload")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="panel:dashedit")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         parse_mode=ParseMode.MARKDOWN,
                         reply_markup=InlineKeyboardMarkup(buttons))



async def dashboard_editor_preview(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V11: Live preview — renders via the production renderer, single message."""
    settings = await _dash_load_settings(context)
    # Ensure the template is present in the settings dict for the renderer.
    if not settings.get("dashboard_template"):
        settings["dashboard_template"] = await db.get_dashboard_template()
    await safe_answer_callback(update.callback_query, "\U0001F441 Preview refreshed below:")
    await _dash_refresh_preview(context.bot, update.effective_chat.id, context, settings)
