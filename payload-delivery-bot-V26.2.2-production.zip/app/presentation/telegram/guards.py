"""Admin guards — admin_only decorator + permission notices.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def admin_only(func):
    """Decorator: restrict a handler to admins (env-based + DB-stored)."""

    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        # BOTV13 Phase 2 fix: use async is_admin() so DB-stored admins work.
        if not user or not await is_admin(user.id):
            if update.effective_message:
                await reply_protected(update,
                    "\u26D4 Access denied. Admins only."
                )
            return
        return await func(update, context)

    wrapper.__name__ = func.__name__
    return wrapper



async def _perm_denied_notice(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              action: str) -> None:
    """BOT7: uniform feedback when an admin lacks a permission. Shows a
    callback alert when invoked from a callback, otherwise sends a text
    message (media/forward contexts have no callback query)."""
    msg = f"\u274C You don't have permission to {action}."
    if update.callback_query:
        await safe_answer_callback(update.callback_query, msg, show_alert=True)
    elif update.effective_chat:
        await safe_send_text(context.bot, update.effective_chat.id, msg)
