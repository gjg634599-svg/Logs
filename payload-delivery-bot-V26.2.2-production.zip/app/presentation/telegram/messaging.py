"""Messaging helpers — safe send/edit, entity serialization, RateLimiter.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations

import logging

from app.presentation.telegram.state import (
    RATE_LIMIT_MAX,
    RATE_LIMIT_WINDOW,
)

# BOT-13 hardening: module-level logger binding. The namespace-rebound
# (runtime) copies of these functions resolve ``logger`` through the
# shared runtime namespace; a DIRECT module-level import previously hit
# NameError on the defensive log paths (the latent messaging.py defect
# this pins). Both resolve to the SAME "payload-bot" logger.
logger = logging.getLogger("payload-bot")

# V25 §10: the bounded cap (seconds) for in-handler FloodWait retries in
# safe_send_text — a commanded wait at or below this retries the send
# ONCE after sleeping; anything longer returns None honestly (never a
# multi-minute block of the update pipeline).
SAFE_SEND_FLOOD_RETRY_CAP = 3



# ============================================================
# HELPERS  (slugs / validation / formatting / time)
# ============================================================


# BOTV13: display_name validation. Allows human-readable names with spaces,
# mixed case, hyphens, and Unicode word characters. Rejects only: empty,
# too long (>128), or control characters. Strips Markdown specials so the
# name can never break parse_mode rendering.
# Control characters (C0 + C1 ranges) — always rejected.
# Markdown specials that could break parse_mode rendering — stripped.


# H3 Security Fix: password hashing. Passwords are stored as SHA-256 hashes
# (with a fixed salt prefix) instead of plaintext. This protects passwords
# if the database file is leaked. Existing plaintext passwords are detected
# by the lack of a "sha256:" prefix and re-hashed on first verification.


def build_msg_link(message_id: int) -> str:
    """Direct delivery link based on a storage-channel message_id (m<prefix>)."""
    return build_start_link(f"{MSG_LINK_PREFIX}{message_id}")



def generate_routing_id() -> str:
    """Generate a unique routing ID for a single-file payload (e.g. 'af81b920').

    The routing ID is immutable, unique, and never derived from the display
    name. It serves as the /start routing key so renaming the display name
    never breaks links.
    """
    return _secrets.token_hex(ROUTING_ID_LENGTH // 2)



async def _resolve_routing_id(arg: str, user_id: int = 0) -> Tuple[Optional[str], str]:
    """Extract the immutable routing ID from a /start argument.

    BOT6 P3: backward-compatible resolver. Tries in deterministic order:
    1. exact current payload code (full)
    2. exact collection code (c<code>)
    3. current routing suffix (last _ segment)
    4. legacy payload aliases / routing identifiers
    5. legacy collection identifiers
    6. progressively longer suffixes

    Logs BOT6_PAYLOAD_RESOLVE_START / _EXACT / _SUFFIX / _LEGACY / _RESULT / _FAIL
    so every resolution is reconstructable from logs.
    """
    logger.info("BOT6_PAYLOAD_RESOLVE_START user_id=%s raw_start_arg=%s", user_id, arg[:80])
    # 1. Try the full arg (exact current payload, old-style links, bare collection codes).
    full_row = await db.get_payload(arg)
    if full_row:
        logger.info("BOT6_PAYLOAD_RESOLVE_EXACT user_id=%s identifier=%s payload_id=%s found=True method=exact",
                    user_id, arg, full_row["id"] if "id" in full_row.keys() else None)
        logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=exact result=SUCCESS",
                    user_id, arg)
        return arg, "full"
    if is_collection_link(arg):
        logger.info("BOT6_PAYLOAD_RESOLVE_EXACT user_id=%s identifier=%s found=True method=exact_collection",
                    user_id, arg)
        logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=exact_collection result=SUCCESS",
                    user_id, arg)
        return arg, "full"

    # 2. Try legacy payload_aliases (old links may map to current payloads).
    try:
        alias_row = await db.alias_owner(arg)
        if alias_row:
            # alias_row has payload_id; look up the actual payload to get its code.
            owner_payload = await db.get_payload_by_id(int(alias_row["payload_id"]))
            if owner_payload:
                resolved_code = owner_payload["payload"] if "payload" in owner_payload.keys() else arg
                logger.info("BOT6_PAYLOAD_RESOLVE_LEGACY user_id=%s legacy_identifier=%s resolved_payload_id=%s method=legacy_alias",
                            user_id, arg, alias_row["payload_id"])
                logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=legacy_alias result=SUCCESS",
                            user_id, resolved_code)
                return resolved_code, "legacy_alias"
    except Exception:  # noqa: BLE001
        pass  # alias table may not exist or method missing

    # 3. Split by '_' and try suffixes from the end (shortest first).
    if "_" not in arg:
        logger.info("BOT6_PAYLOAD_RESOLVE_FAIL user_id=%s raw_arg=%s reason=no_matching_payload_or_collection",
                    user_id, arg[:80])
        return None, "none"
    parts = arg.split("_")
    # Try suffixes of increasing length: last 1, last 2, last 3, ... up to full.
    for suffix_len in range(1, len(parts) + 1):
        candidate = "_".join(parts[-suffix_len:])
        if suffix_len > 1 and candidate == arg:
            continue  # already tried as the full arg
        if is_collection_link(candidate):
            logger.info("BOT6_PAYLOAD_RESOLVE_SUFFIX user_id=%s identifier=%s suffix_len=%s found=True method=suffix_collection",
                        user_id, candidate, suffix_len)
            logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=suffix_collection result=SUCCESS",
                        user_id, candidate)
            return candidate, f"suffix{suffix_len}"
        row = await db.get_payload(candidate)
        if row:
            logger.info("BOT6_PAYLOAD_RESOLVE_SUFFIX user_id=%s identifier=%s suffix_len=%s found=True payload_id=%s method=suffix",
                        user_id, candidate, suffix_len, row["id"] if "id" in row.keys() else None)
            logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=suffix result=SUCCESS",
                        user_id, candidate)
            return candidate, f"suffix{suffix_len}"
        # Also try legacy aliases for each suffix candidate.
        try:
            alias_row = await db.alias_owner(candidate)
            if alias_row:
                owner_payload = await db.get_payload_by_id(int(alias_row["payload_id"]))
                if owner_payload:
                    resolved_code = owner_payload["payload"] if "payload" in owner_payload.keys() else candidate
                    logger.info("BOT6_PAYLOAD_RESOLVE_LEGACY user_id=%s legacy_identifier=%s resolved_payload_id=%s method=legacy_alias_suffix",
                                user_id, candidate, alias_row["payload_id"])
                    logger.info("BOT6_PAYLOAD_RESOLVE_RESULT user_id=%s resolved_identifier=%s resolution_method=legacy_alias_suffix result=SUCCESS",
                                user_id, resolved_code)
                    return resolved_code, "legacy_alias"
        except Exception:  # noqa: BLE001
            pass
    logger.info("BOT6_PAYLOAD_RESOLVE_FAIL user_id=%s raw_arg=%s reason=no_matching_payload_or_collection",
                user_id, arg[:80])
    return None, "none"



# Issue 8: human-readable media-type label for Browse Files. Never exposes
# filenames, message ids, payload ids or channel ids.


# ============================================================
# SAFE TELEGRAM SEND / EDIT / ANSWER HELPERS
# (prevents Markdown parse crashes + callback timeout crashes)
# ============================================================


# Issue #44: Global internal message protection helper.
# Defined early so safe_send_text can use it. All bot-generated messages
# get protect_content based on the internal_bot_messages V3 setting.
async def _get_internal_protect() -> bool:
    """Get the current internal_bot_messages protection setting."""
    try:
        return await _prot_v3_get("internal_bot_messages")
    except Exception:  # noqa: BLE001
        return True  # fail-closed: protect by default


# BOT-11 §8 keyboard-field defensive validation (production bug
# bot-11.log: a raw DB row dict reached Telegram as an
# InlineKeyboardButton text → BadRequest 'field "text" must be of type
# string' → swallowed → BOT6_CALLBACK_RESULT success=True). This layer
# guarantees a non-string text can NEVER reach Telegram again, whatever
# a future call site constructs.
_KEYBOARD_SAFE_PLACEHOLDER = "•"


def _coerce_button_text(value) -> str:
    """Best-effort SAFE string label for a non-string button text.

    Only simple scalars (str/int/float) are stringified; dicts, lists,
    objects and empty values collapse to the placeholder so no internal
    structure (a DB row repr, tokens, ...) is ever echoed to Telegram."""
    if isinstance(value, str):
        return value if value.strip() else _KEYBOARD_SAFE_PLACEHOLDER
    if isinstance(value, bool) or value is None:
        return _KEYBOARD_SAFE_PLACEHOLDER
    if isinstance(value, (int, float)):
        s = str(value)
        return s if s.strip() else _KEYBOARD_SAFE_PLACEHOLDER
    return _KEYBOARD_SAFE_PLACEHOLDER


def validate_keyboard_markup(markup):
    """Validate + repair an InlineKeyboardMarkup before it reaches Telegram.

    BOT-11 §8 defensive layer (exported — also used directly by tests):
    walks every button and, when ``text`` is not a non-empty ``str``,
    coerces it to a safe string label ("•" when nothing usable). Returns
    the ORIGINAL markup when it is already safe; a REBUILT markup when a
    fix was applied; the input unchanged (including None) otherwise.

    SECURITY: the fix log carries the button's text TYPE NAME and the
    first 40 chars of callback_data ONLY — never the button content
    (which may embed sensitive row data). NEVER raises: a broken
    keyboard must not crash the send path.
    """
    if markup is None:
        return None
    rows = getattr(markup, "inline_keyboard", None)
    if not rows:
        return markup
    try:
        new_rows = []
        changed = False
        for r_idx, row in enumerate(rows):
            if not isinstance(row, (list, tuple)):
                continue
            new_row = []
            for b_idx, btn in enumerate(row):
                text = getattr(btn, "text", None)
                if isinstance(text, str) and text.strip():
                    # V26 CALLBACK_DATA GUARD (the Button_data_invalid
                    # root cause): Telegram rejects the WHOLE message when
                    # ANY callback_data exceeds 64 BYTES — a rejected
                    # panel is strictly worse than a panel missing one
                    # broken button. Central pre-send validation: measure
                    # the byte length here (EVERY keyboard passes through
                    # _validated_reply_markup on send/edit); an oversized
                    # callback is DROPPED (the button with it) with a loud
                    # CALLBACK_DATA_OVER_LIMIT line carrying the prefix +
                    # length ONLY (never the full data — it may embed row
                    # data). The five historical raw-slug sites are fixed
                    # to id-based callbacks at the source; this is the
                    # tripwire for FUTURE regressions.
                    try:
                        cb_data = getattr(btn, "callback_data", None)
                    except Exception:  # noqa: BLE001
                        cb_data = None
                    if isinstance(cb_data, str):
                        cb_len = len(cb_data.encode("utf-8"))
                        if cb_len > 64:
                            cb_peek = cb_data[:24]
                            logger.error(
                                "CALLBACK_DATA_OVER_LIMIT bytes=%s "
                                "prefix=%s row=%s col=%s (button DROPPED — "
                                "Telegram's 64-byte callback_data limit "
                                "would reject the ENTIRE message with "
                                "Button_data_invalid)",
                                cb_len, cb_peek, r_idx, b_idx)
                            changed = True
                            continue
                    new_row.append(btn)  # untouched — byte-identical
                    continue
                changed = True
                try:
                    cb_peek = str(getattr(btn, "callback_data", None)
                                  or "")[:40]
                except Exception:  # noqa: BLE001
                    cb_peek = ""
                logger.error(
                    "TELEGRAM_KEYBOARD_TEXT_FIXED reason=non_string_text "
                    "row=%s col=%s text_type=%s callback_data=%s",
                    r_idx, b_idx, type(text).__name__, cb_peek)
                fixed_text = _coerce_button_text(text)
                fields: Dict[str, Any] = {}
                try:
                    fields = {k: v for k, v in btn.to_dict().items()
                              if k != "text"}
                except Exception:  # noqa: BLE001 — non-PTB button object
                    for attr in ("callback_data", "url"):
                        v = getattr(btn, attr, None)
                        if v:
                            fields[attr] = v
                try:
                    new_row.append(InlineKeyboardButton(fixed_text, **fields))
                except Exception:  # noqa: BLE001 — pathological fields
                    new_row.append(InlineKeyboardButton(
                        _KEYBOARD_SAFE_PLACEHOLDER))
            if new_row:
                # V26: a row whose every button was dropped (oversized
                # callback_data) is omitted entirely — Telegram never
                # receives an empty keyboard row.
                new_rows.append(new_row)
        if not changed:
            return markup
        return InlineKeyboardMarkup(new_rows)
    except Exception:  # noqa: BLE001 — NEVER raise from validation
        # BOT-13 hardening: the namespace-rebound (runtime) copy of this
        # function resolves ``logger`` through the shared namespace; a
        # DIRECT module-level import does not. The log call itself is
        # guarded so this except-block can never trade one exception for
        # another (validate_keyboard_markup's contract: never raises).
        try:
            logger.exception(
                "TELEGRAM_KEYBOARD_TEXT_FIXED reason=validation_error")
        except Exception:  # noqa: BLE001 — logging must never raise here
            pass
        return markup


def _validated_reply_markup(kwargs) -> None:
    """In-place defensive validation of kwargs['reply_markup'] (BOT-11 §8).

    Cheap: no-op unless a reply_markup was actually passed."""
    if "reply_markup" in kwargs and kwargs["reply_markup"] is not None:
        kwargs["reply_markup"] = validate_keyboard_markup(
            kwargs["reply_markup"])



async def safe_send_text(bot, chat_id: int, text: str, **kwargs) -> Optional[Message]:
    """send_message wrapper: if Markdown/HTML parsing fails, retries as plain
    text. Prevents the 'Can't parse entities' BadRequest crash.

    Issue #44: automatically applies protect_content based on the
    internal_bot_messages V3 setting. This is the GLOBAL protection layer —
    every bot-generated text message passes through here. File delivery
    uses send_file/send_album which read forward_blocking separately.
    """
    # Issue #44: apply internal message protection globally.
    # Only set protect_content if the caller hasn't explicitly overridden it.
    if "protect_content" not in kwargs:
        try:
            kwargs["protect_content"] = await _get_internal_protect()
        except Exception:  # noqa: BLE001
            pass  # don't crash if DB isn't ready yet
    # BOT-11 §8: a non-string button text can NEVER reach Telegram.
    _validated_reply_markup(kwargs)
    parse_mode = kwargs.pop("parse_mode", None)
    try:
        return await bot.send_message(chat_id=chat_id, text=text,
                                       parse_mode=parse_mode, **kwargs)
    except RetryAfter as e:
        # V25 §10 (bot-34.log flood-control forensics): FloodWait is
        # classified HONESTLY — never turned into success. A SHORT
        # commanded wait (<= SAFE_SEND_FLOOD_RETRY_CAP seconds) retries
        # the send exactly ONCE after the sleep; longer waits return
        # None honestly (blocking the update pipeline for minutes would
        # be worse — the caller's fallback UX proceeds without the
        # message, exactly like the pre-V25 behaviour but no longer
        # ERROR-level noise for an expected rate-limit class).
        try:
            _ra = float(getattr(e, "retry_after", 0) or 0)
        except (TypeError, ValueError):
            _ra = 0.0
        _cap = globals().get("SAFE_SEND_FLOOD_RETRY_CAP", 3)
        if 0 < _ra <= _cap:
            logger.warning(
                "safe_send_text: FloodWait retry_after=%ss (within the "
                "bounded cap — one retried send after the commanded "
                "sleep)", _ra)
            await asyncio.sleep(_ra)
            try:
                return await bot.send_message(
                    chat_id=chat_id, text=text,
                    parse_mode=parse_mode, **kwargs)
            except TelegramError as e2:
                logger.error(
                    "safe_send_text: bounded flood retry failed: %s", e2)
                return None
        logger.warning(
            "safe_send_text: Flood control exceeded. Retry in %s seconds "
            "(honest None — the commanded wait exceeds the bounded "
            "in-handler cap; callers proceed via their fallback UX)", _ra)
        return None
    except BadRequest as e:
        # V25 §6 (bot-34.log "Message to be replied not found"): a
        # vanished reply target is an EXPECTED condition — the auto-
        # delete TTL removes replied-to file messages, and callers (the
        # retrieve flow) fall back to a standalone send. Classified at
        # WARNING with the expected-condition reason — never ERROR-level
        # noise for a normal lifecycle event.
        _low = str(e).lower()
        if ("message to be replied not found" in _low
                or "reply message not found" in _low
                or "message replied not found" in _low):
            logger.warning(
                "safe_send_text: reply target vanished (expected after "
                "TTL auto-delete — the caller falls back to a standalone "
                "send): %s", e)
            return None
        if "parse" in _low or "entity" in _low:
            logger.warning("safe_send_text: markdown parse failed, retrying plain: %s", e)
            try:
                return await bot.send_message(chat_id=chat_id, text=text, **kwargs)
            except TelegramError as e2:
                logger.error("safe_send_text: plain retry also failed: %s", e2)
                return None
        logger.error("safe_send_text: BadRequest: %s", e)
        return None
    except TelegramError as e:
        logger.error("safe_send_text: %s", e)
        return None



async def reply_protected(update: Update, text: str, **kwargs) -> Optional[Message]:
    """Protected reply_text replacement (Issue #44).

    ALL reply_text calls must use this instead. Routes through safe_send_text
    which automatically applies protect_content based on internal_bot_messages.
    """
    if not update or not update.effective_chat:
        return None
    return await safe_send_text(update.get_bot(), update.effective_chat.id, text, **kwargs)



async def safe_edit_text(target, text: str, **kwargs) -> Optional[Message]:
    """edit_message_text / query.edit_message_text wrapper: falls back to plain
    text if Markdown parsing fails. `target` can be a CallbackQuery or a Message.

    BOT-11 §8 — HONEST failure semantics: a Telegram RENDER rejection
    (keyboard/button field errors, or a parse/entity rejection whose
    plain-text retry ALSO fails) is RE-RAISED so the callback wrapper
    reports success=False instead of a silent None (the bot-11.log
    false-success root cause). "message is not modified" stays a benign
    None; other Telegram failures (network flaps) keep the legacy
    log+None so handlers never crash on transient transport errors."""
    # BOT-11 §8: a non-string button text can NEVER reach Telegram.
    _validated_reply_markup(kwargs)
    parse_mode = kwargs.pop("parse_mode", None)
    try:
        if hasattr(target, "edit_message_text"):
            # CallbackQuery
            return await target.edit_message_text(text=text, parse_mode=parse_mode, **kwargs)
        elif hasattr(target, "edit_text"):
            # Message
            return await target.edit_text(text=text, parse_mode=parse_mode, **kwargs)
        return None
    except BadRequest as e:
        low = str(e).lower()
        if "not modified" in low:
            return None  # benign no-op — the UI is already current
        # Deterministic KEYBOARD/RENDER rejections (bot-11 §8: Telegram
        # rejected the keyboard) — RE-RAISE honestly: the callback must
        # report failure. (The §8 validation layer above makes these
        # unreachable in practice; this is the last-resort guarantee.)
        if ("inlinekeyboardbutton" in low
                or ('field "text" must be of type string' in low)
                or ('field "url" must be of type string' in low)
                or ("button url invalid" in low)):
            logger.error(
                "SAFE_EDIT_TEXT_FAILED reason=telegram_rejected "
                "stage=initial error_type=BadRequest detail=%s",
                low[:160])
            raise
        if "parse" in low or "entity" in low:
            logger.warning("safe_edit_text: markdown parse failed, retrying plain: %s", e)
            try:
                if hasattr(target, "edit_message_text"):
                    return await target.edit_message_text(text=text, **kwargs)
                elif hasattr(target, "edit_text"):
                    return await target.edit_text(text=text, **kwargs)
            except BadRequest as e2:
                low2 = str(e2).lower()
                # The PLAIN-TEXT retry was ALSO render-rejected — a
                # deterministic Telegram rejection, not a network flap:
                # report the honest failure (bot-11 §8).
                if ("parse" in low2 or "entity" in low2
                        or "keyboard" in low2 or "button" in low2):
                    logger.error(
                        "SAFE_EDIT_TEXT_FAILED reason=telegram_rejected "
                        "stage=plain_retry error_type=BadRequest detail=%s",
                        low2[:160])
                    raise
                logger.error("safe_edit_text: plain retry also failed: %s", e2)
                return None
            except TelegramError as e2:
                # Non-BadRequest transport failure on the retry — legacy
                # swallow (network flaps must not crash handlers).
                logger.error("safe_edit_text: plain retry also failed: %s", e2)
                return None
        logger.error("safe_edit_text: BadRequest: %s", e)
        return None
    except TelegramError as e:
        logger.error("safe_edit_text: %s", e)
        return None



async def safe_answer_callback(query, text: str = None, show_alert: bool = False, **kwargs) -> None:
    """query.answer() wrapper: swallows 'Query is too old' / 'query id is invalid'
    BadRequest so the bot never crashes on expired callback queries.
    BOT7: also no-ops safely when query is None (message-context callers)."""
    if query is None:
        return
    try:
        if text:
            await query.answer(text, show_alert=show_alert, **kwargs)
        else:
            await query.answer(**kwargs)
    except BadRequest as e:
        logger.debug("safe_answer_callback: swallowed: %s", e)
    except TelegramError as e:
        logger.debug("safe_answer_callback: swallowed: %s", e)



# ============================================================
# CENTRALIZED BOT MESSAGE PROTECTION LAYER (Issue #44)
# ============================================================
# All bot-generated messages (menus, notifications, panels, status messages,
# etc.) MUST pass through these helpers. They automatically apply
# protect_content based on the "internal_bot_messages" V3 setting.
#
# File delivery (send_file, send_album) does NOT use these helpers — it uses
# resolve_delivery_protection() (forward_blocking) instead.
# ============================================================

# (_get_internal_protect is defined earlier, before safe_send_text)


async def send_bot_message(bot, chat_id: int, text: str, **kwargs) -> Optional[Message]:
    """Send a bot-generated text message with internal protection applied.

    Issue #44: ALL bot UI messages (menus, notifications, panels, etc.) must
    use this helper. protect_content is set based on internal_bot_messages.
    """
    protect = await _get_internal_protect()
    kwargs.setdefault("protect_content", protect)
    return await safe_send_text(bot, chat_id, text, **kwargs)



async def send_bot_photo(bot, chat_id: int, photo: str, **kwargs) -> Optional[Message]:
    """Send a bot-generated photo with internal protection applied."""
    protect = await _get_internal_protect()
    kwargs.setdefault("protect_content", protect)
    # BOT-11 §8: a non-string button text can NEVER reach Telegram.
    _validated_reply_markup(kwargs)
    try:
        return await bot.send_photo(chat_id, photo, **kwargs)
    except BadRequest as e:
        if "parse" in str(e).lower() or "entity" in str(e).lower():
            kwargs.pop("parse_mode", None)
            try:
                return await bot.send_photo(chat_id, photo, **kwargs)
            except TelegramError:
                return None
        logger.error("send_bot_photo: BadRequest: %s", e)
        return None
    except TelegramError as e:
        logger.error("send_bot_photo: %s", e)
        return None



async def send_bot_video(bot, chat_id: int, video: str, **kwargs) -> Optional[Message]:
    """Send a bot-generated video with internal protection applied."""
    protect = await _get_internal_protect()
    kwargs.setdefault("protect_content", protect)
    try:
        return await bot.send_video(chat_id, video, **kwargs)
    except TelegramError as e:
        logger.error("send_bot_video: %s", e)
        return None



async def send_bot_document(bot, chat_id: int, document: str, **kwargs) -> Optional[Message]:
    """Send a bot-generated document with internal protection applied."""
    protect = await _get_internal_protect()
    kwargs.setdefault("protect_content", protect)
    try:
        return await bot.send_document(chat_id, document, **kwargs)
    except TelegramError as e:
        logger.error("send_bot_document: %s", e)
        return None



async def send_bot_media(bot, chat_id: int, media_type: str, file_id: str,
                          caption: Optional[str] = None, **kwargs) -> Optional[Message]:
    """Send a bot-generated media message with internal protection applied.

    Routes to the correct send_* method based on media_type.
    """
    protect = await _get_internal_protect()
    kwargs.setdefault("protect_content", protect)
    if caption:
        kwargs.setdefault("caption", caption)
    try:
        if media_type == "photo":
            return await bot.send_photo(chat_id, file_id, **kwargs)
        elif media_type == "video":
            return await bot.send_video(chat_id, file_id, **kwargs)
        elif media_type == "document":
            return await bot.send_document(chat_id, file_id, **kwargs)
        elif media_type == "animation":
            return await bot.send_animation(chat_id, file_id, **kwargs)
        elif media_type == "audio":
            return await bot.send_audio(chat_id, file_id, **kwargs)
        elif media_type == "voice":
            return await bot.send_voice(chat_id, file_id, **kwargs)
        else:
            return await bot.send_document(chat_id, file_id, **kwargs)
    except TelegramError as e:
        logger.error("send_bot_media: %s", e)
        return None



async def edit_bot_message(target, text: str, **kwargs) -> Optional[Message]:
    """Edit a bot-generated message with internal protection applied.

    Issue #44: ALL bot UI message edits (panels, menus, etc.) must use this
    helper. Falls back to plain text if Markdown fails.
    """
    # Note: edit_message_text doesn't support protect_content (it's already sent),
    # but we use this helper for consistency and to ensure safe_edit_text is used.
    return await safe_edit_text(target, text, **kwargs)



def extract_forward_origin(msg: Message) -> Tuple[Optional[int], Optional[int]]:
    """Extract (channel_id, message_id) from a forwarded message using a
    5-priority fallback chain.

    Returns (None, None) if forward metadata is completely unavailable
    (e.g. protected content with forward info stripped).

    Priority order:
    1. forward_from_chat.id
    2. forward_from_message_id
    3. forward_origin.chat.id (PTB v20+)
    4. forward_origin.message_id (PTB v20+)
    5. (media fingerprint lookup is handled by caller via indexed_files search)
    """
    # Priority 1+2: classic forward_from_chat + forward_from_message_id
    ffc = getattr(msg, "forward_from_chat", None)
    ffm_id = getattr(msg, "forward_from_message_id", None)
    if ffc and ffm_id:
        return ffc.id, ffm_id

    # Priority 3+4: forward_origin (PTB v20+ MessageOriginChannel)
    fo = getattr(msg, "forward_origin", None)
    if fo:
        chat_obj = getattr(fo, "chat", None) or getattr(fo, "sender_chat", None)
        ch_id = getattr(chat_obj, "id", None) if chat_obj else None
        msg_id = getattr(fo, "message_id", None)
        if ch_id and msg_id:
            return ch_id, msg_id
        # Partial: one of them might be available
        if ch_id or msg_id:
            return ch_id, msg_id

    # Priority 5: No metadata available at all
    return None, None



# ============================================================
# START MESSAGE BUTTON PARSING / BUILDING
# ============================================================
def parse_start_buttons(text: str) -> List[List[Dict[str, str]]]:
    """Parse admin-supplied button text into rows of button dicts.

    Format (one button per line; a line containing only '---' starts a new row):
        Button Text | url:https://example.com
        Main Channel | channel:@mychannel
        Get Spider | deeplink:spider_nwh
        ---
        Premium | url:https://t.me/premium
    """
    rows: List[List[Dict[str, str]]] = []
    current: List[Dict[str, str]] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line == "---":
            if current:
                rows.append(current)
                current = []
            continue
        label = line
        btype = "url"
        value = build_start_link("")
        if "|" in line:
            label, rest = line.split("|", 1)
            label = label.strip()
            rest = rest.strip()
            if ":" in rest:
                btype, value = rest.split(":", 1)
                btype = btype.strip().lower()
                value = value.strip()
                if btype not in ("url", "channel", "deeplink"):
                    btype = "url"
                    value = build_start_link("")
        current.append({"text": label, "type": btype, "value": value})
    if current:
        rows.append(current)
    return rows



# ============================================================
# BOTV13 PHASE 5: TELEGRAM ENTITY PRESERVATION
# ============================================================
# Centralized helpers for serializing/deserializing Telegram MessageEntity
# objects so text links, bold, italic, code, etc. survive EDIT → SAVE →
# PREVIEW → REOPEN → EDIT cycles. Stored as JSON in the database.
# ============================================================

def serialize_entities(entities: Optional[List]) -> Optional[str]:
    """Serialize a list of Telegram MessageEntity objects to a JSON string.

    Handles all entity types: text_link, url, bold, italic, underline,
    strikethrough, code, pre, spoiler, custom_emoji, etc.
    Returns None if entities is empty or None (for backward compat with
    columns that default to NULL).
    """
    if not entities:
        return None
    import json as _json
    serialized: List[Dict[str, Any]] = []
    for ent in entities:
        item: Dict[str, Any] = {"type": ent.type, "offset": ent.offset, "length": ent.length}
        # Optional fields depending on entity type.
        if ent.type == "text_link" and hasattr(ent, "url") and ent.url:
            item["url"] = ent.url
        if ent.type == "text_mention" and hasattr(ent, "user") and ent.user:
            item["user_id"] = ent.user.id
        if ent.type == "pre" and hasattr(ent, "language") and ent.language:
            item["language"] = ent.language
        if ent.type == "custom_emoji" and hasattr(ent, "custom_emoji_id") and ent.custom_emoji_id:
            item["custom_emoji_id"] = ent.custom_emoji_id
        serialized.append(item)
    return _json.dumps(serialized) if serialized else None



def deserialize_entities(entities_json: Optional[str]) -> Optional[List]:
    """Deserialize a JSON string back to a list of MessageEntity objects.

    Returns None if the JSON is empty/invalid (backward compat with rows
    that have no entities stored). Never raises.
    """
    if not entities_json:
        return None
    import json as _json
    try:
        data = _json.loads(entities_json)
    except (ValueError, TypeError):
        return None
    if not data or not isinstance(data, list):
        return None
    from telegram import MessageEntity
    entities: List[MessageEntity] = []
    for item in data:
        try:
            ent_type = item.get("type", "")
            offset = int(item.get("offset", 0))
            length = int(item.get("length", 0))
            url = item.get("url")
            user = None
            if item.get("user_id"):
                # Create a minimal User-like object for text_mention.
                from telegram import User
                user = User(id=int(item["user_id"]), first_name="", is_bot=False)
            language = item.get("language")
            custom_emoji_id = item.get("custom_emoji_id")
            ent = MessageEntity(
                type=ent_type, offset=offset, length=length,
                url=url, user=user, language=language,
                custom_emoji_id=custom_emoji_id,
            )
            entities.append(ent)
        except (TypeError, ValueError, KeyError):
            continue
    return entities if entities else None



def extract_message_content(message) -> Dict[str, Any]:
    """Extract text/caption + entities + media info from a Telegram message.

    Returns a dict with keys:
      - text: the message text or caption (whichever is present)
      - entities: serialized entities (JSON string) or None
      - media_type: photo/video/document/animation/audio/voice/None
      - file_id: media file_id or None
      - buttons_json: serialized inline keyboard or None
    """
    text = ""
    raw_entities = None
    if message.text:
        text = message.text
        raw_entities = message.entities
    elif message.caption:
        text = message.caption
        raw_entities = message.caption_entities
    entities_json = serialize_entities(raw_entities)
    # Media extraction.
    media_type = None
    file_id = None
    if message.photo:
        media_type = "photo"
        file_id = message.photo[-1].file_id  # largest size
    elif message.video:
        media_type = "video"
        file_id = message.video.file_id
    elif message.document:
        media_type = "document"
        file_id = message.document.file_id
    elif message.animation:
        media_type = "animation"
        file_id = message.animation.file_id
    elif message.audio:
        media_type = "audio"
        file_id = message.audio.file_id
    elif message.voice:
        media_type = "voice"
        file_id = message.voice.file_id
    # Inline keyboard.
    buttons_json = None
    if message.reply_markup and hasattr(message.reply_markup, "inline_keyboard"):
        import json as _json
        rows_data = []
        for row in message.reply_markup.inline_keyboard:
            row_data = []
            for btn in row:
                item: Dict[str, Any] = {"text": btn.text}
                if btn.url:
                    item["url"] = btn.url
                elif btn.callback_data:
                    item["callback_data"] = btn.callback_data
                row_data.append(item)
            if row_data:
                rows_data.append(row_data)
        if rows_data:
            buttons_json = _json.dumps(rows_data)
    return {
        "text": text,
        "entities": entities_json,
        "media_type": media_type,
        "file_id": file_id,
        "buttons_json": buttons_json,
    }



def build_message_kwargs(stored: Dict[str, Any]) -> Dict[str, Any]:
    """Build kwargs for bot.send_message / send_photo from stored content.

    Handles text + entities + media + buttons. Used by both real delivery
    and preview so they match exactly.

    BOTV13 Phase B (wired): now actually deserializes entities and builds the
    inline keyboard. Handles BOTH button JSON formats:
      - admin text format (parse_start_buttons output): [{"type","text","value"}, ...]
      - raw Telegram reply_markup format (extract_message_content output):
        [{"text","url"/"callback_data"}, ...]
    """
    kwargs: Dict[str, Any] = {}
    entities = deserialize_entities(stored.get("entities"))
    if entities:
        kwargs["entities"] = entities
    buttons_json = stored.get("buttons_json")
    if buttons_json:
        kb = build_start_buttons(buttons_json)
        if not kb:
            # Fallback: try the raw reply_markup format produced by
            # extract_message_content ([{text, url/callback_data}, ...]).
            kb = _build_inline_keyboard_from_raw(buttons_json)
        if kb:
            kwargs["reply_markup"] = kb
    return kwargs



def _build_inline_keyboard_from_raw(buttons_json: str) -> Optional[InlineKeyboardMarkup]:
    """Build an InlineKeyboardMarkup from the raw reply_markup JSON format
    produced by extract_message_content (list of rows of {text, url?, callback_data?}).

    Returns None on any error or empty input.
    """
    if not buttons_json:
        return None
    try:
        import json as _json
        data = _json.loads(buttons_json)
    except (ValueError, TypeError):
        return None
    if not isinstance(data, list) or not data:
        return None
    rows: List[List[InlineKeyboardButton]] = []
    for row in data:
        if not isinstance(row, list):
            continue
        btns: List[InlineKeyboardButton] = []
        for b in row:
            if not isinstance(b, dict):
                continue
            label = b.get("text", "")
            if not label:
                continue
            url = b.get("url")
            cb = b.get("callback_data")
            try:
                if url:
                    btns.append(InlineKeyboardButton(label, url=url))
                elif cb:
                    btns.append(InlineKeyboardButton(label, callback_data=cb))
            except (TypeError, ValueError):
                continue
        if btns:
            rows.append(btns)
    return InlineKeyboardMarkup(rows) if rows else None



# ============================================================
# RATE LIMITER  (in-memory, per-user sliding window)
# ============================================================
class RateLimiter:
    """Per-user sliding-window rate limiter with automatic pruning.

    Issue 4 Critical Fix: inactive users are pruned so the `_hits` dict never
    grows unbounded over long runtimes. Pruning runs:
      - lazily on every check (expired entries removed)
      - proactively when the dict exceeds MAX_USERS threshold (whole-user prune)
    """

    # Maximum tracked users before a full prune sweep runs.
    MAX_USERS: int = 5000

    def __init__(self, window: int = RATE_LIMIT_WINDOW, max_req: int = RATE_LIMIT_MAX) -> None:
        self.window = window
        self.max_req = max_req
        self._hits: Dict[int, List[float]] = {}

    def check(self, user_id: int) -> bool:
        now = time.time()
        hits = [t for t in self._hits.get(user_id, []) if now - t < self.window]
        if len(hits) >= self.max_req:
            self._hits[user_id] = hits
            return False
        hits.append(now)
        self._hits[user_id] = hits
        # Issue 4: periodic prune — if the user map has grown large, sweep it.
        if len(self._hits) > self.MAX_USERS:
            self._prune_inactive(now)
        return True

    def clear(self, user_id: int) -> None:
        self._hits.pop(user_id, None)

    def _prune_inactive(self, now: float) -> None:
        """Remove ALL users whose hit lists are fully expired.

        Called when the tracked-user count exceeds MAX_USERS. Keeps memory
        stable over long runtimes.
        """
        expired_users = [
            uid for uid, hits in self._hits.items()
            if not hits or all(now - t >= self.window for t in hits)
        ]
        for uid in expired_users:
            self._hits.pop(uid, None)
        if expired_users:
            logger.debug("RateLimiter pruned %d inactive users (now tracking %d)",
                         len(expired_users), len(self._hits))

    def prune_now(self) -> int:
        """Force a prune sweep. Returns the number of users removed."""
        now = time.time()
        before = len(self._hits)
        self._prune_inactive(now)
        return before - len(self._hits)
