"""Media operations — media extraction and channel fetch transport.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



# ============================================================
# MEDIA EXTRACTION  (channel post -> media dict)
# ============================================================
def is_real_message(obj: Any) -> bool:
    """Return True only if obj is a real telegram Message (not a MessageId).

    Telegram APIs (copy_message / forward_message) may return a MessageId object
    instead of a full Message when copying into channels or under certain
    conditions. Passing such an object into extract_media() crashes with
    AttributeError: 'MessageId' object has no attribute 'video'.
    """
    return isinstance(obj, Message)



def safe_extract_media(obj: Any) -> Optional[Dict[str, Any]]:
    """extract_media() guarded against non-Message objects.

    Returns None if `obj` is a MessageId (or any non-Message), so callers can
    treat it as 'no media to index' instead of crashing.
    """
    if not is_real_message(obj):
        return None
    return extract_media(obj)



async def fetch_channel_media(bot, admin_id: int, channel_id: int,
                              message_id: int) -> Tuple[Optional[Dict[str, Any]], Optional[int]]:
    """Fetch a message from a storage channel and extract its media.

    Issue 5: uses safe_extract_media() everywhere so a non-Message result
    (MessageId from content-protected channels) is treated as 'no media'
    instead of crashing. Tries copy_message first (fast); if it returns a
    MessageId, falls back to forward_message which always returns a full
    Message.

    Returns (media_info_or_None, forwarded_msg_id_or_None_for_cleanup).
    The caller MUST delete the forwarded message if forwarded_msg_id is set.
    """
    # Try copy_message first (preserves caption, fast).
    try:
        result = await bot.copy_message(admin_id, channel_id, message_id)
        if is_real_message(result):
            info = safe_extract_media(result)
            return info, result.message_id
        # MessageId returned (content-protected channel) - fall back to forward.
        logger.debug("copy_message returned MessageId for msg %s, falling back to forward_message", message_id)
        # Clean up the MessageId copy if possible.
        mid = getattr(result, "message_id", None)
        if mid:
            try:
                await bot.delete_message(admin_id, mid)
            except TelegramError:
                pass
    except RetryAfter as e:
        # H1 Fix: sleep and retry instead of skipping the message.
        logger.debug("fetch: RetryAfter %ss for msg %s, retrying", e.retry_after, message_id)
        await asyncio.sleep(e.retry_after)
        return await fetch_channel_media(bot, admin_id, channel_id, message_id)
    except (BadRequest, Forbidden, TelegramError) as e:
        logger.debug("copy_message failed for msg %s: %s, trying forward_message", message_id, e)

    # Fallback: forward_message always returns a full Message.
    try:
        fwd = await bot.forward_message(chat_id=admin_id, from_chat_id=channel_id,
                                         message_id=message_id, disable_notification=True)
        if is_real_message(fwd):
            info = safe_extract_media(fwd)
            return info, fwd.message_id
        return None, None
    except RetryAfter as e:
        # H1 Fix: sleep and retry.
        logger.debug("fetch forward: RetryAfter %ss for msg %s, retrying", e.retry_after, message_id)
        await asyncio.sleep(e.retry_after)
        return await fetch_channel_media(bot, admin_id, channel_id, message_id)
    except (BadRequest, Forbidden, TelegramError) as e:
        logger.debug("forward_message also failed for msg %s: %s", message_id, e)
        return None, None



def _log_message_media(message: Message) -> None:
    """Debug logging: log every media attribute of an inspected message."""
    mid = getattr(message, "message_id", "?")
    logger.debug(
        "MSG %s | doc=%s video=%s audio=%s photo=%s anim=%s voice=%s video_note=%s sticker=%s",
        mid,
        bool(getattr(message, "document", None)),
        bool(getattr(message, "video", None)),
        bool(getattr(message, "audio", None)),
        bool(getattr(message, "photo", None)),
        bool(getattr(message, "animation", None)),
        bool(getattr(message, "voice", None)),
        bool(getattr(message, "video_note", None)),
        bool(getattr(message, "sticker", None)),
    )



def _extract_media_metadata_fields(media_obj: Any) -> Dict[str, Any]:
    """WEBSITE PHASE 2 (v30 part A): additive richer metadata for a media
    object (mime_type / width / height / thumbnail references).

    Pure getattr-based extraction — PTB attribute differences never raise,
    and every value the source message does not provide stays None
    (metadata is NEVER fabricated: photos carry no mime_type, documents
    carry no dimensions, voice carries no thumbnail…).

    The thumbnail follows the SAME identity discipline as the media itself:
    thumb_file_unique_id is the thumbnail's cross-bot identity/dedup key;
    thumb_file_id is its bot-scoped Bot API transport reference — and the
    two are never swapped (file_unique_id is never used as a file_id).
    """
    out: Dict[str, Any] = {
        "mime_type": None,
        "width": None,
        "height": None,
        "thumb_file_id": None,
        "thumb_file_unique_id": None,
    }
    if media_obj is None:
        return out
    out["mime_type"] = getattr(media_obj, "mime_type", None)
    out["width"] = getattr(media_obj, "width", None)
    out["height"] = getattr(media_obj, "height", None)
    thumb = getattr(media_obj, "thumbnail", None)
    if thumb is not None:
        out["thumb_file_id"] = getattr(thumb, "file_id", None)
        out["thumb_file_unique_id"] = getattr(thumb, "file_unique_id", None)
    return out



def extract_media(message: Message) -> Optional[Dict[str, Any]]:
    """Pull the relevant file fields out of a channel/group message.

    Supports: video, document, audio, photo, voice, animation, video_note, sticker.
    Precondition: `message` must be a real telegram.Message.
    """
    if not is_real_message(message):
        return None
    _log_message_media(message)
    info: Optional[Dict[str, Any]] = None
    if message.video:
        info = {
            "media_type": "video",
            "file_id": message.video.file_id,
            "file_unique_id": message.video.file_unique_id,
            "file_name": message.video.file_name or f"video_{message.message_id}.mp4",
            "file_size": message.video.file_size,
            "duration": message.video.duration,
        }
    elif message.document:
        info = {
            "media_type": "document",
            "file_id": message.document.file_id,
            "file_unique_id": message.document.file_unique_id,
            "file_name": message.document.file_name or f"file_{message.message_id}",
            "file_size": message.document.file_size,
            "duration": None,
        }
    elif message.audio:
        info = {
            "media_type": "audio",
            "file_id": message.audio.file_id,
            "file_unique_id": message.audio.file_unique_id,
            "file_name": message.audio.file_name or f"audio_{message.message_id}.mp3",
            "file_size": message.audio.file_size,
            "duration": message.audio.duration,
        }
    elif message.photo:
        photo = message.photo[-1]  # largest variant
        info = {
            "media_type": "photo",
            "file_id": photo.file_id,
            "file_unique_id": photo.file_unique_id,
            "file_name": f"photo_{message.message_id}.jpg",
            "file_size": photo.file_size,
            "duration": None,
        }
    elif message.voice:
        info = {
            "media_type": "voice",
            "file_id": message.voice.file_id,
            "file_unique_id": message.voice.file_unique_id,
            "file_name": f"voice_{message.message_id}.ogg",
            "file_size": message.voice.file_size,
            "duration": message.voice.duration,
        }
    elif message.animation:
        info = {
            "media_type": "animation",
            "file_id": message.animation.file_id,
            "file_unique_id": message.animation.file_unique_id,
            "file_name": message.animation.file_name or f"animation_{message.message_id}.mp4",
            "file_size": message.animation.file_size,
            "duration": message.animation.duration,
        }
    elif getattr(message, "video_note", None):
        info = {
            "media_type": "video_note",
            "file_id": message.video_note.file_id,
            "file_unique_id": message.video_note.file_unique_id,
            "file_name": f"video_note_{message.message_id}.mp4",
            "file_size": message.video_note.file_size,
            "duration": message.video_note.duration,
        }
    elif getattr(message, "sticker", None):
        info = {
            "media_type": "sticker",
            "file_id": message.sticker.file_id,
            "file_unique_id": message.sticker.file_unique_id,
            "file_name": f"sticker_{message.message_id}.webp",
            "file_size": message.sticker.file_size,
            "duration": None,
        }
    if info:
        info["caption"] = message.caption or None
        # WEBSITE PHASE 2 (v30 part A): additive richer metadata capture.
        # Keys are additive — every pre-v30 consumer (delivery, dedup,
        # panels, tests) keeps its exact behavior; the persistence layer
        # stores the new columns only when present (NULL otherwise).
        media_obj = (
            message.video or message.document or message.audio
            or message.animation
            or getattr(message, "video_note", None)
            or getattr(message, "sticker", None)
            or message.voice
            or (message.photo[-1] if message.photo else None)
        )
        info.update(_extract_media_metadata_fields(media_obj))
        if message.photo and len(message.photo) > 1:
            # A photo message's smallest variant is its own preview
            # thumbnail (a REAL Telegram-provided smaller size — never a
            # fabricated or downloaded artifact).
            smallest = message.photo[0]
            info["thumb_file_id"] = getattr(smallest, "file_id", None)
            info["thumb_file_unique_id"] = getattr(
                smallest, "file_unique_id", None)
    else:
        logger.warning("MSG %s: no media detected (all attributes False)", message.message_id)
    return info
