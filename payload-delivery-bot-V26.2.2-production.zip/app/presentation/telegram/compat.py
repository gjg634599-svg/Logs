"""Compatibility facades — service facade zone (bot.py L330-1217).

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations























def _svc_make_payload_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.payload_service()







def _svc_make_referral_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.referral_service()












def _svc_make_watch_ads_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.watch_ads_service()





def _svc_make_access_points_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.access_points_service()
























def _svc_make_force_join_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.force_join_service()


def _svc_make_delivery_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.delivery_service()



async def create_recovery_card(*args, **kwargs):
    """Compatibility facade → app/core/delivery/service (canonical)."""
    return await _svc_make_delivery_service().create_recovery_card(*args, **kwargs)



async def _recovery_admin_chat_id(*args, **kwargs):
    """Compatibility facade → app/core/delivery/service (canonical)."""
    return await _svc_make_delivery_service()._recovery_admin_chat_id(*args, **kwargs)



async def get_retrieve_text(*args, **kwargs):
    """Compatibility facade → app/core/delivery/service (canonical)."""
    return await _svc_make_delivery_service().get_retrieve_text(*args, **kwargs)



async def get_retrieve_button(*args, **kwargs):
    """Compatibility facade → app/core/delivery/service (canonical)."""
    return await _svc_make_delivery_service().get_retrieve_button(*args, **kwargs)



def _format_retrieve_text(*args, **kwargs):
    """Compatibility facade → app/core/delivery/service (canonical)."""
    return _svc_make_delivery_service()._format_retrieve_text(*args, **kwargs)





async def _dispatch_delivery_arg(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                 user: User, arg: str) -> None:
    """WATCH_AD refresh dispatch: re-run the delivery path for any link arg.

    Mirrors the verify: routing (m<link> / c<code> / r-range / named payload)
    but is deliberately a separate function so the Force-Join verify event
    sourcing is untouched.
    """
    if not arg:
        await safe_send_text(context.bot, update.effective_chat.id,
                             "\u274C Invalid or expired link.")
        return
    if is_msg_link(arg):
        message_id = parse_msg_link(arg)
        await deliver_message_file(update, context, message_id, user)
    elif is_collection_link(arg):
        collection_code = parse_collection_link(arg)
        await deliver_collection(update, context, collection_code, user)
    elif is_range_link(arg):
        start_id, end_id = parse_range_link(arg)
        code = await _migrate_legacy_range_to_collection(start_id, end_id,
                                                         user_id=user.id)
        if code:
            await deliver_collection(update, context, code, user)
        else:
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "\u274C Invalid or expired link.")
    else:
        full_row = await db.get_payload(arg)
        if full_row:
            await attempt_delivery(update, context, arg, user)
        else:
            routing_id, _m = await _resolve_routing_id(arg)
            if routing_id:
                if is_collection_link(routing_id):
                    collection_code = parse_collection_link(routing_id)
                    await deliver_collection(update, context, collection_code, user)
                else:
                    await attempt_delivery(update, context, routing_id, user)
            else:
                await safe_send_text(context.bot, update.effective_chat.id,
                                     "\u274C Invalid or expired link.")


def _svc_make_web_auth_service():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.web_auth_service()



def _svc_make_keyboards():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.keyboards()











































def _svc_make_network_ui():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.network_ui()


async def create_unique_payload(*args, **kwargs):
    """Compatibility facade → app/core/payload/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_payload_service().create_unique_payload(*args, **kwargs)


def build_start_link(*args, **kwargs):
    """Compatibility facade → app/core/payload/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_payload_service().build_start_link(*args, **kwargs)


def build_link(*args, **kwargs):
    """Compatibility facade → app/core/payload/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_payload_service().build_link(*args, **kwargs)


def build_collection_link(*args, **kwargs):
    """Compatibility facade → app/core/payload/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_payload_service().build_collection_link(*args, **kwargs)


async def check_referral_gate(*args, **kwargs):
    """Compatibility facade → app/core/referral/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_referral_service().check_referral_gate(*args, **kwargs)


async def qualify_referral(*args, **kwargs):
    """Compatibility facade → app/core/referral/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_referral_service().qualify_referral(*args, **kwargs)


async def _get_referral_dedup_lock(*args, **kwargs):
    """Compatibility facade → app/core/referral/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_referral_service()._get_referral_dedup_lock(*args, **kwargs)


def build_referral_link(*args, **kwargs):
    """Compatibility facade → app/core/referral/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_referral_service().build_referral_link(*args, **kwargs)


def validate_watch_ads_mini_app_url(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service().validate_watch_ads_mini_app_url(*args, **kwargs)


def validate_watch_ads_sdk_code(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service().validate_watch_ads_sdk_code(*args, **kwargs)


def _parse_monetag_sdk_tag(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service()._parse_monetag_sdk_tag(*args, **kwargs)


async def get_watch_ads_global_config(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_watch_ads_service().get_watch_ads_global_config(*args, **kwargs)


def validate_watch_ads_unlock_template(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service().validate_watch_ads_unlock_template(*args, **kwargs)


def render_watch_ads_unlock_message(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service().render_watch_ads_unlock_message(*args, **kwargs)


async def get_watch_ads_unlock_template(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_watch_ads_service().get_watch_ads_unlock_template(*args, **kwargs)


def _watch_ads_template_unknown_placeholders(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_watch_ads_service()._watch_ads_template_unknown_placeholders(*args, **kwargs)


async def _watch_ads_unlock_minutes(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_watch_ads_service()._watch_ads_unlock_minutes(*args, **kwargs)


async def _watch_ads_gate_active(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_watch_ads_service()._watch_ads_gate_active(*args, **kwargs)


async def build_watch_ad_session_url(*args, **kwargs):
    """Compatibility facade → app/core/watch_ads/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_watch_ads_service().build_watch_ad_session_url(*args, **kwargs)


async def _point_access_active(*args, **kwargs):
    """Compatibility facade → app/core/access/engine.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_access_points_service()._point_access_active(*args, **kwargs)


async def _point_cost(*args, **kwargs):
    """Compatibility facade → app/core/access/engine.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_access_points_service()._point_cost(*args, **kwargs)


async def _stamp_point_context(*args, **kwargs):
    """Compatibility facade → app/core/access/engine.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_access_points_service()._stamp_point_context(*args, **kwargs)


async def _point_unlock_allows(*args, **kwargs):
    """Compatibility facade → app/core/access/engine.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_access_points_service()._point_unlock_allows(*args, **kwargs)


async def check_membership(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().check_membership(*args, **kwargs)


async def is_member(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().is_member(*args, **kwargs)


async def get_pending_channel_for_user(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().get_pending_channel_for_user(*args, **kwargs)


async def unjoined_channels(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().unjoined_channels(*args, **kwargs)


def _force_channel_label(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_force_join_service()._force_channel_label(*args, **kwargs)


async def classify_channel_access(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().classify_channel_access(*args, **kwargs)


async def _check_force_channel_valid(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._check_force_channel_valid(*args, **kwargs)


def _channel_validity_label(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_force_join_service()._channel_validity_label(*args, **kwargs)


async def _get_fj_progress(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._get_fj_progress(*args, **kwargs)


async def _get_or_init_fj_progress(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._get_or_init_fj_progress(*args, **kwargs)


def _parse_json_list(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_force_join_service()._parse_json_list(*args, **kwargs)


def _parse_json_list_of_lists(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_force_join_service()._parse_json_list_of_lists(*args, **kwargs)


async def _reconcile_fj_channel_order(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._reconcile_fj_channel_order(*args, **kwargs)


async def _persist_fj_progress(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._persist_fj_progress(*args, **kwargs)


async def _get_active_fj_batch_ids(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._get_active_fj_batch_ids(*args, **kwargs)


async def _get_active_fj_batch_channels(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._get_active_fj_batch_channels(*args, **kwargs)


async def _get_fj_batch(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._get_fj_batch(*args, **kwargs)


async def _mark_fj_presented(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._mark_fj_presented(*args, **kwargs)


async def unjoined_channels_for_user(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().unjoined_channels_for_user(*args, **kwargs)


async def _unjoined_for_access(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service()._unjoined_for_access(*args, **kwargs)


async def get_fj_mode(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().get_fj_mode(*args, **kwargs)


async def get_fj_batch_size(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().get_fj_batch_size(*args, **kwargs)


async def force_join_active(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_force_join_service().force_join_active(*args, **kwargs)


async def fj_gate_view(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates).

    V26.2 (bot-41 §16-§24): the per-gate progressive-batching view — the
    pinned batch this gate presented (never a future batch)."""
    return await _svc_make_force_join_service().fj_gate_view(*args, **kwargs)


async def fj_gate_unjoined(*args, **kwargs):
    """Compatibility facade → app/core/force_join/service.py (canonical
    implementation; single engine, no duplicates).

    V26.2 (bot-41 §16-§24): the access-engine adapter for the gate view."""
    return await _svc_make_force_join_service().fj_gate_unjoined(*args, **kwargs)


def validate_telegram_init_data(*args, **kwargs):
    """Compatibility facade → app/web/auth.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_web_auth_service().validate_telegram_init_data(*args, **kwargs)


def _validate_webapp_init_data(*args, **kwargs):
    """Compatibility facade → app/web/auth.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_web_auth_service()._validate_webapp_init_data(*args, **kwargs)


def build_start_buttons(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/keyboards.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_keyboards().build_start_buttons(*args, **kwargs)


async def build_force_join_keyboard(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/keyboards.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_keyboards().build_force_join_keyboard(*args, **kwargs)


async def network_enabled(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().network_enabled(*args, **kwargs)


def _net_context_id(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui()._net_context_id(*args, **kwargs)


async def _net_validate_token_via_telegram(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_validate_token_via_telegram(*args, **kwargs)


async def _net_probe_storage_access(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_probe_storage_access(*args, **kwargs)


async def _network_media_guard(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._network_media_guard(*args, **kwargs)


async def _network_record_start(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._network_record_start(*args, **kwargs)


async def _net_get_bot_client(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_get_bot_client(*args, **kwargs)


def is_global_payload_link(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui().is_global_payload_link(*args, **kwargs)


def _net_serving_bot_username(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui()._net_serving_bot_username(*args, **kwargs)


async def handle_global_payload_link(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().handle_global_payload_link(*args, **kwargs)


async def generate_global_payload_link(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().generate_global_payload_link(*args, **kwargs)


async def handle_pt_unlock(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().handle_pt_unlock(*args, **kwargs)


async def network_command(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().network_command(*args, **kwargs)


async def _render_my_network(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_my_network(*args, **kwargs)


def _net_reg_get(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui()._net_reg_get(*args, **kwargs)


def _net_reg_clear(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui()._net_reg_clear(*args, **kwargs)


async def _render_net_reg_start(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_reg_start(*args, **kwargs)


async def _render_net_reg_token(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_reg_token(*args, **kwargs)


async def _net_reg_consent_keyboard(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_reg_consent_keyboard(*args, **kwargs)


async def handle_network_registration_text(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().handle_network_registration_text(*args, **kwargs)


async def _net_complete_registration(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_complete_registration(*args, **kwargs)


async def render_network_control(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().render_network_control(*args, **kwargs)


async def _render_net_bots(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_bots(*args, **kwargs)


async def _render_net_health(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_health(*args, **kwargs)


async def _net_run_health_checks(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_run_health_checks(*args, **kwargs)


async def _render_net_points_settings(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_points_settings(*args, **kwargs)


async def _render_net_links(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_links(*args, **kwargs)


async def _render_net_settings(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_net_settings(*args, **kwargs)


async def _render_broadcast_center(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_broadcast_center(*args, **kwargs)


async def _render_bcast_new(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_bcast_new(*args, **kwargs)


async def handle_network_broadcast_text(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui().handle_network_broadcast_text(*args, **kwargs)


async def _render_bcast_preview(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_bcast_preview(*args, **kwargs)


async def _net_broadcast_start(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_broadcast_start(*args, **kwargs)


async def _render_bcast_jobs(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._render_bcast_jobs(*args, **kwargs)


def _bcast_source_ids(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return _svc_make_network_ui()._bcast_source_ids(*args, **kwargs)


async def _net_broadcast_send_one(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._net_broadcast_send_one(*args, **kwargs)


async def _handle_net_points_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_net_points_callback(*args, **kwargs)


async def _handle_net_reg_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_net_reg_callback(*args, **kwargs)


async def _handle_net_bot_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_net_bot_callback(*args, **kwargs)


async def _handle_net_admin_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_net_admin_callback(*args, **kwargs)


async def _handle_gpl_admin_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_gpl_admin_callback(*args, **kwargs)


async def _handle_nbc_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/network_ui.py (canonical
    implementation; single engine, no duplicates)."""
    return await _svc_make_network_ui()._handle_nbc_callback(*args, **kwargs)


# ----------------------------------------------------------------------
# FILE DELIVERY v34 (spec §20-§66): Delivery Group wizard + Create
# Network Bot wizard (delivery_ui) and the Control Bot panel (control_ui).
# ----------------------------------------------------------------------

def _svc_make_delivery_ui():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.delivery_ui()


async def render_delivery_center(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py."""
    return await _svc_make_delivery_ui().render_delivery_center(*args, **kwargs)


async def handle_delivery_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py."""
    return await _svc_make_delivery_ui().handle_delivery_callback(*args, **kwargs)


async def handle_ncreate_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py."""
    return await _svc_make_delivery_ui().handle_ncreate_callback(*args, **kwargs)


async def _handle_net_managed_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py
    (MANAGED BOTS v37 Task 8: nmg: managed create navigation)."""
    return await _svc_make_delivery_ui()._handle_net_managed_callback(*args, **kwargs)


async def _handle_net_legacy_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py
    (MANAGED BOTS v37 Task 8: ADMIN-ONLY nleg: legacy manual import)."""
    return await _svc_make_delivery_ui()._handle_net_legacy_callback(*args, **kwargs)


async def handle_nleg_text(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py
    (MANAGED BOTS v37 Task 8: LEGACY import token capture — the only
    token text path left on the create surface)."""
    return await _svc_make_delivery_ui().handle_nleg_text(*args, **kwargs)


async def _net_handle_delivery_group_detection(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/delivery_ui.py."""
    return await _svc_make_delivery_ui()._net_handle_delivery_group_detection(*args, **kwargs)


def _svc_make_control_ui():
    """Facade → app/services/container.py (§4 composition boundary)."""
    return _SVCS.control_ui()


async def render_control_panel(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/control_ui.py."""
    return await _svc_make_control_ui().render_control_panel(*args, **kwargs)


async def handle_control_callback(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/control_ui.py."""
    return await _svc_make_control_ui().handle_control_callback(*args, **kwargs)


async def handle_control_text(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/control_ui.py."""
    return await _svc_make_control_ui().handle_control_text(*args, **kwargs)


async def handle_control_owner_text(*args, **kwargs):
    """Compatibility facade → app/presentation/telegram/control_ui.py."""
    return await _svc_make_control_ui().handle_control_owner_text(*args, **kwargs)
