"""FILE DELIVERY v34 — user-facing Delivery UI (spec §41-§43, §60, §72-§73).

Owns:
  * the Delivery Channel setup wizard (``dg:`` callbacks): instructions for
    Use Existing Channel / Create New Channel, real verification, status;
  * the Create Network Bot entry (``ncreate:``) — v37 (Task 8): the
    PRIMARY path renders the MANAGED-BOT flow (Telegram creates the
    bot under the main bot's management via a reply-keyboard request —
    NO BotFather instructions, NO token pasting). The manual token
    import survives ONLY as the explicitly relabeled, ADMIN-ONLY
    LEGACY ``nleg:`` namespace (migration), with its own state key
    (``nleg_state``) so it can never consume managed-bot updates or
    hijack other flows;
  * the ``nmg:`` managed-create navigation (cancel/back → My Network,
    reply keyboard restored);
  * the network-worker group/channel-message DETECTION hook
    (``_net_handle_delivery_group_detection``) that captures the private
    Delivery Channel when the owner posts there and runs the
    full verification chain (spec §41/§73). A.2 (bot-25): the Delivery
    CHANNEL is the required transport — a private Telegram channel
    carries the relay (bot-to-bot messages are invisible in supergroups,
    the bot-25.log jobs 48/49 root cause; channel posts ARE accessible
    to admin bots).
  * the +5 delivery-ready reward call — fired exactly at the verified
    DELIVERY_READY transition (spec §60/§61).

Security model (spec §30-§32): the platform-managed credential is
submitted ONCE through the wizard, encrypted immediately, and NEVER
displayed/exported again. The user cannot deregister the bot (backend
enforcement in network_ui's nbot: handler). We never claim the user
"cannot use the token elsewhere" — the platform prevents EXPORT by
retaining exclusive possession (the honest §32 statement).
"""
from __future__ import annotations

import json
import logging
from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.core.constants import (
    NET_CREATE_CB,
    NET_DG_CB,
    NET_LEGACY_CB,
    NET_MANAGED_CB,
    NET_SETTING_MAX_REWARD,
    NET_SETTING_POINTS_PER_BOT,
    NET_DEFAULT_MAX_BOTS,
    NET_DEFAULT_POINTS_PER_BOT,
)
from app.network.managed_bots import MANAGED_BOT_PENDING_STATE_KEY
from app.network.registry import _row_is_removed as _is_removed_bot
from app.storage.repositories.delivery import (
    DG_READY,
    DG_SETUP_REQUIRED,
    MGMT_PLATFORM_MANAGED,
)
from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    ReplyKeyboardRemove,
    Update,
)
from telegram.ext import ContextTypes

logger = logging.getLogger("payload-bot")

_DG_STATE_KEY = "dg_setup_state"
_NCREATE_STATE_KEY = "ncreate_state"   # pre-v37 wizard (kept for purge safety)
# MANAGED BOTS v37 (Task 8): the ADMIN-ONLY legacy manual token import
# state — a SEPARATE key (never "ncreate_state"/"nmg_pending") so the
# legacy flow can never consume managed-bot updates or hijack other
# flows. Registered in state.py CONVERSATION_INPUT_STATE_KEYS.
_NLEG_STATE_KEY = "nleg_state"


def make_delivery_ui(db, is_admin=None, safe_answer_callback=None,
                     safe_edit_text=None, safe_send_text=None,
                     _net_registry=None, _net_points=None,
                     _net_workers=None, _fdb=None):
    """Bind the delivery-UI functions to explicit dependencies (the same
    late-binding factory discipline as make_network_ui)."""
    # v36 state helpers — imported INSIDE the factory (state.py imports
    # this module's siblings in its import zone; the factory runs
    # post-initialization, so this is cycle-free).
    from app.presentation.telegram.state import (
        clear_conversation_input_states,
        stamp_conversation_state,
        get_net_wizard_origin,
        clear_net_wizard_origin,
        _conversation_state_expired,
        # b10 §1 (B10-B2): the durable token-input intent (the LEGACY
        # admin import's manual token paste gets the same intent gate +
        # BOT_TOKEN_* stage logs as the Add Existing Bot flow).
        set_pending_token_intent,
        get_pending_token_intent,
        update_pending_token_intent,
        consume_pending_token_intent,
        clear_pending_token_intent,
    )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    # b10 §2/§3 (B10-B2): the DURABLE pending Delivery-Group setup record.
    # ROOT CAUSE (bot-10.log): the wizard armed dg_setup_state in the MAIN
    # app's user_data — the WORKER app (where /setup and group messages
    # arrive) has its OWN per-application memory → pending=False, no group
    # row yet → silent return: SETUP_COMMAND_RECEIVED nid=2 … then NOTHING.
    # The pending intent now lives in the DB (network_dg_pending_setup,
    # keyed by network_bot_id) so BOTH applications see it and it survives
    # worker restarts. The repo methods are resolved with getattr so older
    # adapters (regression fakes) simply see no durability — never a crash.
    _DG_PENDING_TTL_NOTE = ("pending Delivery Channel setup rows expire "
                            "after 24h (repo-side pruning)")

    async def _dg_pending_set(nid: int, owner_user_id: int,
                              chat_id: Optional[int] = None) -> None:
        fn = getattr(db, "upsert_pending_delivery_group", None)
        if fn is None:
            return
        try:
            await fn(int(nid), int(owner_user_id), chat_id=chat_id)
        except Exception:  # noqa: BLE001 — durability is best-effort
            pass

    async def _dg_pending_get(nid: int) -> Optional[Dict[str, Any]]:
        fn = getattr(db, "get_pending_delivery_group", None)
        if fn is None:
            return None
        try:
            return await fn(int(nid))
        except Exception:  # noqa: BLE001
            return None

    async def _dg_pending_note_chat(nid: int, chat_id: int) -> None:
        """Remember the LAST detected candidate group/channel chat — Check
        Again (dg:verify) re-runs the REAL verification against it even
        before an association row exists (b10 §3: never a dead-end
        button)."""
        fn = getattr(db, "update_pending_delivery_group_chat", None)
        if fn is None:
            return
        try:
            await fn(int(nid), int(chat_id))
        except Exception:  # noqa: BLE001
            pass

    async def _dg_pending_clear(nid: int) -> None:
        fn = getattr(db, "clear_pending_delivery_group", None)
        if fn is None:
            return
        try:
            await fn(int(nid))
        except Exception:  # noqa: BLE001
            pass

    async def _dg_status_of(nid: int) -> Dict[str, Any]:
        bot = await db.get_network_bot(int(nid))
        if not bot:
            return {"ok": False, "reason": "bot_not_found"}
        group = await db.get_delivery_group_for_bot(int(nid))
        if not group:
            return {"ok": True, "bot": dict(bot), "group": None,
                    "state": DG_SETUP_REQUIRED}
        return {"ok": True, "bot": dict(bot), "group": dict(group),
                "state": str(group.get("status") or DG_SETUP_REQUIRED)}

    def _state_emoji(state: str) -> str:
        return {
            DG_READY: "✅",
            "DELIVERY_VERIFYING": "⏳",
            "DELIVERY_DEGRADED": "🟠",
            "DELIVERY_UNAVAILABLE": "⛔",
            DG_SETUP_REQUIRED: "📁",
        }.get(state, "📁")

    def _fdb_username() -> str:
        return (getattr(_fdb, "bot_username", "") or "").lstrip("@")

    async def _hybrid_ready_line(nid: int) -> str:
        """B23-2 §2.2/§2.5 — the wizard's separate HYBRID pipeline
        readiness line, read from the PERSISTED delivery group row's
        checks (``hybrid_mode_ready`` — the value verify_delivery_group
        computed and stored). NEVER a fabricated PASS: a missing row,
        missing checks or an unknown value reports UNKNOWN with the
        re-verify instruction."""
        row = None
        try:
            row = await db.get_delivery_group_for_bot(int(nid))
        except Exception:  # noqa: BLE001 — honest unknown, never a crash
            row = None
        checks: Dict[str, Any] = {}
        if row:
            raw = row.get("checks")
            if isinstance(raw, dict):
                checks = raw
            elif isinstance(raw, str) and raw.strip():
                try:
                    parsed = json.loads(raw)
                    checks = parsed if isinstance(parsed, dict) else {}
                except Exception:  # noqa: BLE001 — unparseable → unknown
                    checks = {}
        val = checks.get("hybrid_mode_ready")
        if val is True:
            return "HYBRID_DELIVERY_READY=PASS"
        if val is False:
            return "HYBRID_DELIVERY_READY=FAIL"
        return ("HYBRID_DELIVERY_READY=UNKNOWN "
                "(re-verify the delivery group)")

    async def _award_delivery_ready(user_id: int, nid: int) -> Dict[str, Any]:
        """+5 exactly at the verified DELIVERY_READY transition (spec §60)."""
        pts_per = await db.get_setting_int(NET_SETTING_POINTS_PER_BOT,
                                           NET_DEFAULT_POINTS_PER_BOT)
        max_rw = await db.get_setting_int(
            NET_SETTING_MAX_REWARD,
            NET_DEFAULT_MAX_BOTS * NET_DEFAULT_POINTS_PER_BOT)
        res = await _net_points.award_delivery_ready_reward(
            int(user_id), int(nid), points_per_bot=pts_per, max_reward=max_rw)
        await db.insert_control_audit_event(
            "NETWORK_BOT_DELIVERY_READY", actor_user_id=int(user_id),
            network_bot_id=int(nid),
            detail=("reward=+5" if res.get("inserted")
                    else f"reward_skipped:{res.get('reason')}"))
        if res.get("inserted"):
            logger.info("NETWORK_BOT_DELIVERY_READY user_id=%s "
                        "network_bot_id=%s reward=+5 (delivery group "
                        "verified)", user_id, nid)
        return res

    async def _notify_owner(user_id: int, text: str,
                            kb: Optional[InlineKeyboardMarkup] = None
                            ) -> None:
        """Best-effort private notify to the owner — prefers the MAIN bot
        (the owner always started it), falls back to the mini-app bot ref
        set by the website wiring. Notification failures are honest no-ops."""
        try:
            from app.presentation.telegram import runtime as _rt
            bot = getattr(_rt, "_mini_app_bot", None)
            if bot is None:
                logger.info("DELIVERY_OWNER_NOTIFY_SKIPPED user_id=%s "
                            "(no main bot client available)", user_id)
                return
            await _rt.safe_send_text(bot, int(user_id), text, reply_markup=kb)
        except Exception:  # noqa: BLE001 — notification is best-effort
            logger.info("DELIVERY_OWNER_NOTIFY_SKIPPED user_id=%s", user_id)

    # ------------------------------------------------------------------
    # Delivery center — V25 §1 CHANNEL-ONLY (no group setup exposed)
    # ------------------------------------------------------------------
    async def render_delivery_center(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE
                                     ) -> None:
        """V25 §1: the Delivery Center reports the CHANNEL-ONLY topology
        (storage channel → File Delivery Bot → user). Delivery groups are
        deprecated: no setup wizard, no verification, no per-bot group
        state — production delivery requires no group, so the center shows
        the bot registry + the File Delivery Bot plane only."""
        q = getattr(update, "callback_query", None)
        bots = await db.list_network_bots_for_owner(
            int(update.effective_user.id))
        fdb_uname = _fdb_username()
        lines = ["\U0001F4C1 DELIVERY — CHANNEL-ONLY\n"]
        if not bots:
            lines.append("You have no Network Bots yet. Add or create one "
                         "first.")
        else:
            for b in bots:
                mode = (" 🤖" if str(b.get("management_mode"))
                        == MGMT_PLATFORM_MANAGED else "")
                status = str(b.get("status") or "-")
                emoji = "\u2705" if status == "ACTIVE" else "\u26A0\uFE0F"
                lines.append(f"{emoji} @{b['username']}{mode} — {status}")
            lines.append(
                "\nProduction delivery architecture (V25 §1):\n"
                "Storage Channel → File Delivery Bot → User\n"
                + (f"🤖 File Delivery Bot: @{fdb_uname}\n"
                   if fdb_uname else
                   "🤖 File Delivery Bot: see Network Control\n")
                + "No delivery group is required, configured or verified — "
                "the legacy group relay is deprecated (V25 §1).")
        rows = []
        for b in bots:
            rows.append([InlineKeyboardButton(
                f"⚙️ @{b['username']}",
                callback_data=f"{NET_DG_CB}bot:{int(b['id'])}")])
        # v36 (spec §4): origin-aware Back — returns to the panel this
        # center was opened from (admin Network Control when entered
        # from the admin surface, My Network for the user surface).
        rows.append([InlineKeyboardButton(
            "⬅️ Back",
            callback_data=(get_net_wizard_origin(context)
                           or "nreg:back"))])
        kb = InlineKeyboardMarkup(rows)
        text = "\n".join(lines)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_dg_bot(update: Update,
                             context: ContextTypes.DEFAULT_TYPE,
                             nid: int) -> None:
        """V25 §1: the per-bot delivery panel reports the CHANNEL-ONLY
        topology. A legacy delivery-group row (pre-V25 deployment) is
        shown read-only as deprecated history — no setup, no re-verify."""
        q = getattr(update, "callback_query", None)
        st = await _dg_status_of(nid)
        if not st.get("ok"):
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        bot = st["bot"]
        group = st.get("group")
        text = (
            f"🤖 @{bot['username']}\n\n"
            f"Management: {'Platform Managed' if str(bot.get('management_mode')) == MGMT_PLATFORM_MANAGED else 'User Owned'}\n"
            "Delivery: \u2705 Channel-Only (V25 §1)\n\n"
            "Storage Channel → File Delivery Bot → User\n"
            "No delivery group is required or used."
        )
        if group:
            text += ("\n\nLegacy group row (deprecated, unused): "
                     f"{group.get('delivery_group_chat_id')} — "
                     f"{str(group.get('status') or '-')}\n"
                     "Historical delivery-group data cannot re-activate "
                     "group delivery (V25 §1 channel-only routing).")
        rows = [[InlineKeyboardButton(
            "⬅️ Delivery", callback_data=f"{NET_DG_CB}main")]]
        kb = InlineKeyboardMarkup(rows)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_dg_setup(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               nid: int) -> None:
        """V25 §1: DEPRECATED — the Delivery-Group setup wizard is retired.
        Production delivery is CHANNEL-ONLY (storage channel → File
        Delivery Bot → user): no group needs to be connected, so the
        wizard renders a deprecation notice and arms NO pending setup
        (the legacy detection path can never be re-triggered from here).
        Legacy group rows remain readable on the per-bot panel only."""
        q = getattr(update, "callback_query", None)
        bot = await db.get_network_bot(int(nid))
        if not bot:
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        text = (
            "📁 DELIVERY CHANNEL SETUP — DEPRECATED\n\n"
            f"🤖 @{bot['username']} needs NO delivery channel.\n\n"
            "V25 §1 channel-only architecture:\n"
            "Storage Channel → File Delivery Bot → User\n\n"
            "Production delivery never routes through a delivery group: "
            "no group setup, no group membership, no group verification. "
            "Historical delivery-group rows are inert (they can never "
            "re-activate group delivery)."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{NET_DG_CB}bot:{nid}")],
        ])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_dg_instructions(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE,
                                      nid: int, create_new: bool) -> None:
        """V25 §1: DEPRECATED — kept as the redirect target for the legacy
        dg:existing/dg:new buttons rendered by pre-V25 messages; shows the
        same channel-only deprecation notice (arms NO pending setup)."""
        await _render_dg_setup(update, context, nid)

    # ------------------------------------------------------------------
    # Verification (the REAL checks — spec §46/§73)
    # ------------------------------------------------------------------
    async def run_verification(nid: int, chat_id: int,
                               owner_user_id: Optional[int] = None,
                               title: str = "") -> Dict[str, Any]:
        """Run the DELIVERY CHANNEL verification chain + award on success
        (spec §73 'only show success after actual verification').

        V25 FINAL (bot-35.log §4): the production verification target is
        the DELIVERY CHANNEL — ``FileDeliveryBotManager.verify_delivery_
        channel`` persists ``network_bots.delivery_channel_chat_id``
        (schema v42) and logs DELIVERY_CHANNEL_VERIFY_*. The legacy
        group-verification chain (DELIVERY_GROUP_VERIFY_*) is retired
        from production paths.

        v37 (bot-8 A4): structured START/RESULT/FAILURE diagnostics with
        network_bot_id, chat_id, result and reason — never secrets."""
        logger.info("DELIVERY_CHANNEL_VERIFY_START network_bot_id=%s "
                    "chat_id=%s owner=%s (V25 FINAL Delivery Channel "
                    "verification — the two-stage architecture)", int(nid),
                    int(chat_id), int(owner_user_id or 0))
        bot = await db.get_network_bot(int(nid))
        if not bot:
            logger.warning("DELIVERY_CHANNEL_VERIFY_FAILURE "
                            "network_bot_id=%s chat_id=%s result=failed "
                            "reason=bot_not_found",
                            int(nid), int(chat_id))
            return {"ok": False, "reason": "bot_not_found"}
        # Truthful pre-check (bot-8 A4): a Network Bot marked TOKEN_INVALID
        # cannot operate at all — say so explicitly instead of running the
        # chain and failing at the membership probe with a generic error.
        # (A bot whose worker is merely not running right now can still be
        # VERIFIED — the FDB probes are live — and delivery resumes when
        # the worker restarts; that state is reported by the panels.)
        bot_status = str(bot.get("status") or "")
        if bot_status == "TOKEN_INVALID":
            reason = "network_bot_token_invalid"
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=%s bot_status=%s",
                int(nid), int(chat_id), reason, bot_status)
            return {"ok": False, "reason": reason,
                    "checks": {"bot_status": bot_status}}
        verifier = getattr(_fdb, "verify_delivery_channel", None)
        if not callable(verifier):
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=verifier_unavailable",
                int(nid), int(chat_id))
            return {"ok": False, "reason": "verifier_unavailable"}
        res = await verifier(
            bot, int(chat_id), title=title, owner_user_id=owner_user_id)
        if not res.get("ok"):
            logger.warning(
                "DELIVERY_CHANNEL_VERIFY_FAILURE network_bot_id=%s "
                "chat_id=%s result=failed reason=%s", int(nid), int(chat_id),
                res.get("reason"))
            return res
        logger.info("DELIVERY_CHANNEL_VERIFY_RESULT network_bot_id=%s "
                    "chat_id=%s result=ok status=DELIVERY_READY",
                    int(nid), int(chat_id))
        # DELIVERY_READY reached → +5 exactly here (spec §60/§61).
        await _award_delivery_ready(
            int(owner_user_id or bot["owner_user_id"]), int(nid))
        # b10 §2: the durable pending-setup record is DONE — cleared so
        # restarts/Check Again treat the bot as verified, not pending.
        await _dg_pending_clear(int(nid))
        return res

    async def _render_verify_result(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE,
                                    nid: int) -> None:
        """Re-verify the STORED group from the main bot (spec §41 'Verify').

        v37 (bot-8 A4) + b10 §3 (B10-B2): Check Again ALWAYS produces a
        NEW verification result — never a dead-end button. Priority:
          1. the STORED association row (the classic re-verify);
          2. the DURABLE pending-setup record's last detected chat id
             (the wizard was opened and a group message was seen — the
             REAL verification runs even before an association row
             exists, with the DEFINITIVE ✅/❌ result);
          3. honest diagnostics when detection is impossible
             (TOKEN_INVALID / worker offline);
          4. otherwise the EXACT missing step with retry buttons."""
        q = getattr(update, "callback_query", None)
        st = await _dg_status_of(nid)
        if not st.get("ok"):
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        group = st.get("group")
        bot = st.get("bot") or {}
        if not group:
            # No stored group yet. When the network bot itself is offline /
            # token-invalid, group messages can never be detected — the
            # user MUST be told that first (bot-8 A3/A4 chain).
            bot_status = str(bot.get("status") or "")
            if bot_status == "TOKEN_INVALID":
                await safe_answer_callback(
                    q, "⚠️ Your Network Bot's credential is "
                       "invalid (TOKEN_INVALID) — it cannot receive group "
                       "messages, so setup cannot complete. Fix the bot "
                       "first (see My Network → Manage Bot).",
                    show_alert=True)
                logger.warning(
                    "DELIVERY_GROUP_VERIFY_FAILURE network_bot_id=%s "
                    "chat_id=0 result=failed reason=network_bot_token_invalid "
                    "(no stored group; detection impossible while the "
                    "worker is down)", int(nid))
                return
            # b10 §3: the durable pending-setup record may already carry
            # the DETECTED candidate chat — run the REAL verification
            # against it and report the definitive result.
            pending_row = await _dg_pending_get(int(nid))
            try:
                pending_chat = int((pending_row or {}).get("chat_id") or 0)
            except (TypeError, ValueError):
                pending_chat = 0
            if pending_chat:
                await safe_answer_callback(
                    q, "⏳ Verifying Delivery Channel...")
                res = await run_verification(
                    int(nid), int(pending_chat),
                    owner_user_id=int(update.effective_user.id),
                    title=str((pending_row or {}).get("title") or ""))
                if q:
                    await safe_edit_text(
                        q, await _verify_result_text(res, int(nid)),
                        reply_markup=_verify_result_kb(int(nid)))
                return
            worker_running = bool(
                _net_workers is not None
                and _net_workers.get(int(nid)) is not None
                and _net_workers.get(int(nid)).running)
            if not worker_running and _net_workers is not None:
                await safe_answer_callback(
                    q, "⚠️ Your Network Bot is not running right "
                       "now — group messages cannot be detected. Re-open "
                       "My Network or contact the platform admin, then "
                       "check again.", show_alert=True)
                logger.warning(
                    "DELIVERY_GROUP_VERIFY_FAILURE network_bot_id=%s "
                    "chat_id=0 result=failed reason=network_bot_worker_offline "
                    "(no stored group; detection impossible while the "
                    "worker is down)", int(nid))
                return
            # b10 §3: no group chat detected yet — the EXACT missing step
            # (with Check again / Setup steps buttons — never a dead end).
            await safe_answer_callback(
                q, "📁 No Delivery Channel chat detected yet — the exact "
                   "missing step is shown in the panel.")
            fdb_uname = _fdb_username()
            bot_uname = str(bot.get("username") or "")
            await safe_edit_text(
                q,
                "📁 DELIVERY CHANNEL SETUP PENDING\n\n"
                "No Delivery Channel chat has been detected yet for "
                f"@{bot_uname}.\n\n"
                "The exact missing step:\n"
                "1️⃣ Create a NEW private CHANNEL (or pick an existing "
                "one)\n"
                "2️⃣ Add the File Delivery Bot as an administrator"
                + (f" (@{fdb_uname})" if fdb_uname else "") + "\n"
                "3️⃣ Add your Network Bot as an administrator"
                + (f" (@{bot_uname})" if bot_uname else "") + "\n"
                "4️⃣ Post /setup yourself (a human must post it — a bot's "
                "post is attributed to the channel and does not trigger "
                "the handler)\n\n"
                "Then tap Check again — it always re-runs the real "
                "verification.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Check again",
                                          callback_data=(f"{NET_DG_CB}"
                                                         f"verify:{nid}"))],
                    [InlineKeyboardButton("📁 Setup steps",
                                          callback_data=(f"{NET_DG_CB}"
                                                         f"setup:{nid}"))],
                    [InlineKeyboardButton("⬅️ Back",
                                          callback_data=(f"{NET_DG_CB}"
                                                         f"bot:{nid}"))],
                ]))
            return
        await safe_answer_callback(q, "⏳ Verifying Delivery Channel...")
        res = await run_verification(
            int(nid), int(group["delivery_group_chat_id"]),
            owner_user_id=int(update.effective_user.id),
            title=str(group.get("title") or ""))
        if q:
            await safe_edit_text(q, await _verify_result_text(res, int(nid)),
                                 reply_markup=_verify_result_kb(int(nid)))

    async def _verify_result_text(res: Dict[str, Any], nid: int) -> str:
        """The DEFINITIVE verification result (b10 §2/§3): '✅ DELIVERY
        GROUP READY' only after the REAL checks passed, otherwise
        '❌ DELIVERY GROUP NOT READY' with the exact friendly explanation
        AND the machine reason code.

        B23-2: the success report carries the SEPARATE HYBRID pipeline
        readiness line (read from the persisted delivery group row's
        checks — never a fabricated PASS)."""
        if res.get("ok"):
            hybrid_line = await _hybrid_ready_line(int(nid))
            return (
                "✅ DELIVERY CHANNEL READY\n\n"
                "✅ File Delivery Bot found\n"
                "✅ File Delivery Bot is administrator\n"
                "✅ Required permissions verified\n"
                "✅ Network Bot found\n"
                "✅ Network Bot identity verified\n"
                "✅ Delivery capability verified\n\n"
                f"{hybrid_line}\n\n"
                "🎉 Network Bot activated\n"
                "⭐ +5 points awarded when your Network Bot completes "
                "Delivery Channel setup"
            )
        checks = res.get("checks") or {}
        reason = res.get("reason") or "verification_failed"
        friendly = {
            "fdb_not_operational": "⚠️ The platform's File Delivery Bot is "
                                   "not configured yet. Ask the platform "
                                   "admin, then retry.",
            "fdb_not_found": "❌ The platform's File Delivery Bot was not "
                             "found — ask the platform admin to configure "
                             "it, then retry.",
            "not_a_group": "❌ That chat is not a group/supergroup/"
                           "channel.",
            "chat_not_found": "❌ The delivery channel could not be reached "
                              "by the File Delivery Bot — is the bot added "
                              "there as an administrator?",
            "fdb_not_admin": "❌ The File Delivery Bot is not an "
                             "administrator (or lacks the Delete messages "
                             "permission) in the channel.",
            "network_bot_not_member": "❌ Your Network Bot was not found in "
                                      "the channel.",
            "network_bot_not_admin": "❌ Your Network Bot is not an "
                                     "administrator in the channel.",
            "bot_not_found": "❌ This Network Bot is no longer registered "
                             "on the platform.",
            "group_already_used": "❌ That channel is already used by another "
                                  "Network Bot.",
            "network_bot_token_invalid": "⚠️ Your Network Bot's "
                                         "credential is invalid — it cannot "
                                         "receive group messages. Fix the bot "
                                         "first (My Network → Manage Bot).",
            "network_bot_worker_offline": "⚠️ Your Network Bot "
                                          "worker is not running — group "
                                          "messages cannot be detected. Try "
                                          "again shortly or contact the "
                                          "platform admin.",
        }.get(reason, f"❌ Verification failed: {reason}")
        detail = ""
        if checks.get("fdb_missing_privileges"):
            detail = "\nMissing permissions: " + ", ".join(
                str(checks["fdb_missing_privileges"]))
        return (f"❌ DELIVERY CHANNEL NOT READY\n\n{friendly}{detail}\n\n"
                f"Reason: {reason}\n\n"
                "Fix the issue in the channel and check again.")

    def _verify_result_kb(nid: int) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Check again",
                                  callback_data=f"{NET_DG_CB}verify:{nid}")],
            [InlineKeyboardButton("📁 Setup steps",
                                  callback_data=f"{NET_DG_CB}setup:{nid}")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{NET_DG_CB}bot:{nid}")],
        ])

    # ------------------------------------------------------------------
    # DETECTION — the network-worker group-message hook (spec §41)
    # ------------------------------------------------------------------
    async def _net_handle_delivery_group_detection(
            update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Called for group/supergroup/CHANNEL messages on NETWORK workers.

        A.2.3 (bot-25): the Delivery CHANNEL transport — channel posts are
        part of the detection surface. In a channel the post is attributed
        to the channel (the sender identity is absent/unreliable), so the
        authorization for the channel branch is the DURABLE pending-setup
        record or an explicit /setup post; in (super)groups the sender
        must still be the owner (or a platform admin).

        Only acts when a Delivery Channel setup is pending for THIS bot
        (or the post is an explicit /setup). Otherwise returns silently —
        the shared handlers already processed the message.

        b10 §2/§3 (B10-B2): "pending" is now resolved from the DURABLE
        DB-backed pending-setup record (visible to the WORKER app where
        this handler runs — the bot-10.log root cause was the MAIN-app
        user_data key being invisible here) OR the in-memory wizard state
        OR an existing association. A /setup from the owner is an
        EXPLICIT setup intent — it arms the durable record itself, so
        /setup ALWAYS ends in a DEFINITIVE result message in the chat
        (✅ DELIVERY CHANNEL READY / ❌ DELIVERY CHANNEL NOT READY + reason).
        """
        msg = update.effective_message
        chat = update.effective_chat
        user = update.effective_user
        if not (msg and chat):
            return
        # A.2.3: only (super)groups and channels are detection surfaces.
        chat_type = str(getattr(chat, "type", "") or "")
        if chat_type not in ("group", "supergroup", "channel"):
            return
        # In channels the post author is the channel itself (user is
        # often None); a sender is only required for group/supergroup.
        if chat_type != "channel" and not user:
            return
        try:
            bd = getattr(context, "application", None)
            bd = getattr(bd, "bot_data", None) if bd is not None else None
            nid = int(bd.get("network_bot_id")) if bd and bd.get(
                "network_bot_id") else None
        except Exception:  # noqa: BLE001
            nid = None
        if nid is None:
            return
        bot_row = await db.get_network_bot(int(nid))
        if not bot_row:
            return
        # /setup is the DOCUMENTED deterministic entry (bot-8 A5 + b10
        # §2): the owner explicitly signals setup intent IN THIS CHAT —
        # arm the durable pending record even when no wizard was opened.
        msg_text = str(getattr(msg, "text", "") or "")
        is_setup_cmd = msg_text.startswith("/setup")
        # Pending setup state: the in-memory wizard key (main app), the
        # DURABLE DB record (shared by main + worker apps) or an existing
        # association (re-verification / re-association).
        # bot-26 ISSUE A (production crash): CHANNEL posts have NO user,
        # so python-telegram-bot hands this handler a context whose
        # ``user_data`` is None — the plain ``context.user_data.get(...)``
        # raised AttributeError and took the guard down (bot-26.log
        # DELIVERY_GROUP_GUARD_ERROR x2). PTB only guarantees user_data
        # for updates that carry a user; the channel branch of this very
        # handler (A.2.3) explicitly accepts user-less channel posts, so
        # the access must be None-safe. Normal-dict behavior is
        # unchanged; when user_data is None the wizard key simply cannot
        # be pending (the durable DB record / /setup intent below still
        # drive channel detection exactly as before).
        state = (getattr(context, "user_data", None) or {}).get(
            _DG_STATE_KEY) or {}
        pending = state.get("nid") == int(nid)
        pending_row = await _dg_pending_get(int(nid))
        group = await db.get_delivery_group_for_bot(int(nid))
        # V25 FINAL: the AUTHORITATIVE configured chat is the bot row's
        # delivery_channel_chat_id (schema v42 — the migrated/verified
        # Delivery Channel); the legacy group row is compat fallback.
        configured_chat = bot_row.get("delivery_channel_chat_id")
        try:
            configured_chat = int(configured_chat) if configured_chat else None
        except (TypeError, ValueError):
            configured_chat = None
        # A.2.3: the owner check BRANCHES on chat type — in a channel the
        # post is attributed to the channel (no trustworthy sender
        # identity), so the durable pending record or an explicit /setup
        # is the authorization; (super)groups keep the owner/admin check.
        owner = int(bot_row["owner_user_id"])
        if chat_type == "channel":
            owner_check_ok = (pending_row is not None) or is_setup_cmd
        else:
            owner_check_ok = (
                int(user.id) == owner
                or (is_admin and await is_admin(int(user.id)))
            )
        if not owner_check_ok:
            return
        if not pending and pending_row is None and not group:
            if not is_setup_cmd:
                return
            # b10 §2: the owner's /setup arms the intent durably — the
            # verification below ALWAYS runs for the chat it was sent in.
            await _dg_pending_set(int(nid), owner)
        chat_id = int(chat.id)
        if configured_chat == chat_id:
            # Already verified in this exact Delivery Channel — nothing
            # to do... EXCEPT the explicit /setup contract (b10 §2): the
            # command must still produce a DEFINITIVE result message.
            if is_setup_cmd:
                try:
                    await context.bot.send_message(
                        chat_id,
                        "✅ DELIVERY CHANNEL READY\n\n"
                        "This Network Bot is DELIVERY READY in this exact "
                        "channel — no further action needed.\n\n"
                        "Route: Storage → File Delivery Bot → this Delivery "
                        "Channel → Network Bot → user.")
                except Exception:  # noqa: BLE001 — group reply is best-effort
                    pass
            return
        await db.insert_control_audit_event(
            # A.2.3: channel posts have no individual sender (the post is
            # attributed to the channel) — actor 0 is the honest marker.
            "DELIVERY_GROUP_DETECTED",
            actor_user_id=int(getattr(user, "id", 0) or 0),
            network_bot_id=int(nid), detail=f"chat={chat_id}")
        # Remember the candidate chat durably BEFORE verification —
        # Check Again (dg:verify) can then re-run the REAL verification
        # against it from either application (b10 §3).
        await _dg_pending_note_chat(int(nid), chat_id)
        res = await run_verification(
            int(nid), chat_id, owner_user_id=owner,
            title=str(getattr(chat, "title", "") or ""))
        if res.get("ok"):
            await _dg_pending_clear(int(nid))
        # Report IN THE GROUP where the user is looking (spec §73) — the
        # DEFINITIVE b10 §2/§3 result text, never a vague "not verified".
        try:
            await context.bot.send_message(
                chat_id,
                (await _verify_result_text(res, int(nid)))[:900])
        except Exception:  # noqa: BLE001 — group reply is best-effort
            pass
        # And notify the owner privately through the main bot.
        await _notify_owner(
            owner,
            ("🎉 Your Network Bot @%s completed Delivery Channel setup — "
             "it is now DELIVERY READY." % bot_row.get("username"))
            if res.get("ok") else
            ("📁 Delivery Channel verification for @%s is still incomplete "
             "— see the channel chat for details." % bot_row.get("username")))

    # ------------------------------------------------------------------
    # Create Network Bot — v37 (Task 8): the PRIMARY path is the
    # MANAGED-BOT flow (Telegram creates the bot under the main bot's
    # management through a reply-keyboard request; NO BotFather, NO
    # token entry). The manual token import survives ONLY as the
    # ADMIN-ONLY relabeled LEGACY nleg: path below (migration).
    # ------------------------------------------------------------------
    async def _render_ncreate_start(update: Update,
                                    context: ContextTypes.DEFAULT_TYPE
                                    ) -> None:
        """Render the managed-bot creation begin screen.

        The v36 fail-fast stays at THIS factory layer first (the
        injected registry is what this instance would use); the managed
        coordinator re-checks the runtime registry — fail-closed twice,
        and never any token invitation in the primary path."""
        q = getattr(update, "callback_query", None)
        # v36 fail-fast: never invite a credential the platform cannot
        # encrypt (honest message, nothing collected).
        if _net_registry is None or not getattr(
                _net_registry, "can_encrypt_tokens", True):
            await safe_edit_text(
                q,
                "🤖 CREATE A NETWORK BOT\n\n"
                "⛔️ Temporarily unavailable.\n\n"
                "The platform's encryption key is not configured — "
                "ask the platform admin to set NETWORK_TOKEN_ENCRYPTION_KEY "
                "and restart.\n\n"
                "No token was collected (bot tokens are only accepted "
                "when they can be stored encrypted).",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back",
                                          callback_data=(
                                              get_net_wizard_origin(context)
                                              or "nreg:back"))],
                ]))
            return
        # The MANAGED-BOT flow owns the whole screen from here (reply
        # keyboard + pending state + origin-aware back + admin-only
        # legacy import button) — resolved through the runtime namespace
        # at CALL time (the late-binding contract).
        from app.presentation.telegram import runtime as _rt
        await _rt.begin_managed_bot_creation(update, context,
                                             update.effective_user)

    async def _render_ncreate_how(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE) -> None:
        """How It Works — the MANAGED flow explanation (no BotFather, no
        token instructions anywhere in the primary create path)."""
        q = getattr(update, "callback_query", None)
        origin_back = get_net_wizard_origin(context) or "nreg:back"
        text = (
            "ℹ️ HOW IT WORKS\n\n"
            "Managed Network Bots are created by Telegram itself, under "
            "this main bot's management:\n\n"
            "• Tap Create Network Bot → Telegram's creation window opens\n"
            "• Choose a name and a @username → Telegram creates the bot\n"
            "• The platform registers it automatically and starts serving\n"
            "• You connect a private Delivery Channel (the +5 reward comes "
            "after the full verified setup)\n\n"
            "🔒 The credential never leaves the platform: it is generated "
            "by Telegram, fetched server-side, encrypted immediately, and "
            "never shown or exported."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Continue",
                                  callback_data=f"{NET_CREATE_CB}start")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=origin_back)],
        ])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    # ------------------------------------------------------------------
    # MANAGED BOTS v37 (Task 8): nmg: — managed create flow navigation.
    # Cancel/Back exit the pending creation (state cleared, reply
    # keyboard restored, My Network persistent panel rendered).
    # ------------------------------------------------------------------
    async def _handle_net_managed_callback(update: Update,
                                           context: ContextTypes.DEFAULT_TYPE,
                                           user, arg: str) -> None:
        """Dispatch nmg:<action> (user-facing managed create flow)."""
        q = getattr(update, "callback_query", None)
        # ANY nmg: action exits the pending creation — clear the state
        # (the v36 on_callback purge already ran; this makes the handler
        # self-sufficient when invoked directly / from a worker).
        had_pending = context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY,
                                            None) is not None
        if had_pending:
            logger.info("MANAGED_BOT_BEGIN_CANCELLED user_id=%s",
                        int(getattr(user, "id", 0) or 0))
        # Restore the standard keyboard (the managed-bot request keyboard
        # is still up) — ReplyKeyboardRemove rides the NEXT message.
        try:
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "🤖 Bot creation closed — keyboard restored.",
                reply_markup=ReplyKeyboardRemove())
        except Exception:  # noqa: BLE001 — best-effort UX nicety
            pass
        from app.presentation.telegram import runtime as _rt
        await _rt._render_my_network(update, context, user)

    # ------------------------------------------------------------------
    # MANAGED BOTS v37 (Task 8): nleg: — the relabeled LEGACY manual
    # token import (ADMIN-ONLY, migration only). Separate namespace +
    # separate state key: it can never consume managed-bot updates or
    # hijack other flows.
    # ------------------------------------------------------------------
    async def _render_nleg_start(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE
                                 ) -> None:
        """LEGACY/MANUAL IMPORT intro — admin-only (the dispatcher
        re-checks is_admin; on_callback's master gate already blocked
        non-admins)."""
        q = getattr(update, "callback_query", None)
        origin_back = get_net_wizard_origin(context) or "nreg:back"
        # v36 fail-fast: never invite a token the platform cannot encrypt.
        if _net_registry is None or not getattr(
                _net_registry, "can_encrypt_tokens", True):
            await safe_edit_text(
                q,
                "⏳ LEGACY/MANUAL IMPORT\n\n"
                "⛔️ Temporarily unavailable.\n\n"
                "The platform's encryption key is not configured — ask "
                "the platform admin to set NETWORK_TOKEN_ENCRYPTION_KEY "
                "and restart.\n\n"
                "No token was collected (bot tokens are only accepted "
                "when they can be stored encrypted).",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back",
                                          callback_data=origin_back)],
                ]))
            return
        text = (
            "⏳ LEGACY/MANUAL IMPORT — admin only\n\n"
            "This is the MIGRATION-ONLY path: import an existing "
            "BotFather-created bot token into the platform as a "
            "platform-managed Network Bot.\n\n"
            "⚠️ This is NOT the recommended way to add bots — use "
            "Create Network Bot (Telegram creates and manages the bot; "
            "no token handling at all).\n\n"
            "Use this ONLY when migrating a bot that already exists.\n\n"
            "🔒 The token is encrypted immediately and never shown, "
            "logged, or exported again.\n"
            "⌛️ The input times out after 10 minutes."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("⏳ Import BotFather Token",
                                  callback_data=f"{NET_LEGACY_CB}token")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=origin_back)],
        ])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_nleg_token(update: Update,
                                 context: ContextTypes.DEFAULT_TYPE
                                 ) -> None:
        """LEGACY token entry prompt (admin-only namespace; state key is
        nleg_state — NEVER the managed pending state).

        b10 §1 (B10-B2): arms the DURABLE token-input intent (flow=nleg)
        so the manual paste survives unrelated callback navigation —
        the same intent gate as the Add Existing Bot flow."""
        q = getattr(update, "callback_query", None)
        # v36 discipline: single active conversation + freshness stamp +
        # explicit Cancel.
        clear_conversation_input_states(context)
        context.user_data[_NLEG_STATE_KEY] = stamp_conversation_state(
            {"step": "await_token"})
        set_pending_token_intent(
            int(getattr(getattr(update, "effective_user", None), "id", 0)
                or 0), "nleg",
            chat_id=(getattr(update.effective_chat, "id", None)
                     if getattr(update, "effective_chat", None) else None),
            message_id=(getattr(getattr(update, "callback_query", None),
                                "message", None)
                        and getattr(update.callback_query.message,
                                   "message_id", None)))
        origin_back = get_net_wizard_origin(context) or "nreg:back"
        text = (
            "⏳ LEGACY TOKEN IMPORT\n\n"
            "LEGACY/MANUAL IMPORT — paste an existing BotFather token "
            "(migration only).\n\n"
            "Format: 123456789:ABCdef...\n\n"
            "🔒 The token is encrypted immediately. It will never be "
            "shown, logged, or exported again.\n"
            "⌛️ The input times out after 10 minutes."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Cancel",
                                  callback_data=origin_back)],
        ])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def handle_nleg_text(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               user, text: str) -> bool:
        """LEGACY token submission (admin-only text input path). Returns
        True when the message was consumed. NEVER active for non-admins:
        the state only exists behind the admin-gated nleg: entry.

        b10 §1 (B10-B2): intent-gated like the Add Existing Bot flow —
        the nleg_state may have been purged by unrelated navigation
        while the durable intent (flow=nleg) survives; the token is
        accepted ONLY while that intent is live, exactly once (BOT_TOKEN_*
        stage logs; never the token itself)."""
        state = context.user_data.get(_NLEG_STATE_KEY)
        intent = get_pending_token_intent(int(user.id))
        if not state:
            if intent and intent.get("flow") == "nleg":
                # Navigation purged the wizard state; the durable intent
                # keeps the flow alive (the b10 §1 recovery).
                state = stamp_conversation_state({"step": "await_token"})
                logger.info(
                    "BOT_TOKEN_INPUT_RECOVERED user_id=%s flow=nleg "
                    "(state purged by navigation; durable intent honored)",
                    int(user.id))
            else:
                return False
        if str(state.get("step")) != "await_token":
            return False
        # Admin gate (defense in depth — the state can only be set
        # through the admin-gated nleg: callbacks, but a non-admin must
        # never be able to consume a secret here).
        if not (is_admin and await is_admin(int(user.id))):
            context.user_data.pop(_NLEG_STATE_KEY, None)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id, "Admins only.")
            return True
        if _conversation_state_expired(state):
            context.user_data.pop(_NLEG_STATE_KEY, None)
            clear_pending_token_intent(int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "⌛️ The legacy token input timed out (10 min) — no bot "
                "was imported. Start again from Legacy Manual Import.")
            return True
        from app.network.registry import token_format_ok as _fmt_ok
        context.user_data.pop(_NLEG_STATE_KEY, None)
        token = (text or "").strip()
        # NEVER echo/log the token; length only (b10 §1 stage logs).
        logger.info("BOT_TOKEN_RECEIVED user_id=%s flow=nleg length=%s "
                    "(content never logged)", int(user.id), len(token))
        if not _fmt_ok(token):
            logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=nleg "
                        "reason=bad_token_format (retry kept — nothing "
                        "was saved)", int(user.id))
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "❌ That doesn't look like a bot token.\n"
                "Format: 123456789:ABCdef... (from @BotFather)\n\n"
                "Start again with /network → Create Network Bot → "
                "Legacy Manual Import (admin).")
            return True
        await safe_send_text(context.bot, update.effective_chat.id,
                             "⏳ Importing the existing bot with Telegram...")
        logger.info("BOT_TOKEN_VALIDATION_STARTED user_id=%s flow=nleg "
                    "(getMe identity validation)", int(user.id))
        val = await _net_registry.attempt_registration(
            int(user.id), token, consent_confirmed=True,
            management_mode=MGMT_PLATFORM_MANAGED,
            credential_control="PLATFORM",
            created_via="legacy_manual_import")
        reason = str(val.get("reason") or "unknown")
        logger.info("BOT_TOKEN_VALIDATION_RESULT user_id=%s flow=nleg "
                    "ok=%s reason=%s", int(user.id), bool(val.get("ok")),
                    reason)
        if not val.get("ok"):
            friendly = {
                "invalid_token": "Telegram rejected this token.",
                "telegram_unreachable": "Could not reach Telegram — try "
                                        "again shortly.",
                "bad_token_format": "That doesn't look like a bot token.",
                "duplicate_bot": "This bot is already registered on the "
                                 "platform.",
                "registration_limit_reached": "You reached the maximum "
                                              "registered bots limit.",
                "network_disabled": "The Network is currently disabled.",
                "encryption_key_missing": "The platform's encryption key "
                                          "is not configured — ask the "
                                          "platform admin.",
            }.get(reason, f"Import failed ({reason}).")
            if reason in ("invalid_token", "telegram_unreachable"):
                # Retryable (spec §1): keep the intent so the admin can
                # paste again immediately.
                logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=nleg "
                            "reason=%s (retry kept — state preserved)",
                            int(user.id), reason)
            else:
                logger.info("BOT_TOKEN_FLOW_FAILED user_id=%s flow=nleg "
                            "reason=%s (input closed)", int(user.id),
                            reason)
                clear_pending_token_intent(int(user.id))
            await safe_send_text(context.bot, update.effective_chat.id,
                                 f"❌ {friendly}")
            return True
        # Accepted exactly once — the durable intent is consumed.
        consume_pending_token_intent(int(user.id))
        # Imported as platform-managed (spec §28) — same completion as
        # the pre-v37 wizard: worker start → ACTIVE → audit → panel.
        nid = int(val["network_bot_id"])
        username = str(val.get("username") or "")
        logger.info("BOT_TOKEN_PERSISTED user_id=%s flow=nleg "
                    "network_bot_id=%s telegram_bot_id=%s username=@%s "
                    "storage=encrypted", int(user.id), nid,
                    int(val.get("telegram_bot_id") or 0), username)
        await db.insert_control_audit_event(
            "MANAGED_NETWORK_BOT_CREATED", actor_user_id=int(user.id),
            network_bot_id=nid,
            detail=f"username=@{username} via=legacy_manual_import")
        await db.insert_control_audit_event(
            "MANAGED_NETWORK_BOT_REGISTERED", actor_user_id=int(user.id),
            network_bot_id=nid)
        worker = await _net_workers.start_worker(
            nid, int(val.get("telegram_bot_id") or 0), username, token)
        if worker is not None:
            await _net_registry.mark_active(nid)
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "✅ Network Bot imported and registered!\n\n"
            f"🤖 @{username}\n"
            "Management: Platform Managed\n"
            "Credential: 🔐 Protected\n"
            "Network: 🟢 Active\n\n"
            "Delivery is active out of the box (V25 §1 channel-only: "
            "storage channel → File Delivery Bot → user).",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📁 Delivery (Channel-Only)",
                                      callback_data=f"{NET_DG_CB}bot:{nid}")],
                [InlineKeyboardButton("🌐 My Network",
                                      callback_data=(
                                          get_net_wizard_origin(context)
                                          or "nreg:back"))],
            ]))
        return True

    async def _handle_net_legacy_callback(update: Update,
                                          context: ContextTypes.DEFAULT_TYPE,
                                          user, arg: str) -> None:
        """Dispatch nleg:<action> — ADMIN-ONLY legacy manual import
        (nleg:start / nleg:token; anything else → the intro)."""
        q = getattr(update, "callback_query", None)
        if not (is_admin and await is_admin(int(user.id))):
            await safe_answer_callback(q, "Admins only.", show_alert=True)
            return
        if arg == "token":
            await _render_nleg_token(update, context)
        else:
            # Leaving the legacy import (start/intro/cancel) — retire the
            # durable token intent too (b10 §1 explicit-exit semantics).
            clear_pending_token_intent(int(getattr(user, "id", 0) or 0))
            await _render_nleg_start(update, context)

    # ------------------------------------------------------------------
    # Dispatcher (dg:<action>:<nid> / ncreate:<action>)
    # ------------------------------------------------------------------
    async def handle_delivery_callback(update: Update,
                                       context: ContextTypes.DEFAULT_TYPE,
                                       user, action: str) -> None:
        """Dispatch dg:<action> (user-facing — owner checks inside)."""
        parts = action.split(":")
        cmd = parts[0] if parts else "main"
        nid = 0
        if len(parts) > 1 and parts[1].isdigit():
            nid = int(parts[1])
        if cmd == "main":
            await render_delivery_center(update, context)
            return
        if not nid:
            return
        # Owner or admin only (spec §59 isolation — a user may only manage
        # their OWN bot's delivery group).
        bot = await db.get_network_bot(nid)
        if not bot:
            return
        if int(bot["owner_user_id"]) != int(user.id) and not (
                is_admin and await is_admin(int(user.id))):
            await safe_answer_callback(
                getattr(update, "callback_query", None),
                "You can only manage your own Network Bot.",
                show_alert=True)
            return
        # BOT-16 (stale-REMOVED guard — mirrors network_ui.py's nbot:
        # guard; THE ONLY delivery_ui change in the BOT-16 round): a
        # REMOVED bot is gone — dg:bot:/dg:setup:/dg:verify: panels on a
        # removed row (typically from a rendered keyboard that predates
        # the removal) answer truthfully instead of opening the Delivery
        # Group wizard for a bot that no longer exists.
        if _is_removed_bot(bot):
            logger.info("NETWORK_BOT_STALE_CALLBACK network_bot_id=%s "
                        "action=%s user_id=%s (delivery-group surface)",
                        nid, cmd, int(user.id))
            await safe_answer_callback(
                getattr(update, "callback_query", None),
                "This Network Bot was removed. Register it again "
                "to use it.", show_alert=True)
            return
        if cmd == "bot":
            await _render_dg_bot(update, context, nid)
        elif cmd == "setup":
            await _render_dg_setup(update, context, nid)
        elif cmd == "existing":
            await _render_dg_instructions(update, context, nid,
                                          create_new=False)
        elif cmd == "new":
            await _render_dg_instructions(update, context, nid,
                                          create_new=True)
        elif cmd == "verify":
            # V25 §1: the legacy group verification is DEPRECATED — answer
            # with the channel-only notice and retire any legacy pending
            # setup row so the detection path goes fully inert.
            q = getattr(update, "callback_query", None)
            await _dg_pending_clear(int(nid))
            await safe_answer_callback(
                q, "Delivery groups are deprecated (V25 §1 channel-only).",
                show_alert=True)
            await _render_dg_bot(update, context, nid)

    async def handle_ncreate_callback(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE,
                                      user, action: str) -> None:
        """Dispatch ncreate:<action> (user-facing).

        v37 (Task 8): ``start`` (and any legacy ``token`` bookmark from
        Telegram message history — the old wizard step no longer exists)
        render the MANAGED-BOT creation flow; ``how`` explains it."""
        if action in ("start", "token", ""):
            await _render_ncreate_start(update, context)
        elif action == "how":
            await _render_ncreate_how(update, context)

    return SimpleNamespace(
        render_delivery_center=render_delivery_center,
        handle_delivery_callback=handle_delivery_callback,
        handle_ncreate_callback=handle_ncreate_callback,
        _handle_net_managed_callback=_handle_net_managed_callback,
        _handle_net_legacy_callback=_handle_net_legacy_callback,
        handle_nleg_text=handle_nleg_text,
        _net_handle_delivery_group_detection=_net_handle_delivery_group_detection,
        _run_delivery_verification=run_verification,
        _award_delivery_ready=_award_delivery_ready,
        _dg_status_of=_dg_status_of,
        # B23-2: exposed for the HYBRID wizard-readiness regression suite
        # (the HYBRID_DELIVERY_READY line is part of the /setup contract).
        _verify_result_text=_verify_result_text,
        _hybrid_ready_line=_hybrid_ready_line,
    )
