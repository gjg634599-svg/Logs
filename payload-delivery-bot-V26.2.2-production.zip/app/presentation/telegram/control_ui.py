"""FILE DELIVERY v34 — the CONTROL BOT (spec §21-§26, §35-§36, §64).

The administrative control plane for platform-owned delivery
infrastructure:

    CONTROL BOT (this module)
         │
    PLATFORM ADMIN (existing is_admin — env ADMIN_IDS + DB admins)
         │
    ├── 📦 File Delivery Bot     — token add/change/validate/health/
    │                              restart/disable/enable (spec §24/§25)
    ├── 🤖 Managed Network Bots  — create/list/health/reconcile/
    │                              disable/rotate/remove (spec §35/§64)
    ├── ❤️ Health                — aggregate health snapshot
    ├── 📊 Analytics             — delivery jobs + routing stats
    ├── 🔑 Credentials           — safe key configuration diagnostics
    ├── 🔄 Reconciliation        — re-verify all Delivery Groups + job
    │                              crash recovery sweep (spec §55)
    └── ⚙️ Settings              — TTL/retry settings + audit trail

Authorization: EVERY action re-checks ``is_admin`` server-side (spec §22)
— hidden buttons are never the security boundary. Audit events are
persisted to control_audit_events + structured logs (spec §36) with NO
secrets (tokens are referenced as "credential=protected", never printed).

The same handlers power BOTH surfaces:
  * the dedicated Control Bot application (CONTROL_BOT_TOKEN — its own
    Telegram bot, started in-process like network workers, spec §21);
  * the main bot's admin area (panel:control → ctl:*) — one
    implementation, two entry surfaces, no duplicate admin identity.
"""
from __future__ import annotations

import logging
from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.core.constants import (
    CONTROL_CB,
    DELIVERY_DEFAULT_MAX_ATTEMPTS,
    DELIVERY_DEFAULT_RELAY_TTL,
    DELIVERY_DEFAULT_RETRY_BASE,
    DELIVERY_DEFAULT_SWEEP_INTERVAL,
    DELIVERY_SETTING_MAX_ATTEMPTS,
    DELIVERY_SETTING_RELAY_TTL,
    DELIVERY_SETTING_RETRY_BASE,
    DELIVERY_SETTING_SWEEP_INTERVAL,
    NET_SETTING_MAX_BOTS,
    NET_DEFAULT_MAX_BOTS,
)
from app.storage.repositories.delivery import (
    DG_READY,
    FDB_DISABLED,
    FDB_READY,
    FDB_TOKEN_INVALID,
    FDB_UNCONFIGURED,
    MGMT_PLATFORM_MANAGED,
)
from app.network.registry import _row_is_removed as _is_removed_bot
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

logger = logging.getLogger("payload-bot")

_CTL_FDB_STATE_KEY = "ctl_fdb_state"
_CTL_ROTATE_STATE_KEY = "ctl_rotate_state"
_CTL_CREATE_STATE_KEY = "ctl_create_state"


def make_control_ui(db, is_admin=None, safe_answer_callback=None,
                    safe_edit_text=None, safe_send_text=None,
                    _fdb=None, _net_registry=None, _net_workers=None,
                    _net_delivery_jobs=None, _net_points=None):
    """Bind the Control Bot handlers to explicit dependencies."""
    # v36 state helpers — imported INSIDE the factory (state.py imports
    # this module in its import zone, so a module-level import would be
    # circular; the factory runs post-initialization).
    from app.presentation.telegram.state import (
        clear_conversation_input_states,
        stamp_conversation_state,
        _conversation_state_expired,
    )

    # ------------------------------------------------------------------
    # Authorization (spec §22 — every action, server-side)
    # ------------------------------------------------------------------
    async def _require_admin(update: Update) -> bool:
        user = update.effective_user
        if not user:
            return False
        if is_admin is None or not await is_admin(int(user.id)):
            await safe_answer_callback(
                getattr(update, "callback_query", None),
                "Platform admins only.", show_alert=True)
            return False
        await db.insert_control_audit_event(
            "CONTROL_BOT_ADMIN_ACCESS", actor_user_id=int(user.id),
            detail=str(getattr(update, "effective_message", None) and
                       "callback") or "message")
        return True

    def _fdb_status_line(snap: Dict[str, Any]) -> str:
        st = str(snap.get("status") or FDB_UNCONFIGURED)
        icon = {FDB_READY: "✅", FDB_DISABLED: "🛑",
                FDB_TOKEN_INVALID: "⛔"}.get(st, "⚠️" if st ==
                                             FDB_UNCONFIGURED else "🟠")
        return f"{icon} {st}"

    async def _fdb_snap() -> Dict[str, Any]:
        """File Delivery Bot snapshot — never raises (spec §31: NOT_CONFIGURED
        must render even when the relay subsystem could not start)."""
        if _fdb is None:
            return {"status": FDB_UNCONFIGURED, "configured": False,
                    "storage_access": "unknown", "worker_state": "stopped",
                    "last_error": "relay subsystem unavailable "
                                  "(network service init failed — see logs)"}
        return await _fdb.status_snapshot()

    # ------------------------------------------------------------------
    # Main panel (spec §23)
    # ------------------------------------------------------------------
    async def render_control_panel(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE
                                   ) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        snap = await _fdb_snap()
        managed = await db.list_network_bots_by_management(
            MGMT_PLATFORM_MANAGED)
        text = (
            "🛡 PLATFORM CONTROL\n\n"
            f"📦 File Delivery Bot: {_fdb_status_line(snap)}\n"
            f"🤖 Managed Network Bots: {len(managed)}\n"
            f"📁 Delivery Channels ready: "
            f"{await db.count_delivery_groups(ready_only=True)}/"
            f"{await db.count_delivery_groups()}\n"
            f"🚚 Delivery jobs active: "
            f"{await db.count_delivery_jobs()}"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 File Delivery Bot",
                                  callback_data=f"{CONTROL_CB}fdb")],
            [InlineKeyboardButton("🤖 Managed Network Bots",
                                  callback_data=f"{CONTROL_CB}managed")],
            [InlineKeyboardButton("➕ Create Network Bot",
                                  callback_data=f"{CONTROL_CB}managed:create")],
            [InlineKeyboardButton("❤️ Health",
                                  callback_data=f"{CONTROL_CB}health")],
            [InlineKeyboardButton("📊 Analytics",
                                  callback_data=f"{CONTROL_CB}analytics")],
            [InlineKeyboardButton("🔑 Credentials",
                                  callback_data=f"{CONTROL_CB}credentials")],
            [InlineKeyboardButton("🔄 Reconciliation",
                                  callback_data=f"{CONTROL_CB}reconcile")],
            [InlineKeyboardButton("⚙️ Settings",
                                  callback_data=f"{CONTROL_CB}settings")],
            [InlineKeyboardButton("⬅️ Admin Panel",
                                  callback_data="panel:main")],
        ])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    # ------------------------------------------------------------------
    # File Delivery Bot panel (spec §24)
    # ------------------------------------------------------------------
    async def _render_fdb(update: Update,
                          context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        snap = await _fdb_snap()
        storage = str(snap.get("storage_access") or "unknown")
        storage_icon = {"full": "✅", "partial": "🟠", "none": "⛔"}.get(
            storage, "❔")
        worker = str(snap.get("worker_state") or "stopped")
        worker_icon = "🟢" if worker == "running" and snap.get(
            "configured") else "⚪️"
        text = (
            "🛡 FILE DELIVERY BOT\n\n"
            f"Status: {_fdb_status_line(snap)}\n\n"
            f"Bot: @{snap.get('username') or '-'}\n"
            f"Bot ID: {snap.get('telegram_bot_id') or '-'}\n\n"
            f"Storage Access: {storage_icon} {storage}\n"
            f"Delivery Capability: "
            f"{'✅' if snap.get('configured') and storage in ('full', 'partial') else '⛔'}\n"
            f"Worker: {worker_icon} {worker}\n"
            f"Credential: 🔐 Protected\n"
        )
        if snap.get("last_error"):
            text += f"Last error: {str(snap['last_error'])[:160]}\n"
        if snap.get("configured"):
            rows = [
                [InlineKeyboardButton("🔄 Change Token",
                                      callback_data=f"{CONTROL_CB}fdb:change")],
                [InlineKeyboardButton("✅ Validate",
                                      callback_data=f"{CONTROL_CB}fdb:validate"),
                 InlineKeyboardButton("❤️ Health",
                                      callback_data=f"{CONTROL_CB}fdb:health")],
                [InlineKeyboardButton("🔄 Restart",
                                      callback_data=f"{CONTROL_CB}fdb:restart")],
            ]
            if str(snap.get("status")) == FDB_DISABLED:
                rows.append([InlineKeyboardButton("▶️ Enable",
                                                  callback_data=f"{CONTROL_CB}fdb:enable")])
            else:
                rows.append([InlineKeyboardButton("🛑 Disable",
                                                  callback_data=f"{CONTROL_CB}fdb:disable")])
        else:
            rows = [[InlineKeyboardButton("🔑 Add Token",
                                          callback_data=f"{CONTROL_CB}fdb:add")]]
        rows.append([InlineKeyboardButton("⬅️ Back",
                                          callback_data=f"{CONTROL_CB}main")])
        kb = InlineKeyboardMarkup(rows)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _fdb_token_input(update: Update,
                               context: ContextTypes.DEFAULT_TYPE,
                               change: bool) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        # v36: entering this input flow ends EVERY other pending input
        # conversation (single active conversation) + freshness stamp.
        clear_conversation_input_states(context)
        context.user_data[_CTL_FDB_STATE_KEY] = stamp_conversation_state(
            {"step": "await_token", "change": bool(change)})
        await db.insert_control_audit_event(
            "FILE_DELIVERY_BOT_CONFIG_STARTED",
            actor_user_id=int(update.effective_user.id))
        text = (
            ("🔄 CHANGE FILE DELIVERY BOT TOKEN\n\n" if change else
             "🔑 ADD FILE DELIVERY BOT TOKEN\n\n")
            + "Send the new token now (from @BotFather).\n\n"
            "The flow (safe order):\n"
            "1️⃣ getMe validation with the NEW token\n"
            "2️⃣ bot identity confirmation\n"
            "3️⃣ encrypt + persist\n"
            "4️⃣ worker rebind\n"
            "5️⃣ health verification\n"
            "6️⃣ old credential retired only AFTER success\n\n"
            "🔒 The token is never displayed, logged, or echoed."
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "❌ Cancel", callback_data=f"{CONTROL_CB}fdb")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def handle_control_text(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE,
                                  user, text: str) -> bool:
        """Text inputs for the Control Bot: FDB token add/change, managed
        bot credential rotation, managed bot create. Returns True when
        consumed."""
        fdb_state = context.user_data.get(_CTL_FDB_STATE_KEY)
        rot_state = context.user_data.get(_CTL_ROTATE_STATE_KEY)
        create_state = context.user_data.get(_CTL_CREATE_STATE_KEY)
        if not (fdb_state or rot_state or create_state):
            return False
        if not (is_admin and await is_admin(int(user.id))):
            context.user_data.pop(_CTL_FDB_STATE_KEY, None)
            context.user_data.pop(_CTL_ROTATE_STATE_KEY, None)
            context.user_data.pop(_CTL_CREATE_STATE_KEY, None)
            return False
        if _fdb is None and (fdb_state or rot_state):
            # The relay subsystem never started — answer honestly
            # instead of crashing on _fdb.change_token (spec §31).
            context.user_data.pop(_CTL_FDB_STATE_KEY, None)
            context.user_data.pop(_CTL_ROTATE_STATE_KEY, None)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "❌ File Delivery subsystem unavailable — network service "
                "init failed. Check the bot logs and restart.")
            return True
        token = (text or "").strip()
        from app.network.registry import token_format_ok as _fmt_ok
        if fdb_state and str(fdb_state.get("step")) == "await_token":
            if _conversation_state_expired(fdb_state):
                context.user_data.pop(_CTL_FDB_STATE_KEY, None)
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "⌛️ The token input timed out (10 min) — no changes were "
                    "made. Start again from the File Delivery Bot panel.")
                return True
            context.user_data.pop(_CTL_FDB_STATE_KEY, None)
            if not _fmt_ok(token):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "❌ That doesn't look like a bot token. "
                    "Format: 123456789:ABCdef...")
                return True
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "⏳ Validating with Telegram (getMe)...")
            res = (await _fdb.change_token(token, actor_user_id=int(user.id))
                   if fdb_state.get("change")
                   else await _fdb.configure_token(token,
                                                   actor_user_id=int(user.id)))
            if res.get("ok"):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    f"✅ File Delivery Bot configured: @{res.get('username')}\n"
                    f"Storage access: {res.get('storage_access')}\n"
                    "Credential: 🔐 Protected",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        "🛡 File Delivery Bot",
                        callback_data=f"{CONTROL_CB}fdb")]]))
            else:
                reason = str(res.get("reason") or "failed")
                friendly = {
                    "invalid_token": "Telegram rejected this token.",
                    "telegram_unreachable": "Could not reach Telegram.",
                    "encryption_key_missing":
                        "NETWORK_TOKEN_ENCRYPTION_KEY is not configured — "
                        "set it first, then retry.",
                }.get(reason, f"Failed ({reason}).")
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    f"❌ {friendly}\n\nThe previous credential was kept "
                    "(never destroyed first).")
            return True
        if rot_state and str(rot_state.get("step")) == "await_token":
            nid = int(rot_state.get("nid") or 0)
            context.user_data.pop(_CTL_ROTATE_STATE_KEY, None)
            if not _fmt_ok(token):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "❌ That doesn't look like a bot token.")
                return True
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "⏳ Validating + rotating...")
            res = await _fdb.rotate_network_bot_credential(
                nid, token, actor_user_id=int(user.id))
            if res.get("ok"):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    f"✅ Credential rotated for bot @{res.get('username')}.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        "🤖 Bot detail",
                        callback_data=f"{CONTROL_CB}managed:bot:{nid}")]]))
            else:
                reason = str(res.get("reason") or "failed")
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    f"❌ Rotation failed ({reason}). The previous "
                    "credential was preserved.")
            return True
        if create_state and str(create_state.get("step")) == "await_token":
            owner = int(create_state.get("owner") or 0)
            context.user_data.pop(_CTL_CREATE_STATE_KEY, None)
            if not _fmt_ok(token):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    "❌ That doesn't look like a bot token.")
                return True
            await safe_send_text(context.bot, update.effective_chat.id,
                                 "⏃ Registering managed bot...")
            res = await _net_registry.attempt_registration(
                owner, token, consent_confirmed=True,
                management_mode=MGMT_PLATFORM_MANAGED,
                credential_control="PLATFORM",
                created_via="admin_control_bot")
            if not res.get("ok"):
                await safe_send_text(
                    context.bot, update.effective_chat.id,
                    f"❌ Registration failed ({res.get('reason')}).")
                return True
            nid = int(res["network_bot_id"])
            await db.insert_control_audit_event(
                "MANAGED_NETWORK_BOT_CREATED", actor_user_id=int(user.id),
                network_bot_id=nid,
                detail=f"username=@{res.get('username')} owner={owner}")
            await db.insert_control_audit_event(
                "MANAGED_NETWORK_BOT_REGISTERED", actor_user_id=int(user.id),
                network_bot_id=nid)
            worker = await _net_workers.start_worker(
                nid, int(res.get("telegram_bot_id") or 0),
                str(res.get("username") or ""), token)
            if worker is not None:
                await _net_registry.mark_active(nid)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                f"✅ Managed bot registered: @{res.get('username')} "
                f"(owner {owner}).",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                    "🤖 Bot detail",
                    callback_data=f"{CONTROL_CB}managed:bot:{nid}")]]))
            return True
        return False

    # ------------------------------------------------------------------
    # Managed Network Bots panel (spec §35)
    # ------------------------------------------------------------------
    async def _render_managed(update: Update,
                              context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        bots = await db.list_network_bots_by_management(MGMT_PLATFORM_MANAGED)
        ready = setup = degraded = disabled = 0
        for b in bots:
            g = await db.get_delivery_group_for_bot(int(b["id"]))
            gs = str((g or {}).get("status") or "DELIVERY_SETUP_REQUIRED")
            if str(b.get("status")) == "DISABLED":
                disabled += 1
            elif gs == DG_READY:
                ready += 1
            elif gs in ("DELIVERY_DEGRADED", "DELIVERY_UNAVAILABLE"):
                degraded += 1
            else:
                setup += 1
        text = (
            "🤖 MANAGED NETWORK BOTS\n\n"
            f"Total: {len(bots)}\n"
            f"Ready: {ready}\n"
            f"Setup Required: {setup}\n"
            f"Degraded: {degraded}\n"
            f"Disabled: {disabled}\n"
            f"Delivery Channels ready: {await db.count_delivery_groups(True)}"
        )
        kb_rows = [
            [InlineKeyboardButton("➕ Create",
                                  callback_data=f"{CONTROL_CB}managed:create")],
            [InlineKeyboardButton("📋 List",
                                  callback_data=f"{CONTROL_CB}managed:list")],
            [InlineKeyboardButton("❤️ Health",
                                  callback_data=f"{CONTROL_CB}health")],
            [InlineKeyboardButton("🔄 Reconcile",
                                  callback_data=f"{CONTROL_CB}reconcile")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{CONTROL_CB}main")],
        ]
        if q:
            await safe_edit_text(q, text,
                                 reply_markup=InlineKeyboardMarkup(kb_rows))
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=InlineKeyboardMarkup(kb_rows))

    async def _render_managed_list(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE
                                   ) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        # BOT-16: the default view lists ACTIVE (non-REMOVED) managed bots
        # only — the repo default excludes REMOVED rows (terminal status +
        # the legacy DISABLED+REMOVED shape). A one-line footer keeps the
        # removed count honest without leaking the gone bots back in.
        bots = await db.list_network_bots_by_management(MGMT_PLATFORM_MANAGED)
        removed_count = 0
        try:
            _all = await db.list_network_bots_by_management(
                MGMT_PLATFORM_MANAGED, include_removed=True)
            removed_count = sum(1 for b in _all if _is_removed_bot(b))
        except Exception:  # noqa: BLE001 — footer is optional
            removed_count = 0
        if not bots:
            text = "🤖 MANAGED NETWORK BOTS\n\nNo platform-managed bots."
        else:
            lines = ["🤖 MANAGED NETWORK BOTS\n"]
            for b in bots[:25]:
                g = await db.get_delivery_group_for_bot(int(b["id"]))
                gs = str((g or {}).get("status") or "SETUP_REQUIRED")
                icon = {"DELIVERY_READY": "✅",
                        "DELIVERY_DEGRADED": "🟠",
                        "DELIVERY_UNAVAILABLE": "⛔"}.get(gs, "📁")
                lines.append(f"{icon} @{b['username']} — #{b['id']} "
                            f"({gs.replace('DELIVERY_', '')})")
            text = "\n".join(lines)
        if removed_count:
            text += (f"\n\n🗑 {removed_count} removed (audit trail in "
                     "Control audit log)")
        # BOT-11 §8 (production bug, bot-11.log): the button text was the
        # RAW DB row dict — Telegram rejects it with
        # BadRequest: Can't parse inlinekeyboardbutton: field "text" must
        # be of type string, and the swallowed error made the callback
        # report success=False→True. Button text is ALWAYS a proper str
        # label now ("@username — #id"; "#id" when username is NULL).
        def _bot_button_label(row: Dict[str, Any]) -> str:
            try:
                nid = int(row["id"])
            except (KeyError, TypeError, ValueError):
                nid = 0
            uname = str(row.get("username") or "").lstrip("@")
            return f"@{uname} — #{nid}" if uname else f"#{nid}"
        rows = [[InlineKeyboardButton(_bot_button_label(b),
                                       callback_data=f"{CONTROL_CB}managed:bot:{int(b['id'])}")]
                for b in bots[:20]]
        rows.append([InlineKeyboardButton("⬅️ Back",
                                          callback_data=f"{CONTROL_CB}managed")])
        kb = InlineKeyboardMarkup(rows)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_managed_bot(update: Update,
                                   context: ContextTypes.DEFAULT_TYPE,
                                   nid: int) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        bot = await db.get_network_bot(int(nid))
        if not bot:
            await safe_answer_callback(q, "Bot not found.", show_alert=True)
            return
        g = await db.get_delivery_group_for_bot(int(nid))
        gs = str((g or {}).get("status") or "DELIVERY_SETUP_REQUIRED")
        text = (
            "🤖 NETWORK BOT\n\n"
            f"Username: @{bot['username']}\n"
            f"Bot ID: {bot['telegram_bot_id']}\n\n"
            f"Owner: Telegram user {bot['owner_user_id']}\n"
            f"Management: PLATFORM MANAGED\n"
            f"Credential: 🔐 Protected\n\n"
            f"Delivery: {'✅ READY' if gs == DG_READY else '📁 ' + gs.replace('DELIVERY_', '')}\n"
            f"Delivery Channel: {(g or {}).get('delivery_group_chat_id') or '-'}\n"
            f"Worker: {'🟢' if str(bot['status']) == 'ACTIVE' else '⚪️'} {bot['status']}\n"
            f"Health: {bot['health']}\n"
        )
        if (g or {}).get("last_error"):
            text += f"Last DG issue: {str(g['last_error'])[:120]}\n"
        rows = [
            [InlineKeyboardButton("❤️ Health",
                                  callback_data=f"{CONTROL_CB}managed:health:{nid}")],
            [InlineKeyboardButton("🔄 Reconcile",
                                  callback_data=f"{CONTROL_CB}managed:recon:{nid}")],
        ]
        if str(bot["status"]) == "DISABLED":
            rows.append([InlineKeyboardButton("▶️ Enable",
                                              callback_data=f"{CONTROL_CB}managed:enable:{nid}")])
        else:
            rows.append([InlineKeyboardButton("⛔ Disable",
                                              callback_data=f"{CONTROL_CB}managed:disable:{nid}")])
        rows.append([InlineKeyboardButton("🔑 Rotate Credential",
                                          callback_data=f"{CONTROL_CB}managed:rotate:{nid}")])
        rows.append([InlineKeyboardButton("🗑 Remove",
                                          callback_data=f"{CONTROL_CB}managed:remove:{nid}")])
        rows.append([InlineKeyboardButton("⬅️ Back",
                                          callback_data=f"{CONTROL_CB}managed:list")])
        kb = InlineKeyboardMarkup(rows)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    # ------------------------------------------------------------------
    # Health / Analytics / Credentials / Reconcile / Settings
    # ------------------------------------------------------------------
    async def _render_health(update: Update,
                             context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        snap = await _fdb_snap()
        bots = await db.list_network_bots()
        active = sum(1 for b in bots if str(b["status"]) == "ACTIVE")
        groups = await db.list_delivery_groups(only_ready=True)
        text = (
            "❤️ PLATFORM HEALTH\n\n"
            f"File Delivery Bot: {_fdb_status_line(snap)}\n"
            f"  Storage: {snap.get('storage_access') or 'unknown'}\n"
            f"  Last check: {snap.get('last_health_check') or '-'}\n\n"
            f"Network Bots: {len(bots)} total / {active} active\n"
            f"Delivery Channels ready: {len(groups)}\n"
            f"Delivery jobs: {await db.count_delivery_jobs()} total\n"
        )
        if snap.get("last_error"):
            text += f"\n⚠️ FDB last error: {str(snap['last_error'])[:140]}"
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "🔄 Refresh", callback_data=f"{CONTROL_CB}health")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{CONTROL_CB}main")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_analytics(update: Update,
                                context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        from app.storage.repositories.delivery import (
            JOB_CREATED, JOB_DELIVERED, JOB_DELETED, JOB_FAILED, JOB_EXPIRED)
        text = (
            "📊 DELIVERY ANALYTICS\n\n"
            f"Jobs total: {await db.count_delivery_jobs()}\n"
            f"Delivered: {await db.count_delivery_jobs(JOB_DELIVERED)}\n"
            f"Fully cleaned: {await db.count_delivery_jobs(JOB_DELETED)}\n"
            f"Failed: {await db.count_delivery_jobs(JOB_FAILED)}\n"
            f"Expired (TTL): {await db.count_delivery_jobs(JOB_EXPIRED)}\n"
            f"Groups ready: {await db.count_delivery_groups(True)}\n"
        )
        recent = await db.list_control_audit_events(limit=12)
        if recent:
            text += "\nRecent audit events:\n" + "\n".join(
                f"• {e['event']} ({e['created_at']})" for e in recent[:10])
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "⬅️ Back", callback_data=f"{CONTROL_CB}main")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_credentials(update: Update,
                                  context: ContextTypes.DEFAULT_TYPE
                                  ) -> None:
        """Safe key-configuration diagnostics (spec §3/§26 — booleans
        only, NEVER the secrets)."""
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        import os as _os
        _has_key = lambda name: bool(  # noqa: E731
            (_os.environ.get(name) or "").strip())
        snap = await _fdb_snap()
        text = (
            "🔑 CREDENTIALS & KEYS (diagnostics)\n\n"
            f"File Delivery Bot credential: "
            f"{'🔐 Protected (stored encrypted)' if snap.get('configured') else '⚠️ Not configured'}\n"
            f"NETWORK_TOKEN_ENCRYPTION_KEY: "
            f"{'✅ configured' if _has_key('NETWORK_TOKEN_ENCRYPTION_KEY') else '❌ missing (registrations refused)'}\n"
            f"NETWORK_GLOBAL_LINK_SIGNING_KEY: "
            f"{'✅ configured (minting enabled)' if _has_key('NETWORK_GLOBAL_LINK_SIGNING_KEY') else '❌ missing (minting refused, existing links keep verifying)'}\n"
            f"FILE_DELIVERY_BOT_TOKEN (env seed): "
            f"{'✅ set' if _has_key('FILE_DELIVERY_BOT_TOKEN') else '— not set (manage via this panel)'}\n"
            f"CONTROL_BOT_TOKEN: "
            f"{'✅ set' if _has_key('CONTROL_BOT_TOKEN') else '— not set (panel available in the main bot)'}\n\n"
            "Secrets are never displayed here. Generate persistent keys:\n"
            "python3 -c \"import secrets; print(secrets.token_urlsafe(48))\""
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "⬅️ Back", callback_data=f"{CONTROL_CB}main")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_reconcile(update: Update,
                                context: ContextTypes.DEFAULT_TYPE
                                ) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        await safe_answer_callback(q, "⏳ Reconciling...")
        if _fdb is None or _net_delivery_jobs is None:
            await safe_edit_text(
                q, "❌ Delivery subsystem unavailable — network service "
                   "init failed. Check the bot logs.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                    "⬅️ Back", callback_data=f"{CONTROL_CB}main")]]))
            return
        sweep = await _net_delivery_jobs.sweep_once()
        await db.insert_control_audit_event(
            "DELIVERY_RECONCILIATION",
            actor_user_id=int(update.effective_user.id),
            detail=f"channel_only sweep={sweep}")
        text = (
            "🔄 RECONCILIATION COMPLETE\n\n"
            "Delivery: Channel-Only (V25 §1) — storage channel → File "
            "Delivery Bot → user\n"
            "Delivery groups are deprecated; no group state is required "
            "or verified.\n"
            f"Job sweep: {sweep.get('ttl_deleted', 0)} TTL-cleaned / "
            f"{sweep.get('retried', 0)} retried / "
            f"{sweep.get('reconciled', 0)} reconciled"
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "⬅️ Back", callback_data=f"{CONTROL_CB}main")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_settings(update: Update,
                               context: ContextTypes.DEFAULT_TYPE
                               ) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        text = (
            "⚙️ DELIVERY SETTINGS\n\n"
            f"Relay TTL: {await db.get_setting_int(DELIVERY_SETTING_RELAY_TTL, DELIVERY_DEFAULT_RELAY_TTL)}s\n"
            f"Max attempts: {await db.get_setting_int(DELIVERY_SETTING_MAX_ATTEMPTS, DELIVERY_DEFAULT_MAX_ATTEMPTS)}\n"
            f"Retry base: {await db.get_setting_int(DELIVERY_SETTING_RETRY_BASE, DELIVERY_DEFAULT_RETRY_BASE)}s (exponential)\n"
            f"Sweep interval: {await db.get_setting_int(DELIVERY_SETTING_SWEEP_INTERVAL, DELIVERY_DEFAULT_SWEEP_INTERVAL)}s\n"
            f"Max bots per user: {await db.get_setting_int(NET_SETTING_MAX_BOTS, NET_DEFAULT_MAX_BOTS)}\n\n"
            "Configure via the admin settings panel (bot_settings)."
        )
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "📜 Audit trail", callback_data=f"{CONTROL_CB}audit")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{CONTROL_CB}main")]])
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    async def _render_audit(update: Update,
                            context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        events = await db.list_control_audit_events(limit=25)
        lines = ["📜 CONTROL AUDIT TRAIL\n"]
        if not events:
            lines.append("No events yet.")
        for e in events:
            lines.append(f"• {e['event']}  {e['created_at']}"
                         + (f"  (bot #{e['network_bot_id']})"
                            if e.get("network_bot_id") else ""))
        kb = InlineKeyboardMarkup([[InlineKeyboardButton(
            "🔄 Refresh", callback_data=f"{CONTROL_CB}audit")],
            [InlineKeyboardButton("⬅️ Back",
                                  callback_data=f"{CONTROL_CB}main")]])
        text = "\n".join(lines)
        if q:
            await safe_edit_text(q, text, reply_markup=kb)
        else:
            await safe_send_text(context.bot, update.effective_chat.id, text,
                                 reply_markup=kb)

    # ------------------------------------------------------------------
    # Dispatcher (ctl:<action>[:<arg>])
    # ------------------------------------------------------------------
    async def handle_control_callback(update: Update,
                                      context: ContextTypes.DEFAULT_TYPE,
                                      action: str) -> None:
        """Dispatch ctl:<action> — EVERY branch re-checks admin."""
        if not await _require_admin(update):
            return
        q = getattr(update, "callback_query", None)
        parts = action.split(":")
        cmd = parts[0] if parts else "main"
        arg = parts[1] if len(parts) > 1 else ""
        # Spec §31/§32: relay-plane ACTIONS need the live FDB subsystem.
        # When it could not start, answer honestly instead of crashing
        # (the read-only panels above still render NOT_CONFIGURED).
        if _fdb is None and (
                cmd == "fdb" or cmd == "reconcile" or
                (cmd == "managed" and (
                    (arg or "").startswith("rotate:") or
                    (arg or "").startswith("recon:"))) or
                cmd == "recon"):
            await safe_answer_callback(
                q, "❌ File Delivery subsystem unavailable — "
                   "network service init failed. Check the bot logs.",
                show_alert=True)
            return
        if cmd == "main":
            await render_control_panel(update, context)
        elif cmd == "fdb":
            sub = arg or "view"
            if sub == "view":
                await _render_fdb(update, context)
            elif sub == "add":
                await _fdb_token_input(update, context, change=False)
            elif sub == "change":
                await _fdb_token_input(update, context, change=True)
            elif sub == "validate":
                res = await _fdb.validate_current()
                await safe_answer_callback(
                    q, "✅ Token valid — bot is alive." if res.get("ok")
                    else f"❌ Validation failed: {res.get('reason')}",
                    show_alert=True)
            elif sub == "health":
                res = await _fdb.restart()
                await safe_answer_callback(
                    q, "✅ Health check passed." if res.get("ok")
                    else f"❌ Health failed: {res.get('reason')}",
                    show_alert=True)
                await _render_fdb(update, context)
            elif sub == "restart":
                res = await _fdb.restart()
                await safe_answer_callback(
                    q, "✅ File Delivery Bot restarted." if res.get("ok")
                    else f"❌ Restart failed: {res.get('reason')}",
                    show_alert=True)
                await _render_fdb(update, context)
            elif sub == "disable":
                await _fdb.disable(actor_user_id=int(
                    update.effective_user.id))
                await _render_fdb(update, context)
            elif sub == "enable":
                await db.update_file_delivery_bot(status=FDB_READY)
                res = await _fdb.restart()
                if not res.get("ok"):
                    await safe_answer_callback(
                        q, f"❌ Enable failed: {res.get('reason')}",
                        show_alert=True)
                await _render_fdb(update, context)
        elif cmd == "managed":
            # B11-E (test_bot11_keyboard_types catch): the buttons emit
            # ctl:managed:<sub>[:<nid>] — sub is the FULL remainder after
            # "managed:" (parts[1] alone dropped the nested action:
            # "managed:bot:5" produced sub="bot" and the bot-detail
            # button was a silent dead button).
            sub = ":".join(parts[1:]) or (arg or "view")
            # BOT-16 (stale-REMOVED guard — mirrors network_ui.py's
            # nbot: guard): a REMOVED managed bot is GONE — the PDF
            # page-2 evidence showed ctl:managed:enable flipping a
            # REMOVED row back to PENDING (destroying the terminal
            # state). Every mutating managed action on a removed row is
            # refused truthfully; a repeated remove is idempotent.
            _stale_prefixes = ("enable:", "disable:", "remove:",
                               "rotate:")
            if any(sub.startswith(_p) for _p in _stale_prefixes):
                try:
                    _gnid = int(sub.split(":")[1])
                except (IndexError, ValueError):
                    _gnid = 0
                if _gnid:
                    _grow = await db.get_network_bot(_gnid)
                    if _grow is not None and _is_removed_bot(_grow):
                        if sub.startswith("remove:"):
                            logger.info(
                                "MANAGED_BOT_REMOVE_IDEMPOTENT "
                                "network_bot_id=%s user_id=%s",
                                _gnid, int(update.effective_user.id))
                            await safe_answer_callback(
                                q, "Already removed.", show_alert=True)
                        else:
                            logger.info(
                                "MANAGED_BOT_STALE_CALLBACK "
                                "network_bot_id=%s action=%s user_id=%s",
                                _gnid, sub.split(":")[0],
                                int(update.effective_user.id))
                            await safe_answer_callback(
                                q, "This managed bot was removed. "
                                   "Re-register it to use it again.",
                                show_alert=True)
                        await _render_managed_list(update, context)
                        return
            if sub == "view":
                await _render_managed(update, context)
            elif sub == "list":
                await _render_managed_list(update, context)
            elif sub == "create":
                # v36 fail-fast: NEVER collect a bot token when the
                # platform cannot encrypt it — refuse entry to the wizard
                # with the honest operator action instead.
                if _net_registry is None or not getattr(
                        _net_registry, "can_encrypt_tokens", True):
                    await safe_answer_callback(
                        q, "❌ NETWORK_TOKEN_ENCRYPTION_KEY is not "
                           "configured — set it and restart, then retry. "
                           "No token was collected.", show_alert=True)
                    return
                clear_conversation_input_states(context)
                context.user_data[_CTL_CREATE_STATE_KEY] = \
                    stamp_conversation_state({"step": "await_owner"})
                await safe_edit_text(
                    q, "➕ CREATE MANAGED NETWORK BOT\n\n"
                       "Send the OWNER's Telegram user id first, then the "
                       "bot token.\n\n"
                       "❌ Cancel / ⬅️ Back anytime — the input ends when "
                       "you navigate away.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        "❌ Cancel",
                        callback_data=f"{CONTROL_CB}managed")]]))
            elif sub.startswith("bot:"):
                await _render_managed_bot(
                    update, context, int(sub.split(":")[1]))
            elif sub.startswith("health:"):
                nid = int(sub.split(":")[1])
                client = _net_workers.get_bot_client(nid)
                ok = False
                if client is not None:
                    try:
                        await client.get_me()
                        ok = True
                    except Exception:  # noqa: BLE001
                        ok = False
                await safe_answer_callback(
                    q, "✅ Bot alive." if ok else "⛔ Bot unreachable.",
                    show_alert=True)
            elif sub.startswith("recon:"):
                nid = int(sub.split(":")[1])
                # V25 §1: delivery groups are DEPRECATED — no group
                # re-verification runs in production; answer honestly.
                await safe_answer_callback(
                    q, "Delivery groups are deprecated (V25 §1 "
                       "channel-only) — no group verification applies.",
                    show_alert=True)
                await _render_managed_bot(update, context, nid)
            elif sub.startswith("disable:"):
                nid = int(sub.split(":")[1])
                await db.update_network_bot_status(
                    nid, "DISABLED", last_error_code="ADMIN_DISABLED")
                await _net_workers.stop_worker(nid)
                await db.insert_control_audit_event(
                    "MANAGED_NETWORK_BOT_DISABLED",
                    actor_user_id=int(update.effective_user.id),
                    network_bot_id=nid)
                await _render_managed_bot(update, context, nid)
            elif sub.startswith("enable:"):
                nid = int(sub.split(":")[1])
                await db.update_network_bot_status(nid, "PENDING")
                await _render_managed_bot(update, context, nid)
            elif sub.startswith("rotate:"):
                nid = int(sub.split(":")[1])
                context.user_data[_CTL_ROTATE_STATE_KEY] = \
                    stamp_conversation_state(
                        {"step": "await_token", "nid": nid})
                await safe_edit_text(
                    q, "🔑 ROTATE CREDENTIAL\n\n"
                       "Send the NEW token for this bot now.\n"
                       "The current credential stays active until the "
                       "new one validates.",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                        "❌ Cancel",
                        callback_data=f"{CONTROL_CB}managed:bot:{nid}")]]))
            elif sub.startswith("remove:"):
                nid = int(sub.split(":")[1])
                bot = await db.get_network_bot(nid)
                if not bot:
                    await safe_answer_callback(q, "Bot not found.",
                                              show_alert=True)
                    return
                # Remove = disable + revoke credential; history preserved.
                # BOT-16: the worker stop is passed INTO the registry
                # orchestrator (honest MANAGED_BOT_WORKER_STOPPED/
                # STOP_FAILED logs + every side-effect retired in one
                # place) and the audit event fires ONLY on a fresh
                # removal — an already-removed row answers idempotently
                # with no duplicate MANAGED_NETWORK_BOT_REMOVED.
                _stop_fn = ((lambda n: _net_workers.stop_worker(n))
                            if _net_workers is not None else None)
                rem = await _net_registry.remove_bot(nid,
                                                     stop_worker=_stop_fn)
                if not (isinstance(rem, dict) and rem.get("already")):
                    await db.insert_control_audit_event(
                        "MANAGED_NETWORK_BOT_REMOVED",
                        actor_user_id=int(update.effective_user.id),
                        network_bot_id=nid,
                        detail=f"username=@{bot.get('username')}")
                await safe_answer_callback(
                    q, "🗑 Managed bot removed (history preserved).",
                    show_alert=True)
                await _render_managed_list(update, context)
        elif cmd == "health":
            await _render_health(update, context)
        elif cmd == "analytics":
            await _render_analytics(update, context)
        elif cmd == "credentials":
            await _render_credentials(update, context)
        elif cmd == "reconcile":
            await _render_reconcile(update, context)
        elif cmd == "settings":
            await _render_settings(update, context)
        elif cmd == "audit":
            await _render_audit(update, context)

    # Owner-id input for managed create (numeric text).
    async def handle_control_owner_text(update: Update,
                                        context: ContextTypes.DEFAULT_TYPE,
                                        user, text: str) -> bool:
        state = context.user_data.get(_CTL_CREATE_STATE_KEY)
        if not state or str(state.get("step")) != "await_owner":
            return False
        if not (is_admin and await is_admin(int(user.id))):
            context.user_data.pop(_CTL_CREATE_STATE_KEY, None)
            return False
        t = (text or "").strip()
        if _conversation_state_expired(state):
            context.user_data.pop(_CTL_CREATE_STATE_KEY, None)
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "⌛️ The input timed out (10 min) — no bot was created. "
                "Start again from Managed Network Bots → Create.")
            return True
        if not t.isdigit():
            await safe_send_text(
                context.bot, update.effective_chat.id,
                "❌ Send the OWNER's numeric Telegram user id.")
            return True
        state["step"] = "await_token"
        state["owner"] = int(t)
        stamp_conversation_state(state)
        await safe_send_text(
            context.bot, update.effective_chat.id,
            "Now send the bot token (from @BotFather).")
        return True

    return SimpleNamespace(
        render_control_panel=render_control_panel,
        handle_control_callback=handle_control_callback,
        handle_control_text=handle_control_text,
        handle_control_owner_text=handle_control_owner_text,
    )
