"""Presentation layer (ARCHITECTURE PROPER BREAKDOWN).

Adapters that face the outside world:

* ``telegram/`` — the Telegram bot presentation package
  (handlers, panels, mini app, website admin, network UI)
* the Website payload platform presentation lives in
  ``app/web/site/`` (preserved existing structure)

Presentation depends DOWNWARD on application services
(``app/services``), domain rules (``app/core``) and ports;
it never owns business policy, SQL or composition.
"""
