"""Web layer: aiohttp Mini App server (auth, routes,
lifecycle)."""
