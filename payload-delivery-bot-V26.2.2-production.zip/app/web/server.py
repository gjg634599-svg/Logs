"""Mini App / Website HTTP server lifecycle (ARCHITECTURE DECOUPLING).

The aiohttp server construction previously embedded in bot.py's
``start_mini_app_server`` / ``stop_mini_app_server`` — extracted with the
same late-binding contract: all state and handler references resolve
through the legacy namespace ``ns`` at CALL TIME (patching
``B._mini_app_bot``, ``B._mini_app_runner``, ``B._wad_handle_*`` ...
keeps working unchanged).

The Watch Ads Mini App request handlers themselves (``_wad_*``) remain
in the legacy Telegram/handler layer — the server binds them via ``ns``
at start time. The Website presentation routes come from
``app.web.site`` with a deps factory bound to the container's
application-level composition (app/services/container.py).
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("payload-bot")

# Same guarded-optional-dependency pattern as the legacy bot.py import —
# the bot still runs without aiohttp (Watch Ads reports "temporarily
# unavailable"; no crash, no second process, no second application).
try:  # pragma: no cover - optional dependency
    from aiohttp import web as _aiohttp_web

    AIOHTTP_AVAILABLE = True  # noqa: F841 — parity with the legacy binding
except Exception:  # noqa: BLE001
    _aiohttp_web = None
    AIOHTTP_AVAILABLE = False  # noqa: F841


async def start_mini_app_server(bot: Any, ns: Any) -> bool:
    """Start the Mini App HTTP server INSIDE the bot's event loop.

    Same process, same database, same Access Engine — no second
    application. Returns True when the site is listening. Failure is
    logged loudly but never crashes the bot (Watch Ads then reports
    unavailable).

    Server state (``_mini_app_runner`` / ``_mini_app_site`` /
    ``_mini_app_bot``) lives on the legacy namespace.
    """
    if _aiohttp_web is None or not getattr(ns, "AIOHTTP_AVAILABLE", True):
        ns.logger.error(
            "Mini App HTTP server NOT started: aiohttp is not installed. "
            "Install requirements (pip install aiohttp) to enable the Watch "
            "Ads Mini App. The Telegram bot itself is unaffected.")
        return False
    ns._mini_app_bot = bot
    # MONETAG WEBSITE (WS-B — spec §19/§20/§21/§24-§28): the root-scope
    # provider service worker, the ad-tag head injection point and the
    # optional origin proxy secret guard. All are surgical: sw.js is
    # served VERBATIM (provider bytes), the ad tag injects NOTHING while
    # unconfigured, and the proxy guard stays OFF unless
    # ORIGIN_PROXY_SECRET is set (zero behavior change by default).
    from app.web import website_monetag as _wsite_monetag
    _db_getter = lambda: getattr(ns, "db", None)  # noqa: E731 — late binding
    middlewares = []
    _origin_guard = _wsite_monetag.make_origin_proxy_middleware()
    if _origin_guard is not None:
        middlewares.append(_origin_guard)
        ns.logger.info(
            "ORIGIN proxy secret check ENABLED (X-Origin-Key required — "
            "must match the Cloudflare worker's ORIGIN_PROXY_SECRET).")
    _ad_tag_mw = _wsite_monetag.make_website_monetag_middleware(_db_getter)
    if _ad_tag_mw is not None:
        middlewares.append(_ad_tag_mw)
    # BOT-26 §7 (production-fix brief): dynamic /site HTML cache hardening.
    # Registered LAST in the list => INNERMOST middleware: it decorates
    # the handler's response BEFORE the Monetag head-injection middleware
    # rebuilds it, so the rebuilt response carries these headers through
    # the header copy. Every per-request /site HTML page answers with
    # Cache-Control: no-store, no-cache, must-revalidate, max-age=0 (+
    # Pragma: no-cache, Expires: 0) so neither the Telegram WebView nor
    # the Cloudflare worker proxy nor any shared cache can keep serving a
    # stale shell. Static/media/API responses are NOT touched (the
    # middleware matches /site text/html 200s only).
    _site_cache_mw = _wsite_monetag.make_site_html_cache_middleware()
    if _site_cache_mw is not None:
        middlewares.append(_site_cache_mw)
    app = _aiohttp_web.Application(middlewares=middlewares)
    # MONETAG WEBSITE (spec §20): the provider service worker MUST answer
    # at the DOMAIN ROOT (https://<domain>/sw.js — root scope, NOT
    # /site/sw.js) so the website integration registers it site-wide. No
    # auth, exact provider bytes, Cache-Control: no-store (the Cloudflare
    # worker allowlist includes /sw.js — see cloudflare/worker.js).
    app.router.add_get("/sw.js", _wsite_monetag.handle_website_sw_js)
    # Admin diagnostics for the website monetization surface (spec §21):
    # reports configured / NOT CONFIGURED without leaking the raw tag.
    app.router.add_get(
        _wsite_monetag.MONETAG_STATUS_PATH,
        _wsite_monetag.make_monetag_status_handler(_db_getter))
    app.router.add_get("/watch-ad/{token}", ns._wad_handle_page)
    # NETWORK (N5, spec §49): Telegram WebApp initData HMAC-SHA256
    # validation endpoint — the network-compatible auth foundation for the
    # Mini App. NEVER trust bot_id/user_id/access state from the browser;
    # the authenticated identity comes ONLY from the verified initData
    # signature. (The full YouTube-style browsing UI remains documented
    # future scope — this is the minimum production-safe integration.)
    app.router.add_post("/api/network/auth", ns._net_handle_webapp_auth)
    app.router.add_post("/api/watch-ad/status", ns._wad_handle_status)
    app.router.add_post("/api/watch-ad/ad-event", ns._wad_handle_ad_event)
    app.router.add_get("/api/watch-ad/postback", ns._wad_handle_postback)
    app.router.add_get("/healthz", ns._wad_handle_health)
    # WEBSITE PHASE 3: the public Website Payload platform routes
    # (app/web/site) — ADDITIVE lines AFTER the pinned Watch Ads routes.
    # Presentation-layer only: every site handler checks the GLOBAL
    # website_enabled setting FIRST (maintenance page when OFF); the
    # Telegram-facing endpoints above are NEVER gated by it. Handlers are
    # None-safe (registration binds a lazy deps factory — never the bot
    # instance), so start_mini_app_server(None) keeps working for tests.
    from app.web.site import register_site_routes
    register_site_routes(app, ns._website_deps_factory)
    ns._mini_app_runner = _aiohttp_web.AppRunner(app)
    await ns._mini_app_runner.setup()
    ns._mini_app_site = _aiohttp_web.TCPSite(
        ns._mini_app_runner, "0.0.0.0", ns.MINI_APP_PORT)
    await ns._mini_app_site.start()
    # MONETAG WEBSITE startup diagnostics (spec §21): clearly report the
    # website ad-tag state — the provider tag is REQUIRED and must be
    # supplied from the Monetag account; until then nothing is injected.
    try:
        _diag = await _wsite_monetag.website_monetag_diagnostics(_db_getter)
        ns.logger.info(
            "MONETAG WEBSITE: sw.js=%s (%s bytes), %s",
            ("served" if _diag["service_worker"]["available"]
             else "MISSING") if _diag.get("enabled", True)
            else "DIAGNOSTIC NO-OP (surface disabled)",
            _diag["service_worker"]["bytes"],
            _diag["website_ad_tag"]["message"])
        if not _diag.get("enabled", True):
            ns.logger.warning(
                "MONETAG WEBSITE surface DISABLED (WEBSITE_MONETAG_ENABLED "
                "is false — diagnostic isolation: no ad tag injected, "
                "/sw.js serves the self-unregistering no-op worker). "
                "Re-enable by unsetting WEBSITE_MONETAG_ENABLED.")
    except Exception:  # noqa: BLE001 — diagnostics never block startup
        ns.logger.debug("monetag website diagnostics failed", exc_info=True)
    ns.logger.info(
        "WATCH_AD Mini App HTTP server started on port %s (same process). "
        "Routes: GET /watch-ad/<token>, POST /api/watch-ad/status, "
        "POST /api/watch-ad/ad-event (display-only lifecycle), "
        "GET /api/watch-ad/postback, GET /healthz, GET /sw.js (Monetag "
        "website service worker — root scope), "
        "GET /api/website/monetag-status. Put it behind an HTTPS "
        "reverse proxy and set Settings → Watch Ads → Mini App Website.",
        ns.MINI_APP_PORT,
    )
    return True


async def stop_mini_app_server(ns: Any) -> None:
    """Stop the Mini App HTTP server (post_shutdown)."""
    try:
        if getattr(ns, "_mini_app_runner", None) is not None:
            await ns._mini_app_runner.cleanup()
            ns.logger.info("WATCH_AD Mini App HTTP server stopped.")
    except Exception:  # noqa: BLE001
        ns.logger.debug("Mini App server cleanup error.", exc_info=True)
    ns._mini_app_runner = None
    ns._mini_app_site = None
    ns._mini_app_bot = None
