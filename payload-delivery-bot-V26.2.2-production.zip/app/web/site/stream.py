"""WEBSITE PHASE 4 — the stream endpoints (Media Gateway HTTP surface).

Route surface (registered on the EXISTING Mini App application, additive
lines inside app/web/site/pages.py:_register_routes):

  POST /site/api/stream        — stream-token issuance: verified Mini App
                                 initData + Phase 3 video ref + EXISTING
                                 Access Engine verdict -> short-lived
                                 stream token + playback metadata
  GET  /site/media/{token}     — the Media Gateway: HEAD / GET / Range /
                                 206 / 416 / bounded chunked streaming
  GET  /site/thumb/{token}     — bounded thumbnail bytes through the same
                                 gateway architecture (priority chain +
                                 honest placeholder fallback)

Layering (spec §1): these handlers ONLY translate HTTP ⇄ :class:`StreamPlan`
(web.application ⇄ app.media.gateway). They contain NO Telegram calls, NO
file_id recovery, NO transport logic — the gateway + Phase 1 stack own all
of that. Every handler checks the GLOBAL website_enabled setting FIRST
(maintenance when OFF — the same Phase 3 rule; Telegram is NEVER gated by
it), applies bounded rate limits, and fails closed on every error.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from app.web.site import ratelimit
from app.web.site.service import make_website_service

logger = logging.getLogger("payload-bot")

try:  # pragma: no cover — optional dependency, same as the rest of app/web
    from aiohttp import web as _aiohttp_web
except Exception:  # noqa: BLE001
    _aiohttp_web = None  # type: ignore[assignment]


# ---------------------------------------------------------------- routes
def register_stream_routes(app, deps_factory) -> bool:
    """Register the Phase 4 stream routes (additive; called from
    pages._register_routes — AFTER the Phase 3 routes).

    BOT-16: also registers the HLS transcoding surface
    (/site/hls/{token}/{path}) — app/web/site/hls.py."""
    if _aiohttp_web is None:  # pragma: no cover — aiohttp guaranteed there
        return False
    app.router.add_post("/site/api/stream", handle_site_api_stream)
    app.router.add_get("/site/media/{stream_token}",
                       handle_site_media)
    app.router.add_get("/site/thumb/{thumb_token}",
                       handle_site_thumb)
    try:
        from app.web.site.hls import register_hls_routes
        register_hls_routes(app, deps_factory)
    except Exception:  # noqa: BLE001 — HLS is additive, never fatal
        logger.warning("WEBSITE_HLS_ROUTE_REGISTER_FAILED (HLS playback "
                       "unavailable — transcoding surface not mounted)",
                       exc_info=True)
    return True


def _deps() -> Optional[Any]:
    from app.web.site.pages import _deps as _page_deps
    return _page_deps()


def _gateway(deps: Any) -> Optional[Any]:
    """The Media Gateway singleton from the request deps (bot.py wires the
    production stack/cache/gateway; tests bind their own)."""
    gw = getattr(deps, "media_gateway", None)
    if callable(gw) and not hasattr(gw, "handle_stream_request"):
        try:
            gw = gw()
        except Exception:  # noqa: BLE001 — fail closed
            logger.debug("media gateway construction failed", exc_info=True)
            return None
    return gw if hasattr(gw, "handle_stream_request") else None


def _client_ip(request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        first = fwd.split(",")[0].strip()
        if first:
            return first[:64]
    return str(request.remote or "unknown")[:64]


async def _website_on(deps: Any) -> bool:
    try:
        return await make_website_service(deps.db).website_enabled()
    except Exception:  # noqa: BLE001 — fail CLOSED (maintenance)
        logger.debug("website_enabled check failed — maintenance",
                     exc_info=True)
        return False


# ------------------------------------------------- V26 Phase 6 anti-leech
async def _anti_leech_active(deps: Any) -> bool:
    """V26 Phase 6 — the Protection Center's 🕮 Anti-Leech toggle is
    AUTHENTIC: when ON, the streaming surfaces (/site/media, /site/hls,
    /site/thumb) reject requests whose Referer/Origin belongs to a
    DIFFERENT host (the classic hotlink shape: a foreign site embedding
    our media URLs). Same-site referers and no-referer clients (the
    site's own <video> element, players, download managers) always pass.
    Fails OPEN on a settings-read error (availability over the
    convenience gate — the token auth + rate limits remain enforced
    regardless)."""
    try:
        return await deps.db.get_setting_bool("prot_v3_anti_leech", True)
    except Exception:  # noqa: BLE001 — fail open (see docstring)
        logger.debug("anti_leech setting read failed — fail open",
                     exc_info=True)
        return False


# V26 FINAL (bot-39 root cause #1): the EFFECTIVE PUBLIC HOST set. The
# production deployment runs the origin aiohttp server BEHIND the
# Cloudflare Worker (cloudflare/worker.js), so ``request.host`` is the
# INTERNAL backend host (e.g. 127.0.0.1:25672) while the browser's
# legitimate Referer is the PUBLIC Worker host (bot-39.log:
# ``WEBSITE_ANTI_LEECH_BLOCKED surface=media`` for a
# ``shy-leaf-cac1...workers.dev`` referer -> HTTP 403 ->
# ``PLAYER_STREAM_ERROR error_code=4`` -> "Cannot play in this
# browser"). The old predicate compared the referer host against
# request.host ONLY, so EVERY legitimate proxied media request was a
# false-positive hotlink.
#
# The secure fix: the same-site host set is the union of
#   1. the configured ``website_public_base_url`` host (the admin's
#      explicit statement of the public site origin — the same setting
#      the issued stream URLs are built from), plus
#   2. any explicitly configured ``website_trusted_public_hosts``
#      (comma-separated public proxy hosts the deployment identified as
#      trusted), plus
#   3. ``request.host`` (the direct, non-proxied deployment case).
#
# Client-supplied ``X-Forwarded-Host`` / ``Host`` / ``Origin`` /
# ``Referer`` are NEVER trusted as allowlist sources — a client can
# forge all four. Only the two DB-configured sources (1)/(2) extend the
# set beyond the request's own transport host.
WEBSITE_TRUSTED_PUBLIC_HOSTS_KEY = "website_trusted_public_hosts"


def _host_of(value: str) -> str:
    """Extract a lowercase hostname from a URL-ish or bare-host string
    (port-insensitive: proxies forward Host without the public port
    while the browser Referer keeps it)."""
    from urllib.parse import urlparse
    raw = str(value or "").strip().lower()
    if not raw:
        return ""
    try:
        parsed = urlparse(raw if "://" in raw else f"https://{raw}")
        host = (parsed.hostname or "").lower()
    except Exception:  # noqa: BLE001 — unparseable → empty
        return ""
    return host


async def _effective_public_hosts(deps: Any) -> frozenset:
    """The configured public-host allowlist (sources 1+2; the request's
    own transport host is added per-request by the predicate)."""
    hosts = set()
    try:
        base = await make_website_service(
            deps.db).website_public_base_url()
        h = _host_of(base)
        if h:
            hosts.add(h)
    except Exception:  # noqa: BLE001 — availability over the gate
        logger.debug("public base url read failed", exc_info=True)
    try:
        raw = str(await deps.db.get_setting(
            WEBSITE_TRUSTED_PUBLIC_HOSTS_KEY, "") or "")
        for part in raw.split(","):
            h = _host_of(part)
            if h:
                hosts.add(h)
    except Exception:  # noqa: BLE001 — availability over the gate
        logger.debug("trusted public hosts read failed", exc_info=True)
    return frozenset(hosts)


def _referer_allowed(request, extra_hosts=None) -> bool:
    """The anti-hotlink predicate: a request passes when it carries NO
    referer/origin (a direct player fetch) or one whose host matches the
    request's own transport host OR one of the deployment's configured
    public hosts (``extra_hosts`` — the proxy-aware V26 FINAL fix); a
    referer from any other host is a hotlink."""
    from urllib.parse import urlparse
    allowed = set(extra_hosts or ())
    try:
        own = str(request.host or "").lower().split(":")[0]
    except Exception:  # noqa: BLE001
        own = ""
    if own:
        allowed.add(own)
    for header in ("Referer", "Origin"):
        val = (request.headers.get(header) or "").strip()
        if not val:
            continue
        try:
            host = (urlparse(val).hostname or "").lower()
        except Exception:  # noqa: BLE001 — unparseable header → allow
            continue
        if not host:
            continue
        if allowed and host not in allowed:
            return False
    return True


def _anti_leech_blocked(request, extra_hosts=None) -> bool:
    """TRUE when the anti-leek rule blocks THIS request (used with
    _anti_leech_active; kept separate for testability)."""
    return not _referer_allowed(request, extra_hosts)


async def _anti_leech_decision(request, deps: Any) -> Dict[str, Any]:
    """The SINGLE proxy-aware anti-leech decision used by ALL THREE
    streaming surfaces. Returns ``{"allowed": bool, "reason": str,
    ...safe diagnostics}``. The decision is FAIL-OPEN on configuration
    read errors (the token auth + Access Engine re-verification on
    every request remain the authoritative security — anti-leech is a
    convenience gate, never the authorization)."""
    from urllib.parse import urlparse
    referer = (request.headers.get("Referer") or "").strip()
    origin = (request.headers.get("Origin") or "").strip()
    try:
        referer_host = (urlparse(referer).hostname or "").lower() \
            if referer else ""
    except Exception:  # noqa: BLE001
        referer_host = ""
    try:
        origin_host = (urlparse(origin).hostname or "").lower() \
            if origin else ""
    except Exception:  # noqa: BLE001
        origin_host = ""
    try:
        request_host = str(request.host or "").lower().split(":")[0]
    except Exception:  # noqa: BLE001
        request_host = ""
    extra = await _effective_public_hosts(deps)
    effective_public_host = sorted(extra)[0] if extra else request_host
    allowed = _referer_allowed(request, extra)
    if allowed:
        reason = "same_site" if (referer_host or origin_host) else \
            "no_referer"
    else:
        reason = "foreign_referer" if referer_host else "foreign_origin"
    return {
        "allowed": allowed,
        "reason": reason,
        "effective_public_host": effective_public_host,
        "referer_host": referer_host,
        "origin_host": origin_host,
        "request_host": request_host,
    }


def _log_anti_leech(surface: str, decision: Dict[str, Any],
                    blocked: bool) -> None:
    """Emit WEBSITE_ANTI_LEECH_ALLOWED / _BLOCKED with ONLY the safe
    diagnostic fields (never tokens, initData, credentials or secrets).
    ALLOWED is emitted for referer/origin-bearing requests (the
    interesting same-site-embedding case); the plain no-referer player
    fetch stays unlogged to keep segment traffic quiet."""
    if not blocked and not (decision.get("referer_host")
                            or decision.get("origin_host")):
        return
    logger.log(
        logging.WARNING if blocked else logging.INFO,
        "WEBSITE_ANTI_LEECH_%s surface=%s effective_public_host=%s "
        "referer_host=%s origin_host=%s request_host=%s reason=%s",
        "BLOCKED" if blocked else "ALLOWED",
        surface,
        decision.get("effective_public_host") or "-",
        decision.get("referer_host") or "-",
        decision.get("origin_host") or "-",
        decision.get("request_host") or "-",
        decision.get("reason") or "-")


def _maintenance_json():
    return _aiohttp_web.json_response(
        {"ok": False, "error": "maintenance",
         "message": "Website is temporarily switched off."},
        status=503)


async def _token_user_if_mismatched(request, deps: Any, token: str):
    """V26 FINAL (Part 14 — cross-user replay guard).

    Returns ``None`` when the request may proceed (no session cookie,
    an unparseable/expired one, or a session whose user MATCHES the
    token's embedded user). Returns ``(session_uid, token_uid)`` when a
    VALID site session proves the caller is a DIFFERENT user than the
    one the stream token was minted for — the cross-user replay shape
    (user B pasting user A's playback link into user B's logged-in
    browser). Never raises; never trusts the client beyond the signed
    AEAD token + the signed AEAD session cookie (both server-issued)."""
    try:
        from app.web.site.pages import _session_of
        session = await _session_of(request, deps)
        if session is None:
            return None
        session_uid = int(session.get("user_id") or 0)
        if not session_uid:
            return None
        from app.media.streamtokens import make_stream_token_codec
        codec = make_stream_token_codec(getattr(deps, "bot_token", None))
        decoded = codec.decode_stream_token(str(token or ""))
        if decoded is None:
            return None  # the gateway answers bad tokens itself (401)
        token_uid = int(decoded.get("user_id") or 0)
        if token_uid and session_uid != token_uid:
            return (session_uid, token_uid)
    except Exception:  # noqa: BLE001 — the guard never blocks playback
        logger.debug("wrong-user session cross-check failed", exc_info=True)
    return None


# ------------------------------------------------------ 18+ age gate (§22)
async def _listing_age_restricted(deps: Any, listing_opaque: str) -> bool:
    """B10-W2 (spec §22): TRUE when the listing belongs to ANY
    age-restricted category — the SAME backend predicate the feed/search/
    collections SQL and pages.py enforce (website_payload_categories ⋈
    website_categories.age_restricted = 1). Fails CLOSED (True) on any
    lookup failure."""
    try:
        detail = await make_website_service(deps.db).get_listing_detail(
            str(listing_opaque or ""))
    except Exception:  # noqa: BLE001 — fail CLOSED
        logger.debug("age-restriction lookup failed listing=%s",
                     listing_opaque, exc_info=True)
        return True
    if not detail:
        return True  # unresolvable listing — not_found anyway
    try:
        cats = await deps.db.list_website_categories_for_listing(
            int((detail.get("listing") or {}).get("id") or 0))
    except Exception:  # noqa: BLE001 — fail CLOSED
        return True
    try:
        return any(int(c["age_restricted"]) for c in cats or [])
    except Exception:  # noqa: BLE001 — fail CLOSED
        return True


async def _session_age_confirmed(request, deps: Any, uid: Optional[int]
                                ) -> bool:
    """TRUE when the EXISTING site session (the ONLY age_ok source — spec
    §20) carries age_ok=true AND belongs to the same identity the caller
    verified (``uid``: the initData-verified user for the stream/access
    APIs — user A's confirmation never opens user B's gate; None for the
    public thumb surface, where the session itself is the whole identity).
    Never a second cookie system, never a client claim."""
    from app.web.site.pages import _session_of
    try:
        session = await _session_of(request, deps)
    except Exception:  # noqa: BLE001 — fail CLOSED
        return False
    if session is None:
        return False
    if uid is not None and int(session.get("user_id") or 0) != int(uid):
        return False
    return bool(session.get("age_ok"))


def _thumb_placeholder_response():
    """The honest age-gated placeholder for restricted listing artwork
    (B10-W2 spec §22): NEUTRAL art — never the restricted thumbnail
    bytes. Same visual family as the gateway's own placeholder."""
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" '
        'viewBox="0 0 640 360" role="img" aria-label="Restricted artwork">'
        '<rect width="640" height="360" fill="#0a121f"/>'
        '<text x="320" y="196" font-family="system-ui,sans-serif" '
        'font-size="64" text-anchor="middle">\U0001F51E</text></svg>')
    return _aiohttp_web.Response(
        body=svg.encode("utf-8"),
        headers={"Content-Type": "image/svg+xml; charset=utf-8",
                 "Cache-Control": "no-store"},
        status=200)


# ------------------------------------------------------ listing resolver
def make_listing_resolver(db: Any):
    """The gateway's canonical-target resolver: (listing opaque id,
    file_pk) -> target dict through the EXISTING Website Payload system
    (published check + ordered-files membership). file_pk==0 is the
    LISTING-level resolution (public thumbnail art). Returns None for
    unpublished/dead/mismatched targets — the gateway answers 404."""

    async def resolver(listing_opaque: str, file_pk: int
                       ) -> Optional[Dict[str, Any]]:
        svc = make_website_service(db)
        try:
            detail = await svc.get_listing_detail(str(listing_opaque or ""))
        except Exception:  # noqa: BLE001
            # PHASE 5 observability: an honest missing listing returns None
            # silently below; a LOOKUP FAILURE (DB down) is an outage signal
            # and must be visible at the default log level.
            logger.warning("WEBSITE_RESOLVE_ERROR listing=%s file_pk=%s "
                           "(answered as not-found — lookup failed)",
                           listing_opaque, file_pk, exc_info=True)
            return None
        if not detail:
            return None
        listing = detail.get("listing") or {}
        if not int(listing.get("published") or 0):
            return None  # unpublished listings are invisible to streams
        canonical = detail.get("canonical") or {}
        payload_id = (int(canonical["payload_id"])
                      if canonical.get("kind") == "payload" else None)
        files = detail.get("files") or []
        base = {
            "payload_id": payload_id,
            "listing_thumb_file_unique_id": listing.get("thumb_file_unique_id"),
            "listing_thumb_file_id": listing.get("thumb_file_id"),
        }
        if int(file_pk or 0) > 0:
            match = None
            for f in files:
                if int(f.get("file_pk") or 0) == int(file_pk):
                    match = f
                    break
            if match is None:
                return None  # file no longer in the payload — honest 404
            parent_row = None
            if match.get("file_unique_id"):
                try:
                    parent_row = await db.get_indexed_file_by_unique_id(
                        str(match["file_unique_id"]))
                except Exception:  # noqa: BLE001
                    parent_row = None
            return dict(base,
                        file_unique_id=match.get("file_unique_id"),
                        file_size=match.get("file_size"),
                        file_name=match.get("file_name"),
                        # V26.2 (bot-41 §9-§11): the PACKAGE child's
                        # user-facing label (subordinate "Video n"); the
                        # raw original filename stays in file_name for the
                        # server-side content-type sniffing and internal
                        # diagnostics, but the CLIENT rendering prefers
                        # display_name for package children.
                        display_name=match.get("display_label"),
                        mime_type=match.get("mime_type"),
                        media_type=match.get("media_type"),
                        parent_row=parent_row)
        # listing-level (thumbnail art): the primary file's row
        first = files[0] if files else None
        parent_row = None
        if first and first.get("file_unique_id"):
            try:
                parent_row = await db.get_indexed_file_by_unique_id(
                    str(first["file_unique_id"]))
            except Exception:  # noqa: BLE001
                parent_row = None
        return dict(base, file_unique_id=None, file_size=None,
                    mime_type=None, media_type=None,
                    parent_row=parent_row)

    return resolver


# ------------------------------------------------------ plan -> response
_CLIENT_GONE = tuple()
try:  # aiohttp client-disconnect exception shapes (lazy, optional)
    import asyncio as _aio

    async def _raise_client_gone():  # pragma: no cover — shape probe
        raise ConnectionResetError()

    _CLIENT_GONE = (ConnectionResetError, _aio.CancelledError)
    try:
        from aiohttp import ClientConnectionResetError as _AReset
        _CLIENT_GONE = _CLIENT_GONE + (_AReset,)
    except Exception:  # noqa: BLE001
        pass
    try:
        from aiohttp import ServerTimeoutError as _STimeout
        _CLIENT_GONE = _CLIENT_GONE + (_STimeout,)
    except Exception:  # noqa: BLE001
        pass
except Exception:  # noqa: BLE001
    pass


class _ClientGoneSignal(Exception):
    """INTERNAL control-flow marker: the HTTP client disconnected
    mid-write (v37 bot-8 A9 classification — a quiet disconnect: the
    stream-cache state is preserved and the dead connection is
    force-closed; never an upstream failure, never a 500)."""


# The write-time disconnect shapes (converted to _ClientGoneSignal in
# the write paths below). aiohttp raises ConnectionResetError for a
# lost server peer, but the bot-8 log evidence (A9) shows a BARE
# ConnectionError reaching this path — the PARENT class is included so
# every client-side disconnect shape (Reset/Aborted/Shutdown/bare) is
# classified as a quiet disconnect; CancelledError during a write is
# caught by _CLIENT_GONE directly.
_WRITE_GONE: tuple = (ConnectionError,)


def _media_error_response(exc: BaseException):
    """v35 truthful media error mapping (spec §7): a preflight upstream
    failure becomes a machine-readable JSON state — never a truncated 206,
    never a one-size "stream ended or expired".

    States surfaced (frontend mirrors these in the video page):
      AUTH class            → never mapped here (token checks precede)
      media_not_found       → 404  (the media no longer exists upstream)
      media_upstream_error  → 503  retryable=true (Telegram-side failure,
                                   stale file_id beyond repair, flood)
      too_large_for_transport → 503 (mid-stream cap hit — rare)
      range_not_satisfiable → 416
      anything else         → 503  media_upstream_error (honest generic,
                                   still retryable + Telegram fallback)
    """
    web = _aiohttp_web
    from app.media.errors import (
        MediaNotFoundError,
        MediaRecoveryFailedError,
        MediaSourceUnavailableError,
        MediaTooLargeError,
        RangeNotSatisfiableError,
    )
    reason = str(getattr(exc, "reason", "") or type(exc).__name__)
    if isinstance(exc, MediaNotFoundError):
        return web.json_response(
            {"ok": False, "error": "media_not_found",
             "reason": reason,
             "message": "This file is no longer available from Telegram. "
                        "Use the Telegram fallback to receive it."},
            status=404)
    if isinstance(exc, RangeNotSatisfiableError):
        return web.json_response(
            {"ok": False, "error": "range_not_satisfiable", "reason": reason,
             "message": "The requested byte range is outside this file."},
            status=416)
    if isinstance(exc, MediaTooLargeError):
        return web.json_response(
            {"ok": False, "error": "too_large_for_transport",
             "reason": reason,
             "message": "This file exceeds the cloud Bot API download "
                        "limit — receive it in Telegram instead."},
            status=503)
    if isinstance(exc, (MediaRecoveryFailedError,
                        MediaSourceUnavailableError)):
        # B17 — Retry-After so the player (and any CDN/Worker in front)
        # backs off politely instead of hammering an upstream that is
        # mid-download on a huge file (bot-18.log: immediate re-requests
        # while the local Bot API was still fetching 856 MB).
        return web.json_response(
            {"ok": False, "error": "media_upstream_error",
             "reason": reason, "retryable": True,
             "message": "Telegram could not serve this file right now. "
                        "Retry the stream or receive it in Telegram."},
            status=503, headers={"Retry-After": "5"})
    return web.json_response(
        {"ok": False, "error": "media_upstream_error",
         "reason": reason, "retryable": True,
         "message": "The media stream failed to start. "
                    "Retry, or receive this file in Telegram."},
        status=503, headers={"Retry-After": "5"})


async def _plan_to_response(request, plan):
    """Convert a gateway :class:`StreamPlan` into an aiohttp response.

    Errors are honest JSON bodies (never stack traces). Bodies stream in
    bounded chunks; a client disconnect closes the plan body quietly (the
    gateway/cache release their resources through the iterators' finally
    blocks — active-reader counts and concurrency slots always unwind).

    PHASE 5: ``resp.prepare()`` is INSIDE the try/finally and the plan's
    idempotent ``release`` is invoked in the finally — a client that
    vanishes before the body generator is ever iterated (prepare raises /
    handler cancelled pre-iteration) still releases the gateway
    concurrency slot. Without this, each such request permanently
    consumed one of the bounded slots (429 lockout after ~32 cycles).

    PRODUCTION BUG FIX v35 (spec §6/§7 — the small-file "Stream ended
    or expired" incident): the FIRST upstream chunk is pulled BEFORE
    ``prepare()``. A deterministic upstream failure that happens before
    any byte exists (stale file_id beyond repair, upstream gone,
    upstream unavailable) then surfaces as an honest JSON error response
    with a machine-readable code — NEVER as a truncated 206 that the
    browser reports as a mystery "stream ended" (the old behavior: 253
    bytes sent, connection reset, user told their authorization
    expired). The buffered chunk is written first once the stream
    starts."""
    web = _aiohttp_web
    headers = {k: v for k, v in (plan.headers or {}).items()}
    content_length = headers.pop("Content-Length", None)
    if plan.body is None:
        # HEAD (headers only — aiohttp suppresses bodies for HEAD) or a
        # header-only plan.
        resp = web.StreamResponse(status=plan.status, headers=headers)
        if content_length is not None:
            try:
                resp.content_length = int(content_length)
            except ValueError:
                pass
        return resp
    # ---- v35 first-chunk pull: preflight the upstream BEFORE the status
    # line is committed (only for streaming media plans — JSON error
    # plans use the single-shot path below and never touch Telegram).
    first_chunk = None
    if not getattr(plan, "is_json_error", False):
        try:
            first_chunk = await plan.body.__anext__()
        except StopAsyncIteration:
            first_chunk = b""  # empty body — stream it honestly
        except Exception as e:  # noqa: BLE001 — honest preflight failure
            logger.warning("STREAM_PREFLIGHT_FAIL reason=%s strategy=%s",
                           type(e).__name__, plan.strategy)
            try:
                await plan.body.aclose()
            except Exception:  # noqa: BLE001
                pass
            release = getattr(plan, "release", None)
            if callable(release):
                try:
                    release()
                except Exception:  # noqa: BLE001
                    pass
            return _media_error_response(e)
    resp = web.StreamResponse(status=plan.status, headers=headers)
    if content_length is not None:
        try:
            resp.content_length = int(content_length)
        except ValueError:
            pass
    release = getattr(plan, "release", None)
    sent = 0
    try:
        await resp.prepare(request)
        if first_chunk:
            sent += len(first_chunk)
            try:
                await resp.write(first_chunk)
            except _WRITE_GONE as wg:
                # v37 (bot-8 A9): the CLIENT vanished mid-write — a normal
                # browser event (tab closed / seek aborted), classified as
                # a quiet disconnect, never an upstream failure.
                raise _ClientGoneSignal() from wg
        elif first_chunk == b"" and plan.body is not None \
                and not getattr(plan, "is_json_error", False):
            pass  # zero-byte upstream body: fall through to write_eof
        async for chunk in plan.body:
            sent += len(chunk)
            try:
                await resp.write(chunk)
            except _WRITE_GONE as wg:
                # v37 (bot-8 A9): same client-gone classification for the
                # streaming writes.
                raise _ClientGoneSignal() from wg
        await resp.write_eof()
        logger.info("STREAM_HTTP_COMPLETE status=%s bytes=%s strategy=%s",
                    plan.status, sent, plan.strategy)
    except (_ClientGoneSignal,) + tuple(_CLIENT_GONE):
        # Client disconnected mid-stream: release the plan body quietly.
        logger.info("STREAM_CLIENT_DISCONNECT bytes=%s strategy=%s "
                    "phase=write (client gone — normal, cache state "
                    "preserved)", sent, plan.strategy)
        try:
            await plan.body.aclose()
        except Exception:  # noqa: BLE001 — best effort
            pass
        resp.force_close()  # dead peer — never reuse the connection
    except Exception as e:  # noqa: BLE001 — honest abort, never a leak
        logger.warning("STREAM_HTTP_ABORT reason=%s strategy=%s phase=body "
                       "bytes=%s (upstream body ended early — transport "
                       "closed so the client sees an honest truncation)",
                       type(e).__name__, plan.strategy, sent)
        try:
            await plan.body.aclose()
        except Exception:  # noqa: BLE001
            pass
        # The body ended EARLY (upstream failure): close the transport so
        # the client sees a truncated response instead of waiting for the
        # promised Content-Length forever (honest abort, prompt signal).
        resp.force_close()
    finally:
        try:
            await plan.body.aclose()
        except Exception:  # noqa: BLE001 — idempotent no-op when exhausted
            pass
        if callable(release):
            # Exactly-once (idempotent in the gateway): covers the
            # never-iterated body case — the generator's finally never
            # runs when aclose() is called on a generator that never
            # started, so the slot must ALSO be released here.
            try:
                release()
            except Exception:  # noqa: BLE001 — never fail the response
                pass
    return resp


# ------------------------------------------------------------- handlers
async def handle_site_api_stream(request):
    """POST /site/api/stream — stream-token issuance (spec §2 flow):

    verified initData -> canonical Payload/video -> EXISTING Access Engine
    -> authorized -> short-lived stream token + playback metadata."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_stream_issue", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    gateway = _gateway(deps)
    if gateway is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "streaming_unavailable",
             "message": "The media gateway is not available (transport "
                        "not configured)."}, status=503)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")[:8192]
    video_ref = str((body or {}).get("video_ref") or "")[:2048]
    if not init_data or not video_ref:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    # 1. Mini App identity (server-side multi-token validation).
    from app.web.site.auth import make_multi_token_web_auth
    from app.web.site.pages import _make_single_validator
    multi_auth = make_multi_token_web_auth(
        getattr(deps, "bot_token", None),
        getattr(deps, "network_tokens", None),
        validate_with_token=_make_single_validator(deps))
    verified = await multi_auth.validate_init_data(init_data)
    if verified is None:
        logger.info("WEBSITE_AUTH_REJECTED (stream issuance)")
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    uid = int(verified.get("user_id") or 0)
    if uid <= 0:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    # 2. Canonical Payload/video resolution (the Phase 3 video ref).
    from app.web.site.tokens import make_video_token_codec
    codec = make_video_token_codec(getattr(deps, "bot_token", None))
    decoded = codec.decode_video_ref(video_ref)
    if decoded is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "invalid_video_ref"}, status=400)
    listing_opaque = str(decoded.get("listing") or "")
    file_pk = int(decoded.get("file_pk") or 0)
    rl = getattr(gateway, "listing_resolver", None)
    target = None
    if callable(rl):
        try:
            target = await rl(listing_opaque, file_pk)
        except Exception:  # noqa: BLE001
            target = None
    if target is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # B10-W2 (spec §22 — API bypass guard): stream-token ISSUANCE for an
    # age-restricted listing requires the 18+ confirmation in the EXISTING
    # site session (same identity as the initData-verified user — user A's
    # confirmation never opens user B's gate). Unconfirmed -> the SAME
    # honest 404 shape an unresolvable target produces (no existence
    # leak); the Access Engine verdict below still runs for everything
    # else (FJ etc. — never bypassed, §25).
    if not await _session_age_confirmed(request, deps, uid) \
            and await _listing_age_restricted(deps, listing_opaque):
        logger.info("WEBSITE_STREAM_ISSUE_AGE_DENIED user_id=%s listing=%s "
                    "(18+ unconfirmed)", uid, listing_opaque)
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # 3. EXISTING Access Engine verdict (never a second engine) through
    # the website-playback authorization chokepoint (B23/P0-1,
    # app/web/site/authz.py): every denial reason stays enforced EXCEPT
    # "watch_ad_required" — the TELEGRAM payload Watch-Ad gate does NOT
    # gate website playback (bot-23.log 01:11:15/01:11:26: a real user
    # with Force Join satisfied was still denied). The waiver is safe for
    # Force Join: the engine only emits watch_ad_required AFTER the base
    # policy (FJ included) authorized. The website pre-roll ad system
    # stays fully independent and fires per its own configuration.
    # GAP-CLOSURE: pass the LIVE bot so Force-Join membership checks run
    # server-side (bot=None failed CLOSED for every non-admin user —
    # the website FJ bug). The bot ref is late-bound through deps.
    payload_id = target.get("payload_id")
    _bot_ref = getattr(deps, "bot_ref", None)
    _bot = _bot_ref() if callable(_bot_ref) else None
    from app.web.site.authz import authorize_website_playback
    try:
        verdict = await authorize_website_playback(
            deps, _bot, uid, payload_id=payload_id,
            gate_key=f"w|{listing_opaque}|{int(file_pk or 0)}")
    except Exception as engine_exc:  # noqa: BLE001 — TASK A2 telemetry
        # The bot-42 production 500 was exactly here: a NameError from the
        # engine, masked at DEBUG level. The safe ERROR telemetry makes the
        # exception class + failure stage visible in production logs.
        from app.web.site.authz import log_website_engine_failure
        log_website_engine_failure(
            "stream_issuance", engine_exc, user_id=uid,
            payload_id=payload_id, file_pk=file_pk,
            gate_key=f"w|{listing_opaque}|{int(file_pk or 0)}")
        return _aiohttp_web.json_response(
            {"ok": False, "error": "engine_error"}, status=500)
    res = verdict.result
    if not verdict.authorized:
        logger.info("WEBSITE_STREAM_ISSUE_DENIED user_id=%s payload_id=%s "
                    "reason=%s", uid, payload_id, verdict.reason)
        from app.web.site.pages import (_REQUIREMENT_TEXT,
                                        _fj_channel_views,
                                        _fj_health_summary)
        requirement = _REQUIREMENT_TEXT.get(
            str(verdict.reason or ""),
            "Complete the access requirement in the bot, then reload.")
        denial: Dict[str, Any] = {
            "ok": True, "authorized": False,
            "reason": verdict.reason,
            "requirement": requirement}
        # BOT-16 (website force-join): a force_join_required denial
        # carries the SAME channel views + health summary the page-level
        # gate and /site/api/access expose — the player renders the
        # in-place Join Required UI (Join buttons + Verify Membership)
        # from this data and NEVER redirects the user to the bot.
        if verdict.reason == "force_join_required" \
                and getattr(res, "not_joined", None):
            try:
                denial["not_joined"] = _fj_channel_views(res.not_joined)
                denial["verify_hint"] = ("Join the required channel(s), "
                                         "then tap Verify Membership.")
                denial.update(await _fj_health_summary(deps))
            except Exception:  # noqa: BLE001 — views are best-effort
                logger.debug("FJ denial views failed", exc_info=True)
        return _aiohttp_web.json_response(denial, status=200)
    # 4. Live settings + mint the short-lived stream token.
    settings = await gateway.read_settings()
    if not settings.get("stream_enabled"):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "streaming_disabled",
             "message": "Website streaming is currently switched off."},
            status=503)
    ttl = int(settings.get("token_ttl") or 300)
    token = gateway.issue_stream_token(uid, listing_opaque, file_pk,
                                       ttl_seconds=ttl)
    svc = make_website_service(deps.db)
    stream_url = svc.build_site_url(
        f"site/media/{token}", await svc.website_public_base_url())
    # GAP-CLOSURE spec §17: the §17 priority (media_type → Telegram
    # metadata → MIME → extension) — a KNOWN video with a generic
    # application/octet-stream MIME is still streamable; the old logic
    # let the generic MIME veto it ("Not streamable" bug).
    from app.media.mime import effective_content_type, is_streamable_media
    media_type = str(target.get("media_type") or "").lower()
    mime = str(target.get("mime_type") or "").lower()
    streamable = is_streamable_media(media_type, mime)
    content_type = effective_content_type(media_type, mime,
                                          target.get("file_name"))
    # GAP-CLOSURE (spec §11): the CONTROLLED "Local Bot API required"
    # state — the SAME authoritative MediaTransportSelector decision the
    # media request would take, surfaced at ISSUANCE time so the player
    # shows the honest verdict instead of mounting a doomed <video> that
    # dies with a generic "stream ended" error.
    too_large_info = None
    feasibility = getattr(gateway, "transport_feasibility", None)
    if callable(feasibility) and streamable:
        try:
            too_large_info = await feasibility(target.get("file_size"))
        except Exception:  # noqa: BLE001 — never block issuance
            too_large_info = None
    if too_large_info and too_large_info.get("too_large"):
        logger.info(
            "WEBSITE_STREAM_ISSUE_TOO_LARGE user_id=%s file_pk=%s size=%s "
            "limit=%s local_state=%s", uid, file_pk,
            target.get("file_size"), too_large_info.get("limit"),
            too_large_info.get("local_state"))
        return _aiohttp_web.json_response({
            "ok": True,
            "authorized": True,
            "streamable": False,
            "unavailable_reason": "too_large_for_transport",
            "file_name": target.get("file_name"),
            "display_name": target.get("display_name"),
            "size": target.get("file_size"),
            "message": "This file exceeds the cloud Bot API download "
                       "limit. Large-file streaming requires a healthy "
                       "Local Bot API server — please retry once it is "
                       "available, or receive this file in Telegram.",
        })
    logger.info("WEBSITE_STREAM_ISSUE_OK user_id=%s file_pk=%s ttl=%s",
                uid, file_pk, ttl)
    # BOT-16 — codec verdict + HLS plan (browser-compatible playback):
    # probe the source (cached ffprobe) when the identity is already on
    # local disk (StreamCache); classify browser compatibility; when the
    # verdict is "transcode" (HEVC/MKV/...) mint a LONGER-LIVED stream
    # token for the HLS surface and expose the real variant ladder. The
    # player then uses hls_url (native HLS / hls.js) instead of the raw
    # stream_url — the "Cannot play in this browser" production failure.
    codec_verdict = "unknown"
    codec_reason = ""
    hls_url: Optional[str] = None
    variants: Optional[List[Dict[str, Any]]] = None
    duration: Optional[float] = None
    hls_unavailable_reason: Optional[str] = None
    # B23 §4.1 PHOTO FIX (root cause of the broken photo player): IMAGE
    # media renders through an <img> element — the browser's NATIVE image
    # decoding. ffprobe on a still image reports its mjpeg stream as a
    # VIDEO codec, which the video classification then read as
    # transcode/mjpeg_video_codec: the issuance minted an HLS ladder for
    # a PHOTO, the player attached hls.js to the <img>, and hls.js
    # stamped a MediaSource blob: URL onto the image (naturalWidth=0 —
    # the "persistent blob UUID"). The transcode ladder is a VIDEO
    # concept: image media is ALWAYS direct and NEVER gets an hls_url.
    _is_image_media = (
        media_type in ("photo", "image") or mime.startswith("image/"))
    # V26 FINAL (Part 3): VIDEO media — the structural types whose
    # browser compatibility is NOT assumable without a probe (unlike
    # images, which the browser decodes natively, and unlike audio,
    # which keeps its current specialized direct behavior).
    _is_video_media = (
        media_type in ("video", "animation", "video_note")
        or mime.startswith("video/"))

    async def _mint_hls_plan() -> None:
        """Mint the LONG-LIVED HLS token + master URL + the variant
        ladder — the EXISTING BOT-16 mechanism (same token codec, same
        /site/hls/{token}/master.m3u8 surface, same variant_ladder).

        BOT-40 ROOT-CAUSE GUARD: NEVER mint a doomed master URL. Before
        promising HLS playback, the EXACT serve-side identity resolver
        (deps.hls_resolver — the production _make_hls_resolver wiring)
        must be able to resolve this (listing, file_pk) to a media
        identity. The bot-40 production failure: probe_unavailable + an
        unresolvable identity minted an hls_url whose /site/hls request
        could only answer an unclassified 404 ("Cannot play in this
        browser"). When the resolver is absent (unwired deployments,
        legacy test harnesses) the mint stays optimistic and the serve
        surface answers its honest hls_not_wired 503."""
        nonlocal hls_url, variants, hls_unavailable_reason
        _hr = getattr(deps, "hls_resolver", None)
        if callable(_hr):
            try:
                _info = await _hr(listing_opaque, file_pk)
            except Exception:  # noqa: BLE001 — unresolvable = refuse
                _info = None
            _fuid = str(((_info or {}) or {}).get("file_unique_id") or "")
            logger.info(
                "WEBSITE_HLS_SOURCE file_pk=%s file_unique_id=%s "
                "source_available=%s", file_pk,
                _fuid[:16] if _fuid else "-",
                "yes" if (_fuid and callable(
                    (_info or {}).get("source_path_fn"))) else "no")
            if not _fuid or not callable((_info or {}).get("source_path_fn")):
                # V26.2 (bot-41): classify the refusal honestly — the
                # issuance's OWN resolved target knows whether the media
                # identity is genuinely missing (NULL/stale file_unique_id
                # on the listing target → media_identity_unresolvable);
                # an identity that EXISTS but the resolver cannot resolve
                # is a wiring failure (hls_resolver_unwired — the bot-41
                # facade-shape class). Both still refuse to mint (no
                # doomed URL, no raw fallback).
                hls_unavailable_reason = (
                    "hls_resolver_unwired"
                    if (target or {}).get("file_unique_id")
                    else "media_identity_unresolvable")
                return  # hls_url stays None — no doomed URL, no raw
                        # fallback (the V26 rule: VIDEO + probe
                        # unavailable NEVER silently returns j.stream_url)
        from app.media.streamtokens import STREAM_TOKEN_TTL_LONGFORM_MAX
        hls_token = gateway.issue_stream_token(
            uid, listing_opaque, file_pk,
            ttl_seconds=max(int(ttl), 6 * 3600),
            ttl_max_seconds=STREAM_TOKEN_TTL_LONGFORM_MAX)
        hls_url = svc.build_site_url(
            f"site/hls/{hls_token}/master.m3u8",
            await svc.website_public_base_url())
        try:
            from app.media.transcode import variant_ladder
            ladder = variant_ladder(_probe_height[0])
            variants = [{"id": "auto", "label": "Auto"}] + [
                {"id": v["id"], "label": v["label"]} for v in ladder]
        except Exception:  # noqa: BLE001 — menu falls back
            variants = [{"id": "auto", "label": "Auto"}]

    _probe_height: List[Optional[int]] = [None]
    if streamable and _is_image_media:
        # verdict/reason flow to the ONE generic WEBSITE_PLAYER_FORMAT
        # log line + the wire fields below — no duplicated logging here.
        codec_verdict, codec_reason = "direct", "image_media"
    elif streamable:
        try:
            from app.media.transcode import get_transcode_manager
            from app.media.probe import (cached_probe,
                                         classify_browser_compatibility)
            from app.media.streamcache import _safe_subdir
            import os as _os
            mgr = get_transcode_manager()
            _cache = getattr(gateway, "cache", None)
            _local_path: Optional[str] = None
            if _cache is not None and target.get("file_unique_id"):
                try:
                    _p = await _cache.probe(str(target["file_unique_id"]))
                except Exception:  # noqa: BLE001
                    _p = None
                if _p and _p.get("complete"):
                    _local_path = _os.path.join(
                        _safe_subdir(_cache.root,
                                     str(target["file_unique_id"])), "data")
            if _local_path:
                probe = await cached_probe(
                    mgr.cache_root, str(target["file_unique_id"]),
                    _local_path)
                verdict, reason = classify_browser_compatibility(probe)
                codec_verdict, codec_reason = verdict, reason
                duration = probe.duration
                _probe_height[0] = probe.height
                if verdict == "transcode":
                    await _mint_hls_plan()
        except Exception:  # noqa: BLE001 — verdict is best-effort only
            logger.debug("codec verdict failed", exc_info=True)
            codec_verdict = "unknown"
        # V26 FINAL (bot-39 root cause #2 — Part 3): a VIDEO whose codec
        # could NOT be probed (no complete local cache entry — the
        # 571.6 MB file_pk=997 shape) must NEVER silently fall back to
        # the raw/direct media URL: unknown codec information is NOT
        # browser compatibility (bot-39: no WEBSITE_PLAYER_FORMAT at
        # all, then "Cannot play in this browser"). The conservative
        # playback plan is the EXISTING authenticated HLS pipeline —
        # the /site/hls route materializes/probes/transcodes the source
        # on demand (ensure_hls + the EXISTING spool fallback, ffprobe,
        # transcoder and variant ladder). codec_reason names the honest
        # cause. Images/audio keep their specialized behavior.
        if codec_verdict == "unknown" and _is_video_media:
            codec_verdict, codec_reason = "transcode", "probe_unavailable"
            await _mint_hls_plan()
    # BOT-40 (Section C): HLS materialization is IMPOSSIBLE for this file
    # (the serve chain cannot resolve its identity) — the honest failure,
    # never a doomed hls_url and never a silent raw-media fallback. The
    # same honest-unavailable response shape the too_large gate uses
    # (streamable=False + unavailable_reason + message — the player
    # renders its in-place unavailable state from this contract).
    if hls_unavailable_reason:
        logger.info(
            "WEBSITE_STREAM_ISSUE_HLS_UNAVAILABLE user_id=%s file_pk=%s "
            "reason=%s", uid, file_pk, hls_unavailable_reason)
        return _aiohttp_web.json_response({
            "ok": True,
            "authorized": True,
            "streamable": False,
            "unavailable_reason": hls_unavailable_reason,
            "file_name": target.get("file_name"),
            "display_name": target.get("display_name"),
            "size": target.get("file_size"),
            "message": "This file's media identity is incomplete — the "
                       "source channel needs re-indexing before it can be "
                       "prepared for browser playback.",
        })
    resp: Dict[str, Any] = {
        "ok": True,
        "authorized": True,
        "stream_url": stream_url,
        "mime_type": target.get("mime_type"),
        "content_type": content_type,
        "media_type": target.get("media_type"),
        "file_name": target.get("file_name"),
        # V26.2 (bot-41 §9-§11): the user-facing now-playing label for
        # PACKAGE children ("Video n") — the player prefers this and
        # falls back to file_name (single payloads keep the legacy
        # behavior because display_name is None for them).
        "display_name": target.get("display_name"),
        "size": target.get("file_size"),
        "streamable": bool(streamable),
        "token_ttl": ttl,
        "user": {"id": uid},
    }
    # BOT-16 — codec verdict + HLS plan fields (present when probed):
    # codec_verdict direct|transcode|unknown, codec_reason, duration,
    # hls_url (transcode only — the master playlist URL), variants (the
    # REAL quality ladder: Auto + the levels that will exist).
    if codec_verdict != "unknown" or hls_url is not None:
        resp["codec_verdict"] = codec_verdict
        if codec_reason:
            resp["codec_reason"] = codec_reason
        if duration is not None:
            resp["duration"] = duration
        if hls_url is not None:
            resp["hls_url"] = hls_url
        if variants is not None:
            resp["variants"] = variants
    # V26 FINAL (Part 3): WEBSITE_PLAYER_FORMAT now fires for EVERY
    # streamable issuance (bot-39 evidence: file_pk=997 produced NO
    # event because the unknown verdict suppressed it) — the fields
    # are exactly user_id / file_pk / verdict / reason / hls=yes|no /
    # variants count (+ duration when probed).
    if streamable:
        logger.info(
            "WEBSITE_PLAYER_FORMAT user_id=%s file_pk=%s verdict=%s "
            "reason=%s hls=%s variants=%s duration=%s",
            uid, file_pk, codec_verdict, codec_reason or "-",
            "yes" if hls_url else "no",
            len(variants) if variants else 0,
            duration if duration is not None else "-")
    # ---- VIDEO ADS (Task 9 v37 → B10-W1 §9-§16) -----------------------
    # INTEGRATION POINT (documented choice): the EXISTING stream-issuance
    # response carries the resolved video-ad policy. This is the SINGLE
    # authenticated playback-metadata call the player page already makes
    # (verified initData is REQUIRED above — unauthenticated callers never
    # reach this point), so no second endpoint, no extra round-trip and no
    # new trust boundary are introduced. The "preroll" key exists ONLY
    # when the server-side policy resolves to SERVE for an authenticated,
    # authorized, streamable playback — never otherwise.
    # §16 provider abstraction: get_videoad_policy() DELEGATES to the v37
    # PreRollPolicy when the configured provider is direct/none (the
    # exact v37 direct-media behavior) and runs the VAST decision path
    # when provider=vast; the player-facing wire key stays "preroll" with
    # the SAME subset + provider + timeout (stable player contract).
    #
    # BOT-16 SURFACE SEPARATION FIX — the per-payload
    # ``video_ad_destination`` (BOT/WEBSITE/NONE) gate is REMOVED. The
    # website pre-roll now follows the WEBSITE ad settings alone
    # (``website_videoad_provider`` + ``website_preroll_*``), exactly as
    # the Telegram Watch Ads system follows the Telegram Watch Ads
    # settings. The two ad systems share ZERO state: website playback
    # never creates watch_ad_sessions, never touches Telegram reward
    # counters, and never redirects to the bot for an ad (locked by
    # tests/test_bot13_website_delivery_modes.py F1/F2). The deprecated
    # DB column stays (backward-compatible migrations; inert at runtime).
    if streamable:
        try:
            from app.web.site.video_ads import (
                get_videoad_policy, player_wire_subset)
            # The signed site-session cookie (server-issued, AEAD) supplies
            # the per-browser session_key for session-frequency accounting;
            # its absence degrades to a per-user bucket. The user id is the
            # initData-verified one — NEVER a client-supplied value.
            from app.web.site.pages import _session_of
            skey = None
            try:
                site_session = await _session_of(request, deps)
                if site_session is not None \
                        and int(site_session.get("user_id") or 0) == uid:
                    # The session_key is used ONLY when the signed cookie's
                    # identity MATCHES the initData-verified user (never a
                    # client-selected frequency bucket).
                    skey = str(site_session.get("session_key") or "") or None
            except Exception:  # noqa: BLE001 — identity stays uid-only
                skey = None
            decision = await get_videoad_policy().resolve(deps.db, uid,
                                                          skey)
            # §14 lifecycle: the DECISION is logged at decision time; the
            # player fires VIDEO_AD_RESPONSE/START/SKIP/COMPLETE/NO_FILL/
            # ERROR client-side (display-only records — §12).
            # FINAL-1: surface=website_preroll names WHICH ad system this
            # is (the WEBSITE pre-roll — configured by the website ad
            # settings alone, ZERO shared state with the Telegram
            # Watch-Ads payload gate that produces watch_ad_required
            # denials; bot-20.log read the two as one contradiction).
            logger.info(
                "WEBSITE_VIDEOAD_DECISION surface=website_preroll "
                "user_id=%s provider=%s serve=%s "
                "reason=%s mode=%s frequency=%s", uid,
                decision.get("provider"), decision.get("serve"),
                decision.get("reason"), decision.get("mode"),
                decision.get("frequency"))
            if decision.get("serve"):
                if str(decision.get("provider")) == "vast":
                    logger.info(
                        "VIDEO_AD_REQUEST user_id=%s provider=vast", uid)
                # Only the player-facing subset crosses the wire (no
                # internal accounting fields; provider + timeout are the
                # §16 additions to the stable v37 contract).
                resp["preroll"] = player_wire_subset(decision)
                logger.info(
                    "WEBSITE_PREROLL_ATTACHED user_id=%s provider=%s "
                    "mode=%s frequency=%s fallback=%s", uid,
                    decision.get("provider"), decision.get("mode"),
                    decision.get("frequency"),
                    decision.get("fallback"))
        except Exception:  # noqa: BLE001 — ads NEVER block issuance
            logger.warning("PREROLL_ATTACH_ERROR (issuance proceeded)",
                           exc_info=True)
    return _aiohttp_web.json_response(resp)


async def handle_site_media(request):
    """GET/HEAD /site/media/{token} — the Media Gateway HTTP surface.
    The gateway authenticates the token, re-verifies the EXISTING access
    state, resolves the canonical media and plans Range/HEAD/GET."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    # V26 Phase 6 + V26 FINAL: the Anti-Leech toggle (see
    # _anti_leech_decision) — a foreign-host referer/origin on the
    # streaming surface is a hotlink; the PROXY-AWARE host set keeps the
    # deployment's legitimate public hosts (Worker/proxy) allowed.
    if await _anti_leech_active(deps):
        _al = await _anti_leech_decision(request, deps)
        if not _al.get("allowed"):
            _log_anti_leech("media", _al, blocked=True)
            return _aiohttp_web.json_response(
                {"ok": False, "error": "anti_leech",
                 "message": "Hotlinking this media is not permitted."},
                status=403)
        _log_anti_leech("media", _al, blocked=False)
    if not ratelimit.check_rate("site_stream", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    if not ratelimit.begin_stream(_client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "too_many_concurrent_streams"},
            status=429)
    try:
        gateway = _gateway(deps)
        if gateway is None:
            return _aiohttp_web.json_response(
                {"ok": False, "error": "streaming_unavailable"},
                status=503)
        token = str(request.match_info.get("stream_token") or "")
        # V26 FINAL (Part 14 — cross-user replay): the AEAD stream token
        # binds user/listing/file/expiry, but it is a BEARER URL. When
        # the request carries a VALID site session whose user differs
        # from the token's user, THIS is a cross-user replay (user B
        # pasting user A's link into a logged-in browser) → 403. No
        # session cookie present (a bare downloader) → the token alone
        # decides (short TTL + Access Engine re-verification remain).
        _al_uid = await _token_user_if_mismatched(request, deps, token)
        if _al_uid is not None:
            logger.info(
                "STREAM_AUTH_FAIL user_id=%s reason=wrong_user "
                "(session user %s != token user)", _al_uid[0], _al_uid[1])
            return _aiohttp_web.json_response(
                {"ok": False, "error": "wrong_user",
                 "message": "This playback link belongs to another user."},
                status=403)
        range_header = request.headers.get("Range")
        plan = await gateway.handle_stream_request(
            token, method=request.method, range_header=range_header)
        return await _plan_to_response(request, plan)
    finally:
        ratelimit.end_stream(_client_ip(request))


async def handle_site_thumb(request):
    """GET /site/thumb/{token} — bounded thumbnail bytes (public listing
    artwork; AEAD token bound to the published listing — no arbitrary
    Telegram file retrieval, bounded size, honest placeholder).

    B10-W2 (spec §22): artwork of an AGE-RESTRICTED listing is gated —
    a leaked thumb URL must not render restricted art for an unconfirmed
    session; the honest neutral placeholder is served instead (the same
    discipline as the feed: restricted listings never render anywhere
    pre-confirmation). The gateway/media path itself is untouched (§26)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    # V26 Phase 6 + V26 FINAL: the Anti-Leech toggle also covers public
    # artwork (proxy-aware — see _anti_leech_decision).
    if await _anti_leech_active(deps):
        _al = await _anti_leech_decision(request, deps)
        if not _al.get("allowed"):
            _log_anti_leech("thumb", _al, blocked=True)
            return _aiohttp_web.json_response(
                {"ok": False, "error": "anti_leech",
                 "message": "Hotlinking this media is not permitted."},
                status=403)
        _log_anti_leech("thumb", _al, blocked=False)
    if not ratelimit.check_rate("site_thumb", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    gateway = _gateway(deps)
    if gateway is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "streaming_unavailable"}, status=503)
    token = str(request.match_info.get("thumb_token") or "")
    # 18+ artwork gate (spec §22). The token decode uses the SAME stream
    # token codec/vault as the gateway (a token that fails HERE also
    # fails THERE — no bytes are ever served); on a resolvable token the
    # listing's categories decide whether the session must be confirmed.
    try:
        from app.media.streamtokens import make_stream_token_codec
        thumb_codec = make_stream_token_codec(
            getattr(deps, "bot_token", None))
        decoded_thumb = thumb_codec.decode_stream_token(token)
    except Exception:  # noqa: BLE001 — gateway answers the bad token
        decoded_thumb = None
    if decoded_thumb is not None \
            and str(decoded_thumb.get("purpose") or "") == "thumb" \
            and not await _session_age_confirmed(request, deps, None) \
            and await _listing_age_restricted(
                deps, str(decoded_thumb.get("listing") or "")):
        logger.info("WEBSITE_THUMB_AGE_DENIED listing=%s (18+ unconfirmed "
                    "— neutral placeholder served)",
                    decoded_thumb.get("listing"))
        return _thumb_placeholder_response()
    plan = await gateway.handle_thumb_request(token)
    return await _plan_to_response(request, plan)
