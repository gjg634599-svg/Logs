"""WEBSITE screens (GAP-CLOSURE spec §21-§32) — the login / identity /
Force-Join / age / network / about / settings screens.

Every screen is a server-rendered page built on the same design system as
app/web/site/html.py (the ``_page`` shell with the premium streaming
chrome). The LOGIN screen performs the spec §21/§22 flow client-side:

    Telegram.WebApp.initData (HMAC-validated server-side on POST)
        → optional additional confirmation (user ID OR username)
        → backend compares with the AUTHENTICATED identity (spec §22)
        → session cookie issued → reload into the gated content

No client-supplied identity is ever trusted: the typed ID/username is ONLY
an extra confirmation the backend compares against the verified identity.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from app.web.site.html import _icon, _page, esc, site_url


# ------------------------------------------------------------------ login
def login_page(*, error: str = "", site_on: bool = True) -> str:
    """The spec §21/§22 login screen (anonymous entry to the Website).

    Auth lifecycle state machine (spec §7-§15): BOOT → TELEGRAM_LOADING
    (bounded poll for window.Telegram.WebApp — 50ms steps, 3000ms cap;
    the SDK <head> script may still be loading on a slow WebView) →
    TELEGRAM_READY → AUTHENTICATING → READY, with AUTHENTICATION_FAILED /
    ERROR recovery. First paint shows a neutral BOOT state (logo +
    "Loading…"): NEVER the login form, NEVER a premature "Open in
    Telegram" deny — the honest deny only appears after the bounded wait
    actually expires.

    V25 (§20/§23) — AUTO-AUTH: when a valid Telegram WebApp initData is
    present the session request is submitted AUTOMATICALLY (no manual
    entry of Telegram user ID / username — the backend validates the
    SIGNED initData and derives the identity itself). The manual
    confirmation form appears ONLY as a fallback after an auto-auth
    failure (or a stale SDK), never as the first screen inside Telegram.
    The POST /site/api/session contract is unchanged:
    {init_data, confirm_user_id?, confirm_username?} (200 → reload, 403
    identity_mismatch message, 401 → "Sign-in expired — reopening…" +
    reload after 900ms). Safe diagnostics only (spec §68): the data-state
    attribute + console.info booleans — initData itself is NEVER logged.
    (QA-stub guard: this file must never contain the literal
    "window.Telegram=" string.)"""
    error_html = ""
    if error:
        error_html = ('<div class="loginerr" role="alert">'
                      + _icon("alert") + esc(error) + "</div>")
    body = (
        '<div class="centerwrap"><div class="loginbox"'
        ' data-state="BOOT">'
        '<div class="logoglyph"><span class="dot"></span></div>'
        "<h1>Welcome to EndieFans</h1>"
        '<p class="loginlead">Verify your Telegram account to continue.</p>'
        '<div id="bootstate" class="loginstate" aria-live="polite">'
        "Loading…</div>"
        '<form id="verifyform" autocomplete="off" hidden>'
        '<label class="fld" for="fid">Telegram User ID</label>'
        '<input id="fid" name="user_id" type="text" inputmode="numeric" '
        'placeholder="e.g. 8370454312" autocomplete="off">'
        '<div class="orrule"><span>OR</span></div>'
        '<label class="fld" for="fun">Telegram Username</label>'
        '<input id="fun" name="username" type="text" '
        'placeholder="e.g. @username" autocomplete="off">'
        '<button class="verifybtn" type="submit" id="verifybtn">'
        "Verify</button>"
        '<p class="fineprint">The entered identity is only an additional '
        "confirmation — the backend compares it with your authenticated "
        "Telegram identity.</p>"
        "</form>"
        '<div id="loginstate" class="loginstate" hidden '
        'aria-live="polite"></div>'
        + error_html +
        '<div id="deny" class="deny" hidden>'
        '<div class="glyph">\U0001F510</div>'
        "<b>Open in Telegram</b>"
        "<p>This website is verified through your Telegram account. "
        "Open it from the bot to continue.</p></div>"
        "</div></div>")
    script = """
<script>
(function(){
  var box=document.querySelector('.loginbox');
  var form=document.getElementById('verifyform');
  var st=document.getElementById('loginstate');
  var deny=document.getElementById('deny');
  var boot=document.getElementById('bootstate');
  var autoTried=false;
  function setState(s){ if(box){ box.setAttribute('data-state',s); } }
  function info(m){ try{ console.info(m); }catch(e){} }
  function setSt(msg,ok){st.hidden=false;st.textContent=msg;
    st.className='loginstate '+(ok?'ok':'bad');}
  function hideBoot(){ if(boot){ boot.hidden=true; } }
  function showDeny(){ if(deny){deny.hidden=false;} if(form){form.hidden=true;} }
  function showFormFallback(msg){
    // V25 (§23): the manual confirmation form is the FALLBACK ONLY —
    // shown after auto-auth failed (never as the first screen inside
    // Telegram, where the signed initData already identifies the user).
    if(form){form.hidden=false;}
    if(boot){boot.hidden=true;}
    if(msg){setSt(msg,false);}
  }
  function postSession(payload, onDone){
    fetch('""" + site_url("site/api/session") + """',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    }).then(function(r){return r.json().then(function(j){return {s:r.status,j:j};});})
      .then(function(res){ onDone(res||{}); })
      .catch(function(){ onDone({s:0,j:{}}); });
  }
  function autoAuthenticate(tg){
    // V25 (§20): AUTO-AUTH — the signed initData IS the credential; the
    // backend validates the HMAC and derives the canonical user. No
    // manual ID/username entry while a valid WebApp identity exists.
    if(autoTried){ return; }
    autoTried=true;
    setState('AUTHENTICATING');
    setSt('Signing you in…',true);
    info('auto_auth_started=true');
    postSession({init_data:tg.initData||''},function(res){
      var j=res.j||{};
      if(res.s===200&&j.ok){
        setSt('Verified — welcome back!',true);
        setState('READY');
        info('auto_auth_ok=true');
        setTimeout(function(){location.reload();},350);
        return;
      }
      if(res.s===401){
        setState('AUTH_FAILED');
        setSt('Sign-in expired — reopening…',false);
        setTimeout(function(){location.reload();},900);
        return;
      }
      // 403 identity_mismatch cannot happen without confirm fields, but
      // any other failure falls back to the manual confirmation form
      // (the honest degraded path — never a silent dead end).
      info('auto_auth_failed=true status='+res.s);
      setState('AUTH_FAILED');
      showFormFallback('Automatic sign-in failed. Confirm your identity '
        +'below and try again.');
    });
  }
  function wireManualForm(tg){
    form.addEventListener('submit',function(ev){
      ev.preventDefault();
      setState('AUTHENTICATING');
      var fid=document.getElementById('fid').value.trim();
      var fun=document.getElementById('fun').value.trim();
      var btn=document.getElementById('verifybtn');btn.disabled=true;
      setSt('Verifying your account…',true);
      postSession({init_data:tg.initData||'',
        confirm_user_id:fid,confirm_username:fun},function(res){
        var j=res.j||{};
        if(res.s===200&&j.ok){setSt('Verified — welcome back!',true);
          setState('READY');
          setTimeout(function(){location.reload();},450);return;}
        if(res.s===403&&j.error==='identity_mismatch'){
          setState('AUTH_FAILED');
          setSt('The ID/username you entered does not match your verified '
            +'Telegram account. Check it and try again.',false);
          btn.disabled=false;return;}
        if(res.s===401){setState('AUTH_FAILED');
          setSt('Sign-in expired — reopening…',false);
          setTimeout(function(){location.reload();},900);return;}
        setState('ERROR');
        setSt('Verification failed. Please try again.',false);
        btn.disabled=false;
      });
    });
  }
  setState('TELEGRAM_LOADING');
  var waited=0;
  var iv=setInterval(function(){
    var tg=window.Telegram&&window.Telegram.WebApp;
    if(tg){
      clearInterval(iv);
      setState('TELEGRAM_READY');
      info('telegram_sdk_present=true');
      if(!tg.initData){
        info('init_data_present=false reason=init_data_missing');
        hideBoot();
        showDeny();
        setState('AUTH_REQUIRED');
        return;
      }
      info('init_data_present=true');
      try{tg.ready();tg.expand();}catch(e){}
      autoAuthenticate(tg);
      wireManualForm(tg);
      return;
    }
    waited+=50;
    if(waited>=3000){
      clearInterval(iv);
      hideBoot();
      info('telegram_sdk_present=false reason=sdk_unavailable');
      showDeny();
      setState('AUTH_REQUIRED');
    }
  },50);
})();
</script>"""
    # V26 script-placement fix: the gate/bootstrap scripts live INSIDE
    # <main> (appended to the page BODY), NOT after </html>. Root cause of
    # the production "first click stuck": the SPA-lite layer swaps ONLY
    # main#main.innerHTML and re-creates <script> tags INSIDE <main> — a
    # script appended after the document was silently DROPPED on every
    # SPA navigation to this page (the button rendered with NO handler;
    # a manual reload was the only way to make the tap work). Inside
    # <main> the script executes (a) right after the markup on full
    # loads — BEFORE the ~50KB of trailing scripts, so the button is
    # interactive the moment it paints even on slow networks — and (b)
    # re-created verbatim by the SPA swap's execScripts(main).
    return _page("Welcome", body + script,
                 description="Verify your Telegram account to continue.",
                 noindex=True)


# ------------------------------------------------------------- force join
def _fj_row_state(ch: Dict[str, Any]) -> str:
    """BOT-16 (Work Item B): the closed per-channel state a gate row
    renders — the NEW ``state`` field (not_joined | api_temporary_failure
    | invalid_channel | bot_permission_failure) with a legacy fallback:
    a row without ``state`` but with ``verification == "unavailable"``
    keeps the bot-side transient semantics (a stored URL means the link
    still works for users — dead links drop the URL server-side, so
    "unavailable + url" is api_temporary_failure and "unavailable without
    url" is a confirmed-dead channel)."""
    state = str(ch.get("state") or "").strip().lower()
    if state in ("not_joined", "api_temporary_failure", "invalid_channel",
                 "bot_permission_failure"):
        return state
    verification = str(ch.get("verification") or "").strip().lower()
    if verification == "unavailable":
        return "api_temporary_failure" if ch.get("url") \
            else "invalid_channel"
    return "not_joined"


_FJ_STATE_BADGE = {
    "not_joined": ("", "Not joined"),
    "api_temporary_failure": ("warn", "Check unavailable"),
    "invalid_channel": ("dead", "Unavailable"),
    "bot_permission_failure": ("dead", "Unavailable"),
}


def _safe_return_to(return_to: str) -> str:
    """BOT-16: sanitize a Verify return target — same-site absolute path
    ONLY (starts with a single "/"), bounded length, never a scheme, never
    a protocol-relative URL. Server-built input, belt-and-braces here."""
    s = str(return_to or "").strip()
    if not s.startswith("/") or s.startswith("//") or s.startswith("/\\"):
        return ""
    if any(c in s for c in ("\n", "\r")):
        return ""
    return s[:512]


def fj_gate_page(channels: List[Dict[str, Any]], *,
                 username: str = "",
                 fj_health: Optional[Dict[str, Any]] = None,
                 return_to: str = "",
                 gate_key: str = "") -> str:
    """The spec §24 Force-Join gate: the EXACT unjoined channels with the
    backend-provided Join URLs and the Verify Again recheck.

    v35 §14/§15: channels the bot cannot VERIFY right now render the
    honest "verification unavailable — retry" state (never "not joined",
    never a dead Join button), and the gate surfaces the aggregate
    DEGRADED banner when fewer than all configured channels are healthy
    (production: 7 configured / 0 healthy — never claim full health).

    BOT-16 (Work Item B): the temporary-error regression is FIXED — a
    TRANSIENT verification failure (state api_temporary_failure) renders
    the Join button ANYWAY (the stored invite URL keeps working for users
    regardless of bot access — mirrors app/presentation/telegram/
    forcejoin.py ~508-516) with an honest "we could not verify just now"
    note; ONLY confirmed-dead channels (invalid_channel /
    bot_permission_failure) drop the URL and render the honest
    "unavailable" line with NO dead Join button. Each row carries a
    state badge, and a successful Verify reloads to ``return_to`` (the
    page the user was actually trying to open) instead of always the
    feed.

    V26.2 (bot-41 §16-§24): ``channels`` is THIS gate's PINNED BATCH
    (progressive batching — the page renders exactly what the server
    delivered, never a future batch); ``gate_key`` rides along so the
    Verify round-trip re-checks the same pinned batch (server-echoed
    context, re-validated server-side)."""
    health = fj_health or {}
    rows = []
    unverify = 0
    for ch in channels or []:
        title = str(ch.get("title") or "Channel")
        url = ch.get("url")
        state = _fj_row_state(ch)
        badge_cls, badge_text = _FJ_STATE_BADGE.get(
            state, _FJ_STATE_BADGE["not_joined"])
        badge = ('<span class="fjbadge' + ((" " + badge_cls) if badge_cls
                                           else "") + '">' + esc(badge_text)
                 + "</span>")
        btn = ""
        if state == "not_joined":
            if url:
                btn = ('<a class="joinbtn" href="' + esc(url)
                       + '" target="_blank" rel="noopener noreferrer">'
                       + _icon("external") + "Join Channel</a>")
            else:
                btn = ('<span class="joinbtn dead" title="Join in Telegram">'
                       + _icon("lock") + "Join in Telegram</span>")
        elif state == "api_temporary_failure":
            # BOT-16: the stored link keeps working for users even when the
            # bot cannot verify right now — render the Join button ANYWAY
            # with the honest retry hint (never blame the user with "not
            # joined", never hide a usable link behind a dead state).
            unverify += 1
            if url:
                btn = ('<a class="joinbtn" href="' + esc(url)
                       + '" target="_blank" rel="noopener noreferrer">'
                       + _icon("external") + "Join Channel</a>"
                       + '<span class="fjnote">We could not verify just '
                       'now — join, then tap Verify.</span>')
            else:
                btn = ('<span class="joinbtn dead" title="The bot cannot '
                       'verify this channel right now">'
                       + _icon("shield") + "Verification unavailable</span>")
        else:
            # invalid_channel / bot_permission_failure — confirmed-dead or
            # unverifiable surface: NO dead Join button, just the honest
            # unavailable line (the bot-side link-health system repairs it).
            unverify += 1
            btn = ('<span class="joinbtn dead" title="This channel cannot '
                   'be verified right now">'
                   + _icon("shield") + "Unavailable</span>")
        rows.append(
            '<li class="fjrow" data-fj-chan="'
            + esc(str(ch.get("channel_id") or "")) + '"><span class="fjtitle">'
            + esc(title)
            + "</span>" + badge + btn + "</li>")
    banner = ""
    if str(health.get("fj_health") or "") == "degraded":
        banner = (
            '<div class="fjhealth" role="status">' + _icon("alert")
            + f"Force Join: DEGRADED — "
            + esc(str(int(health.get("healthy") or 0))) + "/"
            + esc(str(int(health.get("total") or 0)))
            + " channels healthy. Some channels may not be verifiable "
              "right now.</div>")
    who = ("@" + username if username else "Telegram User")
    body = (
        '<div class="centerwrap"><div class="fjbox">'
        '<div class="glyph">\U0001F512</div>'
        "<h1>Required Channels</h1>"
        + banner +
        '<p class="loginlead">👤 ' + esc(who) + " — one more step.</p>"
        '<ul class="fjlist">' + "".join(rows) + "</ul>"
        '<button class="verifybtn" id="fjverify" type="button">'
        "Verify Membership</button>"
        '<div id="fjstate" class="loginstate" hidden aria-live="polite">'
        "</div>"
        '<p class="fineprint">Joining does not mark membership as complete '
        "— the backend re-checks your membership when you verify."
        + (" Verification for some channels is temporarily unavailable "
           "— you are not blocked for it; use Verify again in a moment."
           if unverify else "") + "</p>"
        "</div></div>")
    ret = _safe_return_to(return_to)
    ret_js = json.dumps(ret)
    gate_js = json.dumps(gate_key or "")
    script = """
<script>
(function(){
  var btn=document.getElementById('fjverify');
  var st=document.getElementById('fjstate');
  var RETURN=""" + ret_js + """;
  var GATE=""" + gate_js + """;
  function setSt(msg,ok){st.hidden=false;st.textContent=msg;
    st.className='loginstate '+(ok?'ok':'bad');}
  function backToTarget(){
    // BOT-16: a successful verify reloads to the RETURN URL (the page
    // the user was trying to open) — never an off-site target (the
    // value is server-built + sanitized; empty falls back to reload).
    if(RETURN){ try{ window.location.href=RETURN; return; }catch(e){} }
    location.reload();
  }
  btn.addEventListener('click',function(){
    btn.disabled=true;setSt('Checking your membership…',true);
    var id='';
    try{id=(window.Telegram&&window.Telegram.WebApp
      &&window.Telegram.WebApp.initData)||'';}catch(e){}
    fetch('"""+ site_url("site/api/forcejoin/verify") + """',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({init_data:id,gate_key:GATE})
    }).then(function(r){return r.json();}).then(function(j){
      if(j&&j.ok&&j.joined){setSt('Membership verified!',true);
        setTimeout(backToTarget,450);return;}
      if(j&&j.ok&&j.not_joined&&j.not_joined.length){
        // V25 §9.3: compare the backend's CURRENT requirement with the
        // rendered rows — when the batch ADVANCED (the completed batch's
        // channels dropped out / the next batch was created server-side),
        // RELOAD so the gate re-renders the genuinely remaining channels
        // (the server is authoritative; the stale rows must never keep
        // showing already-completed channels as "not joined").
        var rendered=[].map.call(
          document.querySelectorAll('.fjrow[data-fj-chan]'),
          function(el){return String(el.getAttribute('data-fj-chan'));});
        var current=j.not_joined.map(function(v){
          return String((v&&(v.channel_id!==undefined?v.channel_id
            :v.channel))||'');}).filter(Boolean);
        var same=rendered.length===current.length&&rendered.every(
          function(c){return current.indexOf(c)>=0;});
        if(!same){
          setSt('Progress saved — updating your remaining channels…',true);
          setTimeout(function(){location.reload();},400);return;}
        setSt('Still missing '+(j.not_joined.length)+' channel'
          +(j.not_joined.length>1?'s':'')+'. Join them, then verify again.',
          false);btn.disabled=false;return;}
      setSt('Could not verify right now — please retry.',false);
      btn.disabled=false;
    }).catch(function(){setSt('Network error — try again.',false);
      btn.disabled=false;});
  });
})();
</script>"""
    # V26 script-placement fix: INSIDE <main> (see login_page) — the SPA
    # swap re-creates scripts inside main ONLY; a trailing script after
    # </html> left the Verify button handler-less on SPA navigation.
    return _page("Required Channels", body + script,
                 description="Join the required channels to continue.",
                 noindex=True)


# ------------------------------------------------------------------ age
def age_gate_page(*, username: str = "") -> str:
    """The 18+ confirmation interstitial (spec §20/§29): backend-authorized —
    the age_ok claim is issued ONLY by the server on explicit confirm.

    B10-W2 (spec §20): the exact required copy — title "18+ Content", the
    two-sentence restricted-content notice and the "I am 18 or older"
    button. The page is STATIC (no payload titles, no metadata, no media
    URLs — nothing about the restricted category is rendered); the button
    POSTs the EXISTING /site/api/session/age endpoint ({age_confirm:
    true}) and the SERVER re-issues the session with age_ok=true, then
    reloads the requesting page (/site/c/{slug} re-renders with the
    category displayed — spec §21). Never localStorage, never a query
    parameter, never client-only state.

    V25 §22-§24 (age-gate lifecycle): the button implements the explicit
    IDLE → SUBMITTING → SUCCESS / ERROR → IDLE state machine. One NAMED
    handler registered ONCE; an in-flight guard makes double taps
    physically unable to fire a second request; an AbortController with a
    bounded timeout returns the UI to an actionable state when the
    request stalls (the previously reported "stuck button" — a hung
    fetch left it disabled forever); a fallback timer restores the
    button if the post-confirm reload is throttled by the WebView; and
    the error surface maps the REAL backend verdicts (rate_limited /
    unauthorized) instead of a generic failure string. The backend stays
    the single authority for the age_ok claim."""
    who = ("@" + username if username else "Telegram User")
    body = (
        '<div class="centerwrap"><div class="agebox" id="agebox" '
        'role="region" aria-label="Age verification">'
        '<div class="agebox-head"><span class="glyph" aria-hidden="true">'
        "\U0001F51E</span><span class=\"agetag\">18+</span></div>"
        "<h1>18+ Content</h1>"
        '<p class="loginlead">This section contains age-restricted '
        "content. You must confirm that you are 18 years of age or older "
        "to continue.</p>"
        '<p class="fineprint">👤 ' + esc(who) + "</p>"
        '<div id="agestate" class="loginstate" hidden aria-live="polite">'
        "</div>"
        '<div class="agerow">'
        '<a class="backlink" href="' + site_url("site") + '">'
        + _icon("arrow-left") + "Go back</a>"
        '<button class="verifybtn" id="ageok" type="button">'
        '<span class="agespinner" aria-hidden="true"></span>'
        '<span class="verbtntxt">I am 18 or older</span></button></div>'
        "</div></div>")
    script = """
<script>
(function(){
  'use strict';
  var btn=document.getElementById('ageok');
  var st=document.getElementById('agestate');
  var box=document.getElementById('agebox');
  if(!btn||!st){return;}
  /* V26 AGE-GATE telemetry (safe structured lifecycle evidence):
     the FULL state model — INITIALIZING -> READY -> SUBMITTING ->
     SUCCESS | ERROR -> READY (retry) — with the deterministic event
     chain RENDER -> IDENTITY_WAIT -> IDENTITY_READY -> HANDLER_ATTACHED
     -> CLICK -> REQUEST_START -> REQUEST_RESULT -> STATE_UPDATED ->
     TRANSITION_COMPLETE (+ AGE_GATE_ERROR with a bounded reason on
     every failure path). Fire-and-forget through the shared __siteTel
     helper (allowlisted server-side; no secrets — the gate carries
     none). */
  function tel(ev,fields){try{
    if(window.__siteTel){window.__siteTel(ev,fields);}
  }catch(e){}}
  tel('AGE_GATE_RENDER');
  tel('AGE_GATE_STATE_UPDATED',{state:'initializing'});
  /* V26 identity lifecycle: the gate's identity IS the signed site
     session (HMAC-verified at login; httpOnly — never client-readable
     and NEVER localStorage-authoritative). The WAIT marker is honest:
     the client cannot observe the identity, the backend owns it and
     proves it at request time; IDENTITY_READY marks the request
     machinery (fetch) live — the point from which the confirm can
     actually reach the authority. */
  tel('AGE_GATE_IDENTITY_WAIT');
  var machineryOk=false;
  try{machineryOk=(typeof fetch==='function');}catch(e){}
  if(machineryOk){
    tel('AGE_GATE_IDENTITY_READY');
    tel('AGE_GATE_STATE_UPDATED',{state:'ready'});
  }else{
    /* Degraded engine without fetch: an honest, actionable error — the
       backend stays authoritative, the button stays visibly disabled. */
    tel('AGE_GATE_ERROR',{error:'no_fetch'});
    tel('AGE_GATE_STATE_UPDATED',{state:'error'});
    btn.disabled=true;
    setMsg('bad','This browser cannot reach the server \u2014 reopen the page from Telegram.');
    return;
  }
  var inFlight=false;      /* READY | SUBMITTING — one request at a time */
  var settleTimer=null;    /* the stalled-reload fallback */
  var TIMEOUT_MS=20000;    /* bounded wait: a hung request NEVER sticks  */

  function setMsg(kind,text){
    st.hidden=false;st.className='loginstate '+(kind||'');
    st.textContent=text;
  }
  function toError(reason,msg){
    /* -> ERROR (telemetry) -> READY (retry): the button MUST become
       actionable again — never a permanently dead SUBMITTING button. */
    tel('AGE_GATE_ERROR',{error:reason});
    tel('AGE_GATE_STATE_UPDATED',{state:'error'});
    toIdle(msg,'bad');
  }
  function toIdle(msg,kind){
    /* ERROR -> READY: the button MUST become actionable again */
    inFlight=false;btn.disabled=false;
    btn.classList.remove('is-pending');btn.setAttribute('aria-busy','false');
    box.setAttribute('aria-busy','false');
    if(settleTimer){clearTimeout(settleTimer);settleTimer=null;}
    if(msg){setMsg(kind||'bad',msg);}
    tel('AGE_GATE_STATE_UPDATED',{state:'ready'});
  }
  function toSubmitting(){
    inFlight=true;btn.disabled=true;
    btn.classList.add('is-pending');btn.setAttribute('aria-busy','true');
    box.setAttribute('aria-busy','true');
    setMsg('ok','Confirming\u2026');
    tel('AGE_GATE_STATE_UPDATED',{state:'submitting'});
  }
  function onConfirm(){                 /* the ONE named handler */
    if(inFlight){return;}               /* duplicate tap: no-op */
    tel('AGE_GATE_CLICK');
    toSubmitting();
    /* V26: the deterministic readiness markers — the request machinery
       (fetch + AbortController) is confirmed live BEFORE the request. */
    tel('AGE_GATE_IDENTITY_READY');
    tel('AGE_GATE_REQUEST_START');
    var ctl=('AbortController' in window)?new AbortController():null;
    var timeout=setTimeout(function(){
      if(ctl){ctl.abort();}
    },TIMEOUT_MS);
    fetch('"""+ site_url("site/api/session/age") + """',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({age_confirm:true}),
      signal:ctl?ctl.signal:undefined
    }).then(function(r){
      tel('AGE_GATE_REQUEST_RESULT',{status:r.status});
      clearTimeout(timeout);
      /* Non-JSON error pages surface as a parse failure below — map the
         HTTP status directly when we can still see it. */
      var status=r.status;
      return r.text().then(function(t){
        var j=null;try{j=JSON.parse(t);}catch(e){}
        return {status:status,j:j};
      });
    }).then(function(res){
      var j=res.j;
      if(j&&j.ok){
        /* SUCCESS: the SERVER re-issued the session with age_ok=true.
           Reload re-renders the gate away; the settle timer covers a
           WebView-throttled reload so the user is never trapped. */
        setMsg('ok','Confirmed \u2713');
        tel('AGE_GATE_STATE_UPDATED',{state:'success'});
        /* V26: sendBeacon beats a fetch during the reload navigation —
           the TRANSITION_COMPLETE evidence survives the unload. */
        try{
          if(window.__TEL_URL__&&navigator.sendBeacon){
            navigator.sendBeacon(window.__TEL_URL__,new Blob(
              [JSON.stringify({event:'AGE_GATE_TRANSITION_COMPLETE'})],
              {type:'application/json'}));
          }
        }catch(e){}
        settleTimer=setTimeout(function(){
          toIdle('Taking longer than expected \u2014 tap again to open the content.','ok');
        },6000);
        location.reload();
        return;
      }
      var err=(j&&j.error)||'';
      var msg='Confirmation failed \u2014 try again.';
      var reason='bad_response';
      if(err==='rate_limited'||res.status===429){
        msg='Too many attempts \u2014 wait a moment, then try again.';
        reason='http_429';
      }else if(err==='unauthorized'||res.status===401){
        msg='Your session expired \u2014 reopen this page from Telegram.';
        reason='http_401';
      }else if(res.status===503){
        msg='The service is momentarily unavailable \u2014 try again.';
        reason='http_503';
      }
      toError(reason,msg);
    }).catch(function(){
      clearTimeout(timeout);
      /* Abort (timeout) or network failure: ERROR -> READY, never a
         permanently disabled SUBMITTING button. */
      toError('timeout_or_network',
        'The request timed out \u2014 check your connection and try again.');
    });
  }
  btn.addEventListener('click',onConfirm);
  tel('AGE_GATE_HANDLER_ATTACHED');
})();
</script>"""
    # V26 script-placement fix: INSIDE <main> (see login_page) — the SPA
    # swap re-creates scripts inside main ONLY; a trailing script after
    # </html> left the confirm button handler-less on SPA navigation
    # (the production "fresh load → first tap dead → reload → works").
    # V26.x browser-QA fix: the OLD trailing "+ script" append (this
    # return's historical form) was left behind alongside the in-main
    # copy — a FULL page load executed the gate script TWICE (double
    # RENDER telemetry, a SECOND click listener with its own inFlight
    # closure, and a DOUBLE POST to /site/api/session/age on the
    # confirm click — browser-verified: 2 POSTs per click). The SPA path
    # never saw it (applyDoc swaps <main> only). The trailing append is
    # REMOVED — exactly ONE script, inside <main>, like login/fj/settings.
    return _page("Restricted", body + script,
                 description="Restricted section.",
                 noindex=True,
                 # V26 (fresh first-click Age Gate): NO welcome overlay on
                 # the interstitial — the full-screen #wintro layer sat on
                 # top of the "I am 18 or older" button for ~2.9 s on the
                 # first page of a fresh session, swallowing the user's
                 # FIRST tap (bot-37.log: three fresh sessions each
                 # re-requested /site/c/adult before the age confirm POST
                 # fired). The gate must be immediately interactive; the
                 # one-time intro still shows on the next (content) page.
                 no_intro=True)


# -------------------------------------------------------------- network
def network_page(data: Dict[str, Any], *,
                 username: str = "") -> str:
    """The Network Mini App surface (spec §9): the user's network bots,
    points balance + recent ledger, and the public bot directory with
    health — all from the AUTHENTICATED identity, no secrets."""
    who = ("@" + username if username else "Telegram User")
    pts = data.get("points") or {}
    lines = [
        '<div class="feedhead"><div><h1 class="feedtitle">My Network</h1>',
        '<div class="feedmeta">👤 ' + esc(who) + " — ⭐ "
        + esc(str(pts.get("balance", 0))) + " points</div></div></div>",
        '<div class="netgrid">',
    ]
    my_bots = data.get("my_bots") or []
    if my_bots:
        lines.append('<section class="netcard"><h2>My bots</h2><ul class="netlist">')
        for b in my_bots[:10]:
            status = str(b.get("status") or "?")
            icon = {"ACTIVE": "🟢", "PENDING": "⚠️", "DEGRADED": "🟡"}.get(
                status, "🔴")
            lines.append(
                '<li><span class="netname">' + icon + " @"
                + esc(str(b.get("username") or "?"))
                + '</span><span class="netmeta">'
                + esc(status) + " · health "
                + esc(str(b.get("health") or "UNKNOWN")) + "</span></li>")
        lines.append("</ul></section>")
    else:
        lines.append(
            '<section class="netcard"><h2>My bots</h2>'
            '<p class="empty">No bots registered yet. Use /network in the '
            "bot to register a network bot and earn points.</p></section>")
    ledger = data.get("ledger") or []
    if ledger:
        lines.append('<section class="netcard"><h2>Recent points</h2><ul class="netlist">')
        for e in ledger[:8]:
            delta = int(e.get("delta") or 0)
            cls = "pos" if delta > 0 else "neg"
            lines.append(
                '<li><span class="netname">' + esc(str(e.get("reason")
                                                    or "points"))
                + '</span><span class="netmeta ' + cls + '">'
                + ("+" if delta > 0 else "") + str(delta) + "</span></li>")
        lines.append("</ul></section>")
    directory = data.get("directory") or []
    if directory:
        lines.append('<section class="netcard"><h2>Network directory</h2><ul class="netlist">')
        for b in directory[:12]:
            status = str(b.get("status") or "?")
            icon = {"ACTIVE": "🟢", "PENDING": "⚠️", "DEGRADED": "🟡"}.get(
                status, "🔴")
            lines.append(
                '<li><span class="netname">' + icon + " @"
                + esc(str(b.get("username") or "?"))
                + '</span><span class="netmeta">'
                + esc(str(b.get("health") or "UNKNOWN")) + "</span></li>")
        lines.append("</ul></section>")
    lines.append("</div>")
    return _page("My Network", "".join(lines),
                 description="Your network bots and points.",
                 noindex=True)


# --------------------------------------------------------------- static
def about_page() -> str:
    body = (
        '<div class="centerwrap"><div class="aboutbox">'
        '<div class="logoglyph"><span class="dot"></span></div>'
        "<h1>About EndieFans</h1>"
        "<p>A premium payload delivery platform on Telegram. Browse the "
        "catalog, open payloads, and stream media right here — with the "
        "same verified access the bot enforces.</p>"
        '<ul class="aboutlist">'
        "<li>🔐 Telegram-verified identity</li>"
        "<li>📶 Force-Join enforced access</li>"
        "<li>🎬 Direct in-app streaming</li>"
        "<li>🌐 A network of delivery bots</li>"
        "</ul>"
        '<p class="fineprint">Open the bot in Telegram to unlock and '
        "receive payloads.</p>"
        '<a class="backlink" href="' + site_url("site") + '">'
        + _icon("arrow-left") + "Back</a></div></div>")
    return _page("About", body, description="About the platform.")


def settings_page(*, username: str = "", age_ok: bool = False) -> str:
    """Client-side settings — the THEME section (V25 §17: dark / light
    ONLY, persisted in localStorage "eutheme" only, never in URLs). The
    "System" option was REMOVED from the user-facing control; a legacy
    stored "system" value is migrated ONCE to the resolved device
    preference by the no-flash boot script (see html.py _THEME_BOOT_JS) —
    the user\u2019s stored record is never deleted, sessions are never
    broken, and there is no theme flash (the boot resolves before first
    paint exactly as before). The page renders through _page(), so it
    inherits that boot; the two explicit buttons below write the same key.
    """
    who = ("@" + username if username else "Telegram User")
    body = (
        '<div class="centerwrap"><div class="aboutbox">'
        "<h1>Settings</h1>"
        '<p class="loginlead">👤 ' + esc(who) + "</p>"
        '<div class="themerow" role="group" aria-label="Theme">'
        '<button class="themechoice" id="themedark" type="button">'
        "🌙 Dark</button>"
        '<button class="themechoice" id="themelight" type="button">'
        "☀️ Light</button>"
        "</div>"
        '<div id="setstate" class="loginstate" hidden aria-live="polite">'
        "</div>"
        '<p class="fineprint">Theme preference is stored on this device '
        "only."
        "</p>"
        '<a class="backlink" href="' + site_url("site") + '">'
        + _icon("arrow-left") + "Back</a></div></div>")
    script = """
<script>
(function(){
  var buttons={dark:document.getElementById('themedark'),
               light:document.getElementById('themelight')};
  var st=document.getElementById('setstate');
  function pref(){
    try{var s=localStorage.getItem('eutheme');
      return (s==='light')?'light':'dark';}catch(e){return 'dark';}
  }
  function apply(){
    document.documentElement.setAttribute('data-theme',pref());
    var mt=document.querySelector('meta[name="theme-color"]');
    if(mt){mt.setAttribute('content',
      pref()==='light'?'#f7f8fa':'#05060a');}
  }
  function paint(){
    var p=pref();
    for(var k in buttons){
      if(!buttons[k]){continue;}
      buttons[k].setAttribute('aria-pressed',(k===p)?'true':'false');
    }
  }
  function note(msg,ok){ if(!st){return;} st.hidden=false;
    st.className='loginstate '+(ok?'ok':'bad'); st.textContent=msg; }
  for(var key in buttons){
    (function(k,btn){
      if(!btn){return;}
      btn.addEventListener('click',function(){
        try{localStorage.setItem('eutheme',k);}
        catch(e){note('Storage unavailable.',false);return;}
        apply();paint();
        note('Theme set to '+k+'.',true);
      });
    })(key,buttons[key]);
  }
  paint();
})();
</script>"""
    # V26 script-placement fix: INSIDE <main> (see login_page) — the SPA
    # swap re-creates scripts inside main ONLY; a trailing script after
    # </html> left the theme buttons handler-less on SPA navigation.
    return _page("Settings", body + script,
                 description="Site settings.")


def collections_page(items: List[Dict[str, Any]], *,
                     thumb_urls: Optional[Dict[str, str]] = None,
                     user: Optional[dict] = None,
                     categories: Optional[list] = None,
                     age_ok: bool = False) -> str:
    """Collections view (the More menu entry): collection-type listings."""
    from app.web.site.html import card
    tu = thumb_urls or {}
    cards = "".join(
        card(dict(i, is_collection=True), index=n, thumb_url=tu.get(
            str(i.get("opaque_id") or ""), ""))
        for n, i in enumerate(items)) or (
        '<div class="empty"><span class="eglyph">\U0001F4C1</span>'
        "<b>No collections yet</b>Publish a collection to the website to "
        "see it here.</div>")
    body = ('<div class="feedhead"><div><h1 class="feedtitle">Collections'
            '</h1><div class="feedmeta">Curated multi-part payloads</div>'
            "</div></div>" + '<div class="grid">' + cards + "</div>")
    return _page("Collections", body, show_search=True, user=user,
                 categories=categories, age_ok=age_ok,
                 description="Browse collections.")
