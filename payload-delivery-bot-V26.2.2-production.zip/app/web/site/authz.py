"""B23 / P0-1 — WEBSITE PLAYBACK AUTHORIZATION (the one-rule module).

The authoritative separation the operator decided after bot-23.log:

    Telegram:  Force Join → Telegram Watch Ad → Telegram delivery
    Website:   Force Join → age/access/security → website pre-roll → PLAY

The Telegram payload Watch-Ad gate (reason="watch_ad_required" from the
EXISTING Access Engine — ``app/presentation/telegram/access.py``) is a
TELEGRAM-side delivery requirement. It is NOT a website playback
requirement: the website runs its own INDEPENDENT ad system
(``preroll.py`` / ``video_ads.py`` — /site/api/ads/decision +
/site/api/ads/event), which fires according to its own configuration.

``authorize_website_playback()`` runs the SAME Access Engine verdict every
other surface uses (never a second engine) and then applies the
website-specific interpretation:

  * every denial reason stays ENFORCED — force_join_required,
    referral_required, points_locked, payload_missing, policy_unknown …
  * EXCEPT "watch_ad_required", which is WAIVED for website playback
    (bot-23.log 01:11:15/01:11:26: a real user with Force Join satisfied
    was still denied website streams by the Telegram ad gate). The
    Telegram delivery path continues to enforce it via ``enforce_access``
    — the two systems remain independent.

The waiver is SAFE with respect to Force Join: the engine only ever
produces watch_ad_required AFTER the base policy (including Force Join)
authorized (``_apply_watch_ad_gate`` returns earlier reasons untouched),
so a waived verdict never skips a Force-Join denial.

Every verdict is structured so log lines are unambiguous: the engine
reason is preserved verbatim (``engine_reason``) and the website-level
reason (``reason``) records the waiver explicitly.

V26.2-bot42 (TASK A2): engine EXCEPTIONS are never silently swallowed —
``log_website_engine_failure`` emits an ERROR-level telemetry line with
ONLY safe fields (the exact production 500 was a NameError masked at
DEBUG level, invisible in the bot-42 log). Never logged: BOT_TOKEN,
Telegram authorization headers, initData, stream tokens, session tokens,
cookies, HMAC secrets.
"""
from __future__ import annotations

import hashlib
import inspect
import logging
import re
import traceback
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger("payload-bot")

# The ONE engine reason the website playback path waives (constants stay
# owned by app/core/constants.py — duplicated here only as the literal the
# website layer gates on, so this module has zero import cycles).
_WATCH_AD_REQUIRED = "watch_ad_required"

# Safe-field sanitisation for engine-failure telemetry: redact anything
# shaped like a bot token, a long base64/hex blob, or an Authorization
# header value. Engine exceptions are internal programming errors, but
# the discipline is defense-in-depth (nothing secret ever reaches a log).
_SECRET_SHAPES = re.compile(
    r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b"          # <bot_id>:<token>
    r"|[A-Za-z0-9+/_-]{120,}"                    # long opaque blobs
    r"|\b(?:Bearer|Basic)\s+\S+",                # authorization headers
    re.IGNORECASE)


def _sanitize_exc_text(text: str, limit: int = 180) -> str:
    """Redact secret-shaped substrings + bound the length (safe to log)."""
    try:
        out = _SECRET_SHAPES.sub("<redacted>", str(text or ""))
    except Exception:  # noqa: BLE001 — never fail the log line
        out = ""
    return out[:limit]


def _classify_engine_failure(exc: BaseException) -> str:
    """Map the exception's traceback to the DEPENDENCY STAGE that raised.

    Walks the frames (innermost last → outermost) and returns the FIRST
    matching stage from the inside out — the true origin of the failure:
      access_engine / force_join_service / membership_verification /
      policy_lookup / watch_ads_gate / points_gate / db_layer /
      namespace_resolution / another_dependency
    """
    try:
        frames = traceback.extract_tb(exc.__traceback__)
    except Exception:  # noqa: BLE001
        return "another_dependency"
    for fs in reversed(frames):
        f = str(fs.filename or "").replace("\\", "/")
        if f.endswith("app/presentation/telegram/access.py"):
            fn = str(fs.name or "")
            if fn in ("_fj_slice_for", "_fj_verifier_bot"):
                return "force_join_slice"
            if fn == "_apply_watch_ad_gate":
                return "watch_ads_gate"
            return "access_engine"
        if f.endswith("app/core/force_join/service.py"):
            fn = str(fs.name or "")
            if fn in ("check_membership", "is_member"):
                return "membership_verification"
            if fn in ("fj_gate_view", "fj_gate_unjoined"):
                return "fj_gate_unjoined"
            return "force_join_service"
        if f.endswith("app/core/watch_ads/service.py"):
            return "watch_ads_gate"
        if f.endswith("app/core/access/engine.py"):
            return "points_gate"
        if f.endswith("app/presentation/telegram/namespace.py"):
            return "namespace_resolution"
        if "/app/storage/" in f or f.endswith("dbutil.py"):
            return "db_layer"
        if f.endswith("app/web/site/authz.py"):
            return "authz_wrapper"
    return "another_dependency"


def _safe_gate_key(gate_key: Optional[str]) -> str:
    """Safe gate-key telemetry: the prefix + a short digest (the website
    key's listing/file_pk components are public URL parts; the bot-side
    link_arg is a public deep-link argument — but the digest keeps the
    line uniformly bounded regardless of shape)."""
    gk = str(gate_key or "")
    if not gk:
        return "-"
    digest = hashlib.sha256(gk.encode("utf-8")).hexdigest()[:8]
    return f"{gk[:24]}~{digest}"


def log_website_engine_failure(stage: str, exc: BaseException, *,
                               user_id: int = 0, payload_id: Any = None,
                               file_pk: Any = None,
                               gate_key: Optional[str] = None) -> None:
    """TASK A2 — SAFE ERROR-level telemetry for an engine exception.

    ``stage`` is the WEBSITE call surface (stream_issuance / hls_reverify /
    access_api / pack_issue / download_gate). The dependency stage where
    the exception originated is classified from the traceback. Fields:
    user_id, payload_id, file_pk, safe gate-key, exception class, the
    classified failure stage, a sanitized message head. NEVER: tokens,
    initData, session/Authorization material (see _sanitize_exc_text).
    The full traceback stays at DEBUG (local diagnosis; the ERROR line is
    the production signal).
    """
    try:
        logger.error(
            "WEBSITE_ACCESS_ENGINE_ERROR surface=%s failure_stage=%s "
            "user_id=%s payload_id=%s file_pk=%s gate_key=%s "
            "exception=%s detail=%s",
            str(stage or "-")[:32],
            _classify_engine_failure(exc),
            int(user_id or 0),
            (int(payload_id) if payload_id is not None else "-"),
            (int(file_pk) if file_pk is not None else "-"),
            _safe_gate_key(gate_key),
            type(exc).__name__,
            _sanitize_exc_text(exc))
        logger.debug("website engine failure traceback", exc_info=exc)
    except Exception:  # noqa: BLE001 — telemetry must never raise
        pass

# Bounded once-per-(user,payload) waiver log memo: the gateway re-verifies
# EVERY media/segment request, so a waived playback would otherwise emit
# one waiver line per range/segment (log spam). The FIRST waiver for a
# (user, payload) is logged at INFO; repeats within the process are
# silent (bounded FIFO — never a leak).
_WAIVER_LOGGED: dict = {}
_WAIVER_LOG_MAX = 512


def _waiver_log_key(user_id: int, payload_id) -> tuple:
    return (int(user_id or 0), int(payload_id or 0))


def _should_log_waiver(user_id: int, payload_id) -> bool:
    key = _waiver_log_key(user_id, payload_id)
    if key in _WAIVER_LOGGED:
        return False
    _WAIVER_LOGGED[key] = True
    if len(_WAIVER_LOGGED) > _WAIVER_LOG_MAX:
        # FIFO evict the oldest inserts (dicts preserve insertion order).
        for k in list(_WAIVER_LOGGED)[:-_WAIVER_LOG_MAX]:
            _WAIVER_LOGGED.pop(k, None)
    return True


@dataclass
class WebsitePlaybackVerdict:
    """Structured outcome of a website-playback authorization.

    Attributes:
        authorized:   the WEBSITE-level decision (True = may play/stream).
        reason:       the effective website reason. For an engine denial
                      this is the engine reason verbatim; for the waived
                      watch-ad case it is "watch_ad_waived_for_website"
                      (an authorized verdict).
        engine_reason: the RAW Access Engine reason — never rewritten, so
                      operators can always see what the engine itself said.
        waived_reason: the engine reason that was waived for website
                      playback (only ever "watch_ad_required"), or None.
        result:       the original AccessResult (not_joined channel views,
                      referral context, points context … are read from it
                      by the callers — the engine object is authoritative).
    """
    authorized: bool
    reason: str
    engine_reason: str
    waived_reason: Optional[str] = None
    result: Any = None

    @property
    def engine_result(self) -> Any:
        return self.result


async def authorize_website_playback(deps: Any, bot: Any, user_id: int,
                                     *, payload_id: Optional[int] = None,
                                     gate_key: Optional[str] = None
                                     ) -> WebsitePlaybackVerdict:
    """The website playback authorization chokepoint (spec §1.2).

    Accepts the SAME inputs the stream/access/pack/HLS handlers used to
    pass to ``deps.access_engine`` and returns a structured verdict:

      * engine authorized                  → authorized verdict (engine
        reason preserved — e.g. "watch_ad_unlocked" stays informative);
      * engine denied, reason == watch_ad_required → AUTHORIZED for the
        website with waived_reason="watch_ad_required" (the Telegram
        delivery path still enforces the gate — never weakened here);
      * engine denied, any other reason    → denied verdict (reason kept).

    V26.2 (bot-41 §16-§24): ``gate_key`` threads the PER-GATE progressive
    Force-Join batching context into the engine (website keys: the
    canonical (listing, file_pk) pair — or the listing for pack-level
    authorization). With a gate key the engine's Force-Join slice is THIS
    gate's pinned batch (satisfied = the pinned batch is live-verified
    joined — the progressive unlock); without one the legacy
    full-requirement verdict applies unchanged. The gate key is derived
    SERVER-side from the signed stream token / listing resolution — never
    from client input.

    Engine exceptions propagate to the caller (the handlers map them to
    honest 5xx responses — through ``log_website_engine_failure`` the
    actual exception is now VISIBLE at ERROR level with safe fields).
    """
    # V26.2-bot42: the legacy ``except TypeError: retry without gate_key``
    # shape is replaced by an explicit signature probe — a GENUINE
    # TypeError raised inside the engine body (e.g. int(None)) used to be
    # retried once and then surface as an opaque engine_error; the probe
    # cannot misclassify, and a real engine TypeError now propagates
    # directly (and is classified by the telemetry).
    engine = getattr(deps, "access_engine", None)
    _accepts_gate_key = False
    try:
        _params = inspect.signature(engine).parameters
        _accepts_gate_key = "gate_key" in _params \
            or any(p.kind == inspect.Parameter.VAR_KEYWORD
                   for p in _params.values())
    except (TypeError, ValueError):
        _accepts_gate_key = False
    try:
        if _accepts_gate_key:
            res = await engine(bot, user_id, payload_id=payload_id,
                               gate_key=gate_key)
        else:
            # A deps snapshot wired to a legacy engine signature (no
            # gate_key) — call unchanged (legacy full-requirement verdict).
            res = await engine(bot, user_id, payload_id=payload_id)
    except TypeError as exc:
        # Signature mismatch on a NON-probed callable (e.g. a bound
        # partial without inspectable params): retry the legacy shape —
        # but only when the TypeError clearly originates from the CALL
        # binding, never for an engine-body TypeError (which propagates).
        if _accepts_gate_key and "gate_key" not in str(exc):
            raise
        try:
            res = await engine(bot, user_id, payload_id=payload_id)
        except TypeError:
            raise
    engine_reason = str(getattr(res, "reason", "denied") or "denied")
    if bool(getattr(res, "authorized", False)):
        return WebsitePlaybackVerdict(
            authorized=True, reason=engine_reason,
            engine_reason=engine_reason, waived_reason=None, result=res)
    if engine_reason == _WATCH_AD_REQUIRED:
        # THE website rule: the Telegram payload Watch-Ad requirement does
        # not gate website playback. Waived honestly + loudly (once per
        # (user, payload) per process — the media gateway re-verifies on
        # EVERY range/segment request and must not spam the log) — the log
        # line is unambiguous about WHICH system decided what.
        if _should_log_waiver(user_id, payload_id):
            logger.info(
                "WEBSITE_PLAYBACK_WATCH_AD_WAIVED user_id=%s payload_id=%s "
                "engine_reason=%s (the Telegram payload Watch-Ad requirement "
                "does not gate website playback — the website pre-roll ad "
                "system fires independently per its own configuration)",
                user_id, payload_id or 0, engine_reason)
        return WebsitePlaybackVerdict(
            authorized=True, reason="watch_ad_waived_for_website",
            engine_reason=engine_reason,
            waived_reason=_WATCH_AD_REQUIRED, result=res)
    return WebsitePlaybackVerdict(
        authorized=False, reason=engine_reason,
        engine_reason=engine_reason, waived_reason=None, result=res)
