"""WEBSITE PHASE 3 — the aiohttp handlers + route registration.

Route surface (spec §7, exact naming follows the existing conventions):

  GET  /site                                  — Payload feed (cards, pagination)
  GET  /site/c/{slug}                         — CATEGORY page (B10-W2 spec
                                                §18/§19/§23): the destination
                                                the category chips / ⋮ More
                                                entries link to; restricted
                                                categories serve the 18+ age
                                                gate until confirmed
  GET  /site/search                           — normalized DB-side search
  GET  /site/payload/{opaque_id}              — Payload DETAIL (ordered file
                                                list, Part 1..N)
  GET  /site/payload/{opaque_id}/video/{ref}  — file selection page (the
                                                Phase 3 minimum authorization
                                                boundary; playback transport
                                                is Phase 4)
  POST /site/api/auth                         — Mini App initData validation
                                                (multi-token, server-side)
  POST /site/api/access                       — Access Engine verdict for a
                                                selected file

EVERY handler first checks the GLOBAL website_enabled setting and renders
the maintenance response when OFF (spec §5/§6). That check lives HERE —
never inside the Access Engine, never inside Telegram-facing endpoints.

The handlers are registered on the EXISTING Mini App application by
bot.py's ``start_mini_app_server`` (AFTER the pinned Watch Ads routes).
aiohttp is imported lazily/optionally (the module stays importable without
it — same discipline as the rest of app/web).
"""
from __future__ import annotations

import logging
import time
from datetime import datetime as _dt, timedelta as _td, timezone as _tz
from typing import Any, Dict, List, Optional

from app.web.site import ratelimit
from app.web.site import html as _html
from app.web.site import screens as _screens
from app.web.site.service import make_website_service
from app.web.site.session import (
    SESSION_COOKIE_NAME,
    clear_cookie_header,
    identity_matches,
    make_site_session_codec,
    session_cookie_header,
)
from app.web.site.tokens import make_video_token_codec

logger = logging.getLogger("payload-bot")

try:  # pragma: no cover — optional dependency, same as bot.py
    from aiohttp import web as _aiohttp_web
except Exception:  # noqa: BLE001
    _aiohttp_web = None  # type: ignore[assignment]

# Bounded feed page size (DB-side pagination; spec §8/§22).
SITE_PAGE_SIZE = 12

# PHASE 5 bounded rendering: maximum file rows / parts pills / AEAD video
# refs minted for one anonymous detail or player request. Membership and
# stream authorization NEVER use this cap (they resolve the full canonical
# list); only the RENDERED surface is bounded — a thousand-part collection
# renders Part 1..200 plus an honest "+N more parts" note.
MAX_DETAIL_FILES = 200

# BOT-11 (spec §15): the Website Get File debounce/idempotency guard —
# a per-(user, listing) IN-PROCESS window. Rapid duplicate POSTs inside
# the window return the SAME link JSON instead of minting twice
# (WEBSITE_GET_FILE_GUARDED); a LATER click (beyond the window) goes
# through the random selection again and MAY pick a different eligible
# registered bot (multi-click distribution — no cross-request
# stickiness beyond the window).
GETFILE_GUARD_WINDOW_SECONDS = 2.0
_GETFILE_GUARD: Dict[str, Any] = {}
_GETFILE_GUARD_MAX_KEYS = 2048  # bounded in-process memory
# BOT-11 §15 (concurrent-click hardening): a per-(user, listing)
# asyncio.Lock — a browser double-click fires CONCURRENT in-flight POSTs
# that all pass the timestamp guard before any response lands (a pure
# TOCTOU race minting N links for one user action). The lock serializes
# the storm; the re-check after acquisition returns the leader's cached
# link. Errors are never cached, so a failed leader still lets the
# follower run its own honest attempt.
_GETFILE_LOCKS: Dict[str, Any] = {}
_GETFILE_LOCKS_MAX_KEYS = 2048
# Indirection point so tests can advance the clock deterministically.
_getfile_clock = time.monotonic

_deps_factory = None


# ------------------------------------------------- session / gating layer
def _session_codec(deps: Any):
    """The site session codec (per-request; AEAD, deterministic key)."""
    return make_site_session_codec(getattr(deps, "bot_token", None))


async def _session_of(request, deps: Any) -> Optional[Dict[str, Any]]:
    """Resolve the site session from the cookie. Fails closed (None) on
    any problem. Grants IDENTITY ONLY — never payload access."""
    try:
        raw = request.cookies.get(SESSION_COOKIE_NAME, "")
        if not raw:
            return None
        return _session_codec(deps).decode_session(raw)
    except Exception:  # noqa: BLE001
        return None


async def _require_session_page(request, deps: Any):
    """Session gate for content pages: returns (session, response) — when
    the response is not None the caller must return it (the LOGIN screen
    for anonymous visitors, spec §21/§22)."""
    session = await _session_of(request, deps)
    if session is not None:
        return session, None
    return None, _aiohttp_web.Response(
        text=_screens.login_page(), content_type="text/html")


async def _fj_gate_response(request, deps: Any, session: Dict[str, Any],
                            unjoined: List[Any],
                            gate_key: str = ""):
    """BOT-16 (Work Item A): the ONE Join Required page render every gated
    surface shares — the SAME ``screens.fj_gate_page`` the feed uses, plus
    the honest aggregate FJ health (the gate's DEGRADED banner, spec §15)
    and the CURRENT page as the ``return_to`` target so a successful
    Verify reloads back to where the user actually was (the feed, the
    payload detail, the player) instead of always the feed.

    V26.2 (bot-41 §16-§24): ``gate_key`` threads the per-gate context so
    the Verify round-trip re-checks THIS gate's pinned batch (the server
    re-derives everything — the key is only a selector, never an input
    the client can influence authorization with)."""
    return _aiohttp_web.Response(
        text=_screens.fj_gate_page(
            _fj_views(deps, unjoined),
            username=str(session.get("username") or ""),
            fj_health=await _fj_health_summary(deps),
            return_to=_request_return_to(request),
            gate_key=gate_key),
        content_type="text/html")


def _request_return_to(request) -> str:
    """BOT-16: the site-relative return target for the Join gate Verify
    flow — the CURRENT page (path + bounded query) so a successful verify
    reloads back to the page the user was trying to open. Built
    SERVER-side only (never client input); ``screens.fj_gate_page``
    re-sanitizes (same-site path only) before it ever reaches an href."""
    try:
        path = str(getattr(request, "path", "") or "")
    except Exception:  # noqa: BLE001
        return ""
    if not path.startswith("/") or path.startswith("//"):
        return ""
    q = ""
    try:
        q = str(getattr(request, "query_string", "") or "")
    except Exception:  # noqa: BLE001
        q = ""
    q = q.lstrip("?")
    out = path + (("?" + q) if q else "")
    return out[:512]


async def _fj_gate(deps: Any, session: Dict[str, Any], *,
                   payload_id: Optional[int] = None,
                   gate_key: Optional[str] = None):
    """The website Force-Join gate (spec §24): the SAME authoritative
    batch view as the Telegram side, live-checked with the site's bot
    reference. Returns (unjoined_rows, needs_gate, verify_failed). Any
    failure FAILS OPEN to the gate only when FJ is verifiably active — never
    silently bypasses (fail-closed) and never blocks when FJ is off.

    ``verify_failed`` (spec §14/§15) marks a check that could not be
    PERFORMED (exception mid-check): the caller must NEVER interpret an
    empty unjoined list in that state as "joined" — the user is not
    blamed and gets the verification-unavailable retry state.

    B24 (Phase 5): ``payload_id`` is forwarded to the canonical FJ service
    so per-payload HTML pages record the payload unlock correctly (the
    top-level feed/search/category pages pass None — symmetric with the
    Telegram gate-page renderer which also passes None).

    V26.2 (bot-41 §16-§24): ``gate_key`` selects the PER-GATE progressive
    batching view (``fj_gate_unjoined``) — the pinned batch THIS gated
    playback presented, never a future batch, never the full requirement
    list. Without a gate_key the legacy full-requirement view applies
    (feed-level surfaces and admin diagnostics — unchanged)."""
    try:
        fj_active = getattr(deps, "fj_active", None)
        if fj_active is None or not await fj_active():
            return [], False, False
        # Admin exemption — the SAME first check the Access Engine applies
        # (admins are never gated by Force Join).
        is_admin = getattr(deps, "is_admin", None)
        if is_admin is not None:
            try:
                if await is_admin(int(session.get("user_id") or 0)):
                    return [], False, False
            except Exception:  # noqa: BLE001 — fall through to the check
                pass
        bot_ref = getattr(deps, "bot_ref", None)
        bot = bot_ref() if callable(bot_ref) else None
        # B24 (Phase 5): loud ERROR when the mini-app bot reference is
        # missing while FJ is active + the user is not admin — operators
        # must see this config gap (the documented Phase 5 limitation #5:
        # bot=None makes the canonical FJ service fail CLOSED for every
        # non-admin user, silently breaking website access to FJ-gated
        # payloads). The check still runs (fail-closed) — the log is the
        # diagnostic, never a bypass.
        if bot is None:
            logger.error(
                "WEBSITE_FJ_BOT_REF_MISSING user_id=%s payload_id=%s "
                "(the mini-app bot is not wired — the canonical FJ service "
                "will fail CLOSED for this non-admin user; verify the "
                "Watch Ads / mini-app server started so _mini_app_bot is set)",
                session.get("user_id"), payload_id)
        if gate_key:
            fj_gate_unjoined = getattr(deps, "fj_gate_unjoined", None)
            if fj_gate_unjoined is not None:
                unjoined = await fj_gate_unjoined(
                    int(session.get("user_id") or 0), str(gate_key), bot,
                    payload_id=payload_id)
                return list(unjoined or []), bool(unjoined), False
            # gate view unavailable on this deps snapshot — fall through to
            # the legacy view (fail-closed, never a bypass).
        fj_unjoined = getattr(deps, "fj_unjoined", None)
        if fj_unjoined is None:
            return [], False, False
        unjoined = await fj_unjoined(int(session.get("user_id") or 0), bot,
                                     payload_id=payload_id)
        return list(unjoined or []), bool(unjoined), False
    except Exception:  # noqa: BLE001 — FJ check failure = show the gate
        logger.warning("WEBSITE_FJ_GATE_ERROR (gate shown)", exc_info=True)
        return [], True, True


def _fj_views(deps: Any, rows: List[Any]) -> List[Dict[str, Any]]:
    """FJ rows → website views (reuse the shared _fj_channel_views)."""
    return _fj_channel_views(rows)


# GAP-CLOSURE spec §14/§15: persisted link-health states that mean the bot
# CANNOT verify this channel right now (channel inaccessible to the bot /
# bot rights problem / transient Telegram error). Such channels are shown
# in the "verification unavailable — retry" state: the user is never
# blamed with "not joined", and membership is never claimed.
_FJ_UNVERIFIABLE_STATES = frozenset({
    "channel_invalid", "bot_permission", "temporary_error",
})
# Link-health states that count as a USABLE join surface: verified-healthy
# invite links + public t.me/<username> links (permanent by design).
_FJ_HEALTHY_STATES = frozenset({"healthy", "unverifiable"})


def _fj_row_link_health(row: Any) -> str:
    """Safely read a force-channel row's persisted link_health state."""
    try:
        keys = row.keys() if hasattr(row, "keys") else []
        if "link_health" not in keys:
            return ""
        return str(row["link_health"] or "").strip().lower()
    except Exception:  # noqa: BLE001
        return ""


async def _fj_health_summary(deps: Any) -> Dict[str, Any]:
    """GAP-CLOSURE spec §15: the honest AGGREGATE Force-Join health report.

    Counts every configured force-join channel (the same policy source the
    bot-side link-health system persists into ``force_join_channels.``
    ``link_health``): ``healthy`` counts verified-usable join surfaces,
    and when fewer than the total are healthy the surface reports
    DEGRADED — never full health (production evidence: 7 configured
    channels, 0 healthy, 7 channel_invalid must surface as degraded,
    healthy=0, total=7). An empty channel list is trivially healthy (the
    gate passes; spec §15).
    """
    try:
        rows = await deps.db.list_force_channels()
    except Exception:  # noqa: BLE001 — honest unknown, never a crash
        logger.warning("WEBSITE_FJ_HEALTH_ERROR (reporting unknown)",
                       exc_info=True)
        return {"fj_health": "unknown", "healthy": 0, "total": 0}
    rows = list(rows or [])
    total = len(rows)
    healthy = sum(1 for r in rows
                  if _fj_row_link_health(r) in _FJ_HEALTHY_STATES)
    if total == 0:
        return {"fj_health": "ok", "healthy": 0, "total": 0}
    return {"fj_health": ("ok" if healthy == total else "degraded"),
            "healthy": healthy, "total": total}


async def _categories_nav(deps: Any, *, age_ok: bool = False):
    """The category navigation data (spec §26-§28): enabled+visible
    categories in admin order.

    B10-W2 (spec §19): age-restricted entries are ALWAYS included (the
    🔞 18+ navigation entry is rendered even BEFORE age confirmation —
    it links to /site/c/{slug} which serves the age gate). The entry
    itself carries NO restricted content: slug + name + icon + the
    age_restricted flag only (never payload titles/counts). The
    ``age_ok`` parameter is kept for call-site compatibility; the FEED
    content filtering (include_age_restricted) is a separate, backend
    enforcement and stays age_ok-gated (spec §22/§29)."""
    try:
        rows = await deps.db.list_website_categories(include_disabled=False)
    except Exception:  # noqa: BLE001
        return []
    out = []
    for r in rows or []:
        try:
            if not int(r["visible"]):
                continue
            out.append({"slug": str(r["slug"]), "name": str(r["name"]),
                        "icon": str(r["icon"] or ""),
                        "age_restricted": bool(int(r["age_restricted"]))})
        except Exception:  # noqa: BLE001
            continue
    return out


def _device_of(request) -> str:
    """Server-side device detection for ad targeting (spec §50)."""
    ua = str(request.headers.get("User-Agent", "") or "").lower()
    if any(k in ua for k in ("mobile", "android", "iphone", "ipad",
                             "ipod", "telegram-android")):
        return "mobile"
    return "desktop"


def _ads_service(deps: Any):
    """The centralized AdsManager (spec §35) — never a second one."""
    from app.ads.service import make_ads_service
    return make_ads_service(deps.db, is_admin=getattr(deps, "is_admin", None))


async def _render_ad(deps: Any, placement: str, *,
                     user_id: Optional[int] = None,
                     session_key: Optional[str] = None,
                     category_slug: Optional[str] = None,
                     device: Optional[str] = None) -> str:
    """One ad slot render (spec §37): returns SAFE html or '' (complete
    collapse). Ads NEVER block content — every failure renders nothing."""
    try:
        svc = _ads_service(deps)
        ad = await svc.get_ad_for_placement(
            placement, user_id=user_id, session_key=session_key,
            category_slug=category_slug, device=device)
        if not ad:
            return ""
        return _ad_html(ad, placement)
    except Exception:  # noqa: BLE001 — spec §44
        logger.warning("ADS_RENDER_ERROR placement=%s", placement)
        return ""


def _ad_html(ad: Dict[str, Any], placement: str) -> str:
    """Render one ad decision dict as SAFE html (banners/html creative).
    Video ads (preroll/midroll/postroll) are delivered through the JSON
    decision API instead — this renders the DISPLAY placements."""
    kind = str(ad.get("kind") or "")
    click = str(ad.get("click_url") or "")
    alt = str(ad.get("alt_text") or "")
    title = str(ad.get("title") or "")
    click_open = (f'<a href="{click}" target="_blank" '
                  'rel="noopener noreferrer" class="adclick">') if click else ""
    click_close = "</a>" if click else ""
    parts = [f'<aside class="adslot ad-{_html.esc(placement.lower())}">']
    parts.append('<span class="adlabel">Ad</span>')
    if kind in ("banner_image", "banner_responsive"):
        desk = str(ad.get("image_desktop") or "")
        mob = str(ad.get("image_mobile") or desk)
        if desk or mob:
            src = mob  # CSS picks the right one below via srcset
            srcset = ""
            if desk and mob and desk != mob:
                srcset = f' srcset="{_html.esc(mob)} 480w, '                          f'{_html.esc(desk)} 1200w" sizes="100vw"'
            # spec §37/§44: a banner that fails to load (network error,
            # dead creative URL) collapses the ENTIRE slot — never a
            # broken-image box. Static inline handler (no user content).
            img = (f'<img src="{_html.esc(src)}" alt="{_html.esc(alt)}"'
                   f'{srcset} loading="lazy" decoding="async"'
                   ' onerror="this.closest(\'.adslot\')'
                   '.classList.add(\'ad-collapsed\')'
                   ';this.style.display=\'none\'">')
            parts.append(click_open + img + click_close)
    elif kind == "html":
        parts.append(str(ad.get("html") or ""))  # pre-sanitized server-side
    elif kind == "provider":
        # Monetag adapter (spec §36): the SDK tag is embedded through the
        # provider zone only — never arbitrary JavaScript from creatives.
        zone = str(ad.get("provider_zone") or "")
        if zone:
            parts.append(
                f'<div class="adprovider" data-zone="{_html.esc(zone)}">'
                "</div>")
    if title:
        parts.append(f'<div class="adtitle">{_html.esc(title)}</div>')
    parts.append("</aside>")
    return "".join(parts)


async def _page_chrome(request, deps: Any, session: Dict[str, Any]):
    """The shared page chrome kwargs (user chip + category nav)."""
    age_ok = bool(session.get("age_ok"))
    return {
        "user": {"username": session.get("username") or "",
                 "first_name": session.get("first_name") or ""},
        "categories": await _categories_nav(deps, age_ok=age_ok),
        "age_ok": age_ok,
    }


async def _nav_chain_for(deps: Any, detail: Dict[str, Any], *,
                         search_back: str = "",
                         payload_opaque: str = "") -> list:
    """V26 FINAL (Parts 6+7) — the CANONICAL navigation chain for a deep
    page, HOME-first: ``["/site", <category-or-search>, <payload>]``.
    The SPA router seeds this chain BEHIND a cold deep entry so every
    Back control walks the canonical hierarchy (PLAY -> PAYLOAD ->
    CATEGORY -> HOME) instead of exiting the website. Best-effort: any
    lookup failure degrades to the shorter honest chain."""
    chain = ["/site"]
    try:
        if search_back:
            chain.append(search_back)
        else:
            listing_dbid = int((detail.get("listing") or {}).get("id") or 0)
            if listing_dbid:
                cats = await deps.db.listing_categories_of(listing_dbid)
                if cats:
                    slug = str(cats[0]["slug"] or "").strip().lower()
                    if slug:
                        chain.append(
                            _html.site_url(f"site/c/{_html.quote_plus(slug)}"))
    except Exception:  # noqa: BLE001 — breadcrumb is best-effort
        pass
    if payload_opaque:
        chain.append(_html.site_url(f"site/payload/{payload_opaque}"))
    return chain


def _register_routes(app, deps_factory):
    """Register the website routes (called from start_mini_app_server —
    additive lines AFTER the pinned Watch Ads routes)."""
    global _deps_factory
    if _aiohttp_web is None:  # pragma: no cover — aiohttp guaranteed there
        return False
    _deps_factory = deps_factory
    app.router.add_get("/site", handle_site_home)
    app.router.add_get("/site/search", handle_site_search)
    app.router.add_get("/site/collections", handle_site_collections)
    app.router.add_get("/site/network", handle_site_network)
    app.router.add_get("/site/about", handle_site_about)
    app.router.add_get("/site/settings", handle_site_settings)
    # B10-W2 (spec §18/§23): the CANONICAL category page route — the
    # destination the header category chips and the ⋮ More entries have
    # linked to since GAP-CLOSURE (html.py site/c/{slug} links) but which
    # was never registered (404). Registered AFTER the literal routes:
    # /site/search, /site/collections, /site/network, /site/about,
    # /site/settings are 2-segment paths and /site/payload/{opaque_id},
    # /site/pack/{token} live under DIFFERENT first segments — the
    # 3-segment dynamic pattern /site/c/{slug} can NEVER swallow any of
    # them (pinned by test_bot10_agegate.py routing checks).
    app.router.add_get("/site/c/{slug}", handle_site_category)
    app.router.add_get("/site/payload/{opaque_id}", handle_site_payload)
    app.router.add_get("/site/payload/{opaque_id}/video/{video_ref}",
                       handle_site_payload_video)
    app.router.add_post("/site/api/auth", handle_site_api_auth)
    app.router.add_post("/site/api/access", handle_site_api_access)
    # GAP-CLOSURE (spec §21-§24/§35/§52/§59): the session/identity layer,
    # the Force-Join Verify Again API, the ads decision/event API and the
    # download-pack surface.
    app.router.add_post("/site/api/session", handle_site_api_session)
    app.router.add_post("/site/api/session/age", handle_site_api_session_age)
    app.router.add_post("/site/api/forcejoin/verify",
                        handle_site_api_fj_verify)
    app.router.add_post("/site/api/ads/decision", handle_site_api_ads_decision)
    app.router.add_post("/site/api/ads/event", handle_site_api_ads_event)
    # V26: the bounded player/age-gate telemetry sink (PLAYER_* +
    # AGE_GATE_* client lifecycle events -> WEBSITE_TELEMETRY log lines).
    app.router.add_post("/site/api/telemetry", handle_site_api_telemetry)
    app.router.add_post("/site/api/pack", handle_site_api_pack)
    app.router.add_get("/site/pack/{token}", handle_site_pack_download)
    # BOT-11 (spec §6-§18): the Website Get File random-delivery API —
    # server-side selection of a RANDOM ELIGIBLE REGISTERED BOT (never the
    # main bot as the normal target) + a durable targeted Global Payload
    # Link mint. The button label state endpoint is public + secret-free.
    app.router.add_post("/site/api/get-file", handle_site_api_get_file)
    app.router.add_get("/site/api/get-file-config",
                       handle_site_api_get_file_config)
    # WEBSITE PHASE 4: the Media Gateway HTTP surface — stream-token
    # issuance, the gateway itself (HEAD/GET/Range) and thumbnail bytes.
    from app.web.site import stream as _stream
    _stream.register_stream_routes(app, deps_factory)
    # B18-FINAL (bot-22.log pass): media engagement (views + like/dislike)
    # and the signed external-browser handoff (Mini App -> browser session
    # transfer — Telegram.WebApp.openLink path).
    from app.web.site import engagement as _engagement
    _engagement.register_engagement_routes(app, deps_factory)
    return True


def _deps() -> Optional[Any]:
    try:
        return _deps_factory() if _deps_factory is not None else None
    except Exception:  # noqa: BLE001
        logger.debug("website deps unavailable", exc_info=True)
        return None


def _tools(deps: Any) -> Any:
    """Per-request presentation tools (website service + video token codec
    + multi-token auth). Built fresh per request — the vault key derivation
    is deterministic from the deployment secret/BOT_TOKEN, and a fresh
    build never holds a stale Database reference."""
    from types import SimpleNamespace
    from app.web.site.auth import make_multi_token_web_auth
    svc = make_website_service(deps.db)
    codec = make_video_token_codec(getattr(deps, "bot_token", None))
    auth = make_multi_token_web_auth(
        getattr(deps, "bot_token", None),
        getattr(deps, "network_tokens", None),
        validate_with_token=_make_single_validator(deps))
    return SimpleNamespace(service=svc, codec=codec, multi_auth=auth)


def _thumb_url(deps: Any, tools: Any, opaque_id: str) -> str:
    """WEBSITE PHASE 4 (spec §23): mint a short-lived PUBLIC thumbnail
    token for a published listing's card art (bound to the listing only —
    user_id=0/file_pk=0/purpose=thumb; the gateway resolves the Phase 3
    priority chain and serves bounded bytes or the honest placeholder).
    Falls back to '' (the styled art) when the gateway is unavailable —
    cards never break."""
    try:
        gw = getattr(deps, "media_gateway", None)
        if gw is None:
            return ""
        if callable(gw) and not hasattr(gw, "handle_stream_request"):
            gw = gw()
        if gw is None or not hasattr(gw, "issue_stream_token"):
            return ""
        token = gw.issue_stream_token(0, str(opaque_id or ""), 0,
                                      purpose="thumb")
        return _html.site_url(f"site/thumb/{token}")
    except Exception:  # noqa: BLE001 — artwork is progressive enhancement
        logger.debug("thumb token mint failed", exc_info=True)
        return ""


def _file_thumb_urls(deps: Any, tools: Any, opaque_id: str,
                     files: List[dict]) -> Dict[int, str]:
    """V25 (§4/§6): per-INNER-MEDIA row thumbnail URLs — one short-lived
    PUBLIC thumb token per stored media record (purpose=thumb bound to
    (listing, file_pk)). The gateway's listing resolver resolves
    file_pk>0 to that specific file's row and serves the file's REAL
    bounded thumbnail bytes (video poster / photo preview) through the
    existing thumbnail infrastructure — never a full-resolution original.
    Only media kinds with visual artwork request a token; documents keep
    the icon tile (no gateway round-trip, no wasted tokens). Failures
    degrade to the plain numbered tile — rows never break."""
    out: Dict[int, str] = {}
    try:
        gw = getattr(deps, "media_gateway", None)
        if gw is None:
            return out
        if callable(gw) and not hasattr(gw, "handle_stream_request"):
            gw = gw()
        if gw is None or not hasattr(gw, "issue_stream_token"):
            return out
        for f in files or []:
            try:
                pk = int(f.get("file_pk") or 0)
            except (TypeError, ValueError):
                continue
            if pk <= 0:
                continue
            mtype = str(f.get("media_type") or "").lower()
            if mtype not in ("video", "animation", "photo", "image"):
                continue
            try:
                token = gw.issue_stream_token(0, str(opaque_id or ""), pk,
                                              purpose="thumb")
                out[pk] = _html.site_url(f"site/thumb/{token}")
            except Exception:  # noqa: BLE001 — one row must never break the page
                continue
    except Exception:  # noqa: BLE001 — progressive enhancement only
        logger.debug("file thumb token mint failed", exc_info=True)
    return out


def _make_single_validator(deps: Any):
    """The canonical single-token validator (app/web/auth.py) — injected so
    the multi-token resolver adds candidates WITHOUT duplicating HMAC code."""
    from app.web.auth import make_web_auth_service
    svc = make_web_auth_service(db=deps.db,
                                BOT_TOKEN=getattr(deps, "bot_token", None))
    return svc._validate_webapp_init_data


# ---------------------------------------------------------------- helpers
async def _enrich_listing_media_counts(deps: Any, items: List[dict]) -> None:
    """B24 (Phase 4): attach a per-kind ``media_counts`` dict to each listing
    item so the outer card badge renders the truthful multi-type summary
    (``"3 videos · 2 photos"``) instead of collapsing to the canonical
    file's single type (``"1 video"``). Two batched queries per page
    (collection items + A.4 membership detection) — never N+1. Also
    corrects ``file_count`` to the truthful total. Defensive: never raises
    (the badge is cosmetic; a failed enrichment falls back to the legacy
    single-type wording via ``_count_label``)."""
    try:
        fn = getattr(deps.db, "batch_listing_media_types", None)
        if not fn:
            return
        counts_map = await fn(items)
        _multi = 0
        for it in items:
            op = str(it.get("opaque_id") or "")
            if not op:
                continue
            mc = counts_map.get(op)
            if mc:
                it["media_counts"] = mc
                total = sum(int(v) for v in mc.values())
                if total > 0:
                    it["file_count"] = total
                # B24 (Phase 8): count multi-type collections so the
                # operator can verify the truthful badge reaches the
                # outer card in production (the bot-27 "1 video" bug).
                if len(mc) > 1:
                    _multi += 1
        if _multi:
            logger.info("WEBSITE_MEDIA_COUNTS multi_type_listings=%s "
                        "page_size=%s (B24 Phase 4: outer card badges "
                        "now render the truthful per-type summary)",
                        _multi, len(items))
    except Exception:  # noqa: BLE001 — enrichment is additive
        pass


def _client_ip(request) -> str:
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        first = fwd.split(",")[0].strip()
        if first:
            return first[:64]
    return str(request.remote or "unknown")[:64]


def _safe_int(value, default: int, lo: int = 1, hi: int = 100000) -> int:
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, n))


# WEBSITE PHASE 3 UX: the public sort whitelist (mirrors the repo's
# _WEBSITE_ORDER_BY keys — the ONLY values accepted from ?sort=; anything
# else falls back to the default curated ordering).
_SORT_KEYS = frozenset({"curated", "newest", "title"})


def _safe_sort(value) -> str:
    s = str(value or "").strip().lower()
    return s if s in _SORT_KEYS else "curated"


def _maintenance_html():
    return _aiohttp_web.Response(text=_html.maintenance_page(),
                                 content_type="text/html", status=503)


def _maintenance_json():
    return _aiohttp_web.json_response(
        {"ok": False, "error": "maintenance",
         "message": "Website is temporarily switched off."},
        status=503)


async def _website_on(deps: Any) -> bool:
    try:
        return await make_website_service(deps.db).website_enabled()
    except Exception:  # noqa: BLE001 — fail CLOSED (maintenance)
        logger.debug("website_enabled check failed — maintenance",
                     exc_info=True)
        return False


async def _published_detail(tools: Any, opaque_id: str
                            ) -> Optional[Dict[str, Any]]:
    """Resolve a listing detail AND enforce public visibility (published +
    resolvable canonical) — dead/unpublished listings are an honest 404."""
    try:
        detail = await tools.service.get_listing_detail(opaque_id)
    except Exception:  # noqa: BLE001
        # PHASE 5 observability: a DB/service FAILURE masked as a 404 is an
        # outage signal — WARNING at the default level (an honestly missing
        # listing never reaches this branch).
        logger.warning("WEBSITE_DETAIL_ERROR opaque_id=%s (request answered "
                       "as 404 — underlying lookup failed)", opaque_id,
                       exc_info=True)
        return None
    if not detail:
        return None
    if not int((detail.get("listing") or {}).get("published") or 0):
        return None
    return detail


async def _listing_age_restricted(deps: Any, listing_id: int) -> bool:
    """B10-W2 (spec §22): TRUE when the listing belongs to ANY
    age-restricted category. The SAME backend predicate the feed/search/
    collections SQL uses (website_payload_categories ⋈ website_categories
    .age_restricted = 1) — reused by every detail/API/stream enforcement
    below so no surface can drift from the DB-side rule. Fails CLOSED
    (True) when the lookup cannot be performed."""
    try:
        cats = await deps.db.list_website_categories_for_listing(
            int(listing_id))
    except Exception:  # noqa: BLE001 — fail CLOSED
        logger.debug("age-restriction lookup failed listing_id=%s",
                     listing_id, exc_info=True)
        return True
    try:
        return any(int(c["age_restricted"]) for c in cats or [])
    except Exception:  # noqa: BLE001 — fail CLOSED
        return True


# ---------------------------------------------------------------- handlers
async def _render_feed_page(request, deps: Any, session: Dict[str, Any],
                            cat_slug: Optional[str] = None, *,
                            cat_name: str = "",
                            cat_restricted: bool = False):
    """The shared CATEGORY-FILTERED FEED renderer (B10-W2 spec §18): the
    exact body /site[?cat=slug] has always rendered, extracted verbatim so
    /site/c/{slug} displays a category through the ONE rendering path (the
    two entries can never diverge). Callers MUST have already enforced the
    session, Force-Join and (for age-restricted categories) the 18+ age
    gate (spec §21/§24/§29) — this function renders feed content only."""
    tools = _tools(deps)
    page = _safe_int(request.query.get("p"), 1)
    sort = _safe_sort(request.query.get("sort"))
    age_ok = bool(session.get("age_ok"))
    try:
        rows, total = await deps.db.list_website_payloads_paged(
            page=page, page_size=SITE_PAGE_SIZE, order=sort,
            category_slug=cat_slug, include_age_restricted=age_ok)
    except Exception:  # noqa: BLE001 — honest empty feed, never a crash
        # PHASE 5 observability: at the default INFO level a DB outage was
        # indistinguishable from an empty catalog — DEBUG promoted to
        # WARNING so operators see the failure mode.
        logger.warning("WEBSITE_FEED_ERROR page=%s (serving empty feed — "
                       "query failed)", page, exc_info=True)
        rows, total = [], 0
    items = [dict(r) for r in rows]
    # B24 (Phase 4): attach truthful per-kind media_counts to each listing
    # so the outer card badge renders "3 videos · 2 photos" instead of
    # collapsing to the canonical file's single type ("1 video"). Two
    # batched queries per page — never N+1. Defensive: never raises.
    await _enrich_listing_media_counts(deps, items)
    thumb_urls = {str(r.get("opaque_id") or ""): _thumb_url(
        deps, tools, str(r.get("opaque_id") or "")) for r in items}
    # Ad slots (spec §37): server-decided, complete collapse when empty.
    uid = int(session.get("user_id") or 0) or None
    skey = str(session.get("session_key") or "") or None
    device = _device_of(request)
    ad_slots = {}
    ad_top = await _render_ad(deps, "AD_TOP", user_id=uid, session_key=skey,
                              category_slug=cat_slug, device=device)
    if cat_slug:
        ad_top = (await _render_ad(
            deps, "AD_CATEGORY_TOP", user_id=uid, session_key=skey,
            category_slug=cat_slug, device=device)) or ad_top
    if ad_top:
        ad_slots["top"] = ad_top
    between = []
    if items:
        n_between = max(0, (len(items) - 1) // 6)
        for i in range(n_between):
            placement = ("AD_CATEGORY_BETWEEN" if cat_slug
                         else "AD_HOME_BETWEEN_CONTENT")
            slot = await _render_ad(deps, placement, user_id=uid,
                                    session_key=skey,
                                    category_slug=cat_slug, device=device)
            if slot:
                between.append(slot)
    if between:
        ad_slots["between"] = between
    footer = await _render_ad(deps, "AD_FOOTER", user_id=uid,
                              session_key=skey, category_slug=cat_slug,
                              device=device)
    if footer:
        ad_slots["footer"] = footer
    chrome = await _page_chrome(request, deps, session)
    return _aiohttp_web.Response(
        text=_html.feed_page(items, page=page, total=total,
                             page_size=SITE_PAGE_SIZE, sort=sort,
                             thumb_urls=thumb_urls, ad_slots=ad_slots,
                             cat_slug=cat_slug, cat_name=cat_name,
                             cat_restricted=cat_restricted,
                             **chrome),
        content_type="text/html")


async def handle_site_home(request):
    """GET /site[?cat=slug] — the Payload FEED (spec §21/§24/§26).

    Gate chain: session (Telegram-verified identity, spec §21/§22) →
    age gate for restricted categories (spec §29) → feed with
    category filtering (spec §26) and ad slots (spec §37).

    V26 (Force Join is a PLAYBACK gate): the feed NO LONGER renders the
    Force-Join gate — the payload dashboard/detail and the feeds are
    browseable; Force Join is evaluated ONLY when playback starts (the
    player page + the stream authorization, both of which re-verify
    against the Access Engine). Required flow: Payload Dashboard →
    Select File → Play → Age Gate if required → Force Join if required
    → Watch Ads if configured → Playback."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    if not ratelimit.check_rate("site_page", _client_ip(request)):
        return _aiohttp_web.Response(text=_html.rate_limited_page(),
                                     content_type="text/html", status=429)
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    # Restricted-category age gate (spec §29).
    cat_slug = str(request.query.get("cat") or "").strip().lower() or None
    age_ok = bool(session.get("age_ok"))
    if cat_slug:
        try:
            cat = await deps.db.get_website_category_by_slug(cat_slug)
        except Exception:  # noqa: BLE001
            cat = None
        if cat is None:
            return _aiohttp_web.Response(
                text=_html.not_found_page("No such category."),
                content_type="text/html", status=404)
        if int(cat["age_restricted"]) and not age_ok:
            return _aiohttp_web.Response(
                text=_screens.age_gate_page(
                    username=str(session.get("username") or "")),
                content_type="text/html")
        return await _render_feed_page(
            request, deps, session, cat_slug,
            cat_name=str(cat["name"] or ""),
            cat_restricted=bool(int(cat["age_restricted"])))
    # PROMPT B (bot-25): the home feed is the SHELF layout (B.2.4) —
    # Continue Watching / Trending / New in [category] / Recently added.
    shelves = await _ux_home_shelves(request, deps, session)
    if not shelves:
        return await _render_feed_page(request, deps, session, None)
    chrome = await _page_chrome(request, deps, session)
    body = ('<div class="narrow"><h1 class="pageh">Home</h1>'
            + shelves + "</div>")
    return _aiohttp_web.Response(
        text=_html._page("Home", body, show_search=True, **chrome),
        content_type="text/html")


async def handle_site_category(request):
    """GET /site/c/{slug} — the CANONICAL CATEGORY page (B10-W2, spec
    §18/§19/§23): the route every header category chip and ⋮ More entry
    links to (the links existed since GAP-CLOSURE but the route itself was
    missing — the bot-10.log 404).

    Gate chain — the EXACT pattern of the home category feed: normal
    Telegram Website authentication (the signed site session, spec §21/§22)
    → honest 404 for an unknown slug → 18+ AGE GATE for age_restricted
    categories until the session carries age_ok=true (spec §18/§20: NO
    payload list, NO metadata, NO thumbnails, NO previews, NO media URLs
    before server-side confirmation) → the SAME _render_feed_page the
    /site?cat= flow uses.

    V26 (Force Join is a PLAYBACK gate): the category page NO LONGER
    renders the Force-Join gate (browsing is open to signed-in users;
    playback enforces the requirement).

    §23 routing: the 3-segment dynamic pattern cannot collide with
    /site/search, /site/collections, /site/network, /site/about,
    /site/settings (2 segments) or /site/payload/{opaque_id} and
    /site/pack/{token} (different first segments); registered after the
    literal routes regardless (belt and braces, pinned by tests)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    if not ratelimit.check_rate("site_page", _client_ip(request)):
        return _aiohttp_web.Response(text=_html.rate_limited_page(),
                                     content_type="text/html", status=429)
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    slug = str(request.match_info.get("slug") or "").strip().lower()
    try:
        cat = await deps.db.get_website_category_by_slug(slug)
    except Exception:  # noqa: BLE001 — honest unknown-category 404
        cat = None
    if cat is None:
        return _aiohttp_web.Response(
            text=_html.not_found_page("No such category."),
            content_type="text/html", status=404)
    if int(cat["age_restricted"]) and not bool(session.get("age_ok")):
        # spec §18/§20: the EXISTING 18+ verification interstitial — the
        # age_ok claim is issued ONLY server-side by POST
        # /site/api/session/age (screens.age_gate_page calls it); nothing
        # about the category's payloads is rendered before that succeeds.
        return _aiohttp_web.Response(
            text=_screens.age_gate_page(
                username=str(session.get("username") or "")),
            content_type="text/html")
    return await _render_feed_page(
        request, deps, session, slug,
        cat_name=str(cat["name"] or ""),
        cat_restricted=bool(int(cat["age_restricted"])))


async def handle_site_search(request):
    """GET /site/search?q=..&p=.. — normalized DB-side search over PUBLISHED
    listings (shared tokenization helpers — ONE search system; spec §9)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    if not ratelimit.check_rate("site_page", _client_ip(request)):
        return _aiohttp_web.Response(text=_html.rate_limited_page(),
                                     content_type="text/html", status=429)
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    # V26 (Force Join is a PLAYBACK gate): the search surface no longer
    # renders the Force-Join gate — the feed/detail surfaces are browseable;
    # playback (the player page + the stream authorization) enforces the
    # requirement against the Access Engine.
    tools = _tools(deps)
    query = str(request.query.get("q") or "").strip()[:120]
    page = _safe_int(request.query.get("p"), 1)
    sort = _safe_sort(request.query.get("sort"))
    age_ok = bool(session.get("age_ok"))
    try:
        rows, total = await deps.db.list_website_payloads_paged(
            page=page, page_size=SITE_PAGE_SIZE, query=query or None,
            order=sort, include_age_restricted=age_ok)
    except Exception:  # noqa: BLE001 — honest empty result, never a crash
        # PHASE 5 observability (same rationale as the feed handler).
        logger.warning("WEBSITE_SEARCH_ERROR q_len=%s page=%s (serving "
                       "empty result — query failed)", len(query), page,
                       exc_info=True)
        rows, total = [], 0
    items = [dict(r) for r in rows]
    # B24 (Phase 4): attach truthful per-kind media_counts (search results
    # share the same outer-card badge fix as the feed).
    await _enrich_listing_media_counts(deps, items)
    thumb_urls = {str(r.get("opaque_id") or ""): _thumb_url(
        deps, tools, str(r.get("opaque_id") or "")) for r in items}
    chrome = await _page_chrome(request, deps, session)
    return _aiohttp_web.Response(
        text=_html.search_page(items, query=query, page=page, total=total,
                               page_size=SITE_PAGE_SIZE, sort=sort,
                               thumb_urls=thumb_urls, **chrome),
        content_type="text/html")


async def handle_site_payload(request):
    """GET /site/payload/{opaque_id} — Payload DETAIL: thumbnail, title,
    description, tags, file count and the ordered Part 1..N file list with
    short-lived signed video references (spec §10)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    if not ratelimit.check_rate("site_page", _client_ip(request)):
        return _aiohttp_web.Response(text=_html.rate_limited_page(),
                                     content_type="text/html", status=429)
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    # V26 (Force Join is a PLAYBACK gate — THE core requirement):
    # "Force Join MUST NOT appear when the payload link is merely opened.
    #  It must be evaluated only when playback starts."
    # The payload DETAIL (the Payload Dashboard: thumbnail, description,
    # the ordered file list — "Select File") is therefore browseable by
    # any signed-in session; the requirement is enforced when PLAYBACK
    # starts (the player page below + the stream authorization — both
    # re-verify against the Access Engine). FJ_OPEN_GATE is the safe
    # structured telemetry line for this deliberate non-gating evaluation
    # (NO live Telegram membership calls happen here — the evaluation is
    # deferred, not silently skipped).
    tools = _tools(deps)
    opaque_id = str(request.match_info.get("opaque_id") or "")
    detail = await _published_detail(tools, opaque_id)
    _fj_pid = None
    if detail is not None:
        _canon = detail.get("canonical") or {}
        if _canon.get("kind") == "payload":
            try:
                _fj_pid = int(_canon.get("payload_id") or 0) or None
            except (TypeError, ValueError):
                _fj_pid = None
    logger.info(
        "FJ_OPEN_GATE user_id=%s payload_id=%s listing=%s "
        "decision=open_without_gate (V26: Force Join is evaluated only "
        "when playback starts — the player page and the stream "
        "authorization enforce it)",
        session.get("user_id"), _fj_pid if _fj_pid is not None else "-",
        opaque_id)
    if detail is None:
        return _aiohttp_web.Response(text=_html.not_found_page(),
                                     content_type="text/html", status=404)
    # 18+ backend enforcement (spec §29): a listing in an age-restricted
    # category is INVISIBLE to unconfirmed users (never just hidden UI).
    # B10-W2: the shared _listing_age_restricted predicate (same rule,
    # ONE implementation for every enforcement surface).
    if not bool(session.get("age_ok")) \
            and await _listing_age_restricted(
                deps, int((detail.get("listing") or {}).get("id") or 0)):
        return _aiohttp_web.Response(text=_html.not_found_page(),
                                     content_type="text/html", status=404)
    # Search-state preservation (spec §10): cards arriving from search keep
    # q/p — and the UX continuation also preserves the active sort — so the
    # back link returns to the same results page in the same order.
    q = str(request.query.get("q") or "").strip()[:120]
    p = _safe_int(request.query.get("p"), 1)
    sort = _safe_sort(request.query.get("sort"))
    if q:
        back_href = (_html.site_url("site/search")
                     + f"?q={_html.quote_plus(q)}&p={p}")
        if sort != "curated":
            back_href += f"&sort={_html.quote_plus(sort)}"
        back_label = "Back to results"
    else:
        back_href = _html.site_url("site")
        if sort != "curated":
            back_href += f"?sort={_html.quote_plus(sort)}"
        back_label = "All payloads"
    video_hrefs: Dict[int, str] = {}
    # PHASE 5 bounded rendering: a collection with thousands of items would
    # otherwise mint one AEAD video ref per file and emit unbounded HTML
    # per anonymous request. The RENDERED list is capped (membership/API
    # verification always uses the full canonical list — never this cap).
    files_all = detail.get("files") or []
    files_shown = files_all[:MAX_DETAIL_FILES]
    files_extra = max(0, len(files_all) - len(files_shown))
    for f in files_shown:
        pk = f.get("file_pk")
        if pk:
            token = tools.codec.encode_video_ref(opaque_id, int(pk))
            video_hrefs[int(pk)] = _html.site_url(
                f"site/payload/{opaque_id}/video/{token}")
    thumb_url = _thumb_url(deps, tools, opaque_id)
    # V25 (§4): per-inner-media row thumbnails (bounded Media Gateway
    # bytes — real video posters / photo previews for the file list).
    file_thumbs = _file_thumb_urls(deps, tools, opaque_id, files_shown)
    # V25 (§5): the MEDIA INTEGRITY INVARIANT trace — stored count vs
    # rendered count vs duplicate-skips, loud on every multi-media
    # detail render so a silent drop is observable in production logs
    # (the invariant: valid source media == stored media == rendered
    # rows; any divergence is EXPLICITLY logged, never silent).
    _pks = [int(f.get("file_pk") or 0) for f in files_shown]
    _dupe = len(_pks) - len(set(_pks))
    if len(files_all) > 1 or _dupe:
        logger.info(
            "WEBSITE_MEDIA_INVENTORY listing=%s stored=%s rendered=%s "
            "capped_extra=%s duplicate_pks=%s media_counts=%s "
            "(V25 §5 integrity trace — stored == rendered unless the "
            "MAX_DETAIL_FILES cap applies, which is reported honestly)",
            opaque_id, len(files_all), len(files_shown), files_extra,
            _dupe, detail.get("media_counts"))
    render_detail = dict(detail, files=files_shown)
    chrome = await _page_chrome(request, deps, session)
    uid = int(session.get("user_id") or 0) or None
    skey = str(session.get("session_key") or "") or None
    device = _device_of(request)
    ad_slots = {}
    ad_detail = await _render_ad(deps, "AD_PAYLOAD_DETAIL", user_id=uid,
                                 session_key=skey, device=device)
    if ad_detail:
        ad_slots["detail"] = ad_detail
    # V26 FINAL (Parts 6+7): the canonical chain breadcrumb for the SPA
    # router's cold-deep-entry seeding (Back walks PAYLOAD -> CATEGORY/
    # SEARCH -> HOME, never out of the site).
    search_back = (back_href if q else "")
    nav_chain = await _nav_chain_for(deps, detail,
                                     search_back=search_back)
    return _aiohttp_web.Response(
        text=_html.detail_page(render_detail, video_hrefs=video_hrefs,
                               back_href=back_href,
                               back_label=back_label,
                               thumb_url=thumb_url,
                               files_extra=files_extra,
                               file_thumb_urls=file_thumbs,
                               ad_slots=ad_slots, nav_chain=nav_chain,
                               **chrome),
        content_type="text/html")


async def _legacy_payload_link(deps: Any, detail: Dict[str, Any]) -> str:
    """The v35 legacy MAIN-BOT deep link (t.me/<main>?start=<routing>) —
    the graceful-degradation FALLBACK href rendered under the player (and
    used by the Get File API only when the operator explicitly enables
    ``website_get_file_allow_main_fallback``). Built SERVER-side from the
    canonical routing id + the main bot username; bot-side policy (auth,
    FJ, age/access rules, ad gates) is enforced there, never bypassed.

    Extracted verbatim from the player-page build (BOT-11: the Get File
    random-delivery API needs the SAME link for its main-fallback path —
    ONE definition, never a second URL builder)."""
    payload_link = ""
    try:
        canon = detail.get("canonical") or {}
        routing = str(canon.get("payload") or "").strip()
        if not routing and canon.get("kind") == "collection" \
                and canon.get("collection_id"):
            routing = f"c{canon['collection_id']}"
        bot_ref = getattr(deps, "bot_ref", None)
        bot = bot_ref() if callable(bot_ref) else None
        bot_username = ""
        if bot is not None:
            me = bot.bot if hasattr(bot, "bot") else bot
            try:
                bot_username = str(me.username or "")
            except Exception:  # noqa: BLE001
                bot_username = ""
        if not bot_username:
            try:
                bot_username = str(
                    await deps.db.get_setting("BOT_USERNAME", "") or
                    "").strip()
            except Exception:  # noqa: BLE001
                bot_username = ""
        if routing and bot_username:
            import re as _re_l
            if _re_l.fullmatch(r"[A-Za-z0-9_-]{1,64}", routing) \
                    and _re_l.fullmatch(r"[A-Za-z0-9_]{4,64}", bot_username):
                payload_link = (f"https://t.me/{bot_username}"
                                f"?start={routing}")
    except Exception:  # noqa: BLE001 — the link is a convenience only
        payload_link = ""
    return payload_link


async def handle_site_payload_video(request):
    """GET /site/payload/{opaque_id}/video/{video_ref} — the file selection
    page: the Phase 3 MINIMUM authorization boundary. The page bootstraps
    the Mini App identity check; the server-side verdict comes from
    /site/api/access. The final player transport is Phase 4 — this page
    never fakes playback (spec §10/§23 header scope).

    V26 — the playback gate chain (the required flow: Payload Dashboard →
    Select File → Play → Age Gate if required → Force Join if required →
    Watch Ads if configured → Playback): the Age Gate interstitial renders
    FIRST for age-restricted listings, then the Force-Join gate (this is
    the ONLY page-level FJ surface — payload open no longer gates), then
    the player; the stream authorization re-verifies at transport time."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    if not ratelimit.check_rate("site_video", _client_ip(request)):
        return _aiohttp_web.Response(text=_html.rate_limited_page(),
                                     content_type="text/html", status=429)
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    # V26 — the PLAYBACK gate chain, in the REQUIRED order:
    #   Play → Age Gate if required → Force Join if required →
    #   Watch Ads (the website pre-roll, spec §39/§42 — never blocking,
    #   skip-and-play) → Playback.
    # The player page is the ONLY page-level Force-Join surface left (the
    # feed/category/search/detail pages no longer gate — FJ is evaluated
    # when playback STARTS, not when the payload link is opened). A
    # leaked/held video_ref still never opens the playback surface for an
    # unjoined user: the gate renders BEFORE the ref is decoded (both a
    # valid and an invalid ref produce the Join Required page for an
    # unjoined visitor — no validity hint). The stream authorization
    # (authorize_website_playback → the Access Engine) re-verifies
    # everything at transport time — defense in depth, unchanged.
    tools = _tools(deps)
    opaque_id = str(request.match_info.get("opaque_id") or "")
    detail = await _published_detail(tools, opaque_id)
    if detail is None:
        return _aiohttp_web.Response(text=_html.not_found_page(),
                                     content_type="text/html", status=404)
    _fj_pid = None
    if detail is not None:
        _canon = detail.get("canonical") or {}
        if _canon.get("kind") == "payload":
            try:
                _fj_pid = int(_canon.get("payload_id") or 0) or None
            except (TypeError, ValueError):
                _fj_pid = None
    # 1) AGE GATE if required (the V26 flow step BEFORE Force Join): an
    #    age-restricted listing + an unconfirmed session renders the 18+
    #    interstitial HERE (at Play) — the SAME server-authoritative
    #    screens.age_gate_page (the first-click fix, the
    #    POST /site/api/session/age confirm, the reload-back-to-this-page
    #    behavior). The interstitial leaks nothing about the file (the
    #    video_ref is still undecoded; a valid and an invalid ref render
    #    the identical page). Unrestricted listings skip straight to FJ.
    if not bool(session.get("age_ok")) \
            and await _listing_age_restricted(
                deps, int((detail.get("listing") or {}).get("id") or 0)):
        logger.info(
            "WEBSITE_PLAY_AGE_GATE user_id=%s listing=%s "
            "decision=age_interstitial (V26 play chain: Age Gate before "
            "Force Join)",
            session.get("user_id"), opaque_id)
        return _aiohttp_web.Response(
            text=_screens.age_gate_page(
                username=str(session.get("username") or "")),
            content_type="text/html")
    # 2) FORCE JOIN if required — the playback-time evaluation (FJ_PLAY_GATE
    #    is the V26 telemetry line; the shared _fj_gate keeps the admin
    #    exemption + FJ-off + fail-closed contract).
    #    V26.2 (bot-41 §16-§24): the gate is PER-VIDEO — the gate key is the
    #    canonical (listing, file_pk) pair decoded SILENTLY here (a valid and
    #    an invalid ref still render the IDENTICAL gate page — the decode
    #    result only selects the server-side presentation row, it never
    #    changes the response for an unjoined visitor; the hard ref
    #    validation below stays the authority). Progressive batching: Video 1
    #    presents the current batch, the next gated video presents the NEXT
    #    batch, completed channels never reappear, future batches are never
    #    delivered to this page.
    _video_ref_raw = str(request.match_info.get("video_ref") or "")
    _gate_key = f"w|{opaque_id}"  # listing-level fallback key
    try:
        _dec = tools.codec.decode_video_ref(_video_ref_raw)
        if _dec and _dec.get("listing") == opaque_id:
            _gate_key = f"w|{opaque_id}|{int(_dec.get('file_pk') or 0)}"
    except Exception:  # noqa: BLE001 — key stays listing-level
        pass
    unjoined, needs_gate, _verify_failed = await _fj_gate(
        deps, session, payload_id=_fj_pid, gate_key=_gate_key)
    logger.info(
        "FJ_PLAY_GATE user_id=%s payload_id=%s listing=%s gate_key=%s "
        "needs_gate=%s remaining=%s verify_failed=%s decision=%s (V26: "
        "Force Join evaluated at playback start; V26.2: per-gate "
        "progressive batching)",
        session.get("user_id"),
        _fj_pid if _fj_pid is not None else "-",
        opaque_id, _gate_key, 1 if needs_gate else 0, len(unjoined or []),
        1 if _verify_failed else 0,
        "gate" if needs_gate else "pass")
    if needs_gate:
        return await _fj_gate_response(request, deps, session, unjoined,
                                       gate_key=_gate_key)
    video_ref = str(request.match_info.get("video_ref") or "")
    decoded = tools.codec.decode_video_ref(video_ref)
    if decoded is None or decoded.get("listing") != opaque_id:
        # Tampered / expired / cross-listing reference — fail closed.
        return _aiohttp_web.Response(
            text=_html.bad_request_page(
                "This file link is invalid or has expired. Go back to the "
                "payload and select the file again."),
            content_type="text/html", status=400)
    files = detail.get("files") or []
    part_index = 0
    found = False
    for idx, f in enumerate(files, start=1):
        if int(f.get("file_pk") or 0) == int(decoded.get("file_pk") or 0):
            part_index = idx if len(files) > 1 else 0
            found = True
            break
    if not found:
        return _aiohttp_web.Response(
            text=_html.bad_request_page(
                "This file no longer belongs to the payload."),
            content_type="text/html", status=400)
    href = _html.site_url(
        f"site/payload/{opaque_id}/video/{video_ref}")
    # WEBSITE PHASE 4 (spec §20): the ordered file list of THIS payload
    # (prev/next stay inside the canonical Payload — never unrelated ones)
    # + the listing's thumbnail URL as the player poster.
    # PHASE 5 bounded rendering: pills/refs are minted for at most
    # MAX_DETAIL_FILES parts (the CURRENT file's ref is always included);
    # the full ordered list above remains authoritative for part_index.
    video_hrefs: Dict[int, str] = {}
    current_pk = int(decoded.get("file_pk") or 0)
    for f in files[:MAX_DETAIL_FILES]:
        pk = f.get("file_pk")
        if pk:
            ref = video_ref if int(pk) == current_pk \
                else tools.codec.encode_video_ref(opaque_id, int(pk))
            video_hrefs[int(pk)] = _html.site_url(
                f"site/payload/{opaque_id}/video/{ref}")
    if current_pk and current_pk not in video_hrefs:
        video_hrefs[current_pk] = href  # current part always navigable
    files_extra = max(0, len(files) - MAX_DETAIL_FILES)
    poster_url = _thumb_url(deps, tools, opaque_id)
    chrome = await _page_chrome(request, deps, session)
    # v35 spec §16/§17: the canonical PAYLOAD deep link (t.me) rendered
    # under the player AND used by every player-failure fallback. Built
    # SERVER-side (never from client input); resolves through the Main
    # Bot's canonical payload resolution — bot-side policy (auth, FJ,
    # age/access rules, ad gates) is enforced there, never bypassed.
    # BOT-11 (spec §6-§18): this is now the FALLBACK href only (never
    # pre-minted, never the normal Get File target — each Get File click
    # hits /site/api/get-file for a FRESH random eligible registered bot;
    # no mint happens at page render time, spec §15).
    # BOT-13 §46.2: a payload with show_get_file=0 exposes NO Get File
    # CTA in ANY player surface — the primary button, the not-streamable
    # fallback AND every failure-state Telegram escape hatch are all
    # suppressed (the endpoint refuses too — nothing left to navigate).
    _gf_canonical = detail.get("canonical") or {}
    _show_get_file = bool(_gf_canonical.get("show_get_file", True))
    payload_link = (await _legacy_payload_link(deps, detail)
                    if _show_get_file else "")
    # Pre-roll ad decision (spec §39/§42): SERVER-side. The ad NEVER
    # blocks content — the player script treats any ad failure as
    # skip-and-play (spec §44).
    preroll_head = ""
    try:
        uid = int(session.get("user_id") or 0) or None
        skey = str(session.get("session_key") or "") or None
        ads = _ads_service(deps)
        show = await ads.should_show_video_ad(
            user_id=uid, session_key=skey)
        if show:
            preroll_head = _preroll_script(uid, skey)
    except Exception:  # noqa: BLE001 — ads never block playback
        preroll_head = ""
    # B18-FINAL (bot-22.log pass): the per-file media engagement state —
    # initial counts (views for VIDEO files only) + the authenticated
    # caller's own reaction, rendered server-side and updated in place by
    # the engagement APIs. Independent per file_pk (reacting to Part 1
    # never touches Part 2); no sensitive identifier reaches the page.
    eng_stats = {"views": 0, "likes": 0, "dislikes": 0}
    eng_reaction = None
    eng_is_video = False
    try:
        for f in files:
            if int(f.get("file_pk") or 0) == current_pk:
                eng_is_video = str(f.get("media_type") or "").lower() == "video"
                break
        if current_pk:
            eng_stats = dict(await deps.db.media_stats(current_pk)
                             or {"views": 0, "likes": 0, "dislikes": 0})
            eng_reaction = await deps.db.get_media_reaction(
                current_pk, int(session.get("user_id") or 0))
    except Exception:  # noqa: BLE001 — engagement never breaks playback
        logger.debug("engagement stats lookup failed", exc_info=True)
        eng_stats, eng_reaction, eng_is_video = (
            {"views": 0, "likes": 0, "dislikes": 0}, None, eng_is_video)
    # PROMPT B (bot-25): B.2.1 the media sidebar + the related payload
    # (the end screen's second card). Optional — failures degrade to the
    # classic single-column player.
    try:
        sidebar_html, related_info = await _ux_media_sidebar(
            deps, session, detail)
    except Exception:  # noqa: BLE001 — the sidebar is an enhancement
        logger.debug("media sidebar build failed", exc_info=True)
        sidebar_html, related_info = "", {}
    # V26 Phase 6 + V26 FINAL (Part 5): the Protection Center's 🎨
    # Watermark toggle is AUTHENTIC: when prot_v3_watermark is ON AND
    # the operator configured prot_v3_watermark_text, the player renders
    # that text as a non-interactive corner overlay on the media. An
    # EMPTY text now renders NO overlay at all — the old
    # "Protected content" fallback label is REMOVED from the UI
    # completely (the production Telegram Android screenshot visibly
    # carried the CSS-uppercased "PROTECTED CONTENT" badge; the
    # underlying protection — signed stream authorization, expiring
    # tokens, session ownership, Anti-Leech, authenticated media/HLS
    # routes, range authorization — is fully preserved). A settings-read
    # failure also renders no overlay (never blocks playback).
    watermark_text = ""
    try:
        if await deps.db.get_setting_bool("prot_v3_watermark", False):
            watermark_text = str(
                await deps.db.get_setting("prot_v3_watermark_text")
                or "").strip()[:80]
    except Exception:  # noqa: BLE001 — enhancement only
        watermark_text = ""
    # V26 FINAL (Parts 6+7): the canonical chain breadcrumb for the SPA
    # router's cold-deep-entry seeding (Back walks PLAY -> PAYLOAD ->
    # CATEGORY -> HOME, never out of the site).
    nav_chain = await _nav_chain_for(deps, detail,
                                     payload_opaque=opaque_id)
    return _aiohttp_web.Response(
        text=_html.video_page(detail, part_index, href,
                              video_hrefs=video_hrefs,
                              poster_url=poster_url,
                              current_file_pk=current_pk,
                              files_extra=files_extra,
                              payload_link=payload_link,
                              ad_slots=({"preroll_head": preroll_head}
                                        if preroll_head else None),
                              media_stats=eng_stats,
                              user_reaction=eng_reaction,
                              is_video=eng_is_video,
                              sidebar=sidebar_html,
                              related=related_info,
                              watermark_text=watermark_text,
                              nav_chain=nav_chain,
                              **chrome),
        content_type="text/html")




# =========================================================================
# PROMPT B (bot-25 UX pass): the home SHELVES + media SIDEBAR data.
# Additive, READ-ONLY; every card still routes through the server
# pipeline on click (B.2.7 — the card never decides access).
# =========================================================================
RECENT_WINDOW_HOURS = 24
"""V25 §21: the Recent→Normal window. A payload is Recent while its
canonical ``created_at`` is strictly within the last 24 hours; the exact
boundary instant belongs to Normal. Computed from the SERVER clock (UTC)
on every render — never a stored boolean, never the client device time."""


def _recent_cutoff_iso(now: Optional[_dt] = None) -> str:
    """The Recent/Normal boundary instant (V25 §21): exactly
    ``RECENT_WINDOW_HOURS`` before ``now`` (UTC, server-authoritative).
    Recent = ``created_at`` strictly AFTER this instant; a payload created
    exactly at the boundary is already Normal. Passing ``now`` explicitly
    is the test seam for boundary-crossing fixtures."""
    n = now or _dt.now(_tz.utc)
    return (n - _td(hours=RECENT_WINDOW_HOURS)).isoformat()


async def _ux_cards(deps, rows, *, start_index: int = 0,
                    with_locks: bool = True) -> str:
    """Render shelf/sidebar cards from feed rows (shared by the home
    shelves and the media sidebar)."""
    tools = _tools(deps)
    # B24 (Phase 4): pre-convert + enrich ONCE (batched, not per-card N+1)
    # so every shelf/sidebar card carries the truthful media_counts.
    items = [dict(r) for r in rows]
    await _enrich_listing_media_counts(deps, items)
    out = []
    for i, d in enumerate(items):
        opaque = str(d.get("opaque_id") or "")
        if with_locks:
            try:
                cats = await deps.db.listing_categories_of(int(d["wdbid"]))
                if any(int(c["age_restricted"]) for c in cats):
                    d["age_restricted"] = 1
            except Exception:  # noqa: BLE001 — badge is cosmetic
                pass
        out.append(_html.card(
            d, index=start_index + i,
            thumb_url=_thumb_url(deps, tools, opaque)))
    return "".join(out)


async def _ux_home_shelves(request, deps, session) -> str:
    """B.2.4 + V25 §15/§16/§21 + V26 Phase 7: the home feed as vertical
    shelves.

    V26 PHASE 7 (Recent Videos — the count-based rule): the PRIMARY
    "Recently added" shelf shows the MAXIMUM 10 NEWEST published
    listings (canonical ``created_at`` DESC — no time window: a catalog
    of any age always shows its newest ten, including when fewer than
    10 exist). When an 11th/NEWER upload arrives the previous oldest
    COMPUTATIONALLY leaves the primary ten and appears in the
    "Older history" shelf below (identity-based exclusion of exactly
    the primary ten — the two shelves are disjoint and complementary
    by construction). NO database row is ever rewritten or deleted by
    the push-out: historical listings remain browsable in the
    horizontal Older-history row and in the fully paginated
    Library/Search feed. V25 §21's 24h window remains available in the
    repository layer (``recently_added_website_listings(recent_cutoff=…)``
    / ``older_website_listings``) for compatibility. Then Continue
    Watching, Trending (7-day views) and New in [the viewer's
    most-viewed category]. Each shelf is the horizontal sliding row
    (touch swipe + wheel/trackpad + keyboard, snap, suppressed
    scrollbar — html.shelf_section); cards stay individually tappable;
    NO "More" action exists on the recent section (the row itself is
    the browsing mechanism; Library/Search are the full surfaces).
    Empty shelves stay hidden."""
    age_ok = bool(session.get("age_ok"))
    uid = int(session.get("user_id") or 0)
    viewer = ""
    try:
        viewer = f"u:{uid}" if uid else ""
    except Exception:  # noqa: BLE001
        viewer = ""
    out = []
    # 1. Recently added (V26 Phase 7: the newest 10, count-based —
    #    newest first; a catalog of ANY age always shows its newest
    #    ten; fewer than 10 shows all of them).
    try:
        ra = await deps.db.recently_added_website_listings(
            10, include_age_restricted=age_ok)
        ra_html = await _ux_cards(deps, ra)
        if ra_html:
            out.append(_html.shelf_section(
                "Recently added", "The 10 newest uploads", ra_html))
    except Exception:  # noqa: BLE001
        logger.warning("WEBSITE_SHELF_ERROR shelf=recent",
                       exc_info=True)
    # 2. Older history (V26 Phase 7: everything beyond the newest 10 —
    #    the horizontal history shelf an upload moves to when a NEWER
    #    arrival pushes it out of the primary ten; identity-based
    #    exclusion keeps the pair disjoint; newest first).
    try:
        nr = await deps.db.older_history_website_listings(
            10, 24, include_age_restricted=age_ok)
        nr_html = await _ux_cards(deps, nr)
        if nr_html:
            out.append(_html.shelf_section(
                "Older history", "Earlier uploads", nr_html))
    except Exception:  # noqa: BLE001
        logger.warning("WEBSITE_SHELF_ERROR shelf=older",
                       exc_info=True)
    # 3. Continue Watching (candidates hydrate client-side; the shelf
    #    starts hidden and is removed entirely when nothing resumes).
    try:
        cw_rows = []
        if viewer:
            cw_rows = await deps.db.recently_viewed_website_listings(
                viewer, 12, include_age_restricted=age_ok)
        cw_html = await _ux_cards(deps, cw_rows)
        if cw_html:
            out.append(_html.shelf_section(
                "Continue watching", "Pick up where you left off",
                cw_html, shelf_id="cwshelf", hidden=True))
    except Exception:  # noqa: BLE001 — shelf is optional
        logger.warning("WEBSITE_SHELF_ERROR shelf=continue_watching",
                       exc_info=True)
    # 4. Trending (7-day views).
    try:
        tr = await deps.db.trending_website_listings(
            12, days=7, include_age_restricted=age_ok)
        tr_html = await _ux_cards(deps, tr)
        if tr_html:
            out.append(_html.shelf_section(
                "Trending", "Last 7 days", tr_html))
    except Exception:  # noqa: BLE001
        logger.warning("WEBSITE_SHELF_ERROR shelf=trending",
                       exc_info=True)
    # 5. New in [the viewer's most-viewed category].
    try:
        most_cat = None
        if viewer:
            viewed = await deps.db.recently_viewed_website_listings(
                viewer, 12, include_age_restricted=age_ok)
            counts: Dict[str, int] = {}
            for r in viewed:
                try:
                    cats = await deps.db.listing_categories_of(
                        int(r["wdbid"]))
                except Exception:  # noqa: BLE001
                    cats = []
                for c in cats:
                    counts[str(c["slug"])] = counts.get(str(c["slug"]),
                                                        0) + 1
            if counts:
                most_cat = sorted(counts.items(),
                                  key=lambda kv: (-kv[1], kv[0]))[0][0]
        if most_cat:
            cat_rows = await deps.db.newest_in_category(
                most_cat, 12, include_age_restricted=age_ok)
            cat_html = await _ux_cards(deps, cat_rows)
            if cat_html:
                out.append(_html.shelf_section(
                    f"New in {most_cat.replace(chr(45), chr(32)).title()}",
                    "Fresh for you", cat_html))
    except Exception:  # noqa: BLE001
        logger.debug("new-in-category shelf lookup failed", exc_info=True)
    return "".join(out)


async def _ux_media_sidebar(deps, session, detail) -> tuple:
    """B.2.1/B.4.2: the media sidebar — 6 related payloads (same
    category, >=2 shared tags preferred for because-you-watched) + 6
    trending (7-day). Returns (sidebar_html, related_info)."""
    age_ok = bool(session.get("age_ok"))
    listing = detail.get("listing") or {}
    ldbid = int(listing.get("id") or 0)
    opaque = str(listing.get("opaque_id") or "")
    tags = [t for t in str(listing.get("tags") or "").replace(
        ",", " ").split() if t][:8]
    cat_slug = None
    try:
        cats = await deps.db.listing_categories_of(ldbid)
        for c in cats:
            if not int(c["age_restricted"]) or age_ok:
                cat_slug = str(c["slug"])
                break
    except Exception:  # noqa: BLE001
        cats = []
    related_rows: List[Any] = []
    try:
        related_rows = await deps.db.related_website_listings(
            ldbid, category_slug=cat_slug, tags=tags or None, limit=6,
            include_age_restricted=age_ok)
    except Exception:  # noqa: BLE001 — sidebar is optional
        logger.debug("related lookup failed", exc_info=True)
    trending_rows: List[Any] = []
    try:
        trending_rows = await deps.db.trending_website_listings(
            6, days=7, include_age_restricted=age_ok)
    except Exception:  # noqa: BLE001
        logger.debug("sidebar trending lookup failed", exc_info=True)
    rel_html = await _ux_cards(deps, related_rows)
    tr_html = await _ux_cards(deps, trending_rows)
    parts = []
    if rel_html:
        head = "Because you watched" if (tags and any(
            str(r["tags"] or "").strip() for r in related_rows)) \
            else "Related payloads"
        parts.append('<section class="sidesec"><div class="shelfhead">'
                     + '<span class="shelftitle">'
                     + _html.esc(head) + "</span></div>"
                     + '<div class="shelfrow">' + rel_html + "</div>"
                     + "</section>")
    if tr_html:
        parts.append('<section class="sidesec"><div class="shelfhead">'
                     '<span class="shelftitle">Trending</span></div>'
                     + '<div class="shelfrow">' + tr_html + "</div>"
                     + "</section>")
    related_info: Dict[str, Any] = {}
    if related_rows:
        r0 = dict(related_rows[0])
        tools = _tools(deps)
        related_info = {
            "href": _html.site_url(
                f"site/payload/{r0.get('opaque_id') or ''}"),
            "title": str(r0.get("eff_title") or "Related"),
            "poster": _thumb_url(deps, tools,
                                 str(r0.get("opaque_id") or "")),
        }
    return "".join(parts), related_info


async def handle_site_api_auth(request):
    """POST /site/api/auth — server-side Mini App initData validation
    (multi-token: main bot + ACTIVE network bots; spec §11). initData is
    read from the request BODY (never a URL/query — no secrets in URLs),
    never logged, and the client-supplied identity is never trusted."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_auth", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")[:8192]
    tools = _tools(deps)
    verified = await tools.multi_auth.validate_init_data(init_data)
    if verified is None:
        logger.info("WEBSITE_AUTH_REJECTED (invalid signature, stale "
                    "auth_date or unknown bot token)")
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    tg_user = verified.get("user") or {}
    logger.info("WEBSITE_AUTH_OK user_id=%s via=%s bot_id=%s",
                verified.get("user_id"), verified.get("via"),
                verified.get("bot_id"))
    return _aiohttp_web.json_response({
        "ok": True,
        "user": {"id": verified.get("user_id"),
                 "username": tg_user.get("username"),
                 "first_name": tg_user.get("first_name")},
        "via": verified.get("via"),
        "bot_id": verified.get("bot_id"),
    })


# Human requirement text for LOCKED AccessResult reasons (presentation
# only — the authoritative decision is always the engine's).
# B23/P0-1: the watch_ad_required entry is now UNREACHABLE from every
# website surface (the website-playback chokepoint in app/web/site/authz.py
# waives the Telegram payload Watch-Ad gate for website playback) — kept
# only as honest defense-in-depth copy should an unforeseen path surface
# the reason. The two ad systems remain SEPARATE: the website pre-roll
# fires per its own configuration regardless of this gate.
_REQUIREMENT_TEXT = {
    "force_join_required":
        "Join the required channel(s) in Telegram first, then reload.",
    "watch_ad_required":
        "Playback should not require this — reload the page.",
    "referral_required":
        "Invite friends via your referral link to unlock this payload.",
    "points_locked":
        "Unlock this payload with points in the bot.",
    "referral_inactive":
        "This payload's unlock campaign is currently inactive.",
    "payload_missing":
        "This payload is no longer available.",
}


async def handle_site_api_access(request):
    """POST /site/api/access — the Access Engine verdict for a selected
    file. REUSES the existing ``access_engine`` (never a second engine,
    never an enforce_access call site, never a website_enabled branch
    inside the engine — spec §12). Body: {init_data, video_ref}."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_access", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")[:8192]
    video_ref = str((body or {}).get("video_ref") or "")[:2048]
    tools = _tools(deps)
    verified = await tools.multi_auth.validate_init_data(init_data)
    if verified is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    uid = int(verified.get("user_id") or 0)
    if not uid:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    decoded = tools.codec.decode_video_ref(video_ref)
    if decoded is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "invalid_video_ref"}, status=400)
    detail = await _published_detail(tools, str(decoded.get("listing") or ""))
    if detail is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # B10-W2 (spec §22 — API bypass guard): the access verdict for an
    # age-restricted listing requires the 18+ confirmation in the EXISTING
    # site session, and the session must belong to the SAME verified user
    # (user A's confirmation never opens user B's gate — the same identity
    # matching the video-ad session_key uses). Unconfirmed -> the SAME
    # honest 404 shape a missing listing produces (no existence leak).
    session = await _session_of(request, deps)
    if not (session is not None
            and int(session.get("user_id") or 0) == uid
            and bool(session.get("age_ok"))) \
            and await _listing_age_restricted(
                deps, int((detail.get("listing") or {}).get("id") or 0)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    files = detail.get("files") or []
    file_pk = int(decoded.get("file_pk") or 0)
    if not any(int(f.get("file_pk") or 0) == file_pk for f in files):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "file_not_in_payload"}, status=400)
    canonical = detail.get("canonical") or {}
    payload_id = (int(canonical["payload_id"])
                  if canonical.get("kind") == "payload" else None)
    # GAP-CLOSURE: pass the LIVE bot so Force-Join membership checks run
    # server-side (bot=None failed CLOSED for non-admin users).
    _bot_ref = getattr(deps, "bot_ref", None)
    _bot = _bot_ref() if callable(_bot_ref) else None
    # B23/P0-1: the website-playback authorization chokepoint — every
    # engine reason stays enforced EXCEPT watch_ad_required (waived for
    # website playback; Telegram-side delivery still enforces it).
    # V26.2 (bot-41 §16-§24): per-video gate key — the FJ slice is this
    # video's pinned batch (progressive batching).
    from app.web.site.authz import authorize_website_playback
    try:
        verdict = await authorize_website_playback(
            deps, _bot, uid, payload_id=payload_id,
            gate_key="w|%s|%s" % (str(decoded.get("listing") or ""),
                                  int(file_pk or 0)))
    except Exception as engine_exc:  # noqa: BLE001 — TASK A2 telemetry
        from app.web.site.authz import log_website_engine_failure
        log_website_engine_failure(
            "access_api", engine_exc, user_id=uid, payload_id=payload_id,
            file_pk=file_pk,
            gate_key="w|%s|%s" % (str(decoded.get("listing") or ""),
                                  int(file_pk or 0)))
        return _aiohttp_web.json_response(
            {"ok": False, "error": "engine_error"}, status=500)
    res = verdict.result
    authorized = bool(verdict.authorized)
    resp: Dict[str, Any] = {"ok": True, "authorized": authorized,
                            "reason": verdict.reason}
    if authorized:
        # Honest Phase 3 note: the actual playback transport is the Phase 4
        # Media Gateway — this boundary authorizes, it does not stream.
        resp["note"] = ("Access granted. Playback arrives with the "
                        "streaming update.")
    else:
        resp["requirement"] = _REQUIREMENT_TEXT.get(
            str(res.reason or ""),
            "Complete the access requirement in the bot, then reload.")
        # GAP-CLOSURE spec §24: the exact unjoined channels with the
        # backend-provided Join URLs — the website Force-Join gate data.
        if res.reason == "force_join_required" and res.not_joined:
            resp["not_joined"] = _fj_channel_views(res.not_joined)
            resp["verify_hint"] = ("Join the channels above in Telegram, "
                                    "then tap Verify Again.")
            # GAP-CLOSURE spec §15: the honest aggregate FJ health on every
            # force-join surface (never claims full health when channels
            # are unverifiable).
            resp.update(await _fj_health_summary(deps))
        if res.reason == "referral_required" and res.required_referrals:
            remaining = max(0, int(res.required_referrals or 0)
                            - int(res.completed_referrals or 0))
            resp["requirement"] = (
                f"Invite {remaining} more friend"
                + ("" if remaining == 1 else "s")
                + " to unlock this payload.")
    logger.info("WEBSITE_ACCESS user_id=%s payload_id=%s authorized=%s "
                "reason=%s", uid, payload_id, authorized, res.reason)
    return _aiohttp_web.json_response(resp)


# ------------------------------------------------------------ BOT-11 §6-§18
# WEBSITE GET FILE — random eligible REGISTERED-BOT delivery. The main
# bot must NOT be the normal Get File target: every click resolves a
# random delivery-eligible registered network bot SERVER-side (spec §17:
# the bot list NEVER reaches the client — only the resulting t.me URL),
# mints a DURABLE targeted Global Payload Link (target_network_bot_id +
# target_mode='random', locked in at creation — B11-B's router handles
# the /start), and returns {"ok": true, "url": <t.me deep link>}. No
# internal bot ids beyond what the URL itself carries.
def _getfile_guard_key(uid: int, listing: str) -> str:
    return f"{int(uid)}:{str(listing)[:64]}"


def _getfile_guard_check(uid: int, listing: str):
    """BOT-11 (spec §15): the in-flight dedup state for (uid, listing)
    inside the 2s window — None when not guarded."""
    try:
        ent = _GETFILE_GUARD.get(_getfile_guard_key(uid, listing))
    except Exception:  # noqa: BLE001
        return None
    if not ent:
        return None
    ts, resp = ent
    if _getfile_clock() - float(ts) > GETFILE_GUARD_WINDOW_SECONDS:
        return None
    return resp


def _getfile_guard_evict_oldest() -> None:
    """A.6.5 (bot-25): bounded-guard EVICTION — never ``.clear()``.

    The old clear-on-overflow destroyed EVERY user's debounce window at
    once (a burst of duplicate Get File mints could land right after any
    overflow). The guard entries are timestamped: first drop the EXPIRED
    ones (outside the 2s window — pure garbage), and only if the map is
    still over the cap evict the OLDEST half (the ratelimit.py
    discipline). LIVE entries survive overflow. Best-effort: any failure
    simply leaves the map as-is (the guard is an optimization, never a
    correctness gate).
    """
    try:
        now = _getfile_clock()
        for k in [k for k, ent in list(_GETFILE_GUARD.items())
                  if now - float(ent[0]) > GETFILE_GUARD_WINDOW_SECONDS]:
            _GETFILE_GUARD.pop(k, None)
        if len(_GETFILE_GUARD) > _GETFILE_GUARD_MAX_KEYS:
            ordered = sorted(_GETFILE_GUARD.items(),
                             key=lambda kv: float(kv[1][0]))
            for k, _ent in ordered[:max(1, len(ordered) // 2)]:
                _GETFILE_GUARD.pop(k, None)
    except Exception:  # noqa: BLE001 — best-effort, never a correctness gate
        pass


def _getfile_guard_set(uid: int, listing: str, resp: Dict[str, Any]) -> None:
    try:
        if len(_GETFILE_GUARD) > _GETFILE_GUARD_MAX_KEYS:
            _getfile_guard_evict_oldest()
        _GETFILE_GUARD[_getfile_guard_key(uid, listing)] = (
            _getfile_clock(), dict(resp))
    except Exception:  # noqa: BLE001 — the guard is best-effort
        pass


def _getfile_lock(uid: int, listing: str):
    """BOT-11 §15: the per-(user, listing) in-flight lock (created
    lazily, bounded — A.6.5 (bot-25): OLDEST-ENTRY EVICTION on overflow,
    never ``.clear()``; an evicted lock only means the next request for
    THAT pair makes a new one, never a correctness change — and every
    OTHER live entry now survives overflow)."""
    key = _getfile_guard_key(uid, listing)
    lock = _GETFILE_LOCKS.get(key)
    if lock is None:
        try:
            if len(_GETFILE_LOCKS) > _GETFILE_LOCKS_MAX_KEYS:
                # A.6.5: evict the OLDEST entries (insertion order — plain
                # dicts preserve it) until back under the cap. Never
                # ``.clear()`` (which nuked every in-flight lock at once).
                for k in list(_GETFILE_LOCKS.keys()):
                    if len(_GETFILE_LOCKS) <= _GETFILE_LOCKS_MAX_KEYS:
                        break
                    _GETFILE_LOCKS.pop(k, None)
            import asyncio as _asyncio
            lock = _asyncio.Lock()
            _GETFILE_LOCKS[key] = lock
        except Exception:  # noqa: BLE001 — best-effort hardening
            return None
    return lock


def _net_links_of(deps: Any):
    """The production Global Payload Links signer (BOT-11 §12) — resolved
    through the website deps (``net_links``, late-bound to the SAME
    ns._net_links singleton the network router uses). None = no signer
    wired (the caller then answers the honest signing_unavailable error —
    NEVER a fabricated link)."""
    try:
        links = getattr(deps, "net_links", None)
        if callable(links):
            links = links()
        return links if links is not None else None
    except Exception:  # noqa: BLE001
        return None


async def _getfile_fallback_allowed(db: Any) -> bool:
    """BOT-11 (spec §14): the explicit operator switch
    ``website_get_file_allow_main_fallback`` (default '0' — the truthful
    no-delivery-bot 503, never a silent main-bot redirect)."""
    try:
        raw = await db.get_setting("website_get_file_allow_main_fallback",
                                   "0")
        return str(raw or "0").strip() == "1"
    except Exception:  # noqa: BLE001 — default: fallback OFF
        return False


async def handle_site_api_get_file(request):
    """POST /site/api/get-file — BOT-11 spec §6-§18: random eligible
    REGISTERED-BOT delivery for the Website Get File button.

    Body: {"listing": "<opaque_id>", "file_pk": <int optional>,
    "init_data": "<optional fresh Mini App identity>"}.

    Gate chain (the same order the other site APIs apply): website_enabled
    → rate limit → identity. Identity resolution mirrors /site/api/access
    + /site/api/pack EXACTLY: a fresh init_data in the body validated
    through the SAME multi-token validator, else the existing site session
    cookie — anonymous gets the 401 login-required JSON.

    Delivery: ``select_random_delivery_bot`` (the ONE centralized unbiased
    §8 selector) → mint_targeted_link (durable, target persisted; fails
    CLOSED with signing_unavailable when the dedicated persistent signing
    key is missing) → the t.me deep link of the SELECTED REGISTERED BOT.
    The main bot is used ONLY through the explicit operator fallback
    switch (§14). Per §15: a per-(user, listing) 2s in-process guard
    returns the SAME link JSON for rapid duplicates; each click beyond
    the window is a FRESH selection (multi-click distribution)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_getfile", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    body = body if isinstance(body, dict) else {}
    listing = str(body.get("listing") or "")[:64]
    file_pk = _safe_int(body.get("file_pk"), 0, lo=0)
    init_data = str(body.get("init_data") or "")[:8192]
    if not listing:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    # Identity: fresh init_data (the SAME multi-token validator the
    # access API uses), else the existing site session cookie (the pack
    # API's resolution chain — the detail-page button relies on it).
    uid = None
    if init_data:
        tools = _tools(deps)
        verified = await tools.multi_auth.validate_init_data(init_data)
        if verified is not None:
            uid = int(verified.get("user_id") or 0) or None
    if uid is None:
        session = await _session_of(request, deps)
        if session is not None:
            uid = int(session.get("user_id") or 0) or None
    if uid is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    tools = _tools(deps)
    detail = await _published_detail(tools, listing)
    if detail is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # The SAME 18+ backend enforcement every payload surface applies
    # (B10-W2 spec §22 — no existence leak through the Get File API).
    # B23/P0-3 (§3.1 age-gate identity binding): the session's age_ok
    # counts ONLY when the session belongs to the SAME identity the
    # caller authenticated (uid) — user A's age-approved cookie plus
    # user B's fresh init_data no longer opens B's gate (the exact
    # stream.py::_session_age_confirmed pattern).
    _gf_session = await _session_of(request, deps)
    _gf_age_ok = bool(
        _gf_session is not None
        and int(_gf_session.get("user_id") or 0) == int(uid)
        and bool(_gf_session.get("age_ok")))
    if not _gf_age_ok \
            and await _listing_age_restricted(
                deps, int((detail.get("listing") or {}).get("id") or 0)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # BOT-13 §46.2 (per-payload Get File switch — SERVER-side enforcement):
    # a payload with show_get_file=0 fails CLOSED here with a truthful
    # denial BEFORE any guard/lock/mint. No eligible-bot selection, no
    # Global Link record, no delivery job, no t.me URL — and this is the
    # SAME endpoint the button uses, so a hidden/disabled button and a
    # direct API attempt are equally refused. Collections have no
    # per-payload row (the switch is payload-scoped) and stay available.
    _canonical = detail.get("canonical") or {}
    if _canonical.get("kind") == "payload" \
            and not bool(_canonical.get("show_get_file", True)):
        logger.info(
            "WEBSITE_GET_FILE_DISABLED user_id=%s listing=%s payload_id=%s "
            "(show_get_file=0 — truthful denial: no selection, no mint, "
            "no link)", uid, listing[:8],
            _canonical.get("payload_id") or 0)
        return _aiohttp_web.json_response(
            {"ok": False, "error": "get_file_disabled",
             "message": "Get File is currently unavailable for this "
                        "payload."}, status=403)
    # §15: rapid duplicate clicks inside the guard window return the SAME
    # link JSON (exactly one mint); errors are never cached.
    guarded = _getfile_guard_check(uid, listing)
    if guarded is not None:
        logger.info("WEBSITE_GET_FILE_GUARDED user_id=%s listing=%s "
                    "(duplicate click inside the %.1fs window — the "
                    "already-minted link is returned)",
                    uid, listing[:8], GETFILE_GUARD_WINDOW_SECONDS)
        return _aiohttp_web.json_response(dict(guarded))

    async def _mint_section():
        """§6-§18: the selection + mint core (extracted verbatim so the
        §15 in-flight lock can wrap it without touching any return
        path)."""
        logger.info("WEBSITE_GET_FILE_START user_id=%s listing=%s file_pk=%s",
                    uid, listing[:8], file_pk)
        canonical = detail.get("canonical") or {}
        payload_id = (int(canonical["payload_id"])
                      if canonical.get("kind") == "payload"
                      and canonical.get("payload_id") else 0)
        # SERVER-SIDE random selection (spec §17 — the bot list never reaches
        # the client). ONE selector, shared with the Global Link mint flow.
        from app.network.routing import (
            LinkSigningUnavailableError,
            mint_targeted_link,
            select_random_delivery_bot,
        )
        # V25 FINAL (two-stage, browser-caught defect): pass the v42
        # delivery-ready predicate (container.website_deps_factory wires
        # the SAME authoritative is_delivery_ready the network router
        # uses). Without it the selector's fail-closed fallback consults
        # the LEGACY network_delivery_groups table — a fresh v42 bot with
        # a verified Delivery Channel but no legacy group row was wrongly
        # ineligible here. getattr(..., None) keeps legacy test fakes on
        # their pinned fallback behavior.
        pick = await select_random_delivery_bot(
            deps.db, delivery_ready=getattr(deps, "delivery_ready", None))
        logger.info("WEBSITE_GET_FILE_ELIGIBLE_BOTS count=%s reason=%s",
                    int(pick.get("eligible") or 0), pick.get("reason"))
        selected = pick.get("selected")
        if selected is None:
            fallback_allowed = await _getfile_fallback_allowed(deps.db)
            if fallback_allowed:
                # §14: the EXPLICIT operator main-bot fallback (legacy
                # behavior) — never a silent redirect.
                fallback_url = await _legacy_payload_link(deps, detail)
                if fallback_url:
                    logger.info("WEBSITE_GET_FILE_MAIN_FALLBACK user_id=%s "
                                "listing=%s (website_get_file_allow_main_"
                                "fallback=1)", uid, listing[:8])
                    resp = {"ok": True, "url": fallback_url}
                    _getfile_guard_set(uid, listing, resp)
                    return _aiohttp_web.json_response(resp)
            logger.info("WEBSITE_GET_FILE_NO_ELIGIBLE_BOT reason=%s "
                        "fallback=%s (the truthful 503 — no delivery bot is "
                        "currently available)",
                        pick.get("reason"), "on" if fallback_allowed else "off")
            # B24 (Phase 1/8): actionable 503 body — no secrets leaked
            # (no bot ids/tokens); the user is told the operator must
            # verify a delivery channel so they can escalate.
            return _aiohttp_web.json_response({
                "ok": False,
                "error": "no_delivery_bot",
                "reason": pick.get("reason") or "no_eligible_bot",
                "action": "Ask the platform admin to verify a Delivery "
                          "Channel for at least one registered Network Bot "
                          "(the File Delivery Bot must be an admin of that "
                          "channel).",
            }, status=503)
        nid = int(selected.get("network_bot_id") or 0)
        username = str(selected.get("username") or "").lstrip("@").strip()
        if nid <= 0 or not username:
            logger.info("WEBSITE_GET_FILE_NO_ELIGIBLE_BOT reason=malformed_row "
                        "(selected row without id/username — refused)")
            return _aiohttp_web.json_response(
                {"ok": False, "error": "no_delivery_bot"}, status=503)
        logger.info("WEBSITE_GET_FILE_SELECTED_BOT network_bot_id=%s "
                    "username=%s", nid, username)
        if payload_id > 0:
            # DURABLE targeted link (spec §12/§16): the mint persists the
            # selected target + mode='random' — B11-B's router delivers the
            # /start through this target (locked in at creation).
            links = _net_links_of(deps)
            if links is None:
                logger.info("WEBSITE_GET_FILE_SIGNING_UNAVAILABLE "
                            "(no Global Payload Links signer wired — no link "
                            "fabricated)")
                return _aiohttp_web.json_response(
                    {"ok": False, "error": "signing_unavailable"}, status=503)
            try:
                code = await mint_targeted_link(
                    deps.db, links, payload_id,
                    target_network_bot_id=nid, target_mode="random")
            except LinkSigningUnavailableError:
                # Spec §4 fail-closed: the dedicated persistent signing key is
                # missing — honest error, NEVER a fabricated link.
                logger.info("WEBSITE_GET_FILE_SIGNING_UNAVAILABLE "
                            "(NETWORK_GLOBAL_LINK_SIGNING_KEY missing — "
                            "minting refused, no link fabricated)")
                return _aiohttp_web.json_response(
                    {"ok": False, "error": "signing_unavailable"}, status=503)
            logger.info("WEBSITE_GET_FILE_LINK_CREATED code_prefix=%s "
                        "target_network_bot_id=%s target_mode=random",
                        str(code)[:6], nid)
            url = f"https://t.me/{username}?start=g{code}"
        else:
            # A COLLECTION listing: the c-code /start deep link on the
            # SELECTED registered bot (collections resolve through the shared
            # handler set, not the g-link table — nothing fabricated).
            coll = canonical.get("collection_id")
            url = f"https://t.me/{username}?start=c{coll}"
            logger.info("WEBSITE_GET_FILE_LINK_CREATED code_prefix=c%s "
                        "target_network_bot_id=%s target_mode=random",
                        coll, nid)
        resp = {"ok": True, "url": url}
        _getfile_guard_set(uid, listing, resp)
        return _aiohttp_web.json_response(resp)

    # §15 concurrent-click hardening: a browser double-click fires
    # CONCURRENT in-flight POSTs that all pass the timestamp guard
    # before any response lands (TOCTOU — N mints for one user action).
    # The per-(user, listing) lock serializes the storm; the re-check
    # after acquisition returns the leader's cached link. Errors are
    # never cached — a failed leader lets the follower run its own
    # honest attempt (the lock releases on EVERY return path).
    gf_lock = _getfile_lock(uid, listing)
    if gf_lock is None:
        return await _mint_section()
    async with gf_lock:
        guarded = _getfile_guard_check(uid, listing)
        if guarded is not None:
            logger.info("WEBSITE_GET_FILE_GUARDED user_id=%s listing=%s "
                        "(concurrent follower — the leader's already-minted "
                        "link is returned)",
                        uid, listing[:8])
            return _aiohttp_web.json_response(dict(guarded))
        return await _mint_section()


async def handle_site_api_get_file_config(request):
    """GET /site/api/get-file-config — BOT-11 (spec §17): the lightweight
    public button-label state (no secrets, no bot list): ``configured``
    is TRUE when the website is on AND at least one delivery-eligible
    registered bot exists (or the operator explicitly enabled the
    main-bot fallback). Never exposes bot ids/usernames."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_getfile", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    from app.network.routing import select_random_delivery_bot
    try:
        # V25 FINAL (two-stage): the SAME v42 delivery-ready predicate as
        # the mint endpoint above — the config badge must reflect the
        # Delivery Channel architecture, never the legacy group table.
        pick = await select_random_delivery_bot(
            deps.db, delivery_ready=getattr(deps, "delivery_ready", None))
        eligible = int(pick.get("eligible") or 0)
    except Exception:  # noqa: BLE001 — honest not-configured state
        eligible = 0
    configured = bool(eligible > 0
                      or await _getfile_fallback_allowed(deps.db))
    return _aiohttp_web.json_response(
        {"ok": True, "configured": configured,
         "delivery_via": "telegram"})


def _fj_state_from_link_health(link_health: str) -> str:
    """BOT-16: a persisted force-channel ``link_health`` state → the
    website per-channel ``state`` badge (the closed set the player Join
    gate + the screens gate render):

      temporary_error                      → api_temporary_failure
      bot_permission                       → bot_permission_failure
      channel_invalid / link_expired /
      link_revoked / link_invalid          → invalid_channel (confirmed-dead)
      anything else (healthy/unverifiable/
      no_link/empty)                      → not_joined

    Mirrors the bot-side semantics (app/presentation/telegram/forcejoin.py
    ~508-516): a TRANSIENT failure keeps the stored invite link usable for
    users regardless of bot access — only confirmed-dead states drop the
    URL (``_fj_channel_views`` does that) and render the honest
    unavailable line."""
    s = str(link_health or "").strip().lower()
    if s == "temporary_error":
        return "api_temporary_failure"
    if s == "bot_permission":
        return "bot_permission_failure"
    if s in ("channel_invalid", "link_expired", "link_revoked",
             "link_invalid"):
        return "invalid_channel"
    return "not_joined"


def map_member_result_to_channel_state(result: Any) -> str:
    """BOT-16 (Work Item D-C): MemberCheckResult → the website per-channel
    ``state`` badge (PURE, testable — the mapping the stream-denial /
    verify surfaces use when a live membership result must become UI):

      MEMBER / ADMINISTRATOR / CREATOR    → joined
      NOT_MEMBER / REQUEST_PENDING        → not_joined (Join button;
                                             a pending request is still
                                             "not a member yet")
      TELEGRAM_ERROR                      → api_temporary_failure
      CHANNEL_NOT_FOUND / PRIVATE_CHANNEL_UNAVAILABLE → invalid_channel
      BOT_NOT_ADMIN                       → bot_permission_failure

    Accepts the enum OR its value string; unknown values fail HONESTLY to
    ``not_joined`` (never silently claim joined)."""
    from app.core.force_join.service import MemberCheckResult
    if isinstance(result, MemberCheckResult):
        val = result.value
    else:
        val = str(getattr(result, "value", result) or "").strip().lower()
    table = {
        "member": "joined",
        "administrator": "joined",
        "creator": "joined",
        "not_member": "not_joined",
        "request_pending": "not_joined",
        "telegram_error": "api_temporary_failure",
        "channel_not_found": "invalid_channel",
        "private_unavailable": "invalid_channel",
        "bot_not_admin": "bot_permission_failure",
    }
    return table.get(val, "not_joined")


def _fj_channel_views(rows: List[Any]) -> List[Dict[str, Any]]:
    """Render AccessResult.not_joined rows into safe website views —
    the backend-provided channel title + the VALID join URL (spec §24).

    URL priority: the health-verified invite_link (PHASE 8) → the public
    username link → honest null (the website shows the channel name and
    directs the user to Telegram). NEVER a guessed URL.

    GAP-CLOSURE §14/§15: each view carries a ``verification`` state —
    "unavailable" marks channels the bot cannot verify right now
    (persisted link_health: channel_invalid / bot_permission /
    temporary_error). The client shows the "verification unavailable —
    retry" state for those instead of blaming the user with "not
    joined", and joined is never claimed until a server-side check
    actually succeeds."""
    views: List[Dict[str, Any]] = []
    for row in rows or []:
        keys = row.keys() if hasattr(row, "keys") else []
        def _get(col: str):
            return row[col] if col in keys else None
        title = (_get("title") or _get("channel_name")
                 or f"Channel {_get('channel_id')}")
        url = _get("invite_link")
        if not url:
            uname = _get("username") or _get("channel_username")
            if uname:
                url = f"https://t.me/{str(uname).lstrip('@')}"
        link_health = str(_get("link_health") or "").strip().lower()
        if url and link_health in ("link_expired", "link_revoked",
                                   "link_invalid", "channel_invalid"):
            # Dead link: keep the title, drop the URL (the FJ link-health
            # system repairs it bot-side; the website never sends a dead
            # Join button — spec §24).
            url = None
        views.append({
            "title": str(title), "url": url,
            "channel_id": _get("channel_id"),
            "verification": ("unavailable"
                             if link_health in _FJ_UNVERIFIABLE_STATES
                             else "not_joined"),
            # BOT-16: the closed per-channel state set the player Join
            # gate + the screens gate render (not_joined |
            # api_temporary_failure | invalid_channel |
            # bot_permission_failure | joined).
            "state": _fj_state_from_link_health(link_health),
        })
    return views


# ==========================================================================
# GAP-CLOSURE: the session / identity / Force-Join / ads / pack surface
# ==========================================================================
def _preroll_script(user_id: Optional[int], session_key: Optional[str]
                    ) -> str:
    """The video-ad state machine (spec §39-§54) — injected into the player
    page head when the SERVER decided a pre-roll applies.

    States: IDLE → LOADING_AD → PLAYING_AD → (AD_SKIPPABLE) →
    AD_COMPLETED | AD_FAILED → LOADING_CONTENT → PLAYING_CONTENT →
    (MIDROLL_PENDING → MIDROLL_PLAYING) → ENDED.
    Ads NEVER block content: a load/decision failure or timeout (4s) skips
    straight to the content (spec §44). Seek across a mid-roll only fires
    once per break; consumed breaks are tracked (spec §43)."""
    uid_js = str(int(user_id)) if user_id else "null"
    skey_js = "'" + _html._esc_js_attr(str(session_key or "")) + "'" \
        if session_key else "null"
    return """
<script>
(function(){
  var API_DECISION = '""" + _html.site_url("site/api/ads/decision") + """';
  var API_EVENT = '""" + _html.site_url("site/api/ads/event") + """';
  var USER_ID = """ + uid_js + """;
  var SESSION_KEY = """ + skey_js + """;
  var st = 'IDLE';
  var consumedBreaks = {};

  function adEvent(creative, placement, event){
    try{
      fetch(API_EVENT, {method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({creative_id:creative&&creative.creative_id,
          placement:placement, event:event, user_id:USER_ID,
          session_key:SESSION_KEY})}).catch(function(){});
    }catch(e){}
  }

  function fetchAd(placement){
    return fetch(API_DECISION, {method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({placement:placement, user_id:USER_ID,
        session_key:SESSION_KEY, context:'video'})})
      .then(function(r){return r.json();})
      .then(function(j){return (j&&j.ok)?(j.ad||null):null;});
  }

  function withTimeout(p, ms){
    return Promise.race([p, new Promise(function(_,rej){
      setTimeout(function(){rej(new Error('ad_timeout'));}, ms);})]);
  }

  function playAdStage(ad, placement, onDone){
    var stage=document.getElementById('adstage');
    var body=document.getElementById('adbody');
    var skip=document.getElementById('adskip');
    var count=document.getElementById('adcount');
    if(!stage||!body){onDone(false);return;}
    st='LOADING_AD';
    body.innerHTML='';
    stage.hidden=false;
    var done=false;
    function finish(completed){
      if(done){return;} done=true;
      try{stage.hidden=true;body.innerHTML='';}catch(e){}
      if(ad){adEvent(ad, placement, completed?'complete':'skip');}
      onDone(true);
    }
    if(!ad){finish(false);return;}   // no eligible ad: collapse instantly
    adEvent(ad, placement, 'start');
    var dur=Math.max(1, parseInt(ad.duration,10)||8);
    var skipAfter=parseInt(ad.skip_after,10);
    var canSkip=!!ad.skip_enabled;
    if(ad.kind==='video'&&ad.video_url){
      var v=document.createElement('video');
      v.src=ad.video_url; v.playsInline=true; v.muted=true;
      v.className='advideo';
      v.addEventListener('error',function(){adEvent(ad,placement,'failure');
        finish(false);});
      v.addEventListener('ended',function(){finish(true);});
      v.addEventListener('timeupdate',function(){
        var t=v.currentTime||0;
        if(count){count.textContent=Math.max(0,Math.ceil(dur-t))+'s';}
        if(skip&&!skip.hidden){/* countdown only */}
        var q=Math.floor(t/(dur||1)*4);
        if(q>=1&&v.dataset.q1!=='1'){v.dataset.q1='1';adEvent(ad,placement,'q25');}
        if(q>=2&&v.dataset.q2!=='1'){v.dataset.q2='1';adEvent(ad,placement,'q50');}
        if(q>=3&&v.dataset.q3!=='1'){v.dataset.q3='1';adEvent(ad,placement,'q75');}
      });
      body.appendChild(v);
      st='PLAYING_AD';
      var p=v.play();
      if(p&&p.catch){p.catch(function(){adEvent(ad,placement,'failure');
        finish(false);});}
      if(skip){
        skip.hidden=!canSkip;
        if(canSkip){
          var armed=false;
          var iv=setInterval(function(){
            if((v.currentTime||0)>=skipAfter){armed=true;clearInterval(iv);}
          },200);
          skip.addEventListener('click',function(){
            if(!armed){return;}
            try{v.pause();}catch(e){}
            finish(false);
          });
        }
      }
      return;
    }
    if(ad.kind==='banner_image'||ad.kind==='banner_responsive'){
      var img=document.createElement('img');
      img.src=ad.image_mobile||ad.image_desktop||'';
      img.alt=ad.alt_text||'Advertisement';
      img.className='adbanner';
      img.addEventListener('error',function(){adEvent(ad,placement,'failure');
        finish(false);});
      if(ad.click_url){
        var a=document.createElement('a');
        a.href=ad.click_url; a.target='_blank'; a.rel='noopener noreferrer';
        a.appendChild(img); body.appendChild(a);
      }else{body.appendChild(img);}
      st='PLAYING_AD';
      if(skip){skip.hidden=!canSkip;}
      if(skip){
        skip.addEventListener('click',function(){finish(false);});}
      setTimeout(function(){finish(true);}, Math.min(dur,15)*1000);
      return;
    }
    // provider/html or unknown kind: no local playback — complete quickly
    finish(false);
  }

  window.__adStage = {
    show: function(placement, onDone){
      withTimeout(fetchAd(placement), 4000)
        .then(function(ad){playAdStage(ad, placement, onDone);})
        .catch(function(){playAdStage(null, placement, onDone);});
    },
    preroll: function(playContent){
      window.__adStage.show('AD_VIDEO_BEFORE', playContent);
    },
    midroll: function(breakKey, playContent){
      if(consumedBreaks[breakKey]){playContent();return;}
      consumedBreaks[breakKey]=true;
      st='MIDROLL_PENDING';
      window.__adStage.show('AD_VIDEO_MIDROLL', playContent);
    },
    state: function(){return st;}
  };

  // Wire into the existing player bootstrap: the Phase-4 script exposes
  // the video element as window.__playerEl once the stream is authorized.
  var _origPlay = null;
  // Audio permission (wrapper §3): when a PROGRAMMATIC play of the
  // authorized content element is rejected (unmuted autoplay blocked
  // after a long pre-roll), surface the one-tap "Tap to play" overlay —
  // the tap IS the permission gesture. One handler, no repeated
  // prompts, never a loop; ads stay muted.
  function showTapToPlay(el){
    var box = document.getElementById('playerbox');
    if(!el || !box || box.querySelector('.tapplay')){ return; }
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'tapplay';
    b.textContent = '\u25B6 Tap to play';
    b.addEventListener('click', function(){
      b.remove();
      try{
        var q = _origPlay ? _origPlay() : el.play();
        if(q && q.catch){ q.catch(function(){}); }
      }catch(e){}
    });
    box.appendChild(b);
  }
  function hookPlayer(){
    var el = window.__playerEl;
    if(!el || el.__adHooked){return;}
    el.__adHooked = true;
    _origPlay = el.play.bind(el);
    el.play = function(){
      if(window.__adStage.__done){return _origPlay();}
      window.__adStage.__done = true;
      var args = arguments;
      window.__adStage.preroll(function(){
        // AD_COMPLETED / AD_FAILED -> content
        st='PLAYING_CONTENT';
        var pr = _origPlay.apply(el, args);
        if(pr && pr.catch){ pr.catch(function(){ showTapToPlay(el); }); }
        return pr;
      });
      return Promise.resolve();
    };
    el.addEventListener('timeupdate', function(){
      if(st!=='PLAYING_CONTENT'){return;}
      var d = el.duration||0;
      if(d < 120){return;}  // spec §43: no mid-roll on short videos
      var mid = d*0.5;
      var t = el.currentTime||0;
      var crossed = (el.__lastT||0) < mid && t >= mid;
      el.__lastT = t;
      if(crossed && !consumedBreaks['m50']){
        var wasPaused = el.paused;
        if(!wasPaused){
          el.pause();
          window.__adStage.midroll('m50', function(){
            var mp = el.play();
            if(mp && mp.catch){ mp.catch(function(){ showTapToPlay(el); }); }
          });
        } else {
          consumedBreaks['m50'] = true;
        }
      }
    }, false);
  }
  var _iv = setInterval(function(){
    if(window.__playerEl){hookPlayer(); clearInterval(_iv);}
  }, 120);
  setTimeout(function(){clearInterval(_iv);}, 20000);
})();
</script>"""


async def handle_site_api_session(request):
    """POST /site/api/session — the spec §21/§22 LOGIN.

    Body: {init_data, confirm_user_id?, confirm_username?}. initData is
    HMAC-validated server-side (multi-token). The entered identity is ONLY
    an additional confirmation compared against the AUTHENTICATED identity
    — a mismatch is a hard 403 (user A can never enter user B's identity).
    Success issues the signed session cookie."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_session", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    init_data = str((body or {}).get("init_data") or "")[:8192]
    confirm_id = str((body or {}).get("confirm_user_id") or "").strip()[:32]
    confirm_un = str((body or {}).get("confirm_username") or "").strip()[:64]
    if not init_data:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    tools = _tools(deps)
    verified = await tools.multi_auth.validate_init_data(init_data)
    if verified is None:
        logger.info("WEBSITE_SESSION_REJECTED (invalid initData)")
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    tg_user = verified.get("user") or {}
    auth_identity = {
        "user_id": verified.get("user_id"),
        "username": tg_user.get("username") or "",
    }
    if not identity_matches(auth_identity,
                            confirm_id or None, confirm_un or None):
        logger.info("WEBSITE_SESSION_IDENTITY_MISMATCH user_id=%s "
                    "(entered confirmation rejected)",
                    verified.get("user_id"))
        return _aiohttp_web.json_response(
            {"ok": False, "error": "identity_mismatch",
             "message": "The entered ID/username does not match your "
                        "verified Telegram account."},
            status=403)
    codec = _session_codec(deps)
    token = codec.issue_session(
        int(verified.get("user_id") or 0),
        username=str(tg_user.get("username") or ""),
        first_name=str(tg_user.get("first_name") or ""))
    logger.info("WEBSITE_SESSION_ISSUED user_id=%s via=%s",
                verified.get("user_id"), verified.get("via"))
    secure = request.scheme == "https" or \
        "https" in str(request.url).lower()
    name, value = session_cookie_header(token, ttl_seconds=codec.ttl_seconds,
                                        secure=secure)
    resp = _aiohttp_web.json_response({
        "ok": True,
        "user": {"id": verified.get("user_id"),
                 "username": tg_user.get("username"),
                 "first_name": tg_user.get("first_name")},
    })
    resp.headers[name] = value
    return resp


async def handle_site_api_session_age(request):
    """POST /site/api/session/age — the 18+ confirmation (spec §29): the
    age_ok claim is issued ONLY server-side, ONLY for a valid session,
    ONLY on an explicit confirm."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    session = await _session_of(request, deps)
    if session is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    if not ratelimit.check_rate("site_session", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    if not bool((body or {}).get("age_confirm")):
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    codec = _session_codec(deps)
    token = codec.issue_session(
        int(session.get("user_id") or 0),
        username=str(session.get("username") or ""),
        first_name=str(session.get("first_name") or ""),
        age_ok=True,
        session_key=str(session.get("session_key") or ""))
    secure = request.scheme == "https" or "https" in str(request.url).lower()
    name, value = session_cookie_header(token, ttl_seconds=codec.ttl_seconds,
                                        secure=secure)
    resp = _aiohttp_web.json_response({"ok": True, "age_ok": True})
    resp.headers[name] = value
    return resp


def _valid_website_gate_key(key: str) -> bool:
    """V26.2: the server-rendered website gate-key shapes ONLY —
    'w|{listing}' or 'w|{listing}|{file_pk}' with bounded hex/alnum parts.
    Client input that does not match is ignored (never an error — the
    legacy full-requirement verify answers instead)."""
    import re as _re
    return bool(_re.fullmatch(r"w\|[A-Za-z0-9_-]{1,64}(\|[0-9]{1,20})?",
                              str(key or "")))


async def handle_site_api_fj_verify(request):
    """POST /site/api/forcejoin/verify — the spec §24 Verify Again: a
    fresh BACKEND membership re-check (never marks membership complete
    from the click alone). Body: {init_data?, gate_key?} — session
    identity is used when init_data is absent (the session was
    HMAC-verified at login).

    V26.2 (bot-41 §16-§24): ``gate_key`` (echoed from the server-rendered
    gate page / player context, FORMAT-VALIDATED here — website keys only,
    bounded length) selects the PER-GATE view: the verify outcome is
    THIS gate's pinned batch ("joined" = the pinned batch is complete —
    the progressive-unlock verdict), and ``not_joined`` never contains a
    future batch. Without a gate_key the legacy full-requirement re-check
    applies (feed-level gate — unchanged). The key is only a SELECTOR for
    a server-persisted presentation: membership itself is always
    re-verified live server-side.

    BOT-43 (§4 work-stream C) — the AUTHORITATIVE completed-state
    contract: the success response carries the UNAMBIGUOUS completed
    state ``{"ok": true, "joined": true, "remaining": [], "complete":
    true}`` (``remaining`` IS the not_joined list — empty only on
    success; ``complete`` mirrors the joined verdict). Partial
    responses keep ``not_joined`` (== ``remaining``) listing ONLY the
    still-unjoined channels of THIS gate's batch. The gate's LISTING is
    also resolved to its canonical payload (the SAME resolution the
    play-gate page uses) so ``payload_id`` reaches the FJ gate — the
    satisfied-path state-machine drive then carries THIS payload into
    its BOT6_FJ_BATCH_COMPLETE / BOT6_FJ_PAYLOAD_UNLOCK bookkeeping
    exactly like the play gate (a failed resolution keeps
    payload_id=None: the gate still verifies membership, only the
    bookkeeping skips — NO validation is weakened)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_fj_verify", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    uid = None
    init_data = ""
    gate_key = ""
    try:
        body = await request.json()
        init_data = str((body or {}).get("init_data") or "")[:8192]
        gate_key = str((body or {}).get("gate_key") or "")[:96]
    except Exception:  # noqa: BLE001
        body = {}
    # FORMAT VALIDATION: only well-formed WEBSITE gate keys (the exact
    # shapes this server renders) are honored — anything else is ignored
    # (the legacy full-requirement view answers, still fail-closed).
    if gate_key and not _valid_website_gate_key(gate_key):
        gate_key = ""
    if init_data:
        tools = _tools(deps)
        verified = await tools.multi_auth.validate_init_data(init_data)
        if verified is not None:
            uid = int(verified.get("user_id") or 0) or None
    if uid is None:
        session = await _session_of(request, deps)
        if session is not None:
            uid = int(session.get("user_id") or 0) or None
    if uid is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    # BOT-43 (§4 work-stream C): resolve the gate's LISTING → the canonical
    # payload the SAME way the play-gate page does (FJ_PLAY_GATE resolution:
    # _published_detail → canonical.kind == "payload" → payload_id) so the
    # verify round-trip threads payload_id into the FJ gate — the satisfied
    # path then records the BOT6_FJ_PAYLOAD_UNLOCK bookkeeping for THIS
    # payload exactly like the play gate. The gate_key here is already
    # FORMAT-VALIDATED ("w|{listing}(|{file_pk})"), so the listing slice is
    # bounded hex/alnum. A failed/absent resolution keeps payload_id=None
    # (the gate still verifies membership — only the unlock bookkeeping
    # skips). This is pure BOOKKEEPING enrichment: the key stays a SELECTOR
    # over server-persisted state and NO validation is weakened.
    _fj_pid: Optional[int] = None
    if gate_key:
        try:
            _listing_opaque = str(gate_key.split("|")[1] or "")
        except (IndexError, ValueError):
            _listing_opaque = ""
        if _listing_opaque:
            try:
                _gate_detail = await _published_detail(
                    _tools(deps), _listing_opaque)
            except Exception:  # noqa: BLE001 — bookkeeping only, never gate
                _gate_detail = None
            if _gate_detail is not None:
                _canon = _gate_detail.get("canonical") or {}
                if _canon.get("kind") == "payload":
                    try:
                        _fj_pid = int(_canon.get("payload_id") or 0) or None
                    except (TypeError, ValueError):
                        _fj_pid = None
    unjoined, _needs_gate, verify_failed = await _fj_gate(
        deps, {"user_id": uid}, payload_id=_fj_pid,
        gate_key=gate_key or None)
    views = _fj_views(deps, unjoined)
    # GAP-CLOSURE spec §14/§15: NEVER claim joined unless the server-side
    # membership check actually SUCCEEDED. A failed/unavailable check
    # returns the honest "not joined + verification unavailable" shape
    # (the gate JS then shows "Could not verify right now — please retry.")
    # — an exception mid-check must not be interpreted as membership.
    joined = (not views) and not verify_failed
    health = await _fj_health_summary(deps)
    logger.info("WEBSITE_FJ_VERIFY user_id=%s joined=%s remaining=%s "
                "gate_key=%s fj_health=%s verify_failed=%s complete=%s "
                "remaining_count=%s payload_id=%s",
                uid, joined, len(views), gate_key or "-",
                health.get("fj_health"),
                verify_failed, bool(joined), len(views),
                _fj_pid if _fj_pid is not None else "-")
    # BOT-43 (§4 work-stream C): ``remaining`` IS the not_joined list (the
    # still-unjoined channels of THIS gate's pinned batch — [] on success)
    # and ``complete`` is the unambiguous completed state (True ONLY when
    # the live server-side verification succeeded with nothing remaining).
    # Every existing field is kept for backward compatibility.
    resp: Dict[str, Any] = {
        "ok": True, "joined": joined, "not_joined": views,
        "remaining": views, "complete": bool(joined),
        "fj_health": health.get("fj_health"),
        "healthy": health.get("healthy"), "total": health.get("total"),
    }
    if verify_failed:
        resp["verification"] = "unavailable"
        resp["verify_hint"] = ("Membership verification is unavailable "
                                "right now — nothing was marked as joined. "
                                "Please retry in a moment.")
    elif not joined:
        resp["verify_hint"] = ("Join the channels above in Telegram, "
                                "then tap Verify Again.")
    # BOT-43 (§4 work-stream C) — the presentation telemetry: the
    # completed-state verdict for THIS gate, in the EXACT field order the
    # service-side FJ_PRESENTATION lines use (user_id, gate_key, state,
    # remaining_count, payload_id) so the two sources are greppable as one
    # event. Safe fields only: the gate key is the server-rendered w|...
    # selector (already logged by WEBSITE_FJ_VERIFY / FJ_PLAY_GATE), the
    # payload id is numeric — never tokens/secrets.
    logger.info(
        "FJ_PRESENTATION user_id=%s gate_key=%s state=%s "
        "remaining_count=%s payload_id=%s",
        uid, gate_key or "-",
        "complete" if joined else "remaining",
        len(views), _fj_pid if _fj_pid is not None else "-")
    return _aiohttp_web.json_response(resp)


# V26 PLAYER / AGE-GATE telemetry — the allowlisted client-event sink.
# The contract (mirrored by the tiny __siteTel client helper in html.py):
#   * EVERY event name is checked against a FIXED allowlist (PLAYER_OPEN,
#     PLAYER_READY, PLAYER_PLAY, PLAYER_PAUSE, QUALITY_CHANGE, PLAYER_BACK,
#     PLAYER_DESTROY, PLAYER_STREAM_ERROR, PLAYER_REAUTH, PLAYER_CLOSE,
#     AGE_GATE_* lifecycle) — anything else is a controlled 400;
#   * field names are bounded + allowlisted per event; values are coerced
#     (numbers pass through rounded, everything else becomes a bounded
#     string) — no JSON blobs, no URLs, no tokens can ever reach the log;
#   * the caller must hold a valid SITE SESSION (the signed cookie that
#     was HMAC-verified at login) — anonymous posts are a controlled 401;
#   * rate-limited per IP (a playback session emits ~6-10 events);
#   * fire-and-forget by design: the response is always a tiny {ok:true}
#     JSON — telemetry must never break the player UX.
# BOT-43 (§4 work-stream C) adds the PLAYER CONTROL-SURFACE lifecycle
# emitted by the player's custom controls (html.py): PLAYER_CONTROL_MODE
# (the custom-vs-native controls decision + reason — the BOT-43 double-
# controls fix), PLAYER_SPEED_CHANGE / PLAYER_QUALITY_CHANGE (the playback
# mutation events, quality now the QUALITY_CHANGE successor with the real
# level), PLAYER_FULLSCREEN (enter/exit transitions). Same coercion rules:
# mode/reason/to/state are bounded strings (≤64), level/position_s are
# numbers (rounded) — no secrets, no URLs, no tokens.
_TELEMETRY_EVENTS = {
    "PLAYER_OPEN": frozenset(),
    "PLAYER_READY": frozenset({"tag"}),
    "PLAYER_PLAY": frozenset({"position_s"}),
    "PLAYER_PAUSE": frozenset({"position_s"}),
    "QUALITY_CHANGE": frozenset({"to", "level", "position_s"}),
    "PLAYER_BACK": frozenset({"from"}),
    "PLAYER_DESTROY": frozenset(),
    "PLAYER_STREAM_ERROR": frozenset({"error_code"}),
    "PLAYER_REAUTH": frozenset(),
    "PLAYER_CLOSE": frozenset(),
    # BOT-43 (§4 work-stream C) — the player CONTROL-SURFACE lifecycle
    # (emitted by the custom controls in html.py). mode/reason/to/state
    # are bounded strings; level/position_s are numbers (rounded) — the
    # coercion in handle_site_api_telemetry already enforces all of it.
    "PLAYER_CONTROL_MODE": frozenset({"mode", "reason"}),
    "PLAYER_SPEED_CHANGE": frozenset({"to", "position_s"}),
    "PLAYER_QUALITY_CHANGE": frozenset({"to", "level", "position_s"}),
    "PLAYER_FULLSCREEN": frozenset({"state", "position_s"}),
    "AGE_GATE_RENDER": frozenset(),
    "AGE_GATE_HANDLER_ATTACHED": frozenset(),
    "AGE_GATE_IDENTITY_WAIT": frozenset(),
    "AGE_GATE_CLICK": frozenset(),
    "AGE_GATE_IDENTITY_READY": frozenset(),
    "AGE_GATE_REQUEST_START": frozenset(),
    "AGE_GATE_REQUEST_RESULT": frozenset({"status", "error"}),
    "AGE_GATE_STATE_UPDATED": frozenset({"state"}),
    "AGE_GATE_TRANSITION_COMPLETE": frozenset(),
    "AGE_GATE_ERROR": frozenset({"error"}),
    # V26 FINAL (Part 7) — SPA navigation lifecycle. from/to carry
    # SANITIZED route paths (the client truncates long segments so
    # capability tokens/opaque refs NEVER reach the log), route is the
    # coarse route NAME, source names the trigger, state_id is the
    # client-side navigation sequence number.
    "SITE_NAV_PUSH": frozenset({"from", "to", "route", "source",
                                "state_id"}),
    "SITE_NAV_REPLACE": frozenset({"from", "to", "route", "source",
                                   "state_id"}),
    "SITE_NAV_POP": frozenset({"from", "to", "route", "source",
                               "state_id"}),
    "SITE_NAV_BACK": frozenset({"from", "to", "route", "source",
                                "state_id"}),
    "SITE_NAV_FALLBACK": frozenset({"from", "to", "route", "source",
                                    "state_id"}),
    "SITE_NAV_ERROR": frozenset({"from", "to", "route", "source",
                                 "state_id"}),
    # V26 FINAL (Part 8) — the website action lifecycle (server-round-
    # trip actions: get-file, force-join verify, age confirm, react...).
    # action is the action NAME, reason is a bounded failure reason (the
    # honest reason string — never a raw error object/URL/token).
    "SITE_ACTION_START": frozenset({"action"}),
    "SITE_ACTION_SUCCESS": frozenset({"action"}),
    "SITE_ACTION_FAILED": frozenset({"action", "reason"}),
}


async def handle_site_api_telemetry(request):
    """POST /site/api/telemetry — the bounded, allowlisted, session-
    authenticated client telemetry sink (V26 PLAYER_* + AGE_GATE_* events).
    Logs one WEBSITE_TELEMETRY line per accepted event. NEVER accepts
    secrets (no token/initData/URL fields exist in the allowlist)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_telemetry", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    # Session gate: telemetry is only accepted from a signed site session.
    session = await _session_of(request, deps)
    if session is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=401)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001 — malformed body = controlled 400
        body = None
    if not isinstance(body, dict):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "bad_request"}, status=400)
    event = str(body.get("event") or "")[:40]
    allowed_fields = _TELEMETRY_EVENTS.get(event)
    if allowed_fields is None:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unknown_event"}, status=400)
    safe_fields: Dict[str, Any] = {}
    for k, v in (body or {}).items():
        if k == "event" or k not in allowed_fields:
            continue
        if isinstance(v, bool):
            safe_fields[str(k)[:24]] = int(v)
        elif isinstance(v, (int, float)):
            safe_fields[str(k)[:24]] = (round(float(v), 3)
                                        if v == v else 0)  # NaN -> 0
        elif v is None:
            continue
        else:
            safe_fields[str(k)[:24]] = str(v)[:64]
    uid = int(session.get("user_id") or 0)
    logger.info(
        "WEBSITE_TELEMETRY event=%s user_id=%s %s",
        event, uid,
        " ".join(f"{k}={safe_fields[k]}" for k in sorted(safe_fields)))
    return _aiohttp_web.json_response({"ok": True})


async def handle_site_api_ads_decision(request):
    """POST /site/api/ads/decision — the SERVER-side ad decision (spec
    §35/§42). Authorization ordering (spec §45): the caller asks ONLY
    after content authorization; the ad decision NEVER grants access."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_ads_api", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    placement = str((body or {}).get("placement") or "")[:40]
    # GAP-CLOSURE spec §11/§52: the ad identity comes from the SERVER-side
    # session ONLY. Client-supplied user_id / session_key values in the
    # body are NEVER trusted — they can neither select another user's ad
    # identity nor rotate the per-session ad frequency key (a mismatched
    # client id is ignored in favor of the session).
    session = await _session_of(request, deps)
    uid = int(session.get("user_id") or 0) or None if session else None
    skey = str(session.get("session_key") or "") or None if session else None
    category = str((body or {}).get("category") or "")[:40] or None
    device = _device_of(request)
    svc = _ads_service(deps)
    ad = await svc.get_ad_for_placement(
        placement, user_id=uid, session_key=skey,
        category_slug=category, device=device)
    if ad is None:
        return _aiohttp_web.json_response({"ok": True, "ad": None})
    return _aiohttp_web.json_response({"ok": True, "ad": ad})


async def handle_site_api_ads_event(request):
    """POST /site/api/ads/event — bounded ad event recording (spec §51).
    Creative ids are opaque; the user identity comes from the session
    (never the client)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_ads_api", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    try:
        creative_id = int((body or {}).get("creative_id") or 0)
    except (TypeError, ValueError):
        creative_id = 0
    placement = str((body or {}).get("placement") or "")[:40]
    event = str((body or {}).get("event") or "")[:16]
    # B10-W1 (§14): display-only VIDEO_AD_* lifecycle records from the
    # website player's pre-roll adapter. The player NEVER sends an
    # adCompleted-style claim — these records are recognized by the
    # CLOSED slug set (video_ads.client_event_full_name), logged with
    # the FULL §14 event names server-side and acknowledged ok. They
    # can NEVER touch policy state (§12): the authoritative decision
    # and frequency accounting happened server-side at issuance; there
    # is no creative to record, so the Ads-Platform path below is
    # skipped entirely for these records.
    try:
        from app.web.site.video_ads import (
            client_event_full_name, log_video_ad_client_event)
        va_name = client_event_full_name(event)
    except Exception:  # noqa: BLE001 — display-only, never blocks
        va_name = ""
    if va_name:
        sess_va = await _session_of(request, deps)
        uid_va = int(sess_va.get("user_id") or 0) or None \
            if sess_va else None
        log_video_ad_client_event(
            va_name,
            provider=str((body or {}).get("provider") or "")[:16],
            reason=str((body or {}).get("reason") or "")[:64],
            user_id=uid_va)
        return _aiohttp_web.json_response({"ok": True})
    if creative_id <= 0 or not placement or not event:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    session = await _session_of(request, deps)
    uid = int(session.get("user_id") or 0) or None if session else None
    svc = _ads_service(deps)
    await svc.record_event(creative_id, placement, uid, event)
    return _aiohttp_web.json_response({"ok": True})


async def handle_site_api_pack(request):
    """POST /site/api/pack — start a download pack (spec §59): canonical
    authorization per file (Access Engine), a signed short-lived pack
    token, bounded by files/bytes settings. Large files follow the SAME
    transport policy as streaming (Local Bot API required when oversized)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_pack", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    init_data = str((body or {}).get("init_data") or "")[:8192]
    listing = str((body or {}).get("listing") or "")[:64]
    if not listing:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "bad_request"},
                                          status=400)
    # identity: init_data (fresh) or the session
    uid = None
    if init_data:
        tools = _tools(deps)
        verified = await tools.multi_auth.validate_init_data(init_data)
        if verified is not None:
            uid = int(verified.get("user_id") or 0) or None
    if uid is None:
        session = await _session_of(request, deps)
        if session is not None:
            uid = int(session.get("user_id") or 0) or None
    if uid is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=401)
    # settings + canonical detail
    try:
        enabled = await deps.db.get_setting_bool("website_pack_enabled",
                                                 True)
    except Exception:  # noqa: BLE001
        enabled = True
    if not enabled:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "packs_disabled",
             "message": "Download packs are currently switched off."},
            status=503)
    tools = _tools(deps)
    detail = await _published_detail(tools, listing)
    if detail is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "not_found"},
                                          status=404)
    canonical = detail.get("canonical") or {}
    payload_id = (int(canonical["payload_id"])
                  if canonical.get("kind") == "payload" else None)
    # 18+ backend enforcement (B10-W2: the SHARED _listing_age_restricted
    # predicate — the identical rule every other surface enforces).
    # B23/P0-3 (§3.1 age-gate identity binding): the session's age_ok now
    # counts ONLY when the session belongs to the SAME identity the
    # caller authenticated (uid). User A's age-approved session cookie +
    # user B's fresh init_data must NOT open B's 18+ gate — the exact
    # stream.py::_session_age_confirmed pattern (spec §3.1 acceptance:
    # cross-identity access refused).
    session = await _session_of(request, deps)
    _session_age_ok = bool(
        session is not None
        and int(session.get("user_id") or 0) == int(uid)
        and bool(session.get("age_ok")))
    if not _session_age_ok \
            and await _listing_age_restricted(
                deps, int((detail.get("listing") or {}).get("id") or 0)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "not_found"}, status=404)
    # Access Engine verdict per payload (FJ is checked inside the engine)
    # B23/P0-1: the website-playback authorization chokepoint — every
    # engine reason stays enforced EXCEPT watch_ad_required (waived for
    # website playback; Telegram-side delivery still enforces it).
    # V26.2 (bot-41 §16-§24): listing-level gate key — the pack's pinned
    # batch (progressive batching).
    try:
        bot_ref = getattr(deps, "bot_ref", None)
        bot = bot_ref() if callable(bot_ref) else None
        from app.web.site.authz import authorize_website_playback
        verdict = await authorize_website_playback(
            deps, bot, uid, payload_id=payload_id,
            gate_key="w|%s" % str(listing or ""))
    except Exception as engine_exc:  # noqa: BLE001 — TASK A2 telemetry
        from app.web.site.authz import log_website_engine_failure
        log_website_engine_failure(
            "pack_issue", engine_exc, user_id=uid, payload_id=payload_id,
            gate_key="w|%s" % str(listing or ""))
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "engine_error"},
                                          status=500)
    if not verdict.authorized:
        return _aiohttp_web.json_response(
            {"ok": True, "authorized": False,
             "reason": verdict.reason}, status=200)
    files = detail.get("files") or []
    try:
        max_files = await deps.db.get_setting_int("website_pack_max_files",
                                                   50)
        max_bytes = await deps.db.get_setting_int("website_pack_max_bytes",
                                                  2147483648)
    except Exception:  # noqa: BLE001
        max_files, max_bytes = 50, 2147483648
    if not files:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "empty_pack",
             "message": "This payload has no files to pack."},
            status=400)
    if len(files) > int(max_files):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "too_many_files",
             "message": f"This payload has {len(files)} files; the pack "
                        f"limit is {max_files}."},
            status=400)
    total = sum(int(f.get("file_size") or 0) for f in files)
    if total > int(max_bytes):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "too_large",
             "message": f"Pack size {total} exceeds the limit {max_bytes}."},
            status=400)
    # mint the pack token (bounded lifetime)
    import time as _time
    from app.web.site.tokens import make_video_token_codec as _mvc
    codec = _mvc(getattr(deps, "bot_token", None), ttl_seconds=600)
    pks = ",".join(str(int(f.get("file_pk") or 0)) for f in files)
    token = codec.encode_video_ref(
        f"pack:{listing}:{uid}:{pks}", 1)  # file_pk must be > 0 (decode gate)
    svc = make_website_service(deps.db)
    url = svc.build_site_url(f"site/pack/{token}",
                             await svc.website_public_base_url())
    logger.info("WEBSITE_PACK_ISSUE user_id=%s listing=%s files=%s "
                "bytes=%s", uid, listing, len(files), total)
    return _aiohttp_web.json_response({
        "ok": True, "authorized": True, "pack_url": url,
        "files": len(files), "bytes": total})


async def handle_site_pack_download(request):
    """GET /site/pack/{token} — stream the ZIP archive (spec §59): every
    member goes through the SAME authorized transport (Media Gateway
    sources); generation is bounded and cleanup is automatic."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_json()
    if not ratelimit.check_rate("site_pack", _client_ip(request)):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "rate_limited"}, status=429)
    from app.web.site.tokens import make_video_token_codec as _mvc
    codec = _mvc(getattr(deps, "bot_token", None), ttl_seconds=600)
    decoded = codec.decode_video_ref(str(request.match_info.get("token")
                                         or ""))
    if decoded is None or not str(decoded.get("listing") or "").startswith(
            "pack:"):
        return _aiohttp_web.Response(
            text=_html.bad_request_page("This pack link is invalid or has "
                                        "expired."),
            content_type="text/html", status=400)
    try:
        _, listing, uid_s, pks_s = str(decoded.get("listing")).split(":", 3)
        uid = int(uid_s)
        pks = [int(x) for x in pks_s.split(",") if x.isdigit()]
    except Exception:  # noqa: BLE001
        return _aiohttp_web.Response(
            text=_html.bad_request_page("Malformed pack link."),
            content_type="text/html", status=400)
    # GAP-CLOSURE spec §11 cross-user hardening: when the request carries a
    # VALID site session, its identity must MATCH the pack token's embedded
    # user — a signed pack URL that leaks to another logged-in visitor is
    # refused with a generic 403 (no existence leak). Anonymous downloads
    # (no session cookie) still rely on the signed token + Access Engine
    # re-authorization below.
    session = await _session_of(request, deps)
    if session is not None and int(session.get("user_id") or 0) != uid:
        logger.info("WEBSITE_PACK_IDENTITY_MISMATCH session_user=%s "
                    "token_user=%s (refused)",
                    session.get("user_id"), uid)
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unauthorized"},
                                          status=403)
    tools = _tools(deps)
    detail = await _published_detail(tools, listing)
    if detail is None:
        return _aiohttp_web.Response(text=_html.not_found_page(),
                                     content_type="text/html", status=404)
    canonical = detail.get("canonical") or {}
    payload_id = (int(canonical["payload_id"])
                  if canonical.get("kind") == "payload" else None)
    # RE-AUTHORIZE at download time (never trust the token alone).
    # B23/P0-1: the website-playback authorization chokepoint — every
    # engine reason stays enforced EXCEPT watch_ad_required (waived for
    # website playback; Telegram-side delivery still enforces it).
    # V26.2 (bot-41 §16-§24): listing-level gate key — the pack's pinned
    # batch (progressive batching).
    try:
        bot_ref = getattr(deps, "bot_ref", None)
        bot = bot_ref() if callable(bot_ref) else None
        from app.web.site.authz import authorize_website_playback
        verdict = await authorize_website_playback(
            deps, bot, uid, payload_id=payload_id,
            gate_key="w|%s" % str(listing or ""))
    except Exception as engine_exc:  # noqa: BLE001 — TASK A2 telemetry
        from app.web.site.authz import log_website_engine_failure
        log_website_engine_failure(
            "download_gate", engine_exc, user_id=uid, payload_id=payload_id,
            gate_key="w|%s" % str(listing or ""))
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "engine_error"},
                                          status=500)
    if not verdict.authorized:
        return _aiohttp_web.json_response(
            {"ok": False, "error": "unauthorized"}, status=403)
    files = [f for f in (detail.get("files") or [])
             if int(f.get("file_pk") or 0) in set(pks)]
    if not files:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "not_found"},
                                          status=404)

    gw = getattr(deps, "media_gateway", None)
    if gw is None or not hasattr(gw, "stack"):
        return _aiohttp_web.json_response(
            {"ok": False, "error": "streaming_unavailable"}, status=503)
    stack = gw.stack

    import binascii as _binascii
    import struct as _struct

    resp = _aiohttp_web.StreamResponse(status=200, headers={
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="pack.zip"',
        "Cache-Control": "no-store",
    })
    await resp.prepare(request)
    sent = 0
    # A minimal STORE-only ZIP streamer (bounded memory: ONE file buffered
    # at a time; every member flows through the SAME authorized transport).
    central = []
    try:
        for f in files:
            arc = _zip_arcname(str(f.get("file_name")
                                   or f"part{f.get('file_pk')}.bin"))
            name_b = arc.encode("utf-8")
            data = bytearray()
            handle = await stack.resolve(_pack_row(f, detail))
            async for chunk in stack.open(handle):
                data.extend(chunk)
            blob = bytes(data)
            crc = _binascii.crc32(blob) & 0xFFFFFFFF
            offset = sent
            # local file header (store method)
            lfh = (_struct.pack("<IHHHHHIIIHH", 0x04034b50, 20, 0, 0, 0,
                                0, crc, len(blob), len(blob),
                                len(name_b), 0) + name_b)
            await resp.write(lfh)
            await resp.write(blob)
            sent += len(lfh) + len(blob)
            central.append((name_b, crc, len(blob), len(blob), offset))
        # central directory + EOCD
        cd = bytearray()
        for name_b, crc, csize, usize, offset in central:
            cd.extend(_struct.pack("<IHHHHHHIIIHHHHHII", 0x02014b50,
                                   20, 20, 0, 0, 0, 0, crc, csize, usize,
                                   len(name_b), 0, 0, 0, 0, 0, offset)
                      + name_b)
        eocd = _struct.pack("<IHHHHIIH", 0x06054b50, 0, 0, len(central),
                            len(central), len(cd), sent, 0)
        await resp.write(bytes(cd))
        await resp.write(eocd)
        sent += len(cd) + len(eocd)
        await resp.write_eof()
        logger.info("WEBSITE_PACK_COMPLETE user_id=%s files=%s bytes=%s",
                    uid, len(files), sent)
    except Exception as exc:  # noqa: BLE001 — honest abort
        logger.warning("WEBSITE_PACK_ABORT reason=%s", type(exc).__name__)
        resp.force_close()
    return resp


def _zip_arcname(name: str) -> str:
    """A safe archive member name (no path traversal, no absolute paths)."""
    import re as _re
    cleaned = _re.sub(r"[^A-Za-z0-9._ -]", "_", str(name or "file.bin"))
    cleaned = cleaned.replace("..", "_").lstrip("/\\.")
    return cleaned[:120] or "file.bin"


def _pack_row(f: Dict[str, Any], detail: Dict[str, Any]):
    """A resolver-compatible row view for one pack member file.

    A.6.6 (bot-25): the channel id is the file's OWN durable source
    reference first (``files[*].channel_id`` — projected by
    get_listing_detail for BOTH canonical kinds since the A.4/A.6.6
    pass), then the listing's canonical channel (collections), and 0
    only as the last-resort fallback. Payload listings used to land on
    channel_id=0 (a fabricated source ref on the MediaHandle)."""
    return {
        "file_unique_id": f.get("file_unique_id"),
        "channel_id": (f.get("channel_id")
                       or (detail.get("canonical") or {}).get("channel_id")
                       or 0),
        "message_id": f.get("message_id") or 0,
        "file_name": f.get("file_name"),
        "mime_type": f.get("mime_type"),
        "file_size": f.get("file_size"),
    }


# ------------------------------------------------------- network / static
async def handle_site_network(request):
    """GET /site/network — the Network Mini App surface (spec §9): the
    user's registered bots, points ledger and the public directory — all
    from the AUTHENTICATED identity (session), no secrets exposed."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    uid = int(session.get("user_id") or 0)
    data: Dict[str, Any] = {"my_bots": [], "ledger": [], "directory": [],
                            "points": {"balance": 0}}
    try:
        rows = await deps.db.list_network_bots()
        rows = [dict(r) for r in (rows or [])]
        data["directory"] = [
            {"username": r.get("username"), "status": r.get("status"),
             "health": r.get("health") or "UNKNOWN"}
            for r in rows if int(r.get("enabled") or 1)][:12]
        data["my_bots"] = [
            {"username": r.get("username"), "status": r.get("status"),
             "health": r.get("health") or "UNKNOWN"}
            for r in rows
            if int(r.get("owner_user_id") or 0) == uid][:10]
    except Exception:  # noqa: BLE001 — honest empty views
        pass
    try:
        pts = await deps.db.points_balance(uid)
        data["points"] = {"balance": int(pts or 0)}
        ledger = await deps.db.points_history(uid, limit=8)
        out_ledger = []
        for r in (ledger or []):
            row = dict(r) if not isinstance(r, dict) else r
            out_ledger.append({
                "delta": int(row.get("amount") or 0),
                "reason": row.get("event_type") or "points"})
        data["ledger"] = out_ledger
    except Exception:  # noqa: BLE001
        pass
    return _aiohttp_web.Response(
        text=_screens.network_page(
            data, username=str(session.get("username") or "")),
        content_type="text/html")


async def handle_site_about(request):
    """GET /site/about — the More-menu About page (spec §28)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    return _aiohttp_web.Response(text=_screens.about_page(),
                                 content_type="text/html")


async def handle_site_settings(request):
    """GET /site/settings — client-side settings (spec §28/§31)."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    return _aiohttp_web.Response(
        text=_screens.settings_page(
            username=str(session.get("username") or ""),
            age_ok=bool(session.get("age_ok"))),
        content_type="text/html")


async def handle_site_collections(request):
    """GET /site/collections — the More-menu Collections view (spec §28):
    collection-type listings only."""
    if _aiohttp_web is None:
        return _aiohttp_web.Response(status=503)
    deps = _deps()
    if deps is None:
        return _aiohttp_web.json_response({"ok": False,
                                           "error": "unavailable"},
                                          status=503)
    if not await _website_on(deps):
        return _maintenance_html()
    session, gate_resp = await _require_session_page(request, deps)
    if gate_resp is not None:
        return gate_resp
    tools = _tools(deps)
    age_ok = bool(session.get("age_ok"))
    try:
        rows, total = await deps.db.list_website_payloads_paged(
            page=1, page_size=36, include_age_restricted=age_ok)
    except Exception:  # noqa: BLE001
        rows, total = [], 0
    items = [d for d in (dict(r) for r in rows)
             if d.get("collection_id")]
    # B24 (Phase 4): collections benefit MOST from the truthful badge
    # (3 videos + 2 photos, not "1 file"). Batch-enrich before render.
    await _enrich_listing_media_counts(deps, items)
    thumb_urls = {str(r.get("opaque_id") or ""): _thumb_url(
        deps, tools, str(r.get("opaque_id") or "")) for r in items}
    chrome = await _page_chrome(request, deps, session)
    return _aiohttp_web.Response(
        text=_screens.collections_page(items, thumb_urls=thumb_urls,
                                       **chrome),
        content_type="text/html")
