"""WEBSITE VIDEO ADS — the provider-agnostic ad layer (spec §9-§16).

A stable, provider-agnostic VIDEO AD architecture for the website video
player (``/site/payload/{opaque}/video/{ref}``), layered ON TOP of the
v37 direct-media pre-roll system (app/web/site/preroll.py) without
regressing it (spec §26):

  * ``VideoAdConfig``     — one resolved configuration snapshot;
  * ``VideoAdDecision``   — the server-side serve/no-serve verdict;
  * ``VideoAdSession``    — SERVER-side frequency accounting;
  * ``VideoAdProvider``   — the abstract provider contract;
  * ``VastAdProvider``    — name="vast": activates when a valid https
    VAST URL is configured (HilltopAds or ANY VAST/VMAP tag endpoint —
    nothing provider-specific is hard-coded, §10/§34);
  * ``DirectMediaProvider`` — name="direct": the v37 behavior (a direct
    https .mp4/.webm source URL);
  * ``VideoAdPlayerAdapter`` — the pure descriptor of what the PLAYER
    must do (slot=PRE_ROLL + the serializable wire subset, §11/§16);
  * ``VideoAdPolicy``    — the ONE decision point mirroring
    ``get_preroll_policy()`` (``get_videoad_policy()``).

Architecture (§10/§11): the player knows only "play an ad before
content" in the ONE stable PRE_ROLL_SLOT; which provider fills the slot
is a configuration/adapter concern. Swapping HilltopAds VAST for any
other provider is a CONFIG/adapter change — player location, slot,
controls, preview and content playback never change (§16).

MODE SEMANTICS (§12): ``provider_controlled`` (the NEW default when
provider=vast) | ``skippable`` | ``non_skippable``. For VAST,
provider_controlled means the ad response's ``skipoffset`` decides
skippability (present → skippable after skipoffset; absent →
non-skippable — a skip button is NEVER fabricated). A FORCED
skippable/non_skippable mode OVERRIDES the skipoffset presence
(skip_delay applies). The v37 mode vocabulary ("skippable",
"non_skippable") keeps working; provider_controlled only has meaning
for the VAST provider — for direct media it degrades to the v37
skippable default (there is no ad-server skipoffset to consult).

SECURITY (§12 — no false claims): the frequency accounting is
SERVER-side at DECISION time, keyed by the AUTHENTICATED Telegram user
id (+ the signed site-session key when present) — the same TTL-map
discipline preroll.py uses. NO client-reachable endpoint can record,
rotate, decrement or reset it: client "adCompleted"-style claims are
display-only records at best and never mutate this state.

Integration (§26): stream.py routes the issuance-time pre-roll
attachment through ``get_videoad_policy().resolve()``. When the
configured provider is "direct"/"none" the policy DELEGATES to the v37
PreRollPolicy (the exact v37 behavior — its own enabled flag, source
URL validation, frequency map and reason vocabulary stay authoritative,
so the v37 direct-media pre-roll keeps working unchanged). When the
provider is "vast" the new VAST decision path runs. The player-facing
wire key ("preroll") and subset STAY THE SAME (stable player contract)
and additionally carry ``provider`` and ``timeout``.

No ad inventory is fabricated: until an admin configures a real VAST
URL the honest verdict is ``not_configured`` ("Video Ads: Not
Configured", §34) and the content video keeps working.
"""
from __future__ import annotations

import logging
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from app.web.site.preroll import (
    PREROLL_COOLDOWN_KEY,
    PREROLL_DEFAULT_COOLDOWN,
    PREROLL_DEFAULT_DURATION,
    PREROLL_DEFAULT_FALLBACK,
    PREROLL_DEFAULT_FREQUENCY,
    PREROLL_DEFAULT_SESSION_FREQUENCY,
    PREROLL_DEFAULT_SKIP_DELAY,
    PREROLL_DURATION_KEY,
    PREROLL_ENABLED_KEY,
    PREROLL_FALLBACK_KEY,
    PREROLL_FREQUENCY_KEY,
    PREROLL_MODE_KEY,
    PREROLL_SESSION_FREQUENCY_KEY,
    PREROLL_SKIP_DELAY_KEY,
    PREROLL_SOURCE_URL_KEY,
    PREROLL_VAST_URL_KEY,
    clamp_cooldown,
    clamp_duration,
    clamp_session_frequency,
    clamp_skip_delay,
    get_preroll_policy,
    is_enabled_value,
    normalize_fallback,
    normalize_frequency,
    validate_preroll_source_url,
    validate_preroll_vast_url,
)

logger = logging.getLogger("payload-bot")

# ------------------------------------------------------------------ keys
# The provider selector + the player VAST timeout are the ONLY new
# settings; every other key/validator is REUSED from preroll.py so the
# v37 direct-media configuration keeps a single source of truth.
PREROLL_PROVIDER_KEY = "website_videoad_provider"
PREROLL_TIMEOUT_KEY = "website_videoad_timeout"

VIDEOAD_PROVIDERS = ("vast", "direct", "none")
VIDEOAD_MODES = ("provider_controlled", "skippable", "non_skippable")

VIDEOAD_DEFAULT_PROVIDER = "none"
VIDEOAD_DEFAULT_TIMEOUT = 8
VIDEOAD_TIMEOUT_MIN = 2
VIDEOAD_TIMEOUT_MAX = 30

# The player-facing wire subset (§16 — stable across providers): the
# "preroll" key on the POST /site/api/stream response carries EXACTLY
# these fields (skip_delay only when the ad can be skippable — the
# v37 rule; duration/source_url/vast_url only when non-empty).
VIDEOAD_WIRE_KEYS = ("provider", "mode", "duration", "source_url",
                     "vast_url", "fallback", "frequency", "timeout")


# ------------------------------------------------------------- validators
def normalize_videoad_provider(value: Any) -> str:
    """Normalize the ``website_videoad_provider`` selector (§10).

    Accepts "vast" | "direct" | "none" (case/space tolerant); anything
    else degrades to the fail-safe default "none" (the v37 direct-media
    delegation — never a fabricated provider)."""
    v = str(value or "").strip().lower().replace("-", "_")
    if v in ("vast", "vast_tag", "vast_url"):
        return "vast"
    if v in ("direct", "direct_media", "source", "mp4"):
        return "direct"
    return VIDEOAD_DEFAULT_PROVIDER


def clamp_videoad_timeout(value: Any) -> int:
    """Clamp the player's VAST response timeout, seconds (default 8,
    clamp 2..30 — §12 'ad timeout')."""
    try:
        v = int(str(value).strip())
    except (TypeError, ValueError):
        return VIDEOAD_DEFAULT_TIMEOUT
    return max(VIDEOAD_TIMEOUT_MIN, min(VIDEOAD_TIMEOUT_MAX, v))


def normalize_videoad_mode(value: Any) -> str:
    """Normalize an EXPLICITLY stored mode value (§12).

    "provider_controlled" (aliases: provider/auto) | "skippable" |
    "non_skippable" (aliases: nonskippable/blocked). Unknown values
    degrade to "skippable" (the v37 default)."""
    v = str(value or "").strip().lower().replace("-", "_")
    if v in ("non_skippable", "nonskippable", "blocked"):
        return "non_skippable"
    if v in ("provider_controlled", "providercontrolled", "provider",
             "auto"):
        return "provider_controlled"
    return "skippable"


def resolve_videoad_mode(raw: Any, *, provider: str = "none") -> str:
    """Resolve the effective mode from the RAW stored value (§12).

    An explicitly stored value is normalized as-is. An EMPTY store
    resolves to "provider_controlled" when provider=vast (the NEW
    default — the VAST skipoffset then decides skippability) and to
    "skippable" otherwise (the v37 default)."""
    if str(raw or "").strip():
        return normalize_videoad_mode(raw)
    return "provider_controlled" if provider == "vast" else "skippable"


def validate_videoad_vast_url(raw: Any) -> Tuple[Optional[str], str]:
    """The VAST tag URL validator for this layer (https-only, §34).

    Delegates to preroll.validate_preroll_vast_url — the SAME rule the
    admin panel and the v37 settings store already use (never fetches
    the URL, never fabricates provider endpoints or zone ids)."""
    return validate_preroll_vast_url(raw)


# ------------------------------------------------- pure VAST time parsing
_SKIPOFFSET_HMS_RE = re.compile(
    r"^(\d+):(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?$")
_SKIPOFFSET_MS_RE = re.compile(r"^(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?$")
_SKIPOFFSET_SEC_RE = re.compile(r"^(\d+(?:\.\d+)?)$")


def parse_vast_skipoffset(raw: Any) -> Optional[float]:
    """Parse a VAST ``skipoffset``/``Duration`` value (§12) — PURE.

    Accepts the VAST timeformat "HH:MM:SS" / "HH:MM:SS.mmm", the short
    "MM:SS[.mmm]" form, or plain seconds ("10", "12.5"). Returns the
    value in seconds (float) or None when absent/invalid. The client
    VAST adapter in app/web/site/html.py mirrors this helper exactly
    (``parseVastSkipoffset``) so both sides agree on one grammar."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    m = _SKIPOFFSET_HMS_RE.match(s)
    if m:
        hh, mm, ss = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if mm > 59 or ss > 59:
            return None
        frac = float("0." + m.group(4)) if m.group(4) else 0.0
        return float(hh * 3600 + mm * 60 + ss) + frac
    m = _SKIPOFFSET_MS_RE.match(s)
    if m:
        mm, ss = int(m.group(1)), int(m.group(2))
        if mm > 59 or ss > 59:
            return None
        frac = float("0." + m.group(3)) if m.group(3) else 0.0
        return float(mm * 60 + ss) + frac
    if _SKIPOFFSET_SEC_RE.match(s):
        v = float(s)
        return v if v >= 0 else None
    return None


# ------------------------------------------------------- config snapshot
@dataclass
class VideoAdConfig:
    """One resolved configuration snapshot (§10) — everything the
    provider layer needs, nothing it does not. Built by
    ``VideoAdPolicy._read_config`` from the bot_settings store (the
    v37 preroll keys + the two new video-ad keys)."""

    provider: str = VIDEOAD_DEFAULT_PROVIDER
    vast_url: str = ""
    source_url: str = ""
    enabled: bool = False
    mode: str = "skippable"
    skip_delay: int = PREROLL_DEFAULT_SKIP_DELAY
    duration: int = PREROLL_DEFAULT_DURATION
    frequency: str = PREROLL_DEFAULT_FREQUENCY
    session_frequency: int = PREROLL_DEFAULT_SESSION_FREQUENCY
    cooldown: int = PREROLL_DEFAULT_COOLDOWN
    fallback: str = PREROLL_DEFAULT_FALLBACK
    timeout: int = VIDEOAD_DEFAULT_TIMEOUT


@dataclass
class VideoAdDecision:
    """The server-side verdict (§10/§12): serve (or not), which
    provider fills the PRE_ROLL_SLOT, the honest reason, and every
    player-facing parameter. ``serve`` is recorded SERVER-side at
    decision time (VideoAdSession) — never by client claims."""

    serve: bool = False
    provider: str = VIDEOAD_DEFAULT_PROVIDER
    reason: str = ""
    vast_url: str = ""
    source_url: str = ""
    mode: str = "skippable"
    skip_delay: int = PREROLL_DEFAULT_SKIP_DELAY
    duration: int = 0
    fallback: str = PREROLL_DEFAULT_FALLBACK
    frequency: str = PREROLL_DEFAULT_FREQUENCY
    timeout: int = VIDEOAD_DEFAULT_TIMEOUT

    def to_dict(self) -> Dict[str, Any]:
        return {
            "serve": self.serve,
            "provider": self.provider,
            "reason": self.reason,
            "vast_url": self.vast_url,
            "source_url": self.source_url,
            "mode": self.mode,
            "skip_delay": self.skip_delay,
            "duration": self.duration,
            "fallback": self.fallback,
            "frequency": self.frequency,
            "timeout": self.timeout,
        }


# ------------------------------------------------ server-side frequency
# The TTL-map discipline mirrors preroll.py exactly (documented there):
# module-level map keyed (kind, uid, session_key), pruned on every
# record, 6h TTL, hard entry cap. NO HTTP endpoint can reset or
# decrement it (§12 — the policy is authoritative server-side).
_FREQUENCY_STATE: Dict[Tuple[str, int, str], Dict[str, Any]] = {}
_FREQUENCY_STATE_TTL_SECONDS = 6 * 3600.0
_FREQUENCY_STATE_MAX_ENTRIES = 20000


def _day_key(now: Optional[float] = None) -> str:
    import datetime as _dt
    t = _dt.datetime.fromtimestamp(
        now if now is not None else time.time(), _dt.timezone.utc)
    return t.strftime("%Y%m%d")


def _prune_frequency_state(now: float) -> None:
    """Bounded housekeeping (same contract as preroll.py)."""
    stale = [k for k, v in _FREQUENCY_STATE.items()
             if now - float(v.get("ts") or 0) > _FREQUENCY_STATE_TTL_SECONDS]
    for k in stale:
        _FREQUENCY_STATE.pop(k, None)
    if len(_FREQUENCY_STATE) > _FREQUENCY_STATE_MAX_ENTRIES:
        oldest = sorted(_FREQUENCY_STATE.items(),
                        key=lambda kv: float(kv[1].get("ts") or 0))
        for k, _v in oldest[:len(_FREQUENCY_STATE)
                            - _FREQUENCY_STATE_MAX_ENTRIES]:
            _FREQUENCY_STATE.pop(k, None)


def reset_videoad_frequency_state() -> None:
    """Test/diagnostic hook ONLY — clears the video-ad frequency map.

    No production HTTP flow calls this (there is deliberately no
    client-reachable way to touch the accounting, §12)."""
    _FREQUENCY_STATE.clear()


def videoad_frequency_state_snapshot() -> Dict[Tuple[str, int, str],
                                                Dict[str, Any]]:
    """Read-only snapshot (tests/diagnostics only)."""
    return {k: dict(v) for k, v in _FREQUENCY_STATE.items()}


class VideoAdSession:
    """SERVER-side frequency accounting for one playback decision.

    Keyed by the AUTHENTICATED user id (+ the signed site-session key
    when present — never a client-selected bucket). ``allows`` checks
    the caps, ``record`` writes the serve at DECISION time; the only
    writer is the provider layer inside VideoAdPolicy.resolve."""

    def __init__(self, user_id: Optional[int],
                 session_key: Optional[str] = None) -> None:
        self.user_id: Optional[int] = (
            None if user_id is None else int(user_id))
        self.session_key: str = str(session_key or "")[:64]

    def allows(self, *, frequency: str, session_frequency: int,
               cooldown: int) -> Tuple[bool, str]:
        """(ok, reason) — reason "" when allowed, else the honest
        §12 cap reason ("session_capped" | "cooldown")."""
        if self.user_id is None:
            return True, ""   # anonymous: never tracked (as preroll.py)
        now = time.time()
        if frequency == "session":
            rec = _FREQUENCY_STATE.get(
                ("sess", self.user_id, self.session_key))
            if rec is not None and rec.get("day") == _day_key(now):
                if int(rec.get("count") or 0) >= int(session_frequency):
                    return False, "session_capped"
        elif frequency == "cooldown":
            rec = _FREQUENCY_STATE.get(("cd", self.user_id, ""))
            if rec is not None:
                if now - float(rec.get("last") or 0) < float(cooldown):
                    return False, "cooldown"
        return True, ""

    def record(self, *, frequency: str) -> None:
        """Record one serve at DECISION time (§12)."""
        if self.user_id is None:
            return
        now = time.time()
        if frequency == "session":
            key = ("sess", self.user_id, self.session_key)
            rec = _FREQUENCY_STATE.get(key)
            if rec is None or rec.get("day") != _day_key(now):
                rec = {"count": 0, "day": _day_key(now), "ts": now}
            rec["count"] = int(rec.get("count") or 0) + 1
            rec["ts"] = now
            _FREQUENCY_STATE[key] = rec
        elif frequency == "cooldown":
            _FREQUENCY_STATE[("cd", self.user_id, "")] = {
                "last": now, "ts": now}
        _prune_frequency_state(now)


# ----------------------------------------------------------- the adapter
class VideoAdPlayerAdapter:
    """The pure descriptor of what the PLAYER must do (§11/§16).

    ``slot`` is ALWAYS "PRE_ROLL": the single stable ad position inside
    the player (Player → Ad slot → Main video). ``to_payload`` is the
    serializable subset that crosses the wire — the SAME shape for
    every provider (only the provider NAME and its urls differ), which
    is what makes a future provider swap a config/adapter change only."""

    SLOT_PRE_ROLL = "PRE_ROLL"

    def __init__(self, provider: str = VIDEOAD_DEFAULT_PROVIDER,
                 vast_url: str = "", source_url: str = "",
                 mode: str = "skippable",
                 skip_delay: int = PREROLL_DEFAULT_SKIP_DELAY,
                 duration: int = 0,
                 fallback: str = PREROLL_DEFAULT_FALLBACK,
                 frequency: str = PREROLL_DEFAULT_FREQUENCY,
                 timeout: int = VIDEOAD_DEFAULT_TIMEOUT) -> None:
        self.slot = self.SLOT_PRE_ROLL
        self.provider = str(provider or VIDEOAD_DEFAULT_PROVIDER)
        self.vast_url = str(vast_url or "")
        self.source_url = str(source_url or "")
        self.mode = str(mode or "skippable")
        self.skip_delay = int(skip_delay)
        self.duration = int(duration or 0)
        self.fallback = str(fallback or PREROLL_DEFAULT_FALLBACK)
        self.frequency = str(frequency or PREROLL_DEFAULT_FREQUENCY)
        self.timeout = int(timeout or VIDEOAD_DEFAULT_TIMEOUT)

    @classmethod
    def from_decision(cls, decision: VideoAdDecision) \
            -> "VideoAdPlayerAdapter":
        return cls(provider=decision.provider, vast_url=decision.vast_url,
                   source_url=decision.source_url, mode=decision.mode,
                   skip_delay=decision.skip_delay,
                   duration=decision.duration, fallback=decision.fallback,
                   frequency=decision.frequency, timeout=decision.timeout)

    def to_payload(self) -> Dict[str, Any]:
        """slot=PRE_ROLL + the wire subset — ONE shape, every provider."""
        return {"slot": self.slot,
                **player_wire_subset({
                    "provider": self.provider, "mode": self.mode,
                    "duration": self.duration,
                    "source_url": self.source_url,
                    "vast_url": self.vast_url, "fallback": self.fallback,
                    "frequency": self.frequency,
                    "skip_delay": self.skip_delay,
                    "timeout": self.timeout,
                })}


def player_wire_subset(decision: Any) -> Dict[str, Any]:
    """The player-facing wire subset (§16 — stable across providers).

    From a VideoAdDecision (or its dict): exactly the VIDEOAD_WIRE_KEYS
    that are meaningful — duration/source_url/vast_url only when
    non-empty.

    V26 Phase 5: ``mode`` and ``skip_delay`` NO LONGER reach the player
    at all (the player has no skip control — the pre-roll always plays
    to completion; the stored mode/skip_delay settings remain the
    server-side POLICY record only, exactly like preroll.py's contract
    "no skip parameters ever reach the client")."""
    d = decision.to_dict() if isinstance(decision, VideoAdDecision) \
        else dict(decision or {})
    out: Dict[str, Any] = {}
    for key in VIDEOAD_WIRE_KEYS:
        val = d.get(key)
        if key in ("duration", "source_url", "vast_url") and not val:
            continue
        if key in ("mode",):
            continue  # V26 Phase 5: the policy record stays server-side
        out[key] = val
    return out


# ---------------------------------------------------------- the providers
class VideoAdProvider(ABC):
    """The abstract provider contract (§10/§16).

    A provider knows: how to VALIDATE its configuration and how to
    BUILD a decision. It knows NOTHING about the player, the DOM or the
    slot — swapping providers never touches the player (§16)."""

    name: str = ""

    @abstractmethod
    async def validate_config(self, config: VideoAdConfig
                              ) -> Tuple[bool, str]:
        """(ok, reason) — configuration sanity for THIS provider."""

    @abstractmethod
    async def build_decision(self, config: VideoAdConfig,
                             session: VideoAdSession) -> VideoAdDecision:
        """Build the serve/no-serve decision, consulting + recording the
        SERVER-side frequency session at DECISION time (§12)."""


class VastAdProvider(VideoAdProvider):
    """name="vast" — any VAST/VMAP tag endpoint (HilltopAds today,
    any other VAST provider tomorrow — §10/§34: nothing
    provider-specific is hard-coded).

    Activates when a VAST URL is configured AND passes the https-only
    validation. The server NEVER parses VAST XML or fabricates
    inventory: it hands the https tag URL to the player (the client
    adapter fetches/parses it and applies the §14 failure policy);
    the SERVER owns the decision + the frequency accounting."""

    name = "vast"

    async def validate_config(self, config: VideoAdConfig
                              ) -> Tuple[bool, str]:
        if str(config.provider or "") != "vast":
            return False, "provider_mismatch"
        if not str(config.vast_url or "").strip():
            return False, "not_configured"
        ok_url, _err = validate_videoad_vast_url(config.vast_url)
        if ok_url is None:
            return False, "invalid_vast_url"
        return True, "ok"

    async def build_decision(self, config: VideoAdConfig,
                             session: VideoAdSession) -> VideoAdDecision:
        decision = VideoAdDecision(
            serve=False, provider=self.name,
            vast_url=str(config.vast_url or ""),
            source_url="", mode=config.mode,
            skip_delay=config.skip_delay, duration=0,
            fallback=config.fallback, frequency=config.frequency,
            timeout=config.timeout)
        if not config.enabled:
            decision.reason = "disabled"
            return decision
        if not str(config.vast_url or "").strip():
            decision.reason = "not_configured"
            decision.vast_url = ""
            return decision
        # Render-time honesty (mirrors preroll.py): a stored URL that no
        # longer passes validation serves NOTHING (§34).
        ok_url, _err = validate_videoad_vast_url(config.vast_url)
        if ok_url is None:
            decision.reason = "not_configured"
            decision.vast_url = ""
            return decision
        allowed, reason = session.allows(
            frequency=config.frequency,
            session_frequency=config.session_frequency,
            cooldown=config.cooldown)
        if not allowed:
            decision.reason = reason       # session_capped | cooldown
            return decision
        session.record(frequency=config.frequency)   # DECISION-time serve
        decision.serve = True
        decision.reason = "ok"
        return decision


class DirectMediaProvider(VideoAdProvider):
    """name="direct" — the v37 behavior (§10): a direct https .mp4/.webm
    source URL played in the SAME PRE_ROLL_SLOT.

    PRODUCTION WIRING: VideoAdPolicy.resolve DELEGATES provider
    "direct"/"none" to the v37 PreRollPolicy (the exact v37 behavior,
    frequency map and reason vocabulary — see decision_from_legacy).
    This native implementation mirrors the same rules through the
    provider abstraction so the layer is complete and any future wiring
    (or the §16 provider-replacement proof) exercises ONE contract."""

    name = "direct"

    async def validate_config(self, config: VideoAdConfig
                              ) -> Tuple[bool, str]:
        if not str(config.source_url or "").strip():
            return False, "not_configured"
        ok_url, _err = validate_preroll_source_url(config.source_url)
        if ok_url is None:
            return False, "invalid_source"
        return True, "ok"

    async def build_decision(self, config: VideoAdConfig,
                             session: VideoAdSession) -> VideoAdDecision:
        decision = VideoAdDecision(
            serve=False, provider=self.name,
            vast_url=str(config.vast_url or ""),
            source_url=str(config.source_url or ""), mode=config.mode,
            skip_delay=config.skip_delay, duration=config.duration,
            fallback=config.fallback, frequency=config.frequency,
            timeout=config.timeout)
        if not config.enabled:
            decision.reason = "disabled"
            return decision
        if not str(config.source_url or "").strip():
            decision.reason = "not_configured"
            return decision
        ok_url, _err = validate_preroll_source_url(config.source_url)
        if ok_url is None:
            decision.reason = "invalid_source"
            decision.source_url = ""
            return decision
        allowed, reason = session.allows(
            frequency=config.frequency,
            session_frequency=config.session_frequency,
            cooldown=config.cooldown)
        if not allowed:
            # v37 vocabulary for the direct family (documented mapping).
            decision.reason = ("frequency_capped" if reason == "session_capped"
                               else "cooldown_active")
            return decision
        session.record(frequency=config.frequency)
        decision.serve = True
        decision.reason = "ok"
        return decision

    @classmethod
    def decision_from_legacy(cls, config: VideoAdConfig,
                             legacy: Dict[str, Any]) -> VideoAdDecision:
        """Map a v37 PreRollPolicy payload into a VideoAdDecision.

        Used by VideoAdPolicy.resolve for provider "direct"/"none": the
        v37 policy stays the ONE decision point for direct media (its
        enabled flag, URL validation, frequency map and reasons are
        authoritative); this only reshapes the verdict into the
        provider-agnostic decision + attaches the new timeout."""
        serve = bool(legacy.get("active"))
        return VideoAdDecision(
            serve=serve,
            provider=cls.name,
            reason=str(legacy.get("reason") or ""),
            vast_url=str(legacy.get("vast_url") or ""),
            source_url=str(legacy.get("source_url") or ""),
            mode=str(legacy.get("mode") or "skippable"),
            skip_delay=int(legacy.get("skip_delay")
                           or config.skip_delay),
            duration=int(legacy.get("duration") or 0),
            fallback=str(legacy.get("fallback")
                         or config.fallback),
            frequency=str(legacy.get("frequency")
                          or config.frequency),
            timeout=config.timeout)


# ------------------------------------------------------------ the policy
class VideoAdPolicy:
    """The ONE video-ad decision point (mirrors get_preroll_policy()).

    ``resolve`` reads the live settings, picks the provider by
    ``website_videoad_provider`` and returns the decision dict
    (serve/provider/reason + every player-facing parameter). It NEVER
    raises: an ads configuration problem degrades to an inactive,
    truthful verdict — an ad decision can never block content issuance
    (§14/§26, mirrors app/ads/service.py).

    serve=False reason vocabulary: "disabled" (enabled flag off),
    "not_configured" (no vast_url AND no source_url — §34), the §12
    caps ("session_capped" | "cooldown" on the vast path; the v37
    "frequency_capped"/"cooldown_active" pass through on the delegated
    direct path), plus "resolve_error" on unexpected failure.
    """

    def __init__(self) -> None:
        self._vast = VastAdProvider()
        self._direct = DirectMediaProvider()

    async def _setting(self, db: Any, key: str, default: str) -> str:
        try:
            val = await db.get_setting(key)
            if val is None:
                return default
            return str(val)
        except Exception:  # noqa: BLE001 — config failure never blocks
            return default

    async def _read_config(self, db: Any) -> VideoAdConfig:
        provider = normalize_videoad_provider(
            await self._setting(db, PREROLL_PROVIDER_KEY,
                                VIDEOAD_DEFAULT_PROVIDER))
        raw_mode = await self._setting(db, PREROLL_MODE_KEY, "")
        return VideoAdConfig(
            provider=provider,
            vast_url=(await self._setting(db, PREROLL_VAST_URL_KEY,
                                          "")).strip(),
            source_url=(await self._setting(db, PREROLL_SOURCE_URL_KEY,
                                            "")).strip(),
            enabled=is_enabled_value(
                await self._setting(db, PREROLL_ENABLED_KEY, "0")),
            mode=resolve_videoad_mode(raw_mode, provider=provider),
            skip_delay=clamp_skip_delay(
                await self._setting(db, PREROLL_SKIP_DELAY_KEY,
                                    str(PREROLL_DEFAULT_SKIP_DELAY))),
            duration=clamp_duration(
                await self._setting(db, PREROLL_DURATION_KEY,
                                    str(PREROLL_DEFAULT_DURATION))),
            frequency=normalize_frequency(
                await self._setting(db, PREROLL_FREQUENCY_KEY,
                                    PREROLL_DEFAULT_FREQUENCY)),
            session_frequency=clamp_session_frequency(
                await self._setting(db, PREROLL_SESSION_FREQUENCY_KEY,
                                    str(PREROLL_DEFAULT_SESSION_FREQUENCY))),
            cooldown=clamp_cooldown(
                await self._setting(db, PREROLL_COOLDOWN_KEY,
                                    str(PREROLL_DEFAULT_COOLDOWN))),
            fallback=normalize_fallback(
                await self._setting(db, PREROLL_FALLBACK_KEY,
                                    PREROLL_DEFAULT_FALLBACK)),
            timeout=clamp_videoad_timeout(
                await self._setting(db, PREROLL_TIMEOUT_KEY,
                                    str(VIDEOAD_DEFAULT_TIMEOUT))),
        )

    async def resolve(self, db: Any, user_id: Optional[int],
                      session_key: Optional[str] = None
                      ) -> Dict[str, Any]:
        """Resolve the video-ad decision for one playback issuance.

        Returns the decision dict (VideoAdDecision.to_dict()). The
        caller (stream.py) logs WEBSITE_VIDEOAD_DECISION at decision
        time and attaches ONLY the player_wire_subset to the response
        when serve=True (the "preroll" wire key — stable contract)."""
        try:
            config = await self._read_config(db)
            session = VideoAdSession(user_id, session_key)
            if config.provider == "vast":
                decision = await self._vast.build_decision(config, session)
            else:
                # §26/§16: provider "direct"/"none" DELEGATE to the v37
                # pre-roll policy — the exact v37 behavior (its own
                # enabled flag + frequency map stay authoritative), so
                # existing v37 direct-media deployments keep working.
                legacy = await get_preroll_policy().resolve(
                    db, user_id, session_key)
                decision = DirectMediaProvider.decision_from_legacy(
                    config, legacy)
            return decision.to_dict()
        except Exception as exc:  # noqa: BLE001 — never block content
            logger.warning("VIDEOAD_RESOLVE_ERROR err=%s",
                           type(exc).__name__)
            return VideoAdDecision(
                serve=False, provider=VIDEOAD_DEFAULT_PROVIDER,
                reason="resolve_error").to_dict()


_VIDEOAD_POLICY = VideoAdPolicy()


def get_videoad_policy() -> VideoAdPolicy:
    """The shared policy instance (one decision point, no second one)."""
    return _VIDEOAD_POLICY


# Server-side hook for client display-only ad events (§14): the player
# POSTs its VIDEO_AD_* lifecycle records to /site/api/ads/event; that
# endpoint (pages.py) recognizes the compact lifecycle slugs below and
# records them through this ONE logging seam — display-only. It can
# NEVER touch policy state (§12) and never logs tokens/URLs.
VIDEOAD_CLIENT_EVENT_NAMES = {
    "va_response": "VIDEO_AD_RESPONSE",
    "va_start": "VIDEO_AD_START",
    # V26 Phase 5: "va_skip" / VIDEO_AD_SKIP is REMOVED — there is no
    # Skip control or skip action anywhere in the player (the pre-roll
    # always plays to completion), so the closed slug set no longer
    # recognizes a skip lifecycle record from any client.
    "va_complete": "VIDEO_AD_COMPLETE",
    "va_no_fill": "VIDEO_AD_NO_FILL",
    "va_error": "VIDEO_AD_ERROR",
}


def client_event_full_name(slug: str) -> str:
    """Map a player lifecycle slug ("va_response") to the FULL §14 event
    name ("VIDEO_AD_RESPONSE"); "" when the slug is NOT one of the six
    video-ad lifecycle records (the caller then falls through to the
    normal Ads-Platform creative path, unchanged).

    The player POSTs the compact form because the ads-event endpoint's
    ``event`` field is bounded (16 chars — "VIDEO_AD_RESPONSE" is 17);
    the map is CLOSED so only genuine lifecycle records take this path
    (a fabricated slug is never interpreted as a video-ad event)."""
    return VIDEOAD_CLIENT_EVENT_NAMES.get(
        str(slug or "").strip().lower(), "")


def log_video_ad_client_event(event: str, provider: str = "",
                              reason: str = "",
                              user_id: Optional[int] = None) -> None:
    """Log a client-reported VIDEO_AD_* lifecycle record server-side.

    Display/diagnostics ONLY: the authoritative decision and frequency
    accounting happened at issuance; these records are never trusted
    for policy state (§12) and carry no URLs or tokens."""
    logger.info("VIDEO_AD_CLIENT_EVENT event=%s provider=%s reason=%s "
                "user_id=%s", str(event or "")[:32],
                str(provider or "")[:16], str(reason or "")[:48],
                user_id)
