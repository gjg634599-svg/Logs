"""WEBSITE PHASE 3 — opaque short-lived SIGNED video references.

The Website NEVER puts database file pks, Telegram message ids or
``file_id`` values into public URLs (spec §7/§20). Instead the Payload
detail page mints a short-lived AEAD-encrypted reference per file:

    encode(listing_opaque_id, file_pk)  ->  opaque urlsafe token
    decode(token)                       ->  {listing, file_pk} | None

The token REUSES the existing CredentialVault (app/network/credentials.py)
— the same authenticated-encryption construction (Fernet primary, stdlib
HMAC-CTR AEAD fallback) and the same key derivation
(NETWORK_TOKEN_ENCRYPTION_KEY, else per-deployment derivation from the main
BOT_TOKEN). No new cryptography exists in this module. Tokens carry an
expiry; decode fails closed on tampering, wrong key, malformed input or
expiry. The plaintext inside the token never leaves this module's parsing
(exposed payload contains ONLY the decoded fields).

This is the MINIMUM authorization boundary required by Phase 3: selecting
a file inside a Payload. The actual player transport / stream tokens are
Phase 4 (Media Gateway) — deliberately NOT implemented here.
"""
from __future__ import annotations

import time
from types import SimpleNamespace
from typing import Any, Dict, Optional

from app.network.credentials import CredentialVault

# Default reference lifetime (seconds). The detail page mints fresh
# references on every render, so a browsing user always gets a full window.
WEBSITE_VIDEO_REF_TTL_DEFAULT = 1800  # 30 minutes


def make_video_token_codec(bot_token: Optional[str] = None,
                           *, ttl_seconds: int = WEBSITE_VIDEO_REF_TTL_DEFAULT
                           ):
    """Build the encode/decode pair bound to the deployment's vault key."""
    ttl_seconds = max(60, int(ttl_seconds or WEBSITE_VIDEO_REF_TTL_DEFAULT))
    vault = CredentialVault(bot_token_fallback=bot_token,
                                allow_ephemeral_fallback=True)

    def encode_video_ref(listing_opaque_id: str, file_pk: int) -> str:
        """Mint an opaque, signed, short-lived video reference."""
        expires_at = int(time.time()) + ttl_seconds
        plaintext = f"v1|{str(listing_opaque_id)}|{int(file_pk)}|{expires_at}"
        return vault.encrypt(plaintext)

    def decode_video_ref(token: str) -> Optional[Dict[str, Any]]:
        """Validate + decode a video reference. Fails CLOSED (None) on
        tampering, wrong key, malformed input or expiry — never raises."""
        try:
            raw = vault.decrypt(str(token or ""))
        except Exception:  # noqa: BLE001 — any failure fails closed
            return None
        parts = raw.split("|")
        if len(parts) != 4 or parts[0] != "v1":
            return None
        try:
            file_pk = int(parts[2])
            expires_at = int(parts[3])
        except ValueError:
            return None
        if file_pk <= 0 or expires_at < time.time():
            return None
        return {"listing": parts[1], "file_pk": file_pk,
                "expires_at": expires_at}

    return SimpleNamespace(
        encode_video_ref=encode_video_ref,
        decode_video_ref=decode_video_ref,
        ttl_seconds=ttl_seconds,
    )
