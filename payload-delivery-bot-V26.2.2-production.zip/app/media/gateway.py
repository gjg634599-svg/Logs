"""WEBSITE PHASE 4 — THE MEDIA GATEWAY.

Owns the streaming behavior of the Website (spec §6). The layering is
strict:

    Website pages (app/web/site) → Mini App auth → Access Engine →
    short-lived stream token → MEDIA GATEWAY (this module) →
    MediaResolver / sources (Phase 1 stack) → Local Bot API / Cloud /
    future source → bounded shared cache → HTTP response

This module NEVER talks to Telegram itself, NEVER contains file_id
recovery logic (the Phase 1 stack owns resolution + the single-retry
repair), NEVER re-implements the Access Engine (injected
``access_check``), and never mints policy — it ENFORCES the chain above
per request:

  1. authenticate the stream request (AEAD stream token, fail-closed)
  2. validate stream authorization (re-run the EXISTING Access Engine for
     the token's user + payload on EVERY request — a revoked user cannot
     ride an unexpired token; spec §2 "no bypass by calling the stream
     URL directly")
  3. resolve the CANONICAL media (listing membership → indexed row →
     MediaHandle through the Phase 1 resolver)
  4. plan the HTTP response: HEAD / GET / Range / 206 / 416 with correct
     Content-Range, Content-Length, Accept-Ranges, Content-Type (indexed
     MIME — never a blind video/mp4)
  5. stream BOUNDED chunks through the shared cache (coalesced fill,
     active-reader protection) or the appropriate direct strategy
     (local native seeks / cloud stream-skip passthrough)

PURE asyncio module: no aiohttp, no telegram, no bot.py imports. The web
handlers in app/web/site/stream.py convert the returned :class:`StreamPlan`
into HTTP responses.

Transport strategies (honest, bounded — spec §7–§11):
  * full GET, cache enabled  → coalesced cache fill (ONE upstream
    download per media identity; concurrent readers follow the fill)
  * full GET, cache off/broken → direct passthrough via the Phase 1
    stack (open_with_repair single-retry policy)
  * Range, fully cached / fill in progress → served from the cache disk
    (native seeks) or follows the active fill
  * Range, cache miss + LOCAL Bot API → ``open_range_with_retry`` native
    seeks under the stack's single-retry repair policy (the local
    transport is THE ranged transport)
  * Range, cache miss + CLOUD → stream-skip passthrough: transfer the
    prefix, DISCARD it unbuffered, serve the window, STOP at its end —
    never a full-file download for a small range, never whole-file RAM
  * media beyond the cloud capability → honest controlled 503 with the
    Local Bot API guidance (never a fake multi-GB claim)

Observability (spec §29): STREAM_AUTH_OK / STREAM_AUTH_FAIL /
STREAM_START / STREAM_END / STREAM_ERROR / RANGE_ERROR + the cache's
MEDIA_CACHE_* vocabulary. Logged fields are identities and counts —
never stream tokens, never bot tokens, never file_ids.
"""
from __future__ import annotations

import logging
import time
from types import SimpleNamespace
from typing import Any, AsyncIterator, Dict, Optional, Tuple

from app.media.cachekeys import cache_key  # noqa: F401 — re-export
from app.media.errors import (
    MediaTooLargeError,
    MediaTransportError,
    RangeNotSatisfiableError,  # noqa: F401 — re-export for handlers
    UnresolvableMediaError,
)
from app.media.interfaces import MediaHandle
from app.media.ranges import (
    UNSATISFIABLE,
    content_range_header,
    parse_range_header,
    unsatisfiable_content_range,
)
from app.media.resolver import handle_from_mapping
from app.media.streamcache import StreamCache, _direct_skip
from app.media.streamtokens import (
    PURPOSE_STREAM,
    PURPOSE_THUMB,
    STREAM_TOKEN_TTL_DEFAULT,
    clamp_stream_ttl,
    make_stream_token_codec,
)

logger = logging.getLogger("payload-bot")

# v32 bot_settings keys (seeds are additive; defaults keep behavior sane
# even on a database that somehow lacks the seeds).
SETTING_STREAM_ENABLED = "website_stream_enabled"
SETTING_CACHE_ENABLED = "website_cache_enabled"
SETTING_CACHE_MAX_BYTES = "website_cache_max_bytes"
SETTING_CACHE_TTL_SECONDS = "website_cache_ttl_seconds"
SETTING_STREAM_TOKEN_TTL = "website_stream_token_ttl"
SETTING_MAX_CONCURRENT_STREAMS = "website_max_concurrent_streams"

DEFAULT_MAX_CONCURRENT_STREAMS = 32
DEFAULT_THUMB_MAX_BYTES = 2 * 1024 * 1024  # bounded thumbnail responses
THUMB_BROWSER_CACHE_SECONDS = 300

# Content type when the indexed MIME is absent: the HONEST generic type
# (never a blind video/mp4 — spec §22).
FALLBACK_CONTENT_TYPE = "application/octet-stream"


def _media_content_type(mime_type: Optional[str],
                         media_type: Optional[str] = None,
                         file_name: Optional[str] = None) -> str:
    """GAP-CLOSURE spec §17: the §17 priority order (media_type →
    Telegram metadata → MIME → extension) via the shared helper
    :func:`app.media.mime.effective_content_type`.

    A KNOWN video (``media_type=video``) with a generic
    ``application/octet-stream`` MIME is served as ``video/mp4`` — never
    the generic binary type that made browsers treat it as a download
    instead of a stream."""
    from app.media.mime import effective_content_type
    return effective_content_type(media_type, mime_type, file_name)


class StreamPlan:
    """An HTTP-ready plan produced by the gateway (transport-agnostic).

    PHASE 5: ``release`` (optional) releases the gateway's concurrency
    slot EXACTLY ONCE — whichever runs first: the body generator's own
    ``finally`` (normal iteration / mid-stream abort) or the HTTP layer's
    ``finally`` (client vanished before the body was ever iterated —
    e.g. ``prepare()`` raising). Without the second path, a body that is
    never started leaks its slot forever (~32 request-then-instantly-
    disconnect cycles would lock /site/media behind 429 until restart).

    v35: ``is_json_error`` marks the controlled single-shot error plans
    (so the HTTP layer's first-chunk preflight skips them — their body
    is always instantly available and touches no upstream).
    """

    __slots__ = ("status", "headers", "body", "detail", "strategy",
                 "release", "is_json_error")

    def __init__(self, status: int, headers: Dict[str, str],
                 body: Optional[AsyncIterator[bytes]] = None,
                 detail: str = "", strategy: str = "",
                 release=None, is_json_error: bool = False) -> None:
        self.status = int(status)
        self.headers = dict(headers or {})
        self.body = body
        self.detail = detail
        self.strategy = strategy
        self.release = release
        self.is_json_error = bool(is_json_error)

    @property
    def ok(self) -> bool:
        return self.status < 400


def _json_error(status: int, code: str, message: str) -> StreamPlan:
    """Honest controlled error (never a stack trace, never a secret)."""
    import json as _json
    payload = _json.dumps({"ok": False, "error": code, "message": message})

    async def _err_body():
        yield payload.encode("utf-8")
    return StreamPlan(
        status, {"Content-Type": "application/json; charset=utf-8",
                 "Cache-Control": "no-store"}, _err_body(),
        detail=f"{code}: {message}", strategy="error", is_json_error=True)


def _rowget(row: Any, key: str):
    try:
        if row is not None and hasattr(row, "keys"):
            if key in row.keys():
                return row[key]
            return None
        if isinstance(row, dict):
            return row.get(key)
    except Exception:  # noqa: BLE001
        pass
    return None


def _rowget_int(row: Any, key: str) -> Optional[int]:
    val = _rowget(row, key)
    if val is None:
        return None
    try:
        return int(val)
    except (TypeError, ValueError):
        return None


def make_media_gateway(db: Any, *, stack: Any,
                       listing_resolver=None, access_check=None,
                       bot_token: Optional[str] = None,
                       cache: Optional[StreamCache] = None) -> SimpleNamespace:
    """Compose the Media Gateway.

    ``stack``            — the Phase 1 media stack (resolver/sources/repair;
                           Phase 4 additions: ``bot_token``/``http`` fields +
                           ``open_range_with_retry``)
    ``listing_resolver`` — async (listing_opaque, file_pk) -> Optional[
        {file_unique_id, file_size, mime_type, media_type, payload_id,
         listing_thumb_file_unique_id, listing_thumb_file_id,
         parent_row}] resolving THROUGH the canonical Website Payload
        system (published + membership checks live there).
    ``access_check``     — async (user_id, payload_id) -> AccessResult-like
        (the EXISTING engine, injected — never a second engine).
    ``cache``            — shared StreamCache (or None: cache disabled).
    """
    codec = make_stream_token_codec(bot_token)
    _concurrent = {"n": 0}

    # ---------------------------------------------------------- settings
    async def read_settings() -> Dict[str, Any]:
        """Live v32 settings (admin toggles take effect immediately)."""
        out: Dict[str, Any] = {}
        try:
            out["stream_enabled"] = await db.get_setting_bool(
                SETTING_STREAM_ENABLED, True)
        except Exception:  # noqa: BLE001 — fail closed for streams
            out["stream_enabled"] = False
        try:
            out["cache_enabled"] = await db.get_setting_bool(
                SETTING_CACHE_ENABLED, True) and cache is not None
        except Exception:  # noqa: BLE001
            out["cache_enabled"] = False
        try:
            out["token_ttl"] = clamp_stream_ttl(await db.get_setting_int(
                SETTING_STREAM_TOKEN_TTL, STREAM_TOKEN_TTL_DEFAULT))
        except Exception:  # noqa: BLE001
            out["token_ttl"] = STREAM_TOKEN_TTL_DEFAULT
        try:
            out["max_concurrent"] = max(1, await db.get_setting_int(
                SETTING_MAX_CONCURRENT_STREAMS,
                DEFAULT_MAX_CONCURRENT_STREAMS))
        except Exception:  # noqa: BLE001
            out["max_concurrent"] = DEFAULT_MAX_CONCURRENT_STREAMS
        if cache is not None:
            try:
                cache.max_bytes = max(1024 * 1024, await db.get_setting_int(
                    SETTING_CACHE_MAX_BYTES, cache.max_bytes))
            except Exception:  # noqa: BLE001
                pass
            try:
                cache.ttl_seconds = max(1, await db.get_setting_int(
                    SETTING_CACHE_TTL_SECONDS, cache.ttl_seconds))
            except Exception:  # noqa: BLE001
                pass
        return out

    # ------------------------------------------------------ token surface
    def issue_stream_token(user_id: int, listing_opaque_id: str, file_pk: int,
                           *, purpose: str = PURPOSE_STREAM,
                           ttl_seconds: Optional[int] = None,
                           ttl_max_seconds: Optional[int] = None) -> str:
        """Mint a stream token bound to user+listing+file+purpose+expiry."""
        return codec.encode_stream_token(
            user_id, listing_opaque_id, file_pk, purpose=purpose,
            ttl_override=ttl_seconds, ttl_max_seconds=ttl_max_seconds)

    # ------------------------------------------------------ handle helpers
    async def _resolve_handle(target: Dict[str, Any]
                              ) -> Optional[MediaHandle]:
        """Canonical indexed row → MediaHandle (Phase 1 resolver)."""
        row = target.get("parent_row")
        if row is None:
            uid = target.get("file_unique_id")
            if not uid:
                return None
            try:
                row = await db.get_indexed_file_by_unique_id(str(uid))
            except Exception:  # noqa: BLE001
                return None
        if row is None:
            return None
        try:
            return handle_from_mapping(row)
        except UnresolvableMediaError:
            return None

    async def _size_of(handle: MediaHandle,
                       hint: Optional[int]) -> Optional[int]:
        """Known size first; else ONE getFile metadata call (never a
        download) through the stack's repair policy."""
        if hint is not None:
            try:
                hint_int = int(hint)
            except (TypeError, ValueError):
                hint_int = -1
            if hint_int >= 0:
                return hint_int
        try:
            return await stack.size(handle)
        except MediaTransportError:
            return None
        except Exception:  # noqa: BLE001 — honest unknown size
            return None

    def _make_slot_release():
        """PHASE 5: idempotent concurrency-slot release. The slot is
        acquired at PLAN time; the matching release must be guaranteed
        even when the returned body generator is never iterated (client
        gone before first chunk). Both the generator's ``finally`` and the
        HTTP layer's ``finally`` call this — exactly-once by flag."""
        state = {"released": False}

        def _release() -> None:
            if not state["released"]:
                state["released"] = True
                _concurrent["n"] = max(0, _concurrent["n"] - 1)
        return _release

    def _counted(body: AsyncIterator[bytes], uid: str,
                 release=None
                 ) -> AsyncIterator[bytes]:
        """Wrap a body iterator with the concurrency-slot guard — the slot
        is released exactly once when the response finishes, the client
        disconnects, or the iterator errors (never leaks)."""
        async def _gen():
            try:
                async for chunk in body:
                    yield chunk
            finally:
                if release is not None:
                    release()
                else:  # pragma: no cover — legacy internal callers
                    _concurrent["n"] = max(0, _concurrent["n"] - 1)
        return _gen()

    # ------------------------------------------------------ core planning
    async def handle_stream_request(token: str, *, method: str = "GET",
                                    range_header: Optional[str] = None
                                    ) -> StreamPlan:
        """Full gateway chain for one /site/media request (spec §6)."""
        # 1. authenticate the stream request (fail-closed AEAD decode).
        decoded = codec.decode_stream_token(str(token or ""))
        if decoded is None:
            logger.info("STREAM_AUTH_FAIL reason=invalid_or_expired_token")
            return _json_error(401, "invalid_stream_token",
                               "This stream link is invalid or has expired.")
        if decoded.get("purpose") != PURPOSE_STREAM:
            logger.info("STREAM_AUTH_FAIL reason=wrong_purpose")
            return _json_error(401, "wrong_purpose",
                               "This stream link is not valid for media.")
        # 2. resolve the canonical Website Payload + file membership.
        if listing_resolver is None:
            return _json_error(503, "unavailable", "Streaming unavailable.")
        try:
            target = await listing_resolver(str(decoded.get("listing")),
                                             int(decoded.get("file_pk") or 0))
        except Exception:  # noqa: BLE001 — honest failure, never a crash
            logger.debug("stream listing resolution failed", exc_info=True)
            return _json_error(503, "unavailable", "Streaming unavailable.")
        if target is None:
            logger.info("STREAM_AUTH_FAIL reason=file_not_in_payload")
            return _json_error(404, "not_found",
                               "This file no longer belongs to a published "
                               "payload.")
        # 3. re-verify the EXISTING access state for THIS user on EVERY
        #    request (spec §2 — direct URL calls cannot bypass it).
        if access_check is not None:
            res = None
            authorized = False
            try:
                res = await access_check(int(decoded.get("user_id") or 0),
                                         target.get("payload_id"))
                authorized = bool(getattr(res, "authorized", False))
            except Exception:  # noqa: BLE001 — engine failure fails closed
                logger.debug("stream access check failed", exc_info=True)
                authorized = False
            if not authorized:
                logger.info("STREAM_AUTH_FAIL user_id=%s reason=%s",
                            decoded.get("user_id"),
                            getattr(res, "reason", "engine_error"))
                return _json_error(403, "access_denied",
                                   "Complete the access requirement in the "
                                   "bot, then reload.")
        # 4. live settings gate + concurrency bound.
        settings = await read_settings()
        if not settings.get("stream_enabled"):
            return _json_error(503, "streaming_disabled",
                               "Website streaming is currently switched "
                               "off.")
        if _concurrent["n"] >= int(settings.get("max_concurrent") or
                                   DEFAULT_MAX_CONCURRENT_STREAMS):
            return _json_error(429, "too_many_streams",
                               "Too many concurrent streams — try again "
                               "shortly.")
        # 5. resolve the canonical media handle (Phase 1 resolver).
        handle = await _resolve_handle(target)
        if handle is None:
            logger.info("STREAM_AUTH_FAIL reason=unresolvable_media")
            return _json_error(404, "not_streamable",
                               "This media record cannot be streamed "
                               "(missing identity — re-index the source).")
        uid = str(handle.file_unique_id)
        size = await _size_of(handle, target.get("file_size"))
        ctype = _media_content_type(target.get("mime_type"),
                                    target.get("media_type"),
                                    target.get("file_name"))
        logger.info("STREAM_AUTH_OK user_id=%s file_unique_id=%s size=%s",
                    decoded.get("user_id"), uid, size)
        # GAP-CLOSURE (spec §10/§11): THE authoritative transport decision —
        # one MediaTransportSelector, never a scattered cloud/local check.
        # Local mode has no cap; AUTO uses Local when healthy; only a
        # cloud-only situation with an oversized file fails with the
        # controlled 503 + Local Bot API guidance — never a fake multi-GB
        # claim, never an infinite fallback loop.
        selector = getattr(stack, "selector", None)
        selection = None
        if selector is not None:
            try:
                selection = await selector.select(size)
            except Exception:  # noqa: BLE001 — decision failure ≠ request failure
                selection = None
        if (selection is not None and selection.too_large
                and size is not None):
            logger.info(
                "STREAM_ERROR file_unique_id=%s reason=too_large size=%s "
                "limit=%s local_health=%s", uid, size,
                selector.config.cloud_download_limit_bytes,
                selection.local_state)
            return _json_error(
                503, "too_large_for_transport",
                f"This file ({size} bytes) exceeds the cloud Bot API "
                f"download limit ({selector.config.cloud_download_limit_bytes} "
                "bytes). A healthy Local Bot API server "
                "(TELEGRAM_API_MODE=auto with TELEGRAM_LOCAL_API_URL) is "
                "required for large-file streaming.")
        # Legacy fallback for stacks without a selector (tests): the old
        # config-only check, preserved verbatim.
        cfg = getattr(stack, "config", None)
        if (selection is None and size is not None and cfg is not None
                and not getattr(cfg, "local_mode", False)
                and not getattr(cfg, "auto_mode", False)
                and size > int(cfg.cloud_download_limit_bytes)):
            logger.info(
                "STREAM_ERROR file_unique_id=%s reason=too_large size=%s "
                "limit=%s", uid, size, cfg.cloud_download_limit_bytes)
            return _json_error(
                503, "too_large_for_transport",
                f"This file ({size} bytes) exceeds the cloud Bot API "
                f"download limit ({cfg.cloud_download_limit_bytes} bytes). "
                "Enable a Local Bot API server (TELEGRAM_API_MODE=local) "
                "for large-file streaming.")
        # 6. plan the HTTP semantics (Range discipline, spec §7/§25).
        if size is None:
            # Unknown size: honest 200 stream; ranges are NOT advertised.
            if range_header:
                logger.info("RANGE_ERROR reason=ignored_unknown_size "
                            "file_unique_id=%s", uid)
            headers = {"Content-Type": ctype,
                       "Cache-Control": "private, max-age=60"}
            if method == "HEAD":
                return StreamPlan(200, headers, None, strategy="head")
            release = _make_slot_release()
            _concurrent["n"] += 1
            body = _counted(_iter_direct_full(handle, uid), uid, release)
            return StreamPlan(200, headers, body, strategy="direct-unknown",
                              release=release)
        start, end = 0, size - 1
        status = 200
        if range_header:
            parsed = parse_range_header(range_header, size)
            if parsed is UNSATISFIABLE:
                logger.info("RANGE_ERROR reason=not_satisfiable "
                            "file_unique_id=%s header=%r",
                            uid, str(range_header)[:64])
                return StreamPlan(
                    416,
                    {"Content-Range": unsatisfiable_content_range(size),
                     "Accept-Ranges": "bytes",
                     "Content-Type": ctype, "Cache-Control": "no-store"},
                    None, detail="range not satisfiable", strategy="error")
            if parsed is not None:
                start, end = parsed
                status = 206
        length = (end - start + 1) if end >= start else 0
        headers = {
            "Content-Type": ctype,
            "Accept-Ranges": "bytes",
            "Content-Length": str(length),
            "Cache-Control": "private, max-age=60",
        }
        if status == 206:
            headers["Content-Range"] = content_range_header(start, end, size)
        if method == "HEAD":
            # Metadata without a body; NEVER downloads the media (spec §9).
            return StreamPlan(status, headers, None,
                              detail=f"head bytes {start}-{end}/{size}",
                              strategy="head")
        # 7. choose the bounded transport strategy.
        body, strategy = await _plan_body_async(handle, size, start, end,
                                               settings)
        release = _make_slot_release()
        _concurrent["n"] += 1
        body = _counted(body, uid, release)
        logger.info("STREAM_START file_unique_id=%s range=%s-%s/%s "
                    "strategy=%s", uid, start, end, size, strategy)
        return StreamPlan(status, headers, body, strategy=strategy,
                          release=release)

    # ------------------------------------------------------ body planning
    def _upstream_factory(handle: MediaHandle):
        def _factory():
            return stack.open(handle)
        return _factory

    async def _plan_body_async(handle: MediaHandle, size: int, start: int,
                               end: int, settings: Dict[str, Any]
                               ) -> Tuple[AsyncIterator[bytes], str]:
        use_cache = bool(settings.get("cache_enabled")) and cache is not None \
            and not cache.broken
        upstream = _upstream_factory(handle)
        is_range = not (start == 0 and end == size - 1)
        uid = str(handle.file_unique_id)
        if use_cache and cache is not None:
            if not is_range:
                # Full GET -> coalesced fill (ONE upstream download per
                # identity; concurrent readers follow from disk).
                return (cache.stream(uid, upstream, start=0, end=None,
                                     size_hint=size),
                        "cache-fill")
            # Range request: fully cached / actively filling -> cache disk
            # serve or follow (no duplicate download); miss -> direct.
            try:
                p = await cache.probe(uid)
            except Exception:  # noqa: BLE001
                p = None
            if p and (p.get("complete") or p.get("filling")):
                strat = "cache-range" if p.get("complete") else "cache-follow"
                return (cache.stream(uid, upstream, start=start, end=end,
                                     size_hint=size), strat)
        if is_range:
            # Range request, cache miss: native seeks when the selected
            # transport is the Local Bot API (through the stack's retry
            # policy + the authoritative selector), else the honest cloud
            # skip-passthrough.
            _use_local_range = bool(getattr(stack.config, "local_mode", False))
            _sel = getattr(stack, "selector", None)
            if _sel is not None and not _use_local_range:
                try:
                    _sel_dec = await _sel.select(size)
                    _use_local_range = _sel_dec.is_local
                except Exception:  # noqa: BLE001 — fall back to config view
                    _use_local_range = False
            if _use_local_range:
                async def _native_range():
                    async for chunk in stack.open_range_with_retry(
                            handle, start, end):
                        yield chunk
                return (_native_range(), "local-native-range")
            return (_direct_skip(upstream, start, end,
                                 cache.chunk_size if cache is not None
                                 else 1024 * 1024),
                    "cloud-skip-range")
        # Full GET without cache: direct passthrough (the single-retry
        # repair policy lives inside stack.open — never duplicated here).
        return (_iter_direct_full(handle, uid), "direct-full")

    def _iter_direct_full(handle: MediaHandle, uid: str
                          ) -> AsyncIterator[bytes]:
        """Direct full passthrough with observability."""
        async def _gen():
            sent = 0
            try:
                async for chunk in stack.open(handle):
                    sent += len(chunk)
                    yield chunk
                logger.info("STREAM_END file_unique_id=%s bytes=%s "
                            "strategy=direct", uid, sent)
            except MediaTooLargeError:
                logger.info("STREAM_ERROR file_unique_id=%s reason=too_large",
                            uid)
                raise
            except MediaTransportError as e:
                logger.warning("STREAM_ERROR file_unique_id=%s reason=%s",
                               uid, e.reason)
                raise
        return _gen()

    # ------------------------------------------------------ thumbnails
    async def handle_thumb_request(token: str) -> StreamPlan:
        """Bounded thumbnail bytes (spec §23): AEAD token bound to a
        published listing; resolution walks the Phase 3 priority chain;
        bytes come through the EXISTING source classes with a thumb-scoped
        file-id provider; failures degrade HONESTLY to the styled
        placeholder (never an error page for a card image)."""
        decoded = codec.decode_stream_token(str(token or ""))
        if decoded is None or decoded.get("purpose") != PURPOSE_THUMB:
            return _json_error(401, "invalid_thumb_token",
                               "This thumbnail link is invalid or expired.")
        if listing_resolver is None:
            return _json_error(503, "unavailable", "Thumbnails unavailable.")
        try:
            target = await listing_resolver(str(decoded.get("listing")),
                                             int(decoded.get("file_pk") or 0))
        except Exception:  # noqa: BLE001
            target = None
        if target is None:
            return _json_error(404, "not_found", "No such published payload.")
        settings = await read_settings()
        if not settings.get("stream_enabled"):
            return _json_error(503, "streaming_disabled",
                               "Website streaming is switched off.")
        parent_row = target.get("parent_row")
        descriptor = _thumb_descriptor(target, parent_row)
        if descriptor is None:
            return _thumb_placeholder_plan()
        data, ctype = await _fetch_thumb_bytes(descriptor, parent_row)
        if not data:
            return _thumb_placeholder_plan()
        logger.info("MEDIA_THUMB_SERVED file_unique_id=%s bytes=%s",
                    descriptor.get("file_unique_id") or "(ref)", len(data))
        return StreamPlan(
            200,
            {"Content-Type": ctype,
             "Content-Length": str(len(data)),
             "Cache-Control":
                 f"private, max-age={THUMB_BROWSER_CACHE_SECONDS}"},
            _single_shot(data),
            strategy="thumb-bytes")

    def _thumb_placeholder_plan() -> StreamPlan:
        """Styled placeholder art (the Phase 3 fallback level, honest)."""
        svg = _placeholder_thumb_svg()
        return StreamPlan(
            200,
            {"Content-Type": "image/svg+xml; charset=utf-8",
             "Content-Length": str(len(svg.encode("utf-8"))),
             "Cache-Control":
                 f"private, max-age={THUMB_BROWSER_CACHE_SECONDS}"},
            _single_shot(svg.encode("utf-8")),
            strategy="thumb-placeholder")

    def _thumb_descriptor(target: Dict[str, Any], parent_row: Any
                          ) -> Optional[Dict[str, Any]]:
        """The Phase 3 thumbnail priority chain, data level (configured →
        indexed/telegram → image-as-art). Returns None for pure fallback."""
        # 1. configured Website thumbnail (listing row)
        listing_thumb_uid = target.get("listing_thumb_file_unique_id")
        listing_thumb_fid = target.get("listing_thumb_file_id")
        if listing_thumb_uid or listing_thumb_fid:
            return {"file_unique_id": listing_thumb_uid,
                    "file_id": listing_thumb_fid}
        # 2/3. indexed file's own thumbnail / the image file itself
        tuid = _rowget(parent_row, "thumb_file_unique_id")
        tfid = _rowget(parent_row, "thumb_file_id")
        if tuid or tfid:
            return {"file_unique_id": tuid, "file_id": tfid}
        uid = _rowget(parent_row, "file_unique_id")
        ftype = str(_rowget(parent_row, "media_type") or "").lower()
        if uid and ftype in ("photo", "image"):
            return {"file_unique_id": uid,
                    "file_id": _rowget(parent_row, "file_id")}
        return None

    async def _fetch_thumb_bytes(descriptor: Dict[str, Any], parent_row: Any
                                 ) -> Tuple[Optional[bytes], str]:
        """Fetch bounded thumbnail bytes through the EXISTING source
        classes with a thumb-scoped file-id provider. Bounded to
        DEFAULT_THUMB_MAX_BYTES; any failure -> (None, '') — placeholder."""
        uid = descriptor.get("file_unique_id")
        direct_fid = descriptor.get("file_id")
        if not uid and not direct_fid:
            return None, ""
        expected_uid = str(uid) if uid else f"thumbref:{direct_fid}"

        async def thumb_provider(file_unique_id: str) -> Optional[str]:
            # Thumb-scoped resolution: the descriptor's own reference wins
            # (telegram thumbs are not indexed rows); indexed images fall
            # through to the canonical row.
            if direct_fid and str(file_unique_id) == expected_uid:
                return str(direct_fid)
            try:
                row = await db.get_indexed_file_by_unique_id(
                    str(file_unique_id))
            except Exception:  # noqa: BLE001
                return None
            if row is None:
                return None
            return row["file_id"] if "file_id" in row.keys() else None

        cfg = stack.config
        http = getattr(stack, "http", None)
        token = getattr(stack, "bot_token", "") or ""
        # Reuse the EXISTING source classes (never a second transport).
        # GAP-CLOSURE: AUTO mode streams thumbnails through the SAME
        # authoritative selector (local when healthy, cloud otherwise).
        _thumb_src = None
        if cfg.local_configured:
            from app.media.sources.local_botapi import LocalBotApiSource
            _thumb_src = LocalBotApiSource(cfg, token,
                                           file_id_provider=thumb_provider,
                                           http=http)
        _cloud_src = None
        from app.media.sources.telegram_cloud import TelegramCloudSource
        _cloud_src = TelegramCloudSource(cfg, token,
                                         file_id_provider=thumb_provider,
                                         http=http)
        _sel = getattr(stack, "selector", None)
        src = _cloud_src
        if _sel is not None:
            try:
                _dec = await _sel.select(None)
                if _dec.is_local and _thumb_src is not None:
                    src = _thumb_src
            except Exception:  # noqa: BLE001 — cloud thumbnails always work
                src = _cloud_src
        elif getattr(cfg, "local_mode", False) and _thumb_src is not None:
            src = _thumb_src
        handle = MediaHandle(
            file_unique_id=expected_uid,
            source_channel_id=_rowget_int(parent_row, "channel_id") or 0,
            source_message_id=_rowget_int(parent_row, "message_id") or 0,
            file_name=None, mime_type=None, size=None)
        data = bytearray()
        agen = src.open(handle)
        try:
            async for chunk in agen:
                data.extend(chunk)
                if len(data) > DEFAULT_THUMB_MAX_BYTES:
                    logger.info("MEDIA_THUMB_SKIP reason=too_large "
                                "bound=%s", DEFAULT_THUMB_MAX_BYTES)
                    return None, ""
        except Exception as e:  # noqa: BLE001 — honest placeholder
            logger.info("MEDIA_THUMB_UNAVAILABLE reason=%s",
                        type(e).__name__)
            return None, ""
        finally:
            # PHASE 5: early exit (too-large) must not leave the source
            # generator (and its underlying HTTP response) open until GC.
            try:
                await agen.aclose()
            except Exception:  # noqa: BLE001 — best effort
                pass
        if not data:
            return None, ""
        return bytes(data), _sniff_image_type(bytes(data[:16]))

    # ------------------------------------------------------ admin surface
    async def cache_stats() -> Dict[str, int]:
        if cache is None:
            return {"enabled": 0}
        stats = cache.stats()
        stats["enabled"] = 1
        return stats

    async def purge_cache() -> Dict[str, int]:
        if cache is None:
            return {"removed": 0, "doomed_active": 0, "enabled": 0}
        out = await cache.purge()
        out["enabled"] = 1
        return out

    async def cleanup_cache() -> Dict[str, int]:
        if cache is None:
            return {"evicted": 0, "skipped_active": 0, "bytes": 0}
        return await cache.cleanup()

    def transport_status() -> Dict[str, Any]:
        """Safe transport summary for the admin panel (no secrets)."""
        cfg = getattr(stack, "config", None)
        if cfg is None:
            return {"mode": "unknown", "local_ready": False}
        base = {
            "mode": cfg.api_mode,
            "local_ready": bool(cfg.local_api_url),
            "local_host": (cfg.local_api_url or "//").split("//")[-1]
            .split("/")[0],
            "file_root": cfg.local_file_root or "",
            "cloud_limit_bytes": cfg.cloud_download_limit_bytes,
            "chunk_bytes": cfg.clamped_chunk_size(),
            "timeout_seconds": cfg.http_timeout_seconds,
            "getfile_timeout_seconds": cfg.getfile_timeout_seconds,
            "describe": cfg.describe(),
        }
        # GAP-CLOSURE: runtime health-aware view when the selector exists.
        return base

    async def transport_health() -> Dict[str, Any]:
        """Runtime health-aware transport status (spec §14) — selector
        view with live local-server health, async by nature."""
        sel = getattr(stack, "selector", None)
        if sel is None:
            return transport_status()
        try:
            status = await sel.status()
        except Exception:  # noqa: BLE001 — honest degraded view
            status = {"mode": getattr(stack.config, "api_mode", "?"),
                      "error": "status_unavailable"}
        return status

    async def transport_feasibility(size: Optional[int]) -> Dict[str, Any]:
        """GAP-CLOSURE (spec §11): the AUTHORITATIVE too-large answer for
        stream issuance — the SAME MediaTransportSelector decision the
        media request itself would take (never a second, scattered size
        check). Returns {too_large, limit, local_state} (no secrets)."""
        sel = getattr(stack, "selector", None)
        if sel is None or size is None:
            return {"too_large": False, "limit": None,
                    "local_state": "unknown"}
        try:
            selection = await sel.select(int(size))
        except Exception:  # noqa: BLE001 — decision failure ≠ request failure
            return {"too_large": False, "limit": None,
                    "local_state": "unknown"}
        limit = getattr(sel.config, "cloud_download_limit_bytes", None)
        return {"too_large": bool(getattr(selection, "too_large", False)),
                "limit": int(limit) if limit is not None else None,
                "local_state": str(getattr(selection, "local_state",
                                           "unknown"))}

    def concurrency() -> int:
        return int(_concurrent["n"])

    return SimpleNamespace(
        codec=codec,
        listing_resolver=listing_resolver,
        read_settings=read_settings,
        issue_stream_token=issue_stream_token,
        handle_stream_request=handle_stream_request,
        handle_thumb_request=handle_thumb_request,
        cache_stats=cache_stats,
        purge_cache=purge_cache,
        cleanup_cache=cleanup_cache,
        transport_status=transport_status,
        transport_health=transport_health,
        transport_feasibility=transport_feasibility,
        concurrency=concurrency,
        cache=cache,
        stack=stack,
    )


# ---------------------------------------------------------------- helpers
def _single_shot(data: bytes) -> AsyncIterator[bytes]:
    async def _gen():
        yield data
    return _gen()


def _sniff_image_type(head: bytes) -> str:
    """Honest image type sniffing from magic bytes (bounded, no libs)."""
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if head.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    return "application/octet-stream"


def _placeholder_thumb_svg() -> str:
    """Deterministic styled placeholder (same visual family as the Phase 3
    feed art — near-black canvas + emerald ambience, no external deps)."""
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" '
        'viewBox="0 0 640 360" role="img" aria-label="Payload artwork">'
        '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
        '<stop offset="0" stop-color="#0d1420"/><stop offset="0.55" '
        'stop-color="#101c2c"/><stop offset="1" stop-color="#0a121f"/>'
        '</linearGradient></defs>'
        '<rect width="640" height="360" fill="url(#g)"/>'
        '<circle cx="320" cy="180" r="64" fill="none" '
        'stroke="#10b981" stroke-opacity="0.65" stroke-width="3"/>'
        '<path d="M305 156 L305 204 L349 180 Z" fill="#10b981" '
        'fill-opacity="0.85"/>'
        '<text x="320" y="330" font-family="system-ui,sans-serif" '
        'font-size="15" fill="#34d399" fill-opacity="0.5" '
        'text-anchor="middle">Payload</text></svg>')
