"""Media transport error taxonomy + Bot API error classification.

PURE module: no aiohttp, no bot.py, no Telegram imports. The classifiers
mirror the production marker semantics of the delivery engine
(bot.py:_WRONG_FILE_ID_MARKERS / is_wrong_file_id_error) so the media layer
classifies the SAME error shapes the Telegram wire actually produces.
"""
from __future__ import annotations

from typing import Optional


class MediaTransportError(Exception):
    """Base class for every media transport failure.

    ``reason`` is a stable machine-readable string (never the raw upstream
    text, which can contain URLs). Messages NEVER contain bot tokens or
    upstream URLs — sources pass a safe ``origin`` label instead.
    """

    def __init__(self, message: str, *, reason: str = "transport_error",
                 status: Optional[int] = None,
                 retryable: bool = False) -> None:
        super().__init__(message)
        self.reason = reason
        self.status = status
        self.retryable = retryable


class FileIdInvalidError(MediaTransportError):
    """The stored file_id is NOT usable by THIS bot context (wrong/foreign/
    expired identifier — the exact class the delivery engine recovers from).

    Recovery contract (Phase 7 hotfix semantics): the caller may repair the
    canonical row from the source reference and retry ONCE.
    """

    def __init__(self, message: str = "stored file_id rejected",
                 *, origin: str = "media") -> None:
        super().__init__(message, reason="file_id_invalid", retryable=False)
        self.origin = origin


class MediaTooLargeError(MediaTransportError):
    """The file exceeds the transport's size capability (cloud Bot API
    getFile/download is capped — 20 MB by default). The honest remedy is a
    Local Bot API server (TELEGRAM_API_MODE=local)."""

    def __init__(self, message: str = "file exceeds transport size limit",
                 *, limit: Optional[int] = None) -> None:
        super().__init__(message, reason="too_large", retryable=False)
        self.limit = limit


class MediaSourceUnavailableError(MediaTransportError):
    """Upstream is temporarily unreachable / rate-limited / 5xx. Retryable by
    policy at a higher layer; never misclassified as an identity failure."""

    def __init__(self, message: str = "media upstream unavailable",
                 *, status: Optional[int] = None,
                 retryable: bool = True) -> None:
        super().__init__(message, reason="upstream_unavailable",
                         status=status, retryable=retryable)


class MediaBadRequestError(MediaTransportError):
    """A deterministic upstream rejection that is neither an identity
    failure nor a size failure (bad parameters, expired download paths…)."""

    def __init__(self, message: str, *, status: Optional[int] = None,
                 origin: str = "media") -> None:
        super().__init__(message, reason="bad_request", status=status,
                         retryable=False)
        self.origin = origin


class RangeUnsupportedError(MediaTransportError):
    """This transport cannot serve byte ranges (e.g. the cloud file endpoint,
    or a local endpoint that ignored a Range request)."""

    def __init__(self, message: str = "transport does not support ranges") -> None:
        super().__init__(message, reason="range_unsupported", retryable=False)


class RangeNotSatisfiableError(MediaTransportError):
    """The requested range lies entirely outside the file (HTTP 416)."""

    def __init__(self, message: str = "range not satisfiable") -> None:
        super().__init__(message, reason="range_not_satisfiable",
                         status=416, retryable=False)


class UnresolvableMediaError(MediaTransportError):
    """The file record cannot be mapped to a streamable media identity
    (missing file_unique_id, or the canonical row disappeared)."""

    def __init__(self, message: str = "media record unresolvable",
                 *, reason: str = "unresolvable") -> None:
        super().__init__(message, reason=reason, retryable=False)


class MediaNotFoundError(MediaTransportError):
    """The upstream proves the stored media itself no longer exists
    ("file not found" / deleted at the source). Distinct from a stale
    file_id (recoverable) — this is a terminal 404-class state: the
    frontend must show an honest "file unavailable" state, not retry
    and not "your authorization expired"."""

    def __init__(self, message: str = "media no longer exists upstream",
                 *, status=None, origin: str = "media") -> None:
        super().__init__(message, reason="media_not_found", status=status,
                         retryable=False)
        self.origin = origin


class MediaRecoveryFailedError(MediaTransportError):
    """File-id recovery was attempted and failed (or is impossible). Raised
    after the single allowed retry — the caller must NOT loop."""

    def __init__(self, message: str = "file_id recovery failed",
                 *, detail: str = "") -> None:
        super().__init__(f"{message}{': ' + detail if detail else ''}",
                         reason="recovery_failed", retryable=False)


# --------------------------------------------------------------------------
# Classification (pure functions on upstream error text/status)
# --------------------------------------------------------------------------

# The production signature markers (lower-cased). Kept in sync with the
# delivery engine's classification — see bot.py:_WRONG_FILE_ID_MARKERS.
_WRONG_FILE_ID_MARKERS = (
    "wrong file identifier",
    "http url specified",
    "wrong remote file identifier",
    "invalid file_id",
    "invalid file id",
    "file_id_invalid",
    "wrong file id",
    "wrong persistent file id",
    "persistent_id_invalid",
    "file identifier is not valid",
    "invalid file identifier",
)

# getFile-phase rejections that prove the stored media itself is gone at
# the source (the identity can no longer be served at all -- recovery
# would be pointless; surface an honest not-found instead of retrying).
_FILE_GONE_MARKERS = (
    "file not found",
    "file is not found",
    "file has been deleted",
)

_TOO_LARGE_MARKERS = (
    "file is too big",
    "file is too large",
    "requested file is too big",
)


def is_wrong_file_id_text(text: str) -> bool:
    """True when upstream text proves a wrong/foreign/expired file_id."""
    s = (text or "").lower()
    return any(marker in s for marker in _WRONG_FILE_ID_MARKERS)


def is_too_large_text(text: str) -> bool:
    """True when upstream text reports a size-cap rejection."""
    s = (text or "").lower()
    return any(marker in s for marker in _TOO_LARGE_MARKERS)


def is_file_gone_text(text: str) -> bool:
    """True when upstream text proves the media itself is gone upstream
    (terminal — no recovery, honest not-found state)."""
    s = (text or "").lower()
    return any(marker in s for marker in _FILE_GONE_MARKERS)


def classify_botapi_error(status: Optional[int], description: str,
                          *, origin: str = "media") -> MediaTransportError:
    """Map a Bot API error (status + description) to the taxonomy.

    Order matters: identity markers FIRST (they are unambiguous rejections),
    then size caps, then rate-limit/unavailable, then generic bad request.
    NEVER turns an ambiguous failure (network, 5xx, flood) into an identity
    failure — the same discipline as the delivery engine's probe.
    """
    desc = description or ""
    if is_file_gone_text(desc):
        return MediaNotFoundError(
            f"media gone from {origin}: {desc}", status=status, origin=origin)
    if is_wrong_file_id_text(desc):
        return FileIdInvalidError(
            f"file_id rejected by {origin}: {desc}", origin=origin)
    if is_too_large_text(desc):
        return MediaTooLargeError(
            f"file too large for {origin}: {desc}")
    if status == 429:
        return MediaSourceUnavailableError(
            f"rate limited by {origin}", status=429, retryable=True)
    if status is not None and status >= 500:
        return MediaSourceUnavailableError(
            f"upstream error from {origin}", status=status, retryable=True)
    return MediaBadRequestError(
        f"{origin} rejected request: {desc or 'no description'}",
        status=status, origin=origin)
