"""BOT-16 MKV/HEVC browser-compatibility pipeline — the HLS transcoding manager.

The REMEDIATION half of the BOT-16 production failure (an MKV/HEVC file
served raw → "Cannot play in this browser"): :mod:`app.media.probe`
classifies a media file as TRANSCODE, and THIS module turns it into a
browser-guaranteed HLS VOD presentation (h264 + aac, MPEG-TS segments, a
master playlist with an adaptive variant ladder).

Design contract (mirrors the StreamCache discipline in
:mod:`app.media.streamcache`):

  * CACHE IDENTITY is ``file_unique_id`` (hashed into the on-disk dir —
    the :mod:`app.media.cachekeys` rule; a repaired file_id never
    invalidates a rendered HLS tree).
  * BOUNDED CONCURRENCY: ONE global ffmpeg job at a time by default
    (``max_concurrent`` semaphore — transcoding is CPU-heavy), plus
    per-identity asyncio locks with COALESCED FILL: the first caller
    runs the job; every later caller of the same identity WAITS on the
    per-file lock and then reuses the result — never a duplicate ffmpeg
    run for the same media.
  * HONEST DISK STATE: every entry dir carries ``state.json``
    ({"status": "ready"|"failed"|"running", "ts": ..., "source_size": int,
    "variants": [...]}). A dir whose state is not "ready" — or whose
    master/variant playlists are missing — is WIPED and redone (a crashed
    partial render is never served). A "failed" state is retried only
    after an exponential-ish backoff window (600 s base, doubling, capped
    at 3600 s) so a permanently broken source cannot spawn an ffmpeg
    storm.
  * HONEST FAILURES: non-zero ffmpeg exits surface the first 300 chars of
    the stderr tail as the error string; timeouts kill the process GROUP
    (``start_new_session``) and are reported as timeouts — never as a
    fabricated success.
  * RETENTION: :meth:`TranscodeManager.cleanup` removes entries whose
    newest file is older than ``hls_retention`` (default 24 h), skipping
    entries that are actively running.

The VERIFIED ffmpeg invocation (real ffmpeg 7.1.5, verified in this repo's
environment — see tests/test_bot16_transcode.py):

    ffmpeg -y -nostdin -hide_banner -loglevel error -i <src>
      -filter_complex "[0:v]split=N[v1]...[vN];[v1]scale=-2:360[v1o];..."
      -map "[v1o]" -map 0:a? \\
      -map "[v2o]" -map 0:a? \\
      ...
      -c:v:0 libx264 -preset veryfast -crf 23 -maxrate 800k -bufsize 1600k
        -g 48 -keyint_min 48 -sc_threshold 0 -pix_fmt yuv420p
      ... per variant ...
      -c:a aac -b:a 128k -ac 2
      -f hls -hls_time 6 -hls_list_size 0 -hls_playlist_type vod
        -hls_segment_type mpegts -hls_flags independent_segments
      -master_pl_name master.m3u8
      -var_stream_map "v:0,a:0,name:360p v:1,a:1,name:480p ..."
      -hls_segment_filename "<dir>/%v/seg%05d.ts" "<dir>/%v/index.m3u8"

DEVIATION FROM THE SPEC DRAFT (verified necessary): the shared-audio
``var_stream_map`` form ("v:0,a:0 v:1,a:0" — one mapped audio reused by
every variant) FAILS on ffmpeg 7.1.5 with "Could not write header
(incorrect codec parameters?): Invalid argument". The audio is therefore
mapped SEPARATELY per variant (``-map 0:a?`` after each video map,
``a:<i>`` per var_stream_map entry) — verified working; audio is encoded
once per variant (the only observable difference is a few extra encoder
ticks).

Secrets discipline: argv carries only LOCAL paths and flags — no tokens,
no Telegram URLs. ``-nostdin`` keeps ffmpeg from ever touching stdin.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import signal
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

from app.media.probe import probe_media

logger = logging.getLogger("app.media.transcode")
# V26.2-bot42: the HLS_PREPARATION lifecycle lines are WEBSITE-surface
# telemetry — they ride the "payload-bot" logger alongside
# WEBSITE_HLS_ENSURE/SERVE/REQUEST for ONE greppable production story
# (the module logger keeps the MEDIA_* lines exactly as before).
_site_logger = logging.getLogger("payload-bot")

# ------------------------------------------------------------------ ladder
# The variant ladder (BOT-16): every level <= source height is offered,
# ALWAYS including the max level <= H. Data-driven so tests enumerate it.
LADDER_LEVELS: Tuple[int, ...] = (1080, 720, 480, 360)

# Per-level target bitrate ladder (bits/s) — matches the -maxrate flags.
LADDER_BANDWIDTHS: Dict[int, int] = {
    1080: 5_000_000,
    720: 2_800_000,
    480: 1_400_000,
    360: 800_000,
}
# Per-level ffmpeg rate-control strings (-maxrate/-bufsize pairs).
LADDER_MAXRATES: Dict[int, Tuple[str, str]] = {
    1080: ("5000k", "10000k"),
    720: ("2800k", "5600k"),
    480: ("1400k", "2800k"),
    360: ("800k", "1600k"),
}
# Fallback rate control for non-ladder heights (source smaller than 360p).
_LADDER_MIN_BANDWIDTH = 200_000

# Single-variant rule: a source at/below 360p is served as one variant
# labeled "Source" (no downscale lies on the player UI).
SOURCE_LABEL_MAX_HEIGHT = 360

# ------------------------------------------------------------------ state
STATE_READY = "ready"
STATE_FAILED = "failed"
STATE_RUNNING = "running"

# Failed-entry retry backoff (exponential-ish, capped).
FAILED_RETRY_BASE_SECONDS = 600.0
FAILED_RETRY_MAX_SECONDS = 3600.0

MASTER_PLAYLIST_NAME = "master.m3u8"
VARIANT_PLAYLIST_NAME = "index.m3u8"
STATE_FILE_NAME = "state.json"

# Bounded stderr tail kept for honest error reporting (bytes; the error
# string itself is clamped to the spec's 300 chars).
_STDERR_TAIL_BYTES = 8192
_STDERR_ERROR_CHARS = 300

SourcePathFn = Callable[[], Awaitable[str]]


def _digest(file_unique_id: str) -> str:
    """Traversal-proof entry dir name (the StreamCache _safe_subdir rule)."""
    return hashlib.sha256(
        str(file_unique_id or "").encode("utf-8")).hexdigest()


def _safe_attempts(state: Dict[str, Any]) -> int:
    """Best-effort attempts counter read (never raises)."""
    try:
        return max(0, int((state or {}).get("attempts") or 0))
    except (TypeError, ValueError):
        return 0


def _even_floor(height: int) -> int:
    """Round a height DOWN to the nearest even value (x264 requires
    even dimensions; never round UP past the source)."""
    h = max(2, int(height))
    return h - (h % 2)


def _bandwidth_for(height: int) -> int:
    bw = LADDER_BANDWIDTHS.get(int(height))
    if bw is not None:
        return bw
    scaled = int(LADDER_BANDWIDTHS[360] * int(height) / 360.0)
    return max(_LADDER_MIN_BANDWIDTH, min(LADDER_BANDWIDTHS[1080], scaled))


def _rate_control_for(height: int) -> Tuple[str, str]:
    """(-maxrate, -bufsize) strings for one ladder height."""
    rc = LADDER_MAXRATES.get(int(height))
    if rc is not None:
        return rc
    maxrate_k = max(1, _bandwidth_for(int(height)) // 1000)
    return (f"{maxrate_k}k", f"{maxrate_k * 2}k")


def variant_ladder(height: Optional[int],
                   *, max_variants: int = 4) -> List[Dict[str, Any]]:
    """Compute the HLS variant ladder for one source height.

    Rules (BOT-16, locked by tests):
      * levels = [1080, 720, 480, 360] filtered to ``<= H`` — the max
        level <= H is ALWAYS present (the best offered rendition);
      * empty (H below 360) -> the source height rounded down to even;
      * capped at ``max_variants`` keeping the TOP entries (so the max
        level always survives the cap);
      * H <= 360 -> a single variant labeled "Source" (id "<H>p").

    Returns ``[{"id": "360p", "label": "360p", "height": 360,
    "bandwidth": 800000}, ...]`` (highest quality first).
    """
    try:
        h = int(height) if height is not None else 0
    except (TypeError, ValueError):
        h = 0
    if h <= 0:
        h = 360  # unknown height -> the safest single rendition
    levels = [lvl for lvl in LADDER_LEVELS if lvl <= h]
    if not levels:
        levels = [_even_floor(h)]
    # Cap keeps the TOP entries (highest qualities): the max level <= H
    # ALWAYS survives the cap by construction.
    cap = max(1, int(max_variants))
    if len(levels) > cap:
        levels = levels[:cap]
    single_source = len(levels) == 1 and levels[0] <= SOURCE_LABEL_MAX_HEIGHT
    out: List[Dict[str, Any]] = []
    for lvl in levels:
        label = "Source" if single_source else f"{lvl}p"
        out.append({
            "id": f"{lvl}p",
            "label": label,
            "height": int(lvl),
            "bandwidth": _bandwidth_for(int(lvl)),
        })
    return out


# ------------------------------------------------------------------ result
@dataclass
class TranscodeResult:
    """One ensure_hls() outcome (never an exception — honest fields)."""

    ok: bool = False
    dir: Optional[Path] = None
    master: str = MASTER_PLAYLIST_NAME
    variants: List[Dict[str, Any]] = field(default_factory=list)
    error: Optional[str] = None
    created: bool = False


# --------------------------------------------------------------- ffmpeg cmd
def build_ffmpeg_hls_command(source_path: str, out_dir: Path,
                             variants: List[Dict[str, Any]], *,
                             segment_seconds: int = 6,
                             has_audio: bool = True) -> List[str]:
    """Build the VERIFIED multi-variant HLS VOD ffmpeg argv (see the module
    docstring for the verified invocation and the shared-audio deviation).

    ``variants`` is the :func:`variant_ladder` output (highest first).
    """
    out_dir = Path(out_dir)  # accept str roots too (public helper)
    n = len(variants)
    filter_parts: List[str] = []
    if n == 1:
        filter_parts.append(
            f"[0:v]scale=-2:{int(variants[0]['height'])}[v0o]")
    else:
        split = "".join(f"[v{i}]" for i in range(n))
        filter_parts.append(f"[0:v]split={n}{split}")
        for i, v in enumerate(variants):
            filter_parts.append(
                f"[v{i}]scale=-2:{int(v['height'])}[v{i}o]")
    filter_complex = ";".join(filter_parts)

    cmd: List[str] = ["ffmpeg", "-y", "-nostdin", "-hide_banner",
                      "-loglevel", "error", "-i", str(source_path),
                      "-filter_complex", filter_complex]
    for i, v in enumerate(variants):
        cmd.append("-map")
        cmd.append(f"[v{i}o]")
        if has_audio:
            # Audio is mapped PER VARIANT (the verified form — the shared
            # "a:0,a:0" var_stream_map fails header init on ffmpeg 7.1.5).
            cmd.append("-map")
            cmd.append("0:a?")
        maxrate, bufsize = _rate_control_for(int(v["height"]))
        cmd.extend([
            f"-c:v:{i}", "libx264", "-preset", "veryfast", "-crf", "23",
            "-maxrate", maxrate, "-bufsize", bufsize,
            "-g", "48", "-keyint_min", "48", "-sc_threshold", "0",
            "-pix_fmt", "yuv420p",
        ])
    if has_audio:
        cmd.extend(["-c:a", "aac", "-b:a", "128k", "-ac", "2"])
    cmd.extend([
        "-f", "hls",
        "-hls_time", str(int(segment_seconds)),
        "-hls_list_size", "0",
        "-hls_playlist_type", "vod",
        "-hls_segment_type", "mpegts",
        "-hls_flags", "independent_segments",
        "-master_pl_name", MASTER_PLAYLIST_NAME,
    ])
    vsm_entries = []
    for i, v in enumerate(variants):
        entry = f"v:{i}"
        if has_audio:
            entry += f",a:{i}"
        entry += f",name:{v['id']}"
        vsm_entries.append(entry)
    cmd.extend(["-var_stream_map", " ".join(vsm_entries)])
    cmd.extend(["-hls_segment_filename",
                str(out_dir / "%v" / "seg%05d.ts"),
                str(out_dir / "%v" / VARIANT_PLAYLIST_NAME)])
    return cmd


# ------------------------------------------------------------------ manager
class TranscodeManager:
    """Bounded, cached, coalesced HLS transcoding manager (see module
    docstring). All disk state lives under ``<cache_root>/hls/<digest>/``.
    """

    def __init__(self, cache_root: str, *,
                 max_concurrent: int = 1,
                 segment_seconds: int = 6,
                 hls_retention: float = 24 * 3600,
                 ffprobe_timeout: float = 20.0,
                 ffmpeg_timeout: float = 4 * 3600,
                 max_variants: int = 4) -> None:
        self.cache_root = str(cache_root)
        self.max_concurrent = max(1, int(max_concurrent))
        self.segment_seconds = max(1, int(segment_seconds))
        self.hls_retention = float(hls_retention)
        self.ffprobe_timeout = float(ffprobe_timeout)
        self.ffmpeg_timeout = float(ffmpeg_timeout)
        self.max_variants = max(1, int(max_variants))
        self._semaphore = asyncio.Semaphore(self.max_concurrent)
        self._locks: Dict[str, asyncio.Lock] = {}
        self._locks_guard = asyncio.Lock()
        self._running: set = set()
        self._stopped = False
        # V26.2-bot42 (TASK C1 — ASYNCHRONOUS HLS PREPARATION): one
        # COALESCED BACKGROUND TASK per media identity. The browser's
        # master.m3u8 request NEVER waits for ffmpeg: the first request
        # STARTS (or joins) the preparation job and receives an honest
        # 503 hls_preparing; once the tree is READY the master serves for
        # real. Concurrent requests for the same file share ONE job —
        # never a duplicate ffmpeg process.
        self._prepare_tasks: Dict[str, "asyncio.Task[TranscodeResult]"] = {}
        self._prepare_guard = asyncio.Lock()
        # Observability counters.
        self.stats_runs = 0
        self.stats_failures = 0
        self.stats_cache_hits = 0
        self.stats_wipes = 0
        self.stats_prepare_started = 0
        self.stats_prepare_coalesced = 0

    # ------------------------------------------------------------ helpers
    def _entry_dir(self, file_unique_id: str) -> Path:
        return Path(self.cache_root) / "hls" / _digest(file_unique_id)

    async def _get_file_lock(self, digest: str) -> asyncio.Lock:
        async with self._locks_guard:
            lock = self._locks.get(digest)
            if lock is None:
                lock = asyncio.Lock()
                self._locks[digest] = lock
            return lock

    async def _read_state(self, entry_dir: Path) -> Optional[Dict[str, Any]]:
        def _read() -> Optional[Dict[str, Any]]:
            try:
                with open(entry_dir / STATE_FILE_NAME, "r",
                          encoding="utf-8") as fh:
                    doc = json.load(fh)
                return doc if isinstance(doc, dict) else None
            except (OSError, ValueError):
                return None
        try:
            return await asyncio.to_thread(_read)
        except Exception:  # noqa: BLE001 — state is advisory, never fatal
            return None

    async def _write_state(self, entry_dir: Path,
                           doc: Dict[str, Any]) -> None:
        def _write() -> None:
            try:
                os.makedirs(entry_dir, exist_ok=True)
                tmp = entry_dir / (STATE_FILE_NAME + ".tmp")
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(doc, fh)
                os.replace(tmp, entry_dir / STATE_FILE_NAME)
            except OSError:
                pass  # best-effort persistence
        try:
            await asyncio.to_thread(_write)
        except Exception:  # noqa: BLE001 — best effort only
            pass

    async def _wipe(self, entry_dir: Path) -> None:
        """Remove a partial/corrupted entry dir (idempotent, best effort —
        the StreamCache two-step rmtree discipline: delete, yield, delete
        again so late writers cannot resurrect a half-dead entry)."""
        self.stats_wipes += 1
        logger.info("MEDIA_TRANSCODE_WIPE entry=%s", entry_dir.name)

        def _rm() -> None:
            import shutil
            shutil.rmtree(entry_dir, ignore_errors=True)
        try:
            await asyncio.to_thread(_rm)
            await asyncio.sleep(0)
            await asyncio.to_thread(_rm)
        except Exception:  # noqa: BLE001 — best effort
            pass

    def _outputs_complete(self, entry_dir: Path,
                          variants: List[Dict[str, Any]]) -> bool:
        """True when master + every variant playlist exists on disk."""
        try:
            if not (entry_dir / MASTER_PLAYLIST_NAME).is_file():
                return False
            for v in variants or []:
                vid = str((v or {}).get("id") or "")
                if not re.match(r"^[A-Za-z0-9_\-]+$", vid):
                    return False
                if not (entry_dir / vid / VARIANT_PLAYLIST_NAME).is_file():
                    return False
            return True
        except OSError:
            return False

    @staticmethod
    def _failed_backoff_seconds(state: Dict[str, Any]) -> float:
        """Exponential-ish retry window for a failed entry (600 s base,
        doubling per stored attempt, capped at 3600 s)."""
        try:
            attempts = max(1, int(state.get("attempts") or 1))
        except (TypeError, ValueError):
            attempts = 1
        return min(FAILED_RETRY_MAX_SECONDS,
                   FAILED_RETRY_BASE_SECONDS * (2 ** (attempts - 1)))

    # ------------------------------------------------------------- public
    async def ensure_hls(self, file_unique_id: str,
                         source_path_fn: SourcePathFn) -> TranscodeResult:
        """Guarantee a READY HLS tree for one media identity.

        ``source_path_fn`` — an async callable ``() -> str`` resolving a
        LOCAL source file path (the wiring layer supplies the
        cache/disk/download resolution; this module never touches
        Telegram). Called at most once per actual job, under the global
        concurrency semaphore.

        Coalescing: concurrent callers for the SAME identity wait on the
        per-identity lock and reuse the first job's result. Honest cache
        hits return ``created=False``; corrupt/partial entries are wiped
        and redone; a recent failure returns the failure (backoff).
        """
        digest = _digest(file_unique_id)
        entry_dir = self._entry_dir(file_unique_id)
        lock = await self._get_file_lock(digest)
        async with lock:
            state = await self._read_state(entry_dir)
            attempts_seed = 0
            if state is not None:
                status = str(state.get("status") or "")
                if status == STATE_READY:
                    variants = list(state.get("variants") or [])
                    if self._outputs_complete(entry_dir, variants):
                        self.stats_cache_hits += 1
                        return TranscodeResult(
                            ok=True, dir=entry_dir,
                            master=MASTER_PLAYLIST_NAME,
                            variants=variants, error=None, created=False)
                    # ready-state but outputs missing: honest wipe + redo
                    await self._wipe(entry_dir)
                elif status == STATE_FAILED:
                    age = time.time() - float(state.get("ts") or 0.0)
                    backoff = self._failed_backoff_seconds(state)
                    if 0.0 <= age < backoff:
                        return TranscodeResult(
                            ok=False, dir=None,
                            error="recent_failure_backoff "
                                  f"({int(backoff - age)}s remain)",
                            created=False)
                    # Past the backoff window: RETRY. The attempts
                    # counter survives the wipe so the exponential-ish
                    # backoff keeps growing across retry cycles.
                    attempts_seed = _safe_attempts(state)
                    await self._wipe(entry_dir)
                else:
                    # "running" leftover of a crashed process (this
                    # process holds the lock, so no live job owns it) or
                    # an unknown status: wipe + redo, keeping the
                    # crashed run's attempt count.
                    attempts_seed = _safe_attempts(state)
                    await self._wipe(entry_dir)
            if self._stopped:
                return TranscodeResult(
                    ok=False, dir=None, error="transcoder_stopped",
                    created=False)
            async with self._semaphore:
                return await self._transcode(digest, entry_dir,
                                             source_path_fn, attempts_seed)

    # ---------------------------------------- V26.2-bot42 async preparation
    async def hls_preparation_snapshot(self,
                                       file_unique_id: str) -> Dict[str, Any]:
        """TASK C1 — the NON-BLOCKING readiness snapshot for one identity.

        Reads the persisted state + the disk outputs and answers, without
        ever running (or waiting for) a job:

          ready             — state "ready" AND master + every variant
                              playlist exist (servable NOW);
          running           — a live background preparation task exists
                              for this identity (or the persisted state
                              says "running" — a stale RUNNING row from a
                              crashed process still counts here; the START
                              path wipes and redoes it through ensure_hls);
          failed            — state "failed" (backoff_remaining_s > 0
                              while inside the retry window);
          backoff_remaining — seconds until a retry is allowed (0 when
                              ready/running/none);
          dir/master/variants — the servable tree coordinates (only
                              meaningful when ready=True).

        PURE READ: no locks taken, no state mutated, never raises (a disk
        error degrades to the honest "none" snapshot).
        """
        out: Dict[str, Any] = {"ready": False, "running": False,
                               "failed": False, "backoff_remaining_s": 0.0,
                               "dir": None, "master": None, "variants": []}
        try:
            digest = _digest(file_unique_id)
            entry_dir = self._entry_dir(file_unique_id)
            task = self._prepare_tasks.get(digest)
            if task is not None and not task.done():
                out["running"] = True
            state = await self._read_state(entry_dir)
            if state is not None:
                status = str(state.get("status") or "")
                variants = list(state.get("variants") or [])
                if status == STATE_READY:
                    if self._outputs_complete(entry_dir, variants):
                        out["ready"] = True
                        out["dir"] = entry_dir
                        out["master"] = MASTER_PLAYLIST_NAME
                        out["variants"] = variants
                    # ready-state with missing outputs: NOT ready (the
                    # start path wipes + redoes through ensure_hls).
                elif status == STATE_FAILED:
                    out["failed"] = True
                    age = time.time() - float(state.get("ts") or 0.0)
                    backoff = self._failed_backoff_seconds(state)
                    out["backoff_remaining_s"] = max(
                        0.0, backoff - age) if 0.0 <= age < backoff else 0.0
                elif status == STATE_RUNNING and not out["running"]:
                    out["running"] = True  # persisted running row
        except Exception:  # noqa: BLE001 — snapshot is a pure read
            pass
        return out

    async def start_hls_preparation(self, file_unique_id: str,
                                    source_path_fn: SourcePathFn
                                    ) -> Dict[str, Any]:
        """TASK C1 — START (or JOIN) the coalesced background preparation.

        Returns ``{"started": bool, "already_live": bool}``:
          * a LIVE task for this identity already exists → ``started=False,
            already_live=True`` (COALESCED — the concurrent request shares
            the ONE running job; no duplicate ffmpeg process);
          * otherwise a NEW background task is spawned → ``started=True``.

        The job itself is the EXISTING ``ensure_hls`` machinery (cache hit
        fast-path, wipe-and-redo, failure backoff, semaphore bounding) —
        nothing about the transcoding semantics changes, only WHO waits:
        the browser request returns immediately with an honest
        503 hls_preparing while the job runs in the background.

        Telemetry (TASK C2): HLS_PREPARE_START / HLS_PREPARE_READY /
        HLS_PREPARE_FAILED (safe fields only — the hashed entry id, the
        elapsed time, the classified error head; never paths with user
        data, never tokens).
        """
        digest = _digest(file_unique_id)
        async with self._prepare_guard:
            task = self._prepare_tasks.get(digest)
            if task is not None and not task.done():
                self.stats_prepare_coalesced += 1
                return {"started": False, "already_live": True}
            new_task = asyncio.create_task(
                self._prepare_job(file_unique_id, source_path_fn))
            self._prepare_tasks[digest] = new_task
            self.stats_prepare_started += 1
            return {"started": True, "already_live": False}

    async def _prepare_job(self, file_unique_id: str,
                           source_path_fn: SourcePathFn) -> TranscodeResult:
        """The background preparation body (ONE per identity at a time)."""
        digest = _digest(file_unique_id)
        started = time.monotonic()
        _site_logger.info("HLS_PREPARE_START entry=%s", digest)
        try:
            result = await self.ensure_hls(file_unique_id, source_path_fn)
            elapsed = time.monotonic() - started
            if result.ok:
                _site_logger.info("HLS_PREPARE_READY entry=%s elapsed=%.1fs "
                            "variants=%s", digest, elapsed,
                            ",".join(str((v or {}).get("id") or "")
                                     for v in (result.variants or [])))
            else:
                _reason = str(result.error or "")[:80] or "unknown"
                _site_logger.warning("HLS_PREPARE_FAILED entry=%s elapsed=%.1fs "
                                   "error=%s", digest, elapsed, _reason)
            return result
        except Exception as e:  # noqa: BLE001 — the job itself never raises
            elapsed = time.monotonic() - started
            _site_logger.warning("HLS_PREPARE_FAILED entry=%s elapsed=%.1fs "
                               "error=%s:%s", digest, elapsed,
                               type(e).__name__, str(e)[:60])
            return TranscodeResult(ok=False, dir=None,
                                   error=f"prepare_error:"
                                         f"{type(e).__name__}",
                                   created=False)
        finally:
            async with self._prepare_guard:
                self._prepare_tasks.pop(digest, None)

    async def wait_for_preparation(self, file_unique_id: str,
                                   timeout: float = 120.0
                                   ) -> Optional[TranscodeResult]:
        """TEST/diagnostic helper: await the live preparation task (if any)
        for up to ``timeout`` seconds. Returns the task's TranscodeResult,
        or None when no live task exists / the timeout elapsed."""
        digest = _digest(file_unique_id)
        task = self._prepare_tasks.get(digest)
        if task is None:
            return None
        try:
            return await asyncio.wait_for(asyncio.shield(task), timeout)
        except asyncio.TimeoutError:
            return None

    async def _transcode(self, digest: str, entry_dir: Path,
                         source_path_fn: SourcePathFn,
                         attempts_seed: int = 0) -> TranscodeResult:
        self._running.add(digest)
        try:
            return await self._transcode_locked(digest, entry_dir,
                                                source_path_fn,
                                                attempts_seed)
        finally:
            self._running.discard(digest)

    async def _transcode_locked(self, digest: str, entry_dir: Path,
                                source_path_fn: SourcePathFn,
                                attempts_seed: int = 0
                                ) -> TranscodeResult:
        # ---- resolve the source (wiring-supplied, local only) -----------
        try:
            source_path = str(await source_path_fn())
        except Exception as e:  # noqa: BLE001 — honest failure classification
            return await self._fail(entry_dir, digest, None, 0,
                                    f"source_resolution_failed: "
                                    f"{type(e).__name__}: {e}",
                                    attempts_seed=attempts_seed)
        if not source_path or not os.path.isfile(source_path):
            return await self._fail(entry_dir, digest, None, 0,
                                    "source_file_missing",
                                    attempts_seed=attempts_seed)

        # ---- fresh probe (variant ladder needs the source height) -------
        probe = await probe_media(source_path,
                                  timeout=self.ffprobe_timeout)
        if not probe.has_video:
            return await self._fail(entry_dir, digest, None, 0,
                                    f"no_video_stream (vcodec="
                                    f"{probe.vcodec})",
                                    attempts_seed=attempts_seed)
        try:
            source_height = int(probe.height or 0)
        except (TypeError, ValueError):
            source_height = 0
        if source_height <= 0:
            return await self._fail(entry_dir, digest, None, 0,
                                    "unknown_video_height",
                                    attempts_seed=attempts_seed)
        variants = variant_ladder(source_height,
                                  max_variants=self.max_variants)
        try:
            source_size = os.path.getsize(source_path)
        except OSError:
            source_size = 0

        # ---- mark running + run the verified ffmpeg invocation ----------
        await self._write_state(entry_dir, {
            "status": STATE_RUNNING,
            "ts": time.time(),
            "source_size": source_size,
            "variants": variants,
            "attempts": int(attempts_seed),
        })
        cmd = build_ffmpeg_hls_command(
            source_path, entry_dir, variants,
            segment_seconds=self.segment_seconds,
            has_audio=bool(probe.has_audio))
        logger.info("MEDIA_TRANSCODE_START entry=%s variants=%s "
                    "segment_seconds=%s has_audio=%s source_size=%s",
                    digest, ",".join(v["id"] for v in variants),
                    self.segment_seconds, probe.has_audio, source_size)
        self.stats_runs += 1
        started = time.monotonic()
        rc, err_tail = await self._run_ffmpeg(cmd, self.ffmpeg_timeout)
        elapsed = time.monotonic() - started

        if rc != 0:
            detail = (f"ffmpeg_exit_{rc}: {err_tail[:_STDERR_ERROR_CHARS]}"
                      if err_tail else f"ffmpeg_exit_{rc}")
            return await self._fail(entry_dir, digest, variants,
                                    source_size, detail, elapsed=elapsed,
                                    attempts_seed=attempts_seed)
        if not self._outputs_complete(entry_dir, variants):
            return await self._fail(entry_dir, digest, variants,
                                    source_size, "incomplete_output",
                                    elapsed=elapsed,
                                    attempts_seed=attempts_seed)

        # ---- success: persist ready state with honest size accounting ---
        total_bytes = await self._dir_size(entry_dir)
        await self._write_state(entry_dir, {
            "status": STATE_READY,
            "ts": time.time(),
            "source_size": source_size,
            "hls_bytes": total_bytes,
            "variants": variants,
        })
        logger.info("MEDIA_TRANSCODE_COMPLETE entry=%s elapsed=%.1fs "
                    "hls_bytes=%s source_size=%s variants=%s",
                    digest, elapsed, total_bytes, source_size,
                    ",".join(v["id"] for v in variants))
        return TranscodeResult(ok=True, dir=entry_dir,
                               master=MASTER_PLAYLIST_NAME,
                               variants=variants, error=None, created=True)

    async def _fail(self, entry_dir: Path, digest: str,
                    variants: Optional[List[Dict[str, Any]]],
                    source_size: int, error: str, *,
                    elapsed: float = 0.0,
                    attempts_seed: int = 0) -> TranscodeResult:
        """Record an honest failed state (attempts counter drives the
        exponential-ish retry backoff — the seed survives the pre-retry
        wipe so repeated failures back off harder) and return the
        failure result."""
        self.stats_failures += 1
        prev = await self._read_state(entry_dir) or {}
        try:
            prev_attempts = int(prev.get("attempts") or 0)
        except (TypeError, ValueError):
            prev_attempts = 0
        attempts = max(int(attempts_seed), prev_attempts) + 1
        await self._write_state(entry_dir, {
            "status": STATE_FAILED,
            "ts": time.time(),
            "source_size": source_size,
            "variants": variants or [],
            "attempts": attempts,
            "error": str(error or "")[:_STDERR_ERROR_CHARS],
        })
        logger.warning("MEDIA_TRANSCODE_FAILED entry=%s elapsed=%.1fs "
                       "error=%s", digest, elapsed,
                       str(error or "")[:_STDERR_ERROR_CHARS])
        return TranscodeResult(ok=False, dir=None, error=str(error),
                               created=False)

    async def _run_ffmpeg(self, cmd: List[str],
                          timeout: float) -> Tuple[int, str]:
        """Run one ffmpeg argv with a BOUNDED stderr tail and process-group
        kill on timeout. Returns (returncode, stderr_tail_text)."""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True)
        except (OSError, FileNotFoundError, ValueError) as e:
            return 127, f"spawn_failed: {type(e).__name__}"
        tail = bytearray()

        async def _drain() -> None:
            assert proc.stderr is not None
            try:
                while True:
                    chunk = await proc.stderr.read(4096)
                    if not chunk:
                        break
                    tail.extend(chunk)
                    if len(tail) > _STDERR_TAIL_BYTES:
                        del tail[:-_STDERR_TAIL_BYTES]
            except Exception:  # noqa: BLE001 — drain must never raise
                pass

        drain_task = asyncio.create_task(_drain())
        try:
            try:
                rc = await asyncio.wait_for(proc.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                self._kill_group(proc)
                try:
                    await asyncio.wait_for(proc.wait(), timeout=30.0)
                except Exception:  # noqa: BLE001 — killed process
                    pass
                try:
                    await asyncio.wait_for(drain_task, timeout=5.0)
                except Exception:  # noqa: BLE001
                    drain_task.cancel()
                return -9, (f"timeout after {int(timeout)}s — process "
                            "group killed")
        finally:
            if not drain_task.done():
                drain_task.cancel()
        try:
            await drain_task
        except Exception:  # noqa: BLE001 — drained or cancelled
            pass
        try:
            text = bytes(tail).decode("utf-8", "replace").strip()
        except Exception:  # noqa: BLE001 — decode is already replace-mode
            text = ""
        return int(proc.returncode if proc.returncode is not None else -1), \
            text

    @staticmethod
    def _kill_group(proc: "asyncio.subprocess.Process") -> None:
        """Kill the whole process group (start_new_session makes ffmpeg
        its own group leader — children die with it)."""
        try:
            pgid = os.getpgid(proc.pid)
        except (ProcessLookupError, PermissionError, OSError):
            pgid = None
        try:
            if pgid is not None:
                os.killpg(pgid, signal.SIGKILL)
            else:
                proc.kill()
        except (ProcessLookupError, PermissionError, OSError):
            pass  # already dead

    @staticmethod
    async def _dir_size(path: Path) -> int:
        def _size() -> int:
            total = 0
            for root, _dirs, files in os.walk(path):
                for name in files:
                    try:
                        total += os.path.getsize(
                            os.path.join(root, name))
                    except OSError:
                        pass
            return total
        try:
            return await asyncio.to_thread(_size)
        except Exception:  # noqa: BLE001 — accounting only
            return 0

    # ------------------------------------------------------------ cleanup
    async def cleanup(self, *, max_age_seconds: Optional[float] = None
                      ) -> int:
        """Remove HLS entries older than the retention window.

        An entry's age is its NEWEST file mtime (a rendered tree stays
        alive while anything in it is fresh). Entries whose state.json
        says "running", or whose digest is tracked in-memory as running,
        are SKIPPED (best-effort reader safety — the StreamCache
        active-reader discipline adapted to jobs). Returns the removed
        entry count. Never raises.
        """
        retention = self.hls_retention if max_age_seconds is None \
            else float(max_age_seconds)
        hls_root = Path(self.cache_root) / "hls"

        def _list_entries() -> List[str]:
            try:
                return [e for e in os.listdir(hls_root)
                        if os.path.isdir(os.path.join(hls_root, e))]
            except OSError:
                return []

        try:
            names = await asyncio.to_thread(_list_entries)
        except Exception:  # noqa: BLE001 — cleanup never raises
            return 0
        removed = 0
        for name in names:
            if name in self._running:
                continue
            entry_dir = hls_root / name
            state = await self._read_state(entry_dir)
            if state is not None \
                    and str(state.get("status") or "") == STATE_RUNNING:
                continue  # possibly a live job: skip (best effort)

            def _stale(entry: Path = entry_dir) -> Optional[float]:
                newest = None
                for root, _dirs, files in os.walk(entry):
                    for fname in files:
                        try:
                            mtime = os.path.getmtime(
                                os.path.join(root, fname))
                        except OSError:
                            continue
                        if newest is None or mtime > newest:
                            newest = mtime
                return newest

            try:
                newest = await asyncio.to_thread(_stale)
            except Exception:  # noqa: BLE001 — skip unreadable entries
                newest = None
            if newest is None:
                continue  # empty/unreadable: leave for the next sweep
            if time.time() - newest <= retention:
                continue
            await self._wipe(entry_dir)
            removed += 1
        if removed:
            logger.info("MEDIA_TRANSCODE_CLEANUP removed=%s "
                        "retention=%ss", removed, int(retention))
        return removed

    def stats(self) -> Dict[str, Any]:
        """Honest manager stats (disk-walked, so restarts are accounted)."""
        hls_root = Path(self.cache_root) / "hls"

        def _walk() -> Tuple[int, int]:
            entries = 0
            total = 0
            try:
                for name in os.listdir(hls_root):
                    p = hls_root / name
                    if not os.path.isdir(p):
                        continue
                    entries += 1
                    for root, _dirs, files in os.walk(p):
                        for fname in files:
                            try:
                                total += os.path.getsize(
                                    os.path.join(root, fname))
                            except OSError:
                                pass
            except OSError:
                pass
            return entries, total

        try:
            entries, total = _walk()
        except Exception:  # noqa: BLE001 — accounting only
            entries, total = 0, 0
        return {
            "entries": entries,
            "bytes": total,
            "running": len(self._running),
            "runs": self.stats_runs,
            "failures": self.stats_failures,
            "cache_hits": self.stats_cache_hits,
            "wipes": self.stats_wipes,
            "cache_root": self.cache_root,
        }

    async def stop(self) -> None:
        """Stop accepting NEW jobs. In-flight jobs are NEVER killed
        mid-await (a half-killed ffmpeg tree would just produce a partial
        entry that the next ensure_hls call wipes honestly); they finish
        and record their final state as usual. Only the tracking of new
        work is cancelled."""
        self._stopped = True
        logger.info("MEDIA_TRANSCODE_STOPPED in_flight=%s",
                    len(self._running))


# ------------------------------------------------------------- singleton
# Lazy module-level singleton (the container wiring pattern mirrored from
# StreamCache: env override first, then the DATABASE_FILE directory — the
# same disk neighborhood as the media cache, overridable for deployments).
_MANAGER_SINGLETON: Optional[TranscodeManager] = None
_MANAGER_THREAD_LOCK = threading.Lock()


def default_transcode_root() -> str:
    """MEDIA_TRANSCODE_ROOT env override, else ``<DATABASE_FILE dir>/
    media_transcode``, else ``media_transcode`` (cwd) — mirroring the
    StreamCache cache-root convention (container.py + EnvDefaults).

    BOT-16 RULE F: the env parsing itself is CENTRALIZED in
    app/bootstrap/config.py (EnvDefaults.media_transcode_root /
    .database_file) — this module contains ZERO os.environ reads."""
    from app.bootstrap.config import EnvDefaults
    try:
        env = EnvDefaults.from_env()
    except Exception:  # noqa: BLE001 — honest cwd fallback
        env = None
    env_root = (getattr(env, "media_transcode_root", "") or "").strip()
    if env_root:
        return env_root
    db_file = (getattr(env, "database_file", "") or "").strip()
    if db_file:
        return os.path.join(
            os.path.dirname(os.path.abspath(db_file)), "media_transcode")
    return "media_transcode"


def get_transcode_manager(cache_root: Optional[str] = None
                          ) -> TranscodeManager:
    """The process-wide TranscodeManager (lazy-init). ``cache_root=None``
    uses :func:`default_transcode_root`; an explicit root creates a
    MANAGED instance (tests / multi-root deployments) without replacing
    the singleton."""
    global _MANAGER_SINGLETON
    with _MANAGER_THREAD_LOCK:
        if cache_root is None:
            if _MANAGER_SINGLETON is None:
                _MANAGER_SINGLETON = TranscodeManager(
                    default_transcode_root())
            return _MANAGER_SINGLETON
        return TranscodeManager(str(cache_root))


__all__ = [
    "TranscodeManager", "TranscodeResult", "variant_ladder",
    "build_ffmpeg_hls_command", "get_transcode_manager",
    "default_transcode_root", "LADDER_LEVELS", "LADDER_BANDWIDTHS",
    "LADDER_MAXRATES", "MASTER_PLAYLIST_NAME", "VARIANT_PLAYLIST_NAME",
    "STATE_READY", "STATE_FAILED", "STATE_RUNNING",
    "FAILED_RETRY_BASE_SECONDS", "FAILED_RETRY_MAX_SECONDS",
]
