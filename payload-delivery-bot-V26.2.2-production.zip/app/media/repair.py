"""Media file-id repair service (WEBSITE PHASE 1).

Mirrors the PROVEN Phase 7 hotfix recovery contract
(bot.py:_recover_file_id_from_source) for the media layer:

  old file_id → upstream rejection → source_channel_id + source_message_id
    → internal fetch (copy/forward into an ADMIN chat, immediately deleted,
      NEVER user-visible — therefore hide_delivery_source CANNOT and MUST
      NOT block it) → identity discipline → ATOMIC in-place file_id repair
      (db.repair_indexed_file_file_id) → the caller retries ONCE.

Identity discipline (identical to the delivery engine):
  * the recovered media's file_unique_id must match the stored one (or, for
    NULL-identity rows, must not belong to a DIFFERENT row) and the media
    type must match — otherwise the source message now hosts a different
    file and the canonical record is left UNTOUCHED (no repair).
  * ONLY the file_id column is repaired; the canonical row (pk, source
    refs, payload references) is always preserved.

This module imports NOTHING from bot.py: the Telegram transport
(fetch_source_media / delete_message) and the admin-chat resolver are
INJECTED (production wiring binds bot.py's fetch_channel_media etc. at
call time; tests bind fakes).

Log vocabulary (spec §44): DELIVERY_SOURCE_RECOVERY /
DELIVERY_FILE_ID_REPAIRED / DELIVERY_RECOVERY_FAILED (new code paths use
the spec names; bot.py's frozen BOT6_* logs stay untouched).
"""
from __future__ import annotations

import hashlib
import logging
from types import SimpleNamespace
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

from app.storage.dbutil import safe_row_get as _safe_row_get

logger = logging.getLogger("payload-bot")


def redact_file_id(fid) -> str:
    """PHASE 5 secret hygiene: file_id values NEVER enter logs verbatim.

    A Telegram file_id together with the bot token is a download
    capability, and operational logs are typically less protected than
    the database — so repair events now log a correlation fingerprint
    (first 8 hex of SHA-256) + length: enough to correlate events for the
    SAME reference across lines, never enough to use it. Identity stays
    observable through file_unique_id (safe — it is not an API
    credential)."""
    try:
        s = str(fid)
    except Exception:  # noqa: BLE001
        return "(?)"
    if fid is None or not s:
        return "(?)" if fid is None else "(none)"
    digest = hashlib.sha256(s.encode("utf-8")).hexdigest()[:8]
    return f"#{digest}(len={len(s)})"

# async (admin_chat_id, channel_id, message_id) -> (media_info | None,
#                                                   temp_message_id | None)
FetchSourceMedia = Callable[[int, int, int],
                             Awaitable[Tuple[Optional[Dict[str, Any]],
                                             Optional[int]]]]
# async () -> Optional[int]  (owner/first-active-admin chat)
AdminChatResolver = Callable[[], Awaitable[Optional[int]]]
# async (chat_id, message_id) -> None  (best-effort temp cleanup)
DeleteMessage = Callable[[int, int], Awaitable[None]]


def make_media_repair_service(db: Any, *,
                              fetch_source_media: FetchSourceMedia,
                              resolve_admin_chat_id: AdminChatResolver,
                              delete_message: Optional[DeleteMessage] = None):
    """Bind the recovery implementation to explicit dependencies
    (call-time late binding — the established service pattern)."""

    async def repair(handle) -> Optional[Dict[str, Any]]:
        """Recover a fresh file_id for the handle's identity from the source
        message and atomically repair the canonical row.

        Returns the fresh media info dict on success (DB already repaired),
        else None (every failure is logged; NEVER raises).
        """
        try:
            row = await db.get_indexed_file_by_unique_id(
                str(handle.file_unique_id))
            if row is None:
                logger.error(
                    "DELIVERY_RECOVERY_FAILED file_unique_id=%s "
                    "reason=row_missing (canonical record not found)",
                    handle.file_unique_id)
                return None
            file_pk = _safe_row_get(row, "id")
            src_channel = _safe_row_get(row, "channel_id")
            src_msg = _safe_row_get(row, "message_id")
            stored_unique = _safe_row_get(row, "file_unique_id")
            stored_type = _safe_row_get(row, "media_type")
            if file_pk is None or src_channel is None or src_msg is None:
                logger.error(
                    "DELIVERY_RECOVERY_FAILED file_pk=%s reason="
                    "missing_source_ref (cannot recover)", file_pk)
                return None

            admin_chat = await resolve_admin_chat_id()
            if not admin_chat:
                logger.error(
                    "DELIVERY_RECOVERY_FAILED file_pk=%s reason=no_admin_chat "
                    "(no internal fetch target available)", file_pk)
                return None

            logger.info(
                "DELIVERY_SOURCE_RECOVERY file_pk=%s channel_id=%s "
                "message_id=%s admin_chat=%s result=started reason=file_id_stale"
                " hide_source_bypassed=True (internal fetch — never "
                "user-visible)", file_pk, src_channel, src_msg, admin_chat)

            info, temp_mid = await fetch_source_media(
                int(admin_chat), int(src_channel), int(src_msg))
            if delete_message is not None and temp_mid:
                try:
                    await delete_message(int(admin_chat), int(temp_mid))
                except Exception:  # noqa: BLE001 — best-effort cleanup
                    pass
            if not info or not info.get("file_id"):
                logger.error(
                    "DELIVERY_SOURCE_RECOVERY file_pk=%s channel_id=%s "
                    "message_id=%s result=failed reason=source_fetch_failed "
                    "(message deleted / inaccessible)",
                    file_pk, src_channel, src_msg)
                return None

            # --- identity discipline: same file or NO repair ---
            fresh_unique = info.get("file_unique_id")
            if stored_unique and fresh_unique != stored_unique:
                logger.error(
                    "DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                    "reason=identity_mismatch stored_unique_id=%s "
                    "fresh_unique_id=%s (source message now hosts a DIFFERENT "
                    "file — canonical record NOT modified)",
                    file_pk, stored_unique, fresh_unique)
                return None
            if not stored_unique and fresh_unique:
                other = await db.get_indexed_file_by_unique_id(fresh_unique)
                if other is not None and _safe_row_get(other, "id") is not None \
                        and int(_safe_row_get(other, "id")) != int(file_pk):
                    logger.error(
                        "DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                        "reason=identity_conflict fresh_unique_id=%s "
                        "belongs_to=%s (different canonical row — NOT "
                        "modified)",
                        file_pk, fresh_unique, _safe_row_get(other, "id"))
                    return None
            if info.get("media_type") != stored_type:
                logger.error(
                    "DELIVERY_SOURCE_RECOVERY file_pk=%s result=failed "
                    "reason=media_type_mismatch stored=%s fresh=%s (canonical "
                    "record NOT modified)",
                    file_pk, stored_type, info.get("media_type"))
                return None

            # --- atomic repair of the canonical row's file_id ONLY ---
            repaired = await db.repair_indexed_file_file_id(
                int(file_pk), str(info["file_id"]))
            if repaired:
                logger.info(
                    "DELIVERY_FILE_ID_REPAIRED file_pk=%s result=ok "
                    "old_file_id=%s new_file_id=%s atomic=True "
                    "canonical_row_preserved=True source_ref_unchanged=%s/%s",
                    file_pk, redact_file_id(_safe_row_get(row, "file_id")),
                    redact_file_id(info["file_id"]), src_channel, src_msg)
            else:
                logger.info(
                    "DELIVERY_FILE_ID_REPAIRED file_pk=%s "
                    "result=already_current (stored==fresh; identity verified "
                    "against source)", file_pk)
            return info
        except Exception as e:  # noqa: BLE001 — recovery never raises
            logger.error(
                "DELIVERY_RECOVERY_FAILED file_unique_id=%s reason=exception "
                "exc=%s.%s", getattr(handle, "file_unique_id", "?"),
                type(e).__module__, type(e).__name__)
            return None

    async def repair_missing_identities(self, limit: int = 50) -> Dict[str, Any]:
        """V26.2 (bot-41 §5/§6): deterministic, bounded repair pass over
        canonical indexed rows whose Telegram media identity
        (file_unique_id) is NULL/empty — the ``file_unique_id=-`` shape
        that makes a payload honestly unstreamable.

        Discipline (spec §6 — never invent an identity):
          * for every affected row the AUTHORITATIVE metadata is fetched
            from its OWN (channel_id, message_id) through the EXISTING
            Telegram transport (the same injected fetch_source_media the
            file-id repair uses — copy into an admin chat, immediately
            deleted, never user-visible);
          * the fresh identity is conflict-checked (must not belong to a
            DIFFERENT row) and media_type-checked;
          * only then the guarded db.repair_indexed_file_identity fills
            the missing column — pk/source refs/payload references are
            always preserved, an existing identity is never overwritten;
          * transport unavailable (no admin chat / fetch failure) is
            reported honestly — rows stay flagged missing, nothing is
            fabricated and the file is never falsely marked streamable.
        Returns a report dict (counts + per-row safe reasons). NEVER raises.
        """
        report: Dict[str, Any] = {
            "scanned": 0, "repaired": 0, "already": 0, "failed": 0,
            "skipped": 0, "rows": []}
        try:
            rows = await db.list_indexed_files_missing_identity(int(limit))
        except Exception:  # noqa: BLE001 — honest empty report
            logger.error("IDENTITY_REPAIR_FAILED reason=scan_error",
                         exc_info=True)
            return report
        report["scanned"] = len(rows)
        for row in rows:
            file_pk = _safe_row_get(row, "id")
            src_channel = _safe_row_get(row, "channel_id")
            src_msg = _safe_row_get(row, "message_id")
            stored_type = _safe_row_get(row, "media_type")
            entry = {"file_pk": file_pk, "channel_id": src_channel,
                     "message_id": src_msg, "result": ""}
            if file_pk is None or src_channel is None or src_msg is None:
                entry["result"] = "missing_source_ref"
                report["skipped"] += 1
                report["rows"].append(entry)
                continue
            try:
                admin_chat = await resolve_admin_chat_id()
                if not admin_chat:
                    entry["result"] = "no_admin_chat"
                    report["skipped"] += 1
                    report["rows"].append(entry)
                    logger.error(
                        "IDENTITY_REPAIR_FAILED file_pk=%s reason="
                        "no_admin_chat (transport unavailable — row left "
                        "honestly unstreamable)", file_pk)
                    continue
                info, temp_mid = await fetch_source_media(
                    int(admin_chat), int(src_channel), int(src_msg))
                if delete_message is not None and temp_mid:
                    try:
                        await delete_message(int(admin_chat), int(temp_mid))
                    except Exception:  # noqa: BLE001 — best-effort cleanup
                        pass
                fresh_unique = str(
                    (info or {}).get("file_unique_id") or "").strip()
                if not fresh_unique:
                    entry["result"] = "source_fetch_failed"
                    report["failed"] += 1
                    report["rows"].append(entry)
                    logger.error(
                        "IDENTITY_REPAIR_FAILED file_pk=%s channel_id=%s "
                        "message_id=%s reason=source_fetch_failed (message "
                        "deleted / inaccessible — identity NOT fabricated)",
                        file_pk, src_channel, src_msg)
                    continue
                # --- conflict discipline: never steal another row's identity
                other = await db.get_indexed_file_by_unique_id(fresh_unique)
                if other is not None and _safe_row_get(other, "id") is not None \
                        and int(_safe_row_get(other, "id")) != int(file_pk):
                    entry["result"] = "identity_conflict"
                    report["failed"] += 1
                    report["rows"].append(entry)
                    logger.error(
                        "IDENTITY_REPAIR_FAILED file_pk=%s reason="
                        "identity_conflict fresh_unique_id=%s belongs_to=%s "
                        "(different canonical row — NOT modified)",
                        file_pk, fresh_unique[:16],
                        _safe_row_get(other, "id"))
                    continue
                if info.get("media_type") != stored_type:
                    entry["result"] = "media_type_mismatch"
                    report["failed"] += 1
                    report["rows"].append(entry)
                    logger.error(
                        "IDENTITY_REPAIR_FAILED file_pk=%s reason="
                        "media_type_mismatch stored=%s fresh=%s (row NOT "
                        "modified)", file_pk, stored_type,
                        info.get("media_type"))
                    continue
                status = await db.repair_indexed_file_identity(
                    int(file_pk), fresh_unique)
                entry["result"] = status
                if status == "repaired":
                    report["repaired"] += 1
                    logger.info(
                        "IDENTITY_REPAIRED file_pk=%s file_unique_id=%s "
                        "source=%s/%s guarded=True canonical_row_preserved="
                        "True", file_pk, fresh_unique[:16], src_channel,
                        src_msg)
                else:
                    report["already"] += 1
                report["rows"].append(entry)
            except Exception as e:  # noqa: BLE001 — per-row, never raises
                entry["result"] = "exception:%s" % type(e).__name__
                report["failed"] += 1
                report["rows"].append(entry)
                logger.error(
                    "IDENTITY_REPAIR_FAILED file_pk=%s reason=exception "
                    "exc=%s.%s", file_pk, type(e).__module__,
                    type(e).__name__)
        logger.info(
            "IDENTITY_REPAIR_SUMMARY scanned=%s repaired=%s already=%s "
            "failed=%s skipped=%s", report["scanned"], report["repaired"],
            report["already"], report["failed"], report["skipped"])
        return report

    return SimpleNamespace(
        repair=repair,
        repair_missing_identities=repair_missing_identities,
        __doc__="File-id recovery + atomic repair (Phase 7 semantics; "
                "V26.2 adds the guarded identity backfill).",
    )
