"""BOT-16 MKV/HEVC browser-compatibility pipeline — the ffprobe verdict layer.

PRODUCTION FAILURE (bot-16.log, Task 14 root cause #3): an MKV/HEVC video
was streamed to the browser as raw Telegram bytes with
``video/x-matroska``; the browser answered ``MEDIA_ERR_SRC_NOT_SUPPORTED``
("Cannot play in this browser"). There was ZERO codec detection anywhere in
the codebase (grep ffprobe/hevc/h265 = 0 hits before this module).

This module is the detection half of the fix:

  * :func:`probe_media` — run the REAL ``ffprobe`` (7.1.5 on PATH) against
    a LOCAL file via ``asyncio.subprocess`` and parse container/codec/
    geometry facts. NEVER raises: any failure (binary missing, timeout,
    non-zero exit, unparseable JSON) returns an "unknown" probe that the
    classifier maps to the honest ERROR verdict — never a fabricated
    "compatible" verdict that would replay the production incident.
  * :func:`classify_browser_compatibility` — a PURE, data-driven verdict:
    ``(direct | transcode | unsupported | error, reason)``. The tables are
    module-level dicts so tests can enumerate every rule. The verdict is
    deliberately CONSERVATIVE: a codec/container combination that is only
    *sometimes* playable (mkv+h264 — Chrome plays it, Safari/Firefox do
    not guarantee it) classifies as TRANSCODE, never DIRECT. A false
    "transcode" costs one remux; a false "direct" costs the production
    "Cannot play" incident again.
  * :func:`cached_probe` — a JSON disk cache of probe results keyed by
    ``file_unique_id`` (the canonical media identity — the same
    :mod:`app.media.cachekeys` discipline as the StreamCache: a repaired
    ``file_id`` never changes the identity, so the probe verdict stays
    valid across repairs). TTL-bounded, best-effort, never raises.

Verdict constants are importable strings (no enum indirection — the wiring
layer compares them directly):

  PROBE_VERDICT_DIRECT      "direct"       — serve the original bytes
  PROBE_VERDICT_TRANSCODE   "transcode"    — route through HLS (this repo's
                                             app/media/transcode.py)
  PROBE_VERDICT_UNSUPPORTED "unsupported"  — no video stream at all
  PROBE_VERDICT_ERROR       "error"        — probe could not run / parse

Secrets discipline: the ffprobe argv contains only a LOCAL file path and
flag strings — never a bot token, never a Telegram URL. Log lines cite the
media identity (file_unique_id), never path contents beyond what is needed
for the failure classification.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("app.media.probe")

# ------------------------------------------------------------------ verdicts
PROBE_VERDICT_DIRECT = "direct"
PROBE_VERDICT_TRANSCODE = "transcode"
PROBE_VERDICT_UNSUPPORTED = "unsupported"
PROBE_VERDICT_ERROR = "error"

# Sentinel codecs/containers for probes that could not be taken at all.
UNKNOWN = "unknown"

# ------------------------------------------------------- classification tables
# DATA-DRIVEN compatibility tables (BOT-16): enumerate these in tests.
#
# Video codecs that EVERY mainstream browser (Chrome/Edge/Firefox/Safari,
# desktop+mobile) decodes in a progressively-served container. h264 is the
# only member — HEVC hardware support is fragmented (Safari yes, Chrome
# desktop only with hw, Firefox no), VP9/AV1 are fine in WebM but the
# direct-serve surface here is MP4-first; anything else transcodes.
BROWSER_SAFE_VIDEO_CODECS = frozenset({"h264"})

# Audio codecs that are safe in ANY direct container.
BROWSER_SAFE_AUDIO_CODECS = frozenset({"aac", "mp3"})

# Audio codecs that are safe ONLY inside WebM (the WebM codec family).
BROWSER_WEBM_AUDIO_CODECS = frozenset({"opus", "vorbis"})

# Containers that can be served as raw bytes given safe codecs above.
# NOTE: "mp4" here is the NORMALIZED container — ffprobe reports
# "mov,mp4,m4v,3gp,3g2,mjf" as one format_name for the whole QuickTime/MP4
# family, and browsers treat them identically for h264+aac. Matroska is
# deliberately absent (see _CONTAINER_REASONS).
BROWSER_SAFE_CONTAINERS = frozenset({"mp4", "webm"})

# Per-codec TRANSCODE reasons (video). Codecs absent from the table get the
# generic "<codec>_video_codec" reason — honest and enumerable.
_VIDEO_CODEC_REASONS: Dict[str, str] = {
    "hevc": "hevc_video_codec",
    "h265": "hevc_video_codec",
}

# Per-container TRANSCODE reasons. Matroska with h264+aac is the classic
# "Chrome sometimes plays it" case: the honest verdict is REMUX-level
# transcode (reason matroska_container_remux) — the HLS pipeline handles
# it with the same machinery as a full transcode.
_CONTAINER_REASONS: Dict[str, str] = {
    "matroska": "matroska_container_remux",
}

# The direct verdict reason (spec BOT-16).
_REASON_BROWSER_COMPATIBLE = "browser_compatible"
# The unsupported verdict reason (no video stream).
_REASON_NO_VIDEO = "no_video_stream"
# The error verdict reason (probe could not run at all).
_REASON_PROBE_UNAVAILABLE = "probe_unavailable"

# ffprobe JSON cache layout: <cache_root>/probe/<sha256(file_unique_id)>.json
_PROBE_SUBDIR = "probe"


# --------------------------------------------------------------------- model
@dataclass
class MediaProbe:
    """The normalized ffprobe verdict for one media file.

    ``container``/``vcodec``/``acodec`` are normalized lowercase names
    ("mp4", "matroska", "webm", "h264", "hevc", "aac", ...). A probe that
    could not be taken carries ``UNKNOWN`` codecs and ``has_video=False``
    — :func:`classify_browser_compatibility` maps that to the ERROR
    verdict (never to "direct").
    """

    container: str = UNKNOWN
    vcodec: str = UNKNOWN
    acodec: str = UNKNOWN
    width: Optional[int] = None
    height: Optional[int] = None
    duration: Optional[float] = None
    bitrate_kbps: Optional[int] = None
    has_video: bool = False
    has_audio: bool = False
    raw: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """JSON-serializable form (cached_probe disk format)."""
        return {
            "container": self.container,
            "vcodec": self.vcodec,
            "acodec": self.acodec,
            "width": self.width,
            "height": self.height,
            "duration": self.duration,
            "bitrate_kbps": self.bitrate_kbps,
            "has_video": self.has_video,
            "has_audio": self.has_audio,
            "raw": self.raw,
        }

    @classmethod
    def from_dict(cls, data: Any) -> "MediaProbe":
        """Parse a cached probe dict. NEVER raises; unparseable fields
        degrade to their "unknown" defaults (the classifier then answers
        the conservative verdict for the whole record)."""
        if not isinstance(data, dict):
            return cls()
        try:
            raw = data.get("raw") if isinstance(data.get("raw"), dict) \
                else {}
            duration = data.get("duration")
            bitrate = data.get("bitrate_kbps")
            return cls(
                container=str(data.get("container") or UNKNOWN),
                vcodec=str(data.get("vcodec") or UNKNOWN),
                acodec=str(data.get("acodec") or UNKNOWN),
                width=_opt_int(data.get("width")),
                height=_opt_int(data.get("height")),
                duration=float(duration)
                if duration is not None else None,
                bitrate_kbps=_opt_int(bitrate),
                has_video=bool(data.get("has_video")),
                has_audio=bool(data.get("has_audio")),
                raw=raw,
            )
        except (TypeError, ValueError):
            return cls()


def _opt_int(value: Any) -> Optional[int]:
    try:
        if value is None:
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _opt_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------ normalization
def _normalize_container(format_name: Any, path: str) -> str:
    """Normalize ffprobe's ``format_name`` into the classifier's container
    vocabulary.

    ffprobe reports COMBINED names: the QuickTime/MP4 family is one
    "mov,mp4,m4v,3gp,3g2,mjf" name, and Matroska/WebM share
    "matroska,webm" (a ``.webm`` file and an ``.mkv`` file are
    indistinguishable from format_name alone). The honest disambiguator
    for the shared Matroska name is the file EXTENSION; an extensionless
    cache blob (the StreamCache stores identity-hashed ``data`` files)
    conservatively resolves to "matroska" — the transcode verdict —
    because serving it raw is exactly the production failure this module
    exists to prevent.
    """
    names = [n.strip().lower()
             for n in str(format_name or "").split(",") if n.strip()]
    if not names:
        return UNKNOWN
    if "matroska" in names or "webm" in names:
        if "matroska" not in names:  # pure webm (rare but honest)
            return "webm"
        ext = os.path.splitext(str(path or ""))[1].lower()
        if ext == ".webm":
            return "webm"
        return "matroska"
    if "mp4" in names or "mov" in names or "m4v" in names \
            or "3gp" in names or "3g2" in names or "mjf" in names:
        return "mp4"
    if "mpegts" in names or "mpegtsraw" in names:
        return "mpegts"
    return names[0]


def _stream_disposition_flag(stream: Dict[str, Any], flag: str) -> bool:
    disposition = stream.get("disposition")
    if isinstance(disposition, dict):
        try:
            return bool(int(disposition.get(flag) or 0))
        except (TypeError, ValueError):
            return False
    return False


def _parse_probe_json(payload: bytes, path: str) -> MediaProbe:
    """ffprobe JSON -> MediaProbe (never raises; bad JSON -> unknown)."""
    try:
        doc = json.loads(payload.decode("utf-8", "replace"))
    except (ValueError, UnicodeDecodeError):
        return MediaProbe()
    if not isinstance(doc, dict):
        return MediaProbe()
    streams = doc.get("streams")
    streams = streams if isinstance(streams, list) else []
    fmt = doc.get("format") if isinstance(doc.get("format"), dict) else {}

    video = None
    audio = None
    for s in streams:
        if not isinstance(s, dict):
            continue
        ctype = str(s.get("codec_type") or "").lower()
        # attached_pic streams (mp3/cover-art mjpeg) are NOT video for
        # playback purposes — an audio file with cover art must classify
        # "unsupported", never "direct video".
        if ctype == "video" and video is None \
                and not _stream_disposition_flag(s, "attached_pic"):
            video = s
        elif ctype == "audio" and audio is None:
            audio = s

    duration = _opt_float(fmt.get("duration"))
    if duration is None:
        if video is not None:
            duration = _opt_float(video.get("duration"))
        if duration is None and audio is not None:
            duration = _opt_float(audio.get("duration"))
    bit_rate = _opt_float(fmt.get("bit_rate"))
    bitrate_kbps = int(round(bit_rate / 1000.0)) \
        if bit_rate is not None else None

    return MediaProbe(
        container=_normalize_container(fmt.get("format_name"), path),
        vcodec=str((video or {}).get("codec_name") or UNKNOWN).lower(),
        acodec=str((audio or {}).get("codec_name") or UNKNOWN).lower(),
        width=_opt_int((video or {}).get("width")),
        height=_opt_int((video or {}).get("height")),
        duration=duration,
        bitrate_kbps=bitrate_kbps,
        has_video=video is not None,
        has_audio=audio is not None,
        raw=doc,
    )


async def _kill_process_group(proc: "asyncio.subprocess.Process") -> None:
    """Kill the whole process group (ffprobe/ffmpeg never spawn children
    here, but the group kill is the disciplined shape)."""
    try:
        pgid = os.getpgid(proc.pid)
    except (ProcessLookupError, PermissionError, OSError):
        pgid = None
    try:
        if pgid is not None:
            os.killpg(pgid, 9)
        else:
            proc.kill()
    except (ProcessLookupError, PermissionError, OSError):
        pass


# ------------------------------------------------------------------- probing
async def probe_media(path: str, *, timeout: float = 20.0) -> MediaProbe:
    """Probe ONE local file with the real ffprobe binary.

    Command (spec BOT-16, verified against ffprobe 7.1.5):

        ffprobe -v quiet -print_format json -show_format -show_streams <p>

    NEVER raises. Failure modes (binary absent, timeout, non-zero exit,
    unparseable output) return the ``UNKNOWN`` probe whose classifier
    verdict is PROBE_VERDICT_ERROR — the caller falls back to the
    transcoding path, which is the conservative, production-safe answer.
    """
    path = str(path or "")
    if not path:
        return MediaProbe()
    argv = ["ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", path]
    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True)
    except (OSError, FileNotFoundError, ValueError) as e:
        logger.warning("MEDIA_PROBE_ERROR reason=spawn_failed detail=%s",
                       type(e).__name__)
        return MediaProbe()
    try:
        try:
            out, _err = await asyncio.wait_for(proc.communicate(),
                                               timeout=timeout)
        except asyncio.TimeoutError:
            await _kill_process_group(proc)
            try:
                await proc.wait()
            except Exception:  # noqa: BLE001 — already dead/killed
                pass
            logger.warning("MEDIA_PROBE_ERROR reason=timeout "
                           "timeout=%s path_tail=%s", timeout,
                           os.path.basename(path)[:80])
            return MediaProbe()
    finally:
        # communicate() closed the pipes on the success path; on the
        # killed path the subprocess transport reaps them with the
        # process. Nothing else to release here (no fd leak: the
        # child-side pipes die with the process group).
        pass
    if proc.returncode != 0:
        logger.warning("MEDIA_PROBE_ERROR reason=exit_%s path_tail=%s",
                       proc.returncode, os.path.basename(path)[:80])
        return MediaProbe()
    probe = _parse_probe_json(out, path)
    if probe.container == UNKNOWN and not probe.has_video \
            and not probe.has_audio:
        logger.warning("MEDIA_PROBE_ERROR reason=unparseable_output "
                       "path_tail=%s", os.path.basename(path)[:80])
        return MediaProbe()
    logger.info("MEDIA_PROBE_OK container=%s vcodec=%s acodec=%s "
                "size=%sx%s duration=%s", probe.container, probe.vcodec,
                probe.acodec, probe.width, probe.height, probe.duration)
    return probe


# --------------------------------------------------------------- classification
def classify_browser_compatibility(probe: MediaProbe) -> Tuple[str, str]:
    """Classify one probe into (verdict, reason) — PURE, total, never raises.

    Rule order (each rule cites its evidence in the reason):

      1. probe never taken (all-unknown)   -> error/probe_unavailable
         (a failed probe is NEVER misread as a real audio-only file)
      2. no video stream at all            -> unsupported/no_video_stream
      3. video codec outside the safe set  -> transcode/<codec>_video_codec
         (hevc/h265 -> the canonical hevc_video_codec reason)
      4. container outside the safe set    -> transcode/matroska_container_
         remux for Matroska (h264+aac in mkv: remux, do not trust Chrome's
         occasional mkv support), else transcode/unsupported_container
      5. audio codec outside the safe set
         for the container                -> transcode/unsupported_audio_codec
         (ac3/dts/flac/alac/... in mp4; opus/vorbis are fine ONLY in webm)
      6. everything safe                   -> direct/browser_compatible
    """
    try:
        vcodec = str(probe.vcodec or UNKNOWN).lower()
        acodec = str(probe.acodec or UNKNOWN).lower()
        container = str(probe.container or UNKNOWN).lower()
        has_audio = bool(probe.has_audio)

        # 1. ERROR: the probe itself failed (all-unknown world — ffprobe
        #    never produced facts). Serving raw bytes on an unknown codec
        #    is exactly the production incident; this must precede the
        #    no-video rule so a failed probe is never misread as a real
        #    audio-only container.
        if vcodec == UNKNOWN and container == UNKNOWN \
                and acodec == UNKNOWN:
            return PROBE_VERDICT_ERROR, _REASON_PROBE_UNAVAILABLE

        # 2. UNSUPPORTED: nothing a <video> element can play (a REAL
        #    probe of an audio-only/payload-less file — container and
        #    audio facts exist).
        if not probe.has_video:
            return PROBE_VERDICT_UNSUPPORTED, _REASON_NO_VIDEO

        # 3. Video codec gate — only h264 is universally decodable.
        if vcodec not in BROWSER_SAFE_VIDEO_CODECS:
            reason = _VIDEO_CODEC_REASONS.get(
                vcodec, f"{vcodec or 'unknown'}_video_codec")
            return PROBE_VERDICT_TRANSCODE, reason

        # 4. Container gate — matroska remux / unsupported containers.
        if container not in BROWSER_SAFE_CONTAINERS:
            reason = _CONTAINER_REASONS.get(
                container, "unsupported_container")
            return PROBE_VERDICT_TRANSCODE, reason

        # 5. Audio gate — silent video is fine; exotic audio is not.
        if has_audio and acodec != UNKNOWN:
            audio_ok = acodec in BROWSER_SAFE_AUDIO_CODECS
            if not audio_ok and container == "webm":
                audio_ok = acodec in BROWSER_WEBM_AUDIO_CODECS
            if not audio_ok:
                return PROBE_VERDICT_TRANSCODE, "unsupported_audio_codec"

        # 6. Safe to serve the original bytes.
        return PROBE_VERDICT_DIRECT, _REASON_BROWSER_COMPATIBLE
    except Exception:  # noqa: BLE001 — total function, honest fallback
        return PROBE_VERDICT_ERROR, "classifier_error"


# ------------------------------------------------------------------- caching
def probe_cache_path(cache_root: str, file_unique_id: str) -> Path:
    """Deterministic probe-cache JSON path for one media identity.

    ``<cache_root>/probe/<sha256(file_unique_id)>.json`` — the same
    traversal-proof hashed-identity layout as the StreamCache entry dirs
    (a hostile file_unique_id can never escape the probe subdir).
    """
    digest = hashlib.sha256(
        str(file_unique_id or "").encode("utf-8")).hexdigest()
    return Path(cache_root) / _PROBE_SUBDIR / f"{digest}.json"


async def cached_probe(cache_root: str, file_unique_id: str, path: str,
                       *, ttl: float = 86400.0) -> MediaProbe:
    """TTL-bounded disk cache of :func:`probe_media` per file_unique_id.

    Hit within TTL -> the parsed cached verdict (no ffprobe run). Miss /
    stale / corrupt -> a fresh probe, written through best-effort. NEVER
    raises: a cache read or write failure simply degrades to a direct
    probe (the cache is an optimization, never canonical — the StreamCache
    discipline). A cache HIT of a previously-failed probe (UNKNOWN world)
    is also honored: it honestly maps to the error verdict without
    re-spawning ffprobe storms against a broken file.
    """
    cache_file = probe_cache_path(cache_root, file_unique_id)

    def _read() -> Optional[MediaProbe]:
        try:
            with open(cache_file, "r", encoding="utf-8") as fh:
                doc = json.load(fh)
            if not isinstance(doc, dict):
                return None
            ts = float(doc.get("ts") or 0.0)
            if not (0.0 < ts <= time.time()) or (time.time() - ts) > ttl:
                return None  # absent/absurd/expired
            probe = MediaProbe.from_dict(doc.get("probe"))
            return probe
        except (OSError, ValueError, TypeError):
            return None

    try:
        hit = await asyncio.to_thread(_read)
    except Exception:  # noqa: BLE001 — cache must never break probing
        hit = None
    if hit is not None:
        return hit

    probe = await probe_media(path)

    def _write() -> None:
        try:
            os.makedirs(cache_file.parent, exist_ok=True)
            tmp = str(cache_file) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"ts": time.time(), "probe": probe.to_dict()},
                          fh)
            os.replace(tmp, str(cache_file))
        except OSError:
            pass  # best-effort write-through

    try:
        await asyncio.to_thread(_write)
    except Exception:  # noqa: BLE001 — best effort only
        pass
    return probe


__all__ = [
    "PROBE_VERDICT_DIRECT", "PROBE_VERDICT_TRANSCODE",
    "PROBE_VERDICT_UNSUPPORTED", "PROBE_VERDICT_ERROR",
    "MediaProbe", "probe_media", "classify_browser_compatibility",
    "probe_cache_path", "cached_probe",
    "BROWSER_SAFE_VIDEO_CODECS", "BROWSER_SAFE_AUDIO_CODECS",
    "BROWSER_WEBM_AUDIO_CODECS", "BROWSER_SAFE_CONTAINERS",
]
