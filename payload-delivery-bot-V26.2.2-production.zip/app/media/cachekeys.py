"""Cache identity discipline for the (future) shared media cache.

THE RULE (spec §20/§22, and the architecture-phase media boundary):

* ``file_unique_id`` is the CACHE IDENTITY — the bot-independent, dedup-grade
  identity of the media bytes. Cache keys are derived from it.
* ``file_id`` is NEVER a cache key: it is bot-scoped and transient. When a
  token change invalidates a stored file_id, the recovery path repairs the
  row IN PLACE (same file_unique_id) — so a cache keyed by file_unique_id
  stays VALID across the repair with zero invalidation logic, while a cache
  keyed by file_id would silently orphan its entries.
* Range entries extend the identity key with the byte window, never with
  bot-scoped references.

PURE module: no imports beyond typing.
"""
from __future__ import annotations

from typing import Optional


def cache_key(file_unique_id: str) -> str:
    """Canonical cache key for one media file's identity."""
    if not file_unique_id:
        raise ValueError("cache identity requires a non-empty file_unique_id")
    return f"media:{file_unique_id}"


def range_key(file_unique_id: str, start: int, end: Optional[int]) -> str:
    """Canonical cache key for one byte window of one media file.

    ``end`` is INCLUSIVE (HTTP Range semantics); ``None`` means open-ended
    (to EOF) and is rendered as ``*``.
    """
    if start < 0:
        raise ValueError("range start must be >= 0")
    if end is not None and end < start:
        raise ValueError("range end must be >= start (inclusive)")
    suffix = "*" if end is None else str(int(end))
    return f"{cache_key(file_unique_id)}:r={int(start)}-{suffix}"
