"""Entrypoint adapter (ARCHITECTURE PROPER BREAKDOWN).

``app.main:main()`` = the module entrypoint (``python -m app.main``). It
delegates to the REAL composition root in app/bootstrap/application.py,
which loads the Telegram presentation runtime
(app/presentation/telegram) and composes the PTB Application, the
service container wiring, and the polling loop.

bot.py is gone — nothing imports it. The handler mass is owned by
app/presentation/telegram/.
"""
from __future__ import annotations

import logging
import os
import sys

_LOGGER = logging.getLogger("app.main")


def _ensure_project_root_on_path() -> None:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)


def main() -> None:
    _ensure_project_root_on_path()
    from app.bootstrap.application import run_production

    _LOGGER.info("app.main: delegating to the application bootstrap")
    run_production()


if __name__ == "__main__":
    main()
