"""Storage layer: SQLite connection core, migration primitives and the
domain repositories extracted from the legacy bot.py Database class."""
