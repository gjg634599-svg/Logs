"""Low-level storage utilities (compatibility re-export).

The canonical home of ``now_iso`` / ``safe_row_get`` moved to the DOMAIN
layer (app/core/dbutil.py — ARCHITECTURE PROPER BREAKDOWN RULE H: domain
services must not import the storage layer for pure helpers). This module
keeps the historical import path working for repositories and
infrastructure code.
"""
from __future__ import annotations

from app.core.dbutil import now_iso, safe_row_get

__all__ = ["now_iso", "safe_row_get"]
