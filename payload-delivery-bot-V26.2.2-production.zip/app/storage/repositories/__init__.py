'''Domain repository mixins extracted from the legacy bot.py
Database class (ARCHITECTURE PHASE). Composed by
app.storage.database.DatabaseBase; see docs/BOT_COMPATIBILITY.md.'''
from .users import UsersRepoMixin
from .media import MediaRepoMixin
from .payloads import PayloadsRepoMixin
from .force_join import ForceJoinRepoMixin
from .referrals import ReferralsRepoMixin, generate_referral_token
from .watch_ads import WatchAdsRepoMixin
from .network import NetworkRepoMixin
from .broadcasts import BroadcastsRepoMixin
from .deliveries import DeliveriesRepoMixin
from .settings import SettingsRepoMixin
from .website import WebsiteRepoMixin
from .categories import WebsiteCategoriesRepoMixin
from .ads import AdsRepoMixin
from .verification import VerificationRepoMixin
from .delivery import DeliveryRepoMixin
from .media_stats import MediaStatsRepoMixin

# B23-3 (§5.14): EVERY mixin composed into app.storage.database.DatabaseBase
# is re-exported here for package consistency. app.storage.database imports
# the mixins from their modules directly, so this __init__ is a convenience
# surface only — it carries no runtime impact either way.
__all__ = [
    "UsersRepoMixin", "MediaRepoMixin", "PayloadsRepoMixin",
    "ForceJoinRepoMixin", "ReferralsRepoMixin", "WatchAdsRepoMixin",
    "NetworkRepoMixin", "BroadcastsRepoMixin", "DeliveriesRepoMixin",
    "SettingsRepoMixin", "generate_referral_token", "WebsiteRepoMixin",
    "WebsiteCategoriesRepoMixin", "AdsRepoMixin",
    "VerificationRepoMixin", "DeliveryRepoMixin", "MediaStatsRepoMixin",
]
