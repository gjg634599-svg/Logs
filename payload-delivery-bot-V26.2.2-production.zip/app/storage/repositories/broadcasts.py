"""network broadcasts (jobs/deliveries) and legacy scheduled broadcasts — broadcasts repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
import json
from typing import Any, Dict, List, Optional
from app.storage.dbutil import now_iso as _now_iso

class BroadcastsRepoMixin:
    """network broadcasts (jobs/deliveries) and legacy scheduled broadcasts."""

    async def create_broadcast(self, *, method: str, created_by: int,
                               text: Optional[str],
                               source_chat_id: Optional[int],
                               source_message_ids: Optional[List[int]],
                               payload_id: Optional[int],
                               target_mode: str,
                               target_bot_ids: Optional[List[int]],
                               protect_content: bool) -> int:
        cur = await self.conn.execute(
            """INSERT INTO broadcasts
               (method, text_content, source_chat_id, source_message_ids,
                payload_id, target_mode, target_bot_ids, protect_content,
                status, created_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)""",
            (method, text, source_chat_id,
             json.dumps(source_message_ids) if source_message_ids else None,
             payload_id, target_mode,
             json.dumps(target_bot_ids) if target_bot_ids else None,
             1 if protect_content else 0, int(created_by), _now_iso()))
        await self.conn.commit()
        return int(cur.lastrowid or 0)
    async def expand_broadcast_targets(self, broadcast_id: int,
                                       target_mode: str,
                                       target_bot_ids: List[int]
                                       ) -> Dict[str, int]:
        """Create per-bot jobs + per-user delivery rows (durable), strictly
        respecting reachability (ACTIVE memberships only — spec §16/§26)."""
        if target_mode == "SELECTED_BOTS" and target_bot_ids:
            bots = []
            for bid in target_bot_ids:
                cur = await self.conn.execute(
                    "SELECT * FROM network_bots WHERE id = ? AND status IN "
                    "('ACTIVE', 'DEGRADED') AND enabled = 1", (int(bid),))
                row = await cur.fetchone()
                if row:
                    bots.append(dict(row))
        else:
            cur = await self.conn.execute(
                "SELECT * FROM network_bots WHERE status IN "
                "('ACTIVE', 'DEGRADED') AND enabled = 1")
            bots = [dict(r) for r in await cur.fetchall()]
        now = _now_iso()
        user_count = 0
        for b in bots:
            nid = int(b["id"])
            if target_mode == "USERS_OF_BOT" and target_bot_ids:
                if nid not in {int(x) for x in target_bot_ids}:
                    continue
            cur = await self.conn.execute(
                "SELECT telegram_user_id FROM user_bot_memberships "
                "WHERE network_bot_id = ? AND status = 'ACTIVE'", (nid,))
            users = [int(r["telegram_user_id"]) for r in await cur.fetchall()]
            await self.conn.execute(
                """INSERT INTO broadcast_bot_jobs
                   (broadcast_id, network_bot_id, status, total, created_at)
                   VALUES (?, ?, 'PENDING', ?, ?)""",
                (int(broadcast_id), nid, len(users), now))
            for uid in users:
                await self.conn.execute(
                    """INSERT OR IGNORE INTO broadcast_deliveries
                       (broadcast_id, network_bot_id, user_id, status,
                        created_at)
                       VALUES (?, ?, ?, 'PENDING', ?)""",
                    (int(broadcast_id), nid, uid, now))
                user_count += 1
        await self.conn.commit()
        return {"bot_count": len(bots), "user_count": user_count}
    async def get_broadcast(self, broadcast_id: int) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM broadcasts WHERE id = ?", (int(broadcast_id),))
        row = await cur.fetchone()
        return dict(row) if row else None
    async def get_broadcast_status(self, broadcast_id: int) -> Optional[str]:
        cur = await self.conn.execute(
            "SELECT status FROM broadcasts WHERE id = ?", (int(broadcast_id),))
        row = await cur.fetchone()
        return str(row["status"]) if row else None
    async def set_network_broadcast_status(self, broadcast_id: int,
                                           status: str,
                                           error: Optional[str] = None) -> None:
        # NOTE: named set_network_broadcast_status to avoid the legacy
        # set_broadcast_status (scheduled_broadcasts table) collision.
        extra = ""
        params: List[Any] = [status]
        if status == "RUNNING":
            extra = ", started_at = COALESCE(started_at, ?)"
            params.append(_now_iso())
        if status in ("COMPLETED", "CANCELLED", "FAILED"):
            extra = ", finished_at = ?"
            params.append(_now_iso())
        if error is not None:
            extra += ", error = ?"
            params.append(str(error)[:500])
        params.append(int(broadcast_id))
        await self.conn.execute(
            f"UPDATE broadcasts SET status = ?{extra} WHERE id = ?", params)
        await self.conn.commit()
    async def list_broadcast_ids_by_status(self, status: str) -> List[int]:
        cur = await self.conn.execute(
            "SELECT id FROM broadcasts WHERE status = ? ORDER BY id ASC",
            (status,))
        return [int(r["id"]) for r in await cur.fetchall()]
    async def list_broadcasts(self, limit: int = 20) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM broadcasts ORDER BY id DESC LIMIT ?",
            (int(limit),))
        return [dict(r) for r in await cur.fetchall()]
    async def mark_pending_bot_jobs_running(self, broadcast_id: int) -> None:
        await self.conn.execute(
            "UPDATE broadcast_bot_jobs SET status = 'RUNNING', updated_at = ? "
            "WHERE broadcast_id = ? AND status IN ('PENDING', 'PAUSED')",
            (_now_iso(), int(broadcast_id)))
        await self.conn.commit()
    async def list_broadcast_bot_jobs(self, broadcast_id: int
                                      ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM broadcast_bot_jobs WHERE broadcast_id = ? "
            "ORDER BY id ASC", (int(broadcast_id),))
        return [dict(r) for r in await cur.fetchall()]
    async def set_bot_job_status(self, broadcast_id: int,
                                 network_bot_id: int, status: str,
                                 error: Optional[str] = None) -> None:
        await self.conn.execute(
            "UPDATE broadcast_bot_jobs SET status = ?, last_error = ?, "
            "updated_at = ? WHERE broadcast_id = ? AND network_bot_id = ?",
            (status, str(error)[:300] if error else None, _now_iso(),
             int(broadcast_id), int(network_bot_id)))
        await self.conn.commit()
    async def bump_bot_job_progress(self, broadcast_id: int,
                                    network_bot_id: int, *, sent: int,
                                    failed: int) -> None:
        await self.conn.execute(
            "UPDATE broadcast_bot_jobs SET sent = sent + ?, failed = failed + ?, "
            "updated_at = ? WHERE broadcast_id = ? AND network_bot_id = ?",
            (int(sent), int(failed), _now_iso(), int(broadcast_id),
             int(network_bot_id)))
        await self.conn.commit()
    async def fetch_pending_deliveries(self, broadcast_id: int,
                                       network_bot_id: int, limit: int
                                       ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM broadcast_deliveries WHERE broadcast_id = ? AND "
            "network_bot_id = ? AND status IN ('PENDING', 'RETRYING') "
            "ORDER BY id ASC LIMIT ?",
            (int(broadcast_id), int(network_bot_id), int(limit)))
        return [dict(r) for r in await cur.fetchall()]
    async def update_broadcast_delivery(self, delivery_id: int, status: str,
                                        *, message_id: Optional[int] = None,
                                        attempts: Optional[int] = None,
                                        error_code: Optional[str] = None,
                                        error: Optional[str] = None) -> None:
        sets = ["status = ?"]
        params: List[Any] = [status]
        if message_id is not None:
            sets.append("telegram_message_id = ?")
            params.append(int(message_id))
        if attempts is not None:
            sets.append("attempts = ?")
            params.append(int(attempts))
        if error_code is not None:
            sets.append("error_code = ?")
            params.append(str(error_code)[:80])
        if error is not None:
            sets.append("error_message = ?")
            params.append(str(error)[:300])
        if status == "SENT":
            sets.append("sent_at = ?")
            params.append(_now_iso())
        sets.append("last_attempt_at = ?")
        params.append(_now_iso())
        params.append(int(delivery_id))
        await self.conn.execute(
            f"UPDATE broadcast_deliveries SET {', '.join(sets)} WHERE id = ?",
            params)
        await self.conn.commit()
    async def cancel_pending_deliveries(self, broadcast_id: int) -> int:
        cur = await self.conn.execute(
            "UPDATE broadcast_deliveries SET status = 'CANCELLED', "
            "last_attempt_at = ? WHERE broadcast_id = ? AND status IN "
            "('PENDING', 'RETRYING')", (_now_iso(), int(broadcast_id)))
        await self.conn.commit()
        return cur.rowcount or 0
    async def broadcast_stats(self, broadcast_id: int) -> Dict[str, Any]:
        cur = await self.conn.execute(
            """SELECT status, COUNT(*) AS c FROM broadcast_deliveries
               WHERE broadcast_id = ? GROUP BY status""",
            (int(broadcast_id),))
        by = {str(r["status"]): int(r["c"]) for r in await cur.fetchall()}
        total = sum(by.values())
        jobs = await self.list_broadcast_bot_jobs(int(broadcast_id))
        per_bot = []
        for j in jobs:
            cur = await self.conn.execute(
                "SELECT username, display_name FROM network_bots WHERE id = ?",
                (int(j["network_bot_id"]),))
            brow = await cur.fetchone()
            per_bot.append({
                "network_bot_id": int(j["network_bot_id"]),
                "bot": (brow["username"] if brow else None) or "-",
                "status": str(j["status"]),
                "total": int(j["total"] or 0),
                "sent": int(j["sent"] or 0),
                "failed": int(j["failed"] or 0),
            })
        return {
            "total": total, "sent": by.get("SENT", 0),
            "failed": by.get("FAILED", 0), "blocked": by.get("BLOCKED", 0),
            "unavailable": by.get("UNAVAILABLE", 0),
            "cancelled": by.get("CANCELLED", 0),
            "retrying": by.get("RETRYING", 0),
            "pending": by.get("PENDING", 0),
            "remaining": by.get("PENDING", 0) + by.get("RETRYING", 0),
            "per_bot": per_bot,
        }
    async def create_scheduled_broadcast(self, send_at: str, text_content: Optional[str] = None,
                                         media_id: Optional[str] = None, media_type: Optional[str] = None,
                                         source_chat_id: Optional[int] = None,
                                         source_message_id: Optional[int] = None,
                                         protect_content: int = 0,
                                         delete_after: int = 0) -> int:
        cur = await self.conn.execute(
            """INSERT INTO scheduled_broadcasts
               (source_chat_id, source_message_id, text_content, media_id, media_type,
                send_at, status, created_at, protect_content, delete_after)
               VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?)""",
            (source_chat_id, source_message_id, text_content, media_id, media_type,
             send_at, _now_iso(), protect_content, delete_after),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def list_pending_broadcasts(self, limit: int = 20) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM scheduled_broadcasts WHERE status = 'Pending' "
            "ORDER BY send_at ASC LIMIT ?", (limit,)
        )
        return await cur.fetchall()
    async def list_all_broadcasts(self, limit: int = 20) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM scheduled_broadcasts ORDER BY id DESC LIMIT ?", (limit,)
        )
        return await cur.fetchall()
    async def get_scheduled_broadcast(self, bcast_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM scheduled_broadcasts WHERE id = ?", (bcast_id,)
        )
        return await cur.fetchone()
    async def set_broadcast_status(self, bcast_id: int, status: str) -> None:
        await self.conn.execute(
            "UPDATE scheduled_broadcasts SET status = ? WHERE id = ?", (status, bcast_id)
        )
        await self.conn.commit()
    async def cancel_scheduled_broadcast(self, bcast_id: int) -> bool:
        cur = await self.conn.execute(
            "UPDATE scheduled_broadcasts SET status = 'Cancelled' "
            "WHERE id = ? AND status = 'Pending'", (bcast_id,)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def due_scheduled_broadcasts(self, now_str: str) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM scheduled_broadcasts WHERE status = 'Pending' AND send_at <= ? "
            "ORDER BY send_at ASC", (now_str,)
        )
        return await cur.fetchall()
    async def fix_stale_processing_broadcasts(self) -> int:
        """Mark any 'Processing' broadcasts as 'Failed' (stale from crash/restart).
        Never resend Failed broadcasts."""
        cur = await self.conn.execute(
            "UPDATE scheduled_broadcasts SET status = 'Failed' WHERE status = 'Processing'"
        )
        await self.conn.commit()
        return cur.rowcount if cur.rowcount else 0
