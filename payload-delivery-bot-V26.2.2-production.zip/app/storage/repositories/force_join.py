"""force-join channels, invite links, link health and FJ dashboards — force_join repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
from typing import Any, List, Optional
from app.storage.dbutil import now_iso as _now_iso

# V26.2 (bot-41 §16-§24): bounded per-user pinned-batch rows (one per gate
# ever opened while the requirement is incomplete; oldest evicted beyond
# the cap; ALL rows dropped when the requirement completes).
_FJ_GATE_PRESENTATIONS_CAP = 200

class ForceJoinRepoMixin:
    """force-join channels, invite links, link health and FJ dashboards."""

    async def get_fj_progress_row(self, user_id: int) -> Optional[aiosqlite.Row]:
        """Most recent per-USER force-join progress row (BOTV13 PART 6:
        progress is per-user, NOT per-payload — query by user_id only)."""
        cur = await self.conn.execute(
            "SELECT * FROM fj_progress WHERE user_id = ? "
            "ORDER BY updated_at DESC LIMIT 1",
            (user_id,),
        )
        return await cur.fetchone()

    async def insert_global_fj_progress(self, user_id: int,
                                        channel_order_json: str,
                                        now_iso: str,
                                        requirement_identity: Optional[str] = None) -> None:
        """INSERT OR IGNORE the single per-user GLOBAL progress row
        (payload_code='' so UNIQUE(user_id, payload_code) keeps one row;
        active_batch is created lazily by _get_fj_batch on first need).
        V26: requirement_identity — the 12-hex fingerprint of the CURRENT
        requirement config (NULL = legacy row, adopted on first read)."""
        await self.conn.execute(
            """INSERT OR IGNORE INTO fj_progress
               (user_id, payload_code, channel_order, presented,
                active_batch, completed_batches, batch_cursor,
                requirement_identity, created_at, updated_at)
               VALUES (?, '', ?, '[]', NULL, '[]', 0, ?, ?, ?)""",
            (user_id, channel_order_json, requirement_identity,
             now_iso, now_iso),
        )
        await self.conn.commit()

    async def update_fj_progress_columns(self, user_id: int,
                                         assignments) -> None:
        """Update fj_progress columns by name ((column, value) pairs from
        the fixed set: channel_order/presented/active_batch/
        completed_batches/batch_cursor/unlocked_payload_ids/
        requirement_identity)."""
        sets, params = [], []
        for col, val in assignments:
            sets.append(f"{col} = ?")
            params.append(val)
        if not sets:
            return
        sets.append("updated_at = ?")
        params.append(_now_iso())
        params.append(user_id)
        await self.conn.execute(
            f"UPDATE fj_progress SET {', '.join(sets)} WHERE user_id = ?",
            params,
        )
        await self.conn.commit()

    # ---- V26.2 (bot-41 §16-§24): per-gate pinned FJ batches --------------
    async def get_fj_gate_presentation(self, user_id: int,
                                        gate_key: str
                                        ) -> Optional[aiosqlite.Row]:
        """The (user, gate_key) pinned-batch row — the batch THIS gate
        presented under the requirement identity recorded at pin time. A
        row whose identity no longer matches the current config is a
        stale arm: the caller re-pins (updates) it deterministically."""
        cur = await self.conn.execute(
            "SELECT * FROM fj_gate_presentations "
            "WHERE user_id = ? AND gate_key = ?",
            (int(user_id), str(gate_key)),
        )
        return await cur.fetchone()

    async def upsert_fj_gate_presentation(self, user_id: int, gate_key: str,
                                          requirement_identity: str,
                                          pinned_batch_json: str) -> None:
        """Pin/refresh the (user, gate_key) presentation row. The pinned
        batch is the ONLY batch delivered to the client for this gate —
        future batches are never stored client-side. Bounded per user:
        the oldest rows are evicted past _FJ_GATE_PRESENTATIONS_CAP so a
        long-lived user cannot grow the table unboundedly."""
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute(
                """
                INSERT INTO fj_gate_presentations
                    (user_id, gate_key, requirement_identity, pinned_batch,
                     created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(user_id, gate_key) DO UPDATE SET
                    requirement_identity = excluded.requirement_identity,
                    pinned_batch = excluded.pinned_batch,
                    updated_at = excluded.updated_at
                """,
                (int(user_id), str(gate_key), str(requirement_identity),
                 str(pinned_batch_json), now, now),
            )
            # bounded growth: oldest-first eviction beyond the cap
            await self.conn.execute(
                """
                DELETE FROM fj_gate_presentations WHERE id IN (
                    SELECT id FROM fj_gate_presentations
                    WHERE user_id = ?
                    ORDER BY updated_at DESC, id DESC
                    LIMIT -1 OFFSET ?
                )
                """,
                (int(user_id), int(_FJ_GATE_PRESENTATIONS_CAP)),
            )
            await self.conn.commit()

    async def delete_fj_gate_presentations_for_user(
            self, user_id: int) -> None:
        """Requirement-complete cleanup: once every configured channel is
        live-verified joined, the pinned presentations are moot (every
        gate is trivially satisfied) — drop them (idempotent)."""
        await self.conn.execute(
            "DELETE FROM fj_gate_presentations WHERE user_id = ?",
            (int(user_id),),
        )
        await self.conn.commit()

    async def update_force_channel(self, channel_id: int,
                                   channel_name: Optional[str] = None,
                                   title: Optional[str] = None) -> bool:
        """Issue 25: update a force-join channel's name/title (for Edit)."""
        sets = []
        params: List[Any] = []
        if channel_name is not None:
            sets.append("channel_name = ?")
            params.append(channel_name)
        if title is not None:
            sets.append("title = ?")
            params.append(title)
        if not sets:
            return False
        params.append(channel_id)
        cur = await self.conn.execute(
            f"UPDATE force_join_channels SET {', '.join(sets)} WHERE channel_id = ?",
            params,
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def get_force_channel(self, channel_id: int) -> Optional[aiosqlite.Row]:
        """Issue 25: fetch a single force-join channel record."""
        cur = await self.conn.execute(
            "SELECT * FROM force_join_channels WHERE channel_id = ?", (channel_id,)
        )
        return await cur.fetchone()
    async def get_force_invite_link(self, channel_id: int) -> Optional[str]:
        """Get the stored persistent invite link for a channel."""
        cur = await self.conn.execute(
            "SELECT invite_link FROM force_join_channels WHERE channel_id = ?",
            (channel_id,),
        )
        row = await cur.fetchone()
        return row["invite_link"] if row else None
    async def set_force_invite_link(self, channel_id: int, link: str,
                                     *, provenance: Optional[str] = None
                                     ) -> None:
        """Store a persistent invite link for a channel.

        B18 (schema v39): ``provenance`` records WHO minted the link —
        'bot_created' (export/create/rotate: provably valid until our own
        rotation revokes it — the Bot API has NO getChatInviteLink, so
        provenance is the only durable distinction) or 'custom' (an
        admin supplied it via Set Custom Link). NULL keeps the previous
        value (legacy callers)."""
        if provenance is None:
            await self.conn.execute(
                "UPDATE force_join_channels SET invite_link = ?, "
                "invite_link_created_at = ?, invite_last_verified = ? "
                "WHERE channel_id = ?",
                (link, _now_iso(), _now_iso(), channel_id),
            )
        else:
            await self.conn.execute(
                "UPDATE force_join_channels SET invite_link = ?, "
                "invite_link_created_at = ?, invite_last_verified = ?, "
                "link_provenance = ? WHERE channel_id = ?",
                (link, _now_iso(), _now_iso(), provenance, channel_id),
            )
        await self.conn.commit()
    async def verify_force_invite_link(self, channel_id: int) -> None:
        """Mark the invite link as verified (still valid).

        B23-3 (5.4): a successful verification must never leave a STALE
        dead/error health state behind. ``link_last_error`` is always
        cleared (the last known error is obsolete the moment the link
        verifies), and a stale dead/error ``link_health`` (link_expired /
        link_revoked / link_invalid / channel_invalid / temporary_error /
        bot_permission / no_link / NULL) is flipped to 'healthy' in the
        SAME UPDATE. The non-dead specialized states ('unverifiable' for
        permanent public links the Bot API cannot introspect, 'healthy'
        itself) are PRESERVED — claiming "healthy" for an unverifiable
        link would be a state lie and would oscillate against the health
        checker's persist-on-change.
        """
        now = _now_iso()
        stale_states = (
            "link_expired", "link_revoked", "link_invalid",
            "channel_invalid", "temporary_error", "bot_permission",
            "no_link",
        )
        await self.conn.execute(
            f"""
            UPDATE force_join_channels
            SET invite_last_verified = ?,
                link_health = CASE
                    WHEN link_health IS NULL
                      OR link_health IN ({','.join('?' for _ in stale_states)})
                    THEN 'healthy'
                    ELSE link_health
                END,
                link_health_updated_at = CASE
                    WHEN link_health IS NULL
                      OR link_health IN ({','.join('?' for _ in stale_states)})
                    THEN ?
                    ELSE link_health_updated_at
                END,
                link_last_error = NULL
            WHERE channel_id = ?
            """,
            (now, *stale_states, *stale_states, now, channel_id),
        )
        await self.conn.commit()
    async def clear_force_invite_link(self, channel_id: int) -> None:
        """Clear the stored invite link (when it's invalid/revoked)."""
        await self.conn.execute(
            "UPDATE force_join_channels SET invite_link = NULL, invite_link_created_at = NULL, "
            "invite_last_verified = NULL WHERE channel_id = ?",
            (channel_id,),
        )
        await self.conn.commit()
    async def set_force_link_health(self, channel_id: int, state: str,
                                     *, expires_at: Optional[str] = None,
                                     error: Optional[str] = None,
                                     link_type: Optional[str] = None) -> None:
        """PHASE 8 (v28): persist the invite-link health state for a channel.

        Called ONLY with verified outcomes from the link-health service
        (app/core/fj_link_health.py). Transient states are persisted too so
        the admin UI can show 'Temporary Error' — but they are never treated
        as invalid anywhere.
        """
        await self.conn.execute(
            "UPDATE force_join_channels SET link_health = ?, "
            "link_health_updated_at = ?, link_last_error = ?, "
            "link_expires_at = COALESCE(?, link_expires_at), "
            "link_type = COALESCE(?, link_type) WHERE channel_id = ?",
            (state, _now_iso(), (error or "")[:200] or None, expires_at,
             link_type, channel_id),
        )
        await self.conn.commit()
    async def update_force_link_validation(self, channel_id: int,
                                            status: str) -> None:
        """PHASE 8 (§15): store the validation verdict for an admin-supplied
        custom link: syntax_valid | telegram_verified | expired | revoked |
        unverifiable."""
        await self.conn.execute(
            "UPDATE force_join_channels SET link_validation_status = ?, "
            "link_health_updated_at = ? WHERE channel_id = ?",
            (status, _now_iso(), channel_id),
        )
        await self.conn.commit()
    async def update_force_join_text(self, channel_id: int, join_text: Optional[str] = None,
                                      verify_text: Optional[str] = None,
                                      channel_text: Optional[str] = None,
                                      join_text_entities: Optional[str] = None) -> None:
        """Update customizable force join text/buttons.

        BOTV13 Phase B (wired): `join_text_entities` is the JSON-serialized
        list of Telegram MessageEntity objects for the join_text. Pass None to
        leave unchanged; pass an explicit value (incl. '[]'→None) to set/clear.
        The column was added in v22 migration.
        """
        sets = []
        params: List[Any] = []
        if join_text is not None:
            sets.append("join_text = ?")
            params.append(join_text)
        if verify_text is not None:
            sets.append("verify_button_text = ?")
            params.append(verify_text)
        if channel_text is not None:
            sets.append("channel_button_text = ?")
            params.append(channel_text)
        if join_text_entities is not None:
            sets.append("join_text_entities = ?")
            params.append(join_text_entities)
        if not sets:
            return
        params.append(channel_id)
        await self.conn.execute(
            f"UPDATE force_join_channels SET {', '.join(sets)} WHERE channel_id = ?",
            params,
        )
        await self.conn.commit()
    async def update_force_join_media(self, channel_id: int,
                                      file_id: Optional[str], media_type: Optional[str]) -> None:
        """Update the media attachment for force join page."""
        await self.conn.execute(
            "UPDATE force_join_channels SET media_file_id = ?, media_type = ? WHERE channel_id = ?",
            (file_id, media_type, channel_id),
        )
        await self.conn.commit()
    async def add_force_channel(self, channel_id: int, channel_name: Optional[str],
                                title: Optional[str] = None) -> bool:
        try:
            await self.conn.execute(
                "INSERT INTO force_join_channels (channel_id, channel_name, title) VALUES (?, ?, ?)",
                (channel_id, channel_name, title or channel_name),
            )
            await self.conn.commit()
            return True
        except aiosqlite.IntegrityError:
            return False
    async def remove_force_channel(self, channel_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM force_join_channels WHERE channel_id = ?", (channel_id,)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def list_force_channels(self) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM force_join_channels ORDER BY id"
        )
        return await cur.fetchall()
    async def get_fj_dashboard(self, admin_chat_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM fj_dashboards WHERE admin_chat_id = ?", (admin_chat_id,)
        )
        return await cur.fetchone()
    async def set_fj_dashboard(self, admin_chat_id: int, message_id: int) -> None:
        """Upsert the canonical FJ dashboard message_id for an admin chat."""
        await self.conn.execute(
            "INSERT INTO fj_dashboards(admin_chat_id, dashboard_message_id, updated_at) "
            "VALUES(?, ?, ?) "
            "ON CONFLICT(admin_chat_id) DO UPDATE SET "
            "dashboard_message_id=excluded.dashboard_message_id, updated_at=excluded.updated_at",
            (admin_chat_id, message_id, _now_iso()),
        )
        await self.conn.commit()
    async def clear_fj_dashboard(self, admin_chat_id: int) -> None:
        await self.conn.execute(
            "DELETE FROM fj_dashboards WHERE admin_chat_id = ?", (admin_chat_id,)
        )
        await self.conn.commit()
