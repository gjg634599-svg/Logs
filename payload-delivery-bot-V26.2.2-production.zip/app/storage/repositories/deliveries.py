"""pending deletions, delivery records, retrieval analytics, views/stats — deliveries repository (ARCHITECTURE PHASE).

Payload-FACING delivery analytics + housekeeping, extracted verbatim from
the legacy ``bot.py`` ``Database`` class; composed into ``app.storage.
database.DatabaseBase`` as ``DeliveriesRepoMixin``. Scope:

* ``payload_views`` — per-(payload, user) view rows + the total/unique/
  daily/weekly/monthly rollups (``record_view`` / ``*_view_stats`` /
  ``top_payloads`` / ``top_downloads``), gated by ENABLE_ANALYTICS.
* ``delivery_records`` — the per-user retrieval ledger for named payloads
  and collections (``create_delivery_record`` / retrieve counters /
  ``most_retrieved_*`` analytics / recovery-message bookkeeping).
* ``pending_deletions`` + ``broadcast_deletions`` — the durable
  self-destruct queues for sent messages (save/defer/due/expired + the
  batch variants).
* ``stat:*`` counters — ``increment_stat`` / ``get_stat`` (backed by
  the shared ``bot_settings`` table).

Naming note (B23-3 §5.13): NOT the trusted-relay delivery architecture —
that is the SIBLING ``delivery.py`` (``DeliveryRepoMixin``:
network_delivery_groups / delivery_jobs / file_delivery_bot /
control_audit_events). This module never touches those tables. No
renames — both keep their historical module names; this docstring is the
disambiguator.
"""
from __future__ import annotations

import aiosqlite
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple
from app.core.constants import (
    ENABLE_ANALYTICS,
)
from app.storage.dbutil import now_iso as _now_iso

class DeliveriesRepoMixin:
    """pending deletions, delivery records, retrieval analytics, views/stats."""

    async def record_view(self, payload_id: int, user_id: int) -> None:
        if not ENABLE_ANALYTICS:
            return
        await self.conn.execute(
            "INSERT INTO payload_views (payload_id, user_id, timestamp) VALUES (?, ?, ?)",
            (payload_id, user_id, _now_iso()),
        )
        await self.conn.commit()
    async def payload_view_stats(self, payload_id: int) -> Dict[str, int]:
        now = datetime.now(timezone.utc)
        day_ago = (now - timedelta(days=1)).isoformat()
        week_ago = (now - timedelta(days=7)).isoformat()
        month_ago = (now - timedelta(days=30)).isoformat()
        stats = {"total": 0, "unique": 0, "daily": 0, "weekly": 0, "monthly": 0}
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payload_views WHERE payload_id = ?", (payload_id,)
        )
        r = await cur.fetchone()
        stats["total"] = int(r["c"]) if r else 0

        cur = await self.conn.execute(
            "SELECT COUNT(DISTINCT user_id) AS c FROM payload_views WHERE payload_id = ?",
            (payload_id,),
        )
        r = await cur.fetchone()
        stats["unique"] = int(r["c"]) if r else 0

        for key, since in (("daily", day_ago), ("weekly", week_ago), ("monthly", month_ago)):
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM payload_views WHERE payload_id = ? AND timestamp >= ?",
                (payload_id, since),
            )
            r = await cur.fetchone()
            stats[key] = int(r["c"]) if r else 0
        return stats
    async def global_view_stats(self) -> Dict[str, int]:
        now = datetime.now(timezone.utc)
        day_ago = (now - timedelta(days=1)).isoformat()
        week_ago = (now - timedelta(days=7)).isoformat()
        month_ago = (now - timedelta(days=30)).isoformat()
        stats = {"total": 0, "unique": 0, "daily": 0, "weekly": 0, "monthly": 0}

        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM payload_views")
        r = await cur.fetchone()
        stats["total"] = int(r["c"]) if r else 0

        cur = await self.conn.execute("SELECT COUNT(DISTINCT user_id) AS c FROM payload_views")
        r = await cur.fetchone()
        stats["unique"] = int(r["c"]) if r else 0

        for key, since in (("daily", day_ago), ("weekly", week_ago), ("monthly", month_ago)):
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM payload_views WHERE timestamp >= ?", (since,)
            )
            r = await cur.fetchone()
            stats[key] = int(r["c"]) if r else 0
        return stats
    async def top_payloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            """
            SELECT p.payload, p.current_clicks,
                   (SELECT COUNT(*) FROM payload_views v WHERE v.payload_id = p.id) AS views
            FROM payloads p
            ORDER BY p.current_clicks DESC
            LIMIT ?
            """,
            (limit,),
        )
        return await cur.fetchall()
    async def top_downloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files ORDER BY downloads DESC LIMIT ?", (limit,)
        )
        return await cur.fetchall()
    async def increment_stat(self, key: str, by: int = 1) -> None:
        cur_val = await self.get_setting_int(f"stat:{key}", 0)
        await self.set_setting(f"stat:{key}", str(cur_val + by))
    async def get_stat(self, key: str, default: int = 0) -> int:
        return await self.get_setting_int(f"stat:{key}", default)
    async def save_pending_deletion(self, chat_id: int, message_id: int, delete_at: str) -> None:
        await self.conn.execute(
            "INSERT OR REPLACE INTO broadcast_deletions (chat_id, message_id, delete_at) "
            "VALUES (?, ?, ?)", (chat_id, message_id, delete_at)
        )
        await self.conn.commit()
    async def bulk_save_pending_deletions(self, rows: List[Tuple[int, int, str]]) -> None:
        await self.conn.executemany(
            "INSERT OR REPLACE INTO broadcast_deletions (chat_id, message_id, delete_at) "
            "VALUES (?, ?, ?)", rows
        )
        await self.conn.commit()
    async def remove_pending_deletion(self, chat_id: int, message_id: int) -> None:
        await self.conn.execute(
            "DELETE FROM broadcast_deletions WHERE chat_id = ? AND message_id = ?",
            (chat_id, message_id)
        )
        await self.conn.commit()
    async def defer_pending_deletion(self, chat_id: int, message_id: int, delete_at: str) -> None:
        await self.conn.execute(
            "UPDATE broadcast_deletions SET delete_at = ? WHERE chat_id = ? AND message_id = ?",
            (delete_at, chat_id, message_id)
        )
        await self.conn.commit()
    async def expired_pending_deletions(self, now_str: str) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT chat_id, message_id FROM broadcast_deletions WHERE delete_at <= ?",
            (now_str,)
        )
        return await cur.fetchall()
    async def add_pending_deletion(self, chat_id: int, message_id: int,
                                    delete_at: int, deletion_type: str) -> int:
        """Persist a scheduled message deletion so it survives bot restart.

        Returns the row id. delete_at is a unix epoch timestamp (seconds).
        deletion_type is one of: delivery, browse, admin_preview, status.
        """
        cur = await self.conn.execute(
            "INSERT INTO pending_deletions (chat_id, message_id, delete_at, deletion_type) "
            "VALUES (?, ?, ?, ?)",
            (chat_id, message_id, int(delete_at), deletion_type),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def add_pending_deletions_batch(self, rows: List[Tuple[int, int, int, str]]) -> None:
        """Bulk insert pending deletions. Each row is (chat_id, message_id, delete_at, type)."""
        if not rows:
            return
        await self.conn.executemany(
            "INSERT INTO pending_deletions (chat_id, message_id, delete_at, deletion_type) "
            "VALUES (?, ?, ?, ?)",
            rows,
        )
        await self.conn.commit()
    async def due_pending_deletions(self, now_ts: int) -> List[aiosqlite.Row]:
        """Return all pending deletions whose delete_at <= now (should be deleted immediately)."""
        cur = await self.conn.execute(
            "SELECT id, chat_id, message_id, deletion_type FROM pending_deletions "
            "WHERE delete_at <= ? ORDER BY delete_at ASC",
            (int(now_ts),),
        )
        return await cur.fetchall()
    async def upcoming_pending_deletions(self, now_ts: int) -> List[aiosqlite.Row]:
        """Return all pending deletions whose delete_at > now (need re-scheduling)."""
        cur = await self.conn.execute(
            "SELECT id, chat_id, message_id, delete_at, deletion_type FROM pending_deletions "
            "WHERE delete_at > ? ORDER BY delete_at ASC",
            (int(now_ts),),
        )
        return await cur.fetchall()
    async def remove_pending_deletion_by_id(self, row_id: int) -> None:
        """Issue 34/C1 Fix: Remove a pending_deletions record by row id.

        Renamed from remove_pending_deletion to avoid collision with the
        broadcast_deletions method of the same name (which takes
        chat_id+message_id). The old name caused a TypeError crash in
        cleanup_loop because Python silently overrode the first definition.
        """
        await self.conn.execute(
            "DELETE FROM pending_deletions WHERE id = ?", (row_id,)
        )
        await self.conn.commit()
    async def remove_pending_deletion_by_msg(self, chat_id: int, message_id: int) -> None:
        """Remove a pending deletion record by (chat_id, message_id)."""
        await self.conn.execute(
            "DELETE FROM pending_deletions WHERE chat_id = ? AND message_id = ?",
            (chat_id, message_id),
        )
        await self.conn.commit()
    async def count_pending_deletions(self) -> int:
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM pending_deletions")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def create_delivery_record(self, payload_code: str, user_id: int,
                                      delivery_type: str, chat_id: int,
                                      collection_code: Optional[str] = None,
                                      max_retrieves: int = 0,
                                      retrieve_window_hours: int = 0) -> int:
        """Store a delivery record so it can be retrieved after auto-delete."""
        cur = await self.conn.execute(
            """INSERT INTO delivery_records
               (payload_code, collection_code, user_id, delivery_type, delivered_at,
                retrieve_count, max_retrieves, retrieve_window_hours, chat_id)
               VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)""",
            (payload_code, collection_code, user_id, delivery_type, _now_iso(),
             max_retrieves, retrieve_window_hours, chat_id),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def get_delivery_record(self, record_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM delivery_records WHERE id = ?", (record_id,)
        )
        return await cur.fetchone()
    async def get_recent_delivery_records(self, user_id: int, limit: int = 5) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM delivery_records WHERE user_id = ? ORDER BY id DESC LIMIT ?",
            (user_id, limit),
        )
        return await cur.fetchall()
    async def get_recent_payload_deliveries_24h(self, user_id: int,
                                                  limit: int = 4) -> List[aiosqlite.Row]:
        """BOT5 /recent: deduped by payload_code, 24h window, max 4."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        cur = await self.conn.execute(
            "SELECT MAX(id) AS max_id FROM delivery_records "
            "WHERE user_id = ? AND delivered_at >= ? "
            "GROUP BY payload_code ORDER BY max_id DESC LIMIT ?",
            (user_id, cutoff, limit),
        )
        id_rows = await cur.fetchall()
        if not id_rows:
            return []
        ids = [int(r["max_id"]) for r in id_rows]
        placeholders = ",".join("?" * len(ids))
        cur = await self.conn.execute(
            f"SELECT * FROM delivery_records WHERE id IN ({placeholders}) ORDER BY id DESC",
            ids,
        )
        return await cur.fetchall()
    async def increment_retrieve_count(self, record_id: int) -> None:
        await self.conn.execute(
            "UPDATE delivery_records SET retrieve_count = retrieve_count + 1 WHERE id = ?",
            (record_id,),
        )
        await self.conn.commit()
    async def delete_delivery_record(self, record_id: int) -> None:
        await self.conn.execute("DELETE FROM delivery_records WHERE id = ?", (record_id,))
        await self.conn.commit()
    async def update_recovery_message_id(self, record_id: int, message_id: int) -> None:
        """Issue #81: store the Telegram message_id of the recovery card."""
        await self.conn.execute(
            "UPDATE delivery_records SET recovery_message_id = ? WHERE id = ?",
            (message_id, record_id),
        )
        await self.conn.commit()
    async def count_delivery_records(self) -> int:
        """Total deliveries that left a recovery card (retrieve-eligible)."""
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM delivery_records")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def count_total_retrieves(self) -> int:
        """Sum of retrieve_count across all delivery records."""
        cur = await self.conn.execute(
            "SELECT COALESCE(SUM(retrieve_count), 0) AS s FROM delivery_records"
        )
        row = await cur.fetchone()
        return int(row["s"]) if row else 0
    async def most_retrieved_payloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        """Issue #55: top single-file payloads by retrieve_count."""
        cur = await self.conn.execute(
            """SELECT payload_code, SUM(retrieve_count) AS total
               FROM delivery_records
               WHERE delivery_type = 'single'
               GROUP BY payload_code
               ORDER BY total DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
    async def most_retrieved_collections(self, limit: int = 10) -> List[aiosqlite.Row]:
        """Issue #55: top collections by retrieve_count."""
        cur = await self.conn.execute(
            """SELECT collection_code, SUM(retrieve_count) AS total
               FROM delivery_records
               WHERE delivery_type = 'collection' AND collection_code IS NOT NULL
               GROUP BY collection_code
               ORDER BY total DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
