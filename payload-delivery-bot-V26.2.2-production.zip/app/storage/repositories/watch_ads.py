"""watch-ads settings reads, session lookups, postback logs and statistics — watch_ads repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
import logging
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple
from app.core.constants import (
    WATCH_ADS_GLOBAL_ENABLED_KEY,
    WATCH_ADS_SESSION_TTL_KEY,
    WATCH_ADS_SESSION_TTL_MAX,
    WATCH_ADS_SESSION_TTL_MIN,
    WATCH_AD_AD_CONTROL_DEFAULT,
    WATCH_AD_AD_CONTROL_KEY,
    WATCH_AD_AD_CONTROL_MODES,
    WATCH_AD_SESSION_TTL,
    WATCH_AD_STATUS_EXPIRED,
    WATCH_AD_STATUS_REWARDED,
)
from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")


class WatchAdsRepoMixin:
    """watch-ads settings reads, session lookups, postback logs and statistics."""

    async def get_watch_ads_ad_control(self) -> str:
        """Load the GLOBAL Ads Control mode (DB authoritative; validated).

        Returns one of 'short' | 'two' | 'three' | 'random'. Unknown/missing
        values fall back to 'short' (the v25-compatible single-ad behavior). The
        environment NEVER writes this key — only the admin panel does.
        """
        raw = (await self.get_setting(WATCH_AD_AD_CONTROL_KEY) or "").strip().lower()
        return raw if raw in WATCH_AD_AD_CONTROL_MODES else WATCH_AD_AD_CONTROL_DEFAULT
    async def get_watch_ads_global_enabled(self) -> bool:
        """WATCH_AD V4 (v27): the GLOBAL Watch Ads master switch.

        DB authoritative (bot_settings watch_ads_global_enabled). Missing key
        (fresh DB pre-seed, legacy DB) = ENABLED — the exact pre-v27 behavior;
        the admin must OPT OUT, never accidentally start disabled.
        """
        raw = (await self.get_setting(WATCH_ADS_GLOBAL_ENABLED_KEY) or "").strip()
        return raw not in ("0", "false", "off", "disabled")
    async def get_watch_ads_session_ttl(self) -> int:
        """WATCH_AD V4 (v27): the pending-session TTL (verification timeout).

        DB authoritative (bot_settings watch_ads_session_ttl), clamped to
        WATCH_ADS_SESSION_TTL_MIN..MAX. Falls back to the WATCH_AD_SESSION_TTL
        env default when the key is absent/invalid.
        """
        raw = (await self.get_setting(WATCH_ADS_SESSION_TTL_KEY) or "").strip()
        try:
            ttl = int(raw)
        except (TypeError, ValueError):
            ttl = WATCH_AD_SESSION_TTL
        return max(WATCH_ADS_SESSION_TTL_MIN,
                   min(WATCH_ADS_SESSION_TTL_MAX, int(ttl)))
    async def get_payload_watch_ads_ad_mode_override(self,
                                                      payload_id: int) -> Optional[str]:
        """WATCH_AD V4 (v27): per-payload override of the default ad mode.

        Returns one of the ad-control modes when this payload overrides the
        global default, or None (= follow the global default).
        """
        cur = await self.conn.execute(
            "SELECT watch_ads_ad_mode_override FROM payloads WHERE id = ?",
            (int(payload_id),))
        row = await cur.fetchone()
        if not row:
            return None
        # B23-3 (5.11): the SELECT projects the column BY NAME, so named
        # access is the contract (positional row[0] would silently break on
        # any future column reordering); the keys() guard stays as
        # defense-in-depth for exotic row factories.
        raw = ((row["watch_ads_ad_mode_override"] or "").strip().lower()
               if "watch_ads_ad_mode_override" in row.keys() else "")
        if raw and raw in WATCH_AD_AD_CONTROL_MODES:
            return raw
        return None
    async def get_watch_ad_session_by_token(self, token: str) -> Optional[aiosqlite.Row]:
        if not token or not re.fullmatch(r"[0-9a-f]{32}", token):
            return None
        cur = await self.conn.execute(
            "SELECT * FROM watch_ad_sessions WHERE token = ?", (token,)
        )
        return await cur.fetchone()
    async def set_watch_ad_session_launch_network_bot_id(
            self, session_id: int, network_bot_id: Optional[int]) -> None:
        """V26 (Network Bot Watch Ads): record the launch context on the
        session — the network bot whose [🎬 Watch Ad] button produced the
        Mini App URL (NULL/0 = the main bot). Best-effort + idempotent:
        a failure NEVER breaks the launch (the reward path falls back to
        the main bot exactly as before). Called when the access screen is
        rendered from a NETWORK worker context so the verified-reward
        notification + auto-resume delivery can route through the bot the
        user is actually talking to."""
        try:
            nid = int(network_bot_id) if network_bot_id else None
            await self.conn.execute(
                "UPDATE watch_ad_sessions SET launch_network_bot_id = ? "
                "WHERE id = ?",
                (nid, int(session_id)))
            await self.conn.commit()
        except Exception:  # noqa: BLE001 — display/routing hint only
            logger.debug("watch_ad launch_network_bot_id update failed",
                         exc_info=True)
    async def watch_ad_unlock_valid(self, user_id: int, payload_id: int
                                    ) -> Tuple[bool, Optional[str]]:
        """Is the Watch Ads requirement SATISFIED for (user, payload)?

        True only when a `rewarded` session exists whose unlock window is still
        open (unlock_expires_at > now). Expired rewarded sessions are lazily
        flipped to `expired` (idempotent, transaction-safe) so the user must
        watch a new ad after the window elapses — never a permanent unlock.
        """
        now_iso = datetime.now(timezone.utc).isoformat()
        cur = await self.conn.execute(
            "SELECT * FROM watch_ad_sessions WHERE user_id = ? AND payload_id = ? "
            "AND status = ? ORDER BY id DESC LIMIT 1",
            (user_id, payload_id, WATCH_AD_STATUS_REWARDED),
        )
        row = await cur.fetchone()
        if not row:
            return False, None
        exp = row["unlock_expires_at"]
        if not exp or exp <= now_iso:
            # Lazily expire (only flip if still rewarded — idempotent).
            try:
                async with self.write_lock:
                    await self.conn.execute(
                        "UPDATE watch_ad_sessions SET status = ? WHERE id = ? AND status = ?",
                        (WATCH_AD_STATUS_EXPIRED, row["id"], WATCH_AD_STATUS_REWARDED),
                    )
                    await self.conn.commit()
                await self._log_access_event_locked("ad_unlock_expired",
                                            payload_id=payload_id, user_id=user_id)
                logger.info("Watch Ad unlock expired for user %s / payload %s",
                            user_id, payload_id)
            except Exception:  # noqa: BLE001
                logger.debug("watch_ad lazy expire failed", exc_info=True)
            return False, None
        # Record first authorized use (consumed_at) — unlock stays valid until
        # unlock_expires_at so the user may re-access within the window.
        if not row["consumed_at"]:
            try:
                await self.conn.execute(
                    "UPDATE watch_ad_sessions SET consumed_at = ? WHERE id = ?",
                    (now_iso, row["id"]),
                )
                await self.conn.commit()
            except Exception:  # noqa: BLE001
                logger.debug("watch_ad consumed_at update failed", exc_info=True)
        return True, exp
    async def mark_watch_ad_session_status(self, session_id: int, status: str) -> None:
        """WATCH_AD V5 (concurrency fix): serialized under write_lock — a
        status flip (expiry) can no longer interleave with an in-flight
        reward transaction on the shared connection."""
        async with self.write_lock:
            await self.conn.execute(
                "UPDATE watch_ad_sessions SET status = ? WHERE id = ?", (status, session_id)
            )
            await self.conn.commit()
    async def watch_ad_payload_stats(self, payload_id: int) -> Dict[str, int]:
        """Additive Watch Ads analytics for one payload (existing access_events)."""
        stats = {"sessions": 0, "ad_watch_started": 0, "ad_rewarded": 0,
                 "ad_unlock_granted": 0, "ad_unlock_expired": 0,
                 "ad_unlock_rejected": 0, "ad_reward_duplicate": 0}
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM watch_ad_sessions WHERE payload_id = ?",
            (payload_id,))
        row = await cur.fetchone()
        stats["sessions"] = int(row["c"]) if row else 0
        cur = await self.conn.execute(
            "SELECT event_type, COUNT(*) AS c FROM access_events "
            "WHERE payload_id = ? AND event_type LIKE 'ad_%' GROUP BY event_type",
            (payload_id,))
        for row in await cur.fetchall():
            if row["event_type"] in stats:
                stats[row["event_type"]] = int(row["c"])
        return stats
    async def watch_ad_global_stats(self) -> Dict[str, int]:
        """Global Watch Ads analytics (Settings panel summary)."""
        stats = {"payloads_enabled": await self.count_watch_ad_payloads(),
                 "sessions": 0, "ad_watch_started": 0, "ad_rewarded": 0,
                 "ad_unlock_granted": 0, "ad_unlock_expired": 0,
                 "ad_unlock_rejected": 0, "ad_reward_duplicate": 0}
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM watch_ad_sessions")
        row = await cur.fetchone()
        stats["sessions"] = int(row["c"]) if row else 0
        cur = await self.conn.execute(
            "SELECT event_type, COUNT(*) AS c FROM access_events "
            "WHERE event_type LIKE 'ad_%' GROUP BY event_type")
        for row in await cur.fetchall():
            if row["event_type"] in stats:
                stats[row["event_type"]] = int(row["c"])
        return stats
    async def log_watch_ad_postback(self, *, ymid_prefix: str,
                                    result: str, http_status: int,
                                    user_id: Optional[int] = None,
                                    payload_id: Optional[int] = None,
                                    ad_index: Optional[int] = None,
                                    event_type: str = "",
                                    reward_event_type: str = "") -> None:
        """Append one row to watch_ad_postback_log (best-effort — monitoring
        must NEVER break postback processing). Stores ONLY the ymid prefix,
        never a full session token.

        WATCH_AD V5 (concurrency fix): the INSERT+COMMIT now runs under the
        SAME write_lock as reward processing. Previously a second concurrent
        postback could queue its BEGIN IMMEDIATE between this (lock-free)
        INSERT's implicit transaction and the reward's own BEGIN — producing
        sqlite3.OperationalError "cannot start a transaction within a
        transaction" (→ HTTP 500, provider retry, delayed rewards). All
        Watch-Ads writes now serialize on one lock: no interleaving, no
        foreign early COMMIT, exactly-once semantics under concurrency.
        """
        try:
            async with self.write_lock:
                await self.conn.execute(
                    """INSERT INTO watch_ad_postback_log
                       (created_at, ymid_prefix, user_id, payload_id, ad_index,
                        event_type, reward_event_type, result, http_status)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (_now_iso(), (ymid_prefix or "")[:10], user_id, payload_id,
                     ad_index, (event_type or "")[:24] or None,
                     (reward_event_type or "")[:24] or None,
                     (result or "unknown")[:24], int(http_status)),
                )
                await self.conn.commit()
        except Exception as e:  # noqa: BLE001
            logger.debug("watch_ad_postback_log insert failed: %s", e)
    async def watch_ad_postback_stats(self) -> Dict[str, int]:
        """Postback counts by classification (admin Status panel)."""
        stats = {"total": 0, "last_24h": 0, "rewarded": 0, "duplicate": 0,
                 "non_valued": 0, "invalid": 0, "error": 0}
        try:
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM watch_ad_postback_log")
            row = await cur.fetchone()
            stats["total"] = int(row["c"]) if row else 0
            day_ago = (datetime.now(timezone.utc)
                       - timedelta(hours=24)).isoformat()
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM watch_ad_postback_log "
                "WHERE created_at >= ?", (day_ago,))
            row = await cur.fetchone()
            stats["last_24h"] = int(row["c"]) if row else 0
            cur = await self.conn.execute(
                "SELECT result, COUNT(*) AS c FROM watch_ad_postback_log "
                "GROUP BY result")
            for row in await cur.fetchall():
                key = str(row["result"])
                cnt = int(row["c"])
                if key == "rewarded":
                    stats["rewarded"] = cnt
                elif key == "duplicate":
                    stats["duplicate"] = cnt
                elif key == "non_valued":
                    stats["non_valued"] = cnt
                elif key == "error":
                    stats["error"] = cnt
                else:  # unknown / expired / rejected / inactive / foreign
                    stats["invalid"] += cnt
        except Exception as e:  # noqa: BLE001
            logger.debug("watch_ad_postback_stats failed: %s", e)
        return stats
    async def latest_watch_ad_session_progress(self, user_id: int,
                                                payload_id: int
                                                ) -> Optional[Dict[str, Any]]:
        """FINAL-1 (bot-20.log observability): the LATEST session row for
        (user, payload) regardless of status — the server-truth progress
        (session id, status, completed_ads, required_ads, unlock window)
        that denial-side logs carry so an operator reading a
        watch_ad_required denial sees WHICH gate denied and HOW FAR the
        user actually got (the bot-20.log 11:45:07 denial had no
        progress context, which made it look contradictory next to the
        separate website-preroll "serve=False reason=disabled" line).
        Read-only; never mutates session state.
        """
        try:
            cur = await self.conn.execute(
                "SELECT id, status, completed_ads, required_ads, "
                "unlock_expires_at, expires_at FROM watch_ad_sessions "
                "WHERE user_id = ? AND payload_id = ? "
                "ORDER BY id DESC LIMIT 1",
                (int(user_id), int(payload_id)))
            row = await cur.fetchone()
            if not row:
                return None
            return {
                "session_id": int(row["id"]),
                "status": str(row["status"] or "-"),
                "completed_ads": max(0, int(row["completed_ads"] or 0)),
                # B23-3 (5.6): max(0, ...) — the old max(1, ...) turned a
                # legitimate required_ads=0 into a fabricated 1 (an
                # observability lie about the server's own gate).
                "required_ads": max(0, int(row["required_ads"] or 0)),
                "unlock_expires_at": str(row["unlock_expires_at"] or ""),
                "expires_at": str(row["expires_at"] or ""),
            }
        except Exception as e:  # noqa: BLE001 — observability only
            logger.debug("latest_watch_ad_session_progress failed: %s", e)
            return None

    async def watch_ad_session_status_counts(self) -> Dict[str, int]:
        """Session counts by status for the admin Status panel (active pending
        vs TTL-elapsed pending ('stuck') vs rewarded/expired/rejected)."""
        counts = {"pending_active": 0, "pending_stuck": 0, "rewarded": 0,
                  "expired": 0, "rejected": 0, "total": 0}
        try:
            now_iso = datetime.now(timezone.utc).isoformat()
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM watch_ad_sessions WHERE status = 'pending'")
            row = await cur.fetchone()
            pending = int(row["c"]) if row else 0
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM watch_ad_sessions "
                "WHERE status = 'pending' AND expires_at > ?", (now_iso,))
            row = await cur.fetchone()
            counts["pending_active"] = int(row["c"]) if row else 0
            counts["pending_stuck"] = max(0, pending - counts["pending_active"])
            for status, key in (("rewarded", "rewarded"),
                                ("expired", "expired"),
                                ("rejected", "rejected")):
                cur = await self.conn.execute(
                    "SELECT COUNT(*) AS c FROM watch_ad_sessions WHERE status = ?",
                    (status,))
                row = await cur.fetchone()
                counts[key] = int(row["c"]) if row else 0
            counts["total"] = (counts["pending_active"] + counts["pending_stuck"]
                               + counts["rewarded"] + counts["expired"]
                               + counts["rejected"])
        except Exception as e:  # noqa: BLE001
            logger.debug("watch_ad_session_status_counts failed: %s", e)
        return counts

    async def watch_ad_launch_metrics(self,
                                      window_hours: Optional[int] = None
                                      ) -> Dict[str, Any]:
        """V27 (admin metrics): Watch Ads sessions grouped by LAUNCH CONTEXT.

        The V26 ``launch_network_bot_id`` column records WHICH bot's
        [🎬 Watch Ad] button produced each session (the network_bots.id row
        id; NULL/0 = the main bot / a legacy pre-V26 row). This read-only
        rollup turns that routing context into the admin observability the
        worklog asked for: per-launch-bot session volume, the reward funnel
        (rewarded vs expired/rejected), the completion rate, and the most
        recent session time — so an operator can SEE the network-bot share
        of Watch Ads traffic (and spot a network bot whose sessions never
        verify) without touching the production logs.

        Structure (every count honest — no fabrication, missing rows are
        simply zero; orphans are labeled, never silently merged):

        {
          "main":    {"sessions", "rewarded", "pending", "expired",
                      "rejected", "reward_rate", "last_activity"},
          "network": [{"network_bot_id", "telegram_bot_id", "username",
                       "bot_status", "sessions", "rewarded", "pending",
                       "expired", "rejected", "reward_rate",
                       "last_activity"}],   # ordered by sessions DESC
          "unknown": [{"network_bot_id", "sessions", "rewarded",
                       "last_activity"}],   # launch ids with NO network_bots
                                          # row (should be impossible — bots
                                          # are REMOVEd, never deleted — but
                                          # labeled honestly if ever seen)
          "total_sessions": int
        }

        reward_rate is rewarded/sessions rounded to 3 decimals (0.0 when
        there are no sessions). Never mutates state; failures return the
        empty structure (observability must never break the panel).

        V27.1 (windowed variant): ``window_hours`` restricts the rollup to
        sessions created within the last N hours (``WHERE s.created_at >=
        cutoff``, the cutoff computed in UTC exactly like the postback
        ``last_24h`` filter — same isoformat, so the lexicographic string
        comparison the schema's TEXT timestamps rely on stays valid).
        ``None`` (the default) = all-time — every existing caller keeps its
        exact behavior. Clamped to >= 1 (a 0/negative window is treated as
        all-time rather than silently returning nothing).
        """
        cutoff: Optional[str] = None
        if window_hours is not None and int(window_hours) >= 1:
            cutoff = (datetime.now(timezone.utc)
                      - timedelta(hours=int(window_hours))).isoformat()
        empty: Dict[str, Any] = {
            "main": {"sessions": 0, "rewarded": 0, "pending": 0,
                     "expired": 0, "rejected": 0, "reward_rate": 0.0,
                     "last_activity": None},
            "network": [], "unknown": [], "total_sessions": 0,
        }
        try:
            cur = await self.conn.execute(
                """SELECT s.launch_network_bot_id AS nid,
                          b.telegram_bot_id   AS telegram_bot_id,
                          b.username          AS username,
                          b.status            AS bot_status,
                          COUNT(*)            AS sessions,
                          SUM(CASE WHEN s.status = 'rewarded' THEN 1
                                   ELSE 0 END) AS rewarded,
                          SUM(CASE WHEN s.status = 'pending'  THEN 1
                                   ELSE 0 END) AS pending,
                          SUM(CASE WHEN s.status = 'expired'  THEN 1
                                   ELSE 0 END) AS expired,
                          SUM(CASE WHEN s.status = 'rejected' THEN 1
                                   ELSE 0 END) AS rejected,
                          MAX(s.created_at)   AS last_activity
                   FROM watch_ad_sessions s
                   LEFT JOIN network_bots b ON b.id = s.launch_network_bot_id
                   {window_clause}
                   GROUP BY s.launch_network_bot_id
                   ORDER BY sessions DESC""".replace("{window_clause}",
                        "WHERE s.created_at >= ?" if cutoff else ""),
                ((cutoff,) if cutoff else ()))
            rows = await cur.fetchall()
        except Exception as e:  # noqa: BLE001 — observability only
            logger.debug("watch_ad_launch_metrics failed: %s", e)
            return empty

        def _rate(sessions: int, rewarded: int) -> float:
            return round(rewarded / sessions, 3) if sessions else 0.0

        for row in rows:
            nid = row["nid"]
            sessions = int(row["sessions"] or 0)
            rewarded = int(row["rewarded"] or 0)
            last_activity = (str(row["last_activity"])
                             if row["last_activity"] else None)
            if nid is None or int(nid) == 0:
                # NOTE: SQL GROUP BY keeps NULL and 0 as TWO separate
                # groups, but they are the SAME launch context (the main
                # bot / a legacy pre-V26 row) — merge them here.
                m = empty["main"]
                m["sessions"] += sessions
                m["rewarded"] += rewarded
                m["pending"] += int(row["pending"] or 0)
                m["expired"] += int(row["expired"] or 0)
                m["rejected"] += int(row["rejected"] or 0)
                if last_activity and (m["last_activity"] is None
                                      or last_activity > m["last_activity"]):
                    m["last_activity"] = last_activity
            elif row["telegram_bot_id"] is not None:
                empty["network"].append({
                    "network_bot_id": int(nid),
                    "telegram_bot_id": int(row["telegram_bot_id"]),
                    "username": (str(row["username"] or "").lstrip("@")
                                 or None),
                    "bot_status": str(row["bot_status"] or "-"),
                    "sessions": sessions,
                    "rewarded": rewarded,
                    "pending": int(row["pending"] or 0),
                    "expired": int(row["expired"] or 0),
                    "rejected": int(row["rejected"] or 0),
                    "reward_rate": _rate(sessions, rewarded),
                    "last_activity": last_activity,
                })
            else:
                # No matching network_bots row — labeled, never merged.
                empty["unknown"].append({
                    "network_bot_id": int(nid),
                    "sessions": sessions,
                    "rewarded": rewarded,
                    "last_activity": last_activity,
                })
            empty["total_sessions"] += sessions
        empty["main"]["reward_rate"] = _rate(empty["main"]["sessions"],
                                             empty["main"]["rewarded"])
        return empty

    async def watch_ad_payload_launch_metrics(
            self, limit: int = 5,
            window_hours: Optional[int] = None) -> List[Dict[str, Any]]:
        """V27 (admin metrics): the per-PAYLOAD launch-context breakdown.

        The launch rollup above answers "which bot launched the sessions?";
        this answers "where the Watch-Ads traffic actually lives" — the top
        payloads by session volume, each with its reward funnel AND its
        launch split (main-bot sessions vs network-bot sessions), so an
        operator can see which payloads drive network-bot Watch Ads (the
        exact per-payload funnel the worklog suggested).

        Read-only, best-effort (failures return []). Rows (ordered by
        sessions DESC, bounded by ``limit`` 1..20):

        {
          "payload_id", "payload_code", "payload_display",
          "sessions", "rewarded", "pending", "expired", "rejected",
          "reward_rate",            # rewarded/sessions, 3 decimals
          "main_sessions",          # NULL/0 launch context
          "network_sessions",       # launch_network_bot_id > 0
          "last_activity"           # MAX(created_at)
        }

        Sessions whose payload row is missing (LEFT JOIN miss) keep
        payload_code None — the caller renders the numeric id; never
        fabricated. main_sessions + network_sessions == sessions always.

        V27.1 (windowed variant): ``window_hours`` restricts the breakdown
        to sessions created within the last N hours — the same cutoff
        convention as watch_ad_launch_metrics (None = all-time, clamped
        >= 1), so a per-window reconciliation between the two rollups
        stays exact by construction.
        """
        cutoff: Optional[str] = None
        if window_hours is not None and int(window_hours) >= 1:
            cutoff = (datetime.now(timezone.utc)
                      - timedelta(hours=int(window_hours))).isoformat()
        try:
            cur = await self.conn.execute(
                """SELECT s.payload_id      AS payload_id,
                          p.payload         AS payload_code,
                          p.display_name    AS payload_display,
                          COUNT(*)          AS sessions,
                          SUM(CASE WHEN s.status = 'rewarded' THEN 1
                                   ELSE 0 END) AS rewarded,
                          SUM(CASE WHEN s.status = 'pending'  THEN 1
                                   ELSE 0 END) AS pending,
                          SUM(CASE WHEN s.status = 'expired'  THEN 1
                                   ELSE 0 END) AS expired,
                          SUM(CASE WHEN s.status = 'rejected' THEN 1
                                   ELSE 0 END) AS rejected,
                          SUM(CASE WHEN s.launch_network_bot_id IS NULL
                                    OR s.launch_network_bot_id = 0
                                   THEN 1 ELSE 0 END) AS main_sessions,
                          SUM(CASE WHEN s.launch_network_bot_id > 0
                                   THEN 1 ELSE 0 END) AS network_sessions,
                          MAX(s.created_at) AS last_activity
                   FROM watch_ad_sessions s
                   LEFT JOIN payloads p ON p.id = s.payload_id
                   {window_clause}
                   GROUP BY s.payload_id
                   ORDER BY sessions DESC, s.payload_id ASC
                   LIMIT ?""".replace("{window_clause}",
                        "WHERE s.created_at >= ?" if cutoff else ""),
                (((cutoff,) if cutoff else ())
                 + (int(max(1, min(20, limit))),)))
            rows = await cur.fetchall()
        except Exception as e:  # noqa: BLE001 — observability only
            logger.debug("watch_ad_payload_launch_metrics failed: %s", e)
            return []

        out: List[Dict[str, Any]] = []
        for row in rows:
            sessions = int(row["sessions"] or 0)
            rewarded = int(row["rewarded"] or 0)
            out.append({
                "payload_id": int(row["payload_id"]),
                "payload_code": (str(row["payload_code"])
                                 if row["payload_code"] is not None else None),
                "payload_display": (str(row["payload_display"])
                                    if row["payload_display"] is not None
                                    else None),
                "sessions": sessions,
                "rewarded": rewarded,
                "pending": int(row["pending"] or 0),
                "expired": int(row["expired"] or 0),
                "rejected": int(row["rejected"] or 0),
                "reward_rate": (round(rewarded / sessions, 3)
                                if sessions else 0.0),
                "main_sessions": int(row["main_sessions"] or 0),
                "network_sessions": int(row["network_sessions"] or 0),
                "last_activity": (str(row["last_activity"])
                                  if row["last_activity"] else None),
            })
        return out

    async def watch_ad_session_trend(self, window_hours: int = 24,
                                     bucket: str = "hour"
                                     ) -> Dict[str, Any]:
        """V27.2 (admin metrics): HOURLY session buckets + window trend.

        The worklog's own next-step suggestion: the windowed rollups answer
        "how many sessions in the last 24h/7d?" but not "is traffic rising
        or falling?" — this answers it from the same schema with a bucketed
        GROUP BY hour: the last N hour-aligned buckets (zero-filled,
        OLDEST first) plus a THIS-window vs PREVIOUS-window comparison, so
        the admin panel (and the dashboard) can render trend arrows and an
        hourly activity chart without any new infrastructure.

        Structure (every count honest — buckets are zero-filled so the
        chart never fabricates gaps; reconciliation is exact by
        construction):

        {
          "bucket": "hour"|"day",             # V27.3 — the bucketing mode
          "window_hours": N,                 # clamped 1..168
          "buckets": [                       # N entries, oldest first
            {"hour_start": "YYYY-MM-DDTHH",  # the bucket key (see below)
             "sessions": int, "rewarded": int,
             "main_sessions": int,           # NULL/0 launch context
             "network_sessions": int},       # launch_network_bot_id > 0
          ],
          "current":  int,                   # sum(buckets) — exact
          "previous": int,                   # the N hours BEFORE the window
          "rewarded_current": int, "rewarded_previous": int,
          "delta": int, "rewarded_delta": int,
          "trend": "up"|"down"|"flat",          # sessions current vs prev
          "rewarded_trend": "up"|"down"|"flat",
          "peak_hour": "YYYY-MM-DDTHH"|None,    # busiest bucket (latest tie)
          "peak_sessions": int,
          "max_bucket_sessions": int            # max(1, max) — chart scale
        }

        The window is HOUR-ALIGNED (the buckets are the N calendar hours
        ending at the current hour), so ``current`` is exactly the sum of
        the buckets — deliberately its own convention, NOT the
        minute-precise ``window_hours`` cutoff of the V27.1 rollups (which
        would make bucket reconciliation depend on sub-hour insert times).
        Sessions with hour keys outside the generated bucket list (e.g. a
        future-dated row) are simply not bucketed. Read-only; failures
        return the zeroed structure (observability must never break the
        panel). ``window_hours`` <= 0 falls back to 24; the upper bound is
        168 (one week — 168 buckets keeps the payload tiny and the chart
        sane).

        V27.3 (``bucket="day"``): the same rollup DAY-BUCKETED — the
        window becomes the last ``window_hours // 24`` CALENDAR DAYS
        (min 1; with the 168h cap that is at most 7 — one week), the bucket
        keys are ``YYYY-MM-DD`` (still carried in ``hour_start``, the
        field name kept for structure compatibility — check the new
        ``bucket`` field for the mode), and ``previous`` is the same number
        of calendar days immediately BEFORE the window. Day mode keeps
        every guarantee: zero-filled day buckets, ``current ==
        sum(buckets)`` exactly (day-aligned by construction), the
        main/network split, the peak (latest day on ties), the honest
        chart scale. An unknown ``bucket`` value falls back to hour mode
        (never an error — observability must never break the panel).
        """
        try:
            n = int(window_hours)
        except (TypeError, ValueError):
            n = 24
        if n < 1:
            n = 24
        n = min(168, n)

        day_mode = str(bucket).lower() == "day"
        now = datetime.now(timezone.utc)
        if day_mode:
            # 168h → 7 calendar days; n ≤ 168 ⇒ days ≤ 7. Floor, min 1.
            days = max(1, n // 24)
            # The day-bucket keys, oldest first: today-(days-1) .. today.
            keys = [(now - timedelta(days=d)).strftime("%Y-%m-%d")
                    for d in range(days - 1, -1, -1)]
            key_len = 10
            prev_start = (now - timedelta(days=2 * days - 1)
                          ).strftime("%Y-%m-%d")
        else:
            # The N hour-bucket keys, oldest first: floor(now)-(N-1)h .. now.
            keys = [(now - timedelta(hours=h)).strftime("%Y-%m-%dT%H")
                    for h in range(n - 1, -1, -1)]
            key_len = 13
            prev_start = (now - timedelta(hours=2 * n - 1)
                          ).strftime("%Y-%m-%dT%H")
        first_key = keys[0]

        out: Dict[str, Any] = {
            "bucket": "day" if day_mode else "hour",
            "window_hours": n,
            "buckets": [{"hour_start": k, "sessions": 0, "rewarded": 0,
                         "main_sessions": 0, "network_sessions": 0}
                        for k in keys],
            "current": 0, "previous": 0,
            "rewarded_current": 0, "rewarded_previous": 0,
            "delta": 0, "rewarded_delta": 0,
            "trend": "flat", "rewarded_trend": "flat",
            "peak_hour": None, "peak_sessions": 0,
            "max_bucket_sessions": 1,
        }
        try:
            by_key: Dict[str, Dict[str, int]] = {
                b["hour_start"]: b for b in out["buckets"]}
            cur = await self.conn.execute(
                f"""SELECT substr(s.created_at, 1, {key_len}) AS bucket_key,
                          COUNT(*) AS sessions,
                          SUM(CASE WHEN s.status = 'rewarded' THEN 1
                                   ELSE 0 END) AS rewarded,
                          SUM(CASE WHEN s.launch_network_bot_id IS NULL
                                    OR s.launch_network_bot_id = 0
                                   THEN 1 ELSE 0 END) AS main_sessions,
                          SUM(CASE WHEN s.launch_network_bot_id > 0
                                   THEN 1 ELSE 0 END) AS network_sessions
                   FROM watch_ad_sessions s
                   WHERE substr(s.created_at, 1, {key_len}) >= ?
                   GROUP BY bucket_key""",
                (first_key,))
            rows = await cur.fetchall()
            for row in rows:
                b = by_key.get(str(row["bucket_key"]))
                if b is None:      # outside the generated bucket list
                    continue
                b["sessions"] = int(row["sessions"] or 0)
                b["rewarded"] = int(row["rewarded"] or 0)
                b["main_sessions"] = int(row["main_sessions"] or 0)
                b["network_sessions"] = int(row["network_sessions"] or 0)
            cur = await self.conn.execute(
                f"""SELECT COUNT(*) AS sessions,
                          SUM(CASE WHEN s.status = 'rewarded' THEN 1
                                   ELSE 0 END) AS rewarded
                   FROM watch_ad_sessions s
                   WHERE substr(s.created_at, 1, {key_len}) >= ?
                     AND substr(s.created_at, 1, {key_len}) < ?""",
                (prev_start, first_key))
            prow = await cur.fetchone()
        except Exception as e:  # noqa: BLE001 — observability only
            logger.debug("watch_ad_session_trend failed: %s", e)
            return out

        out["current"] = sum(b["sessions"] for b in out["buckets"])
        out["rewarded_current"] = sum(b["rewarded"] for b in out["buckets"])
        out["previous"] = int(prow["sessions"] or 0) if prow else 0
        out["rewarded_previous"] = int(prow["rewarded"] or 0) if prow else 0
        out["delta"] = out["current"] - out["previous"]
        out["rewarded_delta"] = (out["rewarded_current"]
                                 - out["rewarded_previous"])

        def _trend(cur: int, prev: int) -> str:
            return "up" if cur > prev else ("down" if cur < prev else "flat")

        out["trend"] = _trend(out["current"], out["previous"])
        out["rewarded_trend"] = _trend(out["rewarded_current"],
                                       out["rewarded_previous"])
        # The busiest bucket — ties resolved to the LATEST hour (the more
        # operationally relevant one), never fabricated when empty.
        peak = None
        for b in out["buckets"]:
            if b["sessions"] > 0 and (peak is None
                                      or b["sessions"] >= peak["sessions"]):
                peak = b
        if peak is not None:
            out["peak_hour"] = peak["hour_start"]
            out["peak_sessions"] = peak["sessions"]
        out["max_bucket_sessions"] = max(
            1, max(b["sessions"] for b in out["buckets"]))
        return out

    async def recent_active_watch_ad_sessions(self, limit: int = 8
                                               ) -> List[aiosqlite.Row]:
        """Most recent pending (still-valid) ad sessions — 'Inspect active
        sessions' in the admin Status panel. Progress is server truth."""
        try:
            now_iso = datetime.now(timezone.utc).isoformat()
            cur = await self.conn.execute(
                """SELECT s.id, s.user_id, s.payload_id, s.ad_control_mode,
                          s.required_ads, s.completed_ads, s.created_at,
                          s.expires_at, p.payload AS payload_code,
                          p.display_name AS payload_display
                   FROM watch_ad_sessions s
                   LEFT JOIN payloads p ON p.id = s.payload_id
                   WHERE s.status = 'pending' AND s.expires_at > ?
                   ORDER BY s.created_at DESC LIMIT ?""",
                (now_iso, int(max(1, min(50, limit)))))
            return await cur.fetchall()
        except Exception as e:  # noqa: BLE001
            logger.debug("recent_active_watch_ad_sessions failed: %s", e)
            return []
    async def recent_watch_ad_rewards(self, limit: int = 5) -> List[aiosqlite.Row]:
        """Most recent VERIFIED rewards (ledger rows) for the admin panel."""
        try:
            cur = await self.conn.execute(
                """SELECT e.created_at, e.user_id, e.payload_id, e.ad_index,
                          e.event_type, p.payload AS payload_code
                   FROM watch_ad_reward_events e
                   LEFT JOIN payloads p ON p.id = e.payload_id
                   ORDER BY e.created_at DESC LIMIT ?""",
                (int(max(1, min(50, limit))),))
            return await cur.fetchall()
        except Exception as e:  # noqa: BLE001
            logger.debug("recent_watch_ad_rewards failed: %s", e)
            return []
    async def recent_watch_ad_postback_errors(self, limit: int = 5
                                               ) -> List[aiosqlite.Row]:
        """Most recent postback error rows (result='error' = internal DB
        errors answered HTTP 500 so the provider retried)."""
        try:
            cur = await self.conn.execute(
                """SELECT created_at, ymid_prefix, user_id, payload_id,
                          result, http_status
                   FROM watch_ad_postback_log
                   WHERE result = 'error'
                   ORDER BY id DESC LIMIT ?""",
                (int(max(1, min(50, limit))),))
            return await cur.fetchall()
        except Exception as e:  # noqa: BLE001
            logger.debug("recent_watch_ad_postback_errors failed: %s", e)
            return []
    async def prune_watch_ad_postback_log(self, days: int = 7,
                                          keep_max: int = 5000) -> int:
        """Cleanup-loop prune for watch_ad_postback_log: drop rows older than
        `days`, and trim to the most recent `keep_max` rows. Returns the
        number of deleted rows (best-effort, never raises)."""
        try:
            cutoff = (datetime.now(timezone.utc)
                      - timedelta(days=max(1, days))).isoformat()
            cur = await self.conn.execute(
                "DELETE FROM watch_ad_postback_log WHERE created_at < ?",
                (cutoff,))
            deleted = max(0, cur.rowcount or 0)
            cur = await self.conn.execute(
                """DELETE FROM watch_ad_postback_log WHERE id NOT IN (
                       SELECT id FROM watch_ad_postback_log
                       ORDER BY id DESC LIMIT ?)""",
                (int(keep_max),))
            deleted += max(0, cur.rowcount or 0)
            await self.conn.commit()
            return deleted
        except Exception as e:  # noqa: BLE001
            logger.debug("prune_watch_ad_postback_log failed: %s", e)
            return 0
