"""bot settings, start/help messages, dashboard template and branding — settings repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
import logging
from typing import Any, Dict, List, Optional
from app.storage.dbutil import now_iso as _now_iso

logger = logging.getLogger("payload-bot")


class SettingsRepoMixin:
    """bot settings, start/help messages, dashboard template and branding."""

    DASHBOARD_DEFAULTS: Dict[str, str] = {
        # V13: The single dashboard template — premium locked-screen layout.
        # All text the user sees comes from this one field (with placeholders).
        # Dynamic placeholders ({percentage}, {dots}, {motivation}, {unlock_count})
        # are auto-computed by render_referral_dashboard at render time.
        # V13: preview media is on-demand (Watch Preview button) — the dashboard
        # is always a text message now.
        "dashboard_template": (
            "\U0001F512 Premium Content Locked\n"
            "\U0001F3AC {payload_name}\n"
            "Invite {required} friends to unlock this exclusive content.\n"
            "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            "\U0001F4CA Progress\n"
            "{dots}\n"
            "{progress_bar}\n"
            "{current}/{required}\n"
            "{percentage}% Complete\n"
            "\u2728 Only {remaining} more friend(s) left\n"
            "\U0001F680 {unlock_count} people clicked this link\n"
            "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
            "{referral_link}\n"
            "{motivation}"
        ),
        "progress_bar_style": "block",  # block|square|emoji (the only non-template setting)
        "preview_caption_enabled": "1",
        "link_preview_enabled": "0",
        # V14: Dashboard Media banner — a decorative media message sent BEFORE
        # the dashboard text. Completely separate from Preview Media. Empty by
        # default (no banner). Stored as file_id + media_type in dashboard_settings.
        "dashboard_media_file_id": "",
        "dashboard_media_type": "",
    }

    async def get_start_message(self, variant: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM start_message WHERE variant = ?", (variant,)
        )
        return await cur.fetchone()
    async def get_help_message(self, variant: str = "default") -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM help_message WHERE variant = ?", (variant,)
        )
        return await cur.fetchone()
    async def set_help_message(self, variant: str = "default",
                               message_type: Optional[str] = None,
                               file_id: Optional[str] = None,
                               caption: Optional[str] = None,
                               buttons_json: Optional[str] = None,
                               entities: Optional[str] = None,
                               enabled: Optional[int] = None) -> None:
        """Upsert the help_message row for a variant."""
        existing = await self.get_help_message(variant)
        if existing:
            mt = message_type if message_type is not None else existing["message_type"]
            fid = file_id if file_id is not None else existing["file_id"]
            cap = caption if caption is not None else existing["caption"]
            bj = buttons_json if buttons_json is not None else existing["buttons_json"]
            if entities is not None:
                ent_val = entities
            elif caption is not None:
                ent_val = None
            else:
                ent_val = existing["entities"] if "entities" in existing.keys() else None
            en = enabled if enabled is not None else existing["enabled"]
            await self.conn.execute(
                "UPDATE help_message SET message_type=?, file_id=?, caption=?, "
                "buttons_json=?, entities=?, enabled=? WHERE variant=?",
                (mt, fid, cap, bj, ent_val, en, variant),
            )
        else:
            mt = message_type or "text"
            en = 1 if enabled is None else enabled
            await self.conn.execute(
                "INSERT INTO help_message (variant, message_type, file_id, caption, "
                "buttons_json, entities, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (variant, mt, file_id, caption, buttons_json, entities, en),
            )
        await self.conn.commit()
    async def set_start_message(self, variant: str, message_type: Optional[str] = None,
                                file_id: Optional[str] = None,
                                caption: Optional[str] = None,
                                buttons_json: Optional[str] = None,
                                entities: Optional[str] = None) -> None:
        """Upsert the start_message row for a variant.

        BOTV13 Phase 5 (Phase B wired): `entities` is the JSON-serialized list
        of Telegram MessageEntity objects (text_link, bold, italic, etc.). Pass
        None to leave entities unchanged on a partial update; pass an explicit
        empty-string-or-None to clear. The column was added in v22 migration.
        """
        existing = await self.get_start_message(variant)
        if existing:
            mt = message_type if message_type is not None else existing["message_type"]
            fid = file_id if file_id is not None else existing["file_id"]
            cap = caption if caption is not None else existing["caption"]
            bj = buttons_json if buttons_json is not None else existing["buttons_json"]
            # BOTV13 Phase B: persist entities when provided. When the text is
            # being changed (caption is not None), entities MUST be supplied
            # (caller serializes update.message.entities). If caption changed
            # but entities wasn't passed, clear stale entities to avoid
            # offset-mismatch bugs.
            if entities is not None:
                ent_val = entities
            elif caption is not None:
                ent_val = None  # text changed without entities → clear
            else:
                ent_val = existing["entities"] if "entities" in existing.keys() else None
            await self.conn.execute(
                "UPDATE start_message SET message_type=?, file_id=?, caption=?, "
                "buttons_json=?, entities=? WHERE variant=?",
                (mt, fid, cap, bj, ent_val, variant),
            )
        else:
            mt = message_type or "text"
            await self.conn.execute(
                "INSERT INTO start_message (variant, message_type, file_id, caption, "
                "buttons_json, entities) VALUES (?, ?, ?, ?, ?, ?)",
                (variant, mt, file_id, caption, buttons_json, entities),
            )
        await self.conn.commit()
    async def reset_start_message(self, variant: str) -> None:
        await self.conn.execute(
            "DELETE FROM start_message WHERE variant = ?", (variant,)
        )
        await self.conn.commit()
    async def get_setting(self, key: str, default: Optional[str] = None) -> Optional[str]:
        cur = await self.conn.execute(
            "SELECT value FROM bot_settings WHERE key = ?", (key,)
        )
        row = await cur.fetchone()
        return row["value"] if row else default
    async def set_setting(self, key: str, value: str) -> None:
        # WATCH_AD V5 (concurrency fix): serialized under write_lock — an
        # admin settings change (e.g. the Ads Control mode) during an
        # in-flight reward transaction can no longer interleave with (or
        # early-commit) it (spec §39: "admin mode change during an active
        # session").
        async with self.write_lock:
            await self.conn.execute(
                "INSERT INTO bot_settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )
            await self.conn.commit()
    async def get_setting_bool(self, key: str, default: bool) -> bool:
        v = await self.get_setting(key)
        if v is None:
            return default
        return v.lower() in ("1", "true", "yes", "on")
    async def get_setting_int(self, key: str, default: int) -> int:
        v = await self.get_setting(key)
        if v is None:
            return default
        try:
            return int(v)
        except ValueError:
            return default
    async def get_dashboard_setting(self, key: str, campaign_id: Optional[int] = None) -> str:
        """Get a single dashboard setting value (campaign override → global → default)."""
        # Try campaign-specific override first.
        if campaign_id is not None:
            cur = await self.conn.execute(
                "SELECT value FROM dashboard_settings WHERE scope='campaign' AND campaign_id=? AND key=?",
                (campaign_id, key),
            )
            row = await cur.fetchone()
            if row and row["value"] is not None:
                return row["value"]
        # Try global override.
        cur = await self.conn.execute(
            "SELECT value FROM dashboard_settings WHERE scope='global' AND campaign_id IS NULL AND key=?",
            (key,),
        )
        row = await cur.fetchone()
        if row and row["value"] is not None:
            return row["value"]
        # Fall back to hardcoded default.
        return self.DASHBOARD_DEFAULTS.get(key, "")
    async def get_all_dashboard_settings(self, campaign_id: Optional[int] = None) -> Dict[str, str]:
        """Get all dashboard settings as a dict (campaign override merged with global)."""
        result = dict(self.DASHBOARD_DEFAULTS)
        # Global overrides.
        cur = await self.conn.execute(
            "SELECT key, value FROM dashboard_settings WHERE scope='global' AND campaign_id IS NULL"
        )
        for row in await cur.fetchall():
            if row["value"] is not None:
                result[row["key"]] = row["value"]
        # Campaign-specific overrides (take precedence).
        if campaign_id is not None:
            cur = await self.conn.execute(
                "SELECT key, value FROM dashboard_settings WHERE scope='campaign' AND campaign_id=?",
                (campaign_id,),
            )
            for row in await cur.fetchall():
                if row["value"] is not None:
                    result[row["key"]] = row["value"]
        return result
    async def set_dashboard_setting(self, key: str, value: str,
                                     campaign_id: Optional[int] = None) -> None:
        """Set a dashboard setting (upsert)."""
        scope = "campaign" if campaign_id is not None else "global"
        now = _now_iso()
        await self.conn.execute(
            """INSERT INTO dashboard_settings (scope, campaign_id, key, value, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(scope, campaign_id, key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
            (scope, campaign_id, key, value, now),
        )
        await self.conn.commit()
    async def get_dashboard_template(self, campaign_id: Optional[int] = None) -> str:
        """V11: Get the dashboard template, migrating legacy fields on first read.

        If a `dashboard_template` override exists, return it. Otherwise, if any
        legacy per-field settings (header_title, main_description, etc.) exist,
        compose a template from them + persist it (one-time migration). If
        neither exists, return the default template. This guarantees existing
        campaigns continue to render correctly without losing customization.
        """
        settings = await self.get_all_dashboard_settings(campaign_id)
        # 1. Explicit template override wins.
        tmpl = settings.get("dashboard_template", "")
        if tmpl:
            return tmpl
        # 2. Legacy per-field settings → compose + persist (one-time migration).
        legacy_keys = ("header_title", "main_description", "progress_label",
                       "counter_format", "referral_link_label", "footer_text")
        has_legacy = any(settings.get(k) for k in legacy_keys)
        if has_legacy:
            header = settings.get("header_title") or "\U0001F512 Premium Content Locked"
            desc = settings.get("main_description") or "Invite friends to unlock this content."
            prog_label = settings.get("progress_label") or "Progress"
            counter_fmt = settings.get("counter_format") or "{current}/{required}"
            ref_label = settings.get("referral_link_label") or "Invite Link"
            footer = settings.get("footer_text") or ""
            # V13: compose a premium layout that preserves the admin's custom
            # text while adding the dynamic progress display (dots, percentage,
            # motivation, social proof, remaining).
            parts = [
                header,
                desc,
                "\u2501" * 20,
                prog_label,
                "{dots}",
                "{progress_bar}",
                counter_fmt,
                "{percentage}% Complete",
                "\u2728 Only {remaining} more friend(s) left",
                "\U0001F680 {unlock_count} people clicked this link",
                "\u2501" * 20,
                "{motivation}",
            ]
            if ref_label:
                parts.extend([ref_label, "{referral_link}"])
            if footer:
                parts.extend(["", footer])
            composed = "\n".join(parts)
            await self.set_dashboard_setting("dashboard_template", composed, campaign_id)
            logger.info("Dashboard V13: migrated legacy fields → premium template (campaign=%s).",
                        campaign_id)
            return composed
        # 3. No template, no legacy → default.
        return self.DASHBOARD_DEFAULTS["dashboard_template"]
    async def reset_dashboard_settings(self, campaign_id: Optional[int] = None) -> None:
        """Reset dashboard settings to defaults (delete overrides)."""
        if campaign_id is not None:
            await self.conn.execute(
                "DELETE FROM dashboard_settings WHERE scope='campaign' AND campaign_id=?",
                (campaign_id,),
            )
        else:
            await self.conn.execute(
                "DELETE FROM dashboard_settings WHERE scope='global' AND campaign_id IS NULL"
            )
        await self.conn.commit()
    async def get_collection_branding(self, collection_id: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM collection_branding WHERE collection_id = ?", (collection_id,)
        )
        return await cur.fetchone()
    async def set_collection_branding(self, collection_id: str,
                                       title: Optional[str] = None,
                                       description: Optional[str] = None,
                                       banner_file_id: Optional[str] = None,
                                       banner_type: Optional[str] = None) -> None:
        existing = await self.get_collection_branding(collection_id)
        if existing:
            t = title if title is not None else existing["title"]
            d = description if description is not None else existing["description"]
            bf = banner_file_id if banner_file_id is not None else existing["banner_file_id"]
            bt = banner_type if banner_type is not None else existing["banner_type"]
            await self.conn.execute(
                "UPDATE collection_branding SET title=?, description=?, banner_file_id=?, banner_type=? "
                "WHERE collection_id=?",
                (t, d, bf, bt, collection_id),
            )
        else:
            await self.conn.execute(
                "INSERT INTO collection_branding (collection_id, title, description, banner_file_id, banner_type) "
                "VALUES (?, ?, ?, ?, ?)",
                (collection_id, title, description, banner_file_id, banner_type),
            )
        await self.conn.commit()
    async def delete_collection_branding(self, collection_id: str) -> None:
        await self.conn.execute("DELETE FROM collection_branding WHERE collection_id = ?", (collection_id,))
        await self.conn.commit()
    async def get_source_branding(self, index_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM source_branding WHERE index_id = ?", (index_id,)
        )
        return await cur.fetchone()
    async def set_source_branding(self, index_id: int,
                                   source_message_id: Optional[int] = None,
                                   banner_file_id: Optional[str] = None,
                                   banner_type: Optional[str] = None,
                                   source_caption: Optional[str] = None,
                                   source_title: Optional[str] = None) -> None:
        existing = await self.get_source_branding(index_id)
        if existing:
            sets = []
            params: List[Any] = []
            for col, val in [("source_message_id", source_message_id), ("banner_file_id", banner_file_id),
                             ("banner_type", banner_type), ("source_caption", source_caption),
                             ("source_title", source_title)]:
                if val is not None:
                    sets.append(f"{col} = ?")
                    params.append(val)
            if sets:
                params.append(index_id)
                await self.conn.execute(
                    f"UPDATE source_branding SET {', '.join(sets)} WHERE index_id = ?", params)
        else:
            await self.conn.execute(
                "INSERT INTO source_branding (index_id, source_message_id, banner_file_id, banner_type, "
                "source_caption, source_title) VALUES (?, ?, ?, ?, ?, ?)",
                (index_id, source_message_id, banner_file_id, banner_type, source_caption, source_title),
            )
        await self.conn.commit()
