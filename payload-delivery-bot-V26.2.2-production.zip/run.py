#!/usr/bin/env python3
"""Production entrypoint for the Payload Delivery Bot.

Usage:
    python run.py

ARCHITECTURE PROPER BREAKDOWN — the REAL production composition path:

``run.py → app/bootstrap/application.py (composition root)
        → app/presentation/telegram (the runtime namespace)
        → app/services/container.py
        → application/domain/infrastructure modules``

bot.py is GONE — nothing imports it anywhere. The Telegram handler mass
lives in app/presentation/telegram/ and is composed by
app/presentation/telegram/namespace.py (the assembled runtime object).

Environment variables are documented in .env.example and
docs/DEPLOYMENT.md.
"""
from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from app.bootstrap.application import run_production  # noqa: E402

if __name__ == "__main__":
    run_production()
