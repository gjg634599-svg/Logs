#!/usr/bin/env python3
"""v99.05 — OFFLINE STRESS VALIDATION (full-VC-mission efficacy).

Proves, against the REAL packaged sources, the v99.05 acceptance
criteria that the 2026-09-11 v99.03 production runs failed:

  1. RC-14 The operator's ACTUAL deployment style (.py files only, NO
           ZIP anywhere — production runs 3+4) now SELF-HEALS: N
           repeated partial-deployment boot cycles each restore the
           226,371-byte asset from the embedded .py copy with the
           stamp-exact sha256, FD-stable.
  2. RC-15 The production expected_cluster=0 bug: N repeated
           account_session_health() reads with the PRODUCTION cluster
           shape (real account + "__primary__" string key) report
           expected_cluster==1 every time (v99.03 printed 0).
  3. RC-17 N repeated recover-without-restart cycles: mismatch →
           re-verify → heal → verified; the RC-8 gate re-opens every
           time; persistent mismatch keeps refusing.
  4. RC-8  The safety net still holds when BOTH repair sources are
           absent (a genuinely mixed .py deployment): 40 join attempts
           → all refused at entry, ZERO entity-resolution RPCs, FD
           delta == 0.

Run: python3 tools/v9904_stress_validation.py
"""
from __future__ import annotations

import ast
import base64
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import types
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
_SRC = _ROOT / "mediagrab_bot"
sys.path.insert(0, str(_ROOT / "tests"))
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_SRC))  # plain-name deploy_health import (RC-17)

import test_v99_00_vc_pipeline as T  # noqa: E402
import test_v99_02_production_stability as T2  # noqa: E402

PASS, FAIL = [], []
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
_REAL_ASSET = (_SRC / "assets" / "vc_silence_600s.opus").read_bytes()
_REAL_SHA16 = hashlib.sha256(_REAL_ASSET).hexdigest()[:16]


def check(name: str, ok: bool, detail: str = ""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}"
          + (f" — {detail}" if detail else ""))


def _fd_count() -> int:
    try:
        return len(os.listdir("/proc/self/fd"))
    except OSError:
        return -1


def _exec_heal_fns() -> dict:
    import logging as _lg
    ns = {"os": os, "hashlib": hashlib, "json": json,
          "asyncio": __import__("asyncio"),
          "logger": _lg.getLogger("mediagrab"),
          "__name__": "v9904_stress", "__file__": str(_SRC / "bootstrap.py")}
    wanted = {"_v9903_self_heal_disabled", "_v9903_self_heal_zip_candidates",
              "_v9903_self_heal_assets", "_v9904_get_deploy_health",
              "_v9904_reverify_identity"}
    tree = ast.parse(_BOOT_TEXT)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name in wanted:
            seg = ast.get_source_segment(_BOOT_TEXT, node)
            exec(compile(seg, "<bootstrap.py:v99.05-stress>", "exec"), ns)
    return ns


# ---------------------------------------------------------------------------
# 1: RC-14 — repeated .py-only partial-deployment boot-heal cycles
# ---------------------------------------------------------------------------

def scenario_rc14_repeated_partial_deployments():
    fns = _exec_heal_fns()
    os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)
    with tempfile.TemporaryDirectory() as td_s:
        td = Path(td_s)
        module_dir = td / "mediagrab_bot"
        (module_dir / "assets").mkdir(parents=True)
        # The operator's channel delivered the .py files (the embed among
        # them); the asset FILE never arrives:
        (module_dir / "asset_embedded.py").write_bytes(
            (_SRC / "asset_embedded.py").read_bytes())
        stamp = {"assets/vc_silence_600s.opus": _REAL_SHA16}
        n = 25
        fd0 = _fd_count()
        healed = 0
        hash_ok = 0
        oldcwd = os.getcwd()
        os.chdir(td)  # NO ZIP anywhere (the production fact)
        try:
            for _ in range(n):
                # simulate the partial deployment: asset file removed
                asset = module_dir / "assets" / "vc_silence_600s.opus"
                if asset.exists():
                    asset.unlink()
                res = fns["_v9903_self_heal_assets"](
                    stamp, {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
                if res.get("ok") and asset.exists() \
                        and asset.read_bytes() == _REAL_ASSET:
                    healed += 1
                    if hashlib.sha256(
                            asset.read_bytes()).hexdigest()[:16] == _REAL_SHA16:
                        hash_ok += 1
        finally:
            os.chdir(oldcwd)
        fd1 = _fd_count()
        check(f"RC-14: {n}/{n} .py-only boots self-heal the 226,371B asset",
              healed == n, f"healed={healed}")
        check("RC-14: every heal is stamp-sha256-exact", hash_ok == n,
              f"hash_ok={hash_ok}")
        check("RC-14: FD delta across the cycles == 0", fd1 - fd0 == 0,
              f"ΔFD={fd1 - fd0}")


# ---------------------------------------------------------------------------
# 2: RC-15 — repeated session-health reads (production cluster shape)
# ---------------------------------------------------------------------------

def scenario_rc15_repeated_health_reads():
    vw, mt = T2._load_real_voicechat()
    mt._SESSION_HEALTH_REGISTRY.clear()
    mt._find_all_session_files = lambda: [
        Path("/home/container/mediagrab_bot/data/sessions/"
             "cluster_918335829278.session"),
        Path("/home/container/mediagrab_bot/data/sessions/"
             "cluster_919006065076.session"),
    ]
    mt._MTPROTO_ACTIVE_SESSION_PATH = (
        "/home/container/mediagrab_bot/data/sessions/"
        "cluster_918335829278.session")

    class _ProdShapeCluster:
        _accounts = {
            "acc_919006065076": {
                "phone": "+919006065076",
                "session_file": "/home/container/mediagrab_bot/data/"
                                "sessions/cluster_919006065076.session"},
            "__primary__": "acc_919006065076",
        }
    mt.get_userbot_cluster = lambda: _ProdShapeCluster()
    n = 500
    fd0 = _fd_count()
    bad = 0
    for _ in range(n):
        h = mt.account_session_health()
        if h["expected_cluster"] != 1 or h["cluster_accounts"] != 1 \
                or h["live"] != 2:
            bad += 1
    fd1 = _fd_count()
    check(f"RC-15: {n} health reads all report expected_cluster=1 "
          "(v99.03 production: 0)", bad == 0, f"bad={bad}")
    check("RC-15: FD delta across 500 reads == 0", fd1 - fd0 == 0,
          f"ΔFD={fd1 - fd0}")


# ---------------------------------------------------------------------------
# 3: RC-17 — repeated recover-without-restart cycles
# ---------------------------------------------------------------------------

def scenario_rc17_repeated_recovery():
    fns = _exec_heal_fns()
    import deploy_health as dh  # the SAME object the helper resolves
    dh.reset_for_tests()
    os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)
    payload = b"STRESS-ASSET-" * 128
    sha16 = hashlib.sha256(payload).hexdigest()[:16]
    mod_bytes = b"# stress module\n"
    mod_sha = hashlib.sha256(mod_bytes).hexdigest()[:16]
    with tempfile.TemporaryDirectory() as td_s:
        module_dir = Path(td_s) / "mediagrab_bot"
        (module_dir / "assets").mkdir(parents=True)
        (module_dir / "__init__.py").write_bytes(mod_bytes)
        (module_dir / "build_stamp.json").write_text(json.dumps({
            "version": "", "modules": {"__init__.py": mod_sha},
            "assets": {"assets/x.opus": sha16}}))
        b64 = base64.b64encode(payload).decode()
        body = "\n".join('    "' + ln + '"'
                         for ln in textwrap_wrap(b64))
        (module_dir / "asset_embedded.py").write_text(
            f'EMBEDDED_ASSETS = {{\n    "assets/x.opus": {{\n'
            f'        "sha256_16": "{sha16}",\n'
            f'        "size": {len(payload)},\n'
            f'        "b64": (\n{body}\n        ),\n    }},\n}}\n')
        n = 10
        recovered = 0
        for _ in range(n):
            dh.reset_for_tests()
            dh.set_build_identity("mismatch", "assets/x.opus missing",
                                  stamp_version="v99.06",
                                  runtime_version="v99.06")
            assert dh.vc_pipeline_disabled_reason() is not None
            # the operator "repairs" by removing the tampered state —
            # here: the asset file is missing, the embed heals it:
            verdict = fns["_v9904_reverify_identity"](str(module_dir))
            if verdict.get("state") == "verified" \
                    and (module_dir / "assets" / "x.opus").exists():
                dh.set_build_identity(
                    "verified", verdict.get("detail", ""),
                    stamp_version="v99.06", runtime_version="v99.06")
                if dh.vc_pipeline_disabled_reason() is None:
                    recovered += 1
                # re-break for the next cycle:
                (module_dir / "assets" / "x.opus").unlink()
        check(f"RC-17: {n}/{n} recover-without-restart cycles flip the "
              "gate open", recovered == n, f"recovered={recovered}")
        # persistent mismatch keeps refusing:
        dh.reset_for_tests()
        dh.set_build_identity("mismatch", "module mismatch",
                              stamp_version="v99.06", runtime_version="v99.06")
        check("RC-17: persistent mismatch keeps the RC-8 gate CLOSED",
              dh.vc_pipeline_disabled_reason() == "build_identity_mismatch")
        dh.reset_for_tests()


def textwrap_wrap(b64: str, width: int = 76) -> list:
    import textwrap
    return textwrap.wrap(b64, width)


# ---------------------------------------------------------------------------
# 4: RC-8 — the safety net when BOTH repair sources are absent
# ---------------------------------------------------------------------------

def scenario_rc8_no_source_safety_net():
    T._install_fake_telethon()
    pkg = types.ModuleType("mg_v9904_stress")
    pkg.__path__ = []
    sys.modules["mg_v9904_stress"] = pkg
    vw = types.ModuleType("mg_v9904_stress.voicechat")

    class VCTransportError(Exception):
        pass

    vw.VCTransportError = VCTransportError
    vw.VCJoinUnverifiedError = type(
        "VCJoinUnverifiedError", (VCTransportError,), {})
    vw._vc_active_join_backends_by_chat = {}
    vw._vc_entity_negative_clear_for_chat = lambda gid: None
    vw._vc_evict_poisoned_entity_cache = lambda r, m, s: 0
    vw._vc_join_account_eligible = lambda aid, **kw: (True, "ok")
    vw._vc_join_account_rank = lambda aid, **kw: (0.0, 0, 0)
    vw._vc_join_account_record_join = lambda aid: None
    vw._vc_join_account_park_floodwait = lambda a, s, **kw: None
    vw._vc_record_verify_evidence = lambda *a, **k: None
    vw._vc_classify_join_transport_error = lambda t: "deterministic"

    async def _reg(*a, **kw):
        return {}

    async def _get(*a, **kw):
        return None

    vw.vc_registry_register = _reg
    vw.vc_registry_get = _get
    vw.vc_get_backend = lambda account_id="": None

    async def _detect(client, entity):
        return {"call_id": 42, "access_hash": 7}

    vw.vc_detect_active_call = _detect

    async def _part(*a, **kw):
        return "unknown"

    vw.vc_check_telegram_participation = _part

    async def _gone(*a, **kw):
        return "inconclusive"

    vw._vc_call_gone_evidence_check = _gone

    mt = types.ModuleType("mg_v9904_stress.mtproto")
    entity_calls: list = []

    async def _resolve(client, chat_ref, **kw):
        entity_calls.append(chat_ref)

        class _Ent:
            id = 1234567890

        return {"ok": True, "entity": _Ent(), "source": "cache"}

    mt.resolve_vc_entity = _resolve
    mt.get_userbot_cluster = lambda: None
    mt.mtproto_get_client_legacy = lambda: None
    mt.mtproto_get_client = lambda: None
    mt._vc_client_scope = lambda client: "global"
    mt._vc_entity_cache = {}
    mt._v9810_hash_invalid_record = lambda s, c, a: None
    sys.modules["mg_v9904_stress.voicechat"] = vw
    sys.modules["mg_v9904_stress.mtproto"] = mt

    spec = importlib.util.spec_from_file_location(
        "mg_v9904_stress.deploy_health", str(_SRC / "deploy_health.py"))
    dh = importlib.util.module_from_spec(spec)
    sys.modules["mg_v9904_stress.deploy_health"] = dh
    spec.loader.exec_module(dh)

    spec = importlib.util.spec_from_file_location(
        "mg_v9904_stress.vc_pipeline", str(_SRC / "vc_pipeline.py"))
    pipe = importlib.util.module_from_spec(spec)
    sys.modules["mg_v9904_stress.vc_pipeline"] = pipe
    spec.loader.exec_module(pipe)
    pipe._null_stream_suppress_reset_for_tests()

    class _B:
        backend_name = "stress"

        async def _is_target_in_calls_container(self, chat):
            return False

        async def _leave_target(self, chat):
            return None

    async def run():
        # mixed .py deployment: module hash mismatch (NO asset issue) —
        # neither the ZIP nor the embed can repair a MODULE mismatch.
        dh.reset_for_tests()
        dh.set_build_identity(
            "MISMATCH", "mtproto.py: stamp=aa actual=bb (mixed .py set)")
        fd0 = _fd_count()
        entity_calls.clear()
        n_attempts = 40
        refusals = 0
        for i in range(n_attempts):
            try:
                await pipe.run_vc_join(_B(), -1001234500000 + i,
                                       call_id=42, access_hash=999)
            except VCTransportError:
                refusals += 1
        fd1 = _fd_count()
        check("RC-8: mixed-.py deployment → all 40 attempts refused",
              refusals == n_attempts, f"refusals={refusals}")
        check("RC-8: ZERO entity-resolution RPCs", len(entity_calls) == 0,
              f"rpcs={len(entity_calls)}")
        check("RC-8: FD delta == 0", fd1 - fd0 == 0, f"ΔFD={fd1 - fd0}")
        dh.reset_for_tests()

    asyncio_run(run())


def asyncio_run(coro):
    import asyncio
    return asyncio.run(coro)


def main() -> int:
    print("v99.05 OFFLINE STRESS VALIDATION — full-VC-mission efficacy")
    print("=" * 72)
    scenario_rc14_repeated_partial_deployments()
    scenario_rc15_repeated_health_reads()
    scenario_rc17_repeated_recovery()
    scenario_rc8_no_source_safety_net()
    print("=" * 72)
    print(f"SUMMARY: {len(PASS)}/{len(PASS) + len(FAIL)} checks pass")
    if FAIL:
        print("FAILED:", "; ".join(FAIL))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
