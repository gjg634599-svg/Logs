#!/usr/bin/env python3
"""v99.03 — OFFLINE STRESS VALIDATION (deployment-hygiene efficacy).

Proves, against the REAL packaged sources, the v99.03 acceptance
criteria that the 2026-09-11 v99.02 production run (36 min, 40 wasted
joins, ~320 entity-resolution RPCs) failed:

  1. RC-8  With a mismatched identity AND no on-disk ZIP: N join
           attempts → ZERO entity-resolution RPCs, ZERO dispatches
           (v99.02 production: 40 attempts / 320 RPCs).
  2. RC-9  Partial deployment (asset extracted away, ZIP on disk):
           self-heal restores the asset → identity VERIFIED → joins run
           the normal path.
  3. RC-12 Repeated blocked joins for the same chat inside the window:
           1 full pipeline pass + (N-1) zero-RPC refusals (≥80% RPC
           reduction), 1 WARNING + DEBUG repeats + 1 SUPPRESSED summary.
  4. FD    ΔFD == 0 across the whole scenario (the RC-12/RC-8 refusals
           must not add resource pressure).
Run: python3 tools/v9903_stress_validation.py
"""
from __future__ import annotations

import asyncio
import hashlib
import importlib.util
import os
import sys
import tempfile
import types
import zipfile
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent
_SRC = _ROOT / "mediagrab_bot"
sys.path.insert(0, str(_ROOT / "tests"))
sys.path.insert(0, str(_ROOT))

import test_v99_00_vc_pipeline as T  # noqa: E402

PASS, FAIL = [], []


def check(name: str, ok: bool, detail: str = ""):
    (PASS if ok else FAIL).append(name)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}"
          + (f" — {detail}" if detail else ""))


def _fd_count() -> int:
    try:
        return len(os.listdir("/proc/self/fd"))
    except OSError:
        return -1


# ---------------------------------------------------------------------------
# 1 + 3: pipeline refusals / suppression through the REAL vc_pipeline
# ---------------------------------------------------------------------------

def scenario_rc8_and_rc12():
    T._install_fake_telethon()

    pkg = types.ModuleType("mg_v9903_stress")
    pkg.__path__ = []
    sys.modules["mg_v9903_stress"] = pkg
    vw = types.ModuleType("mg_v9903_stress.voicechat")

    class VCTransportError(Exception):
        pass

    class VCJoinUnverifiedError(VCTransportError):
        pass

    vw.VCTransportError = VCTransportError
    vw.VCJoinUnverifiedError = VCJoinUnverifiedError
    vw._vc_active_join_backends_by_chat = {}
    vw._vc_entity_negative_clear_for_chat = lambda gid: None
    vw._vc_evict_poisoned_entity_cache = lambda r, m, s: 0
    vw._vc_join_account_eligible = lambda aid, **kw: (True, "ok")
    vw._vc_join_account_rank = lambda aid, **kw: (0.0, 0, 0)
    vw._vc_join_account_record_join = lambda aid: None
    vw._vc_join_account_park_floodwait = lambda a, s, **kw: None
    vw._vc_record_verify_evidence = lambda *a, **k: None
    vw._vc_classify_join_transport_error = lambda t: "deterministic"

    async def _reg(*a, **kw):
        return {}

    async def _get(*a, **kw):
        return None

    vw.vc_registry_register = _reg
    vw.vc_registry_get = _get
    vw.vc_get_backend = lambda account_id="": None

    async def _detect(client, entity):
        return {"call_id": 42, "access_hash": 7}

    vw.vc_detect_active_call = _detect

    async def _part(*a, **kw):
        return "unknown"

    vw.vc_check_telegram_participation = _part

    async def _gone(*a, **kw):
        return "inconclusive"

    vw._vc_call_gone_evidence_check = _gone

    mt = types.ModuleType("mg_v9903_stress.mtproto")
    entity_calls: list = []

    async def _resolve(client, chat_ref, **kw):
        entity_calls.append(chat_ref)

        class _Ent:
            id = 1234567890

        return {"ok": True, "entity": _Ent(), "source": "cache"}

    mt.resolve_vc_entity = _resolve
    mt.get_userbot_cluster = lambda: None
    mt.mtproto_get_client_legacy = lambda: None
    mt.mtproto_get_client = lambda: None
    mt._vc_client_scope = lambda client: "global"
    mt._vc_entity_cache = {}
    mt._v9810_hash_invalid_record = lambda s, c, a: None
    sys.modules["mg_v9903_stress.voicechat"] = vw
    sys.modules["mg_v9903_stress.mtproto"] = mt

    spec = importlib.util.spec_from_file_location(
        "mg_v9903_stress.deploy_health", str(_SRC / "deploy_health.py"))
    dh = importlib.util.module_from_spec(spec)
    sys.modules["mg_v9903_stress.deploy_health"] = dh
    spec.loader.exec_module(dh)

    spec = importlib.util.spec_from_file_location(
        "mg_v9903_stress.vc_pipeline", str(_SRC / "vc_pipeline.py"))
    pipe = importlib.util.module_from_spec(spec)
    sys.modules["mg_v9903_stress.vc_pipeline"] = pipe
    spec.loader.exec_module(pipe)
    pipe._null_stream_suppress_reset_for_tests()

    class _B:
        backend_name = "stress"

        async def _is_target_in_calls_container(self, chat):
            return False

        async def _leave_target(self, chat):
            return None

    async def run():
        # -- RC-8: mismatch + NO override + NO heal ------------------
        dh.reset_for_tests()
        dh.set_build_identity(
            "MISMATCH", "assets/vc_silence_600s.opus actual=missing")
        fd0 = _fd_count()
        entity_calls.clear()
        n_attempts = 40  # the v99.02 production join count in 36 min
        refusals = 0
        for i in range(n_attempts):
            try:
                await pipe.run_vc_join(_B(), -1001234500000 + i,
                                       call_id=42, access_hash=999)
            except VCTransportError:
                refusals += 1
        fd1 = _fd_count()
        check("RC-8: all 40 join attempts refused",
              refusals == n_attempts, f"refusals={refusals}")
        check("RC-8: ZERO entity-resolution RPCs (v99.02: ~320)",
              len(entity_calls) == 0, f"rpcs={len(entity_calls)}")
        check("RC-8: FD delta across 40 refusals == 0",
              fd1 - fd0 == 0, f"ΔFD={fd1 - fd0}")
        # Override restores the normal path.
        os.environ["VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH"] = "1"
        try:
            entity_calls.clear()
            try:
                await pipe.run_vc_join(_B(), -1001234500000,
                                       call_id=42, access_hash=999)
            except VCTransportError:
                pass
            check("RC-8: env override lets joins run the normal path",
                  len(entity_calls) >= 1)
        finally:
            os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)
        dh.reset_for_tests()

        # -- RC-12: repeated blocked joins, same chat ------------------
        pipe._null_stream_suppress_reset_for_tests()
        entity_calls.clear()
        n = 10
        for _ in range(n):
            try:
                await pipe.run_vc_join(_B(), -1009876543210,
                                       call_id=42, access_hash=999)
            except VCTransportError:
                pass  # gate block or suppressed refusal — both honest
        full_passes = len(entity_calls)
        # Pre-RC-12 world: every join resolves (clear the windows each
        # iteration to emulate no suppression memory).
        pipe._null_stream_suppress_reset_for_tests()
        entity_calls.clear()
        for _ in range(n):
            pipe._NULL_STREAM_SUPPRESS.clear()
            try:
                await pipe.run_vc_join(_B(), -1009876543210,
                                       call_id=42, access_hash=999)
            except VCTransportError:
                pass
        pre_rc12 = len(entity_calls)
        reduction = 1.0 - (full_passes / pre_rc12) if pre_rc12 else 0.0
        check("RC-12: repeats collapse to ONE full pipeline pass",
              full_passes == 1, f"full_passes={full_passes}/{n}")
        check("RC-12: entity-RPC reduction ≥ 80%",
              reduction >= 0.80,
              f"{pre_rc12} → {full_passes} RPCs ({reduction:.0%})")
        # The SUPPRESSED summary fires on flush after window expiry.
        key = (list(pipe._NULL_STREAM_SUPPRESS.keys()) or [None])[0]
        if key is not None:
            pipe._NULL_STREAM_SUPPRESS[key]["window_start"] -= 301.0
            flushed = pipe._null_stream_suppress_flush()
            check("RC-12: SUPPRESSED summary flushed on expiry",
                  flushed >= 1,
                  f"suppressed={pipe._NULL_STREAM_SUPPRESS.get(key, {}).get('suppressed', 0)}")
        else:
            check("RC-12: SUPPRESSED summary flushed on expiry", False,
                  "no window recorded")
        pipe._null_stream_suppress_reset_for_tests()

    asyncio.run(run())


# ---------------------------------------------------------------------------
# 2: RC-9 self-heal on a REAL partial deployment
# ---------------------------------------------------------------------------

def scenario_rc9_partial_deployment():
    import logging
    logging.basicConfig(level=logging.INFO)
    with tempfile.TemporaryDirectory() as td_s:
        td = Path(td_s)
        # The production layout: /home/container/{zip, mediagrab_bot/}
        tree = td / "home" / "container"
        pkg_dir = tree / "mediagrab_bot"
        (pkg_dir / "assets").mkdir(parents=True)
        asset = os.urandom(226_371)  # the shipped asset size
        expected = hashlib.sha256(asset).hexdigest()[:16]
        zip_path = tree / "mediagrab_bot_v99.03_deployment.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("mediagrab_bot/assets/vc_silence_600s.opus", asset)
        # PARTIAL deployment: the operator extracted only .py files —
        # assets/ is EMPTY (the file was never copied).
        stamp_assets = {"assets/vc_silence_600s.opus": expected}
        runtime = {"assets/vc_silence_600s.opus": "missing"}

        sys.path.insert(0, str(_ROOT / "tests"))
        ns = {}
        import ast
        boot_src = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
        wanted = {"_v9903_self_heal_disabled",
                  "_v9903_self_heal_zip_candidates",
                  "_v9903_self_heal_assets"}
        ns = {"os": os, "hashlib": hashlib,
              "logger": logging.getLogger("mediagrab"),
              "__name__": "v9903_stress_heal"}
        tree_ast = ast.parse(boot_src)
        for node in tree_ast.body:
            if isinstance(node, ast.FunctionDef) and node.name in wanted:
                seg = ast.get_source_segment(boot_src, node)
                exec(compile(seg, "<stress-rc9>", "exec"), ns)
        oldcwd = os.getcwd()
        os.chdir(tree)  # cwd = /home/container (the production cwd)
        try:
            res = ns["_v9903_self_heal_assets"](stamp_assets, runtime,
                                                str(pkg_dir))
        finally:
            os.chdir(oldcwd)
        healed = pkg_dir / "assets" / "vc_silence_600s.opus"
        check("RC-9: partial deployment heals from the on-disk ZIP",
              res.get("ok") is True and healed.is_file()
              and healed.read_bytes() == asset,
              f"reason={res.get('reason')}")
        # Post-heal re-hash equals the stamp → identity would be VERIFIED.
        actual = hashlib.sha256(healed.read_bytes()).hexdigest()[:16]
        check("RC-9: healed asset hash == stamp hash (identity VERIFIED)",
              actual == expected, f"{actual} vs {expected}")


if __name__ == "__main__":
    print("=" * 72)
    print("v99.03 OFFLINE STRESS VALIDATION — deployment hygiene")
    print("=" * 72)
    scenario_rc8_and_rc12()
    scenario_rc9_partial_deployment()
    print("-" * 72)
    print(f"RESULT: {len(PASS)} passed, {len(FAIL)} failed")
    if FAIL:
        print("FAILED:", ", ".join(FAIL))
        raise SystemExit(1)
    print("ALL DEPLOYMENT-HYGIENE BOUNDS HOLD")
