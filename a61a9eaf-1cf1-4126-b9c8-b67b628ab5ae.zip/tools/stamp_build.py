#!/usr/bin/env python3
"""v98.12 §21 — build stamper: freeze the packaged source identity.

Usage (from the deployment tree root, BEFORE zipping):
    python3 tools/stamp_build.py

Writes ``mediagrab_bot/build_stamp.json``:
    {
      "version": "<__bot_version__>",
      "built_at": "<UTC isoformat>",
      "modules": {"<file>": "<sha256[:16]>", ...}
    }

At startup (bootstrap.py DEPLOYMENT_IDENTITY) the runtime recomputes the
same hashes and compares them with the stamp:
  * all match    → BUILD_IDENTITY_VERIFIED  (logged INFO)
  * any mismatch → BUILD_IDENTITY_MISMATCH  (logged ERROR, identity line
                    carries stamp_detail=[...] — the (6).log lesson: a
                    runtime log MUST be attributable to an exact source
                    tree; "version=v98.09 + v98.11 hashes" ambiguity is
                    what this closes)

The stamp is a PACKAGING artifact — it belongs in the deployment ZIP and
must NOT be committed to dev trees (dev/test runs log
build_stamp=missing, which is expected and non-fatal).
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import datetime

_MODULES = [
    "voicechat.py", "utils_real.py", "config.py", "mtproto.py",
    "bootstrap.py", "handlers.py", "join_all_worker.py",
    "mtproto_generation.py", "__init__.py",
    # v99 §17: the canonical VC join pipeline is now a stamped core
    # module — its hash MUST be part of the deployment identity (the
    # (6).log lesson: every log must be attributable to an exact tree).
    "vc_pipeline.py",
]

# v99 §17: packaged DATA assets whose integrity the runtime depends on
# (the RC-A silent-stream join requires the bundled silence asset).
_ASSETS = [
    "assets/vc_silence_600s.opus",
]


def main() -> int:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    pkg = os.path.join(root, "mediagrab_bot")
    init_py = os.path.join(pkg, "__init__.py")
    if not os.path.isfile(init_py):
        print(f"ERROR: {init_py} not found (run from the deployment tree root)", file=sys.stderr)
        return 2
    version = "unknown"
    with open(init_py, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("__bot_version__"):
                version = line.split("=", 1)[1].strip().strip('"').strip("'")
                break
    modules: dict[str, str] = {}
    for rel in _MODULES:
        path = os.path.join(pkg, rel)
        try:
            with open(path, "rb") as f:
                modules[rel] = hashlib.sha256(f.read()).hexdigest()[:16]
        except FileNotFoundError:
            print(f"WARN: {rel} missing — skipped", file=sys.stderr)
    assets: dict[str, str] = {}
    for rel in _ASSETS:
        path = os.path.join(pkg, rel)
        try:
            with open(path, "rb") as f:
                assets[rel] = hashlib.sha256(f.read()).hexdigest()[:16]
        except FileNotFoundError:
            print(f"WARN: {rel} missing — skipped", file=sys.stderr)
    stamp = {
        "version": version,
        "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "modules": modules,
        "assets": assets,
    }
    out = os.path.join(pkg, "build_stamp.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(stamp, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"BUILD_STAMP_WRITTEN {out} version={version} modules={len(modules)}")
    for rel, sha in sorted(modules.items()):
        print(f"  {rel}: {sha}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
