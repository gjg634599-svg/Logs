"""v99.11 — Resource telemetry, headroom admission, transport lifecycle.

WHY THIS MODULE EXISTS (the 2026-09-21 production evidence)
-----------------------------------------------------------
The v99.10 run died — kernel OOM SIGKILL, zero Python traceback — while
dispatching the ~47th/48th native VC transport, even though the v99.10
guard (``VC_GUARD_MAX_JOINED=48``, ``VC_GUARD_MAX_RSS_MB=900``) was
active.  Post-mortem correlation of the run against the v99.09 evidence
(2× mid-join SIGKILLs at ~60 joined VCs; 41× ``[Errno 11] Resource
temporarily unavailable`` from native thread/socket-buffer allocation;
FD census plateaued at 409/1024 — NOT fd exhaustion) proves the guard's
threshold model was wrong in three ways:

  1.  ``VC_GUARD_MAX_JOINED=48`` sat EXACTLY at the observed crash
      boundary (the killer join dispatched when joined_transports=46/47
      — 46 < 48 → admitted → allocation → SIGKILL).  A limit placed AT
      the failure point is not a safety margin.
  2.  The fixed ``VC_GUARD_MAX_RSS_MB=900`` ceiling never tripped before
      death, so the container's real memory limit was below what the
      guard modeled for the *native allocation spike* (RSS + socket
      buffer memory + thread stacks reserved during join).
  3.  ``joined_transports`` counted only COMPLETED joins, so up to N
      concurrently-dispatching joins each passed the check while their
      combined native allocations stacked toward the ceiling.

THE v99.11 MODEL (mission §resource-exhaustion-fix)
---------------------------------------------------
Headroom-based admission BEFORE every native VC allocation:

    current usage
      + estimated allocation cost × (in-flight joins + this join)
      + safety headroom
      <  safe boundary

where the safe boundary is measured from the ACTUAL runtime limits
(cgroup v2/v1 memory limit, /proc/meminfo fallback) — not guessed.

Defaults are derived from the measured evidence, not invented:

  * ``VC_MAX_JOINED=40``  — the LOWEST observed hard boundary is 47
    (v99.10 run; v99.09 died at ~60 on a bigger day); 40 ≈ boundary
    minus ~15% margin for the measured per-transport variance
    (~4.3 UDP sockets/VC + threads + SRTP/jitter/decoder buffers).
  * ``VC_JOIN_COST_MB=12`` — conservative committed-memory estimate per
    native pipeline: 4 UDP socket buffers (~0.2-1MB) + 2 native thread
    stacks (~0.5MB committed) + SRTP/jitter/decoder buffers (~2-4MB) +
    Python-side call objects.  Errs high on purpose.
  * ``VC_MEMORY_HEADROOM_MB=64`` — the un-measurable tail (allocator
    fragmentation, page-cache pressure inside the cgroup, RPC spikes
    during join verification).
  * ``VC_MAX_CONCURRENT_JOINS=2`` — bounds the allocation spike itself
    (v99.10's declarative ``max_join_in_flight=3`` was never enforced
    by any semaphore; the crash happened with joins stacking).

Every metric is optional at runtime: an unreadable cgroup, a missing
/proc entry or an unknown value NEVER raises and NEVER blocks on its
own — only KNOWN pressure blocks, and only new joins (an ACTIVE
transport is never touched by admission; pressure defers, it never
destroys — see vc_leave_policy.py for the leave side).

v99.10 COMPATIBILITY: the legacy ``VC_GUARD_*`` env vars are still
honored (as fallbacks when the new names are unset), and
``voicechat._vc_resource_pressure_state`` / ``_vc_resource_pressure_check``
keep their v99.10 contracts (the 43-test v99.10 suite stays green).

ENVIRONMENT (all optional; documented in DEPLOYMENT.md §v99.11):
  VC_RESOURCE_GUARD_ENABLED=true       master switch (false = allow-all)
  VC_MEMORY_SOFT_LIMIT_MB=<MB>         soft boundary (overrides derived)
  VC_MEMORY_HARD_LIMIT_MB=<MB>         used when no cgroup limit is visible
  VC_MEMORY_HEADROOM_MB=64             safety tail inside the boundary
  VC_JOIN_COST_MB=12                   estimated native allocation per join
  VC_MAX_THREADS=320                   native+asyncio thread ceiling
  VC_MAX_FDS=0                         fd ceiling (0 = derive from limits×ratio)
  VC_MAX_JOINED=40                     concurrent joined transports ceiling
  VC_MAX_CONCURRENT_JOINS=2            native join semaphore width
  VC_RESOURCE_SAMPLE_INTERVAL_SECONDS=10  snapshot cache + marker cadence
  VC_GUARD_MAX_RSS_MB / VC_GUARD_MAX_THREADS / VC_GUARD_MAX_JOINED /
  VC_GUARD_FD_RATIO                    v99.10 names (fallbacks, still read)
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger("mediagrab")

# ---------------------------------------------------------------------------
# Environment helpers (never raise; bad values fall back to defaults)
# ---------------------------------------------------------------------------


def _env_int(name: str, default: int, *, minimum: int = 0) -> int:
    """Read an int env var; unparsable/absent/<=minimum → default."""
    try:
        raw = str(os.environ.get(name, "") or "").strip()
        if not raw:
            return default
        val = int(float(raw))
        return val if val > minimum else default
    except Exception:  # noqa: BLE001
        return default


def _env_float(name: str, default: float, *, minimum: float = 0.0) -> float:
    try:
        raw = str(os.environ.get(name, "") or "").strip()
        if not raw:
            return default
        val = float(raw)
        return val if val > minimum else default
    except Exception:  # noqa: BLE001
        return default


def resource_guard_enabled() -> bool:
    """Master switch (default ON; only an explicit falsy value disables)."""
    raw = str(os.environ.get("VC_RESOURCE_GUARD_ENABLED", "") or "").strip().lower()
    if raw in ("0", "false", "no", "off"):
        return False
    return True


# ---------------------------------------------------------------------------
# Defaults — derived from the measured production evidence (see docstring)
# ---------------------------------------------------------------------------

DEFAULT_MAX_JOINED = 40          # lowest observed crash boundary (47) − 15%
DEFAULT_MAX_THREADS = 320        # v99.10 default 350 sat above the crash zone
DEFAULT_JOIN_COST_MB = 12.0      # conservative native pipeline cost
DEFAULT_HEADROOM_MB = 64.0       # un-measurable allocation tail
DEFAULT_MAX_CONCURRENT_JOINS = 2  # bounds the allocation spike
DEFAULT_FD_RATIO = 0.80          # v99.10 value (proven safe: 409/1024 peak)

# v99.11.1 FIX-1 (MEASURED, not assumed): the v99.11 admission model
# used a per-join FD cost of 5 (and its comments assumed "~4.3 UDP
# sockets/VC").  The 2026-09-22/23 production FD_CENSUS evidence
# measured the REAL steady-state cost: idle process = 6 sockets
# (joined=0, 85 flat minutes at fd≈20 after the 23:13 restart); 36-39
# joined transports = 252-282 sockets → ≈ 6.8-7.1 PYTHON-process
# sockets per ACTIVE native transport (the in-process WebRTC stack:
# RTP/RTCP + ICE candidate sockets), plus a transient burst of ~10-11
# per transport DURING the join phase (entity/verification sockets
# released over the following ~10 min: fd 389 → 300 settling observed
# at 00:44-00:59 in bot-diagnostic.log (1).1).  The admission model now
# uses the measured 7 + 1 margin = 8 FDs per projected in-flight join.
DEFAULT_JOIN_FD_COST = 8         # measured ≈7 sockets/transport + 1 margin

# Sentinel: cgroup "no limit" values (v2 "max", v1 ~2^63, totalram) are
# not usable boundaries.
_CGROUP_NO_LIMIT = (1 << 40)  # bytes; anything >= 1TB is "unlimited"


# ---------------------------------------------------------------------------
# ResourceSnapshot — the reliable telemetry abstraction (P0 requirement)
# ---------------------------------------------------------------------------

@dataclass
class ResourceSnapshot:
    """One point-in-time process/system resource measurement.

    Every field is Optional: ``None`` means UNKNOWN (metric could not be
    read on this platform).  Telemetry failure degrades to unknown — it
    must never raise into the caller and never destabilize the bot.
    """
    timestamp: float = 0.0
    pid: int = 0
    rss_mb: Optional[float] = None
    threads: Optional[int] = None
    fd_count: Optional[int] = None
    fd_limit: Optional[int] = None
    joined_transports: int = 0
    active_joins: int = 0
    queued_joins: int = 0
    available_memory_mb: Optional[float] = None
    memory_limit_mb: Optional[float] = None
    cgroup_path: Optional[str] = None
    extras: Dict[str, Any] = field(default_factory=dict)

    @property
    def resource_headroom_mb(self) -> Optional[float]:
        """Usable headroom inside the boundary (None when unknown)."""
        if self.memory_limit_mb is not None and self.rss_mb is not None:
            return max(0.0, self.memory_limit_mb - self.rss_mb)
        if self.available_memory_mb is not None:
            return self.available_memory_mb
        return None


def _read_status_fields() -> Dict[str, Any]:
    """VmRSS/Threads from /proc/self/status (empty on failure)."""
    out: Dict[str, Any] = {}
    try:
        with open("/proc/self/status", "r") as fh:
            for line in fh:
                if line.startswith("VmRSS:"):
                    out["rss_kb"] = int(line.split()[1])
                elif line.startswith("Threads:"):
                    out["threads"] = int(line.split()[1])
    except Exception:  # noqa: BLE001
        pass
    return out


def _read_fd_count() -> Optional[int]:
    try:
        return len(os.listdir("/proc/self/fd"))
    except Exception:  # noqa: BLE001
        return None


def _read_fd_limit() -> Optional[int]:
    try:
        with open("/proc/self/limits", "r") as fh:
            for line in fh:
                if line.startswith("Max open files"):
                    return int(line.split()[3])
    except Exception:  # noqa: BLE001
        pass
    return None


def _cgroup_v2_memory(path: str = "/sys/fs/cgroup") -> Dict[str, Any]:
    """cgroup v2 memory.max / memory.current."""
    out: Dict[str, Any] = {}
    try:
        with open(os.path.join(path, "memory.max"), "r") as fh:
            raw = fh.read().strip()
        if raw and raw != "max":
            limit = int(raw)
            if 0 < limit < _CGROUP_NO_LIMIT:
                out["limit_bytes"] = limit
        with open(os.path.join(path, "memory.current"), "r") as fh:
            out["current_bytes"] = int(fh.read().strip())
    except Exception:  # noqa: BLE001
        pass
    return out


def _cgroup_v1_memory(path: str = "/sys/fs/cgroup/memory") -> Dict[str, Any]:
    """cgroup v1 memory.limit_in_bytes / usage_in_bytes."""
    out: Dict[str, Any] = {}
    try:
        with open(os.path.join(path, "memory.limit_in_bytes"), "r") as fh:
            limit = int(fh.read().strip())
        if 0 < limit < _CGROUP_NO_LIMIT:
            out["limit_bytes"] = limit
        with open(os.path.join(path, "memory.usage_in_bytes"), "r") as fh:
            out["current_bytes"] = int(fh.read().strip())
    except Exception:  # noqa: BLE001
        pass
    return out


def _proc_meminfo() -> Dict[str, int]:
    out: Dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 2 and parts[0] in ("MemTotal:", "MemAvailable:"):
                    try:
                        out[parts[0][:-1]] = int(parts[1])  # kB
                    except Exception:  # noqa: BLE001
                        pass
    except Exception:  # noqa: BLE001
        pass
    return out


def collect_resource_snapshot(
    *,
    joined_transports: int = 0,
    active_joins: int = 0,
    queued_joins: int = 0,
) -> ResourceSnapshot:
    """Gather one ResourceSnapshot.  Platform-safe; never raises.

    Reads (each individually guarded):
      * /proc/self/status          → rss_mb, threads
      * /proc/self/fd + limits     → fd_count, fd_limit
      * cgroup v2, then cgroup v1  → memory_limit_mb, current usage
      * /proc/meminfo              → available_memory_mb (fallback)
    """
    snap = ResourceSnapshot(
        timestamp=time.time(),
        pid=os.getpid(),
        joined_transports=int(joined_transports or 0),
        active_joins=int(active_joins or 0),
        queued_joins=int(queued_joins or 0),
    )
    status = _read_status_fields()
    if "rss_kb" in status:
        snap.rss_mb = float(status["rss_kb"]) / 1024.0
    if "threads" in status:
        snap.threads = int(status["threads"])
    snap.fd_count = _read_fd_count()
    snap.fd_limit = _read_fd_limit()

    # Memory boundary: the ACTUAL container limit when visible.
    cg = _cgroup_v2_memory()
    snap.cgroup_path = "/sys/fs/cgroup" if cg else None
    if not cg:
        cg = _cgroup_v1_memory()
        if cg:
            snap.cgroup_path = "/sys/fs/cgroup/memory"
    if "limit_bytes" in cg:
        snap.memory_limit_mb = cg["limit_bytes"] / (1024.0 * 1024.0)
    if "current_bytes" in cg:
        cur_mb = cg["current_bytes"] / (1024.0 * 1024.0)
        snap.extras["cgroup_current_mb"] = round(cur_mb, 1)
        if snap.memory_limit_mb is not None:
            snap.available_memory_mb = max(
                0.0, snap.memory_limit_mb - cur_mb)
    if snap.available_memory_mb is None:
        mi = _proc_meminfo()
        if "MemAvailable" in mi:
            snap.available_memory_mb = mi["MemAvailable"] / 1024.0
    # An explicitly configured hard limit is the last-resort boundary.
    env_hard = _env_int("VC_MEMORY_HARD_LIMIT_MB", 0)
    if env_hard > 0 and snap.memory_limit_mb is None:
        snap.memory_limit_mb = float(env_hard)
    return snap


# ---------------------------------------------------------------------------
# Headroom-based admission (P0: preflight before EVERY native allocation)
# ---------------------------------------------------------------------------

@dataclass
class AdmissionDecision:
    allowed: bool
    reason: str = ""
    projected_mb: Optional[float] = None
    boundary_mb: Optional[float] = None
    snapshot: Optional[ResourceSnapshot] = None


def admission_limits() -> Dict[str, Any]:
    """Resolve the effective limit set (new env names first, VC_GUARD_*
    v99.10 names as fallbacks so existing deployments keep working)."""
    max_joined = _env_int("VC_MAX_JOINED", 0)
    if max_joined <= 0:
        max_joined = _env_int("VC_GUARD_MAX_JOINED", DEFAULT_MAX_JOINED)
    max_threads = _env_int("VC_MAX_THREADS", 0)
    if max_threads <= 0:
        max_threads = _env_int("VC_GUARD_MAX_THREADS", DEFAULT_MAX_THREADS)
    # v99.10 default preserved (900): the fixed RSS ceiling remains the
    # first-class fallback boundary when no cgroup limit is visible.
    max_rss_mb = _env_int("VC_GUARD_MAX_RSS_MB", 900)
    soft_limit = _env_int("VC_MEMORY_SOFT_LIMIT_MB", 0)
    hard_limit = _env_int("VC_MEMORY_HARD_LIMIT_MB", 0)
    headroom = _env_int("VC_MEMORY_HEADROOM_MB", int(DEFAULT_HEADROOM_MB))
    join_cost = int(_env_float("VC_JOIN_COST_MB", DEFAULT_JOIN_COST_MB))
    fd_ratio = _env_float("VC_GUARD_FD_RATIO", DEFAULT_FD_RATIO)
    max_fds = _env_int("VC_MAX_FDS", 0)
    return {
        "max_joined": max_joined,
        "max_threads": max_threads,
        "max_rss_mb": max_rss_mb,
        "soft_limit_mb": soft_limit,
        "hard_limit_mb": hard_limit,
        "headroom_mb": headroom,
        "join_cost_mb": join_cost,
        "fd_ratio": fd_ratio,
        "max_fds": max_fds,
    }


def evaluate_admission(snap: ResourceSnapshot) -> AdmissionDecision:
    """Headroom admission for ONE new native VC allocation.

    Evaluates:  current + cost×(in-flight + 1) + headroom  <  boundary
    across the dimensions that are KNOWN.  Unknown dimensions are
    skipped (never block on unknown — but also never crash the caller).
    """
    if not resource_guard_enabled():
        return AdmissionDecision(True, "guard_disabled", snapshot=snap)
    lim = admission_limits()

    # --- dimension 1: concurrent joined transports (hard-won evidence) ---
    projected_joined = snap.joined_transports + snap.active_joins + 1
    if lim["max_joined"] > 0 and projected_joined > lim["max_joined"]:
        return AdmissionDecision(
            False,
            f"joined_transports={snap.joined_transports}"
            f"+inflight={snap.active_joins}+1={projected_joined}"
            f">VC_MAX_JOINED({lim['max_joined']})",
            snapshot=snap,
        )

    # --- dimension 2: threads (native+asyncio ceiling) ---
    if snap.threads is not None and lim["max_threads"] > 0:
        # Each in-flight join can add ~2 native threads before it lands.
        projected_threads = snap.threads + 2 * (snap.active_joins + 1)
        if projected_threads >= lim["max_threads"]:
            return AdmissionDecision(
                False,
                f"threads={snap.threads}"
                f"+2×({snap.active_joins}+1)={projected_threads}"
                f">=VC_MAX_THREADS({lim['max_threads']})",
                snapshot=snap,
            )

    # --- dimension 3: file descriptors ---
    if (snap.fd_count is not None and snap.fd_count > 0
            and (snap.fd_limit or 0) > 0):
        ceiling = lim["max_fds"] if lim["max_fds"] > 0 else int(
            snap.fd_limit * lim["fd_ratio"])
        # v99.11.1 FIX-1: the projected per-join FD cost is the MEASURED
        # steady-state (≈7 sockets per active native transport + 1 margin
        # → 8; env-tunable via VC_JOIN_FD_COST), replacing v99.11's
        # assumed 5.  Measured from the 2026-09-22/23 production census:
        # 6 sockets idle / 252-282 at 36-39 joined.  The admission
        # boundary (ratio 0.80 of the soft limit) still sits BELOW the
        # v99.02 FD-guard emergency region (0.85 across two heartbeats),
        # so a new join is deferred BEFORE the process can drift into
        # the guard-restart region.
        join_fd_cost = int(_env_int("VC_JOIN_FD_COST", DEFAULT_JOIN_FD_COST))
        projected_fd = snap.fd_count + join_fd_cost * (snap.active_joins + 1)
        if ceiling > 0 and projected_fd >= ceiling:
            return AdmissionDecision(
                False,
                f"fd_total={snap.fd_count}"
                f"+{join_fd_cost}×({snap.active_joins}+1)"
                f"={projected_fd}>={ceiling}",
                snapshot=snap,
            )

    # --- dimension 4: memory headroom (the OOM killer dimension) ---
    cost = lim["join_cost_mb"]
    headroom = float(lim["headroom_mb"])
    projected_mb: Optional[float] = None
    boundary_mb: Optional[float] = None

    # 4a. explicit v99.10 fixed RSS ceiling (kept for compat)
    if lim["max_rss_mb"] > 0 and snap.rss_mb is not None:
        projected_mb = snap.rss_mb + cost * (snap.active_joins + 1)
        boundary_mb = float(lim["max_rss_mb"])
        if projected_mb >= boundary_mb:
            return AdmissionDecision(
                False,
                f"rss_mb={snap.rss_mb:.0f}+cost={cost}"
                f"×({snap.active_joins}+1)>={boundary_mb:.0f}"
                f"(VC_GUARD_MAX_RSS_MB)",
                projected_mb=projected_mb,
                boundary_mb=boundary_mb,
                snapshot=snap,
            )

    # 4b. explicit soft limit (operator-tuned boundary)
    if lim["soft_limit_mb"] > 0 and snap.rss_mb is not None:
        projected_mb = snap.rss_mb + cost * (snap.active_joins + 1) + headroom
        boundary_mb = float(lim["soft_limit_mb"])
        if projected_mb >= boundary_mb:
            return AdmissionDecision(
                False,
                f"rss_mb={snap.rss_mb:.0f}+cost+headroom="
                f"{projected_mb:.0f}>=VC_MEMORY_SOFT_LIMIT_MB"
                f"({boundary_mb:.0f})",
                projected_mb=projected_mb,
                boundary_mb=boundary_mb,
                snapshot=snap,
            )
        return AdmissionDecision(True, "", projected_mb=projected_mb,
                                 boundary_mb=boundary_mb, snapshot=snap)

    # 4c. the MEASURED container limit (cgroup) — the v99.10 blind spot
    if snap.memory_limit_mb is not None and snap.rss_mb is not None:
        boundary_mb = snap.memory_limit_mb - headroom
        projected_mb = snap.rss_mb + cost * (snap.active_joins + 1)
        if projected_mb >= boundary_mb:
            src = "cgroup" if snap.cgroup_path else "env"
            return AdmissionDecision(
                False,
                f"rss_mb={snap.rss_mb:.0f}+cost={cost}"
                f"×({snap.active_joins}+1)={projected_mb:.0f}"
                f">=limit({snap.memory_limit_mb:.0f})"
                f"-headroom({headroom:.0f}) [{src}]",
                projected_mb=projected_mb,
                boundary_mb=boundary_mb,
                snapshot=snap,
            )
        return AdmissionDecision(True, "", projected_mb=projected_mb,
                                 boundary_mb=boundary_mb, snapshot=snap)

    # 4d. system-wide available memory (last resort signal)
    if snap.available_memory_mb is not None:
        projected_mb = cost * (snap.active_joins + 1) + headroom
        boundary_mb = snap.available_memory_mb
        if projected_mb >= boundary_mb:
            return AdmissionDecision(
                False,
                f"cost+headroom={projected_mb:.0f}>="
                f"MemAvailable({boundary_mb:.0f})",
                projected_mb=projected_mb,
                boundary_mb=boundary_mb,
                snapshot=snap,
            )

    # Everything knowable is clear (or everything unknown — safe pass;
    # the joined/threads/fd dimensions above are the hard evidence).
    return AdmissionDecision(True, "", projected_mb=projected_mb,
                             boundary_mb=boundary_mb, snapshot=snap)


def snapshot_line(snap: ResourceSnapshot) -> str:
    """Machine-searchable VC_RESOURCE_SNAPSHOT payload (one line)."""
    def _f(val: Any, fmt: str = "%.0f") -> str:
        return (fmt % val) if isinstance(val, (int, float)) else "unknown"

    headroom = snap.resource_headroom_mb
    return (
        f"pid={snap.pid} rss_mb={_f(snap.rss_mb)} "
        f"threads={_f(snap.threads, '%d')} fd={_f(snap.fd_count, '%d')}"
        f"/{_f(snap.fd_limit, '%d')} "
        f"joined_transports={snap.joined_transports} "
        f"active_joins={snap.active_joins} queued_joins={snap.queued_joins} "
        f"memory_limit_mb={_f(snap.memory_limit_mb)} "
        f"available_memory_mb={_f(snap.available_memory_mb)} "
        f"resource_headroom_mb={_f(headroom)}"
    )


# ---------------------------------------------------------------------------
# Transport lifecycle (P0: ALLOCATING → ACTIVE → STOPPING → RELEASED/FAILED)
# ---------------------------------------------------------------------------

class TransportState:
    ALLOCATING = "ALLOCATING"
    ACTIVE = "ACTIVE"
    STOPPING = "STOPPING"
    RELEASED = "RELEASED"
    FAILED = "FAILED"


@dataclass
class TransportRecord:
    transport_id: int
    chat_id: int
    account_id: str
    created_at: float
    state: str = TransportState.ALLOCATING
    last_state_change: float = 0.0
    reason: str = ""


class TransportLifecycleTracker:
    """Bounded registry of native transports + leak detection.

    Records are keyed by chat_id (one native transport per chat per
    process — the PyTgCalls container model).  Terminal records
    (RELEASED/FAILED) are pruned after ``retention_seconds`` so the
    registry never grows unboundedly.
    """

    def __init__(self, *, retention_seconds: float = 3600.0,
                 leak_after_seconds: float = 180.0) -> None:
        self._records: Dict[int, TransportRecord] = {}
        self._next_id = 1
        self.retention_seconds = retention_seconds
        self.leak_after_seconds = leak_after_seconds
        self._last_leak_log: Dict[int, float] = {}
        self._last_prune = 0.0

    # -- state transitions -------------------------------------------------
    def mark_allocating(self, chat_id: int, account_id: str = "",
                        reason: str = "") -> TransportRecord:
        rec = TransportRecord(
            transport_id=self._next_id, chat_id=chat_id,
            account_id=account_id or "", created_at=time.time(),
            state=TransportState.ALLOCATING, last_state_change=time.time(),
            reason=reason,
        )
        self._next_id += 1
        self._records[chat_id] = rec
        return rec

    def mark_active(self, chat_id: int, reason: str = "") -> None:
        self._transition(chat_id, TransportState.ACTIVE, reason)

    def mark_stopping(self, chat_id: int, reason: str = "") -> None:
        self._transition(chat_id, TransportState.STOPPING, reason)

    def mark_released(self, chat_id: int, reason: str = "") -> None:
        self._transition(chat_id, TransportState.RELEASED, reason)

    def mark_failed(self, chat_id: int, reason: str = "") -> None:
        self._transition(chat_id, TransportState.FAILED, reason)

    def _transition(self, chat_id: int, state: str, reason: str) -> None:
        rec = self._records.get(chat_id)
        if rec is None:
            # A transport we never saw allocate (e.g. resumed process):
            # create a synthetic record so downstream observation works.
            rec = TransportRecord(
                transport_id=self._next_id, chat_id=chat_id,
                account_id="", created_at=time.time(), state=state,
                last_state_change=time.time(), reason=reason,
            )
            self._next_id += 1
            self._records[chat_id] = rec
            return
        rec.state = state
        rec.last_state_change = time.time()
        if reason:
            rec.reason = reason

    # -- queries -----------------------------------------------------------
    def get_state(self, chat_id: int) -> Optional[str]:
        rec = self._records.get(chat_id)
        return rec.state if rec else None

    def count_active(self) -> int:
        return sum(1 for r in self._records.values()
                   if r.state == TransportState.ACTIVE)

    def records(self) -> Dict[int, TransportRecord]:
        return dict(self._records)

    def prune(self, *, now: Optional[float] = None) -> int:
        """Drop long-retained terminal records.  Returns dropped count."""
        _now = now if now is not None else time.time()
        if self._last_prune and _now - self._last_prune < 60.0:
            return 0
        self._last_prune = _now
        drop = [cid for cid, r in self._records.items()
                if r.state in (TransportState.RELEASED, TransportState.FAILED)
                and (_now - r.last_state_change) > self.retention_seconds]
        for cid in drop:
            self._records.pop(cid, None)
            self._last_leak_log.pop(cid, None)
        return len(drop)

    def sweep_for_leaks(self, *, now: Optional[float] = None) -> list:
        """Detect transports stuck in ALLOCATING/STOPPING beyond the
        threshold — the signature of leaked native resources.  Emits
        VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED (rate-limited per chat).
        """
        _now = now if now is not None else time.time()
        suspects = []
        for cid, rec in list(self._records.items()):
            if rec.state not in (TransportState.ALLOCATING,
                                 TransportState.STOPPING):
                continue
            age = _now - rec.last_state_change
            if age >= self.leak_after_seconds:
                suspects.append((cid, rec, age))
                if _now - self._last_leak_log.get(cid, 0.0) >= 300.0:
                    self._last_leak_log[cid] = _now
                    logger.warning(
                        "VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED chat_id=%s "
                        "account=%s state=%s age=%.0fs transport_id=%d "
                        "reason=%s — transport stuck mid-lifecycle; "
                        "native resources may be retained (v99.11)",
                        cid, rec.account_id or "(global)", rec.state, age,
                        rec.transport_id, rec.reason or "-",
                    )
        return suspects


# Module-level singletons (import-safe; no mediagrab imports → no cycles)
transport_lifecycle = TransportLifecycleTracker()

_snapshot_cache: Dict[str, Any] = {"ts": 0.0, "snap": None}


# ---------------------------------------------------------------------------
# v99.11.1 FIX-1 — FD/socket lifecycle instrumentation
#
# The v99.11 census (BOT_HEARTBEAT / FD_CENSUS every 60s, aggregate class
# counts only) could not attribute FD growth to an OPERATION: the
# 2026-09-22/23 production logs show sockets climbing 282→759 with
# joined_transports FLAT at 39 (≈ +5-7 sockets/min, invisible to every
# log-visible operation), and the operator had no per-operation delta
# evidence.  These helpers give every transport lifecycle operation a
# BEFORE / AFTER / CLEANUP FD delta (VC_FD_OP_DELTA) so the next
# production run pinpoints the leaking operation directly from the log.
# ---------------------------------------------------------------------------

def fd_class_census() -> Dict[str, int]:
    """Classified FD census of THIS process (total/sockets/pipes/files/
    anon/other).  Pure /proc — no allocation, never raises (unknown →
    zero-filled dict with available=False semantics via total<0)."""
    out: Dict[str, int] = {
        "total": -1, "sockets": 0, "pipes": 0, "files": 0,
        "anon": 0, "other": 0,
    }
    try:
        names = os.listdir("/proc/self/fd")
    except Exception:  # noqa: BLE001
        return out
    out["total"] = len(names)
    for _name in names:
        try:
            _tgt = os.readlink(f"/proc/self/fd/{_name}")
        except Exception:  # noqa: BLE001
            out["other"] += 1
            continue
        if _tgt.startswith("socket:"):
            out["sockets"] += 1
        elif _tgt.startswith("pipe:"):
            out["pipes"] += 1
        elif _tgt.startswith("anon_inode:"):
            out["anon"] += 1
        elif _tgt.startswith("/"):
            out["files"] += 1
        else:
            out["other"] += 1
    return out


# Per-(op, chat_id) baselines for the operation-delta instrumentation.
_fd_op_baselines: Dict[Any, Dict[str, int]] = {}


def fd_op_phase(op: str, chat_id: int, phase: str,
                *, account: str = "") -> Dict[str, int]:
    """Record one FD-census phase of a transport lifecycle operation.

    Phases (the required investigation protocol):
      * ``"before"``      — baseline immediately BEFORE the operation
                            (native allocation, leave, recovery, pause…).
      * ``"after"``       — immediately AFTER the operation completed.
      * ``"cleanup"``     — after the operation's cleanup/release path.
      * ``"gc"``          — after event-loop settling / GC where the
                            caller awaits it (best-effort; GC is only
                            advisory for native sockets, which is exactly
                            what this marker makes visible).

    Emits ``VC_FD_OP_DELTA`` with the delta vs the ``before`` baseline AND
    vs the previous phase, classified by socket/pipe/file.  Never raises;
    returns the census dict so callers/tests can assert on it.
    """
    cens = fd_class_census()
    key = (str(op), int(chat_id or 0))
    try:
        if phase == "before":
            _fd_op_baselines[key] = dict(cens)
        base = _fd_op_baselines.get(key)
        if base is not None and base.get("total", -1) >= 0 \
                and cens.get("total", -1) >= 0:
            d_total = cens["total"] - base["total"]
            d_sock = cens["sockets"] - base.get("sockets", 0)
            d_pipe = cens["pipes"] - base.get("pipes", 0)
            d_file = cens["files"] - base.get("files", 0)
            logger.info(
                "VC_FD_OP_DELTA op=%s chat_id=%s phase=%s account=%s "
                "total=%d delta_total=%+d delta_sockets=%+d "
                "delta_pipes=%+d delta_files=%+d "
                "(v99.11.1 FIX-1 per-operation FD instrumentation)",
                op, chat_id, phase, account or "(global)",
                cens["total"], d_total, d_sock, d_pipe, d_file,
            )
        else:
            logger.info(
                "VC_FD_OP_DELTA op=%s chat_id=%s phase=%s account=%s "
                "total=%d (baseline unavailable) "
                "(v99.11.1 FIX-1 per-operation FD instrumentation)",
                op, chat_id, phase, account or "(global)",
                cens.get("total", -1),
            )
        if phase in ("cleanup", "gc"):
            # Operation complete — drop the baseline so the key is not
            # retained (the instrumentation itself must not leak).
            _fd_op_baselines.pop(key, None)
    except Exception:  # noqa: BLE001
        pass
    return cens


# Heartbeat drift detector state (module-level; guarded everywhere).
_fd_drift_state: Dict[str, Any] = {
    "ts": 0.0, "fd_total": -1, "sockets": -1, "joined": -1,
    "suspect_streak": 0, "last_log": 0.0,
}


def fd_drift_evaluate(fd_total: int, joined_transports: int,
                      *, sockets: int = -1,
                      interval_seconds: float = 60.0) -> bool:
    """Detect FD growth WITHOUT corresponding transport growth.

    The measured production leak signature (bot-diagnostic.log (1).1
    20:13→22:53): sockets 282→759 while joined_transports stayed 39 —
    ≈ +5-7 sockets/minute of retained-but-unattributed native sockets,
    invisible to every log-visible operation and to the task census
    (asyncio tasks flat at 37 — the sockets carry no tasks: they are
    in-process native WebRTC sockets, not Telethon TCP connections).

    This runs on every BOT_HEARTBEAT (no new task): when fd_total grows
    ≥ the threshold across a heartbeat interval while joined_transports
    did NOT increase, the drift is flagged with the class breakdown +
    the per-transport arithmetic, at WARNING (VC_FD_DRIFT_SUSPECTED).
    Detection is OBSERVABILITY ONLY — the v99.11 guarantees are
    preserved: no destructive leave of healthy transports, no new
    restarts; admission still defers only NEW joins, and the v99.02
    FD guard remains the last-resort backstop.
    """
    try:
        _now = time.monotonic()
        prev = _fd_drift_state
        if prev["fd_total"] < 0 or fd_total < 0:
            prev.update({"ts": _now, "fd_total": fd_total,
                         "sockets": sockets, "joined": joined_transports})
            return False
        dt = max(0.001, _now - float(prev.get("ts", 0.0) or _now))
        d_fd = fd_total - int(prev.get("fd_total", fd_total))
        d_joined = joined_transports - int(prev.get("joined", joined_transports))
        rate_per_min = d_fd / (dt / 60.0) if dt > 0 else 0.0
        # Threshold: sustained growth ≥ 1 FD/min with joined flat or
        # shrinking (healthy steady-state jitter is ±0-2 per minute; the
        # measured leak was +5-7).
        suspected = (d_fd >= max(1, int(dt / 60.0))
                     and d_joined <= 0 and rate_per_min >= 1.0)
        if suspected:
            _fd_drift_state["suspect_streak"] = \
                int(_fd_drift_state.get("suspect_streak", 0)) + 1
        else:
            _fd_drift_state["suspect_streak"] = 0
        if _fd_drift_state["suspect_streak"] >= 3:
            # Log at most every 5 min (heartbeat cadence guard).
            if _now - float(_fd_drift_state.get("last_log", 0.0)) >= 300.0:
                _fd_drift_state["last_log"] = _now
                per_transport = (
                    fd_total / joined_transports
                    if joined_transports > 0 else 0.0)
                logger.warning(
                    "VC_FD_DRIFT_SUSPECTED fd_total=%d→%d (+%d in %.0fs, "
                    "%.1f/min) sockets=%d joined_transports=%d→%d "
                    "(FLAT/SHRINKING) fd_per_transport=%.1f streak=%d — "
                    "FD/socket growth WITHOUT transport growth: retained "
                    "native sockets (compare against VC_FD_OP_DELTA "
                    "markers for the owning operation; the per-transport "
                    "measured steady-state is ≈7 sockets) (v99.11.1 FIX-1 "
                    "drift observability — no destructive action taken)",
                    prev.get("fd_total"), fd_total, d_fd, dt, rate_per_min,
                    sockets if sockets >= 0 else -1,
                    prev.get("joined"), joined_transports, per_transport,
                    _fd_drift_state["suspect_streak"],
                )
        prev.update({"ts": _now, "fd_total": fd_total,
                     "sockets": sockets, "joined": joined_transports})
        return suspected
    except Exception:  # noqa: BLE001
        return False


def reset_fd_instrumentation() -> None:
    """Test/harness hook: clear the instrumentation baselines + drift
    state (deterministic regression runs)."""
    try:
        _fd_op_baselines.clear()
        _fd_drift_state.update({
            "ts": 0.0, "fd_total": -1, "sockets": -1, "joined": -1,
            "suspect_streak": 0, "last_log": 0.0,
        })
    except Exception:  # noqa: BLE001
        pass


def cached_snapshot(*, joined_transports: int, active_joins: int,
                    queued_joins: int, force: bool = False,
                    ttl: Optional[float] = None) -> ResourceSnapshot:
    """Sample-interval-cached collect (default 10s) so per-join preflight
    checks add no measurable overhead (v99.10 FIX-C contract preserved)."""
    _ttl = ttl if ttl is not None else _env_int(
        "VC_RESOURCE_SAMPLE_INTERVAL_SECONDS", 10, minimum=0)
    _now = time.monotonic()
    if (not force and _snapshot_cache["snap"] is not None
            and (_now - float(_snapshot_cache["ts"])) < max(0.0, _ttl)):
        snap = _snapshot_cache["snap"]
        # refresh the live counters (cheap, always accurate)
        snap.joined_transports = int(joined_transports or 0)
        snap.active_joins = int(active_joins or 0)
        snap.queued_joins = int(queued_joins or 0)
        return snap
    snap = collect_resource_snapshot(
        joined_transports=joined_transports,
        active_joins=active_joins, queued_joins=queued_joins,
    )
    _snapshot_cache["ts"] = _now
    _snapshot_cache["snap"] = snap
    return snap


__all__ = [
    "ResourceSnapshot", "AdmissionDecision", "TransportState",
    "TransportRecord", "TransportLifecycleTracker", "transport_lifecycle",
    "collect_resource_snapshot", "cached_snapshot", "evaluate_admission",
    "admission_limits", "resource_guard_enabled", "snapshot_line",
    "_env_int", "_env_float",
    "DEFAULT_MAX_JOINED", "DEFAULT_MAX_THREADS", "DEFAULT_JOIN_COST_MB",
    "DEFAULT_HEADROOM_MB", "DEFAULT_MAX_CONCURRENT_JOINS", "DEFAULT_FD_RATIO",
    "DEFAULT_JOIN_FD_COST", "fd_class_census", "fd_op_phase",
    "fd_drift_evaluate", "reset_fd_instrumentation",
]
