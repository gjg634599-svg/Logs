"""Configuration module — real implementation extracted from _bot_core.py.

Contains the Config dataclass with all 45+ feature flags, env-var parsing
helpers, and the module-level config singleton.
"""

from __future__ import annotations

import os
from pathlib import Path
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

_PROJECT_ROOT = Path(__file__).resolve().parent


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "")
    if not raw:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _env_list_int(name: str, default: list[int]) -> list[int]:
    raw = os.environ.get(name, "")
    if not raw:
        return list(default)
    out: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        # CODE-A-010: int() accepts negative numbers and surrounding
        # whitespace that str.isdigit() rejects; use try/except instead.
        try:
            out.append(int(part))
        except ValueError:
            continue
    return out or list(default)


# Official Telegram Bot API hard limits.
#   * Cloud Bot API getFile   : 20 MB
#   * Cloud Bot API send      : 50 MB
#   * Local Bot API server    : 2 GB for both (true hard ceiling).
CLOUD_BOT_API_DOWNLOAD_LIMIT_BYTES = 20 * 1024 * 1024
CLOUD_BOT_API_UPLOAD_LIMIT_BYTES = 50 * 1024 * 1024
LOCAL_BOT_API_LIMIT_BYTES = 2 * 1024 * 1024 * 1024


@dataclass(frozen=True)
class Config:
    """Immutable runtime configuration.

    v99.07 FIX-31 (documented contract): the dataclass is frozen, and the
    ONLY sanctioned mutation paths are validate_config() (startup-time
    clamping/coercion) and the bootstrap _cmd_discovermode runtime toggle
    — both exclusively via object.__setattr__ (the frozen-dataclass
    escape hatch). This is INTENTIONAL and preserved by the v99.07
    constraints: no code path may assign config.<field> = ... directly;
    runtime mutation continues via object.__setattr__ only.
    """

    # --- Telegram (Bot API only) ---
    bot_token: str = _env("TG_BOT_TOKEN")

    # --- Local Bot API server (optional, for large files) ---
    local_mode: bool = _env_bool("LOCAL_MODE", False)
    bot_api_base_url: str = _env("BOT_API_BASE_URL", "http://localhost:8081")
    bot_api_file_url: str = _env("BOT_API_FILE_URL", "http://localhost:8081")

    # --- AI ---
    gemini_api_key: str = _env("GEMINI_API_KEY")

    # --- Admin ---
    admin_ids: tuple[int, ...] = tuple(_env_list_int("ADMIN_IDS", []))

    # --- Paths ---
    project_root: Path = _PROJECT_ROOT
    db_path: Path = Path(_env("DB_PATH", str(_PROJECT_ROOT / "data" / "bot.db")))
    downloads_dir: Path = Path(_env("DOWNLOADS_DIR", str(_PROJECT_ROOT / "data" / "downloads")))
    frames_dir: Path = Path(_env("FRAMES_DIR", str(_PROJECT_ROOT / "data" / "frames")))
    # v97 CHAOS-3 FIX: dedicated backups directory — NOT cleaned by periodic_cleanup.
    # Previously backups were written to frames_dir and auto-deleted after 1 hour.
    backups_dir: Path = Path(_env("BACKUPS_DIR", str(_PROJECT_ROOT / "data" / "backups")))

    # --- Limits / performance ---
    max_file_size_mb: int = _env_int("MAX_FILE_SIZE_MB", 5120)
    max_concurrent_downloads: int = _env_int("MAX_CONCURRENT_DOWNLOADS", 4)
    chunk_size_kb: int = _env_int("CHUNK_SIZE_KB", 512)
    download_timeout: int = _env_int("DOWNLOAD_TIMEOUT", 3600)
    max_retries: int = _env_int("MAX_RETRIES", 5)
    num_frames: int = _env_int("NUM_FRAMES", 6)

    # --- Local Bot API Server (v97.21) ---
    # When enabled, PTB sends requests to a local Bot API server instead of
    # the cloud API. This removes the 20MB getFile ceiling (up to 2GB) and
    # allows sending local file paths directly (no re-upload for files
    # already on the same machine as the Bot API server).
    # The Telethon MTProto download pipeline is NOT affected — it remains
    # the primary method for protected/restricted media retrieval.
    local_bot_api_enabled: bool = _env_bool("LOCAL_BOT_API_ENABLED", False)
    local_bot_api_url: str = _env("LOCAL_BOT_API_URL", "http://127.0.0.1:8081")

    # --- Per-user quotas ---
    user_daily_download_limit: int = _env_int("USER_DAILY_DOWNLOAD_LIMIT", 100)
    user_daily_download_bytes_mb: int = _env_int("USER_DAILY_DOWNLOAD_BYTES_MB", 5120)

    # --- Defaults (overridable per-user via Settings) ---
    default_quality: str = "1080p"
    # v97.48 FIX: gemini-2.0-flash is DEPRECATED by Google (404 NOT_FOUND).
    # Changed default to gemini-2.5-flash. Operators can override via
    # DEFAULT_AI_MODEL env var or the /settings command.
    default_ai_model: str = "gemini-2.5-flash"
    default_language: str = "English"

    log_level: str = _env("LOG_LEVEL", "INFO").upper()
    # v99.07 FIX-30: bot_version / log_path were read via
    # getattr(config, ..., default) from bootstrap.py without being
    # declared here. bot_version mirrors the package __bot_version__
    # default (the package __init__ cannot be imported here — cycle);
    # log_path matches the setup_logging() default (bot.log at the
    # project root; utils_real may override at runtime).
    bot_version: str = _env("BOT_BUILD_VERSION", "v99.07")
    log_path: Path = Path(_env("LOG_PATH", str(_PROJECT_ROOT / "bot.log")))

    # --- Webhook (optional; falls back to long-polling) ---
    use_webhook: bool = _env_bool("USE_WEBHOOK", False)
    webhook_url: str = _env("WEBHOOK_URL", "")           # public https URL
    webhook_port: int = _env_int("WEBHOOK_PORT", 8443)
    webhook_path: str = _env("WEBHOOK_PATH", "/webhook")
    webhook_listen: str = _env("WEBHOOK_LISTEN", "127.0.0.1")
    # v99.07 FIX-30: webhook_secret_token was read via
    # getattr(config, "webhook_secret_token", "") from bootstrap.py but
    # never declared — an undeclared attribute on a frozen dataclass that
    # only worked because of the getattr default. Now a real field.
    webhook_secret_token: str = _env("WEBHOOK_SECRET_TOKEN", "")

    # --- Inline mode ---
    inline_enabled: bool = _env_bool("INLINE_ENABLED", True)

    # --- MTProto backend (optional) ---
    mtproto_enabled: bool = _env_bool("MTPROTO_ENABLED", False)
    tg_api_id: int = _env_int("TG_API_ID", 0)
    tg_api_hash: str = _env("TG_API_HASH")
    tg_user_session: str = _env("TG_USER_SESSION", "mediagrab_user")
    mtproto_admin_id: int = _env_int("MTPROTO_ADMIN_ID", 0)

    # --- VC Tour (voice-chat tour, optional) ---
    vc_tour_enabled: bool = _env_bool("VC_TOUR_ENABLED", False)
    vc_stay_minutes: int = _env_int("VC_STAY_MINUTES", 5)
    vc_cooldown_seconds: int = _env_int("VC_COOLDOWN_SECONDS", 30)
    vc_revisit_same_group: bool = _env_bool("VC_REVISIT_SAME_GROUP", False)
    vc_auto_resume_after_manual: bool = _env_bool("VC_AUTO_RESUME_AFTER_MANUAL", True)
    vc_join_notifications: bool = _env_bool("VC_JOIN_NOTIFICATIONS", True)
    vc_leave_notifications: bool = _env_bool("VC_LEAVE_NOTIFICATIONS", True)
    vc_save_history: bool = _env_bool("VC_SAVE_HISTORY", True)
    vc_discovery_limit: int = _env_int("VC_DISCOVERY_LIMIT", 200)
    vc_min_stay_minutes: int = _env_int("VC_MIN_STAY_MINUTES", 1)
    # v97.53: increased default max from 60 to 2880 (48h) to support 1-day and 2-day durations
    vc_max_stay_minutes: int = _env_int("VC_MAX_STAY_MINUTES", 2880)
    # --- Multi-VC participation (evidence-based, NOT hardcoded) ---
    # These are conservative caps for the bounded Join Multiple flow.  They
    # are ONLY used when runtime evidence has proven the backend can
    # genuinely maintain multiple participations (MULTI_TRACKED or higher).
    # Defaults are intentionally small to prevent uncontrolled task storms.
    vc_multi_max_targets: int = _env_int("VC_MULTI_MAX_TARGETS", 10)
    vc_multi_join_concurrency: int = _env_int("VC_MULTI_JOIN_CONCURRENCY", 3)
    vc_multi_join_timeout: int = _env_int("VC_MULTI_JOIN_TIMEOUT", 30)
    vc_multi_stagger_seconds: float = _env_float("VC_MULTI_STAGGER_SECONDS", 2.0)
    vc_reconcile_interval: int = _env_int("VC_RECONCILE_INTERVAL", 300)
    # v98.07 FIX-SS: heartbeat canary — a daemon thread that dumps ALL
    # thread stacks + os._exit(86) when the event-loop liveness stamp goes
    # stale > 180s (converts the F1-class silent 95-min freeze into a
    # ≤3-min crash with a full stack dump). Default ON.
    vc_heartbeat_canary: bool = _env_bool("VC_HEARTBEAT_CANARY", True)
    # v98.08 FIX-XX: optional webhook URL notified by the canary THREAD on
    # trigger (bounded 10s, JSON POST). Empty = disabled (the gate is ON
    # by design; it needs a URL to act).
    vc_canary_notify_webhook: str = os.environ.get("VC_CANARY_NOTIFY_WEBHOOK", "") or ""
    # v98.08 FIX-AAA: post-rotation settle window (seconds) — reconcile
    # re-eligibility + discovery cycle starts deferred while active.
    vc_rotation_settle_seconds: int = _env_int("VC_ROTATION_SETTLE_SECONDS", 45)
    # v98.08 FIX-WW/F7': discovery cycle wall-clock cap (seconds). The
    # v98.07 contract claimed 90s; the observed cycle 1 ran 440s. This is
    # the REAL cap now (per-query deadline check + CAPPED marker).
    vc_discovery_cycle_wall_cap: int = _env_int("VC_DISCOVERY_CYCLE_WALL_CAP", 90)
    # Fix 1/2: auto-refresh intervals for live dashboard + join-all progress.
    vc_dashboard_refresh_interval: int = _env_int("VC_DASHBOARD_REFRESH_INTERVAL", 30)
    vc_join_all_refresh_interval: int = _env_int("VC_JOIN_ALL_REFRESH_INTERVAL", 30)
    # Fix 3: auto-join all active VCs after discovery (off by default).
    vc_auto_join_after_discovery: bool = _env_bool("VC_AUTO_JOIN_AFTER_DISCOVERY", False)
    # VC Watcher: lightweight periodic monitoring for newly started VCs.
    vc_watcher_interval: int = _env_int("VC_WATCHER_INTERVAL", 60)
    # #4/P2 #12: DEPRECATED. Previously allowed the MTProto userbot to join
    # a PUBLIC Telegram group first (via JoinChannelRequest) before detecting
    # + joining a VC.  The current flow (P1 #3) resolves the public group
    # and detects/starts the VC DIRECTLY without requiring group membership
    # first.  This config is retained for backward compatibility but has no
    # effect — the _vc_try_auto_group_join helper is no longer called.
    vc_allow_auto_group_join: bool = _env_bool("VC_ALLOW_AUTO_GROUP_JOIN", False)
    # --- VC Group Discovery (broad public-search discovery subsystem) ---
    # Master enable flag (#32). When True, a supervised background loop runs
    # periodic public-search discovery cycles on vc_discovery_interval.
    vc_discovery_enabled: bool = _env_bool("VC_DISCOVERY_ENABLED", False)
    # Periodic background discovery schedule in seconds (#31).
    vc_discovery_interval: int = _env_int("VC_DISCOVERY_INTERVAL", 3600)
    # Comma-separated search terms / topics / keywords (#3).
    vc_discovery_queries: str = _env("VC_DISCOVERY_QUERIES", "")
    # Cap results per query and per complete discovery cycle (#6).
    vc_discovery_results_per_query: int = _env_int("VC_DISCOVERY_RESULTS_PER_QUERY", 50)
    vc_discovery_max_results_per_cycle: int = _env_int("VC_DISCOVERY_MAX_RESULTS_PER_CYCLE", 500)
    # Search-result pagination pages to inspect per query (#5).
    vc_discovery_pagination_pages: int = _env_int("VC_DISCOVERY_PAGINATION_PAGES", 3)
    # Rate-limit stagger between queries in seconds (#7).
    vc_discovery_search_delay: float = _env_float("VC_DISCOVERY_SEARCH_DELAY", 3.0)
    # Bounded concurrency for metadata checks + VC detection (#22).
    vc_discovery_metadata_concurrency: int = _env_int("VC_DISCOVERY_METADATA_CONCURRENCY", 4)
    # Safety caps per discovery cycle (#40): max queries, runtime (s).
    vc_discovery_max_queries_per_cycle: int = _env_int("VC_DISCOVERY_MAX_QUERIES_PER_CYCLE", 20)
    # v98.07 FIX-TT (fast mode): default 90s (was 600s) — a cycle always
    # COMPLETES and increments the global counter instead of starving the
    # 300s reconcile/60s coverage cadences for 10 minutes.
    vc_discovery_max_runtime_seconds: int = _env_int("VC_DISCOVERY_MAX_RUNTIME_SECONDS", 90)
    # v98.07 FIX-TT (discovery feature upgrade): query-variant expansion
    # (engine supports it; the auto loop previously hard-coded False →
    # every search variants=1).
    vc_discovery_expand: bool = _env_bool("VC_DISCOVERY_EXPAND", True)
    # Stale-group revalidation interval in seconds (#37).
    vc_discovery_stale_revalidate_interval: int = _env_int("VC_DISCOVERY_STALE_REVALIDATE_INTERVAL", 86400)
    # Dead/unavailable group recheck cooldown in seconds (#19, #38).
    vc_discovery_dead_cooldown: int = _env_int("VC_DISCOVERY_DEAD_COOLDOWN", 604800)
    # Per-query failure/FloodWait cooldown in seconds (#19, #20).
    vc_discovery_query_cooldown: int = _env_int("VC_DISCOVERY_QUERY_COOLDOWN", 7200)
    # FloodWait retries per search call (#8).
    vc_discovery_floodwait_max_retries: int = _env_int("VC_DISCOVERY_FLOODWAIT_MAX_RETRIES", 3)
    # Auto-join discovered active VCs into the capacity-aware join path (#17).
    vc_discovery_auto_join: bool = _env_bool("VC_DISCOVERY_AUTO_JOIN", True)
    # --- v98.09-P3: Discovery/Join-All knowledge cache + fast path ---
    # §20 freshness: active-VC knowledge TTL (SHORT — active state changes
    # quickly; default 300s mirrors vc_reconcile_interval cadence).  A fresh
    # cache hit is handed directly to Join-All with NO Telegram RPC.
    vc_knowledge_active_ttl: int = _env_int("VC_KNOWLEDGE_ACTIVE_TTL", 300)
    # §4 fast path master switch: when True (default), a manual Join All
    # consumes fresh knowledge-cache candidates FIRST and decouples the
    # dialog discovery refresh into a background task instead of blocking
    # the critical join path.  Set False to restore the v98.09-P2
    # discovery-then-join sequencing exactly.
    vc_join_all_fast_path: bool = _env_bool("VC_JOIN_ALL_FAST_PATH", True)
    # §4 third preference: bounded Tier-2 refresh quota for STALE active
    # candidates (per Join-All run).  Never a hidden full-scan.
    vc_knowledge_stale_refresh_limit: int = _env_int("VC_KNOWLEDGE_STALE_REFRESH_LIMIT", 40)
    # §11 adaptive pagination: stop fetching further pages when a page
    # yields ZERO new unique chats (duplicate-only page).  Hard upper bound
    # (vc_discovery_pagination_pages) is ALWAYS respected.
    vc_discovery_adaptive_pagination: bool = _env_bool("VC_DISCOVERY_ADAPTIVE_PAGINATION", True)
    # §10 adaptive expansion: skip the expansion/fuzzy variant fan-out when
    # the exact+normalized search already reached the result target.  All
    # variants still run for zero-result queries (discovery quality
    # preserved where it matters).
    vc_discovery_adaptive_expansion: bool = _env_bool("VC_DISCOVERY_ADAPTIVE_EXPANSION", True)
    # --- v98.10 entity-resolution hardening bounds (§32; safe clamps,
    #     env-overridable, NEVER unlimited) ---
    # Account-scoped access-state TTL: how long a remembered
    # "account X resolved entity Y with hash H" entry is trusted before
    # it needs re-validation (§19: ENTITY metadata TTL — deliberately
    # LONG; it is independent of the short active-VC TTL).
    # 300..604800s, default 21600s (6h).
    vc_entity_scope_state_ttl: int = _env_int("VC_ENTITY_SCOPE_STATE_TTL", 21600)
    # Scoped stale-hash hint TTL: how long a REJECTED (scope, hash) pair
    # suppresses replaying THAT hash from THAT scope (§10/§11 — never an
    # exclusion; the owning scope is unaffected).  30..86400s, default 300s.
    vc_entity_hash_invalid_ttl: int = _env_int("VC_ENTITY_HASH_INVALID_TTL", 300)
    # Bounded size of the account-scoped access state + hash-invalid
    # stores (oldest-entry eviction; §32 no unlimited structures).
    # 1000..200000 entries, default 20000.
    vc_entity_scope_state_max_entries: int = _env_int(
        "VC_ENTITY_SCOPE_STATE_MAX_ENTRIES", 20000)
    # --- v98.11 entity-resolution convergence bounds (§29; safe clamps,
    #     env-overridable, NEVER unlimited) ---
    # Per-account dialogs index TTL: how long the ONE dialogs scan that
    # feeds resolve_entity_full Step 4 is reused before a re-scan (the
    # v98.11 fix for the per-resolution 300-dialog cascade — §24).
    # 60..3600s, default 300s.
    vc_entity_dialogs_index_ttl: int = _env_int(
        "VC_ENTITY_DIALOGS_INDEX_TTL", 300)
    # Typed-probe RPC timeout for the fast-recovery/rotation pre-probe
    # (§6): 2..30s, default 8s (matches the v98.10 Step 0b/0c cap).
    vc_entity_probe_timeout: int = _env_int(
        "VC_ENTITY_PROBE_TIMEOUT", 8)
    # --- Feature A/B: default query pool + managed queries + mode ---
    # Built-in default public-discovery query pool (Feature A #1).  When
    # VC_DISCOVERY_QUERIES is empty AND no manual SQLite queries exist, the
    # subsystem automatically uses this pool.  Comma-separated.
    vc_discovery_default_queries: str = _env(
        "VC_DISCOVERY_DEFAULT_QUERIES",
        "voice chat,group call,vc group,voice group chat,"
        "music vc,study group vc,english speaking vc,radio vc"
    )
    # Discovery query-merge mode: "fallback" (custom first, builtin only if
    # no custom), "mixed" (builtin + custom merged), "custom_only" (never
    # use builtin).  Feature A #5, #72, #73, Query-merge #66-#73.
    vc_discovery_mode: str = _env("VC_DISCOVERY_MODE", "fallback")
    # Maximum query string length for managed-query validation (#47).
    vc_discovery_query_max_length: int = _env_int("VC_DISCOVERY_QUERY_MAX_LENGTH", 100)
    # --- Adaptive Autonomous Discovery Engine ---
    # Master enable for autonomous query generation + scoring + rotation.
    # When True, the engine learns new query candidates from discovered
    # group titles/usernames/descriptions, scores them by yield, and
    # rotates them into the search schedule.
    vc_discovery_autonomous: bool = _env_bool("VC_DISCOVERY_AUTONOMOUS", True)
    # Max autonomous queries to keep in the pool (bounded memory).
    vc_discovery_autonomous_pool_size: int = _env_int("VC_DISCOVERY_AUTONOMOUS_POOL_SIZE", 200)
    # Min score to keep an autonomous query alive (below = retired).
    vc_discovery_autonomous_min_score: float = _env_float("VC_DISCOVERY_AUTONOMOUS_MIN_SCORE", -5.0)
    # Max autonomous queries to generate per cycle (from learned metadata).
    vc_discovery_autonomous_gen_per_cycle: int = _env_int("VC_DISCOVERY_AUTONOMOUS_GEN_PER_CYCLE", 10)
    # Score adjustment: +N per unique group found, -N per zero-result run.
    vc_discovery_autonomous_score_per_unique: float = _env_float("VC_DISCOVERY_AUTONOMOUS_SCORE_PER_UNIQUE", 1.0)
    vc_discovery_autonomous_penalty_per_zero: float = _env_float("VC_DISCOVERY_AUTONOMOUS_PENALTY_PER_ZERO", 0.5)
    # Consecutive zero-result runs before retiring a query.
    vc_discovery_autonomous_retire_after_zeros: int = _env_int("VC_DISCOVERY_AUTONOMOUS_RETIRE_AFTER_ZEROS", 5)

    # --- v98.09 ARCHITECTURE HARDENING (boundedness model) ---
    # ALL defaults preserve v98.08 behavior exactly (each mirrors an
    # existing effective concurrency/cardinality in the v98.08 code —
    # see VC_ARCH_BUDGETS in vc_architecture.py for rationale + env
    # override + min/max). These are INTERNAL budgets surfaced as config
    # for operator override; nothing here changes any v98.08 option's
    # meaning or default.
    # Concurrency budgets (§14 backpressure).
    vc_arch_max_discovery_in_flight: int = _env_int("VC_ARCH_MAX_DISCOVERY_IN_FLIGHT", 4)
    vc_arch_max_entity_resolution_in_flight: int = _env_int("VC_ARCH_MAX_ENTITY_RESOLUTION_IN_FLIGHT", 8)
    vc_arch_max_classification_in_flight: int = _env_int("VC_ARCH_MAX_CLASSIFICATION_IN_FLIGHT", 4)
    vc_arch_max_join_in_flight: int = _env_int("VC_ARCH_MAX_JOIN_IN_FLIGHT", 3)
    vc_arch_max_reconcile_in_flight: int = _env_int("VC_ARCH_MAX_RECONCILE_IN_FLIGHT", 4)
    # Queue / memory / task budgets (§30).
    vc_arch_max_dispatch_queue_depth: int = _env_int("VC_ARCH_MAX_DISPATCH_QUEUE_DEPTH", 200)
    vc_arch_negcache_max_entries: int = _env_int("VC_ARCH_NEGCACHE_MAX_ENTRIES", 10000)
    vc_arch_task_population_bound: int = _env_int("VC_ARCH_TASK_POPULATION_BOUND", 5000)
    # Retry budget (§21 — preserves the v98.08 FIX-ZZ sliding window).
    vc_arch_retry_budget_per_window: int = _env_int("VC_ARCH_RETRY_BUDGET_PER_WINDOW", 25)
    vc_arch_retry_window_seconds: int = _env_int("VC_ARCH_RETRY_WINDOW_SECONDS", 60)

    # --- Talkative Mode (conversational AI, Task ID 16) ---
    # Global enable + provider selection. Per-chat enable is in
    # ``talkative_chat_settings``. The handler is registered in a LATE handler
    # group (group=10) so every other workflow takes priority.
    talkative_enabled: bool = _env_bool("TALKATIVE_ENABLED", False)
    talkative_provider: str = _env("TALKATIVE_PROVIDER", "groq")
    # Groq (primary recommended provider).
    groq_api_key: str = _env("GROQ_API_KEY")
    groq_model: str = _env("GROQ_MODEL", "llama-3.3-70b-versatile")
    # OpenRouter (fallback / alternative).
    openrouter_api_key: str = _env("OPENROUTER_API_KEY")
    openrouter_model: str = _env("OPENROUTER_MODEL", "")
    # Session + memory.
    talkative_session_timeout: int = _env_int("TALKATIVE_SESSION_TIMEOUT", 300)
    talkative_memory_turns: int = _env_int("TALKATIVE_MEMORY_TURNS", 10)
    talkative_cooldown_seconds: int = _env_int("TALKATIVE_COOLDOWN_SECONDS", 3)
    # Group context (recent chat history fed to the model as context).
    talkative_group_context_enabled: bool = _env_bool("TALKATIVE_GROUP_CONTEXT_ENABLED", True)
    talkative_group_context_messages: int = _env_int("TALKATIVE_GROUP_CONTEXT_MESSAGES", 8)
    talkative_private_auto_reply: bool = _env_bool("TALKATIVE_PRIVATE_AUTO_REPLY", True)
    talkative_max_reply_chars: int = _env_int("TALKATIVE_MAX_REPLY_CHARS", 3500)
    talkative_request_timeout: int = _env_int("TALKATIVE_REQUEST_TIMEOUT", 30)
    talkative_typing_enabled: bool = _env_bool("TALKATIVE_TYPING_ENABLED", True)
    talkative_global_rpm: int = _env_int("TALKATIVE_GLOBAL_RPM", 30)
    # --- Adaptive Multimodal Context-Aware Talkative Engine ---
    # Per-group mode: off / chat / vc / both.  Global default + per-group override.
    talkative_default_mode: str = _env("TALKATIVE_DEFAULT_MODE", "off")
    # Engagement scoring thresholds (0.0-1.0).
    talkative_engagement_threshold: float = _env_float("TALKATIVE_ENGAGEMENT_THRESHOLD", 0.5)
    talkative_ambient_probability: float = _env_float("TALKATIVE_AMBIENT_PROBABILITY", 0.05)
    # Anti-spam budget: max bot messages per group per minute.
    talkative_max_replies_per_minute: int = _env_int("TALKATIVE_MAX_REPLIES_PER_MINUTE", 5)
    # Max consecutive bot messages before forced silence.
    talkative_max_consecutive_bot: int = _env_int("TALKATIVE_MAX_CONSECUTIVE_BOT", 2)
    # Memory importance + decay.
    talkative_memory_ttl_seconds: int = _env_int("TALKATIVE_MEMORY_TTL_SECONDS", 3600)
    talkative_memory_summarize_threshold: int = _env_int("TALKATIVE_MEMORY_SUMMARIZE_THRESHOLD", 20)
    # VC audio: minimum silence (seconds) before bot speaks.
    talkative_vc_min_silence: float = _env_float("TALKATIVE_VC_MIN_SILENCE", 1.5)
    # VC audio: max consecutive bot turns.
    talkative_vc_max_consecutive_turns: int = _env_int("TALKATIVE_VC_MAX_CONSECUTIVE_TURNS", 2)
    # VC audio: max bot speaking duration (seconds).
    talkative_vc_max_speaking_duration: int = _env_int("TALKATIVE_VC_MAX_SPEAKING_DURATION", 30)
    # VC audio: STT/TTS language (auto = detect from transcription).
    talkative_vc_stt_language: str = _env("TALKATIVE_VC_STT_LANGUAGE", "auto")
    talkative_vc_tts_voice: str = _env("TALKATIVE_VC_TTS_VOICE", "default")
    # VC audio: latency budget (seconds) — cancel stale responses.
    talkative_vc_latency_budget: float = _env_float("TALKATIVE_VC_LATENCY_BUDGET", 8.0)
    # Privacy: VC transcript retention (0 = off, N seconds = retain).
    talkative_vc_transcript_retention: int = _env_int("TALKATIVE_VC_TRANSCRIPT_RETENTION", 0)
    # --- Context-Aware Sticker, GIF & Media Reaction Engine ---
    # Master enable for media reactions (stickers/GIFs/animations).
    talkative_media_enabled: bool = _env_bool("TALKATIVE_MEDIA_ENABLED", True)
    # Media cooldown between reactions (seconds).
    talkative_media_cooldown: int = _env_int("TALKATIVE_MEDIA_COOLDOWN", 30)
    # Max consecutive media replies before forcing text.
    talkative_media_max_consecutive: int = _env_int("TALKATIVE_MEDIA_MAX_CONSECUTIVE", 2)
    # Duplicate suppression window (seconds) — don't resend same media.
    talkative_media_dedup_window: int = _env_int("TALKATIVE_MEDIA_DEDUP_WINDOW", 300)
    # Base probability of choosing media (vs text) when engaged.
    talkative_media_probability: float = _env_float("TALKATIVE_MEDIA_PROBABILITY", 0.15)

    # V52 Multimodal & Voice subsystem — master switch + feature toggles.
    # Backward-compatible: talkative_media_enabled remains as legacy alias.
    talkative_multimodal_enabled: bool = _env_bool("TALKATIVE_MULTIMODAL_ENABLED", True)
    talkative_voice_understand: bool = _env_bool("TALKATIVE_VOICE_UNDERSTAND", False)
    talkative_voice_replies: bool = _env_bool("TALKATIVE_VOICE_REPLIES", False)
    talkative_match_reply_type: bool = _env_bool("TALKATIVE_MATCH_REPLY_TYPE", False)
    talkative_voice_clone_enabled: bool = _env_bool("TALKATIVE_VOICE_CLONE_ENABLED", False)
    talkative_clone_for_voice_msgs: bool = _env_bool("TALKATIVE_CLONE_FOR_VOICE_MSGS", False)
    talkative_clone_voice_in_vc: bool = _env_bool("TALKATIVE_CLONE_VOICE_IN_VC", False)
    talkative_use_voice_everywhere: bool = _env_bool("TALKATIVE_USE_VOICE_EVERYWHERE", False)
    talkative_standard_tts_fallback: bool = _env_bool("TALKATIVE_STANDARD_TTS_FALLBACK", True)
    talkative_sticker_replies: bool = _env_bool("TALKATIVE_STICKER_REPLIES", False)
    talkative_context_stickers: bool = _env_bool("TALKATIVE_CONTEXT_STICKERS", False)
    talkative_gif_replies: bool = _env_bool("TALKATIVE_GIF_REPLIES", False)
    talkative_native_reactions: bool = _env_bool("TALKATIVE_NATIVE_REACTIONS", False)
    talkative_image_understanding: bool = _env_bool("TALKATIVE_IMAGE_UNDERSTANDING", False)
    talkative_gif_understanding: bool = _env_bool("TALKATIVE_GIF_UNDERSTANDING", False)
    talkative_sticker_understanding: bool = _env_bool("TALKATIVE_STICKER_UNDERSTANDING", False)
    talkative_media_dedup: bool = _env_bool("TALKATIVE_MEDIA_DEDUP", True)
    talkative_voice_reply_policy: str = _env("TALKATIVE_VOICE_REPLY_POLICY", "voice_only")

    # V42 Fix #20: diagnostic logging — when True, DEBUG/INFO goes to a
    # separate bot-diagnostic.log. When False (default), only ERROR/CRITICAL
    # goes to the main bot.log (production mode).
    diagnostic_logging: bool = _env_bool("DIAGNOSTIC_LOGGING", False)

    # V43 Fix #4: explicit admin-controlled provider fallback.
    # When the primary provider fails, the bot will ONLY try fallback providers
    # if this is explicitly set. Credentials alone never imply fallback consent.
    # Format: comma-separated provider names in priority order, e.g. "gemini,groq".
    # Empty = no fallback (fail gracefully).
    talkative_fallback_providers: str = _env("TALKATIVE_FALLBACK_PROVIDERS", "")

    # ─── Multimodal AI (V86 upgrade) ───────────────────────────────────
    witai_enabled: bool = _env_bool("WITAI_ENABLED", False)
    witai_server_token: str = _env("WITAI_SERVER_TOKEN", "")
    voice_provider: str = _env("VOICE_PROVIDER", "auto")  # auto|witai|gemini|groq|openrouter
    intent_provider: str = _env("INTENT_PROVIDER", "auto")  # auto|witai|gemini|groq
    vision_provider: str = _env("VISION_PROVIDER", "gemini")  # gemini|groq|openrouter
    multimodal_enabled: bool = _env_bool("MULTIMODAL_ENABLED", True)
    voice_reply_enabled: bool = _env_bool("VOICE_REPLY_ENABLED", False)
    voice_reply_language: str = _env("VOICE_REPLY_LANGUAGE", "auto")
    ocr_enabled: bool = _env_bool("OCR_ENABLED", True)
    video_summarization_enabled: bool = _env_bool("VIDEO_SUMMARIZATION_ENABLED", True)
    audio_summarization_enabled: bool = _env_bool("AUDIO_SUMMARIZATION_ENABLED", True)
    multimodal_max_image_bytes: int = _env_int("MULTIMODAL_MAX_IMAGE_BYTES", 20 * 1024 * 1024)
    multimodal_max_audio_bytes: int = _env_int("MULTIMODAL_MAX_AUDIO_BYTES", 100 * 1024 * 1024)  # 100 MB
    multimodal_max_audio_seconds: int = _env_int("MULTIMODAL_MAX_AUDIO_SECONDS", 300)
    witai_api_url: str = _env("WITAI_API_URL", "https://api.wit.ai")

    @property
    def mtproto_configured(self) -> bool:
        """True if MTProto can be started (enabled + has credentials)."""
        return (self.mtproto_enabled
                and self.tg_api_id
                and self.tg_api_hash
                and self.tg_user_session)

    @property
    def vc_admin_ids(self) -> tuple[int, ...]:
        """IDs authorised to control the VC tour (admin IDs + MTProto admin)."""
        ids = set(self.admin_ids)
        if self.mtproto_admin_id:
            ids.add(self.mtproto_admin_id)
        return tuple(ids)

    # --- Derived ---
    @property
    def max_file_size_bytes(self) -> int:
        return self.max_file_size_mb * 1024 * 1024

    @property
    def chunk_size_bytes(self) -> int:
        return max(64 * 1024, self.chunk_size_kb * 1024)

    @property
    def download_limit_bytes(self) -> int:
        """Effective download ceiling: configured limit capped by Bot API backend.

        CODE-A-004: Cloud Bot API only allows downloading files up to 20 MB via
        getFile; local Bot API servers allow up to 2 GB. Without this cap the
        bot would attempt downloads that are guaranteed to fail on cloud mode.
        v97.21: also respect local_bot_api_enabled (same as local_mode).
        """
        _is_local = self.local_mode or self.local_bot_api_enabled
        cap = LOCAL_BOT_API_LIMIT_BYTES if _is_local else CLOUD_BOT_API_DOWNLOAD_LIMIT_BYTES
        return min(self.max_file_size_bytes, cap)

    @property
    def upload_limit_bytes(self) -> int:
        """Bot API sendDocument ceiling. Cloud=50MB, local=2GB."""
        if self.local_mode or self.local_bot_api_enabled:
            return LOCAL_BOT_API_LIMIT_BYTES
        return CLOUD_BOT_API_UPLOAD_LIMIT_BYTES

    @property
    def user_daily_download_bytes(self) -> int:
        return self.user_daily_download_bytes_mb * 1024 * 1024

    def ensure_dirs(self) -> None:
        for path in (self.downloads_dir, self.frames_dir, self.backups_dir, self.db_path.parent):
            path.mkdir(parents=True, exist_ok=True)

    def validate_config(self) -> None:
        """#22 + V40 Fix #7: validate config values at startup.

        Validates AND clamps all Discovery/VC timing, concurrency,
        result-limit, refresh, retry, timeout, and runtime env values
        centrally.  Prevents zero/negative intervals, invalid concurrency,
        pathological result limits, immediate retry loops, and unsafe
        timeout values.  Does NOT rely only on warnings — invalid values
        are clamped to safe defaults.
        """
        import logging as _lg
        _log = _lg.getLogger("mediagrab")

        # v99.07 FIX-29: the `default` parameter was accepted by every call
        # site but NEVER used (the body clamps to [lo, hi] per CODE-A-002,
        # and the docstring's "set default" promise was never delivered).
        # The misleading parameter is removed; the docstring now tells the
        # truth. All ~70 call sites drop the dead argument.
        def _clamp_int(name: str, val: int, lo: int, hi: int) -> None:
            """Clamp an int field to [lo, hi]; warn + clamp if out of range."""
            v = int(val)
            if v < lo or v > hi:
                # CODE-A-002: clamp to the actual clamped value (not the default).
                clamped = max(lo, min(hi, v))
                _log.warning(
                    "CONFIG: %s=%d is out of range [%d, %d] — clamping to %d.",
                    name, v, lo, hi, clamped)
                object.__setattr__(self, name, clamped)

        def _clamp_float(name: str, val: float, lo: float, hi: float) -> None:
            """Clamp a float field to [lo, hi]; warn + clamp if out of range."""
            v = float(val)
            if v < lo or v > hi:
                # CODE-A-002: clamp to the actual clamped value (not the default).
                clamped = max(lo, min(hi, v))
                _log.warning(
                    "CONFIG: %s=%s is out of range [%s, %s] — clamping to %s.",
                    name, v, lo, hi, clamped)
                object.__setattr__(self, name, clamped)

        # --- Talkative mode/provider (existing #22 validation) ---
        valid_modes = ("off", "chat", "vc", "both")
        mode = (self.talkative_default_mode or "off").strip().lower()
        if mode not in valid_modes:
            _log.warning(
                "CONFIG: invalid TALKATIVE_DEFAULT_MODE='%s' — defaulting to 'off'. "
                "Valid: %s", self.talkative_default_mode, ", ".join(valid_modes))
            object.__setattr__(self, "talkative_default_mode", "off")
        else:
            object.__setattr__(self, "talkative_default_mode", mode)
        valid_providers = ("groq", "openrouter", "gemini")
        prov = (self.talkative_provider or "groq").strip().lower()
        if prov not in valid_providers:
            _log.warning(
                "CONFIG: invalid TALKATIVE_PROVIDER='%s' — defaulting to 'groq'. "
                "Valid: %s", self.talkative_provider, ", ".join(valid_providers))
            object.__setattr__(self, "talkative_provider", "groq")

        # --- V86 multimodal: Wit.ai / voice / intent / vision provider guards ---
        # Wit.ai requires a server token; without one, silently disable so
        # downstream code can short-circuit on `witai_service.available`.
        if self.witai_enabled and not (self.witai_server_token or "").strip():
            _log.warning(
                "CONFIG: WITAI_ENABLED=true but WITAI_SERVER_TOKEN is empty — "
                "disabling Wit.ai integration.")
            object.__setattr__(self, "witai_enabled", False)
        valid_voice = ("auto", "witai", "gemini", "groq")  # V87: openrouter removed — no STT support
        vp = (self.voice_provider or "auto").strip().lower()
        if vp not in valid_voice:
            _log.warning(
                "CONFIG: invalid VOICE_PROVIDER='%s' — defaulting to 'auto'. "
                "Valid: %s", self.voice_provider, ", ".join(valid_voice))
            object.__setattr__(self, "voice_provider", "auto")
        else:
            object.__setattr__(self, "voice_provider", vp)
        valid_intent = ("auto", "witai", "gemini", "groq")
        ip = (self.intent_provider or "auto").strip().lower()
        if ip not in valid_intent:
            _log.warning(
                "CONFIG: invalid INTENT_PROVIDER='%s' — defaulting to 'auto'. "
                "Valid: %s", self.intent_provider, ", ".join(valid_intent))
            object.__setattr__(self, "intent_provider", "auto")
        else:
            object.__setattr__(self, "intent_provider", ip)

        # --- V40 Fix #7: VC Tour / Multi-VC timing bounds ---
        _clamp_int("vc_stay_minutes", self.vc_stay_minutes, 1, 1440)
        _clamp_int("vc_cooldown_seconds", self.vc_cooldown_seconds, 0, 86400)
        _clamp_int("vc_min_stay_minutes", self.vc_min_stay_minutes, 1, 1440)
        _clamp_int("vc_max_stay_minutes", self.vc_max_stay_minutes, 1, 10080)  # v97.53: max 7 days (10080 min)
        if self.vc_min_stay_minutes > self.vc_max_stay_minutes:
            _log.warning("CONFIG: vc_min_stay_minutes > vc_max_stay_minutes — swapping.")
            object.__setattr__(self, "vc_min_stay_minutes", self.vc_max_stay_minutes)
        _clamp_int("vc_discovery_limit", self.vc_discovery_limit, 1, 10000)

        # --- Multi-VC participation bounds ---
        _clamp_int("vc_multi_max_targets", self.vc_multi_max_targets, 1, 100)
        _clamp_int("vc_multi_join_concurrency", self.vc_multi_join_concurrency, 1, 20)
        _clamp_int("vc_multi_join_timeout", self.vc_multi_join_timeout, 5, 300)
        _clamp_float("vc_multi_stagger_seconds", self.vc_multi_stagger_seconds, 0.0, 60.0)
        _clamp_int("vc_reconcile_interval", self.vc_reconcile_interval, 30, 86400)

        # --- Auto-refresh interval bounds (Fix 1/2) ---
        _clamp_int("vc_dashboard_refresh_interval", self.vc_dashboard_refresh_interval, 5, 3600)
        _clamp_int("vc_join_all_refresh_interval", self.vc_join_all_refresh_interval, 5, 3600)

        # --- VC Watcher interval ---
        _clamp_int("vc_watcher_interval", self.vc_watcher_interval, 10, 86400)

        # --- Discovery timing / concurrency / limit bounds ---
        _clamp_int("vc_discovery_interval", self.vc_discovery_interval, 60, 86400)
        _clamp_int("vc_discovery_results_per_query", self.vc_discovery_results_per_query, 1, 500)
        _clamp_int("vc_discovery_max_results_per_cycle", self.vc_discovery_max_results_per_cycle, 1, 5000)
        _clamp_int("vc_discovery_pagination_pages", self.vc_discovery_pagination_pages, 1, 20)
        _clamp_float("vc_discovery_search_delay", self.vc_discovery_search_delay, 0.5, 300.0)
        _clamp_int("vc_discovery_metadata_concurrency", self.vc_discovery_metadata_concurrency, 1, 32)
        _clamp_int("vc_discovery_max_queries_per_cycle", self.vc_discovery_max_queries_per_cycle, 1, 200)
        _clamp_int("vc_discovery_max_runtime_seconds", self.vc_discovery_max_runtime_seconds, 30, 7200)
        _clamp_int("vc_discovery_stale_revalidate_interval", self.vc_discovery_stale_revalidate_interval, 300, 604800)
        _clamp_int("vc_discovery_dead_cooldown", self.vc_discovery_dead_cooldown, 300, 604800)
        _clamp_int("vc_discovery_query_cooldown", self.vc_discovery_query_cooldown, 60, 604800)
        _clamp_int("vc_discovery_floodwait_max_retries", self.vc_discovery_floodwait_max_retries, 0, 10)
        _clamp_int("vc_discovery_query_max_length", self.vc_discovery_query_max_length, 3, 500)

        # --- v98.09-P3 knowledge-cache / fast-path bounds ---
        # Active TTL: 30s..86400s (short by design — §20). Default 300s.
        _clamp_int("vc_knowledge_active_ttl", self.vc_knowledge_active_ttl, 30, 86400)
        # Stale refresh quota: 0..500 Tier-2 verifications per Join-All run.
        _clamp_int("vc_knowledge_stale_refresh_limit", self.vc_knowledge_stale_refresh_limit, 0, 500)

        # --- v98.10 entity-resolution hardening bounds (§32) ---
        # Scoped access-state TTL: 300..604800s (entity metadata freshness —
        # LONG, independent of the active-VC TTL per §19). Default 21600s.
        _clamp_int("vc_entity_scope_state_ttl", self.vc_entity_scope_state_ttl, 300, 604800)
        # Scoped hash-invalid hint TTL: 30..86400s. Default 300s.
        _clamp_int("vc_entity_hash_invalid_ttl", self.vc_entity_hash_invalid_ttl, 30, 86400)
        # Scoped store size bound: 1000..200000 entries. Default 20000.
        _clamp_int("vc_entity_scope_state_max_entries", self.vc_entity_scope_state_max_entries, 1000, 200000)

        # --- v98.11 entity-resolution convergence bounds (§29) ---
        # Per-account dialogs index TTL: 60..3600s. Default 300s.
        _clamp_int("vc_entity_dialogs_index_ttl", self.vc_entity_dialogs_index_ttl, 60, 3600)
        # Typed-probe timeout: 2..30s. Default 8s.
        _clamp_int("vc_entity_probe_timeout", self.vc_entity_probe_timeout, 2, 30)

        # --- Autonomous Discovery bounds ---
        _clamp_int("vc_discovery_autonomous_pool_size", self.vc_discovery_autonomous_pool_size, 1, 2000)
        _clamp_float("vc_discovery_autonomous_min_score", self.vc_discovery_autonomous_min_score, -100.0, 100.0)
        _clamp_int("vc_discovery_autonomous_gen_per_cycle", self.vc_discovery_autonomous_gen_per_cycle, 0, 100)
        _clamp_float("vc_discovery_autonomous_score_per_unique", self.vc_discovery_autonomous_score_per_unique, 0.0, 10.0)
        _clamp_float("vc_discovery_autonomous_penalty_per_zero", self.vc_discovery_autonomous_penalty_per_zero, 0.0, 10.0)
        _clamp_int("vc_discovery_autonomous_retire_after_zeros", self.vc_discovery_autonomous_retire_after_zeros, 1, 50)

        # --- v98.09 Architecture Hardening budgets (§29: every new limit
        # has default/rationale/override/min/max; clamps mirror
        # VC_ARCH_BUDGETS in vc_architecture.py — the startup validator
        # (§28) additionally rejects impossible COMBINATIONS). ---
        _clamp_int("vc_arch_max_discovery_in_flight", self.vc_arch_max_discovery_in_flight, 1, 64)
        _clamp_int("vc_arch_max_entity_resolution_in_flight", self.vc_arch_max_entity_resolution_in_flight, 1, 64)
        _clamp_int("vc_arch_max_classification_in_flight", self.vc_arch_max_classification_in_flight, 1, 64)
        _clamp_int("vc_arch_max_join_in_flight", self.vc_arch_max_join_in_flight, 1, 32)
        _clamp_int("vc_arch_max_reconcile_in_flight", self.vc_arch_max_reconcile_in_flight, 1, 64)
        _clamp_int("vc_arch_max_dispatch_queue_depth", self.vc_arch_max_dispatch_queue_depth, 1, 10000)
        _clamp_int("vc_arch_negcache_max_entries", self.vc_arch_negcache_max_entries, 100, 1000000)
        _clamp_int("vc_arch_task_population_bound", self.vc_arch_task_population_bound, 100, 100000)
        _clamp_int("vc_arch_retry_budget_per_window", self.vc_arch_retry_budget_per_window, 1, 1000)
        _clamp_int("vc_arch_retry_window_seconds", self.vc_arch_retry_window_seconds, 1, 3600)

        # --- Talkative timing bounds ---
        _clamp_int("talkative_session_timeout", self.talkative_session_timeout, 10, 86400)
        _clamp_int("talkative_memory_turns", self.talkative_memory_turns, 1, 100)
        _clamp_int("talkative_cooldown_seconds", self.talkative_cooldown_seconds, 0, 3600)
        _clamp_int("talkative_group_context_messages", self.talkative_group_context_messages, 1, 50)
        _clamp_int("talkative_max_reply_chars", self.talkative_max_reply_chars, 100, 10000)
        _clamp_int("talkative_request_timeout", self.talkative_request_timeout, 5, 120)
        _clamp_int("talkative_global_rpm", self.talkative_global_rpm, 1, 1000)
        _clamp_float("talkative_engagement_threshold", self.talkative_engagement_threshold, 0.0, 1.0)
        _clamp_float("talkative_ambient_probability", self.talkative_ambient_probability, 0.0, 1.0)
        _clamp_int("talkative_max_replies_per_minute", self.talkative_max_replies_per_minute, 1, 100)
        _clamp_int("talkative_max_consecutive_bot", self.talkative_max_consecutive_bot, 1, 20)
        _clamp_int("talkative_memory_ttl_seconds", self.talkative_memory_ttl_seconds, 0, 604800)
        _clamp_int("talkative_memory_summarize_threshold", self.talkative_memory_summarize_threshold, 5, 200)
        _clamp_float("talkative_vc_min_silence", self.talkative_vc_min_silence, 0.0, 30.0)
        _clamp_int("talkative_vc_max_consecutive_turns", self.talkative_vc_max_consecutive_turns, 1, 20)
        _clamp_int("talkative_vc_max_speaking_duration", self.talkative_vc_max_speaking_duration, 5, 300)
        _clamp_float("talkative_vc_latency_budget", self.talkative_vc_latency_budget, 1.0, 60.0)
        _clamp_int("talkative_media_cooldown", self.talkative_media_cooldown, 0, 3600)
        _clamp_int("talkative_media_max_consecutive", self.talkative_media_max_consecutive, 1, 20)
        _clamp_int("talkative_media_dedup_window", self.talkative_media_dedup_window, 0, 86400)
        _clamp_float("talkative_media_probability", self.talkative_media_probability, 0.0, 1.0)


# CODE-A-001: logger is set up BEFORE config.validate_config() so that
# validation warnings flow through the configured logger (dedup filter,
# file handler, etc.). setup_logging() is defined further down and called
# there; validate_config() is invoked immediately after that call.
config = Config()

