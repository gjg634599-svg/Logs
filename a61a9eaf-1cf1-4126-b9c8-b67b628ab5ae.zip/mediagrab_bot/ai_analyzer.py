"""AI analyzer — Gemini-based analysis for video frames, audio, and images.

Physically reconstructed (the previous migration left this as a 20-line stub).

Provides:
  - analyze_frames / analyze_audio / analyze_images — async entry points
    returning a normalised dict consumed by ``ai_modes.render_result``.
  - _get_client — cached google.genai Client factory.
  - _read_bytes / _run_in_thread / _extract_text — async helpers.
  - _parse_json / _strip_codefences / _find_first_json_object — JSON extraction.
  - _build_parts / _build_audio_parts — genai Part builders.
  - cleanup_frames — temp-file cleanup.
  - _client_cache_key / _lru_cap / _CLIENT_CACHE_MAX / _CLIENT_ERROR_TTL — cache plumbing.

Uses google.genai for multimodal content generation. The SDK is lazy-imported
inside _get_client so the bot runs without it installed (analysis calls fail
gracefully with a clear error).
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Callable, TypeVar

logger = logging.getLogger("mediagrab")

T = TypeVar("T")

# ===========================================================================
# Client cache plumbing
# ===========================================================================

_CLIENT_CACHE_MAX: int = 8
_CLIENT_ERROR_TTL: float = 30.0

# v99.07 FIX-40: OrderedDict-backed so _lru_cap evicts the TRUE
# least-recently-used entry (the old dict popped the oldest INSERTED
# key — FIFO despite the name/docstring saying LRU).
_client_cache: "OrderedDict[tuple, Any]" = OrderedDict()
_client_error_cache: "OrderedDict[tuple, float]" = OrderedDict()
# v99.07 FIX-26: bounded registry of analysis threads abandoned by a
# caller-side asyncio.wait_for timeout — asyncio.to_thread has NO
# cancellation path, so the thread keeps running; it is tracked here
# and reaped (exception retrieved, no 'never retrieved' warnings).
_abandoned_thread_futures: set = set()


def _reap_abandoned_thread(fut) -> None:
    """v99.07 FIX-26: retrieve + drop an abandoned analysis future."""
    _abandoned_thread_futures.discard(fut)
    if fut.cancelled():
        return
    exc = fut.exception()  # retrieved — silences the never-retrieved warning
    if exc is not None:
        logger.debug(
            "GEMINI_ABANDONED_THREAD_COMPLETED exc=%s: %s (v99.07 FIX-26)",
            type(exc).__name__, str(exc)[:120],
        )


def _client_cache_key(api_key: str | None, model: str | None) -> tuple:
    """Build a hashable cache key from (api_key, model)."""
    return ("genai", api_key or "<default>", model or "<default>")


def _lru_cap(cache: "OrderedDict", max_size: int) -> None:
    """Cap a dict-based cache to ``max_size`` (TRUE LRU eviction).

    v99.07 FIX-40: the cache must be an OrderedDict whose hit path calls
    move_to_end(key) — then evicting from the front removes the
    least-recently-USED entry. (The previous implementation popped the
    oldest INSERTED key, which is FIFO — the name and docstring said LRU.)
    """
    while len(cache) > max_size:
        try:
            oldest = next(iter(cache))
            cache.pop(oldest, None)
        except StopIteration:
            break


def _get_client(api_key: str | None = None, model: str | None = None) -> Any:
    """Return a cached ``google.genai.Client`` (creates one on first call).

    Uses the Gemini API key from config if ``api_key`` is not provided.
    Caches by (api_key, model) with a short error-TTL so a transient
    client-construction failure doesn't permanently block that key.
    """
    import time as _time

    from .config import config

    key = api_key or config.gemini_api_key
    cache_key = _client_cache_key(key, model)

    # Fast path: cached client.
    cached = _client_cache.get(cache_key)
    if cached is not None:
        _client_cache.move_to_end(cache_key)  # v99.07 FIX-40: LRU touch
        return cached

    # Error cooldown: if this key recently failed, don't retry immediately.
    err_ts = _client_error_cache.get(cache_key)
    if err_ts is not None and (_time.monotonic() - err_ts) < _CLIENT_ERROR_TTL:
        _client_error_cache.move_to_end(cache_key)  # v99.07 FIX-40: LRU touch
        raise RuntimeError(
            f"Gemini client for key={cache_key!r} is in error cooldown "
            f"({_CLIENT_ERROR_TTL:.0f}s)"
        )

    try:
        from google import genai  # type: ignore
    except ImportError as exc:
        logger.error("GOOGLE_GENAI_MISSING: %s", exc)
        raise RuntimeError(
            "google-genai is not installed — install with: pip install google-genai"
        ) from exc

    try:
        client = genai.Client(api_key=key)
    except Exception as exc:
        _client_error_cache[cache_key] = _time.monotonic()
        _lru_cap(_client_error_cache, _CLIENT_CACHE_MAX)
        logger.error("GEMINI_CLIENT_CREATE_FAILED: %s", exc)
        raise

    _client_cache[cache_key] = client
    _lru_cap(_client_cache, _CLIENT_CACHE_MAX)
    _client_error_cache.pop(cache_key, None)
    return client


# ===========================================================================
# Async helpers
# ===========================================================================

async def _read_bytes(path: Path) -> bytes:
    """Read a file's bytes asynchronously (offloaded to a thread)."""
    return await asyncio.to_thread(Path(path).read_bytes)


async def _run_in_thread(func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run a sync callable in a worker thread, returning its result."""
    return await asyncio.to_thread(func, *args, **kwargs)


async def _v9907_track(coro):
    """v99.07 FIX-26: bridge that keeps a handle to the to_thread future.

    ``asyncio.wait_for(asyncio.shield(<to_thread>), ...)`` discards the
    inner future on timeout — this wrapper materialises it as a task,
    hands it to the reaper on abandonment, and otherwise returns its
    result transparently.
    """
    fut = asyncio.ensure_future(coro)
    try:
        return await fut
    except asyncio.CancelledError:
        # The caller timed out (shield cancellation) — the thread keeps
        # running; track + reap instead of leaking it untracked.
        if not fut.done():
            _abandoned_thread_futures.add(fut)
            fut.add_done_callback(_reap_abandoned_thread)
            logger.debug(
                "GEMINI_THREAD_ABANDONED tracked=%d (v99.07 FIX-26: thread "
                "cannot be cancelled; reaped on completion)",
                len(_abandoned_thread_futures),
            )
        raise


def _extract_text(response: Any) -> str:
    """Extract text from a google.genai response, tolerating SDK variations."""
    # Primary: response.text (the SDK's convenience property).
    try:
        text = getattr(response, "text", None)
        if text:
            return str(text)
    except Exception:
        pass
    # Fallback: walk candidates[0].content.parts[*].text.
    try:
        candidates = getattr(response, "candidates", None) or []
        if candidates:
            content = getattr(candidates[0], "content", None)
            if content is not None:
                parts = getattr(content, "parts", None) or []
                chunks = []
                for part in parts:
                    t = getattr(part, "text", None)
                    if t:
                        chunks.append(str(t))
                if chunks:
                    return "".join(chunks)
    except Exception:
        pass
    return ""


# ===========================================================================
# JSON extraction helpers
# ===========================================================================

def _strip_codefences(text: str) -> str:
    """Remove ```json ... ``` (or bare ``` ... ```) wrappers."""
    text = text.strip()
    m = re.match(r"^```(?:json|JSON)?\s*\n?(.*?)\n?```$", text, re.DOTALL)
    if m:
        return m.group(1).strip()
    return text


def _find_first_json_object(text: str) -> str | None:
    """Find the first balanced {...} substring in ``text``."""
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        else:
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
    return None


def _parse_json(text: str) -> dict[str, Any] | None:
    """Parse JSON from ``text``, tolerating code fences and surrounding prose."""
    if not text:
        return None
    cleaned = _strip_codefences(text)
    # Try direct parse first.
    try:
        result = json.loads(cleaned)
        if isinstance(result, dict):
            return result
    except (json.JSONDecodeError, ValueError):
        pass
    # Fallback: extract the first {...} block.
    blob = _find_first_json_object(cleaned)
    if blob:
        try:
            result = json.loads(blob)
            if isinstance(result, dict):
                return result
        except (json.JSONDecodeError, ValueError):
            pass
    return None


# ===========================================================================
# Part builders
# ===========================================================================

def _mime_for_image(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif",
        ".webp": "image/webp", ".bmp": "image/bmp",
    }.get(ext, "image/jpeg")


def _mime_for_audio(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".mp3": "audio/mpeg", ".m4a": "audio/mp4",
        ".wav": "audio/wav", ".ogg": "audio/ogg",
        ".oga": "audio/ogg", ".flac": "audio/flac",
    }.get(ext, "audio/mpeg")


async def _build_parts(frames: list[Path], prompt: str) -> list:
    """Build a list of genai Parts: the prompt text + each frame as an image.

    v99.07 FIX-25: frame bytes are read via asyncio.to_thread (the old
    Path(...).read_bytes() ran synchronously on the event loop — a slow
    disk or a large frame set stalled every concurrent update).
    """
    from google.genai import types  # type: ignore

    parts: list = [types.Part.from_text(text=prompt)]
    for frame in frames:
        data = await _read_bytes(Path(frame))
        parts.append(types.Part.from_bytes(data=data, mime_type=_mime_for_image(Path(frame))))
    return parts


async def _build_audio_parts(audio_path: Path, prompt: str) -> list:
    """Build a list of genai Parts: the prompt text + the audio file.

    v99.07 FIX-25: audio bytes are read via asyncio.to_thread (see
    _build_parts).
    """
    from google.genai import types  # type: ignore

    parts: list = [types.Part.from_text(text=prompt)]
    data = await _read_bytes(Path(audio_path))
    parts.append(types.Part.from_bytes(data=data, mime_type=_mime_for_audio(Path(audio_path))))
    return parts


# ===========================================================================
# Cleanup
# ===========================================================================

def cleanup_frames(frames: list[Path]) -> None:
    """Delete temporary frame files (swallow OSError)."""
    for f in frames:
        try:
            Path(f).unlink(missing_ok=True)
        except OSError:
            pass


# ===========================================================================
# Analysis entry points
# ===========================================================================

async def _run_analysis(
    parts: list,
    *,
    model: str,
    mode: str,
    user_api_key: str | None,
) -> dict[str, Any]:
    """Shared engine: build client, generate content, extract + normalise."""
    from .ai_modes import normalise

    client = _get_client(user_api_key, model)
    effective_model = model or "gemini-2.5-flash"  # v97.48: gemini-2.0-flash deprecated

    def _call():
        return client.models.generate_content(
            model=effective_model,
            contents=parts,
        )

    try:
        response = await asyncio.wait_for(
            # v99.07 FIX-26: shield + track — on timeout the underlying
            # thread CANNOT be cancelled (asyncio.to_thread has no
            # cancellation path); it is tracked in
            # _abandoned_thread_futures and reaped by done-callback so its
            # exception is retrieved and the leak is observable.
            asyncio.shield(_v9907_track(_run_in_thread(_call))),
            timeout=120)
    except asyncio.TimeoutError:
        logger.error("GEMINI_TIMEOUT mode=%s model=%s abandoned_tracked=%d", mode, effective_model, len(_abandoned_thread_futures))
        return {"error": "timeout", "confidence": 0.0}
    except Exception as exc:
        logger.error("GEMINI_ERROR mode=%s model=%s exc=%s", mode, effective_model, exc)
        return {"error": str(exc), "confidence": 0.0}

    text = _extract_text(response)
    if not text:
        logger.warning("GEMINI_EMPTY_RESPONSE mode=%s model=%s", mode, effective_model)
        return {"error": "empty_response", "confidence": 0.0}

    parsed = _parse_json(text)
    if parsed is None:
        logger.warning("GEMINI_JSON_PARSE_FAILED mode=%s text=%r", mode, text[:200])
        return {"error": "json_parse_failed", "raw_text": text[:500], "confidence": 0.0}

    return normalise(mode, parsed)


async def analyze_frames(
    frames: list[Path],
    *,
    model: str,
    mode: str,
    user_api_key: str | None = None,
    target_language: str | None = None,
) -> dict[str, Any]:
    """Analyze extracted video frames with Gemini (movie/ocr/describe/translate)."""
    from .ai_modes import build_prompt

    if not frames:
        return {"error": "no_frames", "confidence": 0.0}

    prompt = build_prompt(mode, target_language=target_language)
    parts = await _build_parts(frames, prompt)
    return await _run_analysis(parts, model=model, mode=mode, user_api_key=user_api_key)


async def analyze_audio(
    src_path: Path,
    *,
    model: str,
    mode: str,
    user_api_key: str | None = None,
    target_language: str | None = None,
) -> dict[str, Any]:
    """Analyze an audio file with Gemini (transcribe mode)."""
    from .ai_modes import build_prompt

    prompt = build_prompt(mode, target_language=target_language)
    parts = await _build_audio_parts(Path(src_path), prompt)
    return await _run_analysis(parts, model=model, mode=mode, user_api_key=user_api_key)


async def analyze_images(
    images: list[Path],
    *,
    model: str,
    mode: str,
    user_api_key: str | None = None,
    target_language: str | None = None,
) -> dict[str, Any]:
    """Analyze image(s) with Gemini (ocr/describe/translate)."""
    from .ai_modes import build_prompt

    if not images:
        return {"error": "no_images", "confidence": 0.0}

    prompt = build_prompt(mode, target_language=target_language)
    parts = await _build_parts([Path(p) for p in images], prompt)
    return await _run_analysis(parts, model=model, mode=mode, user_api_key=user_api_key)
