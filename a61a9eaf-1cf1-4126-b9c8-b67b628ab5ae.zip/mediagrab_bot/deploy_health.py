"""v99.03 — deployment-health shared state (RC-8 / RC-9 / RC-13).

RUNTIME-PROVEN CONTEXT (the 2026-09-11 02:45:10 → 03:20:39 v99.02
production diagnostic log, 1,086s uptime):
  * Line 2 of that log: ``BUILD_IDENTITY_MISMATCH stamp_version=v99.02
    runtime_version=v99.02 detail=[assets/vc_silence_600s.opus:
    stamp=e6ad24a0ecd48db2 actual=missing]`` — the v99.02 FIX-1a asset
    identity check fired CORRECTLY at boot (the operator had extracted
    only the .py files from the deployment ZIP and skipped assets/).
  * The bot then continued running for 36 minutes and wasted 40 join
    attempts (each honestly blocked by the FIX-1b null-stream gate, but
    each still paying full entity-resolution RPCs — 8 RPCs × 40 ≈ 320
    wasted RPCs) against an environment KNOWN at boot to be broken.
  * Every other v99.02 fix was proven healthy in the same log: FD_CENSUS
    stable at 18–20 for 36 minutes, ZERO Errno 24, ZERO reconnects,
    ``MTPROTO_GENERATION_STATE active=0 generation_sessions=0
    live_clients=2`` for the whole window.

v99.03 therefore separates "the code is correct" (proven) from "the
operator can run it correctly" (this module's job):

  RC-8  — when the build identity mismatches, the VC pipeline refuses to
          run (joins / discovery / reconcile all short-circuit) while the
          Bot API surface stays available for diagnosis.
  RC-9  — the most common cause (a partial extraction with the deployment
          ZIP still on disk) is SELF-HEALED at boot: the stamped asset is
          re-extracted from the ZIP after a sha256 verification.
  RC-13 — discovery and reconcile cycles skip their bodies while the
          pipeline is disabled.

This module is the SHARED STATE carrier between bootstrap (the identity
authority, which computes the verdict at boot) and the consumers
(vc_pipeline entry gate, the discovery/reconcile loops, the heartbeat,
the /deploy_check command).  It deliberately imports NOTHING from the
package (stdlib only) so any module can import it at any point without
circular-import risk, and so exec-harness test contexts can inject it.

State semantics (``_BUILD_IDENTITY["state"]``):
  "unknown"   — bootstrap.main() has not run the identity check yet
                (dev/test trees, or imports before boot).  Consumers must
                treat this as NOT-disabled (fail-open: a missing check
                must never silently disable joins — that would trade an
                availability regression for a hygiene win).
  "verified"  — modules + stamped assets all match the packaged stamp.
  "mismatch"  — at least one stamp entry does not match the runtime tree
                (and the RC-9 self-heal, if attempted, did not repair it).
  "missing" / "unreadable" — no build stamp packaged (dev/test tree);
                consumers treat these as NOT-disabled for the same
                fail-open reason as "unknown".
"""
from __future__ import annotations

import os
from typing import Any, Optional

__all__ = [
    "set_build_identity",
    "build_identity_state",
    "build_identity_mismatch",
    "mark_self_heal",
    "self_heal_report",
    "vc_pipeline_disabled_reason",
    "reset_for_tests",
]

# The single shared record.  Keys:
#   state     — "unknown" | "verified" | "mismatch" | "missing" | "unreadable"
#   detail    — the human-readable mismatch detail (or verification summary)
#   checked   — True once bootstrap.main() has evaluated the identity
#   stamp_version — the version recorded in build_stamp.json ("" if unknown)
#   runtime_version — __bot_version__ at boot
#   self_heal — None, or {"ok": bool, "assets": [...], "source": str,
#                "sha256": {...}} once an RC-9 self-heal was ATTEMPTED
_BUILD_IDENTITY: dict[str, Any] = {
    "state": "unknown",
    "detail": "",
    "checked": False,
    "stamp_version": "",
    "runtime_version": "",
    "self_heal": None,
}


def set_build_identity(state: str, detail: str, *,
                       stamp_version: str = "",
                       runtime_version: str = "") -> None:
    """Called ONCE by bootstrap.main() after the identity evaluation.

    Normalizes the bootstrap-internal states ("verified" / "MISMATCH" /
    "missing" / "unreadable") into this module's vocabulary.
    """
    norm = str(state or "unknown").strip().lower()
    if norm == "mismatch":
        norm = "mismatch"
    _BUILD_IDENTITY["state"] = norm
    _BUILD_IDENTITY["detail"] = str(detail or "")[:400]
    _BUILD_IDENTITY["checked"] = True
    _BUILD_IDENTITY["stamp_version"] = str(stamp_version or "")
    _BUILD_IDENTITY["runtime_version"] = str(runtime_version or "")


def build_identity_state() -> dict[str, Any]:
    """A copy of the shared record (callers must not mutate the original)."""
    return dict(_BUILD_IDENTITY)


def build_identity_mismatch() -> bool:
    """True ONLY when the identity was checked AND found mismatched.

    Fail-open by design: "unknown"/"missing"/"unreadable" (dev/test trees,
    exec-harness contexts, imports before boot) return False — RC-8 must
    never disable joins on evidence that was never collected.
    """
    return bool(_BUILD_IDENTITY.get("checked")) and \
        _BUILD_IDENTITY.get("state") == "mismatch"


def mark_self_heal(ok: bool, assets: list[str], source: str,
                   sha256: dict[str, str]) -> None:
    """Record the RC-9 self-heal attempt outcome (for /deploy_check)."""
    _BUILD_IDENTITY["self_heal"] = {
        "ok": bool(ok),
        "assets": list(assets or []),
        "source": str(source or ""),
        "sha256": dict(sha256 or {}),
    }


def self_heal_report() -> Optional[dict[str, Any]]:
    """The RC-9 self-heal report, or None when never attempted."""
    rep = _BUILD_IDENTITY.get("self_heal")
    return dict(rep) if isinstance(rep, dict) else None


def vc_pipeline_disabled_reason() -> Optional[str]:
    """RC-8: the reason the VC pipeline must refuse to run, or None.

    Returns "build_identity_mismatch" when the boot identity check found
    a mismatch AND the operator has not explicitly overridden the
    fail-fast (``VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1`` — the escape
    hatch that mirrors the v99.02 FIX-1 ``VC_ALLOW_NULL_STREAM_JOIN``
    convention: fail-safe by default, explicit opt-in to run degraded).
    """
    if not build_identity_mismatch():
        return None
    if os.environ.get("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH") == "1":
        return None
    return "build_identity_mismatch"


def reset_for_tests() -> None:
    """Test hook: restore the pristine pre-boot state."""
    _BUILD_IDENTITY.update({
        "state": "unknown",
        "detail": "",
        "checked": False,
        "stamp_version": "",
        "runtime_version": "",
        "self_heal": None,
    })
