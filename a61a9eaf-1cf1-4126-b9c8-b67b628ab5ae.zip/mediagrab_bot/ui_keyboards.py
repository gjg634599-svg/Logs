"""UI keyboards — extracted from _bot_core.py.

All inline keyboard builders for the bot's menu system.
Pure presentation layer: depends only on telegram types + config + md_escape.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from mediagrab_bot.config import config
from mediagrab_bot.text_utils import md_escape
from mediagrab_bot.ai_modes import MODE_ORDER, MODE_LABELS
from mediagrab_bot.db_layer import vc_get_tour_state

MAIN = "m:main"
BACK_MAIN = "b:main"


def _back(destination: str = "main") -> InlineKeyboardButton:
    return InlineKeyboardButton("🔙 Back", callback_data=f"b:{destination}")


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📥 Download", callback_data="m:dl"),
            InlineKeyboardButton("🎬 AI Analyze", callback_data="m:ai"),
        ],
        [
            InlineKeyboardButton("🔍 Inspect Chat", callback_data="m:ins"),
            InlineKeyboardButton("🧰 Media Toolbox", callback_data="m:tb"),
        ],
        [
            InlineKeyboardButton("⭐ Library", callback_data="m:lib"),
            InlineKeyboardButton("📊 Stats", callback_data="m:st"),
        ],
        [
            InlineKeyboardButton("🔳 QR Code", callback_data="m:qr"),
            InlineKeyboardButton("📦 Batch / Album", callback_data="m:batch"),
        ],
        [
            InlineKeyboardButton("⏰ Scheduled", callback_data="m:sched"),
            InlineKeyboardButton("💾 Backup", callback_data="m:bk"),
        ],
        [
            InlineKeyboardButton("📜 History", callback_data="m:hist"),
            InlineKeyboardButton("⚙️ Settings", callback_data="m:set"),
        ],
        [
            InlineKeyboardButton("ℹ️ Help", callback_data="m:help"),
            InlineKeyboardButton("🛡️ Admin", callback_data="m:admin"),
        ],
    ])


def admin_only_menu(is_admin: bool = False) -> InlineKeyboardMarkup:
    """Main menu variant — shows Admin button only to admins."""
    if is_admin:
        return main_menu()
    return main_menu()


def download_menu() -> InlineKeyboardMarkup:
    """Download menu — forward media OR download by link/@username."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ Forward media to me", callback_data="dl:fwd")],
        [InlineKeyboardButton("🔗 Download by link or @username", callback_data="dl:link")],
        [InlineKeyboardButton("👤 Profile Media & Posts", callback_data="prof:menu")],
        [_back("main")],
    ])


def analyze_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎬 Forward media to analyze", callback_data="ai:fwd")],
        [InlineKeyboardButton("🧠 Choose AI Mode", callback_data="ai:modes")],
        [_back("main")],
    ])


def ai_modes_menu(current_mode: str = "movie") -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    for mode in MODE_ORDER:
        label = MODE_LABELS.get(mode, mode)
        marker = "✅ " if mode == current_mode else "  "
        rows.append([InlineKeyboardButton(
            f"{marker}{label}", callback_data=f"ai:mode:{mode}"
        )])
    rows.append([_back("ai")])
    return InlineKeyboardMarkup(rows)


def inspector_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Inspect a @username or link", callback_data="ins:fwd")],
        [InlineKeyboardButton("🕘 Recent Inspections", callback_data="ins:recent")],
        [_back("main")],
    ])


def toolbox_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎵 Extract Audio (MP3)", callback_data="tb:audio")],
        [InlineKeyboardButton("🖼️ Extract Thumbnail", callback_data="tb:thumb")],
        [InlineKeyboardButton("📋 Media Info", callback_data="tb:info")],
        [InlineKeyboardButton("🎬 Compress Video", callback_data="tb:compress")],
        [InlineKeyboardButton("🔄 Convert Image", callback_data="tb:imgconv")],
        [_back("main")],
    ])


def library_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📚 Browse All", callback_data="lib:browse"),
            InlineKeyboardButton("🔍 Search", callback_data="lib:search"),
        ],
        [
            InlineKeyboardButton("🎬 Videos", callback_data="lib:t:video"),
            InlineKeyboardButton("🎵 Audio", callback_data="lib:t:audio"),
        ],
        [
            InlineKeyboardButton("🖼️ Images", callback_data="lib:t:photo"),
            InlineKeyboardButton("📄 Documents", callback_data="lib:t:document"),
        ],
        [InlineKeyboardButton("🧹 Clear Library", callback_data="lib:clear")],
        [_back("main")],
    ])


def library_entry_keyboard(entry_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🗑️ Remove", callback_data=f"lib:del:{entry_id}")],
        [_back("lib")],
    ])


def stats_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👤 My Stats", callback_data="st:me"),
            InlineKeyboardButton("🌍 Global", callback_data="st:global"),
        ],
        [_back("main")],
    ])


def qr_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔳 Generate a QR Code", callback_data="qr:make")],
        [_back("main")],
    ])


def batch_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(
            "📦 Forward an album (media group)", callback_data="batch:fwd"
        )],
        [_back("main")],
    ])


def scheduled_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 View scheduled tasks", callback_data="sched:list")],
        [_back("main")],
    ])


def backup_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💾 Export my data (JSON)", callback_data="bk:export")],
        [InlineKeyboardButton("📥 Import settings from JSON", callback_data="bk:import")],
        [_back("main")],
    ])


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Bot Health & Dashboard", callback_data="adm:health"),
         InlineKeyboardButton("👥 Users", callback_data="adm:users")],
        [InlineKeyboardButton("📣 Broadcast", callback_data="adm:bcast"),
         InlineKeyboardButton("📊 Global Stats", callback_data="adm:stats")],
        [InlineKeyboardButton("💾 Export Stats", callback_data="adm:export"),
         InlineKeyboardButton("⚙️ Active Tasks", callback_data="adm:tasks")],
        [InlineKeyboardButton("🛰️ MTProto", callback_data="adm:mtp"),
         InlineKeyboardButton("🤖 Userbot Manager", callback_data="cluster:menu")],
        [InlineKeyboardButton("🔍 Discovery", callback_data="adm:disc"),
         InlineKeyboardButton("🎙 VC Control", callback_data="adm:vc")],
        [InlineKeyboardButton("💬 Talkative", callback_data="adm:talk"),
         InlineKeyboardButton("🔄 Restart Bot", callback_data="adm:restart")],
        [_back("main")],
    ])


def mtproto_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("▶️ Start", callback_data="mtp:start"),
            InlineKeyboardButton("⏹️ Stop", callback_data="mtp:stop"),
        ],
        [
            InlineKeyboardButton("🔄 Restart", callback_data="mtp:restart"),
            InlineKeyboardButton("📊 Refresh", callback_data="mtp:status"),
        ],
        [InlineKeyboardButton("📸 Screenshot", callback_data="mtp:screenshot")],
        [InlineKeyboardButton("📥 MTProto Download", callback_data="mtp:download")],
        [_back("admin")],
    ])


def history_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📥 Recent Downloads", callback_data="h:dl"),
            InlineKeyboardButton("🤖 Recent AI Analyses", callback_data="h:ai"),
        ],
        [
            InlineKeyboardButton("🧹 Clear Downloads", callback_data="h:clr:dl"),
            InlineKeyboardButton("🧹 Clear AI", callback_data="h:clr:ai"),
        ],
        [InlineKeyboardButton("🧹 Clear All", callback_data="h:clr:all")],
        [_back("main")],
    ])


def settings_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎯 Quality", callback_data="s:q"),
            InlineKeyboardButton("🧠 AI Model", callback_data="s:m"),
        ],
        [
            InlineKeyboardButton("🧠 AI Mode", callback_data="s:am"),
            InlineKeyboardButton("🌐 Language", callback_data="s:l"),
        ],
        [
            InlineKeyboardButton("🗑️ Auto Delete", callback_data="s:ad"),
            InlineKeyboardButton("🔔 Notifications", callback_data="s:n"),
        ],
        [InlineKeyboardButton("🔑 Gemini API Key", callback_data="s:key")],
        [_back("main")],
    ])


def help_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 How to Download Media", callback_data="hp:dl")],
        [InlineKeyboardButton("🤖 How AI Recognition Works", callback_data="hp:ai")],
        [InlineKeyboardButton("🔍 Inspect & Toolbox", callback_data="hp:feat")],
        [InlineKeyboardButton("📄 Supported Formats", callback_data="hp:fmt")],
        [InlineKeyboardButton("❓ Frequently Asked Questions", callback_data="hp:faq")],
        [_back("main")],
    ])


def back_only(destination: str = "main") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back(destination)]])


def cancel_back(destination: str = "main") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Cancel", callback_data=f"b:{destination}")],
    ])


def settings_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("set")]])


def help_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("help")]])


def history_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("hist")]])


def library_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("lib")]])


def inspector_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("ins")]])


def toolbox_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("tb")]])


def stats_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("st")]])


def qr_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("qr")]])


def download_done_keyboard() -> InlineKeyboardMarkup:
    """Shown after a download completes — offer to bookmark to Library."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⭐ Save to Library", callback_data="lib:savelast")],
        [InlineKeyboardButton("🔙 Main Menu", callback_data="b:main")],
    ])


def batch_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("batch")]])


def scheduled_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("sched")]])


def backup_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("bk")]])


def admin_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("admin")]])


def ai_modes_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("ai")]])


# ---------------------------------------------------------------------------
# VC Tour control
# ---------------------------------------------------------------------------

def vc_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("▶️ Start VC Tour", callback_data="vc:start"),
            InlineKeyboardButton("⏸ Pause Tour", callback_data="vc:pause"),
        ],
        [
            InlineKeyboardButton("▶️ Resume Tour", callback_data="vc:resume"),
            InlineKeyboardButton("⏹ Stop Tour", callback_data="vc:stop"),
        ],
        [
            InlineKeyboardButton("📍 Current VC", callback_data="vc:current"),
            InlineKeyboardButton("📊 Tour Status", callback_data="vc:status"),
        ],
        [
            InlineKeyboardButton("📜 VC History", callback_data="vc:hist:0"),
            InlineKeyboardButton("🔄 Refresh Groups", callback_data="vc:refresh"),
        ],
        [
            InlineKeyboardButton("🎯 Manual VC Control", callback_data="vc:manual"),
            InlineKeyboardButton("⚙️ VC Settings", callback_data="vc:settings"),
        ],
        [InlineKeyboardButton("📊 Live VC Dashboard", callback_data="vc:dash")],
        [_back("admin")],
    ])


def vc_dashboard_menu() -> InlineKeyboardMarkup:
    """Inline keyboard for the Live VC Dashboard V3 (Task ID 11 — Phase 17).

    All 13 spec-required buttons are present and routed in route_callback:
      🔄 Refresh, 🧪 Backend Test, 🔍 Scan Groups, 🧱 Rebuild Queue,
      🧪 Multi-VC Probe, 🧬 Two-Target Probe, 🎯 Join Multiple,
      📋 Participations, 🧹 Cleanup Required, 🛑 Leave Selected,
      🛑 Leave All Tracked, 📤 Export Logs, ⬅️ Back.
    Plus tour-control buttons (Start/Pause/Resume/Stop/Skip) and sub-view
    buttons (Queue, Errors, Logs, Settings, Close).
    """
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔄 Refresh Now", callback_data="vc:dash_refresh"),
            InlineKeyboardButton("▶️ Start Tour", callback_data="vc:start"),
        ],
        [
            InlineKeyboardButton("⏸ Pause", callback_data="vc:pause"),
            InlineKeyboardButton("▶️ Resume", callback_data="vc:resume"),
            InlineKeyboardButton("⏹ Stop", callback_data="vc:stop"),
        ],
        [
            InlineKeyboardButton("⏭ Skip Current", callback_data="vc:skip"),
            InlineKeyboardButton("🔍 Scan Groups", callback_data="vc:refresh"),
            InlineKeyboardButton("🧱 Rebuild Queue", callback_data="vc:rebuild_queue"),
        ],
        [
            InlineKeyboardButton("🧪 Backend Test", callback_data="vc:backend_test"),
            InlineKeyboardButton("🧪 Multi-VC Probe", callback_data="vc:multi_probe"),
        ],
        [
            InlineKeyboardButton("🧬 Two-Target Probe", callback_data="vc:two_target_probe"),
            InlineKeyboardButton("🎯 Join Multiple", callback_data="vc:join_multi"),
        ],
        [
            InlineKeyboardButton("🚀 Join All Active VCs", callback_data="vc:join_all_active"),
        ],
        [
            InlineKeyboardButton("👁 VC Watcher Start", callback_data="vc:watcher_start"),
            InlineKeyboardButton("⏹ Watcher Stop", callback_data="vc:watcher_stop"),
        ],
        [
            InlineKeyboardButton("📋 Queue", callback_data="vc:queue_view"),
            InlineKeyboardButton("📋 Participations", callback_data="vc:participations"),
        ],
        [
            InlineKeyboardButton("⚠️ Errors", callback_data="vc:errors_view"),
            InlineKeyboardButton("📜 Live Logs", callback_data="vc:logs_view"),
            InlineKeyboardButton("📤 Export Logs", callback_data="vc:export_logs"),
        ],
        [
            InlineKeyboardButton("🧹 Cleanup Required", callback_data="vc:cleanup_req"),
            InlineKeyboardButton("🛑 Leave Selected", callback_data="vc:leave_selected"),
        ],
        [
            InlineKeyboardButton("🛑 Leave All Tracked", callback_data="vc:leave_all"),
            InlineKeyboardButton("⚙️ Settings", callback_data="vc:settings"),
        ],
        # V86: Discovery has been separated into its own independent module.
        # The 9 Discovery buttons that used to live here (Discovery V2, Unified
        # Status, Add/Remove/List Queries, Query Settings, Disc Mode, Recent
        # Results, Auto Queries) have been moved to the top-level Discovery
        # menu (disc:main), reachable from the admin menu.  A single link
        # remains here so VC users can still jump to Discovery when they need
        # to find groups with active VCs.  The Live VC module calls the
        # DiscoveryManager API internally — it never performs independent
        # search.
        [
            InlineKeyboardButton("🔍 Discovery Module", callback_data="disc:main"),
        ],
        [
            InlineKeyboardButton("⬅️ Back to VC Menu", callback_data="b:vc"),
            InlineKeyboardButton("❌ Close", callback_data="vc:close_dash"),
        ],
    ])


def vc_dashboard_back_menu() -> InlineKeyboardMarkup:
    """Compact menu used by sub-views (errors, logs, backend test) —
    a single row that returns to the dashboard."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Dashboard", callback_data="vc:dash")],
    ])


def vc_dashboard_errors_menu(page: int, total_pages: int) -> InlineKeyboardMarkup:
    """Paginated navigation for the error viewer."""
    rows: list[list[InlineKeyboardButton]] = []
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Prev",
                                         callback_data=f"vc:errors_view:{page - 1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh",
                                     callback_data=f"vc:errors_view:{page}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("➡️ Next",
                                         callback_data=f"vc:errors_view:{page + 1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton("🔙 Back to Dashboard",
                                       callback_data="vc:dash")])
    return InlineKeyboardMarkup(rows)


def vc_dashboard_logs_menu(page: int, total_pages: int) -> InlineKeyboardMarkup:
    """Paginated navigation for the live logs viewer."""
    rows: list[list[InlineKeyboardButton]] = []
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Prev",
                                         callback_data=f"vc:logs_view:{page - 1}"))
    nav.append(InlineKeyboardButton("🔄 Refresh",
                                     callback_data=f"vc:logs_view:{page}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("➡️ Next",
                                         callback_data=f"vc:logs_view:{page + 1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton("🔙 Back to Dashboard",
                                       callback_data="vc:dash")])
    return InlineKeyboardMarkup(rows)


async def vc_dashboard_text() -> str:
    """Render the Live VC Dashboard V2 as a Markdown string.

    V2 reorganises the dashboard into seven truthful sections, each driven
    by the canonical ``vc_backend_health()`` snapshot so every UI surface
    shows the SAME story:

      A. SYSTEM       — Bot API / MTProto / VC backend / class / adapter /
                        installed / initialized / started / compatible /
                        operational
      B. TOUR         — running/stopped/paused / uptime / queue position /
                        queue size / visited / failed joins
      C. VC SESSION   — confirmed connected / pending join / unknown
                        confirmation / cleanup required / cleanup failed /
                        current chat ID / pending chat ID
      D. STATUS READER— strategy / last result (CONNECTED / DISCONNECTED /
                        UNKNOWN) / consecutive failures / last safe error
      E. CAPABILITIES — join / leave / status strategy / multi-VC
                        classification
      F. SCANNER      — discovered / scanned / active / startable /
                        not startable / failed / last scan
      G. TIMING       — stay / cooldown / auto-start VC / end-created-VC

    Does NOT trigger rescans, discovery, or any Telegram RPC. Cheap enough
    to call on every refresh (a few dict lookups + one DB read for the
    tour started_at).
    """
    # Lazy import: voicechat imports from ui_keyboards, so a top-level
    # import would create a cycle. Pull all voicechat internals here.
    import logging as _logging
    from typing import Any as _Any
    from mediagrab_bot.utils_real import get_bot as _get_bot, _active_tasks as _active_tasks_mod
    from mediagrab_bot.utils_real import _supervised_task_counts as _supervised_task_counts_mod
    import mediagrab_bot.voicechat as _vc
    from mediagrab_bot.voicechat import (
        vc_get_status, vc_get_backend, vc_get_health,
        _vc_mtproto_ok, _vc_tour_task, _vc_duration_str, _vc_state,
        _vc_metrics, _vc_scan_counts, _vc_capability_evidence,
        _vc_discovery_metrics, _vc_discovery_state,
        _vc_last_participation_check, _vc_last_scan_iso, _vc_now_iso,
        _vc_participations, _vc_talkative_capabilities,
        _vc_watcher_interval, _vc_watcher_state,
    )
    from mediagrab_bot.db_layer import vc_get_settings, vc_group_count
    logger = _logging.getLogger("mediagrab")
    get_bot = _get_bot
    _active_tasks = _active_tasks_mod
    _supervised_task_counts = _supervised_task_counts_mod
    Any = _Any
    s = await vc_get_status()
    settings = await vc_get_settings()
    backend = vc_get_backend()
    tour_state = await vc_get_tour_state()

    # --- Canonical backend health snapshot ---
    bh = s.get("backend_health") or {}
    backend_installed = bool(bh.get("installed", False))
    backend_initialized = bool(bh.get("initialized", False))
    backend_started = bool(bh.get("started", False))
    backend_compatible = bool(bh.get("compatible", False))
    backend_operational = bool(bh.get("operational", False))
    backend_connected = bool(bh.get("connected", False))
    connection_state = bh.get("connection_state", "disconnected") or "disconnected"
    backend_state = bh.get("state", "") or "uninitialized"
    backend_reason = bh.get("reason", "") or ""
    backend_last_err = (bh.get("last_error") or "")[:200]
    backend_last_trans = bh.get("last_transition_at", "") or ""
    join_strat = bh.get("join_strategy", "") or "NONE"
    leave_strat = bh.get("leave_strategy", "") or "NONE"
    status_strat = bh.get("status_strategy", "") or "NONE"
    status_error = (bh.get("last_status_error") or "")[:160]
    consec_fail = int(bh.get("consecutive_status_failures", 0))
    multi_vc = bh.get("multi_vc") or {}
    multi_vc_cls = multi_vc.get("classification", "UNKNOWN")
    backend_class = bh.get("backend_class") or type(backend).__name__
    backend_name = bh.get("backend_name") or getattr(backend, "backend_name", "abstract")

    # --- Direct backend state (for VC SESSION section) ---
    cur_chat_id = getattr(backend, "_current_chat_id", None) if backend else None
    pend_chat_id = getattr(backend, "_pending_chat_id", None) if backend else None
    join_path_ok = bool(getattr(backend, "_join_path_operational", True)) if backend else True

    # --- System status ---
    bot_ok = get_bot() is not None
    mtproto_ok = _vc_mtproto_ok()
    backend_icon = ("✅" if backend_operational
                    else "⚠️" if backend_installed
                    else "❌")
    tour_task_ok = bool(_vc_tour_task is not None and not _vc_tour_task.done())

    # Tour uptime from DB-persisted started_at.
    started_iso = (tour_state or {}).get("started_at") or ""
    tour_uptime = "—"
    if started_iso and s.get("running"):
        try:
            # V43 Fix #2: parse naive SQLite timestamp, normalize to aware UTC
            # before subtracting from an aware datetime. Prevents both
            # deprecation (utcnow) and TypeError (naive vs aware).
            st = datetime.strptime(started_iso, "%Y-%m-%d %H:%M:%S")
            if st.tzinfo is None:
                st = st.replace(tzinfo=timezone.utc)
            tour_uptime = _vc_duration_str(
                (datetime.now(timezone.utc) - st).total_seconds()
            )
        except Exception:  # noqa: BLE001
            tour_uptime = "—"

    # --- Tour state label ---
    if s.get("running") and s.get("paused"):
        tour_label = "⏸ Paused"
    elif s.get("running"):
        tour_label = "▶️ Running"
    else:
        tour_label = "⏹ Stopped"

    # --- Current VC ---
    if s.get("current_group_id"):
        title = md_escape(s.get("current_title") or "Unknown")
        gid = s.get("current_group_id")
        call_id = _vc_state.current_call_id or "—"
        elapsed = s.get("elapsed_seconds") or 0
        stay = s.get("planned_stay") or 300
        remaining = max(0, int(stay - elapsed))
        cur_block = (
            f"State: 🟢 Joined\n"
            f"Group: {title} (`{gid}`)\n"
            f"Call ID: `{call_id}`\n"
            f"Join time: `{s.get('joined_at_iso', '—')}`\n"
            f"Stay remaining: {_vc_duration_str(remaining)}"
        )
    else:
        cur_block = (
            "State: ⚪ Idle\n"
            "Group: —\n"
            "Call ID: —\n"
            "Join time: —\n"
            "Stay remaining: —"
        )

    # --- Queue ---
    queue_pos = s.get("queue_index", 0)
    queue_size = s.get("queue_size", 0)
    visited = s.get("visited_count", 0)
    failed_joins = _vc_metrics.get("join_failures", 0)

    # --- Scanner ---
    sc = _vc_scan_counts or {}
    discovered = _vc_metrics.get("groups_discovered", 0)
    newly_discovered = _vc_metrics.get("groups_newly_discovered", 0)
    scanned = _vc_metrics.get("groups_scanned", 0) or sc.get("total", 0)
    last_scan = _vc_last_scan_iso or "—"
    # Patch 8 — show known groups (persisted DB count) alongside scanned.
    # Fetched from the DB; if the call fails, fall back to the scanned count.
    try:
        known_groups = await vc_group_count()
    except Exception:  # noqa: BLE001
        known_groups = scanned  # fallback

    # --- Overall subsystem health ---
    health = vc_get_health()
    health_icon = {"HEALTHY": "✅", "DEGRADED": "⚠️",
                   "CRITICAL": "❌"}.get(health, "❓")

    # --- Timing ---
    stay_min = (settings.get("stay_seconds", 300) or 300) // 60
    cooldown = settings.get("cooldown_seconds", 30)
    auto_start = "✅" if settings.get("auto_start_vc") else "⚪️"
    end_created = "✅" if settings.get("end_created_vc") else "⚪️"

    state_summary = backend_state
    if backend_reason:
        state_summary += f" ({backend_reason})"

    # --- VC SESSION STATE flags ---
    confirmed_connected = backend_connected and connection_state == "connected"
    pending_join = pend_chat_id is not None
    unknown_confirm = connection_state == "unknown"
    cleanup_required = unknown_confirm  # cleanup is attempted when UNKNOWN
    # cleanup_failed is not persisted; derive from last_error containing
    # "CLEANUP_FAILURE" or a failed-leave marker.  Conservative: show "—"
    # unless we can prove it.
    cleanup_failed = "—" if not unknown_confirm else ("⚠️" if status_error else "—")

    # --- STATUS READER last result label ---
    if connection_state == "connected":
        sr_last = "🟢 CONNECTED"
    elif connection_state == "unknown":
        sr_last = "❓ UNKNOWN"
    else:
        sr_last = "⚪ DISCONNECTED"

    # --- Multi-VC icon (evidence-based classifications) ---
    mv_icon = {"MULTI_TRANSPORT": "✅",
               "MULTI_TRACKED": "🟢",
               "MULTI_PARTICIPATION_ONLY": "🟡",
               "SINGLE_CONFIRMED": "🔒",
               "UNKNOWN": "❓",
               "UNAVAILABLE": "❌",
               # Legacy classifications (kept for backwards compat).
               "MULTI_NATIVE": "✅",
               "MULTI_ADAPTER_POSSIBLE": "🟡",
               "SINGLE_ONLY": "🔒",
               }.get(multi_vc_cls, "❓")

    # Safe chat-ID display (only show if non-None).
    cur_id_s = str(cur_chat_id) if cur_chat_id is not None else "—"
    pend_id_s = str(pend_chat_id) if pend_chat_id is not None else "—"

    # --- Participation registry data (Task ID 18) ---
    participations = list(_vc_participations.values())
    p_total = len(participations)
    p_present = sum(1 for p in participations
                    if p.telegram_participation == "present")
    p_tracked = sum(1 for p in participations if p.locally_tracked)
    p_controllable = sum(1 for p in participations
                         if p.transport_controllable)
    p_unknown = sum(1 for p in participations
                    if p.telegram_participation == "unknown")
    p_cleanup_req = sum(1 for p in participations if p.cleanup_required)
    p_cleanup_failed = sum(1 for p in participations
                           if p.cleanup_outcome == "failed")
    # Evidence source + last probe.
    ev = _vc_capability_evidence or {}
    ev_source = ev.get("evidence_source", "—")
    ev_collected = ev.get("collected_at", "—")
    ev_confidence = ev.get("confidence", "—")
    # Phase 16 — new truth fields for the dashboard.
    ev_leave_ts = ev.get("leave_target_specific", False)
    ev_contradictions = len(ev.get("contradictory_evidence", []))
    # Participation check diagnostics (last call to vc_check_telegram_participation).
    pc = _vc_last_participation_check
    # Multi-VC concurrency-allowed flag (Phase 7 gating).
    multi_cls = multi_vc_cls
    if multi_cls == "MULTI_TRANSPORT":
        concurrency_allowed = "yes (concurrent)"
    elif multi_cls == "MULTI_TRACKED" and ev_leave_ts:
        concurrency_allowed = "sequential only"
    else:
        concurrency_allowed = "no"
    # Task supervision counts (Phase 5).
    supervised_active = len(_active_tasks)
    supervised_total = _supervised_task_counts["created"]
    supervised_failed = _supervised_task_counts["failed"]
    supervised_cancelled = _supervised_task_counts["cancelled"]

    return (
        f"*📊 Live VC Dashboard V2*\n"
        f"_`{_vc_now_iso()}` UTC · Health: {health_icon} `{health}`_\n\n"
        # A. SYSTEM
        f"*A. System*\n"
        f"Bot API: {'✅' if bot_ok else '❌'} · "
        f"MTProto: {'✅' if mtproto_ok else '❌'}\n"
        f"VC Backend: {backend_icon} "
        f"{'operational' if backend_operational else backend_state}\n"
        f"Class: `{md_escape(backend_class)}` · "
        f"Adapter: `{md_escape(backend_name)}`\n"
        f"Installed: {'✅' if backend_installed else '❌'} "
        f"Init: {'✅' if backend_initialized else '❌'} "
        f"Started: {'✅' if backend_started else '❌'}\n"
        f"Compatible: {'✅' if backend_compatible else '❌'} "
        f"Operational: {'✅' if backend_operational else '❌'}\n\n"
        # B. TOUR
        f"*B. Tour*\n"
        f"State: {tour_label} · Uptime: `{tour_uptime}`\n"
        f"Task: {'✅ running' if tour_task_ok else '⏹ stopped'}\n"
        f"Queue pos: `{queue_pos}/{queue_size}` · "
        f"Visited: `{visited}` · Failed: `{failed_joins}`\n\n"
        # C. VC SESSION STATE
        f"*C. VC Session State*\n"
        f"Confirmed: {'🟢' if confirmed_connected else '⚪'} · "
        f"Pending: {'🟡' if pending_join else '⚪'}\n"
        f"Unknown: {'❓' if unknown_confirm else '⚪'} · "
        f"Cleanup req: {'⚠️' if cleanup_required else '⚪'}\n"
        f"Cleanup failed: {cleanup_failed}\n"
        f"Current chat: `{cur_id_s}` · Pending: `{pend_id_s}`\n\n"
        # D. STATUS READER
        f"*D. Status Reader*\n"
        f"Strategy: `{status_strat}`\n"
        f"Last result: {sr_last}\n"
        f"Consecutive failures: `{consec_fail}` "
        f"{'(degraded)' if consec_fail >= 3 else ''}\n"
        f"Last error: `{md_escape(status_error or '—')}`\n\n"
        # E. CAPABILITIES
        f"*E. Capabilities*\n"
        f"Join: `{join_strat}` · Leave: `{leave_strat}` · "
        f"Status: `{status_strat}`\n"
        f"Join path OK: {'✅' if join_path_ok else '❌'}\n"
        f"Multi-VC: {mv_icon} `{md_escape(multi_vc_cls)}`\n\n"
        # E2. MULTI CAPABILITY (evidence-based)
        f"*E2. Multi Capability*\n"
        f"Classification: `{md_escape(multi_vc_cls)}`\n"
        f"Evidence source: `{md_escape(ev_source)}`\n"
        f"Confidence: `{md_escape(ev_confidence)}`\n"
        f"Last probe: `{md_escape(ev_collected)}`\n"
        f"Target-specific leave: {'✅' if ev_leave_ts else '❌'}\n"
        f"Contradictions: `{ev_contradictions}`\n"
        f"Concurrency allowed: `{md_escape(concurrency_allowed)}`\n\n"
        # E3. PARTICIPATIONS (registry)
        f"*E3. Participations*\n"
        f"Tracked: `{p_total}` · Telegram-present: `{p_present}`\n"
        f"Locally tracked: `{p_tracked}` · Controllable: `{p_controllable}`\n"
        f"Unknown: `{p_unknown}` · Cleanup req: `{p_cleanup_req}` · "
        f"Cleanup failed: `{p_cleanup_failed}`\n"
        f"Last check: `{md_escape(pc.get('result', '—'))}` "
        f"pages=`{pc.get('pages_inspected', 0)}` "
        f"inspected=`{pc.get('participants_inspected', 0)}` "
        f"complete={'yes' if pc.get('complete') else 'no'}\n\n"
        # E4. TASK SUPERVISION (Phase 5)
        f"*E4. Task Supervision*\n"
        f"Active supervised: `{supervised_active}` · "
        f"Total created: `{supervised_total}`\n"
        f"Failed: `{supervised_failed}` · "
        f"Cancelled: `{supervised_cancelled}`\n\n"
        # E5. VC WATCHER (#46)
        f"*E5. VC Watcher*\n"
        f"Running: {'✅' if _vc_watcher_state.get('running') else '⏹'} · "
        f"Interval: `{_vc_watcher_interval}s`\n"
        f"Groups checked: `{_vc_watcher_state.get('groups_checked', 0)}` · "
        f"New active: `{_vc_watcher_state.get('newly_active_detected', 0)}`\n"
        f"Auto-joins: `{_vc_watcher_state.get('auto_joins_confirmed', 0)}` ✅ · "
        f"Failed: `{_vc_watcher_state.get('auto_joins_failed', 0)}` ❌\n"
        f"Deferred: `{_vc_watcher_state.get('deferred_targets', 0)}` · "
        f"Capacity: `{_vc_watcher_state.get('capacity_used', 0)}/{config.vc_multi_max_targets}`\n"
        f"Last scan: `{md_escape(_vc_watcher_state.get('last_scan_at', '—') or '—')}`\n\n"
        # F. SCANNER
        f"*F. Scanner*\n"
        f"Known groups: `{known_groups}` · Scanned: `{scanned}`\n"
        f"Discovery events: `{discovered}` (cumulative)\n"
        f"New groups: `{newly_discovered}` (cumulative)\n"
        f"Active: `{sc.get('active', 0)}` · "
        f"Startable: `{sc.get('startable', 0)}`\n"
        f"Not startable: `{sc.get('not_startable', 0)}` · "
        f"Failed: `{sc.get('failed', 0)}`\n"
        f"Last scan: `{md_escape(last_scan)}`\n\n"
        # H. DISCOVERY — V86: Discovery is now an independent module.
        # The VC dashboard shows only a brief summary; full Discovery
        # diagnostics live in the Discovery module (disc:diag).
        f"*H. Discovery* (independent module — tap 🔍 Discovery Module below)\n"
        f"Auto-join: ✅`{_vc_discovery_state.get('auto_joins_confirmed',0)}` "
        f"❌`{_vc_discovery_state.get('auto_joins_failed',0)}` "
        f"⏸`{_vc_discovery_state.get('deferred_targets',0)}`\n"
        f"Cumulative: new=`{_vc_discovery_metrics.get('total_new_groups',0)}` "
        f"active=`{_vc_discovery_metrics.get('total_active_vcs_found',0)}` "
        f"joined=`{_vc_discovery_metrics.get('total_auto_joins_confirmed',0)}`\n\n"
        # G. TIMING
        f"*G. Timing*\n"
        f"Stay: `{stay_min} min` · Cooldown: `{cooldown}s`\n"
        f"Auto-start VC: {auto_start} · End created VC: {end_created}\n\n"
        # Current VC detail + last transition
        f"*Current VC*\n{cur_block}\n\n"
        f"Last transition: `{md_escape(backend_last_trans or '—')}`\n"
        f"Last error: `{md_escape(backend_last_err or '—')}`"
    )


def vc_manual_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎙 Join Target VC", callback_data="vc:jointarget")],
        [InlineKeyboardButton("🚪 Leave Current VC", callback_data="vc:leave")],
        [
            InlineKeyboardButton("⏱ Stay 5 Min", callback_data="vc:stay5"),
            InlineKeyboardButton("⏱ Custom Duration", callback_data="vc:staycustom"),
        ],
        [
            InlineKeyboardButton("🔎 Check Target VC", callback_data="vc:checktarget"),
            InlineKeyboardButton("📍 Current VC", callback_data="vc:current"),
        ],
        [_back("vc")],
    ])


def vc_settings_menu(s: dict | None = None) -> InlineKeyboardMarkup:
    """VC settings menu with live toggle indicators.

    *s* is the runtime settings dict (from repo.vc_get_settings). Buttons show
    ✅/⚪️ based on current values.
    """
    s = s or {}
    stay_min = (s.get("stay_seconds", 300) or 300) // 60
    cooldown = s.get("cooldown_seconds", 30)
    rev = "✅" if s.get("revisit_same_group") else "⚪️"
    ar = "✅" if s.get("auto_resume_after_manual") else "⚪️"
    jn = "✅" if s.get("join_notifications") else "⚪️"
    ln = "✅" if s.get("leave_notifications") else "⚪️"
    sh = "✅" if s.get("save_history") else "⚪️"
    as_ = "✅" if s.get("auto_start_vc") else "⚪️"
    ec = "✅" if s.get("end_created_vc") else "⚪️"
    # v97.1 MULTI-ACCOUNT: VC Join Mode (primary | distributed).
    mode = s.get("vc_join_mode") or "primary"
    if mode not in ("primary", "distributed"):
        mode = "primary"
    mode_label = "🌐 Distributed Accounts" if mode == "distributed" else "👤 Primary Account"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"⏱ Stay: {stay_min} min", callback_data="vcs:stay")],
        [InlineKeyboardButton(f"⏳ Cooldown: {cooldown}s", callback_data="vcs:cd")],
        [InlineKeyboardButton(f"🔁 Revisit same group: {rev}", callback_data="vcs:t:revisit_same_group")],
        [InlineKeyboardButton(f"▶️ Auto-resume after manual: {ar}", callback_data="vcs:t:auto_resume_after_manual")],
        [InlineKeyboardButton(f"🔔 Join notifications: {jn}", callback_data="vcs:t:join_notifications")],
        [InlineKeyboardButton(f"🔔 Leave notifications: {ln}", callback_data="vcs:t:leave_notifications")],
        [InlineKeyboardButton(f"📊 Save history: {sh}", callback_data="vcs:t:save_history")],
        [InlineKeyboardButton(f"🚀 Auto-start VC when inactive: {as_}", callback_data="vcs:t:auto_start_vc")],
        [InlineKeyboardButton(f"🔚 End VC created by tour: {ec}", callback_data="vcs:t:end_created_vc")],
        # v97.1: VC Join Mode toggle (cycles primary <-> distributed).
        [InlineKeyboardButton(f"🔗 VC Join Mode: {mode_label}", callback_data="vcs:join_mode")],
        [
            InlineKeyboardButton("🔄 Refresh", callback_data="vcs:refresh"),
            InlineKeyboardButton("📊 Status", callback_data="vc:status"),
        ],
        [_back("vc")],
    ])


def vc_stay_presets_menu() -> InlineKeyboardMarkup:
    # v97.53: extended presets to include hours, 1 day, 2 days
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("5 min", callback_data="vcs:stayset:5"),
            InlineKeyboardButton("15 min", callback_data="vcs:stayset:15"),
            InlineKeyboardButton("30 min", callback_data="vcs:stayset:30"),
        ],
        [
            InlineKeyboardButton("1 hour", callback_data="vcs:stayset:60"),
            InlineKeyboardButton("2 hours", callback_data="vcs:stayset:120"),
            InlineKeyboardButton("6 hours", callback_data="vcs:stayset:360"),
        ],
        [
            InlineKeyboardButton("12 hours", callback_data="vcs:stayset:720"),
            InlineKeyboardButton("1 day", callback_data="vcs:stayset:1440"),
            InlineKeyboardButton("2 days", callback_data="vcs:stayset:2880"),
        ],
        [InlineKeyboardButton("✏️ Custom (minutes)", callback_data="vcs:staycustom")],
        [_back("vcs")],
    ])


def vc_cooldown_presets_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("0s", callback_data="vcs:cdset:0"),
            InlineKeyboardButton("10s", callback_data="vcs:cdset:10"),
            InlineKeyboardButton("30s", callback_data="vcs:cdset:30"),
        ],
        [
            InlineKeyboardButton("60s", callback_data="vcs:cdset:60"),
            InlineKeyboardButton("120s", callback_data="vcs:cdset:120"),
            InlineKeyboardButton("300s", callback_data="vcs:cdset:300"),
        ],
        [InlineKeyboardButton("✏️ Custom", callback_data="vcs:cdcustom")],
        [_back("vcs")],
    ])


def vc_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("vc")]])


def vcmanual_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("vcmanual")]])


# ===========================================================================
# Talkative Mode UI (Task ID 16)
# ===========================================================================
# All callback data uses the ``talk:`` prefix and stays under 64 bytes.


def talkative_menu(global_s: dict | None = None,
                   chat_s: dict | None = None) -> InlineKeyboardMarkup:
    """Talkative V2 Control Center (#1).

    Redesigned dashboard: one clean status panel with all controls organized
    by subsystem.  Bot API is control-plane only (#15).
    """
    global_s = global_s or {}
    g_enabled = bool(global_s.get("enabled"))
    provider = global_s.get("provider", "groq")
    rows: list[list[InlineKeyboardButton]] = [
        # Main enable/disable.
        [InlineKeyboardButton(
            "🟢 Disable Talkative" if g_enabled else "🔴 Enable Talkative",
            callback_data="talk:disable_g" if g_enabled else "talk:enable_g")],
        # Subsystem controls.
        [
            InlineKeyboardButton("💬 Chat Controls", callback_data="talk:chat_ctrl"),
            InlineKeyboardButton("🎙 VC Controls", callback_data="talk:vc_ctrl"),
        ],
        [
            InlineKeyboardButton("🎭 Multimodal & Voice", callback_data="talk:media_ctrl"),
            InlineKeyboardButton("🧠 Memory & Context", callback_data="talk:mem_ctrl"),
        ],
        [
            InlineKeyboardButton("⚡ Engagement", callback_data="talk:engage_ctrl"),
            InlineKeyboardButton("🤖 AI Provider", callback_data="talk:provider"),
        ],
        [
            InlineKeyboardButton("🧠 Wit.ai", callback_data="talk:witai:menu"),
        ],
        [
            InlineKeyboardButton("🌐 Language", callback_data="talk:lang"),
            InlineKeyboardButton("🎨 Personality", callback_data="talk:personality"),
        ],
        [
            InlineKeyboardButton("🛡 Safety & Limits", callback_data="talk:safety_ctrl"),
            InlineKeyboardButton("📊 Live Status", callback_data="talk:status"),
        ],
        [
            InlineKeyboardButton("🔧 Diagnostics", callback_data="talk:diag"),
            InlineKeyboardButton("🔔 Wake Words", callback_data="talk:wake"),
        ],
        [InlineKeyboardButton("⬅ Admin", callback_data="b:admin")],
    ]
    return InlineKeyboardMarkup(rows)


def witai_settings_menu() -> InlineKeyboardMarkup:
    """Wit.ai settings submenu — manage STT/intent provider without .env editing."""
    enabled = getattr(config, "witai_enabled", False)
    token_set = bool((getattr(config, "witai_server_token", "") or "").strip())
    vp = getattr(config, "voice_provider", "auto")
    ip = getattr(config, "intent_provider", "auto")
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(
            "🟢 Disable Wit.ai" if enabled else "🔴 Enable Wit.ai",
            callback_data="talk:witai:toggle")],
        [InlineKeyboardButton(
            f"🔑 Token: {'✅ Set' if token_set else '❌ Not set'}",
            callback_data="talk:witai:token_prompt")],
        [InlineKeyboardButton(
            f"🗑 Remove Token" if token_set else " _(no token to remove)_",
            callback_data="talk:witai:token_remove" if token_set else "talk:witai:menu",
            )] if token_set else [],
        [InlineKeyboardButton(
            f"🧪 Test Connection",
            callback_data="talk:witai:test")],
        [InlineKeyboardButton(
            f"🎙 Voice Provider: {vp}",
            callback_data="talk:witai:cycle_voice")],
        [InlineKeyboardButton(
            f"🧠 Intent Provider: {ip}",
            callback_data="talk:witai:cycle_intent")],
        [InlineKeyboardButton(
            "📊 Diagnostics",
            callback_data="talk:witai:diag")],
        [InlineKeyboardButton(
            "🎤 Voice Pipeline Check",
            callback_data="talk:witai:voice_check")],
        [InlineKeyboardButton("🔙 Talkative Menu", callback_data="talk:menu")],
    ]
    # Filter out empty rows (from the conditional token-remove row).
    rows = [r for r in rows if r]
    return InlineKeyboardMarkup(rows)


def witai_settings_text() -> str:
    """Status text for the Wit.ai settings menu."""
    enabled = getattr(config, "witai_enabled", False)
    token_set = bool((getattr(config, "witai_server_token", "") or "").strip())
    vp = getattr(config, "voice_provider", "auto")
    ip = getattr(config, "intent_provider", "auto")
    available = enabled and token_set
    lines = [
        "🧠 *Wit.ai Settings*",
        "",
        f"• Status: `{'🟢 Enabled' if enabled else '🔴 Disabled'}`",
        f"• Available: `{'✅ Yes' if available else '❌ No (enable + set token)'}`",
        f"• Token: `{'✅ Set' if token_set else '❌ Not set'}`",
        f"• Voice Provider: `{vp}`",
        f"• Intent Provider: `{ip}`",
        "",
        "_Wit.ai provides: speech-to-text, intent detection, entity extraction, language detection._",
        "_If disabled, the bot uses Gemini/Groq for these tasks._",
    ]
    return "\n".join(lines)


def talkative_chat_controls_menu() -> InlineKeyboardMarkup:
    """#2: Chat Controls submenu.

    V48 Fix: added Typing Indicator toggle button (was missing from UI).
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👤 Private DM: Toggle", callback_data="talk:private_auto"),
         InlineKeyboardButton("👥 Group Chat: Toggle", callback_data="talk:group_ctx")],
        [InlineKeyboardButton("⌨️ Typing Indicator: Toggle", callback_data="talk:typing"),
         InlineKeyboardButton("🗣 Wake Words", callback_data="talk:wake")],
        [InlineKeyboardButton("🔗 Follow-up (session)", callback_data="talk:timeout"),
         InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_vc_controls_menu() -> InlineKeyboardMarkup:
    """#4: VC Controls submenu.

    Fix 1: Only buttons wired to real callbacks are shown.
    V41 Fix #5: capabilities are async — use a cached/sync wrapper for menu rendering.
    """
    # V41 Fix #5: caps are now async, but menu rendering is sync.
    # Use the cached value if available, else default to degraded.
    # Lazy import: voicechat imports from ui_keyboards, so top-level would cycle.
    from mediagrab_bot.voicechat import _vc_talkative_capabilities
    caps = _vc_talkative_capabilities if _vc_talkative_capabilities is not None else {"degraded": True, "ready": False}
    vc_state = "Degraded" if caps.get("degraded") else "Ready" if caps.get("ready") else "Off"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🎙 VC Talkative: {vc_state}", callback_data="talk:status")],
        [InlineKeyboardButton("🧪 Capability Test", callback_data="talk:vc_cap_test"),
         InlineKeyboardButton("📊 Status", callback_data="talk:status")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_media_controls_menu(global_s: dict | None = None) -> InlineKeyboardMarkup:
    """V53 Fix #16: Multimodal & Voice main submenu with master toggle."""
    master_on = bool(global_s.get("multimodal_enabled", True)) if global_s else config.talkative_multimodal_enabled
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🎭 Multimodal: {'✅ ON' if master_on else '⏹ OFF'}",
                              callback_data="talk:toggle:multimodal_enabled")],
        [InlineKeyboardButton("🎙 Voice & Audio", callback_data="talk:mm_voice")],
        [InlineKeyboardButton("🗣 Voice Clone", callback_data="talk:mm_clone")],
        [InlineKeyboardButton("🧩 Stickers", callback_data="talk:mm_stickers")],
        [InlineKeyboardButton("🎞 GIFs", callback_data="talk:mm_gifs")],
        [InlineKeyboardButton("❤️ Reactions", callback_data="talk:mm_reactions")],
        [InlineKeyboardButton("🖼 Vision", callback_data="talk:mm_vision")],
        [InlineKeyboardButton("⚙️ Limits", callback_data="talk:mm_limits")],
        [InlineKeyboardButton("🧪 Diagnostics", callback_data="talk:mm_diag")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_mm_voice_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Voice & Audio submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🎧 Understand Voice: {on_off('voice_understand')}", callback_data="talk:toggle:voice_understand"),
         InlineKeyboardButton(f"🎙 Voice Replies: {on_off('voice_replies')}", callback_data="talk:toggle:voice_replies")],
        [InlineKeyboardButton(f"🔄 Match Reply Type: {on_off('match_reply_type')}", callback_data="talk:toggle:match_reply_type"),
         InlineKeyboardButton(f"🔊 TTS Fallback: {on_off('standard_tts_fallback')}", callback_data="talk:toggle:standard_tts_fallback")],
        [InlineKeyboardButton(f"🎚 Voice Policy: {global_s.get('voice_reply_policy', 'voice_only')}", callback_data="talk:cycle:voice_reply_policy")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_clone_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Voice Clone submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🗣 Voice Clone: {on_off('voice_clone_enabled')}", callback_data="talk:toggle:voice_clone_enabled")],
        [InlineKeyboardButton("➕ Enroll Voice", callback_data="talk:clone:enroll"),
         InlineKeyboardButton("🔄 Replace Voice", callback_data="talk:clone:replace")],
        [InlineKeyboardButton("🧪 Test Voice", callback_data="talk:clone:test"),
         InlineKeyboardButton("🗑 Delete Voice", callback_data="talk:clone:delete")],
        [InlineKeyboardButton("ℹ️ Voice Status", callback_data="talk:clone:status")],
        [InlineKeyboardButton(f"💬 Clone for Voice Msgs: {on_off('clone_for_voice_msgs')}", callback_data="talk:toggle:clone_for_voice_msgs"),
         InlineKeyboardButton(f"🎙 Clone in VC: {on_off('clone_voice_in_vc')}", callback_data="talk:toggle:clone_voice_in_vc")],
        [InlineKeyboardButton(f"🌍 Voice Everywhere: {on_off('use_voice_everywhere')}", callback_data="talk:toggle:use_voice_everywhere")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_stickers_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Stickers submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🧩 Sticker Replies: {on_off('sticker_replies')}", callback_data="talk:toggle:sticker_replies"),
         InlineKeyboardButton(f"🧩 Understand Stickers: {on_off('sticker_understanding')}", callback_data="talk:toggle:sticker_understanding")],
        [InlineKeyboardButton(f"🎯 Context-Aware: {on_off('context_stickers')}", callback_data="talk:toggle:context_stickers")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_gifs_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: GIFs submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🎞 GIF Replies: {on_off('gif_replies')}", callback_data="talk:toggle:gif_replies"),
         InlineKeyboardButton(f"🎞 Understand GIFs: {on_off('gif_understanding')}", callback_data="talk:toggle:gif_understanding")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_reactions_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Reactions submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"❤️ Native Reactions: {on_off('native_reactions')}", callback_data="talk:toggle:native_reactions")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_vision_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Vision submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🖼 Image Understanding: {on_off('image_understanding')}", callback_data="talk:toggle:image_understanding")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_limits_menu(global_s: dict) -> InlineKeyboardMarkup:
    """V52: Limits submenu."""
    def on_off(key):
        return "✅" if global_s.get(key) else "⏹"
    probs = {0.0: "Off", 0.05: "Low", 0.15: "Medium", 0.3: "High", 1.0: "Always"}
    cur_prob = config.talkative_media_probability
    prob_label = "Custom"
    for v, l in probs.items():
        if abs(cur_prob - v) < 0.01:
            prob_label = l
            break
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🎲 Probability: {prob_label}", callback_data="talk:cycle:media_prob")],
        [InlineKeyboardButton(f"⏱ Media Cooldown: {config.talkative_media_cooldown}s", callback_data="talk:cycle:media_cooldown")],
        [InlineKeyboardButton(f"🔢 Max Consecutive: {config.talkative_media_max_consecutive}", callback_data="talk:cycle:media_max_consec")],
        [InlineKeyboardButton(f"🔁 Media Dedup: {on_off('media_dedup')}", callback_data="talk:toggle:media_dedup")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_mm_diag_menu() -> InlineKeyboardMarkup:
    """V52: Multimodal diagnostics submenu."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧪 Pipeline Diagnostic", callback_data="talk:mm_diag_run")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:media_ctrl")],
    ])


def talkative_memory_controls_menu() -> InlineKeyboardMarkup:
    """#6: Memory & Context Controls submenu.

    V48 Fix: added Group Context Depth cycle button (was missing from UI).
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🧠 Memory turns", callback_data="talk:memory"),
         InlineKeyboardButton("⏱ Session timeout", callback_data="talk:timeout")],
        [InlineKeyboardButton("📋 Group Context Depth", callback_data="talk:group_ctx_msgs"),
         InlineKeyboardButton("🧹 Clear memory (this chat)", callback_data="talk:clear_mem")],
        [InlineKeyboardButton("📊 Status", callback_data="talk:status"),
         InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_engagement_controls_menu() -> InlineKeyboardMarkup:
    """#7: Engagement Controls submenu.

    Fix 3: Only buttons wired to real callbacks are shown.
    Fix 4: Ambient probability and unimplemented weight toggles removed.
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⏱ Reply Cooldown", callback_data="talk:cooldown"),
         InlineKeyboardButton("🧠 Memory Turns", callback_data="talk:memory")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_safety_controls_menu() -> InlineKeyboardMarkup:
    """#11: Safety & Limits submenu.

    V51 Fix #9: removed fake "Duplicate Suppression" and "Stale Cancellation"
    toggle buttons that routed to talk:status (no actual mutation). These
    features are always-on internal protections, not user-configurable toggles.
    Replaced with read-only status text to avoid misleading the admin.
    """
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("ℹ️ Duplicate Suppression: always on", callback_data="talk:status"),
         InlineKeyboardButton("ℹ️ Stale Cancellation: always on", callback_data="talk:status")],
        [InlineKeyboardButton("🧹 Clear memory (this chat)", callback_data="talk:clear_mem"),
         InlineKeyboardButton("📊 Status", callback_data="talk:status")],
        [InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_diagnostics_menu() -> InlineKeyboardMarkup:
    """#13 + V42 Fix #19 + V43 Fix #6/#12: Diagnostics submenu."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Provider Health", callback_data="talk:provider_health"),
         InlineKeyboardButton("🧪 Test Provider", callback_data="talk:test_provider")],
        [InlineKeyboardButton("🧪 Test DM Pipeline", callback_data="talk:test_dm_pipeline"),
         InlineKeyboardButton("🧪 Test VC Caps", callback_data="talk:vc_cap_test")],
        [InlineKeyboardButton("🔑 Add Provider Key", callback_data="talk:provider_key:add"),
         InlineKeyboardButton("📊 Status", callback_data="talk:status")],
        [InlineKeyboardButton("🔄 Refresh", callback_data="talk:diag"),
         InlineKeyboardButton("⬅ Back", callback_data="talk:menu")],
    ])


def talkative_back() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[_back("talk")]])


# V44 Fix #5: Callback audit — enumerate all rendered Talkative callback_data
# and verify exactly one registered route exists for each.

def _talkative_audit_callbacks() -> dict[str, Any]:
    """V50 Fix: audit every rendered Talkative callback_data against registered routes.

    V50 changes:
    - Menu render failures are NO LONGER silently swallowed. Each menu is
      constructed individually with error capture. If a menu fails to render,
      the audit marks it as failed and logs at ERROR.
    - The audit cannot falsely return success after skipping failed menus.
    - Distinguishes: menu render failure, callback extraction failure,
      missing handler, duplicate callback, unknown callback.

    Returns: {"valid": bool, "total": int, "missing": list, "render_failures": list, ...}
    """
    import logging as _logging
    from typing import Any as _Any
    logger = _logging.getLogger("mediagrab")
    Any = _Any
    # Build sample global settings for menu rendering.
    sample_global = {
        "enabled": False, "provider": "gemini", "personality": "",
        "language_mode": "auto", "session_timeout_seconds": 300,
        "memory_turns": 10, "group_context_enabled": True,
        "group_context_messages": 8, "cooldown_seconds": 3,
        "private_auto_reply": True, "typing_enabled": True,
        "talkative_mode": "off",
    }
    sample_chat = {"enabled": None, "talkative_mode": None}

    # V53 Fix #18: include ALL V52 submenu builders in the audit.
    menu_builders = [
        ("talkative_menu", lambda: talkative_menu(sample_global, sample_chat)),
        ("talkative_chat_controls_menu", talkative_chat_controls_menu),
        ("talkative_vc_controls_menu", talkative_vc_controls_menu),
        ("talkative_media_controls_menu", lambda: talkative_media_controls_menu(sample_global)),
        ("talkative_mm_voice_menu", lambda: talkative_mm_voice_menu(sample_global)),
        ("talkative_mm_clone_menu", lambda: talkative_mm_clone_menu(sample_global)),
        ("talkative_mm_stickers_menu", lambda: talkative_mm_stickers_menu(sample_global)),
        ("talkative_mm_gifs_menu", lambda: talkative_mm_gifs_menu(sample_global)),
        ("talkative_mm_reactions_menu", lambda: talkative_mm_reactions_menu(sample_global)),
        ("talkative_mm_vision_menu", lambda: talkative_mm_vision_menu(sample_global)),
        ("talkative_mm_limits_menu", lambda: talkative_mm_limits_menu(sample_global)),
        ("talkative_mm_diag_menu", talkative_mm_diag_menu),
        ("talkative_memory_controls_menu", talkative_memory_controls_menu),
        ("talkative_engagement_controls_menu", talkative_engagement_controls_menu),
        ("talkative_safety_controls_menu", talkative_safety_controls_menu),
        ("talkative_diagnostics_menu", talkative_diagnostics_menu),
        ("talkative_back", talkative_back),
    ]

    rendered: set[str] = set()
    render_failures: list[dict[str, str]] = []
    cb_seen: dict[str, list[str]] = {}  # callback_data → [menu_names]

    for menu_name, builder in menu_builders:
        # V50 Fix: construct each menu individually — NO silent except:pass.
        try:
            menu = builder()
        except Exception as exc:  # noqa: BLE001
            render_failures.append({
                "menu": menu_name,
                "error": type(exc).__name__,
                "reason": str(exc)[:100],
            })
            logger.error(
                "TALKATIVE_CALLBACK_AUDIT menu_render_failed menu=%s exc=%s: %s",
                menu_name, type(exc).__name__, str(exc)[:100],
            )
            continue  # skip this menu, but audit continues for others

        # V50 Fix: extract callbacks — NO silent except:pass.
        try:
            if hasattr(menu, "inline_keyboard"):
                for row in menu.inline_keyboard:
                    for btn in row:
                        if btn.callback_data:
                            rendered.add(btn.callback_data)
                            cb_seen.setdefault(btn.callback_data, []).append(menu_name)
        except Exception as exc:  # noqa: BLE001
            render_failures.append({
                "menu": menu_name,
                "error": "callback_extraction_failed",
                "reason": f"{type(exc).__name__}: {str(exc)[:80]}",
            })
            logger.error(
                "TALKATIVE_CALLBACK_AUDIT extraction_failed menu=%s exc=%s: %s",
                menu_name, type(exc).__name__, str(exc)[:80],
            )

    # Known Talkative routes (from route_callback elif branches).
    known_routes = {
        "talk:menu", "talk:enable_g", "talk:disable_g",
        "talk:enable_c", "talk:disable_c",
        "talk:provider", "talk:cooldown", "talk:memory",
        "talk:private_auto", "talk:group_ctx", "talk:group_ctx_msgs", "talk:wake", "talk:timeout",
        "talk:clear_mem", "talk:status", "talk:back",
        "talk:chat_ctrl", "talk:vc_ctrl", "talk:media_ctrl",
        "talk:mem_ctrl", "talk:eng_ctrl", "talk:safety_ctrl",
        "talk:dup_suppress", "talk:stale_cancel",
        "talk:diag", "talk:provider_health", "talk:test_provider",
        "talk:vc_cap_test", "talk:test_dm_pipeline",
        "talk:gemini_key:add", "talk:gemini_key:cancel",
        "talk:provider_key:add", "talk:provider_key:cancel",
        # V52 Multimodal & Voice routes
        "talk:mm_voice", "talk:mm_clone", "talk:mm_stickers",
        "talk:mm_gifs", "talk:mm_reactions", "talk:mm_vision",
        "talk:mm_limits", "talk:mm_diag", "talk:mm_diag_run",
        "talk:clone:enroll", "talk:clone:cancel", "talk:clone:status",
        "talk:clone:replace", "talk:clone:test", "talk:clone:delete",
    }

    # Check for missing routes (rendered but no route).
    missing = []
    for cb in rendered:
        if cb in known_routes:
            continue
        # V53 Fix: handle dynamic prefix routes.
        if cb.startswith("talk:wakedel:"):
            continue
        if cb.startswith("talk:toggle:"):
            continue  # generic toggle handler
        if cb.startswith("talk:cycle:"):
            continue  # generic cycle handler
        found = False
        for route in known_routes:
            if cb == route or cb.startswith(route + ":"):
                found = True
                break
        if not found:
            missing.append(cb)

    # V50 Fix: detect duplicate callbacks (same callback_data from multiple menus).
    duplicates = {cb: menus for cb, menus in cb_seen.items() if len(menus) > 1}

    # V50 Fix: if any menu failed to render, audit is NOT valid.
    valid = len(missing) == 0 and len(render_failures) == 0

    return {
        "valid": valid,
        "total": len(rendered),
        "rendered": sorted(rendered),
        "missing": missing,
        "render_failures": render_failures,
        "duplicates": duplicates,
    }


