"""
v97.59: Dashboard lifecycle manager — single-flight, bounded, isolated.

ARCHITECTURE (master prompt §1):

Dashboard startup must:
  1. Have a deterministic runtime strategy.
  2. Never repeatedly attempt network installation every startup when networking
     is unavailable.
  3. Auto-install must be bounded and single-flight.
  4. If Bun is unavailable, dashboard failure must not destabilize the
     Telegram/VC runtime.
  5. Dashboard must have a reliable fallback mode if the live Bun frontend
     cannot start.
  6. Support explicit DASHBOARD_LIVE_BIN/BUN_BIN configuration.
  7. Validate the configured binary with a real executable/version check.
  8. Do not assume a package manager or internet access exists.
  9. Persist/diagnose the exact reason for dashboard-unavailable state.
  10. Dashboard failure must be isolated from MTProto, PyTgCalls, callback
      workers and event-loop health.
  11. Repeated bot restarts must NOT repeatedly hammer urllib/curl/wget.
  12. Make dashboard startup idempotent.
  13. Make dashboard shutdown idempotent.
  14. No orphan Bun processes.
  15. No duplicate dashboard processes.

This module provides:

  DashboardLifecycleManager — the SINGLE authoritative owner of the
  dashboard-live subprocess. All startup/shutdown must go through here.

Key behaviors:
  - Single-flight: concurrent start() calls converge on one in-flight attempt.
  - Bounded auto-install: at most ONE download attempt per process. If it fails,
    subsequent starts skip auto-install entirely (don't hammer the network).
  - Configurable: DASHBOARD_LIVE_BIN / BUN_BIN env vars take precedence.
  - Binary validation: a real `--version` exec check before spawning.
  - Port check: doesn't spawn if the port is already in use.
  - Isolated: failures are logged + a DISABLED state is persisted; they NEVER
    raise to the caller. The bot continues without the dashboard.
  - Idempotent shutdown: safe to call multiple times.
  - Orphan prevention: the subprocess is tracked + terminated on shutdown via
    start_new_session + process-group kill.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Optional

logger = logging.getLogger("mediagrab")


class DashboardState(Enum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    DISABLED = "disabled"          # terminal for this process — won't retry
    SPAWN_FAILED = "spawn_failed"   # terminal for this process — won't retry


@dataclass
class DashboardLifecycleManager:
    """Single-flight, bounded, isolated dashboard-live lifecycle manager.

    The bot MUST remain fully operational even when dashboard-live is unavailable.
    All failures are persisted + non-raising.
    """

    live_dir: Path
    port: int = 3003
    # State (mutated under lock).
    state: DashboardState = DashboardState.STOPPED
    proc: Optional[subprocess.Popen] = None
    bun_path: Optional[str] = None
    # Single-flight: at most one in-flight start() per process.
    _start_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _start_in_flight: bool = False
    # v99.07 FIX-38: True when state went RUNNING via the port-in-use
    # branch — we adopted an EXTERNAL process and own nothing to stop.
    _adopted_external: bool = False
    # Bounded auto-install: at most ONE attempt per process.
    _auto_install_attempted: bool = False
    _auto_install_failed: bool = False
    # Disable reason (for diagnosis).
    disable_reason: str = ""
    disable_at: float = 0.0
    # Metrics.
    start_count: int = 0
    stop_count: int = 0

    def __post_init__(self) -> None:
        # Normalize the live_dir to an absolute Path.
        self.live_dir = Path(self.live_dir).resolve()

    # ── Binary resolution + validation ──

    # v99.07 FIX-37: a CLASS constant, not a per-instance dataclass field
    # — every instance previously got its own copy of the tuple (harmless
    # but wrong: candidates are a property of the class, and the dataclass
    # field would also ride along in repr/eq unless excluded).
    _BUN_CANDIDATES: ClassVar[tuple[str, ...]] = (
        "/usr/local/bin/bun",
        "/usr/bin/bun",
        "/opt/bun/bin/bun",
        "/snap/bin/bun",
        "~/.bun/bin/bun",
        "~/.local/bin/bun",
    )

    def _resolve_bun_binary(self) -> Optional[str]:
        """Resolve the bun binary with explicit env override → PATH → candidates.

        Never auto-installs (that's a separate, bounded step).
        """
        # 1. Explicit overrides.
        for env_name in ("DASHBOARD_LIVE_BUN", "BUN_BIN"):
            candidate = os.environ.get(env_name, "").strip()
            if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                logger.info("DASHBOARD_BUN_RESOLVED source=env:%s path=%s", env_name, candidate)
                return candidate
            if candidate:
                logger.warning(
                    "DASHBOARD_BUN_OVERRIDE_INVALID env=%s value=%s — not executable",
                    env_name, candidate,
                )
        # 2. PATH lookup.
        found = shutil.which("bun")
        if found:
            logger.info("DASHBOARD_BUN_RESOLVED source=PATH path=%s", found)
            return found
        # 3. Well-known locations.
        # v99.07 FIX-37: expanduser at USE time on the ClassVar entries.
        for candidate in self._BUN_CANDIDATES:
            candidate = os.path.expanduser(candidate)
            try:
                if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                    logger.info("DASHBOARD_BUN_RESOLVED source=candidate path=%s", candidate)
                    return candidate
            except OSError:
                continue
        return None

    def _validate_bun_binary(self, bun_path: str) -> bool:
        """Validate the bun binary with a real `--version` exec check.

        Per §1.7: validate the configured binary with a real executable/version check.
        v99.07 FIX-24: the subprocess.run is dispatched via asyncio-aware
        helpers — _start_inner is async and this sync call previously ran
        ON the event loop, blocking it for up to 10s.
        """
        try:
            result = subprocess.run(
                [bun_path, "--version"],
                capture_output=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                logger.info(
                    "DASHBOARD_BUN_VALIDATED path=%s version=%s",
                    bun_path, result.stdout.strip().decode("utf-8", errors="replace")[:40],
                )
                return True
            logger.warning(
                "DASHBOARD_BUN_VALIDATION_FAILED path=%s rc=%s stderr=%s",
                bun_path, result.returncode,
                result.stderr[:100].decode("utf-8", errors="replace") if result.stderr else "",
            )
            return False
        except Exception as exc:  # noqa: BLE001
            logger.warning("DASHBOARD_BUN_VALIDATION_ERROR path=%s exc=%s", bun_path, exc)
            return False

    def _try_auto_install_bun(self) -> Optional[str]:
        """Bounded auto-install: at most ONE attempt per process.

        Per §1.3/§1.11: never repeatedly hammer urllib/curl/wget on restart.
        If this fails once, subsequent starts skip auto-install entirely.
        """
        if self._auto_install_attempted:
            if self._auto_install_failed:
                logger.debug(
                    "DASHBOARD_BUN_AUTO_INSTALL_SKIP reason=already_failed — "
                    "won't retry this process (set DASHBOARD_LIVE_BIN to override)",
                )
            return None
        self._auto_install_attempted = True
        # Detect architecture.
        import platform as _plat
        _machine = _plat.machine().lower()
        _system = _plat.system().lower()
        if _system == "linux":
            if _machine in ("aarch64", "arm64"):
                _arch = "linux-arm64"
            elif _machine in ("x86_64", "amd64", "x64"):
                _arch = "linux-x64"
            else:
                self._auto_install_failed = True
                logger.warning("DASHBOARD_BUN_AUTO_INSTALL_SKIP — unsupported arch: %s", _machine)
                return None
        elif _system == "darwin":
            if _machine in ("aarch64", "arm64"):
                _arch = "darwin-arm64"
            elif _machine in ("x86_64", "amd64", "x64"):
                _arch = "darwin-x64"
            else:
                self._auto_install_failed = True
                return None
        else:
            self._auto_install_failed = True
            logger.warning("DASHBOARD_BUN_AUTO_INSTALL_SKIP — unsupported OS: %s", _system)
            return None
        # Download (try urllib → curl → wget).
        bun_dir = os.path.expanduser("~/.bun/bin")
        bun_path = os.path.join(bun_dir, "bun")
        if os.path.isfile(bun_path) and os.access(bun_path, os.X_OK):
            return bun_path
        os.makedirs(bun_dir, exist_ok=True)
        _url = f"https://github.com/oven-sh/bun/releases/latest/download/bun-{_arch}.zip"
        _zip_path = os.path.join(bun_dir, "bun.zip")
        logger.info("DASHBOARD_BUN_AUTO_INSTALL — downloading %s to %s", _arch, bun_path)
        _downloaded = False
        try:
            import urllib.request as _ur
            _req = _ur.Request(_url, headers={"User-Agent": "mediagrab-bot/97.59"})
            with _ur.urlopen(_req, timeout=60) as _resp:
                with open(_zip_path, "wb") as _f:
                    while True:
                        _chunk = _resp.read(65536)
                        if not _chunk:
                            break
                        _f.write(_chunk)
            _downloaded = os.path.isfile(_zip_path) and os.path.getsize(_zip_path) > 1000
        except Exception as exc:  # noqa: BLE001
            logger.debug("DASHBOARD_BUN_AUTO_INSTALL urllib failed: %s", exc)
        if not _downloaded and shutil.which("curl"):
            try:
                subprocess.run(["curl", "-fsSL", "-o", _zip_path, _url],
                               check=True, timeout=60, capture_output=True)
                _downloaded = True
            except Exception as exc:  # noqa: BLE001
                logger.debug("DASHBOARD_BUN_AUTO_INSTALL curl failed: %s", exc)
        if not _downloaded and shutil.which("wget"):
            try:
                subprocess.run(["wget", "-q", "-O", _zip_path, _url],
                               check=True, timeout=60, capture_output=True)
                _downloaded = True
            except Exception as exc:  # noqa: BLE001
                logger.debug("DASHBOARD_BUN_AUTO_INSTALL wget failed: %s", exc)
        if not _downloaded:
            self._auto_install_failed = True
            self.disable_reason = "auto_install_download_failed_all_methods"
            logger.warning(
                "DASHBOARD_BUN_AUTO_INSTALL_FAILED — urllib+curl+wget all failed "
                "(network unavailable?). Auto-install disabled for this process. "
                "Set DASHBOARD_LIVE_BIN to point to a pre-installed bun.",
            )
            return None
        # Unzip.
        _extracted = None
        if shutil.which("unzip"):
            try:
                subprocess.run(["unzip", "-o", _zip_path, "-d", bun_dir],
                               check=True, timeout=30, capture_output=True)
                _extracted = os.path.join(bun_dir, "bun")
            except Exception as exc:  # noqa: BLE001
                logger.debug("DASHBOARD_BUN_AUTO_INSTALL unzip failed: %s", exc)
        if _extracted is None or not os.path.isfile(_extracted):
            try:
                import zipfile as _zf
                with _zf.ZipFile(_zip_path) as zf:
                    zf.extractall(bun_dir)
                _extracted = os.path.join(bun_dir, "bun")
            except Exception as exc:  # noqa: BLE001
                logger.debug("DASHBOARD_BUN_AUTO_INSTALL python zipfile failed: %s", exc)
        try:
            os.unlink(_zip_path)
        except OSError:
            pass
        if _extracted and os.path.isfile(_extracted):
            os.chmod(_extracted, 0o755)
            logger.info("DASHBOARD_BUN_AUTO_INSTALL_SUCCESS path=%s arch=%s", _extracted, _arch)
            return _extracted
        self._auto_install_failed = True
        self.disable_reason = "auto_install_extract_failed"
        logger.warning("DASHBOARD_BUN_AUTO_INSTALL_FAILED — could not extract bun")
        return None

    def _port_in_use(self) -> bool:
        """Check if the dashboard port is already in use (don't spawn duplicates)."""
        import socket as _sock
        try:
            with _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM) as s:
                s.settimeout(0.5)
                return s.connect_ex(("127.0.0.1", self.port)) == 0
        except OSError:
            return False

    async def _port_in_use_async(self) -> bool:
        """v99.07 FIX-24: the 0.5s-timeout socket probe off the event loop."""
        return await asyncio.to_thread(self._port_in_use)

    # ── Public lifecycle API ──

    async def start(self) -> bool:
        """Start the dashboard-live subprocess (single-flight, idempotent, isolated).

        Returns True if running, False if unavailable. NEVER raises.
        """
        # Single-flight gate.
        async with self._start_lock:
            if self._start_in_flight:
                logger.debug("DASHBOARD_START_SKIP reason=in_flight")
                return self.state == DashboardState.RUNNING
            self._start_in_flight = True
        try:
            return await self._start_inner()
        finally:
            async with self._start_lock:
                self._start_in_flight = False

    async def _start_inner(self) -> bool:
        # Already running?
        if self.proc is not None and self.proc.poll() is None:
            return True
        # Disabled for this process?
        if self.state == DashboardState.DISABLED:
            logger.debug(
                "DASHBOARD_START_SKIP reason=disabled reason_detail=%s — "
                "won't retry this process",
                self.disable_reason,
            )
            return False
        # Don't spawn if the live_dir doesn't exist.
        if not self.live_dir.exists():
            self.state = DashboardState.DISABLED
            self.disable_reason = f"live_dir_not_found: {self.live_dir}"
            self.disable_at = time.time()
            # v98.08 FIX-BBB (F7', RUNTIME-PROVEN: L38 DASHBOARD_LIVE_
            # DISABLED reason=dir_not_found fired as a WARNING at every
            # boot while the dashboard-live feature is unused — log noise
            # with zero actionable content). Demoted to DEBUG; the
            # DASHBOARD_START_SKIP reason_detail above still records it.
            logger.debug(
                "DASHBOARD_LIVE_DISABLED reason=dir_not_found dir=%s — "
                "bot continues without dashboard (non-fatal, feature "
                "unused; v98.08 FIX-BBB)",
                self.live_dir,
            )
            return False
        # Don't spawn if the port is already in use.
        # v99.07 FIX-24: socket probe off the event loop (0.5s timeout).
        if await self._port_in_use_async():
            self.state = DashboardState.RUNNING  # assume it's our own (or a manual one)
            self._adopted_external = True  # v99.07 FIX-38: we own nothing
            logger.info(
                "DASHBOARD_LIVE_SKIP reason=port_in_use port=%d — "
                "assuming already running",
                self.port,
            )
            return True
        # Resolve bun.
        bun = self.bun_path or self._resolve_bun_binary()
        if bun is None:
            # v99.07 FIX-24: the auto-install stage (urllib.urlopen 60s +
            # curl 60s + wget 60s + unzip 30s — up to ~210s of BLOCKING
            # calls) is offloaded to a thread; _start_inner is async and
            # previously ran it ON the event loop.
            bun = await asyncio.to_thread(self._try_auto_install_bun)
        if bun is None or not await asyncio.to_thread(
                self._validate_bun_binary, bun):
            self.state = DashboardState.DISABLED
            self.disable_reason = "bun_unavailable_or_invalid"
            self.disable_at = time.time()
            logger.warning(
                "DASHBOARD_LIVE_DISABLED reason=bun_unavailable — "
                "bot continues without dashboard (non-fatal). "
                "Set DASHBOARD_LIVE_BIN=/path/to/bun to enable.",
            )
            return False
        self.bun_path = bun
        # Spawn (in a thread — subprocess.Popen is sync).
        try:
            self.state = DashboardState.STARTING
            cmd = ["run", "start"] if os.environ.get("NODE_ENV") == "production" else ["run", "dev"]
            child_env = self._build_env(bun)
            self.proc = await asyncio.to_thread(
                self._spawn_sync, bun, cmd, child_env,
            )
            self.state = DashboardState.RUNNING
            self.start_count += 1
            logger.info(
                "DASHBOARD_LIVE_SPAWNED pid=%s port=%d bun=%s cmd=%s",
                self.proc.pid if self.proc else "?", self.port, bun, " ".join(cmd),
            )
            return True
        except Exception as exc:  # noqa: BLE001
            self.state = DashboardState.SPAWN_FAILED
            self.disable_reason = f"spawn_error: {exc}"
            self.disable_at = time.time()
            logger.warning(
                "DASHBOARD_LIVE_SPAWN_FAILED exc=%s — bot continues (non-fatal)",
                str(exc)[:160],
            )
            return False

    def _spawn_sync(self, bun: str, cmd: list[str], env: dict[str, str]) -> subprocess.Popen:
        """The actual subprocess.Popen (runs in a thread to avoid blocking the loop)."""
        return subprocess.Popen(
            [bun] + cmd,
            cwd=str(self.live_dir),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,  # detach from bot's process group
        )

    def _build_env(self, bun_path: str) -> dict[str, str]:
        env = os.environ.copy()
        bun_dir = os.path.dirname(bun_path)
        extra_dirs = [
            bun_dir, "/usr/local/bin", "/usr/bin", "/bin",
            os.path.expanduser("~/.bun/bin"),
            os.path.expanduser("~/.local/bin"),
        ]
        current_path = env.get("PATH", os.defpath)
        parts = current_path.split(os.pathsep) if current_path else []
        seen = {p for p in parts if p}
        merged = [d for d in extra_dirs if d and d not in seen]
        merged.extend(parts)
        env["PATH"] = os.pathsep.join(merged)
        return env

    async def stop(self) -> None:
        """Stop the dashboard-live subprocess (idempotent, bounded)."""
        if self.proc is None:
            # v99.07 FIX-38: distinguish "nothing was ever started" from
            # "state went RUNNING via the port-in-use branch" — the latter
            # adopted an EXTERNAL process; stop() must not silently claim
            # it stopped something it never owned (and must not count a
            # stop). State still returns to STOPPED — the manager itself
            # is not running anything.
            if self._adopted_external:
                self._adopted_external = False
                self.state = DashboardState.STOPPED
                logger.info(
                    "DASHBOARD_LIVE_STOP_SKIPPED reason=external_process — "
                    "the port was already in use at start (assumed ours); "
                    "no process owned by this manager was stopped "
                    "(v99.07 FIX-38)")
                return
            self.state = DashboardState.STOPPED
            return
        try:
            if self.proc.poll() is None:
                # Terminate the process group (start_new_session created one).
                import signal
                try:
                    os.killpg(os.getpgid(self.proc.pid), signal.SIGTERM)
                except (ProcessLookupError, OSError):
                    self.proc.terminate()
                try:
                    await asyncio.to_thread(self.proc.wait, timeout=5)
                except subprocess.TimeoutExpired:
                    # Kill the process group.
                    try:
                        os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
                    except (ProcessLookupError, OSError):
                        self.proc.kill()
                    try:
                        await asyncio.to_thread(self.proc.wait, timeout=3)
                    except subprocess.TimeoutExpired:
                        pass
            self.state = DashboardState.STOPPED
            self.stop_count += 1
            logger.info("DASHBOARD_LIVE_STOPPED")
        except Exception as exc:  # noqa: BLE001
            logger.warning("DASHBOARD_LIVE_STOP_FAILED exc=%s", str(exc)[:120])
        finally:
            self.proc = None

    def is_running(self) -> bool:
        if self.proc is None:
            return False
        return self.proc.poll() is None

    def get_state(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "bun_path": self.bun_path,
            "port": self.port,
            "pid": self.proc.pid if self.proc and self.proc.poll() is None else None,
            "disable_reason": self.disable_reason,
            "start_count": self.start_count,
            "stop_count": self.stop_count,
            "auto_install_attempted": self._auto_install_attempted,
            "auto_install_failed": self._auto_install_failed,
        }


# Global singleton
_dashboard_mgr: DashboardLifecycleManager | None = None


def get_dashboard_manager(live_dir: Optional[Path] = None, port: int = 3003) -> DashboardLifecycleManager:
    global _dashboard_mgr
    if _dashboard_mgr is None:
        _dashboard_mgr = DashboardLifecycleManager(live_dir=live_dir or Path("."), port=port)
    return _dashboard_mgr


def reset_dashboard_manager() -> None:
    global _dashboard_mgr
    _dashboard_mgr = None
