"""
v97.59: Deterministic shutdown state machine.

ARCHITECTURE (master prompt §15/§25):

Shutdown must be a real state machine with phases, not "wait 30s then force-clear".

Phases (in order):
  STOP_ACCEPTING_WORK        — stop accepting new VC operations / callbacks
  STOP_CALLBACK_INGRESS      — stop the callback queue workers
  STOP_JOIN_ALL              — cancel + verify Join-All worker stopped
  STOP_RECONCILIATION        — stop reconcile loops
  STOP_DASHBOARD_REFRESH     — stop dashboard auto-refresh loops
  STOP_PERIODIC_WORKERS      — stop heartbeat / history / snapshot / cleanup
  RETIRE_MTPROTO_GENERATIONS — retire all MTProto generations safely
  STOP_BOT_POLLING           — stop PTB polling
  CLOSE_PYTGCALLS            — close PyTgCalls backends
  CLOSE_DATABASE             — close the DB connection
  FINAL_TASK_VERIFICATION    — verify no owned application task remains alive

Each phase has:
  - a timeout
  - a cancellation policy
  - a verification step

At final verification: no owned application task may remain alive. If an
unavoidable third-party task remains, it's identified + its owner generation
is marked retired/poisoned so it cannot affect new state.

NEVER force-clear state while a live worker exists (per §10 — that creates
split-brain ownership).
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional

logger = logging.getLogger("mediagrab")


class ShutdownPhase(Enum):
    PENDING = "pending"
    STOP_ACCEPTING_WORK = "stop_accepting_work"
    STOP_CALLBACK_INGRESS = "stop_callback_ingress"
    STOP_JOIN_ALL = "stop_join_all"
    STOP_RECONCILIATION = "stop_reconciliation"
    STOP_DASHBOARD_REFRESH = "stop_dashboard_refresh"
    STOP_PERIODIC_WORKERS = "stop_periodic_workers"
    RETIRE_MTPROTO_GENERATIONS = "retire_mtproto_generations"
    STOP_BOT_POLLING = "stop_bot_polling"
    CLOSE_PYTGCALLS = "close_pytgcalls"
    CLOSE_DATABASE = "close_database"
    FINAL_TASK_VERIFICATION = "final_task_verification"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class PhaseResult:
    phase: ShutdownPhase
    success: bool
    duration_seconds: float
    detail: str = ""
    orphan_tasks: list[str] = field(default_factory=list)


class ShutdownStateMachine:
    """Deterministic shutdown with phases + verification (master prompt §15)."""

    def __init__(self):
        self.phase: ShutdownPhase = ShutdownPhase.PENDING
        self.results: list[PhaseResult] = []
        self._stop_callbacks: list[tuple[str, Callable[[], Awaitable[bool]], float]] = []
        self._verify_callbacks: list[tuple[str, Callable[[], Awaitable[bool]]]] = []
        self._started_at = 0.0
        self._completed_at = 0.0

    def register_stop(self, name: str, fn: Callable[[], Awaitable[bool]], timeout: float = 10.0) -> None:
        """Register a stop function for a named subsystem."""
        self._stop_callbacks.append((name, fn, timeout))

    def register_verify(self, name: str, fn: Callable[[], Awaitable[bool]]) -> None:
        """Register a verification function (must return True if clean)."""
        self._verify_callbacks.append((name, fn))

    async def _run_phase(self, phase: ShutdownPhase, fn: Callable[[], Awaitable[bool]],
                         timeout: float = 10.0) -> PhaseResult:
        """Run one shutdown phase with timeout + verification."""
        t0 = time.monotonic()
        logger.info("SHUTDOWN_PHASE_START phase=%s timeout=%.1fs", phase.value, timeout)
        success = False
        detail = ""
        try:
            success = await asyncio.wait_for(fn(), timeout=timeout)
        except asyncio.TimeoutError:
            detail = f"timeout_after_{timeout}s"
            logger.warning("SHUTDOWN_PHASE_TIMEOUT phase=%s timeout=%.1fs", phase.value, timeout)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            detail = f"{type(exc).__name__}: {exc}"
            logger.warning("SHUTDOWN_PHASE_ERROR phase=%s exc=%s", phase.value, detail[:120])
        duration = time.monotonic() - t0
        result = PhaseResult(
            phase=phase, success=bool(success), duration_seconds=duration,
            detail=detail,
        )
        self.results.append(result)
        logger.info(
            "SHUTDOWN_PHASE_DONE phase=%s success=%s duration=%.1fs detail=%s",
            phase.value, result.success, duration, detail[:80],
        )
        return result

    async def run(self) -> bool:
        """Run the full shutdown sequence. Returns True if all phases succeeded."""
        self._started_at = time.monotonic()
        logger.info("SHUTDOWN_START phases=%d", len(self._stop_callbacks))
        all_ok = True
        try:
            # Run registered stop callbacks in order.
            for name, fn, timeout in self._stop_callbacks:
                phase = ShutdownPhase(name) if name in [p.value for p in ShutdownPhase] else ShutdownPhase.STOP_PERIODIC_WORKERS
                result = await self._run_phase(phase, fn, timeout=timeout)
                if not result.success:
                    all_ok = False
            # Final verification.
            self.phase = ShutdownPhase.FINAL_TASK_VERIFICATION
            orphan_tasks: list[str] = []
            for name, vfn in self._verify_callbacks:
                try:
                    clean = await vfn()
                    if not clean:
                        all_ok = False
                        orphan_tasks.append(name)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("SHUTDOWN_VERIFY_ERROR name=%s exc=%s", name, str(exc)[:120])
                    all_ok = False
                    orphan_tasks.append(f"{name}:verify_error")
            if orphan_tasks:
                logger.warning(
                    "SHUTDOWN_ORPHAN_TASKS detected=%s — these must be retired/poisoned",
                    orphan_tasks,
                )
            self.phase = ShutdownPhase.COMPLETED if all_ok else ShutdownPhase.FAILED
        except asyncio.CancelledError:
            self.phase = ShutdownPhase.FAILED
            raise
        except Exception as exc:  # noqa: BLE001
            self.phase = ShutdownPhase.FAILED
            logger.error("SHUTDOWN_FATAL_ERROR exc=%s", str(exc)[:160])
            all_ok = False
        finally:
            self._completed_at = time.monotonic()
            total = self._completed_at - self._started_at
            logger.info(
                "SHUTDOWN_COMPLETE total=%.1fs phase=%s all_ok=%s orphans=%d",
                total, self.phase.value, all_ok, len(orphan_tasks) if 'orphan_tasks' in locals() else 0,
            )
        return all_ok

    def get_report(self) -> dict[str, Any]:
        return {
            "phase": self.phase.value,
            "total_duration": round(self._completed_at - self._started_at, 2)
                              if self._completed_at else 0,
            "phases": [
                {
                    "phase": r.phase.value,
                    "success": r.success,
                    "duration": round(r.duration_seconds, 2),
                    "detail": r.detail,
                    "orphan_tasks": r.orphan_tasks,
                }
                for r in self.results
            ],
        }


# Global singleton
_shutdown_sm: ShutdownStateMachine | None = None


def get_shutdown_state_machine() -> ShutdownStateMachine:
    global _shutdown_sm
    if _shutdown_sm is None:
        _shutdown_sm = ShutdownStateMachine()
    return _shutdown_sm
