"""Backup utilities — extracted from _bot_core.py.

Provides user data export/import and global stats export.
Dependencies (repo, safe_filename, config) are injected to avoid circular imports.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiofiles

logger = logging.getLogger("mediagrab")

# Injected dependencies (set by handlers.py at import time via
# _set_dependencies).
_repo = None
_safe_filename_fn = None
_config = None


def _set_dependencies(repo, safe_filename_fn, config):
    """Inject dependencies (called at import time by handlers.py)."""
    global _repo, _safe_filename_fn, _config
    _repo = repo
    _safe_filename_fn = safe_filename_fn
    _config = config


def _deps():
    """v99.07 FIX-36: resolve (repo, safe_filename, config) with fallbacks.

    The injection was asymmetric — nothing inside backup.py guaranteed the
    setters ran before use, leaving _repo/_safe_filename_fn/_config one
    import-order change away from None (the exact FIX-9 shape in db_layer).
    The injected values stay authoritative when present; otherwise the
    module-level imports (the same objects) are used.
    """
    # v99.07 FIX-36: direct-import fallbacks (same objects handlers injects).
    if _repo is None or _safe_filename_fn is None or _config is None:
        from . import db_layer as _db_layer_mod
        from .utils_real import safe_filename as _safe_filename_direct
        from .config import config as _config_direct
        return (
            _repo if _repo is not None else _db_layer_mod.repo,
            _safe_filename_fn if _safe_filename_fn is not None else _safe_filename_direct,
            _config if _config is not None else _config_direct,
        )
    return _repo, _safe_filename_fn, _config


async def export_user_json(user_id: int) -> Path:
    """Export the user's data to a JSON file and return its path.

    v97 FIX: all file I/O (mkdir, exists loop, os.open, write, replace,
    chmod) is offloaded to asyncio.to_thread to avoid blocking the event
    loop. The JSON serialization is also done in the thread.
    """
    data = await _deps()[0].export_user_data(user_id)
    data["exported_at"] = datetime.now(timezone.utc).isoformat()
    data["bot_version"] = "mediagrab-ai-bot"

    def _write_backup_sync() -> Path:
        # v99.07 FIX-36: resolve dependencies through _deps().
        _bk_repo, _bk_safe_name, _bk_config = _deps()
        # v97 CHAOS-3 FIX: use backups_dir (not frames_dir) — frames_dir is
        # auto-cleaned by periodic_cleanup, which would delete user backups.
        out_dir = _bk_config.backups_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        name = _bk_safe_name(f"mediagrab_backup_{user_id}.json")
        target = out_dir / name
        text = json.dumps(data, indent=2, default=str, ensure_ascii=False)
        # v99.07 FIX-35: ATOMIC unique-name claim — the old
        # ``while target.exists(): target = ..._{i}.json`` loop was a
        # TOCTOU race between concurrent exports for the same user (both
        # coroutines could observe the same free name, then both write
        # it — one export silently overwriting the other). O_CREAT|O_EXCL
        # claims the name atomically; FileExistsError advances the suffix.
        # Content is written through the EXCLUSIVE fd (0600) — the name
        # can never be double-claimed and never shows mixed content from
        # two writers (SEC-C-003/FS-C-004 perms preserved).
        claimed_fd = -1
        i = 0
        while claimed_fd < 0:
            try:
                claimed_fd = os.open(
                    target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            except FileExistsError:
                i += 1
                target = out_dir / f"mediagrab_backup_{user_id}_{i}.json"
                if i > 1000:  # bounded — a pathological FS state must not loop forever
                    raise
        try:
            with os.fdopen(claimed_fd, "w", encoding="utf-8") as fh:
                fh.write(text)
            os.chmod(target, 0o600)
        except Exception:
            try:
                target.unlink(missing_ok=True)
            except Exception:
                pass
            raise
        logger.info("Exported backup for user %s -> %s (%d bytes)",
                    user_id, target.name, len(text))
        return target

    return await asyncio.to_thread(_write_backup_sync)


async def parse_backup_file(path: Path) -> dict:
    """Read a backup JSON file into a dict.

    ERR-C-001: rejects files larger than 50 MB to avoid OOMing on a malicious
    or accidental giant backup.
    """
    st = path.stat()
    if st.st_size > 50 * 1024 * 1024:
        raise ValueError(f"Backup too large: {st.st_size} bytes")
    async with aiofiles.open(path, "r", encoding="utf-8") as fh:
        text = await fh.read()
    return json.loads(text)


async def restore_from_dict(user_id: int, data: dict) -> dict[str, int]:
    """Restore a user's settings from a backup dict."""
    settings = data.get("settings") or {}
    # SEC-C-006: ensure ``settings`` is a dict object before passing it to
    # the repo layer — a backup with ``"settings": [...]`` or a string would
    # otherwise cause confusing SQL errors downstream.
    if not isinstance(settings, dict):
        raise ValueError("Backup 'settings' must be an object")
    await _deps()[0].restore_user_settings(user_id, settings)
    return {"settings": len(settings)}


async def export_global_json() -> Path:
    """Admin-only: export aggregate global stats (no per-user PII).

    v97 FIX: offload all file I/O to asyncio.to_thread.
    """
    stats = await _deps()[0].global_stats()
    data = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "global_stats": stats,
    }

    def _write_global_sync() -> Path:
        # v97 CHAOS-3 FIX: use backups_dir (not frames_dir).
        out_dir = _deps()[2].backups_dir
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / "mediagrab_global_stats.json"
        text = json.dumps(data, indent=2, default=str, ensure_ascii=False)
        # FS-C-001 + SEC-C-003 + FS-C-004: atomic write with 0600 perms.
        tmp = target.with_suffix(target.suffix + ".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(text)
            os.replace(tmp, target)
            os.chmod(target, 0o600)
        except Exception:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
            raise
        return target

    return await asyncio.to_thread(_write_global_sync)


