"""Downloader — extracted from _bot_core.py.

Downloads files via the Telegram Bot API with progress reporting,
retry logic, and size validation.
Dependencies (config, with_retries, download_slot) are injected.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import aiofiles
import httpx

from .config import config
from .utils_real import safe_filename, unique_path, remove_path

logger = logging.getLogger("mediagrab")

# Injected dependencies
_config = None
_with_retries_fn = None
_download_slot = None


def _set_dependencies(config, with_retries_fn, download_slot):
    """Called by _bot_core.py to inject dependencies."""
    global _config, _with_retries_fn, _download_slot
    _config = config
    _with_retries_fn = with_retries_fn
    _download_slot = download_slot

ProgressCB = Callable[[float, int, int, str], Awaitable[None]]

_FILE_URL_TEMPLATE = "https://api.telegram.org/file/bot{token}/{file_path}"


class DownloadError(Exception):
    pass


class FileTooLarge(DownloadError):
    pass


class _ProgressThrottle:
    """Calls the user callback at most every ``min_interval`` seconds OR
    every ``min_step`` percent, whichever comes first."""

    def __init__(self, cb: ProgressCB | None, *, min_interval: float = 1.0,
                 min_step: float = 4.0):
        self.cb = cb
        self.min_interval = min_interval
        self.min_step = min_step
        self._last_ts = 0.0
        self._last_pct = -100.0
        self._start_ts = 0.0
        self._received_at_start = 0

    def reset(self, received_at_start: int = 0) -> None:
        self._last_ts = 0.0
        self._last_pct = -100.0
        self._start_ts = time.monotonic()
        self._received_at_start = received_at_start

    async def _maybe_emit(self, received: int, total: int) -> None:
        if self.cb is None or total <= 0:
            return
        pct = received / total * 100.0
        now = time.monotonic()
        speed = ""
        delta = received - self._received_at_start
        elapsed = now - self._start_ts
        if elapsed > 0 and delta > 0:
            speed = _fmt_speed(delta / elapsed)
        due_time = (now - self._last_ts) >= self.min_interval
        due_step = (pct - self._last_pct) >= self.min_step
        # Phase 10 — edge-trigger for 100% completion: emit at most ONCE per
        # transfer.  The old level-trigger (`pct >= 100.0` alone) emitted on
        # every callback at 100%, causing Telegram edit flood.  The edge-
        # trigger fires only when we cross from <100% to >=100%.
        due_completion = pct >= 100.0 and self._last_pct < 100.0
        if due_time or due_step or due_completion:
            self._last_ts = now
            self._last_pct = pct
            try:
                await self.cb(pct, received, total, speed)
            except Exception as exc:  # noqa: BLE001
                logger.debug("progress cb error (ignored): %s", exc)


def _fmt_speed(bps: float) -> str:
    for unit in ("B/s", "KB/s", "MB/s", "GB/s"):
        if bps < 1024 or unit == "GB/s":
            return f"{bps:.1f} {unit}"
        bps /= 1024
    return f"{bps:.1f} GB/s"


async def download_forwarded(
    message,
    *,
    progress: ProgressCB | None = None,
    bot,
) -> tuple[Path, str, str, int]:
    """Download media from a forwarded PTB message using the Bot API only.

    Returns ``(path, filename, media_type, size_bytes)``.
    """
    media_type = _ptb_media_type(message)
    file_id, declared_size, suggested_name = _ptb_file_meta(message, media_type)

    if not file_id:
        raise DownloadError("No downloadable media found in that message.")

    if declared_size and declared_size > config.download_limit_bytes:
        raise FileTooLarge(
            f"File is ~{declared_size // (1024 * 1024)} MB; the official Bot "
            f"API can download up to {_config.max_file_size_mb} MB."
        )

    if suggested_name:
        suggested_name = safe_filename(suggested_name)
    else:
        ext = _ext_for_media_type(media_type)
        suggested_name = safe_filename(f"media_{message.message_id}{ext}")

    target = unique_path(config.downloads_dir, suggested_name)

    try:
        tg_file = await bot.get_file(file_id)
    except Exception as exc:  # noqa: BLE001
        raise DownloadError(f"getFile failed: {exc}") from exc

    remote_path = getattr(tg_file, "file_path", None)
    if not remote_path:
        raise DownloadError("Telegram returned no file_path for that media.")
    total_size = int(getattr(tg_file, "file_size", 0) or declared_size or 0)

    if config.local_mode and os.path.isabs(remote_path) and os.path.exists(remote_path):
        path = await _copy_local(Path(remote_path), target, total_size, progress)
        size = path.stat().st_size if path.exists() else 0
        return path, path.name, media_type, size

    url = _file_url(bot.token, remote_path)
    path = await _stream_to_disk(
        url, target, total_size=total_size, progress=progress, bot_token=bot.token
    )
    size = path.stat().st_size if path.exists() else 0
    return path, path.name, media_type, size


def _file_url(token: str, file_path: str) -> str:
    """Build the official Bot API file download URL for the active mode."""
    if config.local_mode:
        base = config.bot_api_file_url.rstrip("/")
        return f"{base}/file/bot{token}/{file_path}"
    return _FILE_URL_TEMPLATE.format(token=token, file_path=file_path)


async def _copy_local(src: Path, target: Path, total_size: int,
                      progress: ProgressCB | None) -> Path:
    """Stream-copy a locally-available file (local Bot API server mode)."""
    throttle = _ProgressThrottle(progress)
    throttle.reset()
    chunk = config.chunk_size_bytes
    received = 0
    async with aiofiles.open(src, "rb") as r, aiofiles.open(target, "wb") as w:
        while True:
            raw = await r.read(chunk)
            if not raw:
                break
            await w.write(raw)
            received += len(raw)
            await throttle._maybe_emit(received, total_size or received)
    return target


async def _stream_to_disk(
    url: str,
    target: Path,
    *,
    total_size: int,
    progress: ProgressCB | None,
    bot_token: str,
) -> Path:
    """Stream ``url`` to ``target`` in chunks, with resume + retries."""
    part_path = target.with_suffix(target.suffix + ".part")
    throttle = _ProgressThrottle(progress)

    async def _attempt() -> Path:
        existing = part_path.stat().st_size if part_path.exists() else 0
        throttle.reset(received_at_start=existing)

        headers: dict[str, str] = {}
        mode = "ab" if existing else "wb"
        if existing:
            headers["Range"] = f"bytes={existing}-"
            logger.info("Resuming %s from byte %d", target.name, existing)

        timeout = httpx.Timeout(
            connect=30.0,
            read=float(_config.download_timeout),
            write=30.0,
            pool=60.0,
        )
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            async with client.stream("GET", url, headers=headers) as resp:
                if resp.status_code == 416:
                    if part_path.exists() and total_size and \
                            part_path.stat().st_size >= total_size:
                        part_path.rename(target)
                        return target
                    part_path.unlink(missing_ok=True)
                    raise DownloadError("Range request not satisfiable.")

                if resp.status_code == 206:
                    mode_eff = "ab"
                    received = existing
                elif resp.status_code == 200:
                    mode_eff = "wb"
                    received = 0
                else:
                    raise DownloadError(
                        f"Telegram file server returned HTTP {resp.status_code}"
                    )

                content_length = resp.headers.get("Content-Length")
                if content_length and content_length.isdigit():
                    cl = int(content_length)
                    if mode_eff == "ab" and existing:
                        total = existing + cl
                    else:
                        total = cl
                else:
                    total = total_size or 0

                # SEC-C-002: enforce declared Content-Length ceiling before
                # touching disk; reject responses that exceed the configured
                # download limit.
                if total and total > config.download_limit_bytes:
                    part_path.unlink(missing_ok=True)
                    raise FileTooLarge(
                        f"File is ~{total // (1024 * 1024)} MB; exceeds download "
                        f"limit ({config.download_limit_bytes // (1024 * 1024)} MB)."
                    )

                chunk = config.chunk_size_bytes
                async with aiofiles.open(part_path, mode_eff) as fh:
                    async for raw in resp.aiter_bytes(chunk):
                        await fh.write(raw)
                        received += len(raw)
                        # SEC-C-002: cap received bytes — Content-Length can be
                        # missing or spoofed, so enforce the limit per-chunk too.
                        if received > config.download_limit_bytes:
                            await remove_path(part_path)
                            raise FileTooLarge(
                                "Stream exceeded download_limit_bytes"
                            )
                        if total:
                            await throttle._maybe_emit(min(received, total), total)
                    # FS-C-003: flush + fsync before the file is closed so the
                    # subsequent rename() lands a fully-durable .part file.
                    # ``aiofiles.os`` isn't auto-imported by ``import aiofiles``
                    # and we can't add new top-level imports in Section A, so
                    # use the running loop's executor to run sync ``os.fsync``
                    # off the event loop.
                    await fh.flush()
                    _loop = asyncio.get_running_loop()
                    await _loop.run_in_executor(None, os.fsync, fh.fileno())

                final_size = part_path.stat().st_size
                if total and final_size < total:
                    raise DownloadError(
                        f"Incomplete download: {final_size}/{total} bytes"
                    )
                if total and final_size > total:
                    logger.warning("Downloaded %d > expected %d; restarting",
                                   final_size, total)
                    part_path.unlink(missing_ok=True)
                    raise DownloadError("Downloaded size exceeds expected.")

        part_path.rename(target)
        # Phase 10 — final 100% emission.  Do NOT reset() here (the old code
        # reset _last_pct=-100 then called _maybe_emit, causing a duplicate
        # 100% emission because the level-trigger fired again).  With the
        # edge-trigger, if 100% was already emitted in-loop, this is a no-op;
        # if it wasn't (e.g. total=0 or last chunk didn't trigger), the edge-
        # trigger allows it exactly once.
        await throttle._maybe_emit(total or target.stat().st_size,
                                   total or target.stat().st_size)
        return target

    try:
        return await _with_retries_fn(_attempt, retries=_config.max_retries)
    except Exception:
        await remove_path(part_path)
        raise


def _ptb_media_type(message) -> str:
    if message.video:
        return "video"
    if message.animation:
        return "gif"
    if message.sticker:
        return "sticker"
    if message.video_note:
        return "video_note"
    if message.voice:
        return "voice"
    if message.audio:
        return "audio"
    if message.photo:
        return "photo"
    if message.document:
        return "document"
    return "file"


def _ptb_file_meta(message, media_type: str) -> tuple[Optional[str], int, Optional[str]]:
    """Extract (file_id, file_size, suggested_filename) from a PTB message."""
    candidates = (
        message.document, message.video, message.audio, message.animation,
        message.voice, message.video_note,
    )
    for cand in candidates:
        if cand is None:
            continue
        file_id = getattr(cand, "file_id", None)
        size = int(getattr(cand, "file_size", 0) or 0)
        name = getattr(cand, "file_name", None)
        if file_id:
            if not name:
                name = _fallback_name(message, media_type)
            return file_id, size, name
    if message.photo:
        largest = message.photo[-1]
        return largest.file_id, int(largest.file_size or 0), None
    if message.sticker:
        ext = ".webm" if (message.sticker.is_animated or message.sticker.is_video) else ".webp"
        return message.sticker.file_id, int(message.sticker.file_size or 0), \
            f"sticker_{message.sticker.file_unique_id}{ext}"
    return None, 0, None


def _fallback_name(message, media_type: str) -> str | None:
    if message.photo:
        return f"photo_{message.photo[-1].file_unique_id}.jpg"
    return None


def _ext_for_media_type(media_type: str) -> str:
    return {
        "video": ".mp4", "gif": ".mp4", "video_note": ".mp4",
        "voice": ".ogg", "audio": ".mp3", "photo": ".jpg",
        "sticker": ".webp", "document": ".bin", "file": ".bin",
    }.get(media_type, ".bin")


# Frame extractor — extracted to mediagrab_bot/frame_extractor.py
from mediagrab_bot.frame_extractor import (
    _FFMPEG, _FFPROBE, FrameExtractionError,
    extract_frames, _extract_at, _probe_duration, _duration_via_ffmpeg, _even_timestamps,
)
