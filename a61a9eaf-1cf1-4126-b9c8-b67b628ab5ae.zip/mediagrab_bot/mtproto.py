"""MTProto / Telethon layer.

Physically extracted from ``_bot_core.py``. Provides:

  - Session management (session_path, validate_session, interactive_login, ...)
  - Multi-account cluster (UserbotCluster, UserbotClusterRouter, VoiceChatAccountPool)
  - Service layer (mtproto_start, mtproto_stop, mtproto_get_client, ...)
  - Global rate limiter (mtproto_call_with_retry, _get_mtproto_semaphore)
  - Capture handler (self-destruct media)
  - Entity resolution (resolve_entity_full, resolve_vc_entity, resolve_forwarded_sender, ...)
  - Profile downloader (profile_download_photo, profile_download_stories, ...)
  - Shared entity-resolution infra (_vc_entity_cache, VCTransportError, _redact_ah)

Telethon is lazy-imported inside functions; the bot runs without Telethon installed.

Cross-subsystem dependencies are resolved without importing ``_bot_core``:
  - clear_account_cache / vc_reset_backend (VC) -> routed through the
    ``vc_hooks`` dependency-injection bridge (``mediagrab_bot.vc_hooks``).
  - resolve_message_link (EntityResolver, in bootstrap) -> routed through
    ``_resolve_message_link_bootstrap`` (lazy import at call time).

This module does NOT import ``_bot_core`` in any form (top-level or lazy).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from .config import _env_int, config
from .db_layer import vc_groups_active
from .link_parser import _AT_USERNAME_RE, _CHAT_ID_RE, _PUBLIC_CHANNEL_LINK_RE
from .text_utils import md_escape
from .utils_real import (
    get_bot,
    safe_filename,
    safe_send_document,
    safe_send_message,
    supervised_create_task,
    unique_path,
)
from .vc_hooks import clear_account_cache, vc_reset_backend, vc_set_global_floodwait, vc_is_global_floodwait_active, vc_rotation_settle_begin, vc_notify_session_import

logger = logging.getLogger("mediagrab")


async def _resolve_message_link_bootstrap(link, client=None):
    """Lazy bridge to ``bootstrap.resolve_message_link``.

    ``resolve_message_link`` lives in bootstrap, which imports ``_bot_core``,
    which imports this module (mtproto) — a top-level import would create a
    cycle. The lazy import defers resolution to call time, by which point
    bootstrap is fully loaded.
    """
    from .bootstrap import resolve_message_link
    return await resolve_message_link(link, client=client)


_MTPROTO_SESSION_DIR = config.project_root / "data"


def session_path() -> Path:
    """Return the full path to the Telethon session file (without extension)."""
    return _MTPROTO_SESSION_DIR / config.tg_user_session


def session_file_exists() -> bool:
    """True if the ``.session`` file exists and is non-empty.

    v97 FIX: also check the cluster sessions directory (data/sessions/) and
    other known locations. Previously, this only checked the legacy path
    (data/mediagrab_user.session). If the user logged in via the cluster
    system (which writes to data/sessions/), the legacy path wouldn't have
    the file, and mtproto_start() would fail with "no session file" even
    though a valid session existed elsewhere.
    """
    # Check the primary (legacy) path first.
    p = str(session_path()) + ".session"
    if os.path.exists(p) and os.path.getsize(p) > 0:
        return True
    # v97: also scan known session directories for ANY .session file.
    # This handles the case where the user logged in via interactive_login
    # (which uses session_path() = data/mediagrab_user) but the session
    # was moved/imported into data/sessions/ by the cluster system.
    for scan_dir in [
        _MTPROTO_SESSION_DIR,
        _CLUSTER_ACCOUNTS_DIR,
        Path(config.project_root) / "sessions",
        Path(config.project_root) / "accounts",
    ]:
        try:
            if scan_dir.exists():
                for sf in scan_dir.glob("*.session"):
                    if sf.stat().st_size > 0:
                        return True
        except OSError:
            pass
    return False


def _find_session_file() -> Path | None:
    """v97.7: find the first non-empty .session file across all known directories.

    This is a FAST filesystem-only scan (no network calls).  Returns the
    first candidate, or None if no .session files exist.

    v97.7 FIX: the v97.6 ``_find_authorized_session_file()`` created temp
    TelegramClients for each candidate and called ``connect()`` +
    ``is_user_authorized()`` — this was SLOW (15s timeout × N candidates)
    and FRAGILE (network issues skipped valid sessions, causing the 70s
    timeout and "no_session_file" error on Termux).

    v97.7 reverts to the simple fast scan.  The authorization check is now
    done in ``mtproto_start()`` which iterates through ALL candidates
    (see ``_find_all_session_files()``) and tries each one until an
    authorized session is found.  This way:
      - the scan is instant (filesystem only)
      - network calls happen once per candidate in mtproto_start
      - if the first candidate (legacy user_session.session) is unauthorized,
        mtproto_start tries the next (cluster_*.session)
    """
    candidates = _find_all_session_files()
    return candidates[0] if candidates else None


def _find_all_session_files() -> list[Path]:
    """v97.7: collect ALL non-empty .session files across all known directories.

    Returns a list of candidate Paths (deduped by resolved path), ordered:
      1. Legacy path (data/user_session.session)
      2. data/ directory (*.session files directly in data/)
      3. data/sessions/ directory (cluster_*.session files)
      4. sessions/ directory (project root)
      5. accounts/ directory (project root)

    This is a FAST filesystem-only scan — no network calls, no temp clients.
    The caller (mtproto_start) iterates through the list and tries each
    candidate with a real TelegramClient until one is authorized.
    """
    candidates: list[Path] = []
    seen: set[str] = set()

    # 1. Legacy path first (preserves prior precedence for ORDER).
    p = Path(str(session_path()) + ".session")
    if p.exists() and p.stat().st_size > 0:
        try:
            rp = str(p.resolve())
            if rp not in seen:
                seen.add(rp)
                candidates.append(p)
        except OSError:
            candidates.append(p)

    # 2-5. Scan known session directories.
    for scan_dir in [
        _MTPROTO_SESSION_DIR,
        _CLUSTER_ACCOUNTS_DIR,
        Path(config.project_root) / "sessions",
        Path(config.project_root) / "accounts",
    ]:
        try:
            if scan_dir.exists():
                for sf in sorted(scan_dir.glob("*.session")):
                    try:
                        if sf.stat().st_size <= 0:
                            continue
                    except OSError:
                        continue
                    try:
                        rp = str(sf.resolve())
                        if rp in seen:
                            continue
                        seen.add(rp)
                        candidates.append(sf)
                    except OSError:
                        candidates.append(sf)
        except OSError:
            pass

    return candidates


# ---------------------------------------------------------------------------
# v99.03 RC-10/RC-11 — per-.session-file health registry + remediation.
#
# RUNTIME-PROVEN (the 2026-09-11 02:45:10 → 03:20:39 v99.02 production
# log): three .session files existed on disk —
#   cluster_916397080450.session → SESSION_UNAUTHORIZED (line 131; dead —
#     logged out elsewhere / auth key revoked / login never completed)
#   cluster_918335829278.session → the PRIMARY GLOBAL client (@Gradieer)
#   cluster_919006065076.session → the cluster account acc_919006065076
#     (@Official_Ihitaa)
# yet the ONLY account-facing summary line was
#   ACCOUNT_STARTUP_REPORT total=1 sessions_found=1 imported=1 connected=1
# which counts REGISTERED CLUSTER accounts — the operator (who expected
# TWO accounts) could not see that the second session file was DEAD and
# needed re-login; the report read as "one account is missing" instead of
# "one account is dead, delete + re-login".  The registry below closes
# that observability gap: every session file's LAST-KNOWN status is
# recorded at the exact points where status is learned (mtproto_start
# candidate scan, import_existing_sessions validation), and
# account_session_health() composes a per-file view over
#   (files on disk) ∪ (registry entries)
# with NO RPCs (filesystem + registry reads only) so the heartbeat, the
# ACCOUNT_SESSION_HEALTH startup line, and /v85accounts can all use it.
# ---------------------------------------------------------------------------

# Maps session FILE NAME → {"status": str, "checked_at": float,
# "username": str, "user_id": int, "account_id": str}.  Statuses:
#   "unauthorized"  — dead session (delete + re-login; RC-11 runbook)
#   "imported"      — successfully imported as a cluster account
#   "primary_global" — the legacy/primary MTProto client's own session
#   "error" / "locked" / "duplicate" — import-time outcomes
_SESSION_HEALTH_REGISTRY: dict[str, dict] = {}

# The .session path mtproto_start() actually SUCCEEDED with (the primary
# global client's session file) — recorded at the success site so
# account_session_health() can label that file "primary_global" instead
# of "unregistered" (the file is NOT a cluster account and is absent from
# accounts.json BY DESIGN — that is exactly the mislabeling that made the
# operator think the file "didn't count").
_MTPROTO_ACTIVE_SESSION_PATH: str = ""


def _register_session_status(file_name: str, status: str, *,
                             username: str = "", user_id: int = 0,
                             account_id: str = "") -> None:
    """RC-10: record a session file's last-known status (no I/O, no RPC)."""
    try:
        _SESSION_HEALTH_REGISTRY[str(file_name)] = {
            "status": str(status), "checked_at": time.time(),
            "username": str(username or ""), "user_id": int(user_id or 0),
            "account_id": str(account_id or ""),
        }
    except Exception:  # noqa: BLE001
        pass


def _emit_session_remediation(file_name: str) -> None:
    """RC-11: the dead-session remediation runbook line.

    Emitted immediately after EVERY SESSION_UNAUTHORIZED — the operator
    who sees "unauthorized" must also see, in the same log, the exact
    repair steps.  The phone number is derived from the file-name stem
    (``cluster_916397080450`` → ``+916397080450``), which is how the
    importer itself derives missing phones — so the emitted command is
    the EXACT command for THIS file.
    """
    try:
        _stem = str(file_name)
        if _stem.endswith(".session"):
            _stem = _stem[:-len(".session")]
        _digits = _stem.replace("cluster_", "").replace("user_", "")
        _phone = f"+{_digits}" if _digits.isdigit() else "<phone>"
        logger.warning(
            "SESSION_REMEDIATION file=%s steps=[1. Stop the bot. "
            "2. Delete the .session file (it is unauthorized and will "
            "NEVER recover: the auth key was revoked or the login never "
            "completed). 3. Re-authorize: "
            "`python -m mediagrab_bot.tools.login --phone %s`. "
            "4. Restart the bot — the session hot-reload (v98.07 FIX-UU) "
            "imports the fresh .session within 60s.] (v99.03 RC-11)",
            file_name, _phone,
        )
    except Exception:  # noqa: BLE001
        pass


def account_session_health() -> dict[str, Any]:
    """RC-10: per-.session-file health snapshot (filesystem + registry only).

    Returns {"total_files", "live", "dead", "unregistered",
    "expected_cluster", "details": [{"file", "status", "action",
    "username", "user_id", "account_id"}]} — one detail entry per .session
    file found on disk (plus registry-only entries for files that
    disappeared after being recorded).  Never issues an RPC; safe from
    the heartbeat loop, the startup path, and /v85accounts alike.
    """
    out: dict[str, Any] = {
        "total_files": 0, "live": 0, "cluster_accounts": 0, "dead": 0,
        "unregistered": 0, "expected_cluster": 0, "details": [],
    }
    try:
        files = _find_all_session_files()
        by_name: dict[str, Path] = {p.name: p for p in files}
        # Include registry entries whose files vanished (honest history).
        for _name in _SESSION_HEALTH_REGISTRY:
            if _name not in by_name:
                by_name[_name] = Path(_name)
        # Registered cluster accounts keyed by their session file NAME.
        cluster_paths: dict[str, str] = {}
        # v99.04 RC-15 (RUNTIME-PROVEN via the 2026-09-11 v99.03 production
        # log runs 3+4): _accounts ALSO carries __-prefixed special keys
        # whose values are STRINGS (e.g. "__primary__": "acc_919006065076")
        # — _acc.get(...) on them raised AttributeError mid-loop, the
        # except:pass swallowed it AFTER the real account had already been
        # added to cluster_paths, and out["expected_cluster"] was never
        # assigned → the production line printed expected_cluster=0 while
        # USERBOT_CLUSTER loaded 1 accounts and the SAME line showed
        # cluster_account_id=acc_919006065076 (reproduced offline exactly;
        # the v99.03 _FakeCluster tests had no __ key, so they never
        # caught it).  Fix: mirror _load()/list_accounts() semantics —
        # skip __-prefixed and non-dict entries, count REAL accounts only.
        _v9904_expected = 0
        try:
            _cluster = get_userbot_cluster()
            if _cluster is not None:
                for _aid, _acc in (_cluster._accounts or {}).items():
                    if str(_aid).startswith("__") or not isinstance(_acc, dict):
                        continue
                    _sf = str(_acc.get("session_file", "") or "")
                    if _sf:
                        cluster_paths[os.path.basename(_sf)] = _aid
                    _v9904_expected += 1
                out["expected_cluster"] = _v9904_expected
        except Exception:  # noqa: BLE001
            pass
        active_name = os.path.basename(_MTPROTO_ACTIVE_SESSION_PATH) \
            if _MTPROTO_ACTIVE_SESSION_PATH else ""
        live = dead = unregistered = cluster_accounts = 0
        # v99.05 RC-F5 (FINAL REBUILD — mission §7/§8 — the "two accounts
        # showing one" fix, RUNTIME-PROVEN via the 2026-09-12 v99.04
        # production log): the SINGLE session file can legitimately hold
        # BOTH roles — the global primary (mtproto_start claimed it after
        # the operator deleted the old primary's session) AND a registered
        # cluster account (acc_919006065076 reuses the SAME live client).
        # The historical classifier checked `if _name == active_name`
        # FIRST, which classified the dual-role file as primary_global and
        # NEVER counted its cluster registration → the production line
        # printed cluster_accounts=0 expected_cluster=1 while the SAME
        # line's details showed the cluster account id — the account
        # registry LOOKED incoherent.  New semantics:
        #   * every file entry carries its cluster account_id when one is
        #     registered (dual-role files: status=primary_global,
        #     account_id=acc_..., roles=primary,cluster);
        #   * cluster_accounts counts DISTINCT registered accounts
        #     (deduped by phone/user_id so a dual-role file counts ONCE) —
        #     so one dual-role account reports cluster_accounts=1
        #     expected_cluster=1 (honest), and two real accounts report
        #     cluster_accounts=2 expected_cluster=2.
        _v9905_distinct: set[str] = set()
        for _name in sorted(by_name):
            _reg = _SESSION_HEALTH_REGISTRY.get(_name, {})
            _status = str(_reg.get("status", ""))
            _aid = cluster_paths.get(_name, _reg.get("account_id", ""))
            _roles: list[str] = []
            if _name == active_name:
                status = "primary_global"
                live += 1
                _roles.append("primary")
                if _aid:
                    # Dual-role file: the cluster registration is REAL —
                    # keep the account_id visible and count it.
                    _roles.append("cluster")
                    _dedup = str(
                        _reg.get("phone", "")
                        or _reg.get("user_id", "")
                        or _aid)
                    if _dedup not in _v9905_distinct:
                        _v9905_distinct.add(_dedup)
                        cluster_accounts += 1
            elif _aid:
                status = f"cluster_account_id={_aid}"
                live += 1
                _roles.append("cluster")
                _dedup = str(
                    _reg.get("phone", "")
                    or _reg.get("user_id", "")
                    or _aid)
                if _dedup not in _v9905_distinct:
                    _v9905_distinct.add(_dedup)
                    cluster_accounts += 1
            elif _status == "unauthorized":
                status = "unauthorized"
                dead += 1
            elif _status in ("imported", "primary_global"):
                # Recorded healthy but no live registration (e.g. the
                # cluster was reset) — still counted live-by-history.
                status = _status
                live += 1
            elif _status in ("error", "locked", "duplicate"):
                status = _status
            else:
                status = "unregistered"
                unregistered += 1
            detail = {
                "file": _name, "status": status,
                "username": _reg.get("username", ""),
                "user_id": _reg.get("user_id", 0),
                "account_id": _aid or _reg.get("account_id", ""),
            }
            if _roles:
                detail["roles"] = ",".join(_roles)
            if status == "unauthorized":
                detail["action"] = "delete_and_relogin"
            out["details"].append(detail)
        out["total_files"] = len(by_name)
        out["live"] = live
        out["cluster_accounts"] = cluster_accounts
        out["dead"] = dead
        out["unregistered"] = unregistered
    except Exception as exc:  # noqa: BLE001
        logger.debug("account_session_health failed (non-fatal): %s", exc)
    return out


def _emit_account_session_health(prefix: str = "ACCOUNT_SESSION_HEALTH") -> None:
    """RC-10: the operator-facing one-line session health summary.

    v99.04 RC-15: added cluster_accounts= (registered-and-distinct-from-
    global count, so the operator sees BOTH halves of "N files / M
    accounts") and fixed the double-brace `}}` cosmetic in details=[].
    """
    try:
        h = account_session_health()
        details = "; ".join(
            f"{{file:{d['file']}, status:{d['status']}"
            + (f", roles:{d['roles']}" if d.get("roles") else "")
            + (f", action:{d['action']}" if d.get("action") else "") + "}"
            for d in h["details"]
        )[:600]
        logger.info(
            "%s total_files=%d live=%d dead=%d unregistered=%d "
            "cluster_accounts=%d expected_cluster=%d details=[%s] — one "
            "entry per .session file on disk; 'dead' files need delete + "
            "re-login (SESSION_REMEDIATION); 'primary_global' is the "
            "global bot session (v99.03 RC-10; v99.04 RC-15; v99.05 RC-F5: "
            "a dual-role file — primary AND a registered cluster account — "
            "carries roles=primary,cluster and its DISTINCT registration "
            "counts in cluster_accounts, so one dual-role account reports "
            "cluster_accounts=1 expected_cluster=1 and two real accounts "
            "report cluster_accounts=2 expected_cluster=2)",
            prefix, h["total_files"], h["live"], h["dead"],
            h["unregistered"], h["cluster_accounts"],
            h["expected_cluster"], details,
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("%s emission failed (non-fatal): %s", prefix, exc)


async def _find_authorized_session_file() -> Path | None:
    """v97.7: DEPRECATED — use _find_all_session_files() + mtproto_start iteration.

    Kept for backward compatibility.  Returns the first candidate (fast,
    no network).  The authorization check is done by mtproto_start which
    iterates through all candidates.
    """
    candidates = _find_all_session_files()
    if not candidates:
        return None
    return candidates[0]


async def validate_session() -> bool:
    """Check whether the stored session can authenticate."""
    if not config.mtproto_configured:
        return False
    if not session_file_exists():
        return False
    # v97: if the session is already owned by a live client, reuse it
    # instead of creating a duplicate TelegramClient.
    _sess_base = str(session_path())
    _existing = _get_session_owner(_sess_base)
    if _existing is not None:
        try:
            if _existing.is_connected():
                return await asyncio.wait_for(
                    _existing.is_user_authorized(), timeout=15)
        except Exception:
            pass  # fall through to create a temp client
    # V85.3 FIX BUG 3.1: ensure the client is ALWAYS disconnected, even when
    # connect()/is_user_authorized()/get_me() raises.
    client = None
    try:
        from telethon import TelegramClient
        client = TelegramClient(str(session_path()), config.tg_api_id,
                                config.tg_api_hash)
        # v97: claim ownership (temp client — will be released on disconnect).
        # v97.5 FIX: _claim_session returns False if another live client won
        # the race between the _get_session_owner check above and here.  We
        # must NOT proceed to client.connect() in that case — it would raise
        # `OperationalError: database is locked` (two TelegramClients on the
        # same SQLite session file).  All other claim sites (connect_account
        # line ~1086, import_existing_sessions line ~1544, mtproto_start line
        # ~2874) already check the return value.
        if not await _claim_session(_sess_base, client):
            logger.warning(
                "VALIDATE_SESSION_SKIP reason=session_claim_lost base=%s — "
                "another client owns this session", _sess_base,
            )
            return False
        await asyncio.wait_for(client.connect(), timeout=30)
        if not await asyncio.wait_for(client.is_user_authorized(), timeout=15):
            await client.disconnect()
            await _release_session(_sess_base)
            return False
        me = await asyncio.wait_for(client.get_me(), timeout=15)
        await client.disconnect()
        await _release_session(_sess_base)
        return me is not None
    except Exception as exc:  # noqa: BLE001
        logger.warning("session validation failed: %s", exc)
        return False
    finally:
        if client is not None:
            try:
                if client.is_connected():
                    await client.disconnect()
            except Exception:  # noqa: BLE001
                pass
            # v97.6 FIX: release the session ownership in ALL exit paths.
            # Previously, the except/finally blocks disconnected the client
            # but did NOT call _release_session — so any exception between
            # _claim_session and the explicit release left a stale owner in
            # _session_owners that blocked all future connect_account /
            # mtproto_start attempts with SESSION_OWNERSHIP_CONFLICT.
            try:
                await _release_session(_sess_base)
            except Exception:  # noqa: BLE001
                pass


async def interactive_login(phone: str | None = None) -> str:
    """Run an interactive login flow to create the session file.

    Call this from a terminal (not from the bot) the first time:
        python -m services.session_manager
    """
    if not config.tg_api_id or not config.tg_api_hash:
        return "ERROR: TG_API_ID and TG_API_HASH must be set in .env"

    from telethon import TelegramClient
    _MTPROTO_SESSION_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(_MTPROTO_SESSION_DIR, 0o700)
    except OSError:
        pass
    client = TelegramClient(str(session_path()), config.tg_api_id,
                            config.tg_api_hash)
    try:
        await client.start(phone=phone)
        me = await client.get_me()
        _login_user_id = me.id
        _login_username = getattr(me, 'username', '—')
        _login_first = getattr(me, 'first_name', '')
        _login_last = getattr(me, 'last_name', '')
    finally:
        # v97 FIX: disconnect FIRST — Telethon saves the session file on
        # disconnect. Then verify the file exists.
        await client.disconnect()

    # v97 FIX: verify the session file was actually written to disk.
    _session_file_path = str(session_path()) + ".session"
    if os.path.exists(_session_file_path) and os.path.getsize(_session_file_path) > 0:
        logger.info("MTProto session created for user %s at %s (verified: %d bytes)",
                    _login_user_id, _session_file_path, os.path.getsize(_session_file_path))
        return (f"✅ Login successful!\n\n"
                f"Logged in as: @{_login_username} "
                f"({_login_first} {_login_last})\n"
                f"User ID: {_login_user_id}\n"
                f"Session saved to: {_session_file_path}")
    else:
        logger.error("MTProto login succeeded but session file NOT written: %s",
                     _session_file_path)
        return (f"⚠️ Login completed but session file was not written to disk.\n"
                f"Expected: {_session_file_path}\n"
                f"Check disk space and permissions.")


def session_info() -> dict:
    """Return static info about the session configuration."""
    return {
        "enabled": config.mtproto_enabled,
        "configured": config.mtproto_configured,
        "session_name": config.tg_user_session,
        "session_path": str(session_path()) + ".session",
        "session_exists": session_file_exists(),
        "api_id_set": bool(config.tg_api_id),
        "api_hash_set": bool(config.tg_api_hash),
    }


# ===========================================================================
# V67: Userbot Cluster Manager
# ===========================================================================
# Manages multiple MTProto accounts with:
# - Account registry (accounts.json)
# - Health tracking (connected, floodwait, banned, etc.)
# - In-bot OTP/2FA login flow
# - Role assignment (PRIMARY, BACKUP, DISCOVERY, DOWNLOADER, VOICE_CHAT)
# - Audit logging
#
# NOTE: The existing single-client architecture (mtproto_get_client()) is
# preserved. The cluster manager runs alongside it. Future versions will
# route MTProto calls through the cluster for automatic failover.

import json as _json_module

_CLUSTER_ACCOUNTS_FILE = Path(config.project_root) / "data" / "accounts.json"
_CLUSTER_ACCOUNTS_DIR = Path(config.project_root) / "data" / "sessions"

# Account roles
ROLE_PRIMARY = "PRIMARY"
ROLE_BACKUP = "BACKUP"
ROLE_DISCOVERY = "DISCOVERY"
ROLE_DOWNLOADER = "DOWNLOADER"
ROLE_VOICE_CHAT = "VOICE_CHAT"

# Account statuses (V67.4: expanded for granular health states)
STATUS_HEALTHY = "healthy"             # session ok + authorized + connected
STATUS_DISCONNECTED = "disconnected"   # not currently connected (may be ok)
STATUS_CONNECTING = "connecting"       # in the middle of connect_account()
STATUS_CONNECTED = "connected"         # legacy alias for healthy (kept for back-compat)
STATUS_FLOODWAIT = "floodwait"         # rate-limited by Telegram
STATUS_BANNED = "banned"               # account banned
STATUS_RESTRICTED = "restricted"       # account restricted
STATUS_UNAUTHORIZED = "unauthorized"   # session invalid / not authorized
STATUS_MISSING_SESSION = "missing_session"   # session file absent on disk
STATUS_INVALID_SESSION = "invalid_session"   # session file present but unreadable
STATUS_CONNECTION_FAILED = "connection_failed"  # could not reach Telegram
STATUS_DISABLED = "disabled"           # admin manually disabled the account

# Pending login sessions (admin_id → login state)
_cluster_pending_logins: dict[int, dict[str, Any]] = {}

# SEC-D-007: Per-(admin, phone) cooldown for cluster_start_login (monotonic seconds).
_cluster_login_cooldowns: dict[tuple[int, str], float] = {}

# V67.4: Persisted primary account id (rotated by admin). Stored in accounts.json
# under the special key "__primary__". When empty, the router auto-selects the
# first healthy PRIMARY-role account.
# v99.05 RC-F5 (FINAL REBUILD — mission §7 account-record schema): the
# __primary__ entry is now a DICT ({"account_id": "acc_..."}) so EVERY value
# in _accounts has the same well-formed shape — the historical STRING value
# ("__primary__": "acc_919006065076") crashed dict-typed consumers mid-loop
# (the v99.04 RC-15 production bug) and is transparently migrated on read.
_PRIMARY_KEY = "__primary__"


def _primary_value(v: Any) -> str:
    """v99.05 RC-F5: read the persisted primary account_id from EITHER the
    new dict schema {"account_id": "..."} or the legacy bare-string form.
    Returns "" when unset/invalid — never raises."""
    if isinstance(v, dict):
        return str(v.get("account_id", "") or "")
    if isinstance(v, str):
        return v
    return ""


def _primary_entry(account_id: str) -> dict[str, Any]:
    """v99.05 RC-F5: the schema-conformant __primary__ value (a DICT)."""
    return {"account_id": str(account_id or "")}


def get_primary_account_id() -> Optional[str]:
    """v99.06 FIX-1 (1.2): the REAL account_id ("acc_<phone>") that the
    primary/global session belongs to — or None when it cannot be
    identified (callers fall back to the literal "global"; NEVER invent
    an id).

    Sources, in order of authority:
      1. The persisted ``__primary__`` entry in accounts.json (the v99.05
         RC-F5 dict schema, legacy string tolerated via _primary_value)
         — but ONLY when that account actually exists in the registry.
      2. The live cluster client registry: when ``_mtproto_client`` IS a
         cluster client by object identity, that account owns the
         primary session (the production dual-role shape:
         primary_global == acc_919006065076 reusing one live client).
      3. The ACTIVE session file path: when it matches a registered
         cluster account's ``session_file``, that account.

    Production root cause (2026-09-09 log, 388x CHANNEL_INVALID): the
    scope token "global" is a chameleon — it ALWAYS means "whatever the
    current primary is", so after a rotation the NEW primary's client
    consumed the OLD primary's access hashes (scope=="global" matched
    both) → "Invalid channel object".  Binding the primary to its real
    account id at every scope keying boundary makes those entries
    structurally unshareable.
    """
    try:
        # 1) the persisted __primary__ entry.
        _cluster = get_userbot_cluster()
        if _cluster is not None:
            try:
                _pv = _primary_value(
                    (_cluster._accounts or {}).get(_PRIMARY_KEY, ""))
                if _pv and isinstance(_cluster._accounts.get(_pv), dict):
                    return str(_pv)
            except Exception:  # noqa: BLE001
                pass
            # 2) _mtproto_client is a cluster client by identity.
            try:
                _clients_map = getattr(_cluster, "_clients", None)
                if isinstance(_clients_map, dict) and _mtproto_client is not None:
                    for _aid, _c in _clients_map.items():
                        if (isinstance(_aid, str)
                                and _aid.startswith("acc_")
                                and _c is _mtproto_client):
                            return str(_aid)
            except Exception:  # noqa: BLE001
                pass
            # 3) the active session file matches a cluster session path.
            try:
                if _MTPROTO_ACTIVE_SESSION_PATH:
                    _active = os.path.basename(_MTPROTO_ACTIVE_SESSION_PATH)
                    for _aid, _acc in (_cluster._accounts or {}).items():
                        if (str(_aid).startswith("__")
                                or not isinstance(_acc, dict)):
                            continue
                        _sf = str(_acc.get("session_file", "") or "")
                        if _sf and os.path.basename(_sf) == _active:
                            return str(_aid)
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        pass
    return None

# V67.4: Map of role → currently routed account_id (in-memory, for the Active
# Account View panel). Reset on every router call so it always reflects the
# most recent routing decision.
_active_routing: dict[str, str] = {}


def _status_icon(status: str) -> str:
    """V67.4: Return a status emoji for an account status string."""
    return {
        STATUS_HEALTHY: "🟢",
        STATUS_CONNECTED: "🟢",
        STATUS_CONNECTING: "🟠",
        STATUS_FLOODWAIT: "🟡",
        STATUS_BANNED: "🔴",
        STATUS_RESTRICTED: "🟣",
        STATUS_UNAUTHORIZED: "🔴",
        STATUS_MISSING_SESSION: "🔴",
        STATUS_INVALID_SESSION: "🔴",
        STATUS_CONNECTION_FAILED: "🔴",
        STATUS_DISABLED: "⚫",
        STATUS_DISCONNECTED: "🔴",
    }.get(status or "", "❓")


def _status_label(status: str) -> str:
    """V67.4: Human-friendly status label."""
    return {
        STATUS_HEALTHY: "healthy",
        STATUS_CONNECTED: "healthy",
        STATUS_CONNECTING: "connecting",
        STATUS_FLOODWAIT: "floodwait",
        STATUS_BANNED: "banned",
        STATUS_RESTRICTED: "restricted",
        STATUS_UNAUTHORIZED: "unauthorized",
        STATUS_MISSING_SESSION: "missing_session",
        STATUS_INVALID_SESSION: "invalid_session",
        STATUS_CONNECTION_FAILED: "connection_failed",
        STATUS_DISABLED: "disabled",
        STATUS_DISCONNECTED: "disconnected",
    }.get(status or "", status or "unknown")


class UserbotCluster:
    """V67.4: Multi-account MTProto cluster manager.

    Adds (vs V67):
      - Existing-session auto-importer (scan data/sessions/*.session)
      - Startup validation + report
      - Persisted primary (rotate_primary)
      - Granular health states (missing_session, invalid_session,
        connection_failed, disabled, …)
      - enable / disable account
      - Account diagnostics snapshot (session exists / size / authorized / …)
      - Active-routing tracking (which account the router last picked)
    """

    def __init__(self):
        # _accounts holds BOTH registered accounts AND a few special keys
        # (prefixed with '__'). Special keys are never listed as accounts.
        self._accounts: dict[str, dict[str, Any]] = {}
        self._clients: dict[str, Any] = {}  # account_id → TelegramClient
        # v97.96 FIX (BUG-4): per-account asyncio.Lock for connect_account
        # single-flight. Prevents _cluster_reconnect_loop + a manual
        # /reconnect command + _mtproto_safe_reconnect from all trying to
        # connect the SAME account simultaneously, which would create 2+
        # TelegramClients on the same SQLite session file → sqlite_locked.
        # NOTE: mutations of _clients/_accounts are single-threaded in
        # asyncio; the lock here is for the CONNECT OPERATION only.
        self._account_connect_locks: dict[str, "asyncio.Lock"] = {}
        self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load accounts from accounts.json."""
        try:
            _CLUSTER_ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
            # SEC-D-002: protect the session directory so other OS users
            # can't read the .session files inside it.
            try:
                os.chmod(_CLUSTER_ACCOUNTS_DIR, 0o700)
            except OSError:
                pass
            if _CLUSTER_ACCOUNTS_FILE.exists():
                data = _json_module.loads(_CLUSTER_ACCOUNTS_FILE.read_text())
                if isinstance(data, dict):
                    self._accounts = data
                    # Migrate legacy statuses → new granular statuses.
                    for aid, acc in self._accounts.items():
                        if aid.startswith("__"):
                            continue
                        if not isinstance(acc, dict):
                            continue
                        # Backfill new fields if missing.
                        acc.setdefault("fail_count", 0)
                        acc.setdefault("success_count", 0)
                        acc.setdefault("last_error", "")
                        acc.setdefault("last_success", 0.0)
                        acc.setdefault("username", "")
                        acc.setdefault("user_id", 0)
                        acc.setdefault("disabled", False)
                        acc.setdefault("session_size", 0)
                        # V70.1: new diagnostics fields.
                        acc.setdefault("last_exception", "")
                        acc.setdefault("last_exception_type", "")
                        acc.setdefault("last_connect_attempt", 0.0)
                        acc.setdefault("legacy", False)
                        st = acc.get("status")
                        # Treat legacy 'connected' as 'healthy' (alias).
                        if st == STATUS_CONNECTED:
                            acc["status"] = STATUS_HEALTHY
                    logger.info("USERBOT_CLUSTER loaded %d accounts",
                                len([k for k in self._accounts if not k.startswith("__")]))
        except Exception as exc:
            logger.warning("USERBOT_CLUSTER load failed: %s", exc)

    def _save(self) -> None:
        """Save accounts to accounts.json atomically (TLG-D-012 + SEC-D-001).

        Writes to a temp file then os.replace()s it onto the destination so
        a crash mid-write never leaves a truncated accounts.json. Also sets
        0o600 on the file so other OS users can't read Telegram sessions.
        Errors are logged at ERROR level and re-raised so callers know the
        state was NOT persisted.
        """
        try:
            _CLUSTER_ACCOUNTS_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = _CLUSTER_ACCOUNTS_FILE.with_suffix(".json.tmp")
            tmp_path.write_text(
                _json_module.dumps(self._accounts, indent=2, default=str))
            os.replace(tmp_path, _CLUSTER_ACCOUNTS_FILE)
            try:
                os.chmod(_CLUSTER_ACCOUNTS_FILE, 0o600)
            except OSError:
                pass
        except Exception as exc:
            logger.error("USERBOT_CLUSTER save failed: %s", exc)
            raise

    # ------------------------------------------------------------------
    # Listing / lookup
    # ------------------------------------------------------------------

    def list_accounts(self) -> list[dict[str, Any]]:
        """List all registered accounts (excludes __-prefixed special keys)."""
        return [dict(v, account_id=k)
                for k, v in self._accounts.items()
                if not k.startswith("__") and isinstance(v, dict)]

    def get_account(self, account_id: str) -> dict[str, Any] | None:
        """Get a single account by ID."""
        acc = self._accounts.get(account_id)
        if not isinstance(acc, dict) or account_id.startswith("__"):
            return None
        return acc

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def add_account(self, phone: str, session_file: str,
                    role: str = ROLE_BACKUP,
                    username: str = "",
                    user_id: int = 0) -> str:
        """Register a new account. Returns account_id.

        V67.4: stores username/user_id captured during login, and a session_size
        snapshot so the admin panel can show 'Session exists' + 'Session size'
        without re-stat-ing the file.
        """
        account_id = f"acc_{phone.replace('+', '')}"
        # If the account already exists, preserve usage counters but refresh
        # volatile fields (session_file, username, role).
        existing = self._accounts.get(account_id, {})
        if not isinstance(existing, dict):
            existing = {}
        session_size = 0
        try:
            p = Path(session_file)
            if p.exists():
                session_size = p.stat().st_size
        except Exception:
            pass
        self._accounts[account_id] = {
            "phone": phone,
            "session_file": session_file,
            "status": STATUS_DISCONNECTED,
            "role": role,
            "last_seen": time.time(),
            "floodwait_until": 0.0,
            "joined_vcs": int(existing.get("joined_vcs", 0)),
            "downloads_count": int(existing.get("downloads_count", 0)),
            "discovery_count": int(existing.get("discovery_count", 0)),
            "fail_count": int(existing.get("fail_count", 0)),
            "success_count": int(existing.get("success_count", 0)),
            "last_error": "",
            "last_success": float(existing.get("last_success", 0.0)),
            "last_exception": "",
            "last_exception_type": "",
            "last_connect_attempt": 0.0,
            "legacy": False,
            "username": username,
            "user_id": user_id,
            "session_size": session_size,
            "disabled": False,
            "created_at": float(existing.get("created_at", time.time())),
            "imported": False,
        }
        self._save()
        logger.info("ACCOUNT_ADDED account_id=%s phone=%s role=%s username=@%s "
                    "session_size=%d",
                    account_id, phone, role, username or "(none)", session_size)
        return account_id

    def remove_account(self, account_id: str) -> bool:
        """Remove an account from the registry.

        v97.97 FIX (BUG-5): schedule the unified async cleanup
        (``_cleanup_client_async``) instead of fire-and-forget
        ``client.disconnect()``. The v97.44 fire-and-forget pattern was a
        latent leak: no ``_forcibly_cancel_telethon_tasks`` and no
        ``_release_client_session``. See ``_cleanup_client_async`` for the
        full v97.96 BUG-1 pattern.
        """
        if account_id not in self._accounts or account_id.startswith("__"):
            return False
        # Disconnect client if connected.
        client = self._clients.pop(account_id, None)
        if client:
            # v97.97 FIX (BUG-5): apply the v97.96 BUG-1 pattern via the
            # unified async cleanup helper. The client is already popped
            # from _clients; the helper holds the only reference and does
            # forcibly_cancel -> disconnect -> drain -> release_session.
            supervised_create_task(
                self._cleanup_client_async(account_id, client,
                                           label="remove_account"),
                name=f"mtproto_remove_{account_id}",
            )
        # If this was the primary, clear the persisted primary.
        if self.get_primary_id() == account_id:
            self.set_primary_id("")
        del self._accounts[account_id]
        self._save()
        logger.info("ACCOUNT_REMOVED account_id=%s", account_id)
        return True

    def set_role(self, account_id: str, role: str) -> bool:
        """Set the role of an account."""
        if account_id not in self._accounts or account_id.startswith("__"):
            return False
        old_role = self._accounts[account_id].get("role", "")
        self._accounts[account_id]["role"] = role
        self._save()
        logger.info("ACCOUNT_ROLE_SET account_id=%s role=%s", account_id, role)
        # V72 PART 18: ROLE_CHANGED log event.
        logger.info("ROLE_CHANGED account_id=%s old_role=%s new_role=%s",
                    account_id, old_role, role)
        return True

    # ------------------------------------------------------------------
    # Enable / disable (V67.4)
    # ------------------------------------------------------------------

    def set_disabled(self, account_id: str, disabled: bool) -> bool:
        """Enable or disable an account.

        v97.97 FIX (BUG-5): schedule the unified async cleanup
        (``_cleanup_client_async``) when disabling, instead of fire-and-forget
        ``client.disconnect()``. See ``_cleanup_client_async`` and
        ``remove_account`` for the full pattern.
        """
        acc = self.get_account(account_id)
        if not acc:
            return False
        acc["disabled"] = bool(disabled)
        if disabled:
            # Disconnect immediately and mark disabled.
            client = self._clients.pop(account_id, None)
            if client:
                # v97.97 FIX (BUG-5): apply the v97.96 BUG-1 pattern via
                # the unified async cleanup helper.
                supervised_create_task(
                    self._cleanup_client_async(account_id, client,
                                               label="set_disabled"),
                    name=f"mtproto_disable_{account_id}",
                )
            acc["status"] = STATUS_DISABLED
            logger.info("ACCOUNT_DISABLED account_id=%s", account_id)
        else:
            acc["status"] = STATUS_DISCONNECTED
            logger.info("ACCOUNT_ENABLED account_id=%s", account_id)
        self._save()
        return True

    def is_disabled(self, account_id: str) -> bool:
        """Check if an account is disabled."""
        acc = self.get_account(account_id)
        return bool(acc and acc.get("disabled"))

    # ------------------------------------------------------------------
    # Status / health
    # ------------------------------------------------------------------

    def update_status(self, account_id: str, status: str,
                       floodwait_until: float = 0.0) -> None:
        """Update account status."""
        acc = self.get_account(account_id)
        if not acc:
            return
        # Don't override 'disabled' with other statuses.
        if acc.get("disabled") and status != STATUS_DISABLED:
            return
        acc["status"] = status
        acc["last_seen"] = time.time()
        if floodwait_until:
            acc["floodwait_until"] = floodwait_until
        self._save()

    def get_healthy_accounts(self, role: str | None = None) -> list[dict[str, Any]]:
        """Get all healthy accounts, optionally filtered by role.

        V67.4: accepts both STATUS_HEALTHY and legacy STATUS_CONNECTED.
        Skips disabled accounts.
        """
        result = []
        for aid, acc in self._accounts.items():
            if aid.startswith("__") or not isinstance(acc, dict):
                continue
            if acc.get("disabled"):
                continue
            st = acc.get("status")
            if st not in (STATUS_HEALTHY, STATUS_CONNECTED):
                continue
            if role and acc.get("role") != role:
                continue
            result.append(dict(acc, account_id=aid))
        return result

    def get_cluster_stats(self) -> dict[str, Any]:
        """Get aggregate cluster statistics."""
        accounts = self.list_accounts()
        total = len(accounts)
        healthy = sum(1 for a in accounts
                      if a.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED))
        floodwait = sum(1 for a in accounts if a.get("status") == STATUS_FLOODWAIT)
        disconnected = sum(1 for a in accounts
                           if a.get("status") == STATUS_DISCONNECTED)
        disabled = sum(1 for a in accounts if a.get("disabled"))
        missing = sum(1 for a in accounts if a.get("status") == STATUS_MISSING_SESSION)
        unauthorized = sum(1 for a in accounts if a.get("status") == STATUS_UNAUTHORIZED)
        downloads = sum(a.get("downloads_count", 0) for a in accounts)
        discovery = sum(a.get("discovery_count", 0) for a in accounts)
        primary_id = self.get_primary_id()
        return {
            "total_accounts": total,
            "healthy": healthy,
            "floodwait": floodwait,
            "disconnected": disconnected,
            "disabled": disabled,
            "missing_session": missing,
            "unauthorized": unauthorized,
            "downloads_today": downloads,
            "discovery_today": discovery,
            "primary_id": primary_id,
        }

    def get_client(self, account_id: str) -> Any | None:
        """Get the TelegramClient for an account."""
        return self._clients.get(account_id)

    async def _release_client_session(self, account_id: str, client: Any) -> None:
        """v97.5: Release the session-ownership registry entry for a client.

        Called when a client is being removed from ``self._clients`` (e.g.
        it disconnected, failed get_me, or is being replaced).  This ensures
        the session-ownership registry (``_session_owners``) doesn't retain
        a stale owner that would block a new client from claiming the session.

        Without this, ``_claim_session`` would correctly REFUSE the new
        client (because the old one is still registered), but the new
        ``connect_account`` call wouldn't know to release — causing a
        permanent "no client can claim this session" deadlock after a
        disconnect.

        Safe to call even if the client was never claimed (no-op).
        """
        try:
            acc = self.get_account(account_id)
            if not acc:
                return
            raw_path = acc.get("session_file", "")
            if not raw_path:
                return
            # Only release if the CURRENT owner is the client we're removing.
            # This prevents releasing a session that a NEW client already
            # claimed (race safety).
            _owner = _get_session_owner(raw_path)
            if _owner is client:
                await _release_session(raw_path)
                logger.info(
                    "SESSION_OWNER_RELEASED account_id=%s client_identity=%s",
                    account_id, id(client),
                )
        except Exception as exc:  # noqa: BLE001
            logger.debug("_release_client_session error: %s", exc)

    async def _cleanup_client_async(self, account_id: str, client: Any,
                                    *, label: str) -> None:
        """v97.97: unified async client cleanup for sync entry points.

        The sync entry points ``remove_account`` and ``set_disabled`` previously
        used fire-and-forget ``supervised_create_task(client.disconnect())``
        (the v97.44 fix for bare ``loop.create_task``). That pattern was a
        LATENT LEAK: it called ``client.disconnect()`` but did NOT call
        ``_forcibly_cancel_telethon_tasks`` (so the 6 Telethon background
        tasks could survive a drain timeout) and did NOT call
        ``_release_client_session`` (so the session-ownership registry
        retained a stale owner, blocking the next ``connect_account`` with
        SESSION_OWNERSHIP_CONFLICT).

        This helper applies the SAME v97.96 BUG-1 pattern used by
        ``connect_account`` (4 paths) and ``disconnect_account`` (BUG-3):
        ``_forcibly_cancel_telethon_tasks`` -> ``client.disconnect()`` ->
        await the ``disconnected`` drain future (10s) ->
        ``_release_client_session``.

        The client has already been popped from ``self._clients`` by the
        caller, so this helper holds the only reference. It is safe to
        schedule via ``supervised_create_task`` from a sync caller — the
        cleanup runs in the background and completes before the next
        ``connect_account`` for this account would attempt to claim the
        session (the per-account asyncio.Lock from v97.96 BUG-4 serializes
        new connects, but does not block this cleanup — which is fine
        because the client is already detached).

        Guard: if ``client is _mtproto_client`` (legacy reuse of the global
        primary session), do NOT disconnect or release — the global
        client's lifecycle is owned by ``mtproto_start`` / ``mtproto_stop``.
        This mirrors the guard in ``disconnect_account`` (v97.9).
        """
        if client is None:
            return
        if client is _mtproto_client:
            logger.info(
                "ACCOUNT_DISCONNECT_SKIP_GLOBAL account_id=%s — client is "
                "the global _mtproto_client (legacy reuse); not cleaning up "
                "(label=%s)", account_id, label,
            )
            return
        # v97.97 FIX (BUG-5): forcibly cancel the client's 6 Telethon bg
        # tasks BEFORE disconnect. Reuses the existing client-specific
        # _forcibly_cancel_telethon_tasks (v97.79). Safe because cluster
        # clients have a _mediagrab_bg_tasks snapshot (set by connect_account
        # at the _snapshot_telethon_bg_tasks call site).
        try:
            await _forcibly_cancel_telethon_tasks(
                client, label=f"{label}:{account_id}",
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "ACCOUNT_FORCED_CANCEL_ERROR account_id=%s label=%s exc=%s",
                account_id, label, exc,
            )
        try:
            await client.disconnect()
        except Exception:  # noqa: BLE001
            pass
        # v97.32: await the disconnected drain future so ALL 6 bg tasks are
        # fully done before we release the session. Mirrors disconnect_account.
        disc = getattr(client, "disconnected", None)
        if disc is not None:
            try:
                await asyncio.wait_for(disc, timeout=10)
            except asyncio.TimeoutError:
                logger.debug(
                    "MTPROTO_CLUSTER_DRAIN_TIMEOUT account=%s (10s) — "
                    "background tasks may still be cancelling (label=%s)",
                    account_id, label,
                )
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "MTPROTO_CLUSTER_DRAIN_ERROR account=%s exc=%s (label=%s)",
                    account_id, exc, label,
                )
        # v97.5: release the session ownership so reconnect can re-claim.
        try:
            await self._release_client_session(account_id, client)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "_release_client_session error: %s (label=%s)", exc, label,
            )

    # ------------------------------------------------------------------
    # Primary persistence (V67.4)
    # ------------------------------------------------------------------

    def get_primary_id(self) -> str:
        """Return the persisted primary account_id, or '' if not set.

        V68.2 §2: If no primary is set BUT healthy accounts exist, auto-assign
        the first healthy account (by created_at) so the Active Accounts panel
        never shows "Current Primary: (none)" when accounts are healthy.
        This covers the case where accounts are imported AFTER startup (via
        the Import Sessions button) — the post_init auto-primary only runs
        once at boot.
        """
        v = self._accounts.get(_PRIMARY_KEY, "")
        # v99.05 RC-F5: accept BOTH the new dict schema and the legacy
        # bare-string form (transparent migration).
        v = _primary_value(v)
        if v:
            # Verify the persisted primary still exists and is healthy.
            # If it was removed or became unhealthy, fall through to auto-assign.
            acc = self._accounts.get(v)
            if isinstance(acc, dict) and not acc.get("disabled") \
                    and acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED):
                return v
            # Stale primary — clear it.
            self._accounts[_PRIMARY_KEY] = _primary_entry("")
            self._save()
        # V68.2 §2: Auto-assign the first healthy account if any.
        healthy = self.get_healthy_accounts()
        if healthy:
            healthy.sort(key=lambda a: float(a.get("created_at", 0)))
            first_aid = healthy[0]["account_id"]
            self._accounts[_PRIMARY_KEY] = _primary_entry(first_aid)
            # Bump role to PRIMARY for clarity.
            if self._accounts[first_aid].get("role") != ROLE_PRIMARY:
                self._accounts[first_aid]["role"] = ROLE_PRIMARY
            self._save()
            logger.info("ACCOUNT_AUTO_PRIMARY account_id=%s (runtime auto-assign)",
                        first_aid)
            return first_aid
        return ""

    def set_primary_id(self, account_id: str) -> bool:
        """Persist the primary account_id. Empty string clears it."""
        if account_id and account_id not in self._accounts:
            return False
        old_primary = _primary_value(self._accounts.get(_PRIMARY_KEY, ""))
        # v99.06 FIX-1 (1.8): compute the OLD primary's EFFECTIVE binding
        # and purge its cache entries BEFORE the swap — after the swap the
        # chameleon token resolves to the NEW primary and the purge would
        # hit the wrong account.  The effective binding ALSO catches the
        # unidentified-old-primary case (stored "" but the real owner is
        # identifiable via cluster identity / session path — the
        # production shape where rotation never purged anything).
        _v9906_old_ids: list[str] = []
        if old_primary:
            _v9906_old_ids.append(old_primary)
        try:
            _v9906_pre_eff = get_primary_account_id() or ""
            if _v9906_pre_eff and _v9906_pre_eff not in _v9906_old_ids:
                _v9906_old_ids.append(_v9906_pre_eff)
        except Exception:  # noqa: BLE001
            pass
        _v9906_old_ids = [i for i in _v9906_old_ids if i and i != account_id]
        if _v9906_old_ids:
            try:
                # PRE-swap: the v99.06 chameleon gate inside
                # clear_account_cache fires when the cleared account IS
                # the (still-current) effective primary — so a rotation
                # also migrates pre-v99.06 shapes (VC_SCOPE_ALIAS_MIGRATION)
                # and truly drops the old owner's handles (production
                # evidence: ENTITY_CACHE_CLEARED entries_removed=0).
                for _v9906_old in _v9906_old_ids:
                    clear_account_cache(_v9906_old)
            except Exception as exc:  # noqa: BLE001
                logger.warning("VC_ROTATION_CACHE_CLEAR_FAILED exc=%s", exc)
        # v99.05 RC-F5: schema-conformant dict entry.
        self._accounts[_PRIMARY_KEY] = _primary_entry(account_id)
        self._save()
        if account_id:
            logger.info("ACCOUNT_PROMOTED_PRIMARY account_id=%s", account_id)
        else:
            logger.info("ACCOUNT_PRIMARY_CLEARED")
        # V72 PART 18: PRIMARY_CHANGED log event.
        logger.info("PRIMARY_CHANGED old_primary=%s new_primary=%s",
                    old_primary or "(none)", account_id or "(none)")
        # V84 ISSUE 1: After rotation, clear stale account-bound entity handles
        # and reset the VC backend so it picks up the new account's client.
        if old_primary and old_primary != account_id:
            try:
                # v99.06 FIX-1: the cache clear moved PRE-swap (above); the
                # backend reset + settle window stay here (post-swap).
                # v98.08 FIX-AAA: ONE rotation = ONE decision. The v98.07
                # log printed BOTH "VC_BACKEND_PRESERVED" (vc_reset_backend
                # :5199 — preserve path, the ACTUAL behavior when the
                # backend is started) and "VC_BACKEND_RESET after primary
                # rotation" (set_primary_id — unconditional, contradicted
                # the preserved decision 1 line earlier, L15431/L15432).
                # vc_reset_backend now RETURNS its decision; this is the
                # single authoritative rotation line.
                _v808_backend_action = vc_reset_backend()
                _v808_action = str(_v808_backend_action or "reset")
                logger.info(
                    "VC_ROTATION_BACKEND_DECISION old=%s new=%s action=%s "
                    "reason=primary_rotation (v98.08 FIX-AAA: one rotation, "
                    "one decision — replaces the contradictory "
                    "PRESERVED+RESET pair)",
                    old_primary, account_id, _v808_action,
                )
                # v98.08 FIX-AAA: settle window — the 2 minutes before the
                # F1' wedge were rotation → 56-line reconcile flood →
                # discovery start within 12s. Defer reconcile
                # re-eligibility + discovery cycle starts for N seconds.
                vc_rotation_settle_begin(old_primary, account_id)
            except Exception as exc:
                logger.warning("VC_BACKEND_RESET_FAILED exc=%s", exc)
        return True

    def rotate_primary(self) -> str:
        """V68.2: Rotate the primary to the NEXT healthy account.

        Order:
          1. If a primary is currently set and healthy, find the NEXT healthy
             account (by created_at) after it and promote that.
          2. If no current primary or current primary is unhealthy, promote
             the first healthy account.
          3. If no healthy accounts at all, return ''.

        V68.2 logs: PRIMARY_ROTATED with OLD_PRIMARY + NEW_PRIMARY (in addition
        to the V67.4 ACCOUNT_ROTATED log for backward compat).

        Returns the new primary account_id, or '' on failure.
        """
        healthy = self.get_healthy_accounts()
        if not healthy:
            logger.warning("ACCOUNT_ROTATE no healthy accounts")
            logger.warning("PRIMARY_ROTATED old_primary=%s new_primary=%s "
                           "result=no_healthy",
                           self.get_primary_id() or "(none)", "(none)")
            return ""
        # Sort by created_at for deterministic rotation order.
        healthy.sort(key=lambda a: float(a.get("created_at", 0)))
        current = self.get_primary_id()
        if current and any(a["account_id"] == current for a in healthy):
            # Find index of current, wrap around.
            ids = [a["account_id"] for a in healthy]
            idx = ids.index(current)
            next_aid = ids[(idx + 1) % len(ids)]
            # If we wrapped back to the same one (only 1 healthy), still return it.
            self.set_primary_id(next_aid)
            # Also bump its role to PRIMARY if needed.
            if self._accounts[next_aid].get("role") != ROLE_PRIMARY:
                self._accounts[next_aid]["role"] = ROLE_PRIMARY
                self._save()
            logger.info("ACCOUNT_ROTATED old=%s new=%s", current, next_aid)
            logger.info("PRIMARY_ROTATED old_primary=%s new_primary=%s",
                        current, next_aid)
            return next_aid
        # No current primary (or current is unhealthy) — promote first healthy.
        next_aid = healthy[0]["account_id"]
        self.set_primary_id(next_aid)
        if self._accounts[next_aid].get("role") != ROLE_PRIMARY:
            self._accounts[next_aid]["role"] = ROLE_PRIMARY
            self._save()
        logger.info("ACCOUNT_ROTATED old=%s new=%s",
                    current or "(none)", next_aid)
        logger.info("PRIMARY_ROTATED old_primary=%s new_primary=%s",
                    current or "(none)", next_aid)
        return next_aid

    # ------------------------------------------------------------------
    # Session file helpers (V67.4)
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_session_path(session_file: str) -> Path | None:
        """Return the actual session file Path, checking both with and without
        the .session extension. Returns None if neither exists.
        """
        if not session_file:
            return None
        p = Path(session_file)
        if p.exists():
            return p
        p2 = Path(str(session_file) + ".session")
        if p2.exists():
            return p2
        return None

    def get_session_info(self, account_id: str) -> dict[str, Any]:
        """V67.4: Return session diagnostics for an account."""
        acc = self.get_account(account_id)
        if not acc:
            return {"exists": False, "path": "", "size": 0, "error": "not_found"}
        sf = acc.get("session_file", "")
        path = self._resolve_session_path(sf)
        if path is None:
            return {"exists": False, "path": sf, "size": 0,
                    "error": "missing_session"}
        try:
            size = path.stat().st_size
        except Exception as exc:
            return {"exists": True, "path": str(path), "size": 0,
                    "error": f"invalid_session: {exc}"}
        if size == 0:
            return {"exists": True, "path": str(path), "size": 0,
                    "error": "invalid_session: empty file"}
        return {"exists": True, "path": str(path), "size": size, "error": ""}

    def get_account_diagnostics(self, account_id: str) -> dict[str, Any]:
        """V70.1: Full diagnostic snapshot for the Account Details panel.

        V70.1 §6: Adds Connected, Authorized, Session Exists, Session Size,
        Last Exception, Last Exception Type, Last Connect Attempt.
        """
        acc = self.get_account(account_id)
        if not acc:
            return {"found": False}
        sess = self.get_session_info(account_id)
        client = self._clients.get(account_id)
        connected = client is not None and getattr(client, "is_connected", lambda: False)()
        fw_until = float(acc.get("floodwait_until", 0) or 0)
        fw_remaining = max(0, int(fw_until - time.time())) if fw_until else 0
        last_ca = float(acc.get("last_connect_attempt", 0) or 0)
        return {
            "found": True,
            "account_id": account_id,
            "phone": acc.get("phone", ""),
            "username": acc.get("username", ""),
            "user_id": acc.get("user_id", 0),
            "role": acc.get("role", ""),
            "status": acc.get("status", ""),
            "status_label": _status_label(acc.get("status", "")),
            "status_icon": _status_icon(acc.get("status", "")),
            "session_path": sess["path"],
            "session_exists": sess["exists"],
            "session_size": sess["size"],
            "session_error": sess["error"],
            "authorized": acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED),
            "connected": connected,
            "disabled": bool(acc.get("disabled")),
            "legacy": bool(acc.get("legacy", False)),
            "fail_count": int(acc.get("fail_count", 0)),
            "success_count": int(acc.get("success_count", 0)),
            "downloads_count": int(acc.get("downloads_count", 0)),
            "discovery_count": int(acc.get("discovery_count", 0)),
            "joined_vcs": int(acc.get("joined_vcs", 0)),
            "last_error": acc.get("last_error", ""),
            "last_exception": acc.get("last_exception", ""),
            "last_exception_type": acc.get("last_exception_type", ""),
            "last_connect_attempt": last_ca,
            "last_connect_attempt_iso": (
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(last_ca))
                if last_ca else "(never)"
            ),
            "last_success": float(acc.get("last_success", 0) or 0),
            "floodwait_remaining": fw_remaining,
            "is_primary": self.get_primary_id() == account_id,
            "last_seen": float(acc.get("last_seen", 0) or 0),
            "created_at": float(acc.get("created_at", 0) or 0),
            "imported": bool(acc.get("imported", False)),
        }

    # ------------------------------------------------------------------
    # Connect / disconnect
    # ------------------------------------------------------------------

    async def connect_account(self, account_id: str) -> str:
        """V70.1: Connect a registered account's TelegramClient.

        V70.1 FIX: The V67.4 connect_account ALWAYS created a new
        TelegramClient for the session file. But if the legacy _mtproto_client
        was already using the SAME file (e.g. data/user_session.session),
        SQLite raised `OperationalError: database is locked` → the account
        was marked `connection_failed` even though the session was valid.
        This was the root cause of:
          List Accounts: acc_xxx — connection_failed
          Active Accounts: Current Primary: (none)

        V70.1 fix:
          1. BEFORE creating a new TelegramClient, check if this account's
             session file is the legacy _mtproto_client's session. If so,
             REUSE _mtproto_client (don't reopen SQLite).
          2. Classify exceptions granularly:
             - AuthKeyUnregistered / UserDeactivated → STATUS_UNAUTHORIZED
               (session_revoked — not connection_failed)
             - OperationalError: database is locked → STATUS_CONNECTION_FAILED
               with a clear "another process holds the lock" reason
             - ConnectionError / TimeoutError → STATUS_CONNECTION_FAILED
             - FloodWait → STATUS_FLOODWAIT
             - Other → STATUS_CONNECTION_FAILED (generic)

        Returns granular status strings:
          - connected:<username>
          - no_session_file      → STATUS_MISSING_SESSION
          - not_authorized       → STATUS_UNAUTHORIZED
          - session_revoked      → STATUS_UNAUTHORIZED
          - session_corrupted    → STATUS_INVALID_SESSION
          - floodwait:<seconds>  → STATUS_FLOODWAIT
          - connection_failed:<exc> → STATUS_CONNECTION_FAILED
          - locked:<exc>         → STATUS_CONNECTION_FAILED (SQLite lock)
          - disabled             → STATUS_DISABLED
        """
        acc = self.get_account(account_id)
        if not acc:
            return "not_found"
        if acc.get("disabled"):
            return "disabled"

        # v97.96 FIX (BUG-4): single-flight per-account. If a manual
        # /reconnect command and _cluster_reconnect_loop both call
        # connect_account for the same account at the same time, the
        # second caller would create a SECOND TelegramClient on the
        # same SQLite session file → sqlite_locked. The lock ensures
        # exactly one connect operation per account at a time. The
        # second caller simply waits, then sees the result via the
        # existing-client reuse path above.
        _lk = self._account_connect_locks.get(account_id)
        if _lk is None:
            _lk = asyncio.Lock()
            self._account_connect_locks[account_id] = _lk
        async with _lk:
            return await self._connect_account_inner(account_id, acc)

    async def _connect_account_inner(
        self, account_id: str, acc: dict[str, Any],
    ) -> str:
        """v97.96: connect_account body, called under the per-account
        single-flight lock (BUG-4 fix). The public connect_account() wrapper
        acquires the lock and dispatches here.
        """
        # v97 CRITICAL FIX: if a client already exists for this account and is
        # connected, REUSE it. Previously, connect_account ALWAYS created a new
        # TelegramClient, even if one was already open on the same session file.
        # Two TelegramClient instances on the same SQLite session file cause
        # `OperationalError: database is locked`.
        existing_client = self._clients.get(account_id)
        if existing_client is not None:
            try:
                if existing_client.is_connected():
                    logger.info("ACCOUNT_CONNECT_REUSING_EXISTING account_id=%s "
                                "phone=%s — client already connected",
                                account_id, acc.get("phone", ""))
                    # Verify it's still authorized.
                    try:
                        me = await asyncio.wait_for(existing_client.get_me(), timeout=10)
                        acc["username"] = getattr(me, "username", "") or ""
                        acc["user_id"] = getattr(me, "id", 0) or 0
                        # v97.96 FIX (BUG-2): reset fail_count on success so
                        # the next transient failure starts backoff from 60s,
                        # not the previously-elevated step.
                        acc["fail_count"] = 0
                        self.update_status(account_id, STATUS_HEALTHY)
                        return f"connected:{acc['username'] or acc['user_id']}"
                    except Exception:
                        # Client exists but get_me failed — disconnect + fall through.
                        # v97.9: if this is the global _mtproto_client, do NOT
                        # disconnect/release — just remove the mapping and let
                        # mtproto_start handle the global client's lifecycle.
                        if existing_client is _mtproto_client:
                            logger.info(
                                "ACCOUNT_CONNECT_GLOBAL_CLIENT_GETME_FAIL account_id=%s "
                                "— client is global _mtproto_client; not disconnecting",
                                account_id,
                            )
                            self._clients.pop(account_id, None)
                        else:
                            # v97.96 FIX (BUG-1): forcibly cancel the existing
                            # client's 6 leaked Telethon background tasks BEFORE
                            # releasing. Without this, the old client's
                            # update_loop/keepalive_loop/sender_loops survive and
                            # keep writing to the SQLite session file, holding the
                            # write lock. Every subsequent connect_account creates
                            # a new TelegramClient that fails with
                            # `OperationalError: database is locked`. This was
                            # the root cause of the v97.95 secondary-account
                            # sqlite_locked cascade (bot-diagnostic (8).log:
                            # client_identity 103877824 stayed alive across
                            # 60+ failed reconnect attempts).
                            try:
                                await _forcibly_cancel_telethon_tasks(
                                    existing_client,
                                    label=f"cluster_reconnect_getme_fail:{account_id}",
                                )
                            except Exception as _fc_exc:  # noqa: BLE001
                                logger.debug(
                                    "ACCOUNT_FORCED_CANCEL_ERROR account_id=%s "
                                    "label=getme_fail exc=%s", account_id, _fc_exc,
                                )
                            try:
                                await existing_client.disconnect()
                            except Exception:  # noqa: BLE001
                                pass
                            await self._release_client_session(account_id, existing_client)
                            self._clients.pop(account_id, None)
                else:
                    # Client exists but not connected — remove and recreate.
                    # v97.9: same guard for the global _mtproto_client.
                    if existing_client is _mtproto_client:
                        self._clients.pop(account_id, None)
                    else:
                        # v97.96 FIX (BUG-1): forcibly cancel the existing
                        # client's 6 leaked Telethon background tasks BEFORE
                        # releasing. The runtime cascade (bot-diagnostic (8).log)
                        # showed this branch (is_connected()=False → release +
                        # pop) leaving client 103877824 alive with all 6 bg
                        # tasks holding the SQLite write lock. Every subsequent
                        # connect_account then failed with sqlite_locked forever.
                        try:
                            await _forcibly_cancel_telethon_tasks(
                                existing_client,
                                label=f"cluster_reconnect_stale:{account_id}",
                            )
                        except Exception as _fc_exc:  # noqa: BLE001
                            logger.debug(
                                "ACCOUNT_FORCED_CANCEL_ERROR account_id=%s "
                                "label=stale exc=%s", account_id, _fc_exc,
                            )
                        try:
                            await existing_client.disconnect()
                        except Exception:  # noqa: BLE001
                            pass
                        await self._release_client_session(account_id, existing_client)
                        self._clients.pop(account_id, None)
            except Exception:  # noqa: BLE001
                # v97.9: same guard for the global _mtproto_client.
                if existing_client is not _mtproto_client:
                    # v97.96 FIX (BUG-1): same forcibly-cancel pattern on the
                    # outer except path. If is_connected()/disconnect() raised
                    # mid-operation, the bg tasks are still alive.
                    try:
                        await _forcibly_cancel_telethon_tasks(
                            existing_client,
                            label=f"cluster_reconnect_except:{account_id}",
                        )
                    except Exception:  # noqa: BLE001
                        pass
                    try:
                        await existing_client.disconnect()
                    except Exception:  # noqa: BLE001
                        pass
                    await self._release_client_session(account_id, existing_client)
                self._clients.pop(account_id, None)

        phone = acc.get("phone", "")
        raw_path = acc.get("session_file", "")
        session_path = self._resolve_session_path(raw_path)

        # V70.1 §3: ACCOUNT_CONNECT_START log with full diagnostics.
        logger.info("ACCOUNT_CONNECT_START account_id=%s phone=%s session_path=%s",
                    account_id, phone, raw_path)
        acc["last_connect_attempt"] = time.time()
        self._save()

        if session_path is None:
            self.update_status(account_id, STATUS_MISSING_SESSION)
            logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                           "reason=no_session_file path=%s",
                           account_id, phone, raw_path)
            acc["last_exception"] = "no_session_file"
            acc["last_exception_type"] = "MissingSession"
            self._save()
            return "no_session_file"
        # If the resolved path differs from the stored one, persist it.
        if str(session_path) != raw_path:
            acc["session_file"] = str(session_path)
            self._save()
        # Validate the file is non-empty + readable SQLite.
        try:
            size = session_path.stat().st_size
            acc["session_size"] = size
            self._save()
            if size == 0:
                self.update_status(account_id, STATUS_INVALID_SESSION)
                logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                               "reason=empty_session path=%s",
                               account_id, phone, session_path)
                acc["last_exception"] = "empty_session_file"
                acc["last_exception_type"] = "InvalidSession"
                self._save()
                return "session_corrupted"
        except Exception as exc:
            self.update_status(account_id, STATUS_INVALID_SESSION)
            logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                           "reason=session_stat_failed path=%s exc=%s: %s",
                           account_id, phone, session_path,
                           type(exc).__name__, str(exc)[:120])
            acc["last_exception"] = f"{type(exc).__name__}: {str(exc)[:120]}"
            acc["last_exception_type"] = type(exc).__name__
            self._save()
            return "session_corrupted"

        # V70.1 §1: Check if this session file is the legacy MTProto session.
        # If so, REUSE _mtproto_client instead of reopening SQLite (which
        # would cause 'database is locked' → connection_failed).
        legacy_session_path = ""
        try:
            from importlib import import_module as _im
            # session_path() is a module-level function — call it via globals.
            _sess_fn = globals().get("session_path")
            if _sess_fn is not None:
                legacy_session_path = str(_sess_fn().resolve()) + ".session"
        except Exception:
            pass
        try:
            resolved_session = str(session_path.resolve())
        except Exception:
            resolved_session = str(session_path)

        legacy_client_active = (
            _mtproto_started
            and _mtproto_client is not None
            and _mtproto_client.is_connected()
        )
        is_legacy_session = (
            legacy_client_active
            and resolved_session == legacy_session_path
        )

        if is_legacy_session:
            # V70.1 §1: Reuse the legacy client.
            logger.info("ACCOUNT_CONNECT_REUSING_LEGACY account_id=%s phone=%s "
                        "session=%s", account_id, phone, legacy_session_path)
            try:
                if not await asyncio.wait_for(_mtproto_client.is_user_authorized(), timeout=15):
                    self.update_status(account_id, STATUS_UNAUTHORIZED)
                    logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s "
                                   "phone=%s reason=legacy_not_authorized",
                                   account_id, phone)
                    acc["last_exception"] = "legacy_not_authorized"
                    acc["last_exception_type"] = "Unauthorized"
                    self._save()
                    return "session_revoked"
                me = await asyncio.wait_for(_mtproto_client.get_me(), timeout=15)
                self._clients[account_id] = _mtproto_client
                acc["username"] = getattr(me, "username", "") or ""
                acc["user_id"] = getattr(me, "id", 0) or 0
                acc["legacy"] = True
                # v97.96 FIX (BUG-2): reset fail_count on success.
                acc["fail_count"] = 0
                self.update_status(account_id, STATUS_HEALTHY)
                logger.info("ACCOUNT_CONNECT_SUCCESS account_id=%s phone=%s "
                            "username=@%s id=%s strategy=legacy_reuse "
                            "session_size=%d",
                            account_id, phone, acc["username"],
                            acc["user_id"], size)
                acc["last_exception"] = ""
                acc["last_exception_type"] = ""
                self._save()
                return f"connected:{acc['username'] or acc['user_id']}"
            except Exception as exc:
                # Classify the exception granularly.
                return await self._classify_connect_exception(
                    account_id, phone, exc, session_path)

        # V70.1 §2: Not the legacy session — open with a new TelegramClient.
        client = None
        try:
            from telethon import TelegramClient
            self.update_status(account_id, STATUS_CONNECTING)
            telethon_session = str(session_path)
            if telethon_session.endswith(".session"):
                telethon_session = telethon_session[:-len(".session")]

            # v97 CRITICAL FIX: check the session ownership registry before
            # creating a new TelegramClient. If another client already owns
            # this session, reuse it instead of creating a duplicate.
            _existing = _get_session_owner(telethon_session)
            if _existing is not None:
                try:
                    if _existing.is_connected():
                        logger.info("ACCOUNT_CONNECT_REUSING_REGISTRY "
                                    "account_id=%s session=%s client_id=%s",
                                    account_id, telethon_session, id(_existing))
                        client = _existing
                        # Skip connect — already connected.
                        me = await asyncio.wait_for(client.get_me(), timeout=15)
                        self._clients[account_id] = client
                        acc["username"] = getattr(me, "username", "") or ""
                        acc["user_id"] = getattr(me, "id", 0) or 0
                        # v97.96 FIX (BUG-2): reset fail_count on success.
                        acc["fail_count"] = 0
                        self.update_status(account_id, STATUS_HEALTHY)
                        logger.info("ACCOUNT_CONNECT_SUCCESS account_id=%s "
                                    "phone=%s username=@%s id=%s "
                                    "strategy=registry_reuse",
                                    account_id, phone, acc["username"],
                                    acc["user_id"])
                        acc["last_exception"] = ""
                        acc["last_exception_type"] = ""
                        self._save()
                        return f"connected:{acc['username'] or acc['user_id']}"
                except Exception:
                    pass  # existing is broken — fall through to create new

            client = TelegramClient(
                telethon_session,
                config.tg_api_id,
                config.tg_api_hash,
                connection_retries=5,
                retry_delay=2,
                # v97.26: DISABLE auto_reconnect — it causes task explosion
                # (113 Telethon tasks, 219 wrong-session-ID errors, 61s lag).
                # The bot's _mtproto_safe_reconnect (with disconnect-first +
                # global lock + 30s cooldown) handles reconnection safely.
                # Telethon's IncompleteReadError is handled by the watchdog
                # which detects disconnection and triggers safe_reconnect.
                auto_reconnect=False,
                request_retries=3,
            )
            # v97: claim session ownership BEFORE connecting.
            if not await _claim_session(telethon_session, client):
                logger.error("ACCOUNT_CONNECT_FAILED account_id=%s "
                             "reason=session_owned_by_another path=%s",
                             account_id, telethon_session)
                self.update_status(account_id, STATUS_CONNECTION_FAILED)
                acc["last_exception"] = "session_owned_by_another"
                acc["last_exception_type"] = "OwnershipConflict"
                self._save()
                try:
                    await client.disconnect()
                except Exception:
                    pass
                return "locked:session_owned_by_another"
            # V86.5: bound each network operation so a hung connect/get_me
            # doesn't block startup_validate indefinitely.
            await asyncio.wait_for(client.connect(), timeout=30)
            if not await asyncio.wait_for(client.is_user_authorized(), timeout=15):
                self.update_status(account_id, STATUS_UNAUTHORIZED)
                await client.disconnect()
                # v97.6 FIX: release the session ownership on the not_authorized
                # path.  Previously, _claim_session registered the client as
                # owner BEFORE connect(), but when is_user_authorized() returned
                # False, the client was disconnected WITHOUT releasing ownership.
                # This left a stale owner in _session_owners that blocked all
                # future connect_account attempts with
                # SESSION_OWNERSHIP_CONFLICT — the same bug pattern that was
                # fixed in import_existing_sessions (line ~1726).
                try:
                    await self._release_client_session(account_id, client)
                except Exception:  # noqa: BLE001
                    pass
                logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s "
                               "phone=%s reason=not_authorized", account_id, phone)
                acc["last_exception"] = "not_authorized"
                acc["last_exception_type"] = "Unauthorized"
                self._save()
                return "session_revoked"
            me = await asyncio.wait_for(client.get_me(), timeout=15)
            # v97.53: invalidate any stale PyTgCallsBackend that references
            # the OLD client for this account. Without this, the backend's
            # self._mtproto points to a dead client until the next start().
            try:
                from .voicechat import vc_get_backend
                if hasattr(vc_get_backend, '_account_backends'):
                    old_backend = vc_get_backend._account_backends.pop(account_id, None)
                    if old_backend is not None:
                        logger.info("VC_BACKEND_INVALIDATED account=%s (client replaced)",
                                    account_id)
            except Exception:  # noqa: BLE001
                pass
            self._clients[account_id] = client
            acc["username"] = getattr(me, "username", "") or ""
            acc["user_id"] = getattr(me, "id", 0) or 0
            # v97.96 FIX (BUG-2): reset fail_count on success.
            acc["fail_count"] = 0
            self.update_status(account_id, STATUS_HEALTHY)
            # v97.79: snapshot THIS cluster client's 6 Telethon background tasks
            # so forced-cancel can cancel ONLY this client's tasks.
            _snapshot_telethon_bg_tasks(client, label=f"cluster:{account_id}")
            logger.info("ACCOUNT_CONNECT_SUCCESS account_id=%s phone=%s "
                        "username=@%s id=%s strategy=new_client "
                        "session_size=%d",
                        account_id, phone, acc["username"],
                        acc["user_id"], size)
            acc["last_exception"] = ""
            acc["last_exception_type"] = ""
            self._save()
            return f"connected:{acc['username'] or acc['user_id']}"
        except Exception as exc:
            if client is not None:
                # v97.96 FIX (BUG-1): forcibly cancel this NEW client's leaked
                # bg tasks BEFORE disconnect. On sqlite_locked the connect()
                # raised mid-handshake — the SQLiteSession was opened and may
                # have started a write transaction. The 6 bg tasks may have
                # been spawned (Telethon spawns them inside connect()) and
                # survive the disconnect() call. Without forcibly cancelling
                # them, the next connect_account iteration inherits the
                # leaked tasks + leaked SQLite write lock.
                try:
                    await _forcibly_cancel_telethon_tasks(
                        client,
                        label=f"cluster_connect_failed:{account_id}",
                    )
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await client.disconnect()
                except Exception:
                    pass
                # v97.5 FIX: release the session ownership when the client
                # fails to connect.  Previously, _claim_session registered
                # the client as owner BEFORE connect(), but if connect()
                # raised (e.g. AuthKeyDuplicatedError), the stale client
                # remained in _session_owners.  Every subsequent reconnect
                # attempt hit SESSION_OWNERSHIP_CONFLICT because the stale
                # (disconnected) client was still the registered owner.
                # This caused Account B to be permanently locked as
                # "session_owned_by_another" even though no live client
                # was using the session.
                try:
                    await self._release_client_session(account_id, client)
                except Exception:
                    pass
                self._clients.pop(account_id, None)
            return await self._classify_connect_exception(
                account_id, phone, exc, session_path)

    async def _classify_connect_exception(
        self, account_id: str, phone: str, exc: Exception,
        session_path) -> str:
        """V70.1 §2: Classify a connect exception into a granular status.

        Avoids collapsing everything into 'connection_failed'. Distinguishes:
          - FloodWait → STATUS_FLOODWAIT
          - AuthKeyUnregistered / UserDeactivated / AuthKeyDuplicated
            → STATUS_UNAUTHORIZED (session_revoked)
          - OperationalError: database is locked
            → STATUS_CONNECTION_FAILED (locked — another process holds the lock)
          - ConnectionError / TimeoutError / OSError
            → STATUS_CONNECTION_FAILED (network)
          - Other → STATUS_CONNECTION_FAILED (generic)
        """
        acc = self.get_account(account_id)
        if not acc:
            return f"connection_failed:{exc}"
        err_str = str(exc).lower()
        exc_type = type(exc).__name__
        acc["last_exception"] = f"{exc_type}: {str(exc)[:150]}"
        acc["last_exception_type"] = exc_type
        acc["last_connect_attempt"] = time.time()

        # FloodWait — extract the wait time.
        if "flood" in err_str:
            import re as _re
            m = _re.search(r"(\d+)\s*second", err_str)
            wait = int(m.group(1)) if m else 60
            self.update_status(account_id, STATUS_FLOODWAIT,
                               floodwait_until=time.time() + wait)
            logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                           "reason=floodwait wait=%ds exc=%s: %s",
                           account_id, phone, wait, exc_type, str(exc)[:120])
            self._save()
            return f"floodwait:{wait}"

        # Session revoked / auth key invalid.
        if any(kw in err_str for kw in (
            "authkeyunregistered", "auth key unregistered",
            "authkeyduplicated", "userdeactivated", "user deactivated",
            "session revoked", "sessionrevoked",
            "unauthorized", "AUTH_KEY_UNREGISTERED",
        )):
            self.update_status(account_id, STATUS_UNAUTHORIZED)
            logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                           "reason=session_revoked exc=%s: %s",
                           account_id, phone, exc_type, str(exc)[:120])
            self._save()
            return "session_revoked"

        # SQLite database locked.
        if "database is locked" in err_str or (
            "operationalerror" in err_str and "locked" in err_str
        ):
            # v97.96 FIX (BUG-2): increment fail_count so the
            # _cluster_reconnect_loop's exponential backoff (60→300→900s)
            # actually escalates. Previously _classify_connect_exception
            # only called update_status(STATUS_CONNECTION_FAILED), which
            # does NOT touch fail_count. As a result the loop retried every
            # 60s forever (fail_count stayed at 0), amplifying BUG-1's
            # leaked-tasks cascade. Runtime evidence: bot (9).log shows
            # ~74s retry period from 14:58:03 to 15:56:37+ (~50 iterations).
            _new_fc = int(acc.get("fail_count", 0)) + 1
            acc["fail_count"] = _new_fc
            self.update_status(account_id, STATUS_CONNECTION_FAILED)
            logger.error("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                         "reason=sqlite_locked path=%s exc=%s: %s — "
                         "another process holds the write lock",
                         account_id, phone, session_path, exc_type,
                         str(exc)[:120])
            # v97.96: structured backoff marker so operators can see the
            # next retry delay without re-deriving it from fail_count.
            _bo_steps = [60, 300, 900]
            _bo_idx = min(_new_fc - 1, len(_bo_steps) - 1)
            logger.warning(
                "ACCOUNT_SQLITE_LOCKED_BACKOFF account_id=%s phone=%s "
                "fail_count=%d next_backoff=%ds (v97.96 BUG-2 fix)",
                account_id, phone, _new_fc, _bo_steps[_bo_idx],
            )
            self._save()
            return f"locked:{exc}"

        # Session corrupted — SQLite errors other than lock.
        if "operationalerror" in err_str or "databaseerror" in err_str:
            self.update_status(account_id, STATUS_INVALID_SESSION)
            logger.error("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                         "reason=session_corrupted path=%s exc=%s: %s",
                         account_id, phone, session_path, exc_type,
                         str(exc)[:120])
            self._save()
            return "session_corrupted"

        # Network / connection errors.
        if any(kw in err_str for kw in (
            "connection", "timeout", "disconnect", "refused",
            "unreachable", "reset", "broken pipe",
        )):
            # v97.96 FIX (BUG-2): increment fail_count (see sqlite_locked
            # branch above for rationale).
            acc["fail_count"] = int(acc.get("fail_count", 0)) + 1
            self.update_status(account_id, STATUS_CONNECTION_FAILED)
            logger.error("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                         "reason=connection_failed exc=%s: %s",
                         account_id, phone, exc_type, str(exc)[:120])
            self._save()
            return f"connection_failed:{exc}"

        # Generic fallback — still connection_failed, but log the full type.
        # v97.96 FIX (BUG-2): increment fail_count (see sqlite_locked
        # branch above for rationale).
        acc["fail_count"] = int(acc.get("fail_count", 0)) + 1
        self.update_status(account_id, STATUS_CONNECTION_FAILED)
        logger.error("ACCOUNT_CONNECT_FAILED account_id=%s phone=%s "
                     "reason=generic exc=%s: %s",
                     account_id, phone, exc_type, str(exc)[:120])
        self._save()
        return f"connection_failed:{exc}"

    async def disconnect_account(self, account_id: str) -> str:
        """Disconnect an account's TelegramClient.

        v97.5 FIX: release the session ownership when disconnecting.
        Previously, disconnect_account removed the client from _clients and
        disconnected it, but did NOT call _release_client_session.  This left
        a stale owner in _session_owners, causing the next connect_account
        to fail with SESSION_OWNERSHIP_CONFLICT.

        v97.9 FIX: if the account's client IS the global _mtproto_client
        (legacy reuse / registry_reuse of the primary session), do NOT
        disconnect it or release its ownership — that would break the entire
        MTProto subsystem.  The global client's lifecycle is owned by
        mtproto_start / mtproto_stop.  We only remove the account→client
        mapping so the account is no longer "connected" from the cluster's
        perspective.
        """
        client = self._clients.pop(account_id, None)
        if client:
            # v97.9: guard against disconnecting the global _mtproto_client.
            # This happens when an account reuses the legacy/primary session
            # (connect_account registry_reuse, import_existing_sessions legacy
            # reuse, or explicit legacy reuse).  Disconnecting it would break
            # MTProto for ALL accounts.
            if client is _mtproto_client:
                logger.info(
                    "ACCOUNT_DISCONNECT_SKIP_GLOBAL account_id=%s — client is "
                    "the global _mtproto_client (legacy reuse); not disconnecting",
                    account_id,
                )
            else:
                # v97.96 FIX (BUG-3): forcibly cancel the client's 6 Telethon
                # background tasks BEFORE disconnect. Without this, if the
                # disconnect() drain (awaited below) times out, the bg tasks
                # survive and keep writing to the SQLite session file. This
                # is the same pattern applied to connect_account's existing-
                # client paths (BUG-1 fix) and to _telethon_drain_and_reconnect_raw
                # (mtproto.py:4962).
                try:
                    await _forcibly_cancel_telethon_tasks(
                        client,
                        label=f"cluster_disconnect:{account_id}",
                    )
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await client.disconnect()
                except Exception:
                    pass
                # v97.32: await the disconnected drain future so ALL 6 Telethon
                # background tasks are fully done before we release the session.
                # Without this, the tasks survive and produce "Task was destroyed
                # but it is pending" when the loop closes.
                disc = getattr(client, "disconnected", None)
                if disc is not None:
                    try:
                        await asyncio.wait_for(disc, timeout=10)
                    except asyncio.TimeoutError:
                        # v97.74 P1: split the broad except — log so operators
                        # can see why a cluster client's background tasks did
                        # not drain (the global path at
                        # _telethon_drain_and_reconnect_raw already logs
                        # MTPROTO_DISCONNECT_DRAIN_TIMEOUT; this per-account
                        # path was previously blind).
                        logger.debug(
                            "MTPROTO_CLUSTER_DRAIN_TIMEOUT account=%s (10s) — "
                            "background tasks may still be cancelling", account_id,
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.debug(
                            "MTPROTO_CLUSTER_DRAIN_ERROR account=%s exc=%s",
                            account_id, exc,
                        )
                # v97.5: release the session ownership so reconnect can re-claim.
                await self._release_client_session(account_id, client)
        acc = self.get_account(account_id)
        if acc and not acc.get("disabled"):
            self.update_status(account_id, STATUS_DISCONNECTED)
        return "disconnected"

    # ------------------------------------------------------------------
    # Existing-session importer (V67.4)
    # ------------------------------------------------------------------

    async def import_existing_sessions(self) -> dict[str, Any]:
        """V69.1: Scan BOTH data/ and data/sessions/ for *.session files and
        auto-import any sessions that aren't already registered.

        V69.1 FIX (vs V68.2): The V68.2 importer opened each .session file with
        a TEMPORARY TelegramClient. But if the legacy MTProto client
        (_mtproto_client from mtproto_start()) was ALREADY using the same file
        (e.g. data/user_session.session), SQLite raised
        `OperationalError: database is locked` because the legacy client held
        a write lock. The import failed with no useful diagnostics.

        V69.1 fix:
          1. BEFORE opening a session file, check if it's already in use by:
             a. An existing cluster account (by resolved path) → skip (duplicate)
             b. The legacy _mtproto_client (compare session paths) → REUSE the
                legacy client as a cluster account (don't reopen SQLite).
          2. If the file is NOT in use by the legacy client, open it with a
             temp client. If SQLite raises 'database is locked', retry with
             exponential backoff (1s, 2s, 5s).
          3. If still locked after 3 retries, log the EXACT reason (which
             process/task likely holds the lock) instead of a generic 'failed'.

        For each .session file:
          1. Validate: exists, size > 0.
          2. Open (or reuse) a TelegramClient.
          3. Verify authorization (is_user_authorized).
          4. Call get_me() to capture phone/username/user_id.
          5. Register it via add_account().
          6. Move the connected client into the cluster pool.

        Avoids duplicates by phone number AND by resolved file path.

        Returns a report dict:
          { scanned, imported, duplicate, failed, details: [...] }
        """
        report = {
            "scanned": 0, "imported": 0, "duplicate": 0, "failed": 0,
            "reused_legacy": 0, "skipped": 0,
            "details": [],
        }
        logger.info("SESSION_IMPORT_START")
        # V72 PART 5: Recursive scan of ALL known session directories.
        # Real deployments have sessions in various locations:
        #   data/*.session
        #   data/sessions/*.session
        #   data/user/*.session          (GitHub deployment layout)
        #   data/user/user_session.session
        #   sessions/*.session           (Railay volume mount)
        #   accounts/*.session
        # Use rglob (recursive) to find ALL .session files in these trees.
        scan_roots = [
            Path(config.project_root) / "data",
            Path(config.project_root) / "sessions",
            Path(config.project_root) / "accounts",
            _CLUSTER_ACCOUNTS_DIR,
        ]
        seen_paths: set[str] = set()
        session_files: list[Path] = []
        for scan_root in scan_roots:
            try:
                scan_root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
            logger.info("SESSION_IMPORT_SCAN_PATH dir=%s exists=%s",
                        scan_root, scan_root.exists())
            if not scan_root.exists():
                continue
            try:
                # V72: rglob (recursive) instead of glob (non-recursive).
                for sf in sorted(scan_root.rglob("*.session")):
                    # Skip SQLite journal/wal/shm sidecar files.
                    if sf.name.endswith(("-journal", "-wal", "-shm")):
                        continue
                    # Skip files inside the downloads/ or frames/ subdirs
                    # (those are media outputs, not Telethon sessions).
                    try:
                        rel = sf.relative_to(scan_root)
                        if any(part in ("downloads", "frames") for part in rel.parts):
                            continue
                    except Exception:
                        pass
                    try:
                        resolved = str(sf.resolve())
                    except Exception:
                        resolved = str(sf)
                    if resolved in seen_paths:
                        continue
                    seen_paths.add(resolved)
                    session_files.append(sf)
                    logger.info("SESSION_FILE_FOUND file=%s dir=%s path=%s",
                                sf.name, scan_root, resolved)
            except Exception as exc:
                logger.warning("SESSION_IMPORT_SCAN_FAILED dir=%s exc=%s: %s",
                               scan_root, type(exc).__name__, str(exc)[:120])

        report["scanned"] = len(session_files)
        logger.info("SESSION_IMPORT_SCAN_COMPLETE found=%d (deduped from %d raw) "
                    "scanned_roots=%s",
                    len(session_files), len(seen_paths),
                    [str(d) for d in scan_roots])
        if not session_files:
            logger.info("SESSION_IMPORT_NO_FILES checked_dirs=%s",
                        [str(d) for d in scan_roots])
            return report

        # V69.1: Identify the legacy MTProto client's session path so we can
        # REUSE it instead of reopening the same SQLite file (which would
        # cause 'database is locked').
        legacy_session_path = ""
        try:
            legacy_session_path = str(session_path().resolve()) + ".session"
        except Exception:
            pass
        legacy_client_active = (
            _mtproto_started
            and _mtproto_client is not None
            and _mtproto_client.is_connected()
        )
        if legacy_client_active:
            logger.info("SESSION_IMPORT_LEGACY_CLIENT_ACTIVE session=%s "
                        "— will reuse instead of reopening", legacy_session_path)

        # Map of phone → account_id AND session_path → account_id for duplicate
        # detection (phone is primary, path is secondary).
        existing_phones: dict[str, str] = {}
        existing_paths: dict[str, str] = {}
        for aid, a in self._accounts.items():
            if aid.startswith("__") or not isinstance(a, dict):
                continue
            ph = a.get("phone", "")
            if ph:
                existing_phones[ph] = aid
            sp = a.get("session_file", "")
            if sp:
                try:
                    existing_paths[str(Path(sp).resolve())] = aid
                except Exception:
                    pass

        for sf in session_files:
            entry = {"file": str(sf), "name": sf.name}
            try:
                # V69.1 §3: Validate file exists + size > 0 BEFORE opening.
                if not sf.exists():
                    report["failed"] += 1
                    entry["status"] = "invalid"
                    entry["reason"] = "file_not_found"
                    report["details"].append(entry)
                    logger.warning("SESSION_INVALID file=%s reason=file_not_found",
                                   sf.name)
                    continue
                try:
                    size = sf.stat().st_size
                except Exception as exc:
                    report["failed"] += 1
                    entry["status"] = "invalid"
                    entry["reason"] = f"stat_failed: {exc}"
                    report["details"].append(entry)
                    logger.warning("SESSION_INVALID file=%s reason=stat_failed exc=%s",
                                   sf.name, exc)
                    continue
                if size == 0:
                    report["failed"] += 1
                    entry["status"] = "invalid"
                    entry["reason"] = "empty_file"
                    report["details"].append(entry)
                    logger.warning("SESSION_INVALID file=%s reason=empty_file",
                                   sf.name)
                    continue

                # Check for path-based duplicate first.
                try:
                    resolved_sf = str(sf.resolve())
                except Exception:
                    resolved_sf = str(sf)
                if resolved_sf in existing_paths:
                    report["duplicate"] += 1
                    entry["status"] = "duplicate"
                    entry["reason"] = "path_already_registered"
                    entry["account_id"] = existing_paths[resolved_sf]
                    report["details"].append(entry)
                    logger.info("SESSION_DUPLICATE file=%s reason=path "
                                "existing=%s", sf.name, existing_paths[resolved_sf])
                    continue

                # V69.1 §1: Check if this file is the legacy MTProto session.
                # If so, REUSE the legacy client instead of reopening SQLite.
                is_legacy_session = (
                    legacy_client_active
                    and resolved_sf == legacy_session_path
                )
                if is_legacy_session:
                    logger.info("SESSION_OPEN_ATTEMPT file=%s strategy=reuse_legacy",
                                sf.name)
                    try:
                        me = await asyncio.wait_for(_mtproto_client.get_me(), timeout=15)
                    except Exception as exc:
                        report["failed"] += 1
                        entry["status"] = "error"
                        entry["reason"] = f"legacy_get_me_failed: {exc}"
                        report["details"].append(entry)
                        logger.error("SESSION_IMPORT_FAILED file=%s "
                                     "reason=legacy_get_me_failed exc=%s: %s",
                                     sf.name, type(exc).__name__, str(exc)[:120])
                        continue
                    if not await asyncio.wait_for(_mtproto_client.is_user_authorized(), timeout=15):
                        report["failed"] += 1
                        entry["status"] = "unauthorized"
                        entry["reason"] = "legacy_not_authorized"
                        report["details"].append(entry)
                        logger.warning("SESSION_UNAUTHORIZED file=%s "
                                       "reason=legacy_not_authorized", sf.name)
                        # v99.03 RC-10/RC-11: registry + remediation line.
                        _register_session_status(sf.name, "unauthorized")
                        _emit_session_remediation(sf.name)
                        continue
                    phone = getattr(me, "phone", "") or ""
                    if not phone:
                        phone = "+" + sf.stem.replace("cluster_", "")
                    if phone in existing_phones:
                        report["duplicate"] += 1
                        entry["status"] = "duplicate"
                        entry["reason"] = "phone_already_registered"
                        entry["account_id"] = existing_phones[phone]
                        report["details"].append(entry)
                        logger.info("SESSION_DUPLICATE file=%s phone=%s "
                                    "existing=%s", sf.name, phone,
                                    existing_phones[phone])
                        continue
                    username = getattr(me, "username", "") or ""
                    user_id = getattr(me, "id", 0) or 0
                    logger.info("SESSION_VALID file=%s phone=%s username=@%s "
                                "strategy=legacy", sf.name, phone, username)
                    # Register the account — reuse the legacy client.
                    aid = self.add_account(
                        phone, str(sf), role=ROLE_PRIMARY,
                        username=username, user_id=user_id,
                    )
                    self._accounts[aid]["imported"] = True
                    self._accounts[aid]["status"] = STATUS_HEALTHY
                    self._accounts[aid]["legacy"] = True
                    self._clients[aid] = _mtproto_client
                    existing_phones[phone] = aid
                    existing_paths[resolved_sf] = aid
                    report["imported"] += 1
                    report["reused_legacy"] += 1
                    entry["status"] = "imported"
                    entry["strategy"] = "reuse_legacy"
                    entry["account_id"] = aid
                    entry["phone"] = phone
                    entry["username"] = username
                    report["details"].append(entry)
                    logger.info("SESSION_IMPORT_SUCCESS file=%s account_id=%s "
                                "phone=%s username=@%s strategy=legacy",
                                sf.name, aid, phone, username)
                    logger.info("ACCOUNT_REGISTERED account_id=%s phone=%s "
                                "source=legacy_reuse", aid, phone)
                    # v99.03 RC-10: registry entry for the imported file.
                    _register_session_status(
                        sf.name, "imported", username=username,
                        user_id=user_id, account_id=aid)
                    continue

                # V72 PART 4: Not the legacy session — open with a temp client.
                # V72 FIX: If the session file is locked (another process holds
                # the SQLite write lock), COPY it to a temp file and open the
                # copy. This avoids the lock entirely because the copy is a
                # fresh SQLite database that no other process has open.
                logger.info("SESSION_OPEN_ATTEMPT file=%s strategy=temp_client",
                            sf.name)
                from telethon import TelegramClient
                import tempfile
                import shutil
                base = str(sf)
                if base.endswith(".session"):
                    base = base[:-len(".session")]

                # v97 CRITICAL FIX: check the session ownership registry.
                # If another client already owns this session, skip the temp
                # client creation entirely — we can't open the same SQLite
                # session file twice.
                _existing_owner = _get_session_owner(base)
                if _existing_owner is not None:
                    try:
                        if _existing_owner.is_connected():
                            logger.info("SESSION_IMPORT_SKIP_OWNED file=%s — "
                                        "session already owned by client_id=%s",
                                        sf.name, id(_existing_owner))
                            report["duplicate"] += 1
                            entry["status"] = "duplicate"
                            entry["reason"] = "session_already_owned"
                            report["details"].append(entry)
                            continue
                    except Exception:
                        pass  # owner is broken — fall through

                tmp = None
                last_lock_exc: Exception | None = None
                copied_to: str | None = None
                for attempt, delay in enumerate([0, 1, 2, 5], start=1):
                    try:
                        tmp = TelegramClient(
                            base, config.tg_api_id, config.tg_api_hash,
                            connection_retries=3, retry_delay=2,
                            # v97.28: disable auto_reconnect for consistency
                            # with the global _mtproto_client policy (v97.26).
                            # Telethon's internal auto_reconnect spawns new
                            # background tasks independently of the bot's
                            # _mtproto_safe_reconnect, causing duplicate
                            # lifecycle task sets on flaky connections.
                            auto_reconnect=False,
                        )
                        # v97: claim session ownership BEFORE connecting.
                        if not await _claim_session(base, tmp):
                            logger.warning("SESSION_IMPORT_OWNERSHIP_CONFLICT "
                                           "file=%s attempt=%d — skipping",
                                           sf.name, attempt)
                            try:
                                await tmp.disconnect()
                            except Exception:
                                pass
                            tmp = None
                            last_lock_exc = Exception("session_owned_by_another")
                            if delay > 0:
                                await asyncio.sleep(delay)
                            continue
                        await asyncio.wait_for(tmp.connect(), timeout=30)
                        last_lock_exc = None
                        break
                    except asyncio.TimeoutError:
                        last_lock_exc = TimeoutError("connect timed out after 30s")
                        logger.warning("SESSION_CONNECT_TIMEOUT file=%s attempt=%d/4", sf.name, attempt)
                        if tmp is not None:
                            try: await tmp.disconnect()
                            except Exception as exc:  # noqa: BLE001
                                # v97.74 P2: previously `except Exception: pass` —
                                # silently swallowed disconnect failures (e.g.
                                # "database is locked"), so the next retry
                                # created a fresh client on a locked file.
                                logger.debug("SESSION_TMP_DISCONNECT_FAILED file=%s err=%s", sf.name, exc)
                            tmp = None
                        if delay > 0:
                            await asyncio.sleep(delay)
                        continue
                    except Exception as exc:
                        last_lock_exc = exc
                        err_str = str(exc).lower()
                        if "database is locked" in err_str or "locked" in err_str:
                            logger.warning("SESSION_LOCKED file=%s attempt=%d/%d "
                                           "wait=%ss exc=%s",
                                           sf.name, attempt, 4, delay,
                                           type(exc).__name__)
                            if tmp is not None:
                                try:
                                    await tmp.disconnect()
                                except Exception:
                                    pass
                                tmp = None
                            # V72 PART 4: On first lock, copy the file to a
                            # temp location and try opening the copy.
                            if attempt == 1 and copied_to is None:
                                try:
                                    fd, copied_to = tempfile.mkstemp(
                                        suffix=".session",
                                        prefix="v72_import_",
                                        dir=str(_CLUSTER_ACCOUNTS_DIR),
                                    )
                                    import os as _os
                                    _os.close(fd)
                                    shutil.copy2(str(sf), copied_to)
                                    logger.info("SESSION_IMPORT_LOCK_RETRY "
                                                "file=%s copied_to=%s "
                                                "reason=sqlite_locked",
                                                sf.name, copied_to)
                                    base = copied_to[:-len(".session")] \
                                        if copied_to.endswith(".session") \
                                        else copied_to
                                except Exception as copy_exc:
                                    logger.warning("SESSION_IMPORT_COPY_FAILED "
                                                   "file=%s exc=%s: %s",
                                                   sf.name,
                                                   type(copy_exc).__name__,
                                                   str(copy_exc)[:120])
                            if delay > 0:
                                await asyncio.sleep(delay)
                            continue
                        # Non-lock error — don't retry.
                        raise
                if tmp is None or last_lock_exc is not None:
                    report["failed"] += 1
                    entry["status"] = "locked"
                    entry["reason"] = (
                        f"SQLite database locked after 4 attempts. "
                        f"Another process holds the write lock on {sf.name}. "
                        f"Last error: {last_lock_exc}"
                    )
                    report["details"].append(entry)
                    logger.error("SESSION_IMPORT_FAILED file=%s reason=locked "
                                 "attempts=4 last_exc=%s: %s", sf.name,
                                 type(last_lock_exc).__name__ if last_lock_exc else "?",
                                 str(last_lock_exc)[:120] if last_lock_exc else "")
                    # Clean up the copy if we made one.
                    if copied_to:
                        try:
                            Path(copied_to).unlink(missing_ok=True)
                        except Exception:
                            pass
                    continue

                # V69.1 §3: Validate the session.
                try:
                    if not await asyncio.wait_for(tmp.is_user_authorized(), timeout=15):
                        report["failed"] += 1
                        entry["status"] = "unauthorized"
                        entry["error"] = "session not authorized"
                        report["details"].append(entry)
                        logger.warning("SESSION_UNAUTHORIZED file=%s "
                                       "reason=not_authorized", sf.name)
                        # v99.03 RC-10/RC-11: registry + the remediation
                        # runbook — THIS is the exact v99.02 production site
                        # (bot-diagnostic.log line 131: cluster_916397080450
                        # .session, dead, never surfaced again afterwards).
                        _register_session_status(sf.name, "unauthorized")
                        _emit_session_remediation(sf.name)
                        try:
                            await tmp.disconnect()
                        except Exception:
                            pass
                        # v97.5 CRITICAL FIX: release the session ownership
                        # when the temp client finds the session unauthorized.
                        # Previously, the temp client from import_existing_sessions
                        # claimed ownership via _claim_session, but when it found
                        # the session unauthorized, it disconnected WITHOUT
                        # releasing ownership.  This left a stale owner in
                        # _session_owners that blocked all future connect_account
                        # and cluster_start_login attempts with
                        # SESSION_OWNERSHIP_CONFLICT.
                        try:
                            # v97.9 FIX: release the COPY path (base), not the
                            # original path — the temp client claimed the COPY.
                            await _release_session(base)
                        except Exception:
                            pass
                        # v97.9 FIX: clean up the COPY file if we made one.
                        if copied_to:
                            try:
                                Path(copied_to).unlink(missing_ok=True)
                            except Exception:  # noqa: BLE001
                                pass
                        continue
                    me = await asyncio.wait_for(tmp.get_me(), timeout=15)
                    phone = getattr(me, "phone", "") or ""
                    if not phone:
                        phone = "+" + sf.stem.replace("cluster_", "")
                    if phone in existing_phones:
                        report["duplicate"] += 1
                        entry["status"] = "duplicate"
                        entry["reason"] = "phone_already_registered"
                        entry["account_id"] = existing_phones[phone]
                        report["details"].append(entry)
                        logger.info("SESSION_DUPLICATE file=%s phone=%s "
                                    "existing=%s", sf.name, phone,
                                    existing_phones[phone])
                        try:
                            await tmp.disconnect()
                        except Exception:
                            pass
                        continue
                    username = getattr(me, "username", "") or ""
                    user_id = getattr(me, "id", 0) or 0
                    logger.info("SESSION_VALID file=%s phone=%s username=@%s "
                                "strategy=temp", sf.name, phone, username)
                    # Register the account — use the COPY path if we
                    # made one (otherwise the original locked file).
                    registered_path = copied_to if copied_to else str(sf)
                    aid = self.add_account(
                        phone, registered_path, role=ROLE_BACKUP,
                        username=username, user_id=user_id,
                    )
                    self._accounts[aid]["imported"] = True
                    self._accounts[aid]["status"] = STATUS_HEALTHY
                    self._clients[aid] = tmp
                    existing_phones[phone] = aid
                    existing_paths[resolved_sf] = aid
                    report["imported"] += 1
                    entry["status"] = "imported"
                    entry["strategy"] = "temp_client"
                    entry["account_id"] = aid
                    entry["phone"] = phone
                    entry["username"] = username
                    report["details"].append(entry)
                    logger.info("SESSION_IMPORT_SUCCESS file=%s account_id=%s "
                                "phone=%s username=@%s strategy=temp "
                                "registered_path=%s",
                                sf.name, aid, phone, username, registered_path)
                    logger.info("ACCOUNT_REGISTERED account_id=%s phone=%s "
                                "source=import", aid, phone)
                    # v99.03 RC-10: registry entry for the imported file.
                    _register_session_status(
                        sf.name, "imported", username=username,
                        user_id=user_id, account_id=aid)
                    continue  # don't run the finally disconnect
                finally:
                    # If we didn't move the client into the pool, disconnect.
                    if entry.get("status") != "imported":
                        try:
                            await tmp.disconnect()
                        except Exception:
                            pass
                        # v97.5: release session ownership for temp clients
                        # that were NOT imported into the pool.  This prevents
                        # stale owners from blocking future connect_account /
                        # cluster_start_login attempts.
                        # v97.9 FIX: release the COPY path (base), not the
                        # original path — the temp client claimed the COPY.
                        try:
                            await _release_session(base)
                        except Exception:
                            pass
                        # v97.9 FIX: clean up the COPY file if we made one.
                        if copied_to:
                            try:
                                Path(copied_to).unlink(missing_ok=True)
                            except Exception:  # noqa: BLE001
                                pass
            except Exception as exc:
                report["failed"] += 1
                entry["status"] = "error"
                entry["error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
                report["details"].append(entry)
                logger.error("SESSION_IMPORT_FAILED file=%s exc=%s: %s",
                             sf.name, type(exc).__name__, str(exc)[:120])
                # v97.5 CRITICAL FIX: release the session ownership when the
                # temp client fails with an exception (e.g. AuthKeyDuplicatedError
                # raised by connect() BEFORE the validation try/finally block).
                # Previously, the finally block at line ~1795 only covered the
                # validation section — but AuthKeyDuplicatedError is raised by
                # connect() which is OUTSIDE that try/finally.  The exception
                # propagated to this outer except, which did NOT release the
                # session, leaving a stale owner that blocked all future
                # connect_account / cluster_start_login attempts.
                if tmp is not None:
                    try:
                        await tmp.disconnect()
                    except Exception:
                        pass
                try:
                    # v97.9 FIX: release the COPY path (base) if a copy was
                    # made, otherwise the original path.
                    _release_base = base if copied_to else str(sf.with_suffix(""))
                    await _release_session(_release_base)
                except Exception:
                    pass
                # v97.9 FIX: clean up the COPY file if we made one.
                if copied_to:
                    try:
                        Path(copied_to).unlink(missing_ok=True)
                    except Exception:  # noqa: BLE001
                        pass
        # Persist the imported flag.
        self._save()
        logger.info("SESSION_IMPORT_REPORT scanned=%d imported=%d duplicate=%d "
                    "failed=%d reused_legacy=%d", report["scanned"],
                    report["imported"], report["duplicate"], report["failed"],
                    report["reused_legacy"])
        # v99.03 RC-10: the per-.session-file health summary — the ONE line
        # that answers "I have N .session files but the bot shows M accounts"
        # (the v99.02 production operator's exact report: 3 files, 1 cluster
        # account shown, 1 file dead, 1 file the primary global session).
        _emit_account_session_health()

        # V69.1 §5: Auto-assign primary if we have healthy accounts but none set.
        if not self.get_primary_id():
            healthy = self.get_healthy_accounts()
            if healthy:
                healthy.sort(key=lambda a: float(a.get("created_at", 0)))
                first_aid = healthy[0]["account_id"]
                self.set_primary_id(first_aid)
                if self._accounts[first_aid].get("role") != ROLE_PRIMARY:
                    self._accounts[first_aid]["role"] = ROLE_PRIMARY
                    self._save()
                logger.info("PRIMARY_ASSIGNED account_id=%s source=import_auto",
                            first_aid)
        return report

    async def startup_validate(self) -> dict[str, Any]:
        """V67.4: Validate every registered account on startup.

        For each account:
          - session exists?
          - authorized?
          - connect succeeds?
          - get_me() succeeds?
        Updates health state and returns a report.
        """
        accounts = self.list_accounts()
        report = {
            "total": len(accounts),
            "sessions_found": 0, "imported": 0, "connected": 0, "failed": 0,
            "details": [],
        }
        for acc in accounts:
            aid = acc["account_id"]
            entry = {"account_id": aid, "phone": acc.get("phone", "")}
            sess = self.get_session_info(aid)
            if sess["exists"]:
                report["sessions_found"] += 1
                entry["session_exists"] = True
                entry["session_size"] = sess["size"]
            else:
                entry["session_exists"] = False
                self.update_status(aid, STATUS_MISSING_SESSION)
                report["failed"] += 1
                entry["status"] = "missing_session"
                report["details"].append(entry)
                continue
            if acc.get("imported"):
                report["imported"] += 1
            # Try to connect.
            try:
                result = await self.connect_account(aid)
                if result.startswith("connected"):
                    report["connected"] += 1
                    entry["status"] = "connected"
                else:
                    report["failed"] += 1
                    entry["status"] = result
            except Exception as exc:
                report["failed"] += 1
                entry["status"] = f"error:{exc}"
            report["details"].append(entry)
        logger.info("ACCOUNT_STARTUP_REPORT total=%d sessions_found=%d "
                    "imported=%d connected=%d failed=%d",
                    report["total"], report["sessions_found"],
                    report["imported"], report["connected"], report["failed"])
        return report


# Global cluster instance.
_userbot_cluster: UserbotCluster | None = None


def get_userbot_cluster() -> UserbotCluster:
    """Get the global UserbotCluster instance (lazy init)."""
    global _userbot_cluster
    if _userbot_cluster is None:
        _userbot_cluster = UserbotCluster()
    return _userbot_cluster


# ---------------------------------------------------------------------------
# v98.07 FIX-UU (F5 — session hot-reload ABSENT, RUNTIME-PROVEN via
# bot-diagnostic.log.1 pid=7670: SESSION_IMPORT_SCAN_COMPLETE found=2
# scanned_roots=[data, sessions, accounts, data/sessions] — the import runs
# ONCE at startup; .session files dropped into those roots AFTER boot are
# NEVER imported (the operator must restart the bot to add accounts).
# This loop rescans the 4 roots every 60s (filesystem-only, no RPC) and,
# when a NEW .session path appears, runs the real import machinery
# (import_existing_sessions: dedup by path/phone, temp-client auth
# validation, add_account) WITHOUT a restart.
# ---------------------------------------------------------------------------
_VC_HOT_RELOAD_KNOWN_PATHS: set[str] | None = None
_vc_session_hot_reload_task: "asyncio.Task[None] | None" = None


async def _vc_session_hot_reload_loop() -> None:
    """v98.07 FIX-UU: periodic (60s) session-root rescan + hot import."""
    global _VC_HOT_RELOAD_KNOWN_PATHS
    logger.info(
        "SESSION_HOT_RELOAD_LOOP started (60s rescan cadence, filesystem-only "
        "until a NEW .session path appears; v98.07 FIX-UU)")
    # v99.08 sustainability item 3: heartbeat with the v98.05 FIX-KK
    # worker watchdog (lazy import — mtproto is imported by bootstrap at
    # module level; same pattern as _mtproto_health_loop).
    _v9908_shb = None
    try:
        from .bootstrap import (
            bot_worker_register as _v9908_sreg,
            bot_worker_heartbeat as _v9908_shb,
        )
        _v9908_sreg("vc_session_hot_reload_loop", expected_duration=90.0)
    except Exception:  # noqa: BLE001
        _v9908_shb = None
    while True:
        try:
            if _v9908_shb is not None:
                try:
                    _v9908_shb("vc_session_hot_reload_loop")  # v99.08 item 3
                except Exception:  # noqa: BLE001
                    pass
            await asyncio.sleep(60)
            _cluster = get_userbot_cluster()
            if _cluster is None:
                continue
            # --- Filesystem-only scan (fast, no RPC, no SQLite open) ------
            _roots = [
                Path(config.project_root) / "data",
                Path(config.project_root) / "sessions",
                Path(config.project_root) / "accounts",
                _CLUSTER_ACCOUNTS_DIR,
            ]
            _found: set[str] = set()
            for _root in _roots:
                try:
                    if not _root.exists():
                        continue
                    for _sf in sorted(_root.rglob("*.session")):
                        if _sf.name.endswith(("-journal", "-wal", "-shm")):
                            continue
                        try:
                            _rel = _sf.relative_to(_root)
                            if any(p in ("downloads", "frames") for p in _rel.parts):
                                continue
                        except Exception:  # noqa: BLE001
                            pass
                        _found.add(str(_sf.resolve()))
                except Exception:  # noqa: BLE001
                    continue
            if _VC_HOT_RELOAD_KNOWN_PATHS is None:
                # Baseline snapshot at boot — no import (startup already ran
                # import_existing_sessions).
                _VC_HOT_RELOAD_KNOWN_PATHS = _found
                continue
            _new_paths = _found - _VC_HOT_RELOAD_KNOWN_PATHS
            if not _new_paths:
                # Also pick up removals silently (baseline refresh).
                _VC_HOT_RELOAD_KNOWN_PATHS = _found
                continue
            logger.info(
                "SESSION_HOT_RELOAD_DETECTED new_files=%d total=%d paths=%s "
                "(v98.07 FIX-UU)",
                len(_new_paths), len(_found),
                ";".join(sorted(_new_paths))[:200],
            )
            # New session file(s) — run the REAL import (bounded; RPC only
            # for the genuinely new files — path-dedup skips the existing
            # ones without opening SQLite).
            try:
                from .voicechat import vc_is_global_floodwait_active  # lazy (cycle-safe)
                if vc_is_global_floodwait_active():
                    logger.info(
                        "SESSION_HOT_RELOAD_DEFERRED reason=global_floodwait — "
                        "retrying next cycle (v98.07 FIX-UU)")
                    continue
            except Exception:  # noqa: BLE001
                pass
            if not mtproto_is_started():
                continue
            try:
                _report = await asyncio.wait_for(
                    _cluster.import_existing_sessions(), timeout=180.0)
            except asyncio.TimeoutError:
                logger.warning(
                    "SESSION_HOT_IMPORT_TIMEOUT — import exceeded 180s bound; "
                    "retrying next cycle (v98.07 FIX-UU)")
                continue
            _VC_HOT_RELOAD_KNOWN_PATHS = _found
            logger.info(
                "SESSION_HOT_IMPORT added=%d duplicate=%d skipped=%d "
                "failed=%d reused_legacy=%d scanned=%d (v98.07 FIX-UU)",
                int(_report.get("imported", 0)),
                int(_report.get("duplicate", 0)),
                int(_report.get("skipped", 0)),
                int(_report.get("failed", 0)),
                int(_report.get("reused_legacy", 0)),
                int(_report.get("scanned", 0)),
            )
            # v98.08 FIX-ZZ: a hot-imported session introduces NEW client
            # scopes — wipe the VC entity negative cache so the fresh
            # account's scopes start clean (bounded, never an exclusion).
            if int(_report.get("imported", 0)) > 0:
                try:
                    from .vc_hooks import vc_notify_session_import as _v808_notify
                    _v808_notify(", ".join(_found[:3]), int(_report.get("imported", 0)))
                except Exception:  # noqa: BLE001
                    pass
        except asyncio.CancelledError:
            logger.info("SESSION_HOT_RELOAD_LOOP cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("SESSION_HOT_RELOAD_LOOP error: %s", exc)
            await asyncio.sleep(10)


def _vc_session_hot_reload_start() -> None:
    """v98.07 FIX-UU: (re)start the session hot-reload task (supervised)."""
    global _vc_session_hot_reload_task
    try:
        _vc_session_hot_reload_task = supervised_create_task(
            _vc_session_hot_reload_loop(), name="vc_session_hot_reload")
    except RuntimeError:
        pass


# --- In-bot account login flow ---

async def cluster_start_login(admin_id: int, phone: str) -> str:
    """Start the OTP login flow for a new account.

    Creates a temporary TelegramClient, sends a login code to the phone,
    and stores the pending login state.
    """
    try:
        from telethon import TelegramClient
        # Normalize phone.
        phone = phone.strip()
        if not phone.startswith("+"):
            phone = "+" + phone.lstrip("+")

        # SEC-D-007: Rate-limit per (admin, phone) — 60s cooldown.
        key = (admin_id, phone)
        now = time.monotonic()
        last = _cluster_login_cooldowns.get(key, 0)
        if now - last < 60:
            remaining = int(60 - (now - last))
            logger.warning("ACCOUNT_LOGIN_RATE_LIMITED admin=%s phone=%s "
                           "remaining=%ss", admin_id, phone, remaining)
            return f"rate_limited:{remaining}s"
        _cluster_login_cooldowns[key] = now

        # TLG-D-009: Evict stale pending-logins (>300s) before creating a
        # new one so abandoned clients don't leak.
        for stale_aid, p in list(_cluster_pending_logins.items()):
            if now - p.get("started_at", 0) > 300:
                stale_client = p.get("client")
                if stale_client is not None:
                    try:
                        await stale_client.disconnect()
                    except Exception:
                        pass
                _cluster_pending_logins.pop(stale_aid, None)

        # SEC-D-003: If this admin already has a pending login, cancel it
        # before overwriting (avoids leaking the old client + SQLite lock).
        existing = _cluster_pending_logins.get(admin_id)
        if existing and existing.get("client"):
            try:
                await existing["client"].disconnect()
            except Exception:
                pass

        session_name = f"cluster_{phone.replace('+', '')}"
        # V67.1 Fix: Telethon auto-appends '.session' to the filename.
        # We pass the path WITHOUT .session to TelegramClient, but store
        # the path WITH .session in the registry so file existence checks work.
        # v97.5 FIX: ensure the sessions directory exists BEFORE creating
        # the TelegramClient.  Previously, if the directory was deleted
        # after UserbotCluster.__init__ (e.g. by a cleanup script), the
        # TelegramClient constructor would fail with SQLite
        # "unable to open database file" because the parent directory
        # didn't exist.
        _CLUSTER_ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(_CLUSTER_ACCOUNTS_DIR, 0o700)
        except OSError:
            pass
        session_base = str(_CLUSTER_ACCOUNTS_DIR / session_name)
        session_file_on_disk = session_base + ".session"
        # v97.7 CRITICAL FIX (PART 17 — NO SESSION DELETION):
        # The v97.5 code DELETED the session file when no live owner existed,
        # assuming it was "blacklisted/invalidated".  This was WRONG: a
        # session ownership conflict is NOT evidence that the Telegram
        # session is invalid.  Deleting a valid session forces OTP re-login
        # and can invalidate the Telegram auth key (AuthKeyDuplicatedError
        # if the old key is still live on Telegram's side).
        #
        # v97.7: NEVER delete cluster_*.session files.  Instead:
        #   - If a LIVE authorized owner exists → return "already_connected"
        #     (handled by the _is_session_live_authorized check below).
        #   - If the session file exists but no live owner → attempt to
        #     REUSE it.  Telethon's connect() + is_user_authorized() will
        #     validate the session.  If it's genuinely invalid, Telethon
        #     raises AuthKeyUnregisteredError / AuthKeyDuplicatedError,
        #     which is handled by the except block (returns error:...).
        #     The user can then explicitly delete the session if they
        #     confirm it's invalid.
        #   - The only sidecar files cleaned up are -journal/-wal/-shm
        #     (SQLite WAL artifacts) which are safe to remove and are
        #     regenerated by Telethon on connect.
        if os.path.exists(session_file_on_disk):
            # Remove SQLite WAL/SHM sidecar files (safe — regenerated on
            # connect).  These are NOT the session file itself.
            for _suffix in ("-wal", "-shm"):
                _sidecar = session_file_on_disk + _suffix
                if os.path.exists(_sidecar):
                    try:
                        os.unlink(_sidecar)
                    except OSError:
                        pass
            # Check if there's a live client using this session.
            _existing_owner = _get_session_owner(session_base)
            _owner_live = False
            if _existing_owner is not None:
                try:
                    _owner_live = _existing_owner.is_connected()
                except Exception:
                    _owner_live = False
            if _owner_live:
                logger.info(
                    "ACCOUNT_LOGIN_SESSION_REUSE phone=%s path=%s "
                    "reason=live_owner_exists — reusing existing session",
                    phone, session_file_on_disk,
                )
            else:
                logger.info(
                    "ACCOUNT_LOGIN_SESSION_FILE_EXISTS phone=%s path=%s "
                    "reason=no_live_owner — will attempt reuse (NOT deleting; "
                    "Telethon will validate authorization on connect)",
                    phone, session_file_on_disk,
                )
        # V67.4 Part 2: Log EXPECTED vs ACTUAL session path for diagnostics.
        logger.info("EXPECTED_SESSION_PATH admin=%s phone=%s path=%s",
                    admin_id, phone, session_file_on_disk)
        # v97.7 LIVE-OWNER DETECTION: if a LIVE, AUTHORIZED client already
        # owns this session, the account is ALREADY connected.  Return
        # "already_connected" instead of creating a duplicate client (which
        # would trigger SESSION_OWNERSHIP_CONFLICT and fail with
        # session_owned_by_another).  This handles the production case where
        # the user selects "Add Account" for a phone that's already
        # connected (e.g. account B, id=535406959888, connected=True).
        if os.path.exists(session_file_on_disk):
            if await _is_session_live_authorized(session_base):
                logger.info(
                    "ACCOUNT_LOGIN_ALREADY_CONNECTED admin=%s phone=%s "
                    "path=%s — live authorized owner exists, not creating "
                    "a duplicate client",
                    admin_id, phone, session_file_on_disk,
                )
                # Try to get the me() for a complete response.
                _live_owner = _get_live_session_owner(session_base)
                _me_id = 0
                _me_username = ""
                if _live_owner is not None:
                    try:
                        _me = await asyncio.wait_for(_live_owner.get_me(), timeout=10)
                        _me_id = getattr(_me, "id", 0) or 0
                        _me_username = getattr(_me, "username", "") or ""
                    except Exception:  # noqa: BLE001
                        pass
                # ---------------------------------------------------------
                # v99.04 RC-16 (RUNTIME-PROVEN via the 2026-09-11
                # production log 03:04:20 + 06:26:31): the operator tried
                # /cluster add +918335829278 (the global primary
                # @Gradieer's phone) TWICE; both times this branch returned
                # already_connected WITHOUT registering the account
                # (USERBOT_CLUSTER stayed at 1) — a dead end that led the
                # operator to DELETE the session file (Run 4:
                # total_files=1, the account gone entirely).  The system
                # ALREADY supports a registered cluster account whose
                # client is the live owner (ACCOUNT_CONNECT_REUSING_REGISTRY
                # does exactly this at startup for acc_919006065076 in
                # Run 4), so registering here creates the SAME supported
                # state — the operator's "add my second account" flow now
                # WORKS instead of dead-ending.
                # ---------------------------------------------------------
                _v9904_phone_digits = phone.lstrip("+")
                _v9904_aid = ""
                try:
                    _v9904_cluster = get_userbot_cluster()
                    for _aid, _acc in (_v9904_cluster._accounts or {}).items():
                        if str(_aid).startswith("__") or not isinstance(_acc, dict):
                            continue
                        if str(_acc.get("phone", "") or "").lstrip("+") \
                                == _v9904_phone_digits:
                            _v9904_aid = str(_aid)
                            break
                except Exception:  # noqa: BLE001
                    _v9904_aid = ""
                if not _v9904_aid and _v9904_phone_digits:
                    try:
                        _v9904_cluster = get_userbot_cluster()
                        _v9904_aid = _v9904_cluster.add_account(
                            phone, session_file_on_disk,
                            role=ROLE_BACKUP,
                            username=_me_username, user_id=_me_id)
                        _v9904_cluster._accounts[_v9904_aid]["imported"] = True
                        _v9904_cluster._accounts[_v9904_aid]["status"] = \
                            STATUS_HEALTHY
                        if _live_owner is not None:
                            _v9904_cluster._clients[_v9904_aid] = _live_owner
                        _v9904_cluster._save()
                        _register_session_status(
                            os.path.basename(session_file_on_disk), "imported",
                            username=_me_username, user_id=_me_id,
                            account_id=_v9904_aid)
                        logger.info(
                            "ACCOUNT_REGISTERED account_id=%s phone=%s "
                            "source=login_live_owner_reuse username=@%s — "
                            "the phone's session was ALREADY live-authorized; "
                            "registered as a cluster account REUSING the "
                            "live client (v99.04 RC-16)",
                            _v9904_aid, phone, _me_username or "(none)")
                        return f"registered:{_v9904_aid}"
                    except Exception as _v9904_reg_exc:  # noqa: BLE001
                        logger.warning(
                            "ACCOUNT_LOGIN_REGISTER_FAILED phone=%s exc=%s: "
                            "%s — falling back to the already_connected "
                            "reply (v99.04 RC-16)",
                            phone, type(_v9904_reg_exc).__name__,
                            str(_v9904_reg_exc)[:120])
                return f"already_connected:{_me_username or _me_id}"
        client = TelegramClient(
            session_base,
            config.tg_api_id,
            config.tg_api_hash,
            connection_retries=3,
            retry_delay=2,
            # v97.28: disable auto_reconnect — see connect_account (line 1222)
            # and mtproto_start (line 3420) for the full v97.26 rationale.
            # Telethon's internal auto_reconnect bypasses the bot's lock +
            # cooldown + drain discipline and spawns duplicate task sets.
            auto_reconnect=False,
        )
        # v97.6 FIX: claim session ownership BEFORE connecting.  Previously,
        # cluster_start_login created a TelegramClient + connected WITHOUT
        # calling _claim_session.  This bypassed the ownership registry,
        # so import_existing_sessions / connect_account / mtproto_start
        # couldn't detect this client via _get_session_owner — leading to
        # duplicate clients on the same session file (SQLite lock +
        # wrong-session-ID).
        # v97.7: _claim_session now evicts STALE (disconnected) owners
        # atomically, so a stale temp client no longer blocks login.
        if not await _claim_session(session_base, client):
            # This branch is now ONLY reachable if a LIVE owner claimed the
            # session between the _is_session_live_authorized check above
            # and here (a race).  In that case, the account is already
            # connected — return already_connected instead of error.
            logger.warning(
                "ACCOUNT_LOGIN_RACE_DETECTED admin=%s phone=%s path=%s — "
                "a live owner claimed the session during login; returning "
                "already_connected",
                admin_id, phone, session_base,
            )
            try:
                await client.disconnect()
            except Exception:  # noqa: BLE001
                pass
            return "already_connected:race"
        await client.connect()
        result = await client.send_code_request(phone)
        logger.info("ACCOUNT_OTP_SENT admin=%s phone=%s", admin_id, phone)
        _cluster_pending_logins[admin_id] = {
            "phone": phone,
            "session_base": session_base,
            "session_file": session_file_on_disk,
            "client": client,
            "phone_code_hash": result.phone_code_hash,
            "started_at": time.monotonic(),
            "step": "await_otp",
        }
        logger.info("ACCOUNT_LOGIN_START admin=%s phone=%s — OTP sent",
                    admin_id, phone)
        return "code_sent"
    except Exception as exc:
        logger.error("ACCOUNT_LOGIN_START_FAILED admin=%s phone=%s exc=%s: %s",
                     admin_id, phone, type(exc).__name__, str(exc)[:120])
        # v97.6 FIX: disconnect the client + release ownership on error.
        # Previously, the except block just returned the error string WITHOUT
        # disconnecting the client — leaking a connected TelegramClient that
        # held the SQLite write lock on the session file.  This blocked all
        # future login/connect attempts on the same session.
        try:
            if 'client' in dir() and client is not None:
                await client.disconnect()
        except Exception:  # noqa: BLE001
            pass
        try:
            if 'session_base' in dir():
                await _release_session(session_base)
        except Exception:  # noqa: BLE001
            pass
        return f"error:{exc}"


async def _verify_and_register_login(admin_id: int, pending: dict[str, Any],
                                     via_2fa: bool = False) -> str:
    """V67.4 Part 1+3: Verify the session was actually created on disk before
    registering the account. Aborts registration if the session is missing or
    empty — never registers broken accounts.

    Returns:
      - 'success:<account_id>' on success
      - 'error:<reason>' on failure (session missing / empty / unauthorized)
    """
    client = pending["client"]
    phone = pending["phone"]
    session_file = pending["session_file"]
    tag = "2FA" if via_2fa else "OTP"
    try:
        # PART 1: Verify authorization + get_me() succeeds.
        if not await client.is_user_authorized():
            logger.error("ACCOUNT_LOGIN_FAILED admin=%s phone=%s reason=not_authorized (%s)",
                         admin_id, phone, tag)
            try:
                await client.disconnect()
            except Exception:
                pass
            return "error:not_authorized"
        me = await client.get_me()
        username = getattr(me, "username", "") or ""
        user_id = getattr(me, "id", 0) or 0
        logger.info("ACCOUNT_LOGIN_SUCCESS admin=%s phone=%s username=@%s "
                    "user_id=%s via=%s",
                    admin_id, phone, username or "(none)", user_id, tag)

        # PART 1: Verify session exists on disk + size > 0.
        # Telethon writes the session file on first authenticated request.
        # Force a save by calling client.session.save() if available.
        try:
            sess = getattr(client, "session", None)
            if sess is not None and hasattr(sess, "save"):
                sess.save()
        except Exception as exc:
            logger.warning("ACCOUNT_SESSION_SAVE_CALL_FAILED phone=%s exc=%s",
                           phone, exc)
        # Check both the expected path and the path with .session appended.
        sf_path = Path(session_file)
        if not sf_path.exists():
            sf_path = Path(str(session_file) + ".session")
        logger.info("ACCOUNT_SESSION_PATH phone=%s expected=%s actual=%s",
                    phone, session_file, str(sf_path))
        if not sf_path.exists():
            logger.error("ACCOUNT_SESSION_MISSING phone=%s path=%s — aborting registration",
                         phone, session_file)
            try:
                await client.disconnect()
            except Exception:
                pass
            return "error:session_missing"
        try:
            size = sf_path.stat().st_size
        except Exception as exc:
            logger.error("ACCOUNT_SESSION_STAT_FAILED phone=%s path=%s exc=%s",
                         phone, sf_path, exc)
            try:
                await client.disconnect()
            except Exception:
                pass
            return "error:session_invalid"
        logger.info("ACCOUNT_SESSION_EXISTS phone=%s path=%s size=%d",
                    phone, sf_path, size)
        if size == 0:
            logger.error("ACCOUNT_SESSION_EMPTY phone=%s path=%s — aborting registration",
                         phone, sf_path)
            try:
                await client.disconnect()
            except Exception:
                pass
            return "error:session_empty"
        logger.info("ACCOUNT_SESSION_SIZE phone=%s size=%d", phone, size)

        # PART 3: All checks passed — safe to register.
        # Disconnect the temp client; connect_account() will create a fresh one.
        try:
            await client.disconnect()
        except Exception:
            pass
        logger.info("ACCOUNT_SESSION_SAVED phone=%s file=%s (%s)",
                    phone, str(sf_path), tag)

        cluster = get_userbot_cluster()
        account_id = cluster.add_account(
            phone, str(sf_path), role=ROLE_BACKUP,
            username=username, user_id=user_id,
        )
        logger.info("ACCOUNT_REGISTERED account_id=%s phone=%s via=%s",
                    account_id, phone, tag)

        # Auto-connect (this re-opens the session file with a fresh client).
        connect_result = await cluster.connect_account(account_id)
        if connect_result.startswith("connected"):
            logger.info("ACCOUNT_CONNECT_SUCCESS account_id=%s via=%s",
                        account_id, tag)
        else:
            logger.warning("ACCOUNT_CONNECT_FAILED account_id=%s result=%s via=%s",
                           account_id, connect_result, tag)

        _cluster_pending_logins.pop(admin_id, None)
        logger.info("ACCOUNT_ADDED admin=%s phone=%s account_id=%s username=@%s via=%s",
                    admin_id, phone, account_id, username or "(none)", tag)
        return f"success:{account_id}"
    except Exception as exc:
        logger.error("ACCOUNT_LOGIN_FAILED admin=%s phone=%s exc=%s: %s via=%s",
                     admin_id, phone, type(exc).__name__, str(exc)[:120], tag)
        try:
            await client.disconnect()
        except Exception:
            pass
        # v97.9 FIX: release the session ownership so the temp client
        # doesn't remain as a stale owner blocking future login attempts.
        try:
            _sb = pending.get("session_base", "")
            if _sb:
                await _release_session(_sb)
        except Exception:  # noqa: BLE001
            pass
        return f"error:{exc}"


async def cluster_submit_otp(admin_id: int, otp: str) -> str:
    """Submit the OTP code for a pending login."""
    pending = _cluster_pending_logins.get(admin_id)
    if not pending or pending.get("step") != "await_otp":
        return "no_pending_login"
    client = pending["client"]
    phone = pending["phone"]
    phone_code_hash = pending["phone_code_hash"]
    try:
        await client.sign_in(
            phone=phone,
            code=otp,
            phone_code_hash=phone_code_hash,
        )
        # Success — account is now authorized.
        logger.info("ACCOUNT_OTP_VERIFIED admin=%s phone=%s",
                    admin_id, phone)
        # V67.4: Defer to the shared verifier (checks session on disk etc).
        return await _verify_and_register_login(admin_id, pending, via_2fa=False)
    except Exception as exc:
        exc_str = str(exc).lower()
        if "session password" in exc_str or "2fa" in exc_str or "password" in exc_str:
            # 2FA required — move to password step.
            pending["step"] = "await_password"
            pending["otp"] = otp
            logger.info("ACCOUNT_LOGIN_2FA_REQUIRED admin=%s phone=%s",
                        admin_id, phone)
            return "2fa_required"
        logger.error("ACCOUNT_OTP_FAILED admin=%s phone=%s exc=%s: %s",
                     admin_id, phone, type(exc).__name__, str(exc)[:120])
        return f"error:{exc}"


async def cluster_submit_password(admin_id: int, password: str) -> str:
    """Submit the 2FA password for a pending login."""
    pending = _cluster_pending_logins.get(admin_id)
    if not pending or pending.get("step") != "await_password":
        return "no_pending_2fa"
    client = pending["client"]
    phone = pending["phone"]
    try:
        await client.sign_in(password=password)
        logger.info("ACCOUNT_2FA_VERIFIED admin=%s phone=%s",
                    admin_id, phone)
        # V67.4: Defer to the shared verifier.
        return await _verify_and_register_login(admin_id, pending, via_2fa=True)
    except Exception as exc:
        logger.error("ACCOUNT_2FA_FAILED admin=%s phone=%s exc=%s: %s",
                     admin_id, phone, type(exc).__name__, str(exc)[:120])
        return f"error:{exc}"


def cluster_cancel_login(admin_id: int) -> None:
    """Cancel a pending login.

    v97.9 FIX: also release the session ownership for the pending client.
    Previously, the client was disconnected but its session ownership was
    NOT released — leaving a stale owner that could block the next login
    attempt (returning "already_connected:race").
    """
    pending = _cluster_pending_logins.pop(admin_id, None)
    if pending and pending.get("client"):
        _pending_session_base = pending.get("session_base", "")
        try:
            # v97.47 FIX: supervised_create_task (was bare create_task —
            # if disconnect raises ConnectionAbortedError, it became an
            # unhandled Future).
            supervised_create_task(
                pending["client"].disconnect(),
                name="cluster_cancel_login_disconnect",
            )
        except Exception:
            pass
        # v97.9: release the session ownership asynchronously.
        if _pending_session_base:
            async def _release_pending():
                try:
                    await _release_session(_pending_session_base)
                except Exception:  # noqa: BLE001
                    pass
            try:
                # v97.74 P1: use supervised_create_task so exceptions raised by
                # _release_pending are logged via the done-callback instead of
                # being silently lost (bare loop.create_task prints "Task
                # exception was never retrieved" to stderr and loses the error).
                supervised_create_task(
                    _release_pending(),
                    name="cluster_cancel_login_release_session",
                )
            except Exception:  # noqa: BLE001
                pass
    logger.info("ACCOUNT_LOGIN_CANCELLED admin=%s", admin_id)


# --- Admin UI ---

def cluster_menu_kb() -> "InlineKeyboardMarkup":
    """V77: Userbot Manager menu keyboard — includes VC distribution, capacity
    test, and session survival test buttons."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add Account", callback_data="cluster:add"),
         InlineKeyboardButton("📥 Import Sessions", callback_data="cluster:import")],
        [InlineKeyboardButton("📋 List Accounts", callback_data="cluster:list"),
         InlineKeyboardButton("📊 Cluster Status", callback_data="cluster:stats")],
        [InlineKeyboardButton("🩺 Health Check", callback_data="cluster:health"),
         InlineKeyboardButton("🔄 Rotate Primary", callback_data="cluster:rotate")],
        [InlineKeyboardButton("🎯 Active Accounts", callback_data="cluster:active"),
         InlineKeyboardButton("🧪 Test Routing", callback_data="cluster:test")],
        [InlineKeyboardButton("📊 VC Distribution", callback_data="cluster:vc_distribution"),
         InlineKeyboardButton("🧪 VC Capacity Test", callback_data="cluster:capacity_test")],
        [InlineKeyboardButton("🧪 Session Survival Test", callback_data="cluster:session_test"),
         InlineKeyboardButton("🔍 Account Details", callback_data="cluster:details")],
        [InlineKeyboardButton("❌ Remove Account", callback_data="cluster:remove"),
         InlineKeyboardButton("⬅ Back to Admin", callback_data="m:admin")],
    ])


# ===========================================================================
# V67.2: UserbotClusterRouter — role-based client selection + failover
# ===========================================================================


class UserbotClusterRouter:
    """V67.4: Routes MTProto operations to the best available cluster account.

    Selection rules (in order):
      1. If a persisted primary is set AND healthy AND matches the requested
         role (or the role is PRIMARY), use it.
      2. Try connected accounts with the exact requested role.
      3. Fall back to the persisted PRIMARY account (if healthy).
      4. Fall back to any connected account with the PRIMARY role.
      5. Fall back to any healthy account.
      6. Fall back to the legacy single-client (mtproto_get_client()) —
         maintains backward compatibility.

    Automatic failover:
      When an MTProto operation fails (FloodWait, auth error, etc.), the
      router marks the account unhealthy and retries with the next available
      account. Logs ACCOUNT_FAILOVER with old + new account ids.
    """

    def __init__(self, cluster: UserbotCluster):
        self._cluster = cluster

    def _record_active(self, role: str, account_id: str | None) -> None:
        """V67.4: Track which account the router last picked for each role.
        Used by the Active Account View panel.
        """
        if account_id:
            _active_routing[role] = account_id
        else:
            _active_routing.pop(role, None)

    def get_active_routing(self) -> dict[str, str]:
        """V72: Return a snapshot of role → account_id currently routed.

        V72 PART 2 FIX: If _active_routing is empty (e.g. right after startup,
        before any MTProto operation has triggered get_client_for_role),
        EAGERLY populate it by calling get_client_for_role for each role.
        This ensures the Active Accounts panel always shows real data instead
        of "(none)" when accounts exist but haven't been used yet.
        """
        if not _active_routing:
            self.populate_active_routing()
        return dict(_active_routing)

    def populate_active_routing(self) -> None:
        """V72 PART 2: Eagerly populate _active_routing for all roles.

        Called by get_active_routing() when the cache is empty, and by the
        Active Accounts panel before rendering. This ensures the panel shows
        real account IDs even before any MTProto operation has run.
        """
        for role in (ROLE_PRIMARY, ROLE_DOWNLOADER, ROLE_DISCOVERY,
                     ROLE_VOICE_CHAT, ROLE_BACKUP):
            # get_client_for_role calls _record_active internally.
            self.get_client_for_role(role)

    def get_client_for_role(self, role: str) -> Any | None:
        """Get the best available TelegramClient for a specific role.

        Returns None if no cluster account is available (caller should
        fall back to mtproto_get_client()).
        """
        # 1. Persisted primary shortcut (only for PRIMARY role, or when the
        #    persisted primary happens to have the requested role).
        primary_id = self._cluster.get_primary_id()
        if primary_id:
            acc = self._cluster.get_account(primary_id)
            if acc and not acc.get("disabled"):
                st = acc.get("status")
                if st in (STATUS_HEALTHY, STATUS_CONNECTED):
                    # Use primary if role matches OR role is PRIMARY OR no
                    # role-specific account exists (we'll check role-specific
                    # first for non-PRIMARY roles below).
                    if role == ROLE_PRIMARY or acc.get("role") == role:
                        client = self._cluster.get_client(primary_id)
                        if client is not None:
                            self._record_active(role, primary_id)
                            logger.debug(
                                "CLUSTER_ROUTER role=%s → persisted primary account=%s",
                                role, primary_id)
                            return client

        # 2. Try connected accounts with the exact role.
        healthy = self._cluster.get_healthy_accounts(role=role)
        if healthy:
            # Sort by created_at for deterministic selection.
            healthy.sort(key=lambda a: float(a.get("created_at", 0)))
            acc = healthy[0]
            client = self._cluster.get_client(acc["account_id"])
            if client is not None:
                self._record_active(role, acc["account_id"])
                logger.debug("CLUSTER_ROUTER role=%s → role-match account=%s",
                             role, acc["account_id"])
                return client

        # 3. Fall back to persisted PRIMARY (already checked healthy above).
        if role != ROLE_PRIMARY and primary_id:
            acc = self._cluster.get_account(primary_id)
            if acc and not acc.get("disabled") \
                    and acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED):
                client = self._cluster.get_client(primary_id)
                if client is not None:
                    self._record_active(role, primary_id)
                    logger.debug(
                        "CLUSTER_ROUTER role=%s → fallback persisted primary account=%s",
                        role, primary_id)
                    return client

        # 4. Fall back to any account with the PRIMARY role.
        if role != ROLE_PRIMARY:
            healthy = self._cluster.get_healthy_accounts(role=ROLE_PRIMARY)
            if healthy:
                healthy.sort(key=lambda a: float(a.get("created_at", 0)))
                acc = healthy[0]
                client = self._cluster.get_client(acc["account_id"])
                if client is not None:
                    self._record_active(role, acc["account_id"])
                    logger.debug(
                        "CLUSTER_ROUTER role=%s → fallback PRIMARY role account=%s",
                        role, acc["account_id"])
                    return client

        # 5. Fall back to any healthy account.
        healthy = self._cluster.get_healthy_accounts()
        if healthy:
            healthy.sort(key=lambda a: float(a.get("created_at", 0)))
            acc = healthy[0]
            client = self._cluster.get_client(acc["account_id"])
            if client is not None:
                self._record_active(role, acc["account_id"])
                logger.debug(
                    "CLUSTER_ROUTER role=%s → fallback any account=%s",
                    role, acc["account_id"])
                return client

        # 6. Fall back to legacy single client.
        self._record_active(role, None)
        logger.debug("CLUSTER_ROUTER role=%s → legacy mtproto_get_client()", role)
        return mtproto_get_client_legacy()

    def get_client_for_role_with_id(self, role: str) -> tuple[str | None, Any | None]:
        """v97.31: like get_client_for_role but returns (account_id, client).

        Needed so the caller can construct the correct per-cluster-client RW
        lock. Returns (None, None) if no cluster account is available (caller
        should fall back to the global client).
        """
        # 1. Persisted primary shortcut.
        primary_id = self._cluster.get_primary_id()
        if primary_id:
            acc = self._cluster.get_account(primary_id)
            if acc and not acc.get("disabled") and acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED):
                if role == ROLE_PRIMARY or acc.get("role") == role:
                    client = self._cluster.get_client(primary_id)
                    if client is not None:
                        self._record_active(role, primary_id)
                        return (primary_id, client)
        # 2. Role-specific healthy accounts.
        healthy = self._cluster.get_healthy_accounts(role=role)
        if healthy:
            healthy.sort(key=lambda a: float(a.get("created_at", 0)))
            acc = healthy[0]
            client = self._cluster.get_client(acc["account_id"])
            if client is not None:
                self._record_active(role, acc["account_id"])
                return (acc["account_id"], client)
        # 3-5. Fallbacks to primary / any healthy account.
        if role != ROLE_PRIMARY:
            if primary_id:
                acc = self._cluster.get_account(primary_id)
                if acc and not acc.get("disabled") and acc.get("status") in (STATUS_HEALTHY, STATUS_CONNECTED):
                    client = self._cluster.get_client(primary_id)
                    if client is not None:
                        self._record_active(role, primary_id)
                        return (primary_id, client)
            healthy = self._cluster.get_healthy_accounts(role=ROLE_PRIMARY)
            if healthy:
                healthy.sort(key=lambda a: float(a.get("created_at", 0)))
                acc = healthy[0]
                client = self._cluster.get_client(acc["account_id"])
                if client is not None:
                    self._record_active(role, acc["account_id"])
                    return (acc["account_id"], client)
        healthy = self._cluster.get_healthy_accounts()
        if healthy:
            healthy.sort(key=lambda a: float(a.get("created_at", 0)))
            acc = healthy[0]
            client = self._cluster.get_client(acc["account_id"])
            if client is not None:
                self._record_active(role, acc["account_id"])
                return (acc["account_id"], client)
        # 6. No cluster account available.
        return (None, None)

    def get_primary_client(self) -> Any | None:
        """Get the primary client (for default MTProto actions)."""
        return self.get_client_for_role(ROLE_PRIMARY)

    def get_backup_client(self) -> Any | None:
        """Get a backup client (for failover)."""
        return self.get_client_for_role(ROLE_BACKUP)

    def get_discovery_client(self) -> Any | None:
        """Get a discovery client (for scans, inspections)."""
        return self.get_client_for_role(ROLE_DISCOVERY)

    def get_downloader_client(self) -> Any | None:
        """Get a downloader client (for media fetch, profile photos)."""
        return self.get_client_for_role(ROLE_DOWNLOADER)

    def get_voice_client(self) -> Any | None:
        """Get a voice chat client (for VC joins)."""
        return self.get_client_for_role(ROLE_VOICE_CHAT)

    async def mark_failure(self, account_id: str, error: str) -> str:
        """Mark an account as failed after an MTProto error.

        V68.2: Returns a short failover_reason string ('floodwait',
        'unauthorized', 'banned', 'connection_failed', 'session_revoked',
        'generic') so execute_with_failover can include it in the
        ACCOUNT_FAILOVER log line.

        Updates the account status based on the error type:
        - FloodWait → floodwait status + floodwait_until
        - Auth/Session → unauthorized status
        - Connection → connection_failed status
        - Banned → banned status
        """
        err_lower = error.lower()
        acc = self._cluster.get_account(account_id)
        if not acc:
            return "unknown_account"

        fail_count = int(acc.get("fail_count", 0)) + 1
        acc["fail_count"] = fail_count
        acc["last_error"] = error[:200]
        reason = "generic"

        if "flood" in err_lower:
            # Extract wait time if possible.
            import re as _re
            m = _re.search(r"(\d+)\s*second", err_lower)
            wait = int(m.group(1)) if m else 60
            self._cluster.update_status(account_id, STATUS_FLOODWAIT,
                                         floodwait_until=time.time() + wait)
            logger.warning("ACCOUNT_FAILOVER account=%s reason=floodwait wait=%ds",
                           account_id, wait)
            reason = "floodwait"
        elif "unauthorized" in err_lower or "auth" in err_lower \
                or "session revoked" in err_lower or "authkeyunregistered" in err_lower:
            self._cluster.update_status(account_id, STATUS_UNAUTHORIZED)
            logger.warning("ACCOUNT_FAILOVER account=%s reason=unauthorized",
                           account_id)
            reason = "unauthorized"
        elif "banned" in err_lower:
            self._cluster.update_status(account_id, STATUS_BANNED)
            logger.warning("ACCOUNT_FAILOVER account=%s reason=banned", account_id)
            reason = "banned"
        elif "connection" in err_lower or "timeout" in err_lower \
                or "disconnect" in err_lower:
            self._cluster.update_status(account_id, STATUS_CONNECTION_FAILED)
            logger.warning("ACCOUNT_FAILOVER account=%s reason=connection_failed",
                           account_id)
            reason = "connection_failed"
        else:
            # Generic failure — disconnect if too many failures.
            if fail_count >= 5:
                await self._cluster.disconnect_account(account_id)
                logger.warning("ACCOUNT_FAILOVER account=%s reason=disconnected "
                               "fail_count=%d", account_id, fail_count)
                reason = "disconnected"
            else:
                self._cluster._save()
                reason = "generic"
        return reason

    async def mark_success(self, account_id: str) -> None:
        """Mark a successful operation for an account."""
        acc = self._cluster.get_account(account_id)
        if acc:
            acc["success_count"] = int(acc.get("success_count", 0)) + 1
            acc["last_success"] = time.time()
            acc["last_seen"] = time.time()
            self._cluster._save()

    async def execute_with_failover(
        self,
        operation: Callable,
        role: str,
        *args,
        **kwargs,
    ) -> Any:
        """Execute an MTProto operation with automatic failover.

        V68.2: Logs ACCOUNT_FAILOVER with OLD_ACCOUNT, NEW_ACCOUNT, and
        FAILOVER_REASON on every account switch.

        Tries the best available account for the role. If it fails with
        FloodWait/auth/connection error, marks the account unhealthy and
        retries with the next available account.

        Args:
            operation: An async callable that takes a client as the first arg.
            role: The role to route to (e.g. ROLE_DOWNLOADER).
            *args, **kwargs: Additional arguments for the operation.

        Returns:
            The result of the operation.

        Raises:
            The last exception if all accounts fail.
        """
        last_exc: Exception | None = None
        tried_accounts: set[str] = set()
        last_account_id: str | None = None
        last_reason: str = ""
        # TLG-D-013: the legacy client (account_id is None) has no failover
        # partner — only allow ONE attempt against it per call to avoid an
        # infinite loop when it keeps returning the same recoverable error.
        tried_legacy = False

        for attempt in range(5):  # V67.4: bumped from 3 → 5 attempts
            client = self.get_client_for_role(role)
            if client is None:
                if last_exc:
                    raise last_exc
                raise RuntimeError("No MTProto client available (cluster + legacy)")

            # Find which account this client belongs to.
            account_id = None
            for aid, cl in self._cluster._clients.items():
                if cl is client:
                    account_id = aid
                    break

            if account_id is None:
                # Legacy client — only one shot.
                if tried_legacy:
                    break
                tried_legacy = True
            elif account_id in tried_accounts:
                # Already tried this account — skip.
                continue
            else:
                tried_accounts.add(account_id)

            # V68.2: Log failover with old + new account ids + reason.
            if last_account_id is not None and account_id != last_account_id:
                logger.warning(
                    "ACCOUNT_FAILOVER role=%s old_account=%s new_account=%s "
                    "failover_reason=%s",
                    role, last_account_id, account_id or "legacy", last_reason)
            last_account_id = account_id

            try:
                result = await operation(client, *args, **kwargs)
                if account_id:
                    await self.mark_success(account_id)
                return result
            except Exception as exc:
                last_exc = exc
                err_str = str(exc).lower()
                logger.warning("CLUSTER_OPERATION_FAILED role=%s account=%s exc=%s: %s",
                               role, account_id or "legacy",
                               type(exc).__name__, str(exc)[:120])
                # Check if this is a recoverable error (FloodWait, auth, connection).
                is_recoverable = any(kw in err_str for kw in [
                    "flood", "unauthorized", "auth", "session",
                    "connection", "timeout", "disconnect",
                ])
                if account_id and is_recoverable:
                    last_reason = await self.mark_failure(account_id, str(exc))
                    # Retry with next account.
                    continue
                else:
                    # Non-recoverable error — re-raise.
                    raise

        # All attempts exhausted.
        if last_exc:
            raise last_exc
        raise RuntimeError("All cluster accounts exhausted")


# Global router instance.
_cluster_router: UserbotClusterRouter | None = None


def get_cluster_router() -> UserbotClusterRouter:
    """Get the global UserbotClusterRouter instance (lazy init)."""
    global _cluster_router
    if _cluster_router is None:
        _cluster_router = UserbotClusterRouter(get_userbot_cluster())
    return _cluster_router


def get_routed_client(role: str = ROLE_PRIMARY) -> Any | None:
    """V67.2: Get a routed MTProto client for a role.

    This is the primary entry point for code that wants to use the cluster
    router instead of the legacy mtproto_get_client().

    Falls back to mtproto_get_client() if no cluster accounts are connected.
    """
    return get_cluster_router().get_client_for_role(role)


# ===========================================================================
# V67.2: VoiceChatAccountPool — per-account VC state
# ===========================================================================

_vc_account_pool: dict[str, dict[str, Any]] = {}
"""Per-account VC state. Keys: account_id. Values:
  chat_id: int — the VC chat ID this account is in (0 = not in a VC)
  call_id: int — the active call ID
  joined_at: float — monotonic timestamp
  role: str — "speaker" | "listener" | "recorder"
"""


class VoiceChatAccountPool:
    """V67.2: Manages per-account VC join state (not global _current_chat_id).

    Each account can join a different VC simultaneously:
      Account A → VC1
      Account B → VC2
      Account C → VC3
    """

    def __init__(self):
        self._states: dict[str, dict[str, Any]] = {}

    def assign(self, account_id: str, chat_id: int, call_id: int,
               role: str = "listener") -> None:
        """Assign an account to a VC."""
        self._states[account_id] = {
            "chat_id": chat_id,
            "call_id": call_id,
            "joined_at": time.monotonic(),
            "role": role,
        }
        logger.info("VC_POOL_ASSIGN account=%s chat=%s call=%s role=%s",
                    account_id, chat_id, call_id, role)
        # V72 PART 18: VC_JOIN log event.
        logger.info("VC_JOIN account=%s chat=%s call=%s role=%s",
                    account_id, chat_id, call_id, role)

    def unassign(self, account_id: str) -> None:
        """Remove an account from its VC."""
        state = self._states.pop(account_id, None)
        if state:
            logger.info("VC_POOL_UNASSIGN account=%s chat=%s",
                        account_id, state.get("chat_id"))
            # V72 PART 18: VC_LEAVE log event.
            logger.info("VC_LEAVE account=%s chat=%s role=%s",
                        account_id, state.get("chat_id"), state.get("role"))

    def get_state(self, account_id: str) -> dict[str, Any] | None:
        """Get the VC state for an account."""
        return self._states.get(account_id)

    def get_accounts_in_vc(self, chat_id: int | None = None) -> list[dict[str, Any]]:
        """Get all accounts currently in a VC, optionally filtered by chat_id."""
        result = []
        for aid, state in self._states.items():
            if chat_id is None or state.get("chat_id") == chat_id:
                result.append(dict(state, account_id=aid))
        return result

    def get_speaker(self, chat_id: int) -> str | None:
        """Get the account_id of the current speaker for a VC."""
        for aid, state in self._states.items():
            if state.get("chat_id") == chat_id and state.get("role") == "speaker":
                return aid
        return None

    def set_speaker(self, account_id: str) -> None:
        """Set an account as the speaker for its current VC."""
        state = self._states.get(account_id)
        if state:
            # Demote any existing speaker for this chat.
            chat_id = state["chat_id"]
            old_speaker = None
            for aid, s in self._states.items():
                if s.get("chat_id") == chat_id and s.get("role") == "speaker":
                    s["role"] = "listener"
                    old_speaker = aid
            state["role"] = "speaker"
            logger.info("VC_POOL_SPEAKER_SWITCH chat=%s → account=%s",
                        chat_id, account_id)
            # V72 PART 10: If this was a speaker failover, log VC_FAILOVER.
            if old_speaker and old_speaker != account_id:
                logger.info("VC_FAILOVER chat=%s old_speaker=%s new_speaker=%s "
                            "reason=speaker_switch",
                            chat_id, old_speaker, account_id)

    def failover_speaker(self, chat_id: int) -> str | None:
        """V76 PART 16: Promote a backup/listener to speaker when the current
        speaker disconnects.

        V76 enhancement: Logs VC_FAILOVER_START / VC_FAILOVER_SUCCESS /
        VC_FAILOVER_FAILED with old + new account.

        Selection order:
          1. Any account in the same VC with role 'backup_speaker'.
          2. Any account in the same VC with role 'listener'.
          3. Any available account (not in any VC).

        Returns the new speaker's account_id, or None if no account is available.
        """
        # V76 PART 16: VC_FAILOVER_START.
        current_speaker = self.get_speaker(chat_id)
        logger.info("VC_FAILOVER_START chat_id=%s old_speaker=%s",
                    chat_id, current_speaker or "(none)")
        # Find candidates in the same VC.
        backup_speakers = []
        listeners = []
        for aid, state in self._states.items():
            if state.get("chat_id") != chat_id:
                continue
            if aid == current_speaker:
                continue
            role = state.get("role", "listener")
            if role == "backup_speaker":
                backup_speakers.append(aid)
            elif role == "listener":
                listeners.append(aid)
        # Selection order.
        new_speaker = None
        if backup_speakers:
            new_speaker = backup_speakers[0]
        elif listeners:
            new_speaker = listeners[0]
        else:
            available = self.get_available_accounts()
            if available:
                new_speaker = available[0]
                self.assign(new_speaker, chat_id, 0, "speaker")
        if new_speaker:
            self.set_speaker(new_speaker)
            logger.info("VC_FAILOVER chat=%s old_speaker=%s new_speaker=%s "
                        "reason=speaker_disconnect",
                        chat_id, current_speaker or "(none)", new_speaker)
            # V76 PART 16: VC_FAILOVER_SUCCESS.
            logger.info("VC_FAILOVER_SUCCESS chat_id=%s old_speaker=%s new_speaker=%s",
                        chat_id, current_speaker or "(none)", new_speaker)
        else:
            logger.warning("VC_FAILOVER chat=%s reason=no_backup_available", chat_id)
            # V76 PART 16: VC_FAILOVER_FAILED.
            logger.error("VC_FAILOVER_FAILED chat_id=%s old_speaker=%s "
                         "reason=no_backup_available",
                         chat_id, current_speaker or "(none)")
        return new_speaker

    def get_available_accounts(self) -> list[str]:
        """Get account IDs that are NOT in any VC."""
        cluster = get_userbot_cluster()
        healthy = cluster.get_healthy_accounts(role=ROLE_VOICE_CHAT)
        if not healthy:
            healthy = cluster.get_healthy_accounts()
        return [acc["account_id"] for acc in healthy
                if acc["account_id"] not in self._states]

    def get_stats(self) -> dict[str, Any]:
        """V72: Get VC pool statistics — includes active speaker, backup speaker,
        VC uptime, and reconnect count."""
        import time as _time
        now = _time.monotonic()
        speakers = [aid for aid, s in self._states.items()
                    if s.get("role") == "speaker"]
        backup_speakers = [aid for aid, s in self._states.items()
                           if s.get("role") == "backup_speaker"]
        listeners = [aid for aid, s in self._states.items()
                     if s.get("role") == "listener"]
        # VC uptime = longest-running assignment.
        max_uptime = 0.0
        for s in self._states.values():
            uptime = now - float(s.get("joined_at", now))
            if uptime > max_uptime:
                max_uptime = uptime
        return {
            "total_assigned": len(self._states),
            "speakers": len(speakers),
            "listeners": len(listeners),
            "backup_speakers": len(backup_speakers),
            "active_speaker": speakers[0] if speakers else None,
            "backup_speaker": backup_speakers[0] if backup_speakers else None,
            "vc_uptime_seconds": int(max_uptime),
            "reconnect_count": int(getattr(self, "_reconnect_count", 0)),
        }


# Global VC pool instance.
_vc_pool: VoiceChatAccountPool | None = None


def get_vc_pool() -> VoiceChatAccountPool:
    """Get the global VoiceChatAccountPool instance."""
    global _vc_pool
    if _vc_pool is None:
        _vc_pool = VoiceChatAccountPool()
    return _vc_pool


def _get_current_vc_account_id() -> str:
    """V76 PART 13-14: Return the account_id currently handling VC operations.

    V76 enhancements:
    - PART 14: Eligibility filter — checks connected, authorized, healthy,
      not floodwait, session valid. Logs ACCOUNT_ELIGIBLE / ACCOUNT_SKIPPED /
      ACCOUNT_UNHEALTHY.
    - PART 13: Least-loaded routing — picks the healthy VOICE_CHAT account
      with the fewest active VCs.
    """
    try:
        cluster = get_userbot_cluster()
        # PART 14: Get all accounts, then filter by eligibility.
        all_accounts = cluster.list_accounts()
        eligible: list[dict[str, Any]] = []
        for acc in all_accounts:
            aid = acc["account_id"]
            if acc.get("disabled"):
                logger.info("ACCOUNT_SKIPPED account_id=%s reason=disabled", aid)
                continue
            status = acc.get("status", "")
            if status not in (STATUS_HEALTHY, STATUS_CONNECTED):
                logger.info("ACCOUNT_UNHEALTHY account_id=%s status=%s", aid, status)
                continue
            fw_until = float(acc.get("floodwait_until", 0) or 0)
            if fw_until and fw_until > time.time():
                logger.info("ACCOUNT_SKIPPED account_id=%s reason=floodwait remaining=%ds",
                            aid, int(fw_until - time.time()))
                continue
            sess = cluster.get_session_info(aid)
            if not sess.get("exists"):
                logger.info("ACCOUNT_UNHEALTHY account_id=%s reason=session_missing", aid)
                continue
            eligible.append(acc)
            logger.info("ACCOUNT_ELIGIBLE account_id=%s role=%s status=%s",
                        aid, acc.get("role", ""), status)

        if not eligible:
            return "(none)"

        # PART 13: Prefer VOICE_CHAT role, then any.
        voice_accounts = [a for a in eligible if a.get("role") == ROLE_VOICE_CHAT]
        candidates = voice_accounts if voice_accounts else eligible
        candidates.sort(key=lambda a: float(a.get("created_at", 0)))

        # Least-loaded routing: pick the account with the fewest active VCs.
        pool = get_vc_pool()
        min_vcs = float("inf")
        best_aid = candidates[0]["account_id"]
        for acc in candidates:
            aid = acc["account_id"]
            in_vc = pool.get_state(aid)
            vc_count = 1 if in_vc else 0
            acc_vc_count = int(acc.get("joined_vcs", 0))
            total = vc_count + acc_vc_count
            if total < min_vcs:
                min_vcs = total
                best_aid = aid
        logger.info("VC_ACCOUNT_SELECTED account_id=%s active_vcs=%d reason=least_loaded",
                    best_aid, min_vcs)
        return best_aid
    except Exception as exc:
        logger.debug("VC_ACCOUNT_SELECTION_FAILED exc=%s: %s",
                     type(exc).__name__, str(exc)[:100])
        return "(none)"


# --- mtproto_manager -------------------------------------------------------

_mtproto_client: Optional[Any] = None  # TelegramClient
_mtproto_started: bool = False
_mtproto_start_time: float = 0.0
# v97.14: global reconnect lock — prevents concurrent connect() calls from
# _mtproto_watchdog_loop + _cluster_reconnect_loop + mtproto_call_with_retry.
# Without this, multiple coroutines could call connect() simultaneously on
# the same client, creating duplicate connection tasks.
_mtproto_reconnect_lock: asyncio.Lock | None = None
_mtproto_last_reconnect_at: float = 0.0
_MTPROTO_RECONNECT_COOLDOWN: float = 30.0  # min seconds between reconnects
_mtproto_health_task: Optional[asyncio.Task] = None
_mtproto_watchdog_task: Optional[asyncio.Task] = None
_mtproto_self_destruct_registered: bool = False
# v97.28: monotonic generation counter — bumped on every _mtproto_safe_reconnect
# invocation. mtproto_start captures the value before its slow candidate loop
# and logs a warning if it changed by the time the loop finishes, surfacing the
# start-vs-reconnect race in production logs without adding lock contention.
_mtproto_generation: int = 0

# v97.29: Reader-writer lock for MTProto client access.
# Readers  = MTProto RPC callers (mtproto_call_with_retry, download path,
#            VC discovery, entity resolution). Multiple readers can hold
#            the lock concurrently — normal operation.
# Writer   = _mtproto_safe_reconnect / mtproto_start. A writer gets EXCLUSIVE
#            access: it waits for all in-flight readers to drain, then blocks
#            new readers until the reconnect/start completes.
#
# This is THE fix for the v97.28-followup issue where workers kept firing
# RPCs into a disconnecting client ("Cannot send requests while disconnected")
# and prevented Telethon's background loops from cleanly cancelling (causing
# duplicate task groups + 8.78s event-loop lag). With the RW lock, reconnect
# first waits for all in-flight RPCs to finish, THEN disconnects — so the
# client is truly quiescent before teardown begins. New RPCs during reconnect
# BLOCK on the read lock (they don't fail), then proceed on the fresh client.
_mtproto_rw_lock: Optional[Any] = None  # _AsyncRWLock, lazily created


class _AsyncRWLock:
    """v97.29: Async reader-writer lock with writer preference.

    Multiple readers can hold the lock simultaneously. A writer gets
    exclusive access (no other readers or writers). Writers are preferred:
    if a writer is waiting, new readers block until the writer acquires and
    releases — this prevents writer starvation and guarantees that a
    reconnect is not delayed indefinitely by a steady stream of readers.

    Implementation uses a single Condition variable. Reader count is tracked
    explicitly; a writer waits until the reader count is zero AND no other
    writer is active. While a writer is waiting or active, new readers block
    on the condition.
    """

    def __init__(self) -> None:
        self._readers: int = 0
        self._writers_waiting: int = 0
        self._writer_active: bool = False
        self._cond: asyncio.Condition = asyncio.Condition()

    async def acquire_read(self, timeout: float | None = None) -> bool:
        """Acquire a read lock. Blocks if a writer is active or waiting.

        v98.08 FIX-WW: optional *timeout* bounds the wait INSIDE the
        condition variable — race-free by construction (the reader count
        is only incremented while holding the condition, so a timed-out
        waiter can never leak a reader slot). Returns True when the read
        lock is held, False on timeout (NOTHING is held — the caller must
        neither release nor proceed as if locked). The v98.07 soak
        (L10759-10777, 12.20s CRITICAL lag, 540 tasks) showed reader
        starvation incubating the F1' wedge; only the 4870 call site was
        bounded in v98.07 — every other acquire_read caller could queue
        forever behind a stuck writer.
        """
        if timeout is None:
            async with self._cond:
                while self._writer_active or self._writers_waiting > 0:
                    await self._cond.wait()
                self._readers += 1
            return True
        # v98.08 FIX-WW: bounded path — deadline-checked condition wait.
        deadline = time.monotonic() + float(timeout)
        async with self._cond:
            while self._writer_active or self._writers_waiting > 0:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                try:
                    await asyncio.wait_for(self._cond.wait(), timeout=remaining)
                except asyncio.TimeoutError:
                    pass  # re-check condition + deadline (still holding _cond)
            self._readers += 1
            return True

    async def release_read(self) -> None:
        """Release a read lock."""
        async with self._cond:
            self._readers -= 1
            if self._readers == 0:
                # Wake a waiting writer (and any waiting readers).
                self._cond.notify_all()

    async def acquire_write(self, timeout: float | None = None) -> None:
        """Acquire the exclusive write lock. Blocks until all readers drain.

        v98.09 ARCH (§17 LOCK ARCHITECTURE): optional *timeout* bounds
        the writer wait — the SAME hazard class v98.08 FIX-WW eliminated
        for readers. Writer-preference already guarantees eventual grant
        (once a writer waits, new readers block until it acquires), so
        the timeout is a guard against a STUCK READER never releasing
        (e.g. a reader holding across a wedged RPC) — a generous default
        (60s at the call sites, > any bounded read critical section)
        makes the healthy path identical to v98.08 while capping the
        worst case. On timeout: raises asyncio.TimeoutError (retryable,
        same contract as the read path) — the caller holds NOTHING.
        """
        deadline = None if timeout is None else time.monotonic() + timeout
        async with self._cond:
            self._writers_waiting += 1
            try:
                while self._readers > 0 or self._writer_active:
                    _v98a_wait = None
                    if deadline is not None:
                        _v98a_wait = max(0.0, deadline - time.monotonic())
                        if _v98a_wait <= 0.0:
                            logger.warning(
                                "VC_RW_ACQUIRE_TIMEOUT scope=write wait=%.1fs "
                                "— writer starved by a stuck reader/writer; "
                                "raising retryable TimeoutError (v98.09 §17; "
                                "read path bounded in v98.08 FIX-WW)",
                                float(timeout or 0.0))
                            raise asyncio.TimeoutError(
                                f"RW write acquire timed out after "
                                f"{timeout}s")
                    try:
                        await asyncio.wait_for(
                            self._cond.wait(), timeout=_v98a_wait)
                    except asyncio.TimeoutError:
                        if deadline is not None and \
                                time.monotonic() >= deadline:
                            logger.warning(
                                "VC_RW_ACQUIRE_TIMEOUT scope=write "
                                "wait=%.1fs — writer starved by a stuck "
                                "reader/writer; raising retryable "
                                "TimeoutError (v98.09 §17; read path "
                                "bounded in v98.08 FIX-WW)",
                                float(timeout or 0.0))
                            raise asyncio.TimeoutError(
                                f"RW write acquire timed out after "
                                f"{timeout}s")
                        # Spurious timeout vs a late notify race: loop
                        # once more (the while-condition is authoritative).
            finally:
                self._writers_waiting -= 1
            self._writer_active = True

    async def release_write(self) -> None:
        """Release the exclusive write lock."""
        async with self._cond:
            self._writer_active = False
            # Wake all waiters — both readers and the next writer.
            self._cond.notify_all()

    # Context managers for ergonomic use.
    # NOTE: __aenter__/__aexit__ are duplicated for read vs write; we expose
    # them as separate helper methods (read_ctx / write_ctx) to keep the
    # intent explicit at call sites.

    class _ReadCtx:
        def __init__(self, lock: "_AsyncRWLock") -> None:
            self._lock = lock
            self._acquired = False

        async def __aenter__(self) -> None:
            # v98.08 FIX-WW: bounded (the ergonomic helper had the same
            # unbounded-forever wait as the wrappers; no live callers today,
            # bounded anyway — one class of hazard eliminated).
            _v808_ok = await self._lock.acquire_read(timeout=20.0)
            if not _v808_ok:
                logger.warning(
                    "VC_RW_ACQUIRE_TIMEOUT scope=read_ctx wait=20.0s — "
                    "read lock starved by a writer; raising retryable "
                    "TimeoutError (v98.08 FIX-WW)")
                raise asyncio.TimeoutError(
                    "RW read-lock (read_ctx) starved > 20s (v98.08 FIX-WW)")
            self._acquired = True

        async def __aexit__(self, *exc: Any) -> None:
            if self._acquired:
                await self._lock.release_read()
                self._acquired = False

    class _WriteCtx:
        def __init__(self, lock: "_AsyncRWLock") -> None:
            self._lock = lock

        async def __aenter__(self) -> None:
            # v98.09 §17: bounded (same treatment as _ReadCtx in v98.08
            # FIX-WW — no live callers today, bounded anyway; 60s > any
            # bounded read critical section).
            await self._lock.acquire_write(timeout=60.0)

        async def __aexit__(self, *exc: Any) -> None:
            await self._lock.release_write()

    def read_ctx(self) -> "_AsyncRWLock._ReadCtx":
        """Context manager: acquire a read lock (shared with other readers)."""
        return self._ReadCtx(self)

    def write_ctx(self) -> "_AsyncRWLock._WriteCtx":
        """Context manager: acquire the exclusive write lock."""
        return self._WriteCtx(self)


def _get_mtproto_rw_lock() -> _AsyncRWLock:
    """v97.29: lazily create the global MTProto reader-writer lock."""
    global _mtproto_rw_lock
    if _mtproto_rw_lock is None:
        _mtproto_rw_lock = _AsyncRWLock()
    return _mtproto_rw_lock


async def _mtproto_with_client_locked() -> Any:
    """v97.29: acquire a READ lock and return the current client.

    Callers MUST use this as an async context manager:

        async with _mtproto_read_lock_ctx() as client:
            if client is None:
                raise MTProtoError("MTProto not started")
            result = await client.some_rpc(...)

    The read lock is held for the duration of the ``with`` block, preventing
    a reconnect from tearing down the client mid-RPC. The client reference
    is captured INSIDE the lock so it cannot go stale.
    """
    # This function is a coroutine helper; callers use the context manager
    # form below which is more ergonomic.
    raise NotImplementedError


class _MtprotoReadLockCtx:
    """v97.29: async context manager that holds a read lock + yields client.

    Usage:
        async with _MtprotoReadLockCtx() as client:
            if client is None:
                return None  # MTProto not started
            return await client.get_me()

    The read lock prevents _mtproto_safe_reconnect from starting a disconnect
    while the caller's RPC is in flight. New RPCs during a reconnect block
    here (on the read lock) until the reconnect completes, then receive the
    FRESH client reference — they never see a disconnecting client.
    """

    def __init__(self) -> None:
        self._client: Any = None
        self._lock_acquired: bool = False

    async def __aenter__(self) -> Any:
        rw = _get_mtproto_rw_lock()
        # v98.08 FIX-WW: bounded read acquire (20s). The unbounded wait
        # could queue forever behind a stuck writer — only the
        # mtproto_call_with_retry site was bounded in v98.07. Timeout →
        # honest asyncio.TimeoutError (retryable by existing callers,
        # same class the 4870 site already raises); VC_RW_ACQUIRE_TIMEOUT
        # marks it for the soak.
        _v808_ok = await rw.acquire_read(timeout=20.0)
        if not _v808_ok:
            logger.warning(
                "VC_RW_ACQUIRE_TIMEOUT scope=global wait=20.0s — read lock "
                "starved by a writer; raising retryable TimeoutError "
                "(v98.08 FIX-WW)")
            raise asyncio.TimeoutError(
                "MTProto global RW read-lock starved > 20s (v98.08 FIX-WW)")
        self._lock_acquired = True
        # Capture the client reference INSIDE the read lock so it cannot be
        # swapped out from under us by a writer (reconnect/start).
        self._client = _mtproto_client if _mtproto_started else None
        return self._client

    async def __aexit__(self, *exc: Any) -> None:
        if self._lock_acquired:
            try:
                await _get_mtproto_rw_lock().release_read()
            except Exception:  # noqa: BLE001
                pass
            self._lock_acquired = False


# v97.31: Per-cluster-client RW locks.  Maps account_id → _AsyncRWLock.
# The global _mtproto_rw_lock protects the GLOBAL _mtproto_client.  Cluster
# clients (UserbotCluster._clients) each need their own lock so that a
# reconnect on account A doesn't block RPCs on account B, while still
# preventing a reconnect on account A from racing with RPCs on account A.
_cluster_client_rw_locks: dict[str, _AsyncRWLock] = {}
_cluster_client_locks_guard = asyncio.Lock()


async def _get_cluster_client_rw_lock(account_id: str) -> _AsyncRWLock:
    """v97.31: lazily create/get the per-cluster-client RW lock."""
    async with _cluster_client_locks_guard:
        lock = _cluster_client_rw_locks.get(account_id)
        if lock is None:
            lock = _AsyncRWLock()
            _cluster_client_rw_locks[account_id] = lock
        return lock


class _GatedClientProxy:
    """v97.31: Transparent proxy that acquires the READ lock for every RPC.

    This is the MINIMUM safe mechanism to gate ALL direct ``client.<method>``
    call sites without touching each one.  ``mtproto_get_client()`` returns
    this proxy instead of the raw ``TelegramClient``.  Every attribute access
    returns a wrapper that:

      1. Acquires the READ lock (blocks if a reconnect/write is in progress).
      2. Calls the underlying method.
      3. Releases the READ lock when the coroutine completes.

    Supports three Telethon access patterns:
      - ``await client.get_entity(...)`` — method returning a coroutine
      - ``await client(SomeRequest(...))`` — client called as a coroutine
      - ``async for x in client.iter_dialogs(...)`` — async iterator

    The lock is held for the duration of each RPC.  For ``iter_dialogs`` the
    lock is held across the entire iteration (the async generator releases on
    exit).  This means a long ``iter_dialogs(limit=5000)`` blocks reconnect
    for its full duration — which is CORRECT: you don't want to tear down a
    client while iterating its dialogs.

    Non-RPC attributes (``is_connected()``, ``disconnect()``, etc.) are passed
    through WITHOUT the lock — they are state probes / teardown, not RPCs.
    """

    # Methods that do NOT send Telegram RPCs — pass through without the lock.
    _NON_RPC_METHODS = frozenset({
        "is_connected", "disconnect", "connect", "is_user_authorized",
        "session", "loop", "flood_sleep_threshold", "receive_updates",
        "async_getstate", "async_setstate",
    })

    def __init__(self, client: Any, rw_lock_getter: Any = None,
                 client_id: str = "global") -> None:
        # Use object.__setattr__ to bypass our __setattr__ if we had one.
        object.__setattr__(self, "_real_client", client)
        object.__setattr__(self, "_rw_lock_getter", rw_lock_getter)
        object.__setattr__(self, "_client_id", client_id)

    async def _acquire_read(self) -> Any:
        """Acquire the READ lock and return the real client.

        v98.08 FIX-WW: bounded at 20s (was unbounded — a stuck writer on
        this account's lock queued every RPC on this client forever;
        only mtproto_call_with_retry's site was bounded in v98.07)."""
        if self._rw_lock_getter is not None:
            lock = await self._rw_lock_getter()
            _v808_ok = await lock.acquire_read(timeout=20.0)
            if not _v808_ok:
                logger.warning(
                    "VC_RW_ACQUIRE_TIMEOUT scope=cluster:%s wait=20.0s — "
                    "read lock starved by a writer; raising retryable "
                    "TimeoutError (v98.08 FIX-WW)", self._client_id)
                raise asyncio.TimeoutError(
                    f"cluster RW read-lock starved > 20s for {self._client_id} "
                    "(v98.08 FIX-WW)")
        return self._real_client

    async def _release_read(self) -> None:
        """Release the READ lock."""
        if self._rw_lock_getter is not None:
            lock = await self._rw_lock_getter()
            await lock.release_read()

    def __getattr__(self, name: str) -> Any:
        """Wrap method calls with the READ lock; pass through non-RPC attrs."""
        if name in self._NON_RPC_METHODS:
            return getattr(self._real_client, name)

        attr = getattr(self._real_client, name)
        if not callable(attr):
            # Non-callable attribute (e.g. property) — pass through.
            return attr

        # Check if it's an async generator function (iter_dialogs, iter_messages)
        import inspect
        if inspect.isasyncgenfunction(attr):
            return self._wrap_async_gen(name, attr)
        if inspect.iscoroutinefunction(attr):
            return self._wrap_coro(name, attr)
        # Sync callable — pass through (shouldn't happen for RPC methods).
        return attr

    def _wrap_coro(self, name: str, func: Any) -> Any:
        """Wrap a coroutine method: acquire read lock → call → release.

        v97.74 P1: bound the RPC with a 10s wait_for so a hung socket cannot
        hold the read lock indefinitely and starve the reconnect writer.
        This completes the v97.72 "RW-lock starvation" fix, which only covered
        mtproto_call_with_retry but not the ~86 call sites that go through the
        proxy directly. 10s matches the RPC-timeout harmonization. On timeout
        wait_for cancels the inner coroutine (Telethon handles CancelledError
        cleanly) and the finally releases the read lock.
        """
        async def wrapper(*args, **kwargs):
            await self._acquire_read()
            try:
                return await asyncio.wait_for(func(*args, **kwargs), timeout=10.0)
            finally:
                await self._release_read()
        return wrapper

    def _wrap_async_gen(self, name: str, func: Any) -> Any:
        """Wrap an async generator: hold the read lock for the entire iteration.

        v97.74 P2 (KNOWN LIMITATION — requires runtime-tested fix): the read
        lock is held across the WHOLE iteration with no per-item timeout. A
        slow iter_dialogs / iter_messages on a large account can starve the
        reconnect writer. The safe fix is a per-__anext__ wait_for budget,
        which needs runtime verification against real Telegram pagination
        before shipping. Tracked as P2: single-call iteration (limit=300
        dialogs) is bounded in practice, and the global
        mtproto_call_with_retry path is already 10s-bounded.
        """
        async def wrapper(*args, **kwargs):
            await self._acquire_read()
            try:
                async for item in func(*args, **kwargs):
                    yield item
            finally:
                await self._release_read()
        return wrapper

    async def __call__(self, *args, **kwargs):
        """Handle ``await client(SomeRequest(...))`` — the client-as-coroutine pattern.

        v97.74 P1: 10s wait_for bound (same rationale as _wrap_coro).
        """
        await self._acquire_read()
        try:
            return await asyncio.wait_for(self._real_client(*args, **kwargs), timeout=10.0)
        finally:
            await self._release_read()

    def __bool__(self) -> bool:
        return self._real_client is not None

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, _GatedClientProxy):
            return self._real_client is other._real_client
        return self._real_client is other

    def __hash__(self) -> int:
        return hash(self._real_client)


# v97 CRITICAL FIX: Session ownership registry.
# Maps canonical session file path → TelegramClient that currently owns it.
# This is the SINGLE source of truth for which client owns which session.
# No code may create a TelegramClient on a session file without checking
# this registry first. This prevents the "wrong session ID" error caused
# by two clients sharing the same auth key with different MTProto session IDs.
_session_owners: dict[str, Any] = {}  # canonical_path → TelegramClient
_session_owners_lock: asyncio.Lock | None = None


def _get_session_owners_lock() -> asyncio.Lock:
    """Lazily create the session owners lock (event-loop-safe)."""
    global _session_owners_lock
    if _session_owners_lock is None:
        _session_owners_lock = asyncio.Lock()
    return _session_owners_lock


def _canonical_session_path(session_base: str) -> str:
    """Return the canonical absolute path for a session file (with .session)."""
    p = session_base
    if not p.endswith(".session"):
        p = p + ".session"
    try:
        return str(Path(p).resolve())
    except Exception:
        return str(Path(p).absolute())


async def _claim_session(session_base: str, client: Any) -> bool:
    """Claim ownership of a session file for a TelegramClient.

    Returns True if the claim succeeded:
      - no previous owner, OR
      - the previous owner was the SAME client object (idempotent re-claim), OR
      - the previous owner is a DIFFERENT client that is STALE (disconnected
        or dead) — in this case the stale owner is evicted and the new client
        claims the session.
    Returns False if a DIFFERENT, LIVE (connected) client already owns this
    session — the caller must reuse that client via _get_session_owner()
    instead of creating a duplicate.

    v97.7 OWNERSHIP LIFECYCLE FIX: the v97.5 implementation refused a
    different client UNCONDITIONALLY (even if the existing owner was a stale
    disconnected temp client).  This caused two production failures:

      1. STALE-OWNER DEADLOCK: a temp client from import_existing_sessions /
         validate_session / cluster_start_login disconnected on an error path
         but (before v97.6) did not release ownership.  The stale
         ``connected=False`` owner blocked ALL future connect_account /
         cluster_start_login attempts with SESSION_OWNERSHIP_CONFLICT —
         permanently locking the account as "session_owned_by_another".

      2. LIVE-OWNER CONFLICT: when a production client was already connected
         (e.g. account B, id=535406959888, connected=True) and the user
         selected "Add Account" for the same phone, cluster_start_login
         created a NEW TelegramClient and _claim_session refused it —
         instead of recognizing the live owner and returning
         "already connected".

    The v97.7 fix distinguishes the two cases:
      - LIVE owner (is_connected()==True): REFUSE the new client.  The caller
        MUST check _get_session_owner() BEFORE calling _claim_session and
        reuse the live client (see connect_account's registry_reuse path
        and cluster_start_login's live-owner check).
      - STALE owner (is_connected()==False): EVICT it atomically (under the
        lock) and let the new client claim the session.  The stale owner's
        disconnect() is called AFTER releasing the lock (to avoid holding
        the lock during network I/O), but the registry mutation is atomic.

    This implements the production invariant:
      LIVE OWNER → remains protected (refuse duplicates)
      STALE OWNER → released (evicted, new client claims)
      TEMP CLIENT → must release on its own exit paths (finally blocks)
    """
    canon = _canonical_session_path(session_base)
    _stale_to_disconnect: Any = None
    async with _get_session_owners_lock():
        existing = _session_owners.get(canon)
        if existing is not None:
            # Idempotent: same client re-claiming its own session.
            if existing is client:
                logger.debug(
                    "SESSION_OWNERSHIP_RECLAIMED path=%s client_id=%s (idempotent)",
                    canon, id(client),
                )
                return True
            # A DIFFERENT client wants this session.  Determine if the
            # existing owner is LIVE (connected) or STALE (disconnected).
            _existing_live = False
            try:
                _existing_live = bool(existing.is_connected())
            except Exception:
                _existing_live = False
            if _existing_live:
                # LIVE owner — REFUSE.  The caller must reuse this client
                # via _get_session_owner() (see connect_account's
                # registry_reuse path).  We must NOT evict a live production
                # client just because another caller wants the session.
                logger.warning(
                    "SESSION_OWNERSHIP_CONFLICT path=%s — a LIVE client "
                    "already owns this session (id=%s, connected=True); "
                    "refusing to create a duplicate (caller must reuse the "
                    "existing client via _get_session_owner)",
                    canon, id(existing),
                )
                return False
            else:
                # STALE owner (disconnected/dead) — EVICT it atomically.
                # The stale owner's disconnect() is called after the lock
                # is released (network I/O must not hold the lock), but
                # the registry mutation is atomic so no concurrent claim
                # can win.
                logger.info(
                    "SESSION_OWNERSHIP_STALE_EVICTED path=%s — evicting "
                    "stale disconnected owner (id=%s) to allow new client "
                    "(id=%s) to claim",
                    canon, id(existing), id(client),
                )
                _stale_to_disconnect = existing
                _session_owners.pop(canon, None)
        # No existing owner (or stale owner evicted) — claim it.
        _session_owners[canon] = client
        logger.info(
            "SESSION_OWNER_ACQUIRED path=%s client_identity=%s",
            canon, id(client),
        )
    # Outside the lock: disconnect the stale owner (best-effort, no await
    # under the lock).  This prevents the stale client's SQLite handle from
    # interfering with the new client.
    if _stale_to_disconnect is not None:
        try:
            await _stale_to_disconnect.disconnect()
        except Exception:  # noqa: BLE001
            pass
    return True


async def _release_session(session_base: str) -> None:
    """Release ownership of a session file."""
    canon = _canonical_session_path(session_base)
    async with _get_session_owners_lock():
        _session_owners.pop(canon, None)
        logger.debug("SESSION_OWNERSHIP_RELEASED path=%s", canon)


def _get_session_owner(session_base: str) -> Any | None:
    """Return the client that currently owns this session, or None."""
    canon = _canonical_session_path(session_base)
    return _session_owners.get(canon)


def _get_live_session_owner(session_base: str) -> Any | None:
    """v97.7: Return the LIVE (connected) owner of a session, or None.

    Unlike _get_session_owner, this returns None if the registered owner is
    stale (disconnected/dead).  Callers should use this to decide whether to
    REUSE an existing client before creating a new one.

    A None return means: no owner OR stale owner — safe to create a new
    client (the new client's _claim_session will evict any stale owner
    atomically).
    """
    owner = _get_session_owner(session_base)
    if owner is None:
        return None
    try:
        if owner.is_connected():
            return owner
    except Exception:
        pass
    return None


async def _is_session_live_authorized(session_base: str) -> bool:
    """v97.7: Check if a session has a live, authorized owner.

    Used by cluster_start_login / connect_account to detect an
    already-connected account and return "already connected" instead of
    creating a duplicate client.
    """
    owner = _get_live_session_owner(session_base)
    if owner is None:
        return False
    try:
        return bool(await asyncio.wait_for(owner.is_user_authorized(), timeout=10))
    except Exception:
        return False

_mtproto_stats = {
    "requests": 0,
    "successes": 0,
    "failures": 0,
    "flood_waits": 0,
    "reconnects": 0,
}


def mtproto_is_available() -> bool:
    """True if Telethon is importable."""
    try:
        import telethon  # noqa: F401
        return True
    except ImportError:
        return False


def mtproto_is_started() -> bool:
    return (_mtproto_started
            and _mtproto_client is not None
            and _mtproto_client.is_connected())


async def mtproto_start() -> str:
    """Start the MTProto client. Returns a status string."""
    global _mtproto_client, _mtproto_started, _mtproto_start_time

    if _mtproto_started and _mtproto_client is not None and _mtproto_client.is_connected():
        return "already_running"
    if not config.mtproto_configured:
        return "not_configured"
    if not mtproto_is_available():
        return "telethon_not_installed"

    from telethon import TelegramClient

    # v97.7 FIX: collect ALL candidate .session files (FAST — filesystem
    # only, no network calls).  Then iterate through them: try each one
    # with a real TelegramClient, and use the FIRST one that connects +
    # is authorized.  This replaces the v97.6 _find_authorized_session_file()
    # which created temp clients for each candidate (SLOW: 15s × N, causing
    # the 70s timeout on Termux).
    _candidates = _find_all_session_files()
    if not _candidates:
        logger.warning("MTProto session file not found — run interactive login first.")
        return "no_session_file"

    logger.info("MTPROTO_SESSION_CANDIDATES count=%d files=%s",
                len(_candidates), [str(c.name) for c in _candidates])

    # v97.29: capture the generation counter BEFORE the slow candidate loop.
    # If a _mtproto_safe_reconnect runs during this start (bumping the
    # generation), we detect it at the success path and abandon this start
    # to avoid installing a stale client over a freshly-reconnected one.
    _gen_at_start: int = _mtproto_generation
    _last_error = "no_authorized_session"
    for _session_file in _candidates:
        # v97: strip the .session extension — TelegramClient adds it back.
        _session_base = str(_session_file)
        if _session_base.endswith(".session"):
            _session_base = _session_base[:-len(".session")]
        logger.info("MTProto trying session file: %s.session", _session_base)

        # v97 CRITICAL FIX: check the session ownership registry before creating
        # a new TelegramClient. If another client already owns this session,
        # reuse it instead of creating a duplicate (which causes "wrong session ID").
        _existing_owner = _get_session_owner(_session_base)
        if _existing_owner is not None:
            try:
                if _existing_owner.is_connected():
                    logger.info("MTProto reusing existing session owner (client_id=%s)",
                                id(_existing_owner))
                    _mtproto_client = _existing_owner
                    _mtproto_started = True
                    _mtproto_start_time = time.time()
                    me = await asyncio.wait_for(_mtproto_client.get_me(), timeout=10)
                    logger.info("MTProto client started as @%s (id=%s)",
                                getattr(me, "username", None), me.id)
                    await _mtproto_register_handlers()
                    _mtproto_start_background_tasks()
                    return f"started:{getattr(me, 'username', me.id)}"
            except Exception:
                pass  # existing owner is broken — fall through to create new

        try:
            _mtproto_client = TelegramClient(
                _session_base,
                config.tg_api_id,
                config.tg_api_hash,
                connection_retries=3,
                retry_delay=1,
                # v97.26: DISABLE auto_reconnect — same reasoning as
                # connect_account above.  auto_reconnect=True causes
                # 113 Telethon tasks + 219 wrong-session-ID + 61s lag.
                auto_reconnect=False,
                request_retries=2,
            )
            # v97: claim session ownership BEFORE connecting.
            # v97.7: _claim_session now evicts STALE (disconnected) owners
            # atomically, so a stale temp client no longer blocks mtproto_start.
            if not await _claim_session(_session_base, _mtproto_client):
                # This branch is ONLY reachable if a LIVE owner claimed the
                # session.  Skip to the next candidate.
                logger.warning("MTProto session ownership conflict for %s — "
                               "a LIVE client owns it; trying next candidate",
                               _session_base)
                try:
                    await _mtproto_client.disconnect()
                except Exception:
                    pass
                _mtproto_client = None
                _last_error = "session_owned_by_another"
                continue
            # v97 CRITICAL FIX: wrap connect() in asyncio.wait_for.
            try:
                await asyncio.wait_for(_mtproto_client.connect(), timeout=15)
            except asyncio.TimeoutError:
                logger.warning("MTProto connect() timed out for %s — trying next candidate",
                               _session_base)
                try:
                    await _mtproto_client.disconnect()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await _release_session(_session_base)
                except Exception:  # noqa: BLE001
                    pass
                _mtproto_client = None
                _last_error = "connect_timeout"
                continue
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # v97.59 §2: classify the connect failure. Network-unreachable
                # must NOT invalidate the session (per §2.2/§2.3) — the candidate
                # is preserved + we wait for the network to return. Only
                # AUTH_FAILURE / SESSION_INVALID may invalidate a session.
                from .mtproto_generation import classify_failure, is_session_invalidating, NetworkFailureClass
                _fail_cls = classify_failure(exc)
                _invalidates = is_session_invalidating(_fail_cls)
                logger.warning(
                    "MTProto connect() failed for %s: %s — classified=%s invalidates_session=%s "
                    "— trying next candidate (network failures do NOT invalidate sessions)",
                    _session_base, exc, _fail_cls.value, _invalidates,
                )
                try:
                    await _mtproto_client.disconnect()
                except Exception:  # noqa: BLE001
                    pass
                # v97.59 §2.2: if this is a network failure (NOT auth), DON'T
                # release the session — preserve it for retry when the network
                # returns. Only release on auth/session-invalid failures.
                if _invalidates:
                    try:
                        await _release_session(_session_base)
                    except Exception:  # noqa: BLE001
                        pass
                else:
                    # Network failure — mark the session as network-deferred
                    # (NOT unauthorized). The candidate is preserved.
                    logger.info(
                        "MTPROTO_SESSION_PRESERVED session=%s reason=%s — "
                        "will retry when network returns (NOT a session failure)",
                        _session_base, _fail_cls.value,
                    )
                _mtproto_client = None
                _last_error = f"connect_failed:{type(exc).__name__}:classified={_fail_cls.value}"
                continue

            if not await asyncio.wait_for(_mtproto_client.is_user_authorized(), timeout=10):
                logger.warning("MTProto session %s not authorized — trying next candidate",
                               _session_base)
                # v99.03 RC-10/RC-11: record the dead file in the session
                # health registry + emit the remediation runbook — the
                # v99.02 production operator never learned that this
                # session needed delete + re-login (they only saw
                # ACCOUNT_STARTUP_REPORT total=1 and concluded an account
                # was "missing").
                _register_session_status(
                    os.path.basename(_session_file), "unauthorized")
                _emit_session_remediation(os.path.basename(_session_file))
                await _mtproto_client.disconnect()
                try:
                    await _release_session(_session_base)
                except Exception:  # noqa: BLE001
                    pass
                _mtproto_client = None
                _last_error = "not_authorized"
                continue

            # v97: wrap get_me() in a timeout.
            try:
                me = await asyncio.wait_for(_mtproto_client.get_me(), timeout=10)
            except asyncio.TimeoutError:
                logger.warning("MTProto get_me() timed out for %s — trying next candidate",
                               _session_base)
                try:
                    await _mtproto_client.disconnect()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await _release_session(_session_base)
                except Exception:  # noqa: BLE001
                    pass
                _mtproto_client = None
                _last_error = "get_me_timeout"
                continue

            _mtproto_started = True
            _mtproto_start_time = time.time()
            # v97.29: verify no reconnect happened during the slow candidate
            # loop. If _mtproto_generation changed, a _mtproto_safe_reconnect
            # ran concurrently and may have reconnected a DIFFERENT client —
            # in that case, abandon this start (the reconnected client wins)
            # to prevent installing a stale client. This closes the start-vs-
            # reconnect race that was only observable (not blocked) in v97.28.
            if _gen_at_start != _mtproto_generation:
                logger.warning(
                    "MTPROTO_START_RACE_DETECTED — generation changed during "
                    "start (%d → %d); a safe_reconnect ran concurrently. "
                    "Abandoning this start to avoid installing a stale client.",
                    _gen_at_start, _mtproto_generation,
                )
                try:
                    await _mtproto_client.disconnect()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await _release_session(_session_base)
                except Exception:  # noqa: BLE001
                    pass
                _mtproto_client = None
                _mtproto_started = False
                _last_error = "start_race_with_reconnect"
                continue
            logger.info("MTProto client started as @%s (id=%s) using %s.session",
                        getattr(me, "username", None), me.id, _session_base)
            # v99.03 RC-10: record WHICH session file the primary global
            # client actually started with — account_session_health() then
            # labels this file "primary_global" (it is NOT a cluster
            # account and is absent from accounts.json BY DESIGN; the
            # v99.02 operator misread its absence as "an account is
            # missing").
            global _MTPROTO_ACTIVE_SESSION_PATH
            _MTPROTO_ACTIVE_SESSION_PATH = f"{_session_base}.session"
            _register_session_status(
                os.path.basename(_MTPROTO_ACTIVE_SESSION_PATH),
                "primary_global",
                username=str(getattr(me, "username", "") or ""),
                user_id=int(getattr(me, "id", 0) or 0))
            # v97.79: snapshot the 6 Telethon background task objects for THIS
            # client so forced-cancel can cancel ONLY this client's tasks (not
            # other clients' tasks globally). The v97.78 asyncio.all_tasks()
            # approach was GLOBAL — it would cancel ALL clients' tasks. The
            # correct Telethon attribute names (verified from upstream source):
            #   client._updates_handle        (update loop)
            #   client._keepalive_handle      (keepalive loop)
            #   client._sender._send_loop_handle
            #   client._sender._recv_loop_handle
            #   client._sender._connection._send_task
            #   client._sender._connection._recv_task
            _snapshot_telethon_bg_tasks(_mtproto_client, label="primary")
            # v97.16: check cryptg availability — critical for download speed.
            try:
                import cryptg  # noqa: F401
                logger.info("MTPROTO_CRYPTG_OK — fast AES-IGE acceleration available")
            except ImportError:
                logger.warning(
                    "MTPROTO_CRYPTG_MISSING — Telethon using slow Python AES-IGE. "
                    "Install cryptg (pip install cryptg) for 10-50x faster downloads."
                )

            await _mtproto_register_handlers()
            _mtproto_start_background_tasks()

            return f"started:{getattr(me, 'username', me.id)}"
        except Exception as exc:  # noqa: BLE001
            logger.warning("MTProto start failed for %s: %s — trying next candidate",
                           _session_base, exc)
            if _mtproto_client is not None:
                try:
                    await _mtproto_client.disconnect()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await _release_session(_session_base)
                except Exception:  # noqa: BLE001
                    pass
            _mtproto_client = None
            _mtproto_started = False
            _last_error = f"error:{exc}"
            continue

    # All candidates exhausted — return the last error.
    # v97.59 §2: distinguish "no authorized session" from "network failure".
    # Network failures are NOT session-invalidating — the candidates are
    # preserved for retry. Only report "no authorized session" when auth was
    # actually proven false.
    from .mtproto_generation import classify_failure, NetworkFailureClass
    _final_cls = classify_failure(None, _last_error)
    _is_network_failure = _final_cls in (
        NetworkFailureClass.NETWORK_UNREACHABLE,
        NetworkFailureClass.CONNECTION_RESET,
        NetworkFailureClass.CONNECTION_ABORTED,
        NetworkFailureClass.REMOTE_CLOSE,
        NetworkFailureClass.TIMEOUT,
    ) or "network_unreachable" in _last_error or "classified=network_" in _last_error
    if _is_network_failure:
        logger.error(
            "MTProto start failed — NETWORK FAILURE (NOT a session problem): "
            "%d candidate(s) tried; last_error=%s. Sessions are PRESERVED — "
            "will retry when the network returns. Do NOT rotate sessions.",
            len(_candidates), _last_error,
        )
    else:
        logger.error(
            "MTProto start failed — no authorized session found among %d candidate(s); "
            "last_error=%s",
            len(_candidates), _last_error,
        )
    _mtproto_client = None
    _mtproto_started = False
    return _last_error


async def mtproto_stop() -> str:
    """Disconnect the MTProto client and cancel background tasks.

    Fix 14: await cancelled tasks before discarding references.
    Fix 15: disconnect client before setting to None (prevents leak).
    v97.32: CRITICAL shutdown race fix — await client.disconnected (drain
    future) after disconnect() so ALL Telethon background tasks (_send_loop,
    _recv_loop, _update_loop, _keepalive_loop, MTProtoSender send/recv) are
    fully cancelled and drained BEFORE we null the reference. Without this,
    the tasks survive until the event loop closes, producing:
      "Task was destroyed but it is pending!"
      "TelegramBaseClient._disconnect_coro was never awaited"
      "RuntimeError: Event loop is closed" (from _recv_loop._start_reconnect)
    v97.32: ALSO disconnect ALL cluster-account clients (not just the global
    client). Previously, cluster clients were left connected at shutdown,
    leaving their 6 background tasks each alive when the loop closed.
    v97.94 INSTRUMENT BUG-P4-2 (SOURCE-PROVEN narrow race):
    mtproto_stop does NOT acquire the RW write lock — if an in-flight
    _mtproto_safe_reconnect._reconnect_fn is running concurrently (e.g.
    SIGTERM received during a reconnect storm), they can race: stop nulls
    _mtproto_client while reconnect reads it. This is pure observability —
    we LOG the in-flight reconnect state at stop time so operators can
    detect the race if it occurs. Wiring the RW lock into mtproto_stop
    risks deadlock if the reconnect path also acquires it; deferred until
    the next hardening cycle.
    """
    global _mtproto_client, _mtproto_started, _mtproto_health_task, _mtproto_watchdog_task, _mtproto_self_destruct_registered

    # v97.94 INSTRUMENT BUG-P4-2: detect in-flight reconnect at shutdown.
    try:
        from .mtproto_generation import get_reconnect_coordinator
        _coord_iog = get_reconnect_coordinator()
        if _coord_iog is not None:
            _in_flight_iog = getattr(_coord_iog, "_in_flight", None)
            if _in_flight_iog is not None and not _in_flight_iog.done():
                logger.warning(
                    "MTPROTO_STOP_RECONNECT_IN_FLIGHT — mtproto_stop() called "
                    "while a reconnect is in progress (no RW lock held); a "
                    "race between stop and _reconnect_fn is possible. "
                    "If this fires alongside AttributeError/NoneType errors, "
                    "the race is the cause."
                )
    except Exception:  # noqa: BLE001
        pass

    # Fix 14: cancel AND await background tasks.
    if _mtproto_health_task and not _mtproto_health_task.done():
        _mtproto_health_task.cancel()
        try:
            await asyncio.wait_for(_mtproto_health_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
    _mtproto_health_task = None
    if _mtproto_watchdog_task and not _mtproto_watchdog_task.done():
        _mtproto_watchdog_task.cancel()
        try:
            await asyncio.wait_for(_mtproto_watchdog_task, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
    _mtproto_watchdog_task = None

    # v97.32: disconnect ALL cluster-account clients (not just the global one).
    # Each cluster client has 6 Telethon background tasks that must be drained
    # before the loop closes, or they produce "Task was destroyed but it is
    # pending" + "_disconnect_coro was never awaited" errors.
    try:
        cluster = get_userbot_cluster()
        cluster_client_ids = list(cluster._clients.keys()) if hasattr(cluster, '_clients') else []
        for aid in cluster_client_ids:
            try:
                await cluster.disconnect_account(aid)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Cluster account %s disconnect error during stop: %s", aid, exc)
    except Exception as exc:  # noqa: BLE001
        logger.debug("Cluster disconnect-all error during stop: %s", exc)

    # Fix 15: disconnect client before nulling reference.
    if _mtproto_client is not None:
        # v97: release session ownership before disconnecting.
        try:
            _sess_file = _find_session_file()
            if _sess_file is not None:
                _sess_base = str(_sess_file)
                if _sess_base.endswith(".session"):
                    _sess_base = _sess_base[:-len(".session")]
                await _release_session(_sess_base)
        except Exception:
            pass
        try:
            # v97.32: bound the disconnect with a timeout so a hung disconnect
            # doesn't block shutdown indefinitely. The drain step below has its
            # own timeout.
            await asyncio.wait_for(_mtproto_client.disconnect(), timeout=10)
        except asyncio.TimeoutError:
            logger.warning("MTProto disconnect timed out after 10s — proceeding (tasks may leak).")
        except Exception as exc:  # noqa: BLE001
            logger.debug("MTProto disconnect error: %s", exc)
        # v97.32: AWAIT the disconnected drain future. This resolves only when
        # ALL 6 Telethon background tasks are fully done. Without this, the
        # tasks survive until loop closure → "Task was destroyed but it is
        # pending" + "_disconnect_coro was never awaited" + "Event loop is
        # closed" from _recv_loop's _start_reconnect.
        disc = getattr(_mtproto_client, "disconnected", None)
        if disc is not None:
            try:
                await asyncio.wait_for(disc, timeout=10)
            except asyncio.TimeoutError:
                logger.warning("MTProto disconnected drain timed out after 10s — "
                               "background tasks may still be cancelling.")
            except Exception as exc:  # noqa: BLE001
                logger.debug("MTProto disconnected drain error: %s", exc)
        # v97.75: forced-cancel ALL 6 Telethon background tasks on shutdown too.
        # Same rationale as the reconnect path: the `disconnected` future may
        # resolve before all tasks are truly done. Without this, shutdown leaks
        # tasks → "Task was destroyed but it is pending" + generation coexistence
        # on the NEXT bot start (if the session file is reused).
        try:
            await _forcibly_cancel_telethon_tasks(_mtproto_client, "mtproto_stop")
        except Exception as exc:  # noqa: BLE001
            logger.debug("MTProto stop forced-cancel error: %s", exc)
        _mtproto_client = None
    _mtproto_started = False
    # v97: clear ALL session ownership entries (cluster accounts too).
    _session_owners.clear()
    # v97.32: clear per-cluster-client RW locks (all clients are disconnected).
    _cluster_client_rw_locks.clear()
    # v97.28: reset the self-destruct handler flag so _mtproto_register_handlers
    # re-registers the NewMessage capture handler on the next mtproto_start.
    # Without this, the handler is silently missing on any client started
    # after the first one (e.g. after mtproto_restart), so self-destruct
    # media capture stops working until the bot is fully restarted.
    _mtproto_self_destruct_registered = False
    logger.info("MTProto client stopped.")
    return "stopped"


async def mtproto_restart() -> str:
    """Restart the MTProto client."""
    await mtproto_stop()
    await asyncio.sleep(1)
    return await mtproto_start()


def mtproto_get_client() -> Optional[Any]:
    """Return the active TelegramClient (gated proxy), or None if not started.

    V67.4 Part 11: This is the SINGLE source of truth for MTProto client
    access. ALL existing call sites (downloader, discovery, VC, profile
    lookup, restricted downloader, media browser) call this function. To
    route them through the cluster WITHOUT changing 51 call sites, we first
    ask the cluster router for a healthy account. If one exists, it wins.
    Otherwise we fall back to the legacy single-client.

    The router itself falls back to ``_mtproto_client`` when no cluster
    accounts are connected, so backward compatibility is preserved.

    v97.31: returns a ``_GatedClientProxy`` that transparently acquires the
    READ lock for every RPC. This gates ALL 86 direct ``client.<method>``
    call sites without touching each one. The proxy delegates to the real
    TelegramClient; non-RPC methods (is_connected, disconnect) pass through
    without the lock.
    """
    # V67.4: prefer a cluster account if any are healthy.
    try:
        router = get_cluster_router()
        routed_account_id, routed_client = router.get_client_for_role_with_id(ROLE_PRIMARY)
        if routed_client is not None:
            # v97.31: wrap the cluster client in a gated proxy with the
            # per-cluster-client RW lock.
            async def _lock_getter():
                return await _get_cluster_client_rw_lock(routed_account_id)
            return _GatedClientProxy(routed_client, _lock_getter,
                                     client_id=f"cluster:{routed_account_id}")
    except Exception as exc:  # noqa: BLE001
        logger.debug("mtproto_get_client: cluster router fallback failed: %s", exc)
    # v97.31: wrap the global client in a gated proxy with the global RW lock.
    if _mtproto_client is not None and mtproto_is_started():
        async def _global_lock_getter():
            return _get_mtproto_rw_lock()
        return _GatedClientProxy(_mtproto_client, _global_lock_getter,
                                 client_id="global")
    return None


def mtproto_get_client_legacy() -> Optional[Any]:
    """v97.31: Return the RAW TelegramClient (NOT gated).

    INTERNAL USE ONLY. Used by:
      - ``_mtproto_safe_reconnect`` (the writer — it holds the write lock)
      - ``_telethon_drain_and_reconnect`` (writer — holds write lock)
      - ``mtproto_start`` (pre-publish — SAFE-BY-TIMING)
      - ``mtproto_stop`` (shutdown — SAFE-BY-TIMING)
      - The cluster router's fallback path (the caller will wrap in a proxy)

    All other callers MUST use ``mtproto_get_client()`` which returns a
    ``_GatedClientProxy`` that acquires the READ lock for every RPC.
    """
    return _mtproto_client if mtproto_is_started() else None


def mtproto_get_client_for_role(role: str = ROLE_PRIMARY) -> Optional[Any]:
    """V67.4 Part 11: Explicit role-based client accessor.

    Use this when the caller knows which role it wants (e.g. the discovery
    scheduler wants ROLE_DISCOVERY, the downloader wants ROLE_DOWNLOADER).
    Falls back to mtproto_get_client() if no cluster accounts are connected.
    """
    try:
        router = get_cluster_router()
        routed = router.get_client_for_role(role)
        if routed is not None:
            return routed
    except Exception as exc:  # noqa: BLE001
        logger.debug("mtproto_get_client_for_role role=%s fallback: %s", role, exc)
    return _mtproto_client if mtproto_is_started() else None


def mtproto_get_status() -> dict[str, Any]:
    """Return a status snapshot for the admin panel."""
    return {
        "available": mtproto_is_available(),
        "configured": config.mtproto_configured,
        "started": mtproto_is_started(),
        "uptime_seconds": (time.time() - _mtproto_start_time) if _mtproto_started else 0,
        "stats": dict(_mtproto_stats),
        "session": session_info(),
    }


# V94 FIX: Global Telethon rate limiter.
# Every MTProto RPC must go through this semaphore to prevent concurrent
# bursts from Discovery + VC Watcher + Join All + Talkative + profile resolver
# from saturating the single Telethon client and triggering FloodWait.
# Default: 3 concurrent requests (safe for a single userbot account).
_MTPROTO_GLOBAL_SEMAPHORE: asyncio.Semaphore | None = None
_MTPROTO_GLOBAL_SEMAPHORE_SIZE = _env_int("MTPROTO_MAX_CONCURRENT", 3)


def _get_mtproto_semaphore() -> asyncio.Semaphore:
    """Lazily create the global MTProto semaphore on the running event loop."""
    global _MTPROTO_GLOBAL_SEMAPHORE
    if _MTPROTO_GLOBAL_SEMAPHORE is None:
        _MTPROTO_GLOBAL_SEMAPHORE = asyncio.Semaphore(
            max(1, _MTPROTO_GLOBAL_SEMAPHORE_SIZE))
    return _MTPROTO_GLOBAL_SEMAPHORE


async def mtproto_call_with_retry(func: Callable, *args, retries: int = 3,
                                  **kwargs) -> Any:
    """Call a Telethon coroutine with FloodWait + network retry.

    Contract: *func* is a callable (e.g. ``client`` or ``client.get_entity``)
    and *args*/*kwargs* are passed to it. Request objects must be INSTANTIATED
    before being passed — never pass a raw request CLASS as an argument.

    V94 FIX: acquires the global MTProto semaphore to bound concurrent RPCs
    across ALL subsystems. This prevents event-loop starvation from
    uncoordinated parallel Telethon calls.
    """
    # Defensive: detect raw request classes passed as arguments (programming
    # defect — must not be retried as a transient Telegram error).
    for i, a in enumerate(args):
        if isinstance(a, type):
            raise TypeError(
                f"mtproto_call_with_retry received a raw type "
                f"({a.__name__}) as positional arg {i}. "
                f"Instantiate the request object before calling."
            )

    from telethon.errors import FloodWaitError

    _mtproto_stats["requests"] += 1
    last_exc: Exception | None = None
    # v97.67: extract the ACTUAL client ONCE — used for per-attempt connectivity checks.
    # The v97.64 gate checked connectivity ONCE before the loop, but the client can
    # disconnect DURING an RPC. The ConnectionError handler then retried WITHOUT
    # re-checking — producing the 48 retry errors in the v97.66 log.
    # Fix: check connectivity BEFORE EVERY attempt + immediately after a ConnectionError.
    _gate_client = None
    try:
        _bound_self = getattr(func, "__self__", None)
        if _bound_self is not None and hasattr(_bound_self, "is_connected"):
            _gate_client = _bound_self
        elif args and hasattr(args[0], "is_connected"):
            _gate_client = args[0]
        elif hasattr(func, "is_connected"):
            _gate_client = func
    except Exception:  # noqa: BLE001
        _gate_client = None
    if _gate_client is None:
        _gate_client = _mtproto_client

    def _is_gate_client_connected() -> bool:
        """Check the ACTUAL client's connectivity. Never raises."""
        if _gate_client is None:
            return True  # can't check — allow the attempt
        try:
            return _gate_client.is_connected()
        except Exception:  # noqa: BLE001
            return False

    for attempt in range(1, retries + 1):
        # v97.30: check the global FloodWait gate BEFORE each attempt.  If a
        # FloodWait is active (set by ANY subsystem — Join-All, discovery,
        # download, or a prior mtproto_call_with_retry attempt), wait until it
        # expires before issuing the RPC.  This prevents retry-hammering during
        # the rate-limit period and ensures FloodWait on one operation pauses
        # ALL MTProto callers (requirement 6: no retry storms across the app).
        try:
            while vc_is_global_floodwait_active():
                _remaining = 30.0  # default poll interval
                try:
                    from .voicechat import vc_global_floodwait_remaining as _gw_rem
                    _remaining = min(30.0, max(1.0, _gw_rem()))
                except Exception:  # noqa: BLE001
                    pass
                logger.debug("MTPROTO_CALL_FLOODWAIT_WAIT remaining=%.0fs (attempt %d/%d)",
                             _remaining, attempt, retries)
                await asyncio.sleep(_remaining)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            pass  # gate check is best-effort — don't block the call on hook errors
        # v97.67 P0: check the ACTUAL client's connectivity BEFORE EVERY attempt.
        # The v97.64 gate checked ONCE before the loop, but the client can disconnect
        # DURING an RPC. The ConnectionError handler then retried WITHOUT re-checking.
        # This per-attempt check ensures we NEVER issue an RPC against a known-disconnected client.
        if not _is_gate_client_connected():
            _mtproto_stats["failures"] += 1
            logger.info(
                "MTPROTO_RPC_DEFERRED_DISCONNECTED — client not connected before attempt %d/%d, "
                "terminating retry loop (no RPC; watchdog handles reconnect)",
                attempt, retries,
            )
            raise ConnectionError(
                "Cannot send requests while disconnected — "
                "MTProto client is not connected (deferring; "
                "watchdog handles reconnect)"
            )
        # V94: acquire the global semaphore for EVERY attempt.
        try:
            sem = _get_mtproto_semaphore()
        except RuntimeError:
            # No running loop — fall through without the semaphore.
            sem = None
        if sem is not None:
            await sem.acquire()
        # v97 CRITICAL FIX (RE-APPLIED): the semaphore MUST be released BEFORE
        # any FloodWait/ConnectionError sleep. Previously, the sleep happened
        # inside the try block, so the finally released the semaphore only
        # AFTER the sleep completed. A single 600s FloodWait would hold 1 of 3
        # global semaphore slots for 600s, starving ALL other Telethon callers
        # (Bot API entity resolution, Join All, Watcher, Talkative). This is
        # the ROOT CAUSE of "bot becomes unresponsive when Auto Discovery runs."
        _sleep_before_retry: float = 0.0
        # v97.29: _read_lock_held is initialized BEFORE the try block so the
        # outer finally can safely check it even if acquire_read() itself
        # raises (e.g. cancelled while waiting for a writer to finish).
        _read_lock_held: bool = False
        try:
            # v97.29: acquire a READ lock for the duration of the RPC so a
            # concurrent _mtproto_safe_reconnect cannot tear down the client
            # mid-call. The lock is released in the finally below (BEFORE the
            # retry sleep) so a pending writer (reconnect) is not blocked for
            # the full FloodWait duration. If a reconnect is in progress when
            # we get here, acquire_read() blocks until it completes — we then
            # receive the fresh client via the captured reference.
            #
            # NOTE: func is typically a bound method like `client.get_entity`
            # captured BEFORE this call. If the client was swapped during a
            # reconnect, func still references the OLD client. To handle this
            # safely, callers that cache `client` across retries should use
            # _MtprotoReadLockCtx instead. mtproto_call_with_retry is used for
            # short-lived single-shot calls where the caller re-fetches the
            # client per invocation, so the stale-func risk is acceptable.
            #
            # v98.07 FIX-SS (F1 — HARD FREEZE 07:47:18, RUNTIME-CORRELATED:
            # MTPROTO_WATCHDOG_DISCONNECT_DETECTED at 07:47:05 → 95 minutes
            # of log silence; the freeze site sat between
            # vc_detect_active_call's return and the participation check's
            # first log — i.e. an RPC queued behind the reconnect writer):
            #   (a) the RW lock has WRITER PREFERENCE — while the reconnect
            #       writer waits/holds, EVERY new reader queues on
            #       acquire_read() with NO timeout. A wedged writer (Telethon
            #       drain hang) starves all RPCs forever.
            #   (b) FIX: bound the acquire at 20s. A timeout is RETRYABLE
            #       (flows into the existing asyncio.TimeoutError handler:
            #       2s sleep + next attempt re-checks connectivity) instead
            #       of queueing forever. The writer itself keeps its own
            #       bounded drain sequence (10s+10s, v97.72/v97.75).
            #   (c) FIX: generation re-check AFTER the acquire — a
            #       _mtproto_safe_reconnect that completed while we waited
            #       bumped _mtproto_generation; our captured func/client is
            #       stale. Re-dispatch (retry with fresh connectivity gate)
            #       instead of calling into a torn-down sender:
            #       VC_CLIENT_GENERATION_MISMATCH.
            rw = _get_mtproto_rw_lock()
            _v807_gen_before = _mtproto_generation
            try:
                await asyncio.wait_for(rw.acquire_read(), timeout=20.0)
            except asyncio.TimeoutError:
                # Bounded — retryable. Falls into the TimeoutError handler
                # below (last_exc + 2s sleep + next-attempt gate).
                raise
            _read_lock_held = True
            try:
                if _mtproto_generation != _v807_gen_before:
                    logger.warning(
                        "VC_CLIENT_GENERATION_MISMATCH generation_before=%d "
                        "generation_after=%d — a safe reconnect completed while "
                        "this RPC waited for the RW read lock; re-dispatching "
                        "(v98.07 FIX-SS)",
                        _v807_gen_before, _mtproto_generation,
                    )
                    # Release the read lock (the finally below) + retry the
                    # attempt via the TimeoutError handler (retryable).
                    raise asyncio.TimeoutError(
                        "RW read-lock wait spanned an MTProto generation bump — "
                        "re-dispatch on the fresh client (v98.07 FIX-SS)")
                # v97.11 FIX: bound every Telethon RPC with a 30s timeout to
                # prevent event-loop starvation from hung RPCs.
                # v97.72 P0: reduced from 30s to 10s. The 30s timeout kept
                # readers holding the RW read lock for 30s, causing the
                # reconnect write lock to wait 30s → EVENT_LOOP_LAG_CRITICAL.
                # 10s is sufficient for most Telethon RPCs (GetFullChannel,
                # GetGroupCall, get_entity, etc. typically complete in <2s).
                result = await asyncio.wait_for(func(*args, **kwargs), timeout=10.0)
                _mtproto_stats["successes"] += 1
                return result
            finally:
                await rw.release_read()
                _read_lock_held = False
        except FloodWaitError as exc:
            _mtproto_stats["flood_waits"] += 1
            wait = exc.seconds + 1
            logger.warning("FloodWait %ss on MTProto call (attempt %d/%d) — waiting %ss",
                           exc.seconds, attempt, retries, wait)
            last_exc = exc
            _sleep_before_retry = float(wait)
            # v97.30: SET the global FloodWait gate so ALL VC/MTProto workers
            # (discovery, reconcile, watcher, join-all, other downloaders)
            # pause for the full FloodWait duration.  This prevents a retry
            # storm where other subsystems keep hitting the same FloodWait.
            # The gate is checked at the top of this function and in the
            # VC loops (reconcile, watcher, auto_discovery, join-all).
            try:
                await vc_set_global_floodwait(float(exc.seconds),
                                              source="mtproto_call_with_retry")
            except Exception:  # noqa: BLE001
                pass  # best-effort — don't fail the call on hook errors
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError as exc:
            # v97.72: timeout is now 10s (was 30s). Treat as retryable.
            logger.warning("MTProto RPC timed out after 10s (attempt %d/%d)",
                           attempt, retries)
            last_exc = exc
            _sleep_before_retry = 2.0
        except ConnectionError as exc:
            # v97.68 P0: AUTHORITATIVE disconnect classification.
            # The v97.67 fix checked is_connected() AFTER the RPC failed, but
            # Telethon's is_connected() can return True even when the transport
            # is in a half-disconnected state. The RPC itself raising
            # "Cannot send requests while disconnected" IS the authoritative
            # signal — we must trust it over is_connected().
            #
            # The v97.67 log proved this: 190 retries where the log said
            # "will retry (client still connected)" while the actual RPC
            # raised "Cannot send requests while disconnected". The
            # is_connected() check was insufficient.
            #
            # Fix: classify the EXCEPTION MESSAGE. If it contains disconnect
            # semantics, treat it as DISCONNECTED immediately — no retry, no
            # sleep, no breaker failure. Only retry if the exception is a
            # genuine transient ConnectionError WITHOUT disconnect semantics
            # (e.g. "wrong session ID" on a specific RPC).
            _exc_msg_lower = str(exc).lower()
            _is_disconnect_exc = any(kw in _exc_msg_lower for kw in (
                "cannot send requests while disconnected",
                "not connected",
                "disconnected",
                "connection reset",
                "connection aborted",
                "connection closed",
                "broken pipe",
                "incomplete read",
                "0 bytes read",
            ))
            if _is_disconnect_exc:
                # The RPC itself confirmed the transport is disconnected.
                # Do NOT retry — terminate immediately.
                _mtproto_stats["failures"] += 1
                logger.info(
                    "MTPROTO_RPC_DEFERRED_DISCONNECTED — ConnectionError on attempt %d/%d "
                    "classified as disconnect (exc=%s), terminating retry loop "
                    "(no sleep, no more attempts, no breaker failure)",
                    attempt, retries, str(exc)[:80],
                )
                raise ConnectionError(
                    "Cannot send requests while disconnected — "
                    "MTProto client disconnected during RPC (deferring; "
                    "watchdog handles reconnect)"
                )
            # The exception is NOT a disconnect — it's a genuine transient
            # ConnectionError (e.g. "wrong session ID"). Re-check is_connected()
            # as a secondary gate, then retry.
            if not _is_gate_client_connected():
                logger.info(
                    "MTPROTO_RPC_DEFERRED_DISCONNECTED — ConnectionError on attempt %d/%d, "
                    "is_connected()=False, terminating retry loop",
                    attempt, retries,
                )
                _mtproto_stats["failures"] += 1
                raise ConnectionError(
                    "Cannot send requests while disconnected — "
                    "MTProto client disconnected during RPC (deferring; "
                    "watchdog handles reconnect)"
                )
            # Client is still connected + exception is not disconnect-related.
            # This is a genuine transient error — preserve retry behavior.
            logger.warning("MTProto connection error (attempt %d/%d): %s — "
                           "will retry (client still connected, transient error); watchdog handles reconnect",
                           attempt, retries, exc)
            last_exc = exc
            _sleep_before_retry = 2.0
        except Exception as exc:  # noqa: BLE001
            _mtproto_stats["failures"] += 1
            raise
        finally:
            # v97: release the semaphore HERE — before the sleep below.
            if sem is not None:
                try:
                    sem.release()
                except ValueError:
                    pass
            # v97.29: safety net — if we exited the try block via an exception
            # BEFORE releasing the read lock (e.g. the wait_for was cancelled),
            # release it here. The _read_lock_held flag tracks ownership.
            if _read_lock_held:
                try:
                    await _get_mtproto_rw_lock().release_read()
                except Exception:  # noqa: BLE001
                    pass
                _read_lock_held = False
        # v97: sleep WITHOUT holding the semaphore. Other coroutines can
        # now make Telethon calls while we wait out the FloodWait.
        # Skip the sleep on the last attempt (we're about to raise anyway).
        if _sleep_before_retry > 0 and attempt < retries:
            try:
                # v97.30: add ±25% jitter to the retry sleep to prevent
                # thundering-herd retries when multiple callers hit the same
                # transient error simultaneously.  For FloodWait, the gate
                # check at the top of the loop handles the real wait; this
                # jitter only applies to ConnectionError/TimeoutError retries.
                import random as _rnd
                _jitter = _sleep_before_retry * (0.75 + 0.5 * _rnd.random())
                await asyncio.sleep(_jitter)
            except asyncio.CancelledError:
                raise
    _mtproto_stats["failures"] += 1
    raise last_exc  # type: ignore[misc]


def _mtproto_start_background_tasks() -> None:
    global _mtproto_health_task, _mtproto_watchdog_task
    # ASYNC-D-004: cancel any previously-spawned tasks before creating
    # new ones (avoids orphaned health/watchdog loops on reconnect).
    for t in (_mtproto_health_task, _mtproto_watchdog_task):
        if t is not None and not t.done():
            t.cancel()
    _mtproto_health_task = asyncio.create_task(_mtproto_health_loop())
    _mtproto_watchdog_task = asyncio.create_task(_mtproto_watchdog_loop())


async def _check_cluster_clients_health() -> None:
    """v97.93: iterate cluster clients; detect silent disconnects.

    SOURCE-PROVEN gap (bot-diagnostic (5).log): during the PRIMARY client's
    reconnect storm (10 generations in 15 minutes), the CLUSTER client
    (@Official_Ishitaa / acc_919006065076) silently disconnected — its
    recv_loop died without anyone noticing. ``TELETHON_BACKGROUND_OK
    telethon_background_tasks`` dropped from 12 (expected for 2 clients)
    to 7 to 6 with NO ``MTPROTO_CLUSTER_DISCONNECT_DETECTED`` event ever
    logged. The cluster client's ``_update_loop`` (Task-52) survived in
    ``cancelling=1`` state for 40+ minutes — orphaned.

    The v97.92 health loop ONLY checked the PRIMARY ``_mtproto_client``.
    Cluster clients in ``UserbotCluster._clients`` had NO health
    monitoring — when their recv_loops died, the cluster reconnect loop
    (which only retries STATUS_CONNECTION_FAILED accounts) didn't see them
    as failed (their status was still STATUS_CONNECTED/STATUS_HEALTHY).
    They stayed silently dead.

    This helper is invoked from ``_mtproto_health_loop`` every 30s. For
    each cluster client whose status is HEALTHY/CONNECTED but whose
    ``client.is_connected()`` returns False, it emits
    ``MTPROTO_CLUSTER_DISCONNECT_DETECTED`` AND transitions the account to
    STATUS_CONNECTION_FAILED. The existing ``_cluster_reconnect_loop``
    (60s interval, exponential backoff) then automatically retries
    ``connect_account()`` on the next iteration.

    No new background task; no behavioral change to the reconnect path
    itself — just observability + status transition that triggers the
    EXISTING reconnect infrastructure for cluster accounts.
    """
    try:
        cluster = get_userbot_cluster()
        for aid, client in list(cluster._clients.items()):
            # Skip the global mtproto client (it's checked separately by
            # the primary health check above; calling is_connected() on it
            # twice per cycle is harmless but redundant).
            if client is _mtproto_client:
                continue
            # Skip accounts that are already in a non-healthy state — those
            # are handled by _cluster_reconnect_loop (60s, exponential
            # backoff) which retries STATUS_CONNECTION_FAILED accounts.
            acc = cluster.get_account(aid)
            if not acc:
                continue
            st = acc.get("status", "")
            if st not in (STATUS_HEALTHY, STATUS_CONNECTED):
                continue
            try:
                ic = bool(client.is_connected())
            except Exception:  # noqa: BLE001
                ic = False
            if not ic:
                logger.warning(
                    "MTPROTO_CLUSTER_DISCONNECT_DETECTED account_id=%s "
                    "phone=%s status=%s — client.is_connected()=False; "
                    "transitioning to STATUS_CONNECTION_FAILED so "
                    "_cluster_reconnect_loop will retry (v97.93).",
                    aid, acc.get("phone", ""), st,
                )
                try:
                    cluster.update_status(aid, STATUS_CONNECTION_FAILED)
                except Exception as exc:  # noqa: BLE001
                    logger.warning(
                        "MTPROTO_CLUSTER_STATUS_UPDATE_FAILED "
                        "account_id=%s exc=%s: %s",
                        aid, type(exc).__name__, str(exc)[:80],
                    )
    except Exception as exc:  # noqa: BLE001
        logger.debug("MTPROTO_CLUSTER_HEALTH_CHECK_ERROR exc=%s", str(exc)[:80])


async def _mtproto_health_loop() -> None:
    """Periodically ping the MTProto client to confirm it's alive.

    v97.61 §4: also emits MTPROTO_GENERATION_STATE every cycle with
    active/retiring/retired counts. Per the master prompt:
    "active_generations MUST NEVER exceed 1" per logical client.

    v97.92 RUNTIME-PROVEN FIX (bot-diagnostic (4).log cascade):
      The runtime log showed the health loop detecting the disconnect at
      13:10:51 (47s after the actual disconnect at 13:10:04) but ONLY
      logging a WARNING — it did NOT trigger a reconnect. The watchdog
      (60s interval) was the sole auto-trigger, and it didn't fire until
      13:11:05. Combined, the userbot sat disconnected for over a minute.

      FIX: when the health check detects a disconnect, trigger the
      single-flight reconnect via ``_mtproto_trigger_reconnect()``
      (fire-and-forget). This complements the watchdog's event-driven
      detection — whichever fires first wins (the single-flight gate
      prevents duplicate reconnects). Interval reduced from 120s to 30s
      for faster detection.

    v97.93 RUNTIME-PROVEN FIX: also calls ``_check_cluster_clients_health()``
    (helper above) every cycle — see its docstring for the runtime
    evidence. The v97.92 loop only watched the PRIMARY client; cluster
    clients silently died without anyone noticing.
    """
    logger.info("MTProto health monitor started (interval=30s, triggers reconnect on disconnect).")
    # v99.07 FIX-12 (P0): heartbeat with the v98.05 FIX-KK worker watchdog
    # (lazy import — mtproto is imported by bootstrap at module level).
    _v9907_mhb = None
    try:
        from .bootstrap import bot_worker_register as _v9907_mreg, \
            bot_worker_heartbeat as _v9907_mhb
        _v9907_mreg("mtproto_health_loop", expected_duration=45.0)
    except Exception:  # noqa: BLE001
        _v9907_mhb = None
    while True:
        try:
            if _v9907_mhb is not None:
                _v9907_mhb("mtproto_health_loop")  # v99.07 FIX-12
            await asyncio.sleep(30)
            # TLG-D-014: skip the get_me() round-trip — is_connected() is
            # already a reliable liveness probe and get_me() can trip
            # FloodWait if the connection is flapping.
            if _mtproto_client and _mtproto_client.is_connected():
                logger.debug("MTProto health check: OK")
            elif _mtproto_started and _mtproto_client:
                # v97.92: trigger reconnect instead of just logging.
                logger.warning(
                    "MTPROTO_HEALTH_DISCONNECT_DETECTED — triggering safe reconnect (v97.92)."
                )
                try:
                    _mtproto_trigger_reconnect()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("MTPROTO_HEALTH_TRIGGER_ERROR exc=%s", str(exc)[:120])
            # v97.93: ALSO check cluster clients' connection state.
            await _check_cluster_clients_health()
            # v97.61 §4: emit generation state instrumentation.
            try:
                from .mtproto_generation import get_reconnect_coordinator
                coord = get_reconnect_coordinator()
                mgr = coord.get_generation_manager()
                stats = mgr.get_stats()
                active = 0
                retiring = 0
                retired = 0
                poisoned = 0
                for _session_key, gens in mgr._generations.items():
                    for g in gens:
                        if g.is_active():
                            active += 1
                        elif g.state is not None:
                            from .mtproto_generation import GenState
                            if g.state == GenState.RETIRING:
                                retiring += 1
                            elif g.state == GenState.RETIRED:
                                retired += 1
                            elif g.state == GenState.POISONED:
                                poisoned += 1
                # v98.06 FIX-PP (BUG-VC-GENERATION-STATE-TOTAL-SESSIONS-
                # MISLEADING, RUNTIME-PROVEN via bot-diagnostic (18+).log:
                # 45 cycles ALL logged
                # ``MTPROTO_GENERATION_STATE active=0 retiring=0 retired=0
                # poisoned=0 total_sessions=0`` while Telethon connections
                # obviously worked (43 VC joins succeeded):
                #   ``len(mgr._generations)`` counts GENERATION OBJECTS —
                #   generations are only created by
                #   ReconnectCoordinator.request_reconnect
                #   (mtproto_generation.py:601). A session with ZERO
                #   reconnects has ZERO generations — the field name
                #   "total_sessions" suggested LIVE TELETHON SESSIONS,
                #   which is flatly wrong (the log lied 45 times).
                # FIX: the field is renamed to its true meaning
                # (generation_sessions) AND a REAL live-client count
                # (live_clients = healthy cluster accounts + the connected
                # global client) is emitted alongside. The v97.61 test
                # contract (marker name MTPROTO_GENERATION_STATE in the
                # health loop) is preserved.
                _v806_live_clients = 0
                try:
                    _v806_cluster = get_userbot_cluster()
                    _v806_live_clients = len(_v806_cluster.get_healthy_accounts())
                except Exception:  # noqa: BLE001
                    pass
                try:
                    if _mtproto_client is not None and _mtproto_client.is_connected():
                        _v806_live_clients += 1
                except Exception:  # noqa: BLE001
                    pass
                logger.info(
                    "MTPROTO_GENERATION_STATE active=%d retiring=%d retired=%d "
                    "poisoned=%d generation_sessions=%d live_clients=%d",
                    active, retiring, retired, poisoned,
                    len(mgr._generations), _v806_live_clients,
                )
                if active > 1:
                    logger.error(
                        "MTPROTO_GENERATION_INVARIANT_VIOLATION active=%d > 1 — "
                        "multiple active generations for the same logical client!",
                        active,
                    )
                # v97.94 INSTRUMENT BUG-P4-1 (SOURCE-PROVEN dead code):
                # MTProtoGenerationManager.retire_generation() (mtproto_generation.py:333)
                # is DEFINED but NEVER CALLED — old generations accumulate in
                # RETIRING state forever (0 MTPROTO_GEN_RETIRED events in any
                # runtime log). This is pure observability — no behavior change.
                # When retiring > 0, log each RETIRING gen's ID + age so operators
                # can see the leak. Wiring retire_generation correctly requires
                # deeper generation-lifecycle analysis; this log proves the leak
                # exists in the next reconnect storm before attempting the fix.
                if retiring > 0:
                    import time as _time_mod_iog
                    _now_io = _time_mod_iog.monotonic()
                    # v98.02 FIX-N (ISSUE 4 — periodic sweep to retire stuck
                    # RETIRING generations, RUNTIME-CORRELATED via
                    # bot-diagnostic (15).log):
                    #   The v98.01 code at this site was observability-only
                    #   (logged MTPROTO_GEN_RETIRING_STUCK but never retired).
                    #   The primary retire path is now in
                    #   ReconnectCoordinator.request_reconnect (mtproto_generation
                    #   .py:600-663) — wired after the new gen connects. But
                    #   if a reconnect FAILS or the new gen's drain didn't
                    #   terminate an old gen's update loop, that old gen stays
                    #   RETIRING forever. This periodic sweep retires gens that
                    #   have been RETIRING for >300s — long enough that any
                    #   legitimate drain should have completed, but short
                    #   enough to prevent unbounded accumulation. The sweep
                    #   also catches gens from failed reconnects (where the
                    #   request_reconnect retire-sweep was skipped because
                    #   the reconnect_fn raised before reaching the finally).
                    _sweep_retired = 0
                    _sweep_poisoned = 0
                    for _sk, _gens in list(mgr._generations.items()):
                        for _g in list(_gens):
                            if _g.state is not None and _g.state == GenState.RETIRING:
                                _age = _now_io - getattr(_g, "created_at", _now_io)
                                logger.warning(
                                    "MTPROTO_GEN_RETIRING_STUCK gen=%s session=%s "
                                    "age=%.1fs — retire_generation() is never called "
                                    "(dead code); generation leaks in RETIRING state",
                                    getattr(_g, "generation_id", "?"),
                                    getattr(_g, "session_path", "?"),
                                    _age,
                                )
                                # v98.02 FIX-N: sweep-retire gens stuck >300s.
                                if _age > 300.0:
                                    try:
                                        _ret = await mgr.retire_generation(
                                            _g, verify_terminated=True)
                                        if _ret:
                                            _sweep_retired += 1
                                        else:
                                            _sweep_poisoned += 1
                                    except Exception as _sweep_exc:  # noqa: BLE001
                                        logger.debug(
                                            "MTPROTO_GEN_RETIRE_SWEEP_FAILED "
                                            "gen=%s exc=%s: %s",
                                            getattr(_g, "generation_id", "?"),
                                            type(_sweep_exc).__name__,
                                            str(_sweep_exc)[:80],
                                        )
                    if _sweep_retired or _sweep_poisoned:
                        logger.info(
                            "MTPROTO_GEN_RETIRE_SWEEP retired=%d poisoned=%d "
                            "— periodic sweep retired stuck RETIRING gens "
                            "(v98.02 FIX-N: bounds RETIRING accumulation)",
                            _sweep_retired, _sweep_poisoned,
                        )
            except Exception as exc:  # noqa: BLE001
                logger.debug("MTPROTO_GENERATION_STATE_ERROR exc=%s", str(exc)[:80])
        except asyncio.CancelledError:
            logger.info("MTProto health monitor cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("MTProto health check failed: %s", exc)


def _get_mtproto_reconnect_lock() -> asyncio.Lock:
    """v97.14: lazily create the global reconnect lock."""
    global _mtproto_reconnect_lock
    if _mtproto_reconnect_lock is None:
        _mtproto_reconnect_lock = asyncio.Lock()
    return _mtproto_reconnect_lock


async def _telethon_drain_and_reconnect(client: Any, *, label: str,
                                        connect_timeout: int = 15) -> bool:
    """v97.28: disconnect + DRAIN + reconnect a Telethon client.

    This is the SINGLE source of truth for the reconnect sequence used by
    both ``_mtproto_safe_reconnect`` (global client) and the download retry
    path (per-account cluster clients).  It guarantees that all of
    Telethon's background tasks (``_send_loop``, ``_recv_loop``, MTProtoSender
    send/recv, ``_update_loop``, ``_keepalive_loop``) are fully cancelled AND
    drained before ``connect()`` is called.

    The DRAIN step (``await client.disconnected``) is the critical fix for the
    v97.26 duplicate-task-set bug: the previous 5-second ``wait_for`` on
    ``disconnect()`` interrupted Telethon mid-cancellation, leaving the six
    background tasks in ``cancelling`` (not ``done``) state.  Telethon's
    ``connect()`` then saw the tasks as not-done and spawned fresh copies —
    producing the exact pattern in the v97.26 log (initial Task-31/32/33/34 +
    Task-51/52 persisting alongside a second complete set Task-32510/32511/
    32512/32513 + Task-32517/32518 after reconnect).

    v97.31: if ``client`` is a ``_GatedClientProxy``, unwraps it to get the
    raw TelegramClient, and acquires the per-cluster-client WRITE lock before
    disconnecting. This prevents concurrent RPCs on the same cluster client
    from racing with the reconnect.

    Args:
        client: The Telethon ``TelegramClient`` (or ``_GatedClientProxy``) to reconnect.
        label: Diagnostic label included in log messages.
        connect_timeout: Timeout for the ``connect()`` call (default 15s).

    Returns:
        ``True`` if the client is connected after the operation,
        ``False`` otherwise.
    """
    # v97.31: unwrap the proxy and acquire the per-cluster-client write lock.
    write_lock: _AsyncRWLock | None = None
    if isinstance(client, _GatedClientProxy):
        # Acquire the write lock so all in-flight readers (RPCs) on this
        # cluster client drain before we disconnect.
        if client._rw_lock_getter is not None:
            write_lock = await client._rw_lock_getter()
        raw_client = client._real_client
    else:
        raw_client = client

    if write_lock is not None:
        await write_lock.acquire_write(timeout=60.0)  # v98.09 §17: bounded writer wait
    try:
        return await _telethon_drain_and_reconnect_raw(
            raw_client, label=label, connect_timeout=connect_timeout)
    finally:
        if write_lock is not None:
            await write_lock.release_write()


async def _telethon_drain_and_reconnect_raw(client: Any, *, label: str,
                                            connect_timeout: int = 15) -> bool:
    """v97.31: the raw disconnect→drain→connect sequence (no lock).

    v97.52 FIX: the old code had a 10s drain timeout. If Telethon's background
    tasks didn't drain within 10s (they were stuck in `cancelling=1` state),
    the code LOGGED a warning and PROCEEDED TO CONNECT ANYWAY. This created
    a NEW set of networking tasks alongside the old stuck ones → two Telethon
    client task groups → 25-33s event-loop starvation.

    The v97.52 fix: increase drain timeout to 30s, and if drain STILL fails,
    forcibly cancel Telethon's internal task references (_update_loop_task,
    _keepalive_task, _sender) before connecting. This ensures the old client's
    tasks are fully dead before the new connection spawns fresh ones.

    v97.72 REVERT: drain timeout reduced back to 10s (the RW-lock starvation
    fix means readers release within 10s, so a 10s writer budget suffices).
    The forced-cancel path is still used as the fallback when 10s drain fails.
    """
    # 1. Disconnect with a bounded budget.
    #    v97.72 P0: the v97.70/v97.71 runtime logs showed 10-17s
    #    EVENT_LOOP_LAG_CRITICAL during reconnect with only 25-28 total tasks.
    #    Root cause: the RW write lock in _mtproto_safe_reconnect waits for
    #    ALL readers to drain. Each reader (mtproto_call_with_retry) holds the
    #    read lock for up to 30s (the RPC timeout at line 4400). So the writer
    #    can wait 30s for the last reader to finish — starving the event loop.
    #    Fix: keep the 10s disconnect timeout (v97.71) + reduce the RPC timeout
    #    in mtproto_call_with_retry from 30s to 10s (see below). This means
    #    each reader releases the read lock within 10s, so the writer doesn't
    #    wait longer than 10s.
    try:
        await asyncio.wait_for(client.disconnect(), timeout=10)
    except asyncio.TimeoutError:
        logger.warning("MTPROTO_DISCONNECT_TIMEOUT label=%s — 10s budget exceeded; "
                       "background tasks may still be cancelling", label)
    except Exception as exc:  # noqa: BLE001
        logger.debug("MTPROTO_DISCONNECT_ERROR label=%s exc=%s", label, exc)

    # 2. AWAIT the ``disconnected`` future — resolves only when ALL Telethon
    #    background tasks (send/recv/mtproto/update/keepalive) are done.
    #    v97.72: this is a pure asyncio future — it yields to the event loop
    #    and does NOT cause starvation. The 10s budget is sufficient.
    disc = getattr(client, "disconnected", None)
    if disc is not None:
        try:
            await asyncio.wait_for(disc, timeout=10)
        except asyncio.TimeoutError:
            logger.warning("MTPROTO_DISCONNECT_DRAIN_TIMEOUT label=%s — "
                           "background tasks did not drain within 10s; "
                           "forcibly cancelling Telethon internals", label)
        except Exception as exc:  # noqa: BLE001
            logger.debug("MTPROTO_DISCONNECT_DRAIN_ERROR label=%s exc=%s",
                         label, exc)

    # v97.75 P0 ARCHITECTURAL FIX (runtime-proven from production log):
    # The previous code only called _forcibly_cancel_telethon_tasks INSIDE
    # the `except asyncio.TimeoutError:` block above — i.e. ONLY when drain
    # timed out. On the HAPPY PATH (drain succeeded), forced-cancel was NEVER
    # called, so if the `disconnected` future resolved prematurely (before all
    # 6 Telethon background tasks were truly done), the old tasks survived into
    # the next connect() → multiple Telethon generations coexisted.
    #
    # The runtime log (note 45) proved this: task dumps showed Tasks 14-19
    # (Gen A: _send_loop/_recv_loop/_update_loop/_keepalive_loop) AND Tasks
    # 50-53/60-61 (Gen B: same 6 tasks) alive SIMULTANEOUSLY, then Tasks
    # 12958-13000 (Gen C) while Gen A still alive. Each generation = 6 tasks.
    # 2-3 generations = 12-18 Telethon background tasks, each spawning
    # _dispatch_update coroutines → PyTgCalls received 2-3× updates →
    # 214-task explosion (200+ pytgcalls _handle_mtproto_updates coroutines).
    #
    # FIX: make _forcibly_cancel_telethon_tasks UNCONDITIONAL — always call
    # it after drain (regardless of whether drain succeeded or timed out),
    # and verify ALL 6 Telethon background tasks are done() before connect().
    # If any task survives, mark the client POISONED and abort the reconnect.
    _client_poisoned = await _forcibly_cancel_telethon_tasks(client, label)
    if _client_poisoned:
        # v97.58 §7 / v97.75: do NOT reconnect a poisoned client — it would
        # reuse the stuck tasks and create generation coexistence. Return
        # False so the caller (the health coordinator) retires this client
        # and creates a fresh one.
        logger.error(
            "MTPROTO_RECONNECT_ABORTED label=%s — client poisoned "
            "(Telethon background tasks survived forced cancel), "
            "not reconnecting (health coordinator will recreate)",
            label,
        )
        return False

    # 3. Connect with the standard budget.
    #    v97.75: by this point ALL old Telethon background tasks are confirmed
    #    done() — connect() will spawn a fresh set with NO coexistence.
    await asyncio.wait_for(client.connect(), timeout=connect_timeout)
    # v97.79: re-snapshot after reconnect (new generation of tasks)
    _snapshot_telethon_bg_tasks(client, label=label)
    return client.is_connected()


# v97.79: CLIENT-SPECIFIC TELETHON TASK OWNERSHIP
# The v97.78 asyncio.all_tasks() approach was GLOBAL — it cancelled ALL clients'
# background tasks, including other accounts' healthy tasks. v97.79 snapshots
# the 6 task objects per client using the CORRECT Telethon attribute names
# (verified from upstream source — NOT the fictional names v97.75 used).
# forced-cancel now cancels only the snapshot, not all_tasks.
_TELETHON_TASK_ATTRS = [
    # (object_path, attr_name, human_name)
    # Telethon 1.x uses _handle suffix for task references (verified upstream)
    ("client", "_updates_handle", "update_loop"),
    ("client", "_keepalive_handle", "keepalive_loop"),
    ("sender", "_send_loop_handle", "mtprotosender_send_loop"),
    ("sender", "_recv_loop_handle", "mtprotosender_recv_loop"),
    ("conn", "_send_task", "connection_send_loop"),
    ("conn", "_recv_task", "connection_recv_loop"),
    # Fallback: also check the v97.75-era names (in case of version differences)
    ("client", "_update_loop_task", "update_loop_legacy"),
    ("client", "_keepalive_task", "keepalive_loop_legacy"),
    ("sender", "_send_loop_task", "mtprotosender_send_loop_legacy"),
    ("sender", "_recv_loop_task", "mtprotosender_recv_loop_legacy"),
]


def _snapshot_telethon_bg_tasks(client: Any, *, label: str = "") -> list:
    """v97.79: Snapshot THIS client's 6 Telethon background task objects.

    Stores the list on client._mediagrab_bg_tasks so forced-cancel can cancel
    ONLY these tasks (not other clients' tasks). Returns the list.
    """
    tasks = []
    sender = getattr(client, "_sender", None)
    conn = getattr(sender, "_connection", None) if sender is not None else None
    for obj_path, attr, human in _TELETHON_TASK_ATTRS:
        obj = {"client": client, "sender": sender, "conn": conn}.get(obj_path)
        if obj is None:
            continue
        task = getattr(obj, attr, None)
        if task is not None:
            tasks.append((task, human))
    # Deduplicate by task identity (some attrs may alias the same task)
    seen = set()
    unique = []
    for t, h in tasks:
        if id(t) not in seen:
            seen.add(id(t))
            unique.append((t, h))
    try:
        setattr(client, "_mediagrab_bg_tasks", unique)
    except Exception:  # noqa: BLE001
        pass
    if unique:
        logger.info(
            "MTPROTO_TASK_SNAPSHOT label=%s count=%d — %s",
            label, len(unique),
            ", ".join(h for _, h in unique),
        )
    return unique


async def _forcibly_cancel_telethon_tasks(client: Any, label: str) -> bool:
    """v97.79: CLIENT-SPECIFIC forced-cancel + verify.

    v97.79 ARCHITECTURAL FIX (source-proven from TRACE-TG-CLIENTS audit):
    The v97.78 asyncio.all_tasks() + __qualname__ approach was GLOBAL — it
    cancelled ALL clients\' background tasks, including other accounts\' healthy
    tasks. In a multi-account bot (primary + cluster), calling this for the
    primary would ALSO cancel the cluster client\'s tasks — a cross-client
    cancellation bug.

    v97.79 FIX: use the client-specific task snapshot stored by
    _snapshot_telethon_bg_tasks() (called after each connect()). Cancel ONLY
    the snapshot\'s tasks. If no snapshot exists (e.g. client never snapshotted),
    fall back to the v97.78 global approach with a warning.

    Returns True if poisoned (caller must abort reconnect + retire client).
    """
    # v97.79: try client-specific snapshot FIRST
    snapshot = getattr(client, "_mediagrab_bg_tasks", None)
    if snapshot is None:
        # No snapshot — client was never snapshotted (old client or connect
        # path missed the snapshot). Fall back to global approach with warning.
        logger.warning(
            "MTPROTO_FORCED_CANCEL_NO_SNAPSHOT label=%s — falling back to GLOBAL "
            "asyncio.all_tasks() (v97.78 behavior). THIS IS UNSAFE for multi-account.",
            label,
        )
        return await _forcibly_cancel_telethon_tasks_global(client, label)

    alive_tasks = [(t, h) for t, h in snapshot if not t.done()]
    if not alive_tasks:
        logger.info(
            "MTPROTO_FORCED_CANCEL_NONE_FOUND label=%s — all %d snapshotted tasks "
            "already done (client-specific)", label, len(snapshot),
        )
        return False

    logger.warning(
        "MTPROTO_FORCED_TASK_CANCEL_START label=%s alive_telethon_tasks=%d "
        "(snapshot=%d) - cancelling ONLY this client\'s tasks (v97.79 client-specific). "
        "Task details: %s",
        label, len(alive_tasks), len(snapshot),
        "; ".join(f"{h}#{id(t) % 0xffffff:06x}" for t, h in alive_tasks)[:300],
    )

    cancelled_count = 0
    for task, _human in alive_tasks:
        try:
            task.cancel(msg="v97.79_client_specific_retirement")
            cancelled_count += 1
        except Exception:  # noqa: BLE001
            pass

    # Wait for ALL cancelled tasks (single bounded wait)
    if alive_tasks:
        try:
            await asyncio.wait_for(
                asyncio.gather(*[t for t, _ in alive_tasks], return_exceptions=True),
                timeout=5.0,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "MTPROTO_FORCED_CANCEL_DRAIN_TIMEOUT label=%s - %d/%d tasks "
                "still alive after 5s grace",
                label,
                sum(1 for t, _ in alive_tasks if not t.done()),
                len(alive_tasks),
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("MTPROTO_FORCED_CANCEL_DRAIN_ERROR label=%s exc=%s", label, exc)

    if cancelled_count > 0:
        logger.warning(
            "MTPROTO_FORCED_TASK_CANCEL label=%s count=%d - "
            "forcibly cancelled Telethon background tasks (client-specific)",
            label, cancelled_count,
        )

    # VERIFY all snapshotted tasks are done()
    _survivors = []
    for task, human in snapshot:
        if not task.done():
            try:
                await asyncio.wait_for(task, timeout=2.0)
            except (asyncio.CancelledError, asyncio.TimeoutError, Exception):
                pass
            if not task.done():
                _survivors.append((task, human))

    _poisoned = len(_survivors) > 0
    if _poisoned:
        try:
            setattr(client, "_mediagrab_poisoned", True)
            setattr(client, "_mediagrab_poisoned_reason",
                    f"tasks_survived_client_specific_cancel:count={len(_survivors)}")
        except Exception:  # noqa: BLE001
            pass
        logger.error(
            "MTPROTO_CLIENT_POISONED label=%s - %d Telethon background task(s) "
            "survived client-specific forced cancel. Survivors: %s",
            label, len(_survivors),
            ", ".join(h for _, h in _survivors)[:200],
        )
    else:
        logger.info(
            "MTPROTO_FORCED_CANCEL_SUCCESS label=%s - all %d client-specific "
            "Telethon background tasks confirmed dead",
            label, cancelled_count,
        )
    # v97.93: OBSERVABILITY-ONLY orphan scan. The snapshot-based cancel above
    # can MISS orphaned Telethon bg tasks (e.g., a previous-generation
    # _update_loop stuck in cancelling=1 state). See _log_orphaned_telethon_tasks
    # for the runtime evidence. We do NOT cancel anything here — pure logging.
    await _log_orphaned_telethon_tasks(client, snapshot, label)
    return _poisoned


async def _forcibly_cancel_telethon_tasks_global(client: Any, label: str) -> bool:
    """v97.79 FALLBACK: the v97.78 global asyncio.all_tasks() approach.

    Only used when no client-specific snapshot exists. UNSAFE for multi-account
    bots because it cancels ALL clients\' tasks. Kept as a safety net.
    """
    _TELETHON_BG_CORO_NAMES = (
        "_send_loop", "_recv_loop", "_update_loop", "_keepalive_loop",
    )

    def _is_telethon_bg_task(task):
        coro = task.get_coro()
        if coro is None:
            return False
        qualname = getattr(coro, "__qualname__", "") or ""
        for name in _TELETHON_BG_CORO_NAMES:
            if qualname.endswith("." + name) or qualname == name:
                return True
        return False

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop is None:
        return False

    all_tasks = asyncio.all_tasks(loop)
    telethon_tasks = [t for t in all_tasks if _is_telethon_bg_task(t)]
    alive_telethon_tasks = [t for t in telethon_tasks if not t.done()]
    if not alive_telethon_tasks:
        return False

    logger.warning(
        "MTPROTO_FORCED_TASK_CANCEL_GLOBAL_FALLBACK label=%s alive=%d (UNSAFE multi-account)",
        label, len(alive_telethon_tasks),
    )
    for task in alive_telethon_tasks:
        try:
            task.cancel(msg="v97.79_global_fallback")
        except Exception:  # noqa: BLE001
            pass
    if alive_telethon_tasks:
        try:
            await asyncio.wait_for(
                asyncio.gather(*alive_telethon_tasks, return_exceptions=True),
                timeout=5.0,
            )
        except (asyncio.TimeoutError, Exception):
            pass
    _survivors = [t for t in alive_telethon_tasks if not t.done()]
    return len(_survivors) > 0


async def _log_orphaned_telethon_tasks(client: Any, snapshot: list,
                                        label: str) -> None:
    """v97.93 OBSERVABILITY-ONLY: log Telethon bg tasks that are alive but NOT
    in this client's snapshot.

    SOURCE-PROVEN GAP (bot-diagnostic (5).log): the v97.92 forced-cancel
    relied on the snapshot stored on ``client._mediagrab_bg_tasks``. But
    Telethon's ``client.disconnect()`` can DROP the reference to the old
    background-task attributes (e.g., ``_updates_handle = None``) before the
    cancel propagates. The orphaned task is then INVISIBLE to the next
    snapshot (which iterates via attribute names). The runtime log proved
    this: Task-52 (cluster client's _update_loop) survived in
    ``cancelling=1`` state for 40+ minutes (00:47:41 → 01:27:48) while
    every forced-cancel reported
    ``MTPROTO_FORCED_CANCEL_NONE_FOUND — all 6 snapshotted tasks already
    done (client-specific)``. The orphaned task was simply invisible to
    the snapshot.

    We CANNOT safely cancel an arbitrary Telethon bg task from
    asyncio.all_tasks() — we cannot reliably determine WHICH client it
    belongs to without inspecting ``cr_frame.f_locals["self"]``, and even
    then, cancelling a stuck ``cancelling=1`` task is a no-op in asyncio
    (the cancel was already issued). So we don't attempt cleanup here —
    we ONLY emit a diagnostic log so future operators can see the leak.

    This function is PURE OBSERVABILITY: no behavior change to the
    reconnect path, no risk of cancelling another client's healthy tasks.
    It is intentionally extracted to a separate function so the primary
    ``_forcibly_cancel_telethon_tasks`` body contains NO
    ``asyncio.all_tasks()`` call (preserving the v97.79 invariant: the
    primary path is CLIENT-SPECIFIC, never global).
    """
    try:
        loop = asyncio.get_running_loop()
        all_tasks = asyncio.all_tasks(loop)
        snapshot_ids = {id(t) for t, _ in snapshot}
        # v97.97 FIX (BUG-6): exclude tasks belonging to the KNOWN-LIVE global
        # _mtproto_client (was a false-positive at shutdown when PRIMARY global
        # client stays running; bot-diagnostic (9).log 17:37:08 count=6).
        _global_is_live = (
            _mtproto_started and _mtproto_client is not None
            and client is not _mtproto_client
            and not getattr(_mtproto_client, "_mediagrab_poisoned", False)
            and _mtproto_client.is_connected()
        )
        _known_global_ids: set = set()
        if _global_is_live:
            _gsnap = getattr(_mtproto_client, "_mediagrab_bg_tasks", None)
            if _gsnap:
                _known_global_ids = {id(t) for t, _ in _gsnap}
        _orphans = []
        for t in all_tasks:
            if t.done():
                continue
            if id(t) in snapshot_ids or id(t) in _known_global_ids:
                continue
            coro = t.get_coro()
            if coro is None:
                continue
            qn = getattr(coro, "__qualname__", "") or ""
            if not (qn.endswith("._update_loop") or qn.endswith("._keepalive_loop")
                    or qn.endswith("._send_loop") or qn.endswith("._recv_loop")
                    or qn == "_update_loop" or qn == "_keepalive_loop"
                    or qn == "_send_loop" or qn == "_recv_loop"):
                continue
            # Try to determine the owner client via the coro's first frame locals.
            _owner = "?"
            _owner_client: Any = None
            try:
                _fr = getattr(coro, "cr_frame", None)
                if _fr is not None:
                    _self = _fr.f_locals.get("self")
                    _owner_client = _self
                    if _self is client:
                        _owner = "this_client"
                    elif _self is _mtproto_client:
                        _owner = "global_mtproto_client"
                    elif _self is not None and _self is not client:
                        _owner = f"other_client id={id(_self) % 0xffffff:06x}"
            except Exception:  # noqa: BLE001
                pass
            # v97.97: also skip if owner is the known-live global client
            # (defensive — handles edge cases where the snapshot was lost).
            if _owner_client is _mtproto_client and _global_is_live:
                continue
            try:
                _cancelling = getattr(t, "_cancelling", 0)
            except Exception:  # noqa: BLE001
                _cancelling = 0
            _orphans.append(
                f"{qn}#{id(t) % 0xffffff:06x} owner={_owner} cancelling={_cancelling}"
            )
        if _orphans:
            logger.warning(
                "MTPROTO_ORPHAN_TELETHON_TASKS_DETECTED label=%s count=%d — "
                "Telethon bg tasks alive, NOT in this client's snapshot, NOT "
                "belonging to the known-live global _mtproto_client (v97.97 "
                "excludes global client tasks). Likely leaks from PRIOR "
                "reconnects/disconnects where Telethon dropped the attribute "
                "before cancel propagated. OBSERVABILITY-ONLY (v97.93; v97.97 "
                "false-positive fix). Tasks: %s",
                label, len(_orphans),
                "; ".join(_orphans)[:400],
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("MTPROTO_ORPHAN_SCAN_ERROR label=%s exc=%s", label, str(exc)[:80])


def _mtproto_is_client_poisoned(client: Any) -> bool:
    """v97.58 §7: check whether a client was marked poisoned (update loop survived
    forced cancel). Poisoned clients must NEVER be used for new RPCs — the health
    coordinator must retire + recreate them.
    """
    return bool(getattr(client, "_mediagrab_poisoned", False))


# v97.76 P0 — STRICT SINGLE-FLIGHT RECONNECT TASK (runtime-proven root cause):
# The v97.75 runtime log (note 46) proved that 4 fire-and-forget call sites
# (voicechat.py:7960/8391/8499/8525) each did:
#     supervised_create_task(_mtproto_safe_reconnect(), name="mtproto_safe_reconnect")
# This created a NEW asyncio.Task per trigger. Even though ReconnectCoordinator
# made the UNDERLYING reconnect single-flight (one operation), the TASKS
# themselves accumulated. Runtime proof: task dumps showed 11 simultaneous
# `mtproto_safe_reconnect` tasks (line 858-868) and 14+ later (line 1192-1205),
# all awaiting `coord.request_reconnect()`.
#
# The fix: a SINGLE shared task. All callers converge on `_mtproto_trigger_reconnect()`
# which creates the task only if none exists. At any instant: 0 or 1 reconnect task.
_mtproto_reconnect_shared_task: Any = None  # asyncio.Task | None


async def _mtproto_safe_reconnect_shared_runner() -> bool:
    """v97.76: the shared reconnect runner — clears the shared task ref on exit.

    This wrapper ensures the module-level `_mtproto_reconnect_shared_task` is
    cleared when the reconnect completes (success or failure), so the NEXT
    trigger can start a fresh task. All callers await the SAME task instance.
    """
    global _mtproto_reconnect_shared_task
    try:
        return await _mtproto_safe_reconnect()
    finally:
        # Clear the shared ref ONLY if we're still the current task
        # (a newer trigger may have already swapped in a new task after
        # we started but before we finished — unlikely but race-safe).
        _current = asyncio.current_task()
        if _mtproto_reconnect_shared_task is _current:
            _mtproto_reconnect_shared_task = None


def _mtproto_trigger_reconnect() -> None:
    """v97.76 P0: fire-and-forget reconnect trigger with STRICT SINGLE-FLIGHT.

    Creates the shared reconnect task if none is in-flight. If one is already
    running, this is a NO-OP (does NOT create a new task). This is the
    architectural fix for the reconnect-storm root cause proven in note 46.

    At any instant: 0 or 1 reconnect task exists. Compare to v97.75 which
    allowed N tasks (one per trigger) to accumulate.

    Use this instead of `supervised_create_task(_mtproto_safe_reconnect(), ...)`
    at ALL fire-and-forget reconnect trigger sites.
    """
    global _mtproto_reconnect_shared_task
    existing = _mtproto_reconnect_shared_task
    if existing is not None and not existing.done():
        # A reconnect is already in-flight — do NOT create a new task.
        # This is the single-flight gate that v97.75 was missing.
        logger.info(
            "MTPROTO_RECONNECT_SHARED_SKIP — shared reconnect task already in-flight "
            "(v97.76 single-flight); trigger is a no-op"
        )
        return
    # Create ONE shared task. supervised_create_task adds it to _active_tasks
    # (strong ref) + attaches a done-callback that logs exceptions.
    try:
        from .utils_real import supervised_create_task
        _mtproto_reconnect_shared_task = supervised_create_task(
            _mtproto_safe_reconnect_shared_runner(),
            name="mtproto_safe_reconnect_shared",
        )
        logger.info(
            "MTPROTO_RECONNECT_SHARED_START — created shared reconnect task (v97.76)"
        )
    except RuntimeError:
        # No running event loop — can't create a task. Log + fall back to
        # the old fire-and-forget pattern (the coordinator will deduplicate).
        logger.warning("MTPROTO_RECONNECT_SHARED_NO_LOOP — cannot create shared task")


async def _mtproto_safe_reconnect() -> bool:
    """v97.29/v97.60: safely reconnect _mtproto_client with full quiescence.

    v97.60 AUTHORITATIVE SINGLE-FLIGHT: this function now delegates to the
    ReconnectCoordinator (mtproto_generation.py). ALL reconnect callers —
    watchdog, health loop, cluster reconnect, manual reconnect, Join-All
    recovery — MUST call this function. The coordinator ensures:
      - ONE in-flight reconnect per session (concurrent callers await the same future)
      - Bounded + jittered backoff (network-unreachable → longer backoff)
      - Generation tracking (old generation marked RETIRING, new generation created)
      - Result caching (a 2nd caller within 30s of success gets the cached result)

    The actual drain+connect logic is preserved as the coordinator's
    ``reconnect_fn`` — the v97.29 RW-write-lock + v97.28 drain sequence is
    unchanged. The coordinator WRAPS it with single-flight + backoff.

    Sequence (inside reconnect_fn):
      1. Acquire RW WRITE lock (waits for all in-flight RPCs to finish).
      2. disconnect → drain → connect (v97.28 helper).
      3. Release WRITE lock (new RPCs proceed on the fresh client).
      4. Verify authorization (is_user_authorized + get_me).
    """
    global _mtproto_last_reconnect_at, _mtproto_generation
    if _mtproto_client is None:
        return False
    if _mtproto_client.is_connected():
        return True  # already connected — no-op

    # v97.60: delegate to the authoritative ReconnectCoordinator.
    from .mtproto_generation import (
        get_reconnect_coordinator, classify_failure, NetworkFailureClass,
    )

    async def _reconnect_fn(gen) -> bool:
        """The actual drain+connect, wrapped with RW write lock + generation bump."""
        global _mtproto_generation
        # v97.28: bump generation BEFORE the (slow) drain+reconnect so a
        # concurrent mtproto_start can detect that a reconnect happened.
        _mtproto_generation += 1
        # v97.82 instrumentation: log reconnect begin with generation + VC context
        try:
            _vc_active = 0
            _join_run = ""
            from . import voicechat as _vc_mod
            if hasattr(_vc_mod, "_vc_state"):
                _vc_active = 1 if getattr(_vc_mod._vc_state, "current_call_id", None) else 0
            _join_run = str(getattr(_vc_mod, "_vc_join_all_state", {}).get("run_id", ""))
        except Exception:  # noqa: BLE001
            pass
        logger.info(
            "MTPROTO_RECONNECT_BEGIN key=primary generation=%d vc_active=%d join_run_id=%s",
            _mtproto_generation, _vc_active, _join_run or "none",
        )
        logger.info("MTPROTO_GENERATION_CHANGED key=primary generation=%d", _mtproto_generation)
        # v98.02 FIX-Q (BUG-A5-5b — set gen.client=_mtproto_client in
        # _reconnect_fn, SOURCE-PROVEN via A5 subagent audit):
        #   The ReconnectCoordinator.request_reconnect at mtproto_generation.py:594
        #   calls create_generation(session_path=..., account_id=...) but does
        #   NOT pass client=_mtproto_client. So gen.client=None. Then
        #   retire_generation's verify_terminated gate at mtproto_generation.py:346
        #   (`if verify_terminated and gen.client is not None:`) is silently
        #   SKIPPED because gen.client is None. This means retire_generation
        #   can't verify the update loop terminated — it just marks RETIRED
        #   without checking.
        #   FIX-Q: _reconnect_fn receives `gen` as a parameter (set by
        #   request_reconnect at mtproto_generation.py:675). Set gen.client =
        #   _mtproto_client here so retire_generation's verify_terminated gate
        #   can read gen.client._mediagrab_bg_tasks and properly verify the
        #   update loop terminated before marking RETIRED.
        try:
            if gen is not None and _mtproto_client is not None:
                gen.client = _mtproto_client
                # Also snapshot the bg tasks so retire_generation has the
                # snapshot available when it reads gen.client._mediagrab_bg_tasks.
                _snapshot_telethon_bg_tasks(_mtproto_client, label="mtproto_safe_reconnect")
        except Exception:  # noqa: BLE001
            pass
        _write_lock_held = False
        rw = _get_mtproto_rw_lock()
        await rw.acquire_write(timeout=60.0)  # v98.09 §17: bounded writer wait
        _write_lock_held = True
        try:
            ok = await _telethon_drain_and_reconnect_raw(
                _mtproto_client, label="mtproto_safe_reconnect")
        finally:
            if _write_lock_held:
                try:
                    await rw.release_write()
                except Exception:  # noqa: BLE001
                    pass
                _write_lock_held = False
        if ok:
            # Verify authorization — a connected client that isn't authorized
            # is NOT a successful reconnect.
            try:
                authorized = await asyncio.wait_for(
                    _mtproto_client.is_user_authorized(), timeout=10)
            except Exception:  # noqa: BLE001
                authorized = False
            if authorized:
                _mtproto_stats["reconnects"] += 1
                _mtproto_last_reconnect_at = time.monotonic()
                logger.info(
                    "MTPROTO_RECONNECT_SUCCESS key=primary generation=%d vc_active=%d join_run_id=%s",
                    _mtproto_generation, _vc_active, _join_run or "none",
                )
                # v98.02 FIX-O (ISSUE 5 — post-MTProto-reconnect VC recovery,
                # RUNTIME-CORRELATED via bot-diagnostic (15).log):
                #   The v98.01 code returned True here WITHOUT triggering
                #   any VC recovery. bot-diagnostic (15).log showed
                #   "6 reconnects in 5 minutes" (11:40:15-11:45:43) with
                #   NO active rejoin of targets skipped during the outage. The reconcile path ran
                #   passively but only did checks — it didn't actively rejoin
                #   chats that were joined before the outage. By the time the
                #   reconcile loop's next cycle ran (60s later per
                #   voicechat.py:6864-6885), 5 chats had been falsely declared
                #   ABSENT (FIX-L prevents this) and destructively cleaned up.
                #   FIX-O: fire-and-forget vc_reconcile_participations()
                #   immediately after reconnect success. This refreshes
                #   per-target state, marks LEFT records (clears stale
                #   coordinator JOINED state), and cleans stale container
                #   objects. The next reconcile cycle then actively rejoins
                #   any targets that should still be joined. This is
                #   non-blocking (fire-and-forget via supervised_create_task).
                #   Per the user's directive #5: "Post-MTProto-reconnect VC
                #   recovery so targets skipped during outages are automatically
                #   restored."
                try:
                    from .utils_real import supervised_create_task
                    from . import voicechat as _vc_mod_post
                    if hasattr(_vc_mod_post, "vc_reconcile_participations"):
                        supervised_create_task(
                            _vc_mod_post.vc_reconcile_participations(),
                            name="post_reconnect_vc_reconcile",
                        )
                        logger.info(
                            "MTPROTO_POST_RECONNECT_VC_RECONCILE_TRIGGERED — "
                            "fire-and-forget vc_reconcile_participations() "
                            "to refresh per-target state after reconnect "
                            "(v98.02 FIX-O: restores targets skipped during "
                            "outage)"
                        )
                except Exception as _vc_trigger_exc:  # noqa: BLE001
                    logger.debug(
                        "MTPROTO_POST_RECONNECT_VC_RECONCILE_FAILED exc=%s: %s",
                        type(_vc_trigger_exc).__name__,
                        str(_vc_trigger_exc)[:120],
                    )
                return True
            else:
                logger.error("MTPROTO_RECONNECT_AUTH_FAILED — connected but not authorized")
                return False
        else:
            logger.error(
                "MTPROTO_RECONNECT_FAILED key=primary generation=%d — still not connected",
                _mtproto_generation,
            )
            _mtproto_last_reconnect_at = time.monotonic()
            return False

    # Determine the failure class for backoff selection. If the client's last
    # error was network-unreachable, use longer backoff.
    _fail_cls = NetworkFailureClass.UNKNOWN
    try:
        if _mtproto_client is not None and not _mtproto_client.is_connected():
            # We don't have the original exception; classify as disconnected.
            _fail_cls = NetworkFailureClass.DISCONNECTED
    except Exception:  # noqa: BLE001
        pass

    coord = get_reconnect_coordinator()
    # The session path is the global mtproto session.
    _session = str(getattr(_mtproto_client, "session", None) or "/tmp/mtproto.session")
    return await coord.request_reconnect(
        session_path=_session,
        account_id="primary",
        reconnect_fn=_reconnect_fn,
        failure_class=_fail_cls,
    )


async def _mtproto_watchdog_loop() -> None:
    """Watchdog — if the client disconnects, attempt reconnection.

    v97.14: uses _mtproto_safe_reconnect() with a global lock + 30s cooldown
    to prevent the reconnect storm that caused 650+ stale Telethon tasks.

    v97.92 RUNTIME-PROVEN FIX (bot-diagnostic (4).log cascade 12:37→13:17):
      The runtime log showed a 61-second delay between the server closing
      the connection (13:10:04 [Errno 103]) and the watchdog triggering
      the reconnect (13:11:05). The 60s ``asyncio.sleep`` meant the
      watchdog could be unlucky and miss the disconnect for up to 60s.
      Combined with the 5.62s EVENT_LOOP_LAG_HIGH that further delayed
      the loop, the userbot sat disconnected for over a minute — long
      enough for Telegram to invalidate the PyTgCalls sessions and drop VC.

      FIX: (1) reduce the poll interval from 60s to 10s — a 6x improvement
      in worst-case detection latency. (2) Use ``_mtproto_trigger_reconnect()``
      (fire-and-forget, single-flight) instead of ``await _mtproto_safe_reconnect()``
      so the watchdog loop keeps monitoring instead of blocking on the
      reconnect's 15s connect timeout. The single-flight gate in
      ``_mtproto_trigger_reconnect`` prevents duplicate reconnects even if
      the watchdog + health loop + cluster reconnect loop all fire at once.
    """
    logger.info("MTProto watchdog started (interval=10s, fire-and-forget single-flight reconnect).")
    # v98.12 §11 (WATCHDOG ADAPTIVE CADENCE — the (6).log 25-min outage
    # produced 72 disconnect-detection warnings at the fixed 10s+5s cadence
    # while every reconnect attempt failed with a connect TimeoutError):
    # during a SUSTAINED outage the watchdog's job is only to keep the
    # single-flight reconnect fed — it does not need to poll at 10s. After
    # 6 consecutive disconnected polls (~90s of outage) the poll interval
    # widens to 30s until the client recovers, cutting trigger noise +
    # log spam by 3x while the coordinator's own backoff (now long-ladder
    # for NETWORK_UNREACHABLE, v98.12 mtproto_generation.py) governs the
    # actual attempt cadence. Detection latency for the FIRST disconnect
    # stays at 10s (the counter starts at 0 → first 6 polls are fast).
    _v9812_wd_consec_disc = 0
    # v99.07 FIX-12 (P0): heartbeat with the v98.05 FIX-KK worker watchdog.
    _v9907_whb = None
    try:
        from .bootstrap import bot_worker_register as _v9907_wreg, \
            bot_worker_heartbeat as _v9907_whb
        _v9907_wreg("mtproto_watchdog_loop", expected_duration=30.0)
    except Exception:  # noqa: BLE001
        _v9907_whb = None
    while True:
        try:
            _v9812_wd_interval = 30.0 if _v9812_wd_consec_disc >= 6 else 10.0
            if _v9907_whb is not None:
                _v9907_whb("mtproto_watchdog_loop")  # v99.07 FIX-12
            await asyncio.sleep(_v9812_wd_interval)
            if _mtproto_started and _mtproto_client and not _mtproto_client.is_connected():
                _v9812_wd_consec_disc += 1
                logger.warning(
                    "MTPROTO_WATCHDOG_DISCONNECT_DETECTED streak=%d interval=%.0fs — triggering safe reconnect (v97.92; v98.12 §11 adaptive cadence).",
                    _v9812_wd_consec_disc, _v9812_wd_interval,
                )
                try:
                    _mtproto_trigger_reconnect()
                except Exception as exc:  # noqa: BLE001
                    logger.warning("MTPROTO_WATCHDOG_TRIGGER_ERROR exc=%s", str(exc)[:120])
                # Give the reconnect some time to make progress before re-triggering.
                await asyncio.sleep(5)
            else:
                if _v9812_wd_consec_disc >= 6:
                    logger.info(
                        "MTPROTO_WATCHDOG_RECOVERED streak=%d — restoring 10s poll interval (v98.12 §11)",
                        _v9812_wd_consec_disc,
                    )
                _v9812_wd_consec_disc = 0
        except asyncio.CancelledError:
            logger.info("MTProto watchdog cancelled.")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("MTProto watchdog error: %s", exc)
            await asyncio.sleep(5)


# v97.64 §3: track which clients have been wrapped to avoid double-wrapping.
_mtproto_wrapped_clients: set[int] = set()


def _wrap_get_entity_disconnect_safe(client: Any) -> None:
    """v97.64 §3: wrap a Telethon client's get_entity to be disconnect-safe.

    PyTgCalls' on_update handler calls `await self._app.get_entity(...)` which
    raises ConnectionResetError during MTProto disconnect — producing 13
    unhandled exceptions in the runtime log. We can't modify PyTgCalls, but we
    CAN wrap the Telethon client's get_entity method to catch disconnect errors
    and return None instead of raising. PyTgCalls' on_update will receive None
    and skip the update gracefully (its code checks for None entities).

    This is idempotent — wrapping the same client twice is a no-op.
    """
    try:
        client_id = id(client)
        if client_id in _mtproto_wrapped_clients:
            return  # already wrapped
        _original_get_entity = client.get_entity
        if not asyncio.iscoroutinefunction(_original_get_entity):
            return  # not a coroutine — can't wrap

        async def _safe_get_entity(*args, **kwargs):
            try:
                if not client.is_connected():
                    logger.debug(
                        "MTPROTO_GET_ENTITY_SKIPPED_DISCONNECTED — "
                        "PyTgCalls/caller get_entity deferred (client disconnected)"
                    )
                    return None
                return await _original_get_entity(*args, **kwargs)
            except (ConnectionResetError, ConnectionAbortedError,
                    ConnectionError) as exc:
                logger.debug(
                    "MTPROTO_GET_ENTITY_DISCONNECT_ERROR exc=%s: %s — "
                    "returning None instead of raising (PyTgCalls-safe)",
                    type(exc).__name__, str(exc)[:80],
                )
                return None
            except asyncio.TimeoutError:
                logger.debug("MTPROTO_GET_ENTITY_TIMEOUT — returning None")
                return None

        client.get_entity = _safe_get_entity  # type: ignore[method-assign]
        _mtproto_wrapped_clients.add(client_id)
        logger.info("MTPROTO_GET_ENTITY_WRAPPED — disconnect-safe wrapper installed (§3)")
    except Exception as exc:  # noqa: BLE001
        logger.debug("MTPROTO_GET_ENTITY_WRAP_FAILED exc=%s", str(exc)[:80])


async def _mtproto_register_handlers() -> None:
    """Register Telethon event handlers (self-destruct media capture)."""
    global _mtproto_self_destruct_registered
    if _mtproto_self_destruct_registered or _mtproto_client is None:
        return

    from telethon import events

    # v97.64 §3: wrap get_entity with a disconnect-aware version. PyTgCalls'
    # on_update handler calls self._app.get_entity() which raises
    # ConnectionResetError during MTProto disconnect — producing 13 unhandled
    # exceptions in the runtime log. We can't modify PyTgCalls, but we CAN
    # wrap the Telethon client's get_entity to return a sentinel + log instead
    # of raising. This prevents the unhandled exception from propagating.
    _wrap_get_entity_disconnect_safe(_mtproto_client)

    # v97.70 P0: add a func filter to the event registration so Telethon does NOT
    # create _dispatch_update tasks for non-self-destruct messages. The v97.69
    # runtime log showed 856 total_tasks at a 13.95s EVENT_LOOP_LAG_CRITICAL —
    # ~800 were _dispatch_update tasks for irrelevant messages. The previous
    # v97.63 fix filtered INSIDE the handler, but Telethon had ALREADY created
    # a task for each message. The func filter runs BEFORE task creation,
    # eliminating ~99% of dispatch tasks.
    def _self_destruct_filter(event):
        """Telethon calls this BEFORE creating a dispatch task. Returns True
        only for messages with self-destruct media — preventing task creation
        for the 99% of messages that are irrelevant."""
        try:
            message = getattr(event, "message", None)
            if message is None:
                return False
            if not getattr(message, "media", None):
                return False
            return _mtproto_is_self_destruct(message)
        except Exception:  # noqa: BLE001
            return False

    @_mtproto_client.on(events.NewMessage(incoming=True, func=_self_destruct_filter))
    async def _on_new_message(event):  # type: ignore[no-untyped-def]
        # v97.63 §1/§11: FILTER at the ingress — only self-destruct media
        # needs capture processing. The runtime log showed mtproto_capture
        # queue-full with parked=214 because EVERY incoming message was
        # enqueued. This is observational telemetry — it must NOT starve
        # operational VC commands. Filter here so only relevant events reach
        # the queue.
        # v97.70: the func filter above already eliminated non-self-destruct
        # messages BEFORE task creation. This handler only runs for the ~1%
        # that pass the filter.
        try:
            # v97.51: enqueue to bounded queue instead of inline processing.
            from .voicechat import _vc_callback_enqueue
            _vc_callback_enqueue(
                lambda ev: mtproto_handle_incoming_message(ev, _mtproto_client),
                event, "mtproto_capture",
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("mtproto capture handler error: %s", exc)

    _mtproto_self_destruct_registered = True
    logger.info("MTProto self-destruct capture handler registered.")


# --- mtproto_capture -------------------------------------------------------


def _mtproto_is_self_destruct(message) -> bool:
    """True if the message carries self-destructing (timer) media."""
    media = getattr(message, "media", None)
    if media is None:
        return False
    photo = getattr(media, "photo", None)
    if photo and getattr(photo, "ttl_seconds", None):
        return True
    doc = getattr(media, "document", None)
    if doc:
        if getattr(media, "ttl_seconds", None):
            return True
        from telethon.tl.types import DocumentAttributeVideo
        for attr in getattr(doc, "attributes", []) or []:
            if isinstance(attr, DocumentAttributeVideo) and getattr(media, "ttl_seconds", None):
                return True
    return getattr(media, "ttl_seconds", None) is not None


def _mtproto_media_kind(message) -> str:
    """Return 'photo' | 'video' | 'document' for the message media."""
    media = getattr(message, "media", None)
    if media is None:
        return "none"
    if getattr(media, "photo", None):
        return "photo"
    doc = getattr(media, "document", None)
    if doc:
        from telethon.tl.types import DocumentAttributeVideo, DocumentAttributeAnimated
        for attr in getattr(doc, "attributes", []) or []:
            if isinstance(attr, DocumentAttributeVideo):
                if getattr(attr, "round_message", False):
                    return "video_note"
                return "video"
            if isinstance(attr, DocumentAttributeAnimated):
                return "gif"
        return "document"
    return "unknown"


async def mtproto_handle_incoming_message(event, client) -> None:
    """Telethon NewMessage handler — captures self-destruct media."""
    message = event.message
    if not _mtproto_is_self_destruct(message):
        return

    sender = await event.get_sender()
    sender_name = (getattr(sender, "username", None)
                   or f"{getattr(sender, 'first_name', '')} {getattr(sender, 'last_name', '')}".strip()
                   or str(getattr(sender, "id", "unknown")))
    sender_id = getattr(sender, "id", "unknown")
    kind = _mtproto_media_kind(message)
    ttl = getattr(message.media, "ttl_seconds", "?")

    # Try to get chat info for the admin notification.
    chat_info = await _mtproto_get_chat_info(event, client)

    logger.info("Self-destruct %s captured from @%s (id=%s, ttl=%ss)",
                kind, sender_name, sender_id, ttl)

    out_dir = config.downloads_dir / "self_destruct"
    out_dir.mkdir(parents=True, exist_ok=True)
    timestamp = int(time.time())
    base_name = f"sd_{kind}_{sender_id}_{timestamp}"
    target = unique_path(out_dir, base_name)

    try:
        path = await client.download_media(message, file=str(target))
        if not path:
            logger.warning("Self-destruct download returned no path.")
            return
        path = Path(path)
        size = path.stat().st_size if path.exists() else 0
        logger.info("Self-destruct media saved: %s (%d bytes)", path.name, size)

        await _mtproto_notify_admin(
            path, sender_name, sender_id, kind, ttl, message, chat_info
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("Self-destruct capture failed: %s", exc)


async def _mtproto_get_chat_info(event, client) -> dict:
    """Extract chat metadata for the admin notification."""
    info: dict = {}
    try:
        chat = await event.get_chat()
        info["chat_id"] = getattr(chat, "id", None)
        info["chat_title"] = (getattr(chat, "title", None)
                              or getattr(chat, "first_name", None)
                              or getattr(chat, "username", None)
                              or str(info.get("chat_id", "unknown")))
        info["chat_type"] = type(chat).__name__
    except Exception as exc:  # noqa: BLE001
        logger.debug("Could not get chat info: %s", exc)
    return info


async def _mtproto_notify_admin(path: Path, sender_name: str, sender_id: int,
                                kind: str, ttl: Any, message,
                                chat_info: dict | None = None) -> None:
    """Send the captured media to the admin via the Bot API.

    Uses the bot registry (``get_bot``) to obtain the running Bot instance —
    NOT ``Application.get_application()`` which doesn't exist. Includes
    sender info, chat info, timestamps, and filename.
    """
    admin_id = config.mtproto_admin_id
    if not admin_id:
        logger.debug("No MTPROTO_ADMIN_ID set — skipping admin notification.")
        return

    bot = get_bot()
    if bot is None:
        logger.warning(
            "Bot instance not registered yet — cannot notify admin. "
            "Ensure register_bot(app.bot) is called in _post_init."
        )
        return

    # Build a rich caption with all available metadata.
    capture_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    msg_date = getattr(message, "date", None)
    msg_ts = msg_date.strftime("%Y-%m-%d %H:%M:%S UTC") if msg_date else "—"

    chat_info = chat_info or {}
    chat_title = md_escape(chat_info.get("chat_title", "—"))
    chat_id = chat_info.get("chat_id", "—")
    chat_type = chat_info.get("chat_type", "—")

    caption = (
        f"📸 *Self-destruct media captured*\n\n"
        f"👤 *From:* @{md_escape(sender_name)} (`{sender_id}`)\n"
        f"💬 *Chat:* {chat_title} (`{chat_id}`)\n"
        f"🗂 *Chat type:* {chat_type}\n"
        f"🎞 *Media type:* {kind}\n"
        f"⏱ *TTL:* {ttl}s\n"
        f"📅 *Message time:* {msg_ts}\n"
        f"🕒 *Captured at:* {capture_ts}\n"
        f"📦 *File:* `{md_escape(path.name)}`"
    )

    try:
        size = path.stat().st_size if path.exists() else 0
        if size <= config.upload_limit_bytes:
            with path.open("rb") as fh:
                await safe_send_document(
                    bot, admin_id, fh,
                    filename=path.name,
                    caption=caption,
                )
            logger.info("Self-destruct media sent to admin %s (%d bytes)",
                        admin_id, size)
            # SEC-D-005: the file has been delivered to the admin — remove
            # it from disk so self-destruct media doesn't accumulate.
            try:
                path.unlink(missing_ok=True)
            except Exception as cleanup_exc:  # noqa: BLE001
                logger.warning("Failed to delete self-destruct media %s: %s",
                               path, cleanup_exc)
        else:
            await safe_send_message(
                bot, admin_id,
                caption + "\n\n_ℹ️ File too large to send via Bot API — "
                "saved on server._",
            )
            logger.info("Self-destruct media too large for Bot API — "
                        "admin notified, file saved on server.")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Admin notification failed: %s", exc)


async def mtproto_take_screenshot(chat_ref: str | int) -> Path | None:
    """Capture a screenshot of a chat's recent messages (MTProto).

    V85 FIX: previously this called ``client.get_entity(chat_ref)`` directly,
    which throws ``ValueError: Cannot find any entity corresponding to
    "https://t.me/.../123"`` for any URL containing a message-id suffix.
    Now we route through the unified ``resolve_message_link`` /
    ``EntityResolver`` pipeline so public links, private ``/c/`` links,
    numeric IDs, and ``@username`` forms all resolve correctly.
    """
    try:
        client = mtproto_get_client()
        if client is None:
            logger.warning("MTProto not started — cannot take screenshot.")
            return None
    except Exception as exc:  # noqa: BLE001
        logger.warning("Cannot get MTProto client for screenshot: %s", exc)
        return None

    try:
        # V85: unified entity resolution. Falls back gracefully to legacy
        # client.get_entity() if the new pipeline is unavailable for any
        # reason (defensive — never breaks the existing path).
        entity = None
        try:
            entity = await _resolve_message_link_bootstrap(chat_ref, client=client)
        except Exception as exc:  # noqa: BLE001
            logger.debug("resolve_message_link fallback to get_entity: %s", exc)
        if entity is None:
            try:
                entity = await resolve_entity_full(client, chat_ref)
            except Exception:
                try:
                    entity = await client.get_entity(chat_ref)
                except Exception:
                    entity = None
        if entity is None:
            logger.warning("SCREENSHOT_ENTITY_UNRESOLVED chat_ref=%s", str(chat_ref)[:120])
            return None
        messages = await client.get_messages(entity, limit=15)
        lines = [f"📱 Screenshot of {getattr(entity, 'title', str(chat_ref))}", ""]
        for m in reversed(messages):
            # TLG-D-015: get_messages() pre-fetches the sender entity, so
            # use m.sender instead of awaiting m.get_sender() (extra RPC).
            # Fall back to the RPC only if the pre-fetched value is missing.
            sender = m.sender
            if sender is None:
                try:
                    sender = await m.get_sender()
                except Exception:
                    sender = None
            name = (getattr(sender, "first_name", None)
                    or getattr(sender, "title", None)
                    or getattr(sender, "username", None)
                    or str(getattr(sender, "id", "?")))
            text = m.text or "(media)"
            ts = m.date.strftime("%H:%M") if m.date else "?"
            lines.append(f"[{ts}] {name}: {text[:120]}")
        content = "\n".join(lines)

        from PIL import Image, ImageDraw, ImageFont
        import textwrap

        img = Image.new("RGB", (800, 600), color=(30, 30, 30))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14
            )
        except Exception:  # noqa: BLE001
            font = ImageFont.load_default()

        y = 10
        for line in content.split("\n"):
            for wrapped in textwrap.wrap(line, width=70) or [""]:
                draw.text((10, y), wrapped, fill=(220, 220, 220), font=font)
                y += 18
                if y > 580:
                    break
            if y > 580:
                break

        out_dir = config.frames_dir
        # v97 FIX: offload mkdir + PIL img.save to a thread — PIL PNG
        # compression + disk write can block the event loop for 100ms+.
        def _save_screenshot_sync() -> Path:
            out_dir.mkdir(parents=True, exist_ok=True)
            out = unique_path(out_dir, f"screenshot_{int(time.time())}.png")
            img.save(str(out), "PNG")
            return out
        out = await asyncio.to_thread(_save_screenshot_sync)
        logger.info("Screenshot saved: %s", out.name)
        return out
    except Exception as exc:  # noqa: BLE001
        logger.exception("Screenshot failed: %s", exc)
        return None


# --- mtproto_service -------------------------------------------------------


class MTProtoError(Exception):
    """User-facing error from the MTProto backend."""


class MTProtoNotAvailable(MTProtoError):
    """Raised when MTProto is disabled or not started."""


def _mtproto_require_client():
    """Return the active Telethon client or raise."""
    client = mtproto_get_client()
    if client is None:
        raise MTProtoNotAvailable(
            "MTProto backend is not running. Enable MTPROTO_ENABLED in .env "
            "and create a session first."
        )
    return client


def mtproto_service_is_available() -> bool:
    """True if MTProto is enabled, installed, and connected."""
    return mtproto_is_started()


async def mtproto_resolve_entity(chat_ref: str | int) -> dict[str, Any]:
    """Resolve a @username or chat id to a plain dict via MTProto.

    V85: routes through ``resolve_message_link`` first so message links
    (``https://t.me/<chan>/<msg_id>`` and ``https://t.me/c/<id>/<msg_id>``)
    resolve correctly instead of raising the legacy
    ``Cannot find any entity corresponding to "https://..."`` error.

    v97.25: try ALL healthy cluster accounts (not just the global client)
    when resolving the entity.  This fixes the case where the global client
    cannot resolve @Sanskari_bookbot (a bot/user it never interacted with)
    but a cluster account CAN (because it has a dialog with that bot).
    """
    from telethon.errors import UsernameInvalidError, ChannelInvalidError

    # v97.25: collect candidate clients — same as mtproto_download_message_media.
    _candidates: list[tuple[str, Any]] = []
    try:
        cluster = get_userbot_cluster()
        healthy = cluster.get_healthy_accounts()
        for acc in healthy:
            aid = acc.get("account_id")
            if aid:
                c = cluster.get_client(aid)
                if c is not None and c.is_connected():
                    _candidates.append((aid, c))
    except Exception:  # noqa: BLE001
        pass
    _global_client = _mtproto_require_client()
    _global_in = any(c is _global_client for _, c in _candidates)
    if not _global_in:
        _candidates.append(("(global)", _global_client))

    entity = None
    _last_resolve_error = None
    for _aid, client in _candidates:
        try:
            # V85: try the unified resolver first.
            try:
                entity = await _resolve_message_link_bootstrap(chat_ref, client=client)
            except Exception as exc:  # noqa: BLE001
                logger.debug("mtproto_resolve_entity: resolve_message_link fallback: %s", exc)
            if entity is None:
                entity = await resolve_entity_full(client, chat_ref)
            if entity is not None:
                logger.info(
                    "ENTITY_RESOLVED_OK chat_ref=%s account_id=%s entity_type=%s",
                    chat_ref, _aid, _mtproto_entity_type(entity),
                )
                break
        except VCTransportError as exc:
            _last_resolve_error = exc
            logger.debug("ENTITY_RESOLVE_TRY_FAILED chat_ref=%s account_id=%s: %s",
                         chat_ref, _aid, str(exc)[:80])
            continue
        except UsernameInvalidError as exc:
            _last_resolve_error = exc
            logger.debug("ENTITY_RESOLVE_TRY_FAILED chat_ref=%s account_id=%s: %s",
                         chat_ref, _aid, str(exc)[:80])
            continue
        except ChannelInvalidError as exc:
            _last_resolve_error = exc
            logger.debug("ENTITY_RESOLVE_TRY_FAILED chat_ref=%s account_id=%s: %s",
                         chat_ref, _aid, str(exc)[:80])
            continue
        except Exception as exc:  # noqa: BLE001
            _last_resolve_error = exc
            logger.debug("ENTITY_RESOLVE_TRY_FAILED chat_ref=%s account_id=%s: %s",
                         chat_ref, _aid, str(exc)[:80])
            continue

    if entity is None:
        raise MTProtoError(
            f"Failed to resolve '{chat_ref}': all candidate accounts failed. "
            f"Last error: {_last_resolve_error}"
        )

    return {
        "id": getattr(entity, "id", None),
        "username": getattr(entity, "username", None),
        "title": getattr(entity, "title", None),
        "first_name": getattr(entity, "first_name", None),
        "last_name": getattr(entity, "last_name", None),
        "type": _mtproto_entity_type(entity),
        "participants_count": getattr(entity, "participants_count", None),
    }


def _mtproto_entity_type(entity) -> str:
    from telethon.tl.types import User, Chat, Channel
    if isinstance(entity, User):
        return "user"
    if isinstance(entity, Chat):
        return "group"
    if isinstance(entity, Channel):
        return "channel" if getattr(entity, "broadcast", False) else "supergroup"
    return "unknown"


async def mtproto_get_channel_history(chat_ref: str | int, limit: int = 20,
                                      offset_id: int = 0) -> list[dict[str, Any]]:
    """Fetch recent messages from a channel/chat via MTProto.

    v97.24: returns scan_account_id + scan_client_id in the result so the
    downloader can reuse the SAME account that successfully scanned.
    """
    client = _mtproto_require_client()

    # v97.24: identify which account/client is scanning.
    _scan_account_id = "(global)"
    _scan_client_id = id(client)
    try:
        cluster = get_userbot_cluster()
        for acc in cluster.get_healthy_accounts():
            aid = acc.get("account_id")
            if aid:
                c = cluster.get_client(aid)
                if c is client:
                    _scan_account_id = aid
                    break
    except Exception:  # noqa: BLE001
        pass

    logger.info(
        "MEDIA_SCAN_ACCOUNT account_id=%s client_id=%s chat_ref=%s",
        _scan_account_id, _scan_client_id, chat_ref,
    )

    try:
        entity = await mtproto_call_with_retry(client.get_entity, chat_ref)
        _entity_type = _mtproto_entity_type(entity)
        _entity_id = getattr(entity, "id", "?")
        logger.info(
            "MEDIA_SCAN_ENTITY_TYPE entity_type=%s entity_id=%s chat_ref=%s "
            "account_id=%s",
            _entity_type, _entity_id, chat_ref, _scan_account_id,
        )
        messages = await mtproto_call_with_retry(
            client.get_messages, entity, limit=limit, offset_id=offset_id,
        )
    except Exception as exc:  # noqa: BLE001
        raise MTProtoError(f"Failed to read history: {exc}") from exc

    out = []
    for m in messages:
        out.append({
            "id": m.id,
            "date": m.date.isoformat() if m.date else None,
            "text": (m.text or "")[:500],
            "has_media": m.media is not None,
            "media_type": _mtproto_media_type(m.media),
            "sender_id": getattr(m, "sender_id", None),
            # v97.24: retain the scan account/client identity per message.
            "scan_account_id": _scan_account_id,
            "scan_client_id": _scan_client_id,
            "scan_entity_type": _entity_type,
            "scan_entity_id": _entity_id,
        })
    return out


def _mtproto_media_type(media) -> Optional[str]:
    if media is None:
        return None
    if getattr(media, "photo", None):
        return "photo"
    doc = getattr(media, "document", None)
    if doc:
        from telethon.tl.types import DocumentAttributeVideo, DocumentAttributeAudio
        for attr in getattr(doc, "attributes", []) or []:
            if isinstance(attr, DocumentAttributeVideo):
                return "video_note" if getattr(attr, "round_message", False) else "video"
            if isinstance(attr, DocumentAttributeAudio):
                return "voice" if getattr(attr, "voice", False) else "audio"
        return "document"
    return "unknown"


async def mtproto_download_message_media(chat_ref: str | int, message_id: int,
                                         progress_cb=None,
                                         preferred_account_id: str = "") -> tuple[Path, str, str, int]:
    """Download media from a specific message via MTProto.

    v97.24 FIX: accept preferred_account_id — the account that SCANNED the
    source chat.  This account is tried FIRST because it has already proven
    it can access the source (it successfully scanned the history).  Other
    accounts are tried only if the preferred account fails.

    This fixes the root cause of "35/35 failed" where:
    - Scan used the global _mtproto_client (Account A)
    - Download tried cluster accounts (Account B, C) first
    - Account B/C don't have a dialog with the source User @Sanskari_bookbot
    - get_messages(InputPeerUser, ids=X) returned None for B/C
    - All 35 items failed

    Returns ``(path, filename, media_type, size_bytes)``.
    """
    from telethon.errors import (
        UserIdInvalidError, ChannelPrivateError, ChatAdminRequiredError,
        FloodWaitError, RPCError, AuthKeyError,
    )
    from telethon.tl.types import (
        InputPeerChannel, InputPeerChat, InputPeerUser,
        Channel, Chat, User,
    )

    # v97.24: collect candidate clients.  The preferred_account_id (the
    # account that scanned the source) is tried FIRST.  This is critical
    # because the scanning account has already proven it can access the
    # source — other accounts may not have a dialog with the source User.
    candidates: list[tuple[str, Any]] = []  # (account_id, client)
    _all_clients: dict[str, Any] = {}  # account_id → client (for lookup)

    # Collect all healthy cluster accounts.
    try:
        cluster = get_userbot_cluster()
        healthy = cluster.get_healthy_accounts()
        for acc in healthy:
            aid = acc.get("account_id")
            if aid:
                c = cluster.get_client(aid)
                if c is not None and c.is_connected():
                    # v97.31: wrap in a gated proxy so download RPCs on this
                    # cluster client are protected by the per-cluster-client
                    # RW lock (prevents concurrent reconnect on the same client).
                    async def _dl_lock_getter(_aid=aid):
                        return await _get_cluster_client_rw_lock(_aid)
                    _all_clients[aid] = _GatedClientProxy(
                        c, _dl_lock_getter, client_id=f"cluster:{aid}")
    except Exception:  # noqa: BLE001
        pass

    # Global client.
    _global_client = _mtproto_require_client()
    _all_clients["(global)"] = _global_client

    # v97.24: put the preferred (scanning) account FIRST.
    if preferred_account_id and preferred_account_id in _all_clients:
        candidates.append((preferred_account_id, _all_clients[preferred_account_id]))
        logger.info(
            "DOWNLOAD_PREFERRED_ACCOUNT account_id=%s chat_ref=%s message_id=%s "
            "— using the same account that scanned the source",
            preferred_account_id, chat_ref, message_id,
        )

    # Add remaining accounts (excluding the preferred one already added).
    for aid, c in _all_clients.items():
        if aid != preferred_account_id:
            candidates.append((aid, c))

    if not candidates:
        raise MTProtoNotAvailable("No connected MTProto client available for download.")

    logger.info("RESTRICTED_DOWNLOAD_START chat_ref=%s message_id=%s "
                "candidate_accounts=%s client_count=%d preferred=%s",
                chat_ref, message_id,
                [aid for aid, _ in candidates], len(candidates),
                preferred_account_id or "none")

    last_error: str = ""
    for account_id, client in candidates:
        _client_id = id(client)
        _t0 = time.monotonic()
        try:
            # ---- Step 1: Resolve entity ----
            logger.info("LINK_RESOLUTION chat_ref=%s account_id=%s client_id=%s",
                        chat_ref, account_id, _client_id)
            try:
                # v97.30: route through mtproto_call_with_retry for RW-lock
                # gating + global FloodWait gate + 10s timeout (v97.72). This
                # replaces the bare asyncio.wait_for(client.get_entity(...),
                # timeout=15) which bypassed the RW lock and could hit "Cannot
                # send requests while disconnected" during a reconnect.
                entity = await mtproto_call_with_retry(
                    client.get_entity, chat_ref, retries=2,
                )
            except asyncio.TimeoutError:
                last_error = f"get_entity timed out after 10s (account={account_id})"
                logger.warning("LINK_RESOLUTION_TIMEOUT chat_ref=%s account_id=%s "
                               "client_id=%s duration=%.1fs",
                               chat_ref, account_id, _client_id, time.monotonic() - _t0)
                continue  # try next account
            except Exception as exc:
                last_error = f"get_entity failed: {type(exc).__name__}: {exc}"[:200]
                logger.warning("LINK_RESOLUTION_FAILED chat_ref=%s account_id=%s "
                               "exc=%s — trying next account",
                               chat_ref, account_id, last_error)
                continue

            _entity_type = _mtproto_entity_type(entity)
            _entity_id = getattr(entity, "id", "?")
            logger.info("ENTITY_RESOLVED chat_ref=%s entity_id=%s entity_type=%s "
                        "account_id=%s client_id=%s duration=%.1fs",
                        chat_ref, _entity_id, _entity_type,
                        account_id, _client_id, time.monotonic() - _t0)

            # ---- Step 2: Build correct InputPeer ----
            # v97.15: use the correct InputPeer type based on entity type.
            # This prevents UserIdInvalidError (using InputPeerUser for a
            # channel message) and InputPeerChannel errors.
            input_peer = None
            if isinstance(entity, Channel):
                _ah = getattr(entity, "access_hash", None)
                if _ah is not None:
                    input_peer = InputPeerChannel(_entity_id, int(_ah))
            elif isinstance(entity, Chat):
                input_peer = InputPeerChat(_entity_id)
            elif isinstance(entity, User):
                _ah = getattr(entity, "access_hash", None)
                if _ah is not None:
                    input_peer = InputPeerUser(_entity_id, int(_ah))

            # ---- Step 3: Fetch the exact message ----
            _t_msg = time.monotonic()
            logger.info("MESSAGE_RESOLUTION chat_ref=%s entity_id=%s entity_type=%s "
                        "message_id=%s account_id=%s client_id=%s",
                        chat_ref, _entity_id, _entity_type, message_id,
                        account_id, _client_id)
            try:
                # v97.30: route through mtproto_call_with_retry for RW-lock
                # gating + global FloodWait gate + 10s timeout (v97.72).
                if input_peer is not None:
                    messages = await mtproto_call_with_retry(
                        client.get_messages, input_peer, ids=message_id, retries=2,
                    )
                else:
                    messages = await mtproto_call_with_retry(
                        client.get_messages, entity, ids=message_id, retries=2,
                    )
            except asyncio.TimeoutError:
                last_error = f"get_messages timed out after 10s (account={account_id})"
                logger.warning("MESSAGE_RESOLUTION_TIMEOUT chat_ref=%s message_id=%s "
                               "account_id=%s duration=%.1fs",
                               chat_ref, message_id, account_id, time.monotonic() - _t_msg)
                continue
            except UserIdInvalidError:
                raise MTProtoError(
                    f"Cannot access message #{message_id} from '{chat_ref}': "
                    f"the resolved entity is a User, but the message ID refers to "
                    f"a channel/group message.  If this is a channel link, "
                    f"make sure the username is correct."
                )

            # ---- Step 4: Validate message + media ----
            # v97.23: log what get_messages actually returned.
            logger.info(
                "GET_MESSAGES_RESULT chat_ref=%s message_id=%s account_id=%s "
                "result_type=%s result_value=%s",
                chat_ref, message_id, account_id,
                type(messages).__name__,
                str(messages)[:200] if messages is not None else "None",
            )
            message = _mtproto_extract_single_message(messages)
            if message is None:
                logger.warning(
                    "MESSAGE_NOT_FOUND chat_ref=%s message_id=%s account_id=%s "
                    "entity_id=%s entity_type=%s — get_messages returned None/empty",
                    chat_ref, message_id, account_id, _entity_id, _entity_type,
                )
                raise MTProtoError(f"Message #{message_id} not found in that chat.")
            if not message.media:
                raise MTProtoError(f"Message #{message_id} has no downloadable media.")
            logger.info("ACCESS_VALIDATION chat_ref=%s message_id=%s access=ok "
                        "media=%s account_id=%s client_id=%s duration=%.1fs",
                        chat_ref, message_id, type(message.media).__name__,
                        account_id, _client_id, time.monotonic() - _t_msg)

            # ---- Step 5: Download media (streaming to disk) ----
            media_type = _mtproto_media_type(message.media) or "media"
            filename = _mtproto_derive_filename(message, media_type)
            filename = safe_filename(filename)
            target = unique_path(config.downloads_dir, filename)

            _t_dl = time.monotonic()

            def _progress(received, total):
                if progress_cb and total:
                    try:
                        pct = received / total * 100
                        # v97.74 P1: supervised so progress-cb exceptions are
                        # observed (previously fire-and-forget, lost on stderr).
                        supervised_create_task(
                            progress_cb(pct, received, total),
                            name="download_progress_cb",
                        )
                    except Exception:  # noqa: BLE001
                        pass

            # v97.16: OPTIMIZED download path.
            # Bottleneck analysis:
            # 1. cryptg NOT installed → Telethon uses slow Python AES-IGE (10-50x slower)
            # 2. No resumable downloads → restart from scratch on interruption
            #
            # Fix: use Telethon's public download_media() API (which handles all
            # media types correctly) with a .part file for resumability + 600s
            # timeout.  cryptg is the #1 real bottleneck — added to requirements.
            #
            # v97.16b FIX: the previous version used client._get_file_location()
            # which is a PRIVATE method that does NOT exist in Telethon 1.44.
            # This caused AttributeError on every download.  Now using the
            # PUBLIC client.download_media() API.
            try:
                # v97.16: check cryptg availability + warn if missing.
                try:
                    import cryptg  # noqa: F401
                    _cryptg_ok = True
                except ImportError:
                    _cryptg_ok = False
                    logger.warning(
                        "DOWNLOAD_NO_CRYPTG — Telethon will use slow Python "
                        "AES-IGE.  Install cryptg (pip install cryptg) for "
                        "10-50x faster downloads."
                    )

                _file_size = 0
                doc = getattr(message.media, "document", None)
                if doc:
                    _file_size = getattr(doc, "size", 0) or 0

                # v97.16: write to a .part file first, then rename on success.
                # This enables resumable downloads (if the .part file exists
                # on a retry, Telethon's download_media will overwrite it —
                # full restart.  True resume would require iter_download with
                # the input location, but that's a private API that varies
                # across Telethon versions.  The .part file at least prevents
                # leaving a partial file with the final name.)
                _part_file = target.with_suffix(target.suffix + ".part")

                # v97.94 FIX BUG-P7-1 (SOURCE-PROVEN clear correctness defect):
                # A DUPLICATE `_progress` definition previously existed here
                # (mtproto.py:6335-6343) that SHADOWED the supervised version
                # defined above at line 6282. The orphan version used
                # `asyncio.get_running_loop().create_task(...)` (fire-and-forget,
                # exceptions silently lost) instead of `supervised_create_task`
                # — exactly the bug the v97.74 P1 comment at line 6286-6288
                # claims to have fixed. Every download spawned dozens of orphan
                # progress-callback tasks whose exceptions were silently lost.
                # FIX: removed the shadowing definition. The supervised
                # `_progress` at line 6282 is now the only one — progress-cb
                # exceptions are properly observed.

                # v97.23: log the actual download start with full context.
                logger.info(
                    "DOWNLOAD_MEDIA_START chat_ref=%s message_id=%s account_id=%s "
                    "client_id=%s entity_id=%s entity_type=%s media=%s",
                    chat_ref, message_id, account_id, _client_id,
                    _entity_id, _entity_type, type(message.media).__name__,
                )

                # v97.16b: use the PUBLIC download_media API — it handles all
                # media types (photo, document, video, voice, etc.) correctly
                # and calls the right internal _download_* method.
                # v97.16d: add a retry loop for connection resets ("Server
                # closed the connection: 0 bytes read").  Telethon with
                # auto_reconnect=False doesn't auto-recover from these — we
                # need to manually reconnect + retry.
                _download_retries = 3
                result = None
                for _dl_attempt in range(1, _download_retries + 1):
                    try:
                        # Verify the client is still connected before downloading.
                        if not client.is_connected():
                            logger.info("DOWNLOAD_RECONNECT_BEFORE_RETRY "
                                        "account_id=%s attempt=%d",
                                        account_id, _dl_attempt)
                            # v97.28: route through _telethon_drain_and_reconnect
                            # so the old connection is fully DRAINED (all
                            # background tasks done) before reconnecting —
                            # prevents duplicate Telethon lifecycle task sets.
                            await _telethon_drain_and_reconnect(
                                client, label=f"download_retry_account={account_id}")
                        result = await asyncio.wait_for(
                            client.download_media(
                                message,
                                file=str(_part_file),
                                progress_callback=_progress,
                            ),
                            timeout=600,
                        )
                        break  # success
                    except (ConnectionError, OSError, asyncio.TimeoutError) as dl_exc:
                        _is_reset = "0 bytes read" in str(dl_exc) or \
                                    "Server closed" in str(dl_exc) or \
                                    "ConnectionResetError" in type(dl_exc).__name__
                        if _dl_attempt < _download_retries and _is_reset:
                            logger.warning("DOWNLOAD_CONNECTION_RESET_RETRY "
                                          "account_id=%s attempt=%d/%d exc=%s",
                                          account_id, _dl_attempt,
                                          _download_retries,
                                          type(dl_exc).__name__)
                            # Reconnect before retrying.
                            # v97.28: drain first to prevent duplicate tasks.
                            try:
                                await _telethon_drain_and_reconnect(
                                    client, label=f"download_reset_account={account_id}")
                            except Exception:  # noqa: BLE001
                                pass
                            await asyncio.sleep(2)  # brief backoff
                            continue
                        # Non-reset error or exhausted retries → re-raise
                        raise
                # Rename .part → final filename.
                if _part_file.exists():
                    _part_file.rename(target)
                # v97.16c FIX: result points to the .part path (what we passed
                # to download_media).  After rename, the file is at `target`.
                # Set result to the final path so the return value is correct.
                result = str(target)

            except asyncio.TimeoutError:
                last_error = f"download timed out after 600s (account={account_id})"
                logger.warning("DOWNLOAD_TIMEOUT chat_ref=%s message_id=%s "
                               "account_id=%s duration=%.1fs cryptg=%s",
                               chat_ref, message_id, account_id,
                               time.monotonic() - _t_dl, _cryptg_ok)
                # Keep the .part file for potential future resume.
                continue
            except FloodWaitError as exc:
                # Respect FloodWait — don't retry, report to caller.
                raise MTProtoError(
                    f"Download rate-limited: must wait {exc.seconds}s."
                ) from exc

            if not result:
                raise MTProtoError("Download produced no file.")
            path = Path(result)
            size = path.stat().st_size if path.exists() else 0
            logger.info("DOWNLOAD_COMPLETE chat_ref=%s message_id=%s account_id=%s "
                        "client_id=%s size=%d media_type=%s duration=%.1fs",
                        chat_ref, message_id, account_id, _client_id,
                        size, media_type, time.monotonic() - _t_dl)
            return path, path.name, media_type, size

        except MTProtoError:
            raise  # caller-facing errors (not found, no media, rate-limited)
        except (ChannelPrivateError, ChatAdminRequiredError) as exc:
            # This account doesn't have access — try the next account.
            last_error = f"{type(exc).__name__}: {exc}"
            logger.info("ACCESS_DENIED chat_ref=%s account_id=%s exc=%s — "
                        "trying next account",
                        chat_ref, account_id, type(exc).__name__)
            continue
        except AuthKeyError as exc:
            # Session invalidated — try the next account.
            last_error = f"AuthKeyError: {exc}"
            logger.warning("AUTH_KEY_ERROR chat_ref=%s account_id=%s: %s — "
                           "trying next account",
                           chat_ref, account_id, str(exc)[:80])
            continue
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            last_error = f"{type(exc).__name__}: {exc}"
            logger.warning("DOWNLOAD_ATTEMPT_FAILED chat_ref=%s message_id=%s "
                           "account_id=%s client_id=%s exc=%s: %s duration=%.1fs",
                           chat_ref, message_id, account_id, _client_id,
                           type(exc).__name__, str(exc)[:120],
                           time.monotonic() - _t0)
            continue  # try next account

    # All candidates exhausted.
    raise MTProtoError(
        f"All candidate accounts failed to download message #{message_id} "
        f"from '{chat_ref}'.  Last error: {last_error}"
    )


def _mtproto_derive_filename(message, media_type: str) -> str:
    """Best-effort original filename from a Telethon message."""
    from telethon.tl.types import DocumentAttributeFilename
    media = message.media
    if media is None:
        return f"media_{message.id}"
    doc = getattr(media, "document", None)
    if doc:
        for attr in getattr(doc, "attributes", []) or []:
            if isinstance(attr, DocumentAttributeFilename) and attr.file_name:
                return attr.file_name
        ext = {"video": ".mp4", "video_note": ".mp4", "voice": ".ogg",
               "audio": ".mp3", "document": ".bin", "photo": ".jpg"}.get(media_type, ".bin")
        return f"{getattr(doc, 'id', 'media')}{ext}"
    if getattr(media, "photo", None):
        return f"photo_{getattr(media.photo, 'id', message.id)}.jpg"
    return f"media_{message.id}"


def _mtproto_extract_single_message(result):
    """Normalise a Telethon get_messages(ids=...) result to one Message.

    Telethon returns a single Message object when ids=<int>, a list when
    ids=<list>, or None if not found. This helper returns the first non-None
    Message or None. It NEVER subscripts a single Message object.
    """
    if result is None:
        return None
    if isinstance(result, (list, tuple)):
        for item in result:
            if item is not None:
                return item
        return None
    return result


async def mtproto_screenshot(chat_ref: str | int) -> Path | None:
    """Take a text-rendered 'screenshot' of a chat's recent messages."""
    return await mtproto_take_screenshot(chat_ref)


async def mtproto_download_channel_media(chat_ref: str | int, limit: int = 50,
                                         progress_cb=None) -> list[dict]:
    """Download up to *limit* recent media messages from a channel."""
    client = _mtproto_require_client()

    try:
        entity = await mtproto_call_with_retry(client.get_entity, chat_ref)
        messages = await mtproto_call_with_retry(
            client.get_messages, entity, limit=limit,
        )
    except Exception as exc:  # noqa: BLE001
        raise MTProtoError(f"Failed to read channel: {exc}") from exc

    results = []
    for m in messages:
        if not m.media:
            continue
        try:
            path, name, mtype, size = await mtproto_download_message_media(
                chat_ref, m.id, progress_cb=progress_cb,
            )
            results.append({
                "path": str(path), "filename": name,
                "media_type": mtype, "size": size, "message_id": m.id,
            })
            if progress_cb:
                try:
                    await progress_cb(len(results), limit)
                except Exception:  # noqa: BLE001
                    pass
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to download message #%s: %s", m.id, exc)
    return results


async def profile_resolve_entity(chat_ref: str | int) -> dict[str, Any]:
    """V64: Resolve a user entity via MTProto.

    Supports: @username, numeric user ID, t.me/username links.

    Returns a dict with:
      ok, entity, user_id, first_name, last_name, username, phone, bio,
      is_premium, is_verified, is_scam, is_fake,
      photo_count, has_stories, stories_count,
      stories_reason (exact reason if stories not visible),
      error, failure_stage
    """
    result: dict[str, Any] = {
        "ok": False, "entity": None, "user_id": 0, "first_name": "",
        "last_name": "", "username": "", "phone": "", "bio": "",
        "is_premium": False, "is_verified": False, "is_scam": False,
        "is_fake": False, "photo_count": 0, "has_stories": False,
        "stories_count": 0, "stories_reason": "",
        "error": "", "failure_stage": "",
        # V65: Profile posts fields.
        "has_posts": False, "posts_count": 0, "text_posts": 0,
        "media_posts": 0, "latest_post_id": 0, "posts_reason": "",
        "posts_failure_stage": "",
        "resolution_method": "", "input_type": "",
    }
    if not mtproto_is_started():
        result["error"] = "MTProto is not started"
        result["failure_stage"] = "mtproto_not_started"
        logger.info("PROFILE_RESOLVE input=%s ok=false reason=mtproto_not_started",
                    chat_ref)
        return result
    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        result["failure_stage"] = "client_unavailable"
        logger.info("PROFILE_RESOLVE input=%s ok=false reason=client_unavailable",
                    chat_ref)
        return result
    # V72 PART 18: PROFILE_RESOLVE log at start.
    logger.info("PROFILE_RESOLVE input=%s ok=pending", chat_ref)

    # Normalize the input.
    ref: str | int = chat_ref
    is_numeric_id = False
    if isinstance(chat_ref, str):
        chat_ref_stripped = chat_ref.strip().lstrip("@")
        if chat_ref_stripped.isdigit():
            ref = int(chat_ref_stripped)
            is_numeric_id = True
            result["input_type"] = "user_id"
        elif chat_ref_stripped.startswith("t.me/"):
            ref = chat_ref_stripped.split("t.me/")[-1]
            result["input_type"] = "t.me_link"
        else:
            ref = chat_ref_stripped
            result["input_type"] = "username"
    elif isinstance(chat_ref, int):
        is_numeric_id = True
        result["input_type"] = "user_id"

    # V65: Guard against message IDs being passed as user IDs.
    # Message IDs are typically < 10,000,000. User IDs are typically > 1,000,000.
    # Channel IDs start with -100. We reject negative IDs and very small IDs.
    if is_numeric_id and isinstance(ref, int):
        if ref < 0:
            result["error"] = "Negative IDs are channel/chat IDs, not user IDs. Use @username or t.me link instead."
            result["failure_stage"] = "invalid_id_type"
            return result
        if ref < 10000:
            result["error"] = "This looks like a message ID, not a user ID. User IDs are typically 8+ digits."
            result["failure_stage"] = "invalid_id_type"
            return result

    # V81 ISSUE 2+3+4: Use resolve_entity_full (9-step pipeline) for ALL inputs.
    # This replaces the old profile_resolve_user_id + direct get_entity calls.
    # The 9-step pipeline tries: cache → forward_cache → dialogs → contacts →
    # common groups → username → get_entity → get_input_entity → persist.
    # It also auto-triggers find_user_in_common_groups when access_hash is missing.
    try:
        entity = await resolve_entity_full(client, ref)
        if entity is not None:
            result["entity"] = entity
            result["ok"] = True
            # Determine resolution method from the entity's source.
            ent_id = getattr(entity, "id", 0) or 0
            cached = _vc_entity_cache.get(ent_id or ref, {})
            result["resolution_method"] = cached.get("source", "resolve_entity_full")
            logger.info("PROFILE_RESOLVE input=%s resolved via resolve_entity_full "
                        "(source=%s)", ref, result["resolution_method"])
        else:
            result["error"] = (
                "⚠ Telegram does not expose enough information to resolve this user.\n\n"
                "Resolution Report:\n"
                "• Cache: tried\n"
                "• Forward Cache: tried\n"
                "• Dialogs: tried\n"
                "• Contacts: tried\n"
                "• Common Groups: tried\n"
                "• Username Lookup: tried\n"
                "• get_entity(): tried\n"
                "• get_input_entity(): tried\n\n"
                "All 9 resolution steps failed.\n\n"
                "Try:\n"
                "• Forward a message from the user\n"
                "• Send a message link (t.me/username/123)\n"
                "• Use @username\n"
                "• Use the 👥 Search User In Common Groups button"
            )
            result["failure_stage"] = "all_9_steps_failed"
            result["resolution_method"] = "failed"
            logger.info("PROFILE_RESOLVE input=%s — all 9 steps failed", ref)
            return result
    except VCTransportError as exc:
        result["error"] = str(exc)[:500]
        result["failure_stage"] = "all_9_steps_failed"
        result["resolution_method"] = "failed"
        logger.info("PROFILE_RESOLVE input=%s — resolve_entity_full raised: %s",
                    ref, str(exc)[:120])
        return result
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"Entity resolution failed: {type(exc).__name__}: {str(exc)[:120]}"
        result["failure_stage"] = "entity_resolution"
        logger.info("PROFILE_RESOLVE failed ref=%s exc=%s: %s",
                    str(ref)[:50], type(exc).__name__, str(exc)[:120])
        return result

    # Extract profile info.
    result["user_id"] = getattr(entity, "id", 0) or 0
    result["first_name"] = getattr(entity, "first_name", "") or ""
    result["last_name"] = getattr(entity, "last_name", "") or ""
    result["username"] = getattr(entity, "username", "") or ""
    result["phone"] = getattr(entity, "phone", "") or ""
    result["is_premium"] = bool(getattr(entity, "premium", False))
    result["is_verified"] = bool(getattr(entity, "verified", False))
    result["is_scam"] = bool(getattr(entity, "scam", False))
    result["is_fake"] = bool(getattr(entity, "fake", False))

    # Get bio + profile photo count via GetFullUserRequest.
    try:
        from telethon.tl.functions.users import GetFullUserRequest
        from telethon.tl.types import InputPeerUser
        if result["user_id"]:
            # V64 Fix: pass InputPeerUser, not a raw int.
            access_hash = getattr(entity, "access_hash", 0) or 0
            input_peer = InputPeerUser(user_id=result["user_id"],
                                       access_hash=access_hash)
            full = await client(GetFullUserRequest(id=input_peer))
            if full and hasattr(full, "full_user"):
                result["bio"] = getattr(full.full_user, "about", "") or ""
                # V64 Fix: log the full response for diagnostics.
                logger.info("PROFILE_GET_FULL_USER success user_id=%s bio_len=%d "
                            "personal_photo=%s profile_photo=%s fallback_photo=%s",
                            result["user_id"],
                            len(result["bio"]),
                            bool(getattr(full.full_user, "personal_photo", None)),
                            bool(getattr(full.full_user, "profile_photo", None)),
                            bool(getattr(full.full_user, "fallback_photo", None)))
    except Exception as exc:  # noqa: BLE001
        logger.warning("PROFILE_GET_FULL_USER failed user_id=%s exc=%s: %s",
                       result["user_id"], type(exc).__name__, str(exc)[:120])

    # V64 Fix: count profile photos using GetUserPhotosRequest (the correct API).
    # The old code used client.download_profile_photos(entity, file=bytes) which
    # returns bytes (not a count) and fails silently. GetUserPhotosRequest
    # returns the actual list of Photo objects.
    try:
        from telethon.tl.functions.photos import GetUserPhotosRequest
        user_id = result["user_id"]
        if user_id:
            # Request with limit=1 to check if any photos exist. If we get 1,
            # we know there's at least 1 photo. Then request with limit=100
            # to get the full count.
            resp = await client(GetUserPhotosRequest(
                user_id=entity, offset=0, max_id=0, limit=100))
            if resp and hasattr(resp, "photos"):
                actual_count = len(resp.photos)
                result["photo_count"] = actual_count
                logger.info("PROFILE_PHOTOS_COUNT user_id=%s count=%d",
                            user_id, actual_count)
            else:
                result["photo_count"] = 0
                logger.info("PROFILE_PHOTOS_COUNT user_id=%s count=0 (empty response)",
                            user_id)
        else:
            result["photo_count"] = 0
    except Exception as exc:  # noqa: BLE001
        # V64 Fix: don't silently set 0 — log the real reason.
        exc_name = type(exc).__name__
        exc_str = str(exc)[:150]
        logger.warning("PROFILE_PHOTOS_COUNT_FAILED user_id=%s exc=%s: %s",
                       result["user_id"], exc_name, exc_str)
        # If GetUserPhotosRequest fails, fall back to checking entity.photo.
        entity_photo = getattr(entity, "photo", None)
        if entity_photo is not None:
            result["photo_count"] = 1  # At least the current profile photo.
            logger.info("PROFILE_PHOTOS_FALLBACK user_id=%s has_entity_photo=True → count=1",
                        result["user_id"])
        else:
            result["photo_count"] = 0

    # V64 Fix: check stories visibility with detailed error reporting + raw logging.
    # The old code silently converted ALL exceptions to "not visible".
    try:
        from telethon.tl.functions.stories import GetPeerStoriesRequest
        if result["user_id"]:
            stories_resp = await client(GetPeerStoriesRequest(peer=entity))

            # V64 Fix: log the RAW response — all attributes, types, and values.
            # This is critical for debugging why stories show as "not visible"
            # for users that clearly have stories.
            raw_attrs = {}
            if stories_resp is not None:
                for attr_name in dir(stories_resp):
                    if not attr_name.startswith("_"):
                        try:
                            attr_val = getattr(stories_resp, attr_name)
                            if not callable(attr_val):
                                if isinstance(attr_val, (list, tuple)):
                                    raw_attrs[attr_name] = f"list[{len(attr_val)}]"
                                elif attr_val is None:
                                    raw_attrs[attr_name] = "None"
                                else:
                                    raw_attrs[attr_name] = type(attr_val).__name__
                        except Exception:
                            raw_attrs[attr_name] = "<error>"
            logger.info("PROFILE_STORIES_RAW_RESPONSE user_id=%s resp_type=%s attrs=%s",
                        result["user_id"],
                        type(stories_resp).__name__ if stories_resp else "None",
                        json.dumps(raw_attrs, default=str)[:500])

            # V64 Fix: robust story count extraction.
            # The Telethon response structure for GetPeerStoriesRequest is:
            #   stories.PeerStories(stories=StoryList(stories=[...], count=N, pinned=...))
            # But different Telethon versions may structure this differently.
            # We try multiple paths to extract the story count.
            stories_count_found = -1
            stories_list = None

            if stories_resp is None:
                result["has_stories"] = False
                result["stories_count"] = 0
                result["stories_reason"] = "Empty response from Telegram (None)"
            else:
                # Path 1: stories_resp.stories.stories (standard Telethon structure).
                story_wrapper = getattr(stories_resp, "stories", None)
                if story_wrapper is not None:
                    # The wrapper could be a StoryList with .stories attribute,
                    # or it could directly be a list.
                    if isinstance(story_wrapper, (list, tuple)):
                        stories_list = story_wrapper
                        stories_count_found = len(story_wrapper)
                    elif hasattr(story_wrapper, "stories"):
                        inner = getattr(story_wrapper, "stories", None)
                        if isinstance(inner, (list, tuple)):
                            stories_list = inner
                            stories_count_found = len(inner)
                        elif inner is None:
                            stories_count_found = 0
                    elif hasattr(story_wrapper, "count"):
                        # Some versions have a count attribute.
                        stories_count_found = int(getattr(story_wrapper, "count", 0) or 0)

                # Path 2: stories_resp directly has a list.
                if stories_count_found < 0 and isinstance(getattr(stories_resp, "stories", None), (list, tuple)):
                    stories_list = stories_resp.stories
                    stories_count_found = len(stories_list)

                # Path 3: check for _stories attribute (Telethon internal).
                if stories_count_found < 0:
                    for attr in ("_stories", "stories_list", "items"):
                        val = getattr(stories_resp, attr, None)
                        if isinstance(val, (list, tuple)):
                            stories_list = val
                            stories_count_found = len(val)
                            break

                if stories_count_found >= 0:
                    result["stories_count"] = stories_count_found
                    result["has_stories"] = stories_count_found > 0
                    if stories_count_found > 0:
                        result["stories_reason"] = ""
                    else:
                        result["stories_reason"] = "No stories available (count=0)"
                    logger.info("PROFILE_STORIES_COUNT user_id=%s count=%d path=%s",
                                result["user_id"], stories_count_found,
                                "wrapper" if story_wrapper else "direct")
                else:
                    # Could not extract count from any known path.
                    result["has_stories"] = False
                    result["stories_count"] = 0
                    result["stories_reason"] = (
                        f"Could not parse stories response (type={type(stories_resp).__name__}). "
                        "The Telethon version may use a different response structure. "
                        "Check PROFILE_STORIES_RAW_RESPONSE log for details."
                    )
                    logger.warning("PROFILE_STORIES_PARSE_FAILED user_id=%s resp_type=%s — "
                                   "could not extract story count from response",
                                   result["user_id"], type(stories_resp).__name__)
    except ImportError:
        result["has_stories"] = False
        result["stories_count"] = 0
        result["stories_reason"] = "API unsupported (GetPeerStoriesRequest not available in this Telethon version)"
        logger.warning("PROFILE_STORIES_UNSUPPORTED user_id=%s — GetPeerStoriesRequest not available",
                       result["user_id"])
    except Exception as exc:  # noqa: BLE001
        exc_name = type(exc).__name__
        exc_str = str(exc)[:200]
        exc_module = getattr(type(exc), "__module__", "unknown")
        result["has_stories"] = False
        result["stories_count"] = 0
        # V64 Fix: surface the REAL reason with full exception class path.
        exc_lower = exc_str.lower()
        if "private" in exc_lower or "forbidden" in exc_lower:
            result["stories_reason"] = (
                f"Stories hidden (privacy setting or not a contact). "
                f"Exception: {exc_module}.{exc_name}: {exc_str[:100]}"
            )
        elif "not found" in exc_lower:
            result["stories_reason"] = (
                f"Peer not found for stories. "
                f"Exception: {exc_module}.{exc_name}: {exc_str[:100]}"
            )
        elif "flood" in exc_lower:
            result["stories_reason"] = (
                f"FloodWait — try again later. "
                f"Exception: {exc_module}.{exc_name}: {exc_str[:100]}"
            )
        elif "chat" in exc_lower and ("admin" in exc_lower or "id" in exc_lower):
            result["stories_reason"] = (
                f"Stories unavailable (may be a channel/bot, not a user). "
                f"Exception: {exc_module}.{exc_name}: {exc_str[:100]}"
            )
        else:
            result["stories_reason"] = (
                f"Request failed: {exc_module}.{exc_name}: {exc_str[:100]}"
            )
        logger.warning("PROFILE_STORIES_CHECK_FAILED user_id=%s exc_module=%s exc=%s: %s — reason=%s",
                       result["user_id"], exc_module, exc_name, exc_str,
                       result["stories_reason"])

    # V64 Fix: store raw diagnostics for the Diagnostics button.
    result["stories_response_type"] = (
        type(stories_resp).__name__ if "stories_resp" in dir() and stories_resp else "N/A"
    )
    result["stories_failure_stage"] = result.get("failure_stage", "")
    if result["stories_reason"]:
        result["stories_failure_stage"] = "stories_check"

    # V65: Count profile posts.
    if result["ok"] and result["entity"] is not None:
        posts_result = await profile_count_posts(result["entity"])
        result["has_posts"] = posts_result.get("has_posts", False)
        result["posts_count"] = posts_result.get("posts_count", 0)
        result["text_posts"] = posts_result.get("text_posts", 0)
        result["media_posts"] = posts_result.get("media_posts", 0)
        result["latest_post_id"] = posts_result.get("latest_post_id", 0)
        result["posts_reason"] = posts_result.get("reason", "")
        if not posts_result.get("ok"):
            result["posts_failure_stage"] = "posts_check"
        else:
            result["posts_failure_stage"] = ""
    else:
        result["has_posts"] = False
        result["posts_count"] = 0
        result["text_posts"] = 0
        result["media_posts"] = 0
        result["latest_post_id"] = 0
        result["posts_reason"] = "Entity not resolved"
        result["posts_failure_stage"] = "entity_not_resolved"

    return result


async def profile_download_photo(user_ref: str | int, all_photos: bool = False,
                                  progress_cb=None) -> dict[str, Any]:
    """V64: Download profile photo(s) via MTProto.

    Args:
        user_ref: @username, user ID, or t.me link.
        all_photos: If True, download ALL profile photos. If False, only the latest.
        progress_cb: Optional progress callback.

    Returns:
        {ok, paths: list[Path], count, error}
    """
    result: dict[str, Any] = {"ok": False, "paths": [], "count": 0, "error": ""}
    if not mtproto_is_started():
        result["error"] = "MTProto is not started"
        return result
    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        return result

    # Resolve entity.
    # V65 Fix: use enhanced resolver for numeric IDs.
    try:
        ref = user_ref
        is_numeric = False
        if isinstance(user_ref, str):
            stripped = user_ref.strip().lstrip("@")
            if stripped.isdigit():
                ref = int(stripped)
                is_numeric = True
            else:
                ref = stripped
        if is_numeric and isinstance(ref, int) and ref > 10000:
            entity, _method = await profile_resolve_user_id(client, ref)
            if entity is None:
                result["error"] = "Unable to resolve user ID. Try @username or t.me link."
                return result
        else:
            entity = await mtproto_call_with_retry(client.get_entity, ref)
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"Entity resolution failed: {type(exc).__name__}"
        return result

    # Download profile photo(s).
    try:
        if all_photos:
            # Download all photos. Telethon's download_profile_photos downloads
            # all available photos when file is a directory or bytes.
            # We'll download each photo individually.
            photos_downloaded: list[Path] = []
            # Get the photo list via photos.GetUserPhotosRequest.
            from telethon.tl.functions.photos import GetUserPhotosRequest
            user_id = getattr(entity, "id", 0)
            if not user_id:
                result["error"] = "Cannot resolve user ID for photo download"
                return result
            offset = 0
            max_id = 0
            limit = 100
            # TLG-E-002: GetUserPhotosRequest paginates by `max_id` (cursor)
            # — incrementing `offset` in addition to advancing `max_id` skips
            # photos on every page after the first.  Keep `offset` fixed at 0
            # and let `max_id` carry the cursor.
            # RELI-E-006: bound the loop at 50 pages (50 × 100 = 5 000 photos)
            # so a buggy server / infinite-empty-response bug can never pin
            # this coroutine in an unbounded while-True.
            for _page in range(50):
                resp = await client(GetUserPhotosRequest(
                    user_id=entity, offset=offset, max_id=max_id, limit=limit))
                if not resp or not hasattr(resp, "photos") or not resp.photos:
                    break
                for i, photo in enumerate(resp.photos):
                    fname = f"profile_{user_id}_{len(photos_downloaded) + i}.jpg"
                    target = unique_path(config.downloads_dir, fname)
                    path = await client.download_media(photo, file=str(target))
                    if path:
                        photos_downloaded.append(Path(path))
                if len(resp.photos) < limit:
                    break
                max_id = resp.photos[-1].id
            result["paths"] = photos_downloaded
            result["count"] = len(photos_downloaded)
            result["ok"] = len(photos_downloaded) > 0
            if not photos_downloaded:
                result["error"] = "No profile photos found"
        else:
            # Download only the latest photo.
            fname = f"profile_{getattr(entity, 'id', 'unknown')}_latest.jpg"
            target = unique_path(config.downloads_dir, fname)
            path = await client.download_profile_photo(entity, file=str(target))
            if path:
                result["paths"] = [Path(path)]
                result["count"] = 1
                result["ok"] = True
            else:
                result["error"] = "No profile photo found"
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"Photo download failed: {type(exc).__name__}: {str(exc)[:120]}"
        logger.warning("PROFILE_PHOTO_DOWNLOAD failed ref=%s exc=%s: %s",
                       str(user_ref)[:50], type(exc).__name__, str(exc)[:120])

    return result


async def profile_download_stories(user_ref: str | int, all_stories: bool = False,
                                    progress_cb=None) -> dict[str, Any]:
    """V64: Download stories via MTProto.

    Args:
        user_ref: @username, user ID, or t.me link.
        all_stories: If True, download ALL stories. If False, only the latest.
        progress_cb: Optional progress callback.

    Returns:
        {ok, paths: list[Path], count, captions: list[str], error, accessible}
    """
    result: dict[str, Any] = {
        "ok": False, "paths": [], "count": 0, "captions": [],
        "error": "", "accessible": True,
    }
    if not mtproto_is_started():
        result["error"] = "MTProto is not started"
        return result
    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        return result

    # Resolve entity.
    # V65 Fix: use enhanced resolver for numeric IDs.
    try:
        ref = user_ref
        is_numeric = False
        if isinstance(user_ref, str):
            stripped = user_ref.strip().lstrip("@")
            if stripped.isdigit():
                ref = int(stripped)
                is_numeric = True
            else:
                ref = stripped
        if is_numeric and isinstance(ref, int) and ref > 10000:
            entity, _method = await profile_resolve_user_id(client, ref)
            if entity is None:
                result["error"] = "Unable to resolve user ID. Try @username or t.me link."
                return result
        else:
            entity = await mtproto_call_with_retry(client.get_entity, ref)
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"Entity resolution failed: {type(exc).__name__}"
        return result
    try:
        from telethon.tl.functions.stories import GetPeerStoriesRequest
        stories_resp = await client(GetPeerStoriesRequest(peer=entity))
        if not stories_resp or not hasattr(stories_resp, "stories"):
            result["accessible"] = False
            result["error"] = "Stories are not visible to this account."
            return result
        story_list = stories_resp.stories
        if not story_list or not hasattr(story_list, "stories"):
            result["accessible"] = False
            result["error"] = "Stories are not visible to this account."
            return result
        stories = story_list.stories
        if not stories:
            result["accessible"] = True
            result["error"] = "No stories available."
            return result

        # Limit to latest if not all_stories.
        to_download = stories if all_stories else [stories[0]]

        user_id = getattr(entity, "id", "unknown")
        downloaded: list[Path] = []
        captions: list[str] = []

        for i, story in enumerate(to_download):
            try:
                # Story media is in story.media.
                media = getattr(story, "media", None)
                if media is None:
                    continue
                # Determine file extension.
                media_type = _mtproto_media_type(media) or "media"
                ext = {"video": ".mp4", "photo": ".jpg", "document": ".bin"}.get(media_type, ".bin")
                fname = f"story_{user_id}_{getattr(story, 'id', i)}{ext}"
                target = unique_path(config.downloads_dir, fname)
                path = await client.download_media(media, file=str(target))
                if path:
                    downloaded.append(Path(path))
                    # Extract caption if available.
                    caption = ""
                    if hasattr(story, "caption") and story.caption:
                        caption = story.caption
                    captions.append(caption)
            except Exception as story_exc:  # noqa: BLE001
                logger.warning("STORY_DOWNLOAD_ITEM_FAILED story_id=%s exc=%s: %s",
                               getattr(story, "id", "?"), type(story_exc).__name__,
                               str(story_exc)[:80])

        result["paths"] = downloaded
        result["count"] = len(downloaded)
        result["ok"] = len(downloaded) > 0
        if not downloaded:
            result["error"] = "No story media could be downloaded"
        result["accessible"] = True
    except Exception as exc:  # noqa: BLE001
        # Check if it's a privacy/permission error.
        exc_str = str(exc).lower()
        if "private" in exc_str or "forbidden" in exc_str or "not found" in exc_str:
            result["accessible"] = False
            result["error"] = "Stories are not visible to this account."
        else:
            result["error"] = f"Story download failed: {type(exc).__name__}: {str(exc)[:120]}"
            logger.warning("PROFILE_STORY_DOWNLOAD failed ref=%s exc=%s: %s",
                           str(user_ref)[:50], type(exc).__name__, str(exc)[:120])

    return result


def profile_format_info(info: dict[str, Any]) -> str:
    """V64: Format profile info into a clean user-friendly message."""
    lines = ["👤 *Profile Info*\n"]
    name_parts = []
    if info.get("first_name"):
        name_parts.append(info["first_name"])
    if info.get("last_name"):
        name_parts.append(info["last_name"])
    full_name = " ".join(name_parts) or "—"
    lines.append(f"Name: `{md_escape(full_name)}`")
    lines.append(f"Username: `@{md_escape(info.get('username', '—'))}`" if info.get("username") else "Username: —")
    lines.append(f"User ID: `{info.get('user_id', '—')}`")
    if info.get("bio"):
        lines.append(f"Bio: `{md_escape(info['bio'][:200])}`")
    # Status flags.
    flags = []
    if info.get("is_premium"):
        flags.append("⭐ Premium")
    if info.get("is_verified"):
        flags.append("✅ Verified")
    if info.get("is_scam"):
        flags.append("⚠️ Scam")
    if info.get("is_fake"):
        flags.append("⚠️ Fake")
    if flags:
        lines.append(f"Status: {' · '.join(flags)}")
    lines.append(f"Photos: `{info.get('photo_count', 0)}`")
    # V66: Show posts instead of stories in profile card.
    if info.get("has_posts"):
        lines.append(f"Posts: `{info.get('posts_count', 0)}`")
    else:
        reason = info.get("posts_reason", "")
        if reason:
            lines.append(f"Posts: — ({reason})")
        else:
            lines.append("Posts: — (none found)")
    return "\n".join(lines)


def _check_stories_api_available() -> bool:
    """V64: Check if the Telethon version supports the stories API."""
    try:
        from telethon.tl.functions.stories import GetPeerStoriesRequest  # noqa: F401
        return True
    except ImportError:
        return False


# V65: Profile Posts detection + download functions.

async def profile_resolve_user_id(client, user_id: int) -> tuple[Any, str]:
    """V65: Resolve a numeric User ID to an entity using multiple strategies.

    Telegram only allows resolving users that the MTProto account already
    knows. This function tries multiple resolution paths:

    1. Direct get_entity (works if access_hash is cached)
    2. Dialogs scan (search through existing conversations)
    3. Contacts lookup
    4. Common groups participant lookup

    Returns (entity, resolution_method) or (None, error_reason).
    """
    # Strategy 1: Direct get_entity (works if Telethon has a cached access_hash).
    try:
        entity = await mtproto_call_with_retry(client.get_entity, user_id)
        if entity is not None:
            return entity, "direct_get_entity"
    except Exception as exc:  # noqa: BLE001
        exc_str = str(exc).lower()
        logger.info("PROFILE_USER_ID_RESOLVE direct failed user_id=%s exc=%s: %s",
                     user_id, type(exc).__name__, str(exc)[:100])
        # V65 Audit Fix: detect the specific "input entity not found" error
        # and the struct.pack overflow for IDs > int32.
        if "could not find the input entity" in exc_str:
            logger.info("PROFILE_USER_ID_RESOLVE user_id=%s — access_hash not cached, "
                        "trying alternative strategies", user_id)
        elif "'i' format requires" in exc_str or "struct" in exc_str:
            # V65 Audit Fix: user_id > 2^31 causes struct.pack overflow in
            # some Telethon versions when building InputPeerUser. This is a
            # Telethon limitation, not a bot bug. The ID is valid but Telethon
            # can't construct the input peer without a cached access_hash.
            logger.warning("PROFILE_USER_ID_RESOLVE user_id=%s — Telethon struct.pack "
                          "overflow (ID > int32). Trying alternative strategies.", user_id)

    # Strategy 2: Dialogs scan — search through existing conversations.
    try:
        async for dialog in client.iter_dialogs(limit=500):
            peer = dialog.entity
            if getattr(peer, "id", None) == user_id:
                return peer, "dialogs_scan"
    except Exception as exc:  # noqa: BLE001
        logger.info("PROFILE_USER_ID_RESOLVE dialogs failed user_id=%s exc=%s: %s",
                     user_id, type(exc).__name__, str(exc)[:100])

    # Strategy 3: Contacts lookup.
    try:
        from telethon.tl.functions.contacts import GetContactsRequest
        contacts_resp = await client(GetContactsRequest(hash=0))
        if contacts_resp and hasattr(contacts_resp, "contacts"):
            for contact in contacts_resp.contacts:
                user_obj = getattr(contact, "user_id", None)
                if user_obj == user_id:
                    # Found in contacts — try get_entity again (access_hash now cached).
                    entity = await mtproto_call_with_retry(client.get_entity, user_id)
                    if entity is not None:
                        return entity, "contacts_lookup"
    except Exception as exc:  # noqa: BLE001
        logger.info("PROFILE_USER_ID_RESOLVE contacts failed user_id=%s exc=%s: %s",
                     user_id, type(exc).__name__, str(exc)[:100])

    # Strategy 4: Common groups participant lookup.
    try:
        from telethon.tl.functions.channels import GetParticipantsRequest
        from telethon.tl.types import ChannelParticipantsSearch
        # Scan recently discovered VC groups for the user.
        groups = await vc_groups_active(limit=50)
        for g in groups:
            gid = g.get("group_id")
            access_hash = g.get("access_hash") or 0
            if not gid or not access_hash:
                continue
            try:
                from telethon.tl.types import InputPeerChannel
                entity_ch = await client.get_entity(
                    InputPeerChannel(int(gid), int(access_hash)))
                resp = await client(GetParticipantsRequest(
                    channel=entity_ch,
                    filter=ChannelParticipantsSearch(""),
                    offset=0, limit=200, hash=0))
                if resp and hasattr(resp, "participants"):
                    for participant in resp.participants:
                        pid = getattr(participant, "user_id", None)
                        if pid == user_id:
                            # Found in a common group — try get_entity.
                            entity = await mtproto_call_with_retry(
                                client.get_entity, user_id)
                            if entity is not None:
                                return entity, "common_groups"
            except Exception:  # noqa: BLE001
                continue
    except Exception as exc:  # noqa: BLE001
        logger.info("PROFILE_USER_ID_RESOLVE common_groups failed user_id=%s exc=%s: %s",
                     user_id, type(exc).__name__, str(exc)[:100])

    return None, "access_hash_unavailable"


async def profile_count_posts(entity) -> dict[str, Any]:
    """V66.2: Count profile posts (pinned stories) for a user.

    ROOT CAUSE FOUND:
    GetPeerStoriesRequest only returns ACTIVE (expiring) stories.
    The "Posts" tab in Telegram shows PINNED stories — stories the user
    has chosen to keep visible permanently. These are fetched via a
    SEPARATE API: stories.GetPinnedStoriesRequest(peer, offset_id, limit).

    GetPinnedStoriesRequest returns stories.Stories:
      - count: int (total pinned stories)
      - stories: [StoryItem] (each with id, date, media, caption, pinned, public)
      - pinned_to_top: [int] (IDs of stories pinned to top)

    This is the CORRECT API for the Profile → Posts tab.

    Returns:
      {ok, posts_count, has_posts, text_posts, media_posts, latest_post_id,
       pinned_count, public_count, total_stories, error, reason}
    """
    result: dict[str, Any] = {
        "ok": False, "posts_count": 0, "has_posts": False,
        "text_posts": 0, "media_posts": 0, "latest_post_id": 0,
        "pinned_count": 0, "public_count": 0, "total_stories": 0,
        "error": "", "reason": "",
    }
    if not mtproto_is_started():
        result["error"] = "MTProto is not started"
        result["reason"] = "mtproto_not_started"
        logger.info("PROFILE_POSTS_FETCH user_id=? ok=false reason=mtproto_not_started")
        return result
    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        result["reason"] = "client_unavailable"
        logger.info("PROFILE_POSTS_FETCH user_id=? ok=false reason=client_unavailable")
        return result

    user_id = getattr(entity, "id", 0)
    if not user_id:
        result["error"] = "Cannot determine user ID"
        result["reason"] = "no_user_id"
        return result

    try:
        # V66.2 FIX: Use GetPinnedStoriesRequest — the CORRECT API for the
        # "Posts" tab. GetPeerStoriesRequest only returns active (expiring)
        # stories, NOT pinned posts.
        from telethon.tl.functions.stories import GetPinnedStoriesRequest
        resp = await client(GetPinnedStoriesRequest(
            peer=entity, offset_id=0, limit=100))

        logger.info("PROFILE_POSTS_RESPONSE user_id=%s resp_type=%s count=%s "
                    "stories_len=%s pinned_to_top=%s",
                    user_id,
                    type(resp).__name__ if resp else "None",
                    getattr(resp, "count", "N/A") if resp else "N/A",
                    len(getattr(resp, "stories", []) or []) if resp else 0,
                    getattr(resp, "pinned_to_top", []) if resp else [])

        if resp is None:
            result["ok"] = True
            result["reason"] = "no_response"
            return result

        # stories.Stories has: count (int), stories ([StoryItem]), pinned_to_top ([int])
        total_count = int(getattr(resp, "count", 0) or 0)
        all_stories = getattr(resp, "stories", None) or []
        pinned_to_top = getattr(resp, "pinned_to_top", None) or []

        media_count = 0
        text_count = 0
        latest_id = 0
        pinned_count = 0
        public_count = 0

        for story in all_stories:
            if story is None:
                continue
            story_id = getattr(story, "id", 0)
            if story_id and not latest_id:
                latest_id = story_id
            if getattr(story, "pinned", False):
                pinned_count += 1
            if getattr(story, "public", False):
                public_count += 1
            if getattr(story, "media", None):
                media_count += 1
            else:
                text_count += 1

        actual_count = total_count if total_count > 0 else len(all_stories)

        result["ok"] = True
        result["posts_count"] = actual_count
        result["has_posts"] = actual_count > 0
        result["text_posts"] = text_count
        result["media_posts"] = media_count
        result["latest_post_id"] = latest_id
        result["pinned_count"] = pinned_count
        result["public_count"] = public_count
        result["total_stories"] = len(all_stories)
        logger.info("PROFILE_POSTS_COUNT user_id=%s posts=%d pinned=%d public=%d "
                    "total=%d media=%d text=%d latest_id=%s (server_count=%d)",
                    user_id, actual_count, pinned_count, public_count,
                    len(all_stories), media_count, text_count, latest_id,
                    total_count)
        # V72 PART 18: PROFILE_POSTS_FETCH success log.
        logger.info("PROFILE_POSTS_FETCH user_id=%s ok=true posts_count=%d "
                    "pinned=%d public=%d media=%d text=%d",
                    user_id, actual_count, pinned_count, public_count,
                    media_count, text_count)
    except ImportError:
        result["error"] = "GetPinnedStoriesRequest not available in this Telethon version"
        result["reason"] = "api_unsupported"
        logger.warning("PROFILE_POSTS_COUNT_FAILED user_id=%s — GetPinnedStoriesRequest not available",
                       user_id)
    except Exception as exc:  # noqa: BLE001
        exc_name = type(exc).__name__
        exc_str = str(exc)[:150]
        exc_lower = exc_str.lower()
        result["error"] = f"Post count failed: {exc_name}: {exc_str[:80]}"
        if "private" in exc_lower or "forbidden" in exc_lower:
            result["reason"] = "Profile inaccessible (privacy)"
        elif "not found" in exc_lower or "peer" in exc_lower:
            result["reason"] = "Cannot resolve peer for posts"
        elif "flood" in exc_lower:
            result["reason"] = "FloodWait — try again later"
        elif "input entity" in exc_lower:
            result["reason"] = "Access hash unavailable (user not known to MTProto account)"
        elif "hashtag" in exc_lower:
            result["reason"] = "API rejected request (HASHTAG_INVALID — this should not occur with GetPinnedStoriesRequest)"
        else:
            result["reason"] = f"Request failed: {exc_name}: {exc_str[:80]}"
        logger.warning("PROFILE_POSTS_COUNT_FAILED user_id=%s exc=%s: %s — reason=%s",
                       user_id, exc_name, exc_str, result["reason"])

    return result


async def profile_download_posts(user_ref: str | int,
                                  latest_only: bool = False,
                                  progress_cb=None) -> dict[str, Any]:
    """V65: Download profile posts (text + media) for a user.

    Args:
        user_ref: @username, user ID, or t.me link.
        latest_only: If True, download only the latest post. If False, download all.
        progress_cb: Optional progress callback.

    Returns:
        {ok, posts: list[{message_id, text, media_path, media_type, date, caption}],
         count, error, reason}
    """
    result: dict[str, Any] = {
        "ok": False, "posts": [], "count": 0, "error": "", "reason": "",
    }
    if not mtproto_is_started():
        result["error"] = "MTProto is not started"
        return result
    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        return result

    # Resolve entity.
    # V65 Fix: use enhanced resolver for numeric IDs.
    try:
        ref = user_ref
        is_numeric = False
        if isinstance(user_ref, str):
            stripped = user_ref.strip().lstrip("@")
            if stripped.isdigit():
                ref = int(stripped)
                is_numeric = True
            else:
                ref = stripped
        if is_numeric and isinstance(ref, int) and ref > 10000:
            entity, _method = await profile_resolve_user_id(client, ref)
            if entity is None:
                result["error"] = "Unable to resolve user ID. Try @username or t.me link."
                result["reason"] = "user_id_unresolvable"
                return result
        else:
            entity = await mtproto_call_with_retry(client.get_entity, ref)
    except Exception as exc:  # noqa: BLE001
        result["error"] = f"Entity resolution failed: {type(exc).__name__}"
        result["reason"] = "entity_resolution"
        return result

    # V66.2 FIX: Use GetPinnedStoriesRequest — the CORRECT API for profile posts.
    try:
        from telethon.tl.functions.stories import GetPinnedStoriesRequest
        resp = await client(GetPinnedStoriesRequest(
            peer=entity, offset_id=0, limit=100))

        if resp is None or not getattr(resp, "stories", None):
            result["ok"] = True
            result["error"] = "No posts found"
            return result

        all_stories = resp.stories
        posts_to_download = all_stories if not latest_only else ([all_stories[0]] if all_stories else [])

        if not posts_to_download:
            result["ok"] = True
            result["error"] = "No posts found"
            return result

        downloaded_posts: list[dict[str, Any]] = []
        user_id = getattr(entity, "id", "unknown")

        for story in posts_to_download:
            post: dict[str, Any] = {
                "message_id": getattr(story, "id", 0),
                "text": "",
                "media_path": None,
                "media_type": "text",
                "date": str(getattr(story, "date", "")),
                "caption": getattr(story, "caption", "") or "",
            }
            # Download media if present.
            media = getattr(story, "media", None)
            if media:
                media_type = _mtproto_media_type(media) or "media"
                post["media_type"] = media_type
                try:
                    ext = {"video": ".mp4", "photo": ".jpg", "document": ".bin",
                           "audio": ".mp3", "voice": ".ogg"}.get(media_type, ".bin")
                    fname = f"post_{user_id}_{post['message_id']}{ext}"
                    target = unique_path(config.downloads_dir, fname)
                    path = await client.download_media(media, file=str(target))
                    if path:
                        post["media_path"] = Path(path)
                except Exception as media_exc:  # noqa: BLE001
                    logger.warning("PROFILE_POST_MEDIA_FAILED story_id=%s exc=%s: %s",
                                   post["message_id"], type(media_exc).__name__,
                                   str(media_exc)[:80])
            downloaded_posts.append(post)

        result["posts"] = downloaded_posts
        result["count"] = len(downloaded_posts)
        result["ok"] = len(downloaded_posts) > 0
        if not downloaded_posts:
            result["error"] = "No posts could be downloaded"
        logger.info("PROFILE_POSTS_DOWNLOAD user_id=%s count=%d latest_only=%s",
                    user_id, result["count"], latest_only)
    except ImportError:
        result["error"] = "GetPinnedStoriesRequest not available in this Telethon version"
        result["reason"] = "api_unsupported"
    except Exception as exc:  # noqa: BLE001
        exc_name = type(exc).__name__
        exc_str = str(exc)[:150]
        exc_lower = exc_str.lower()
        if "private" in exc_lower or "forbidden" in exc_lower:
            result["reason"] = "Profile inaccessible (privacy)"
        elif "input entity" in exc_lower:
            result["reason"] = "Access hash unavailable (user not known to MTProto account)"
        else:
            result["reason"] = f"Request failed: {exc_name}: {exc_str[:80]}"
        result["error"] = f"Post download failed: {exc_name}: {exc_str[:80]}"
        logger.warning("PROFILE_POSTS_DOWNLOAD_FAILED ref=%s exc=%s: %s — reason=%s",
                       str(user_ref)[:50], exc_name, exc_str, result["reason"])

    return result


def profile_is_profile_link(text: str) -> bool:
    """V64: Check if text is a profile link (@username, user ID, or t.me/username).

    Excludes message links (t.me/username/123) and invite links (t.me/+...).
    """
    if not text:
        return False
    text = text.strip().strip("`<>()")
    if not text:
        return False
    # @username
    if _AT_USERNAME_RE.match(text):
        return True
    # Numeric user ID (6+ digits).
    if _CHAT_ID_RE.match(text) and not text.startswith("-"):
        return True
    # t.me/username (no message ID after).
    m = _PUBLIC_CHANNEL_LINK_RE.search(text)
    if m:
        return True
    # t.me/username (with trailing slash removed).
    if "t.me/" in text.lower():
        # Check it's NOT a message link or invite link.
        if "/c/" in text or "/joinchat/" in text or "/+" in text:
            return False
        # t.me/username — check no message ID after.
        parts = text.lower().split("t.me/")
        if len(parts) == 2:
            remainder = parts[1].strip("/")
            if "/" not in remainder and remainder:
                return True
    return False


# ===========================================================================
# Services — VC transport (real group-call backend abstraction, optional)
# ===========================================================================
# This section provides a clean :class:`VCBackend` abstraction over the
# Telegram voice-chat transport. The tour subsystem talks ONLY to this
# interface — it never constructs raw ``JoinGroupCallRequest`` calls itself.
#
# Backend selection
# -----------------
# The primary backend is **PyTgCalls** — a maintained Python library that
# wraps the MTProto group-call protocol with a real UDP transport. PyTgCalls
# establishes a genuine voice-chat session (the userbot appears as a connected
# participant).
#
# If ``pytgcalls`` is not installed (or VC is disabled), the backend reports
# ``is_available() == False`` and the tour refuses to start — it NEVER fakes a
# join with ``params=None``.
#
# Compatibility note
# ------------------
# PyTgCalls requires its own ``MTProtoClient`` which can be a Telethon client.
# We reuse the existing authenticated Telethon client from ``mtproto_manager``
# via ``PyTgCalls(client)`` — no second session is created. PyTgCalls is
# lazy-imported so the bot still starts when VC support is unavailable.
#
# Lifecycle semantics
# -------------------
# A join is only reported as successful AFTER:
#   1. ``backend.join(chat)`` returns without error, AND
#   2. ``backend.is_connected()`` confirms the connection, AND
#   3. ``backend.verify_joined(chat_id)`` confirms participant state.
#
# A visit is recorded as ``joining`` → ``joined`` (on verification) →
# ``completed`` / ``failed`` / ``disconnected``.
# ===========================================================================


class VCTransportError(Exception):
    """Raised when a VC transport operation fails."""


class VCResourcePressureError(VCTransportError):
    """v99.10 FIX-B: raised when a VC join cannot allocate a native resource.

    Production evidence (2026-09-20 11:34:16→11:36:46): 41×
    ``BlockingIOError: [Errno 11] Resource temporarily unavailable`` from
    PyTgCalls joins at ~60 concurrent joined VCs — the native ntgcalls
    media pipeline (threads + SRTP + jitter buffers + UDP sockets) could
    not allocate under cgroup memory pressure, and the process was
    OOM-killed twice mid-join (~12 min apart).  This error is a
    VCTransportError subclass so every existing ``except VCTransportError``
    site keeps working, but carries DIFFERENT semantics for the callers
    that check for it:

      * NEVER immediately retried (the allocator is starved — the v99.09
        run burned 3 retries in 6s, all failing);
      * NEVER recorded as a circuit-breaker failure (the breaker would
        punish the wrong layer and can open on threshold=1 systemic);
      * the target is DEFERRED (requeued with a later retry) and the
        Join-All worker enters a bounded resource-pressure wait;
      * classified by ``_vc_classify_join_transport_error`` /
        ``vc_pipeline._classify_transport_exc`` as ``"resource_pressure"``.
    """


def is_resource_pressure_error(exc: BaseException) -> bool:
    """v99.10 FIX-B: true when *exc* is (or wraps) a resource-pressure failure.

    Checks the exception TYPE first (VCResourcePressureError, or any
    OSError with EAGAIN/ENOMEM/EMFILE/ENFILE errno), then the message text
    (``[Errno 11]``, "Resource temporarily unavailable", "Too many open
    files", "can't start new thread", "No buffer space").  Used by the
    Join-All worker + reconcile paths to defer instead of retry/record.
    """
    if isinstance(exc, VCResourcePressureError):
        return True
    if isinstance(exc, OSError):
        try:
            if int(getattr(exc, "errno", 0) or 0) in (11, 12, 23, 24):
                return True
        except Exception:  # noqa: BLE001
            pass
    t = f"{type(exc).__name__}: {exc}".lower()
    return ("resource pressure" in t
            or "resource temporarily unavailable" in t
            or "[errno 11]" in t
            or "errno 11" in t
            or "too many open files" in t
            or "can't start new thread" in t
            or "cant start new thread" in t
            or "no buffer space" in t)


# ---------------------------------------------------------------------------
# SEC-E-001: access_hash redaction helper for log output.
# Telegram access hashes are account-specific secrets; logging the raw value
# would leak a credential usable to impersonate the holder in MTProto
# requests.  _redact_ah() keeps only the first 4 characters as a debug aid
# (so operators can still correlate log lines across calls) and replaces the
# rest with an ellipsis.
# ---------------------------------------------------------------------------
def _redact_ah(ah: Any) -> str:
    """Return a redacted representation of an access_hash for logging."""
    if ah is None or ah == 0:
        return "0"
    s = str(ah)
    if not s:
        return "0"
    return f"<{s[:4]}…>"


# ---------------------------------------------------------------------------
# V73 PART 2: 7-step entity resolution chain for VC joins.
# ---------------------------------------------------------------------------

# V73: Entity cache (chat_id → resolved entity/access_hash). Persists for the
# process lifetime. Prevents repeated entity fetches for the same chat.
_vc_entity_cache: dict[int, dict[str, Any]] = {}
# V85.4 (Req 9): per-client scoped entity cache to prevent cross-account
# access-hash contamination.  v99 RC-C: keyed by (SCOPE TOKEN, chat_id) —
# "global" / "acc_<id>" — NOT id(client) (transient for per-call gated
# proxies; id-reuse could serve a foreign account's entry).  Checked
# BEFORE the global _vc_entity_cache in resolve_entity_full.
_vc_entity_cache_by_client: dict[tuple, dict[str, Any]] = {}

# ---------------------------------------------------------------------------
# v98.10 (§§7/§10-12/§22/§41) — account-scoped resolution state.  Declared
# BEFORE the module-level persistence load below so a restart seeds the
# scoped access state at import time (successful resolutions must keep
# stopping future retries ACROSS restarts — §12).
# ---------------------------------------------------------------------------
_v9810_access_state: dict[tuple[str, int], dict[str, Any]] = {}
_v9810_hash_invalid: dict[tuple[str, int], dict[str, Any]] = {}
_v9810_resolve_inflight: dict[tuple[str, int], Any] = {}
_v9810_resolution_stats: dict[str, int] = {
    "attempts": 0, "successes": 0, "failures": 0, "rpcs": 0,
    "failed_rpcs": 0, "rotations": 0, "cache_hits": 0,
    "scope_state_hits": 0, "hash_invalid_skips": 0,
    "singleflight_joins": 0, "representation_errors": 0,
}
_v9810_resolution_latency_ms: list[float] = []


# ---------------------------------------------------------------------------
# v98.07 FIX-QQ (F2 — per-account resolution poisoning, RUNTIME-PROVEN via
# bot-diagnostic.log.1 pid=7670: 237x "Invalid channel object" discovery
# skips + 179x VC_PARTICIPATION_REDETECT_FAILED, all on the account client
# consuming cross-scope access hashes/entities):
#   Telegram access_hash is ACCOUNT-SCOPED for non-member channels. The
#   global ``_vc_entity_cache`` is keyed ONLY by chat_id — an entity
#   resolved by account A (e.g. source=account_rotation:acc_A from the
#   join path, or _global discovery scope) carries A's access_hash.
#   When account B's client (or the global client) consumes that entity
#   in GetFullChannelRequest → ChannelInvalidError ("Invalid channel
#   object"). This is the same BUG CLASS as v98.06 FIX-LL (bare-id /
#   cross-account resolution), one call-site over.
# Every cache entry now carries a ``scope`` (the account id that resolved
# it, "global" for the primary client, "client:<id>" otherwise). Readers
# MUST NOT consume an entry whose scope does not match the consuming
# client's scope — they re-resolve instead.
# ---------------------------------------------------------------------------
def _v9908_cluster_identity(client: Any) -> str:
    """v99.08 Patch-9: the TRUE owning account id of *client* from the
    cluster registries, or '' when the client is not cluster-registered.

    Checks ``_clients`` (the real cluster's live-client map) then
    ``_accounts`` (the fake-cluster shape that nests the client inside
    per-account dicts).  Used by ``_v9908_rotation_scope_conflict`` to
    detect the rotation-window misattribution (set_primary_id swaps
    the primary ACCOUNT ID but preserves the client object — the live
    session stays the OLD primary's).  Never raises."""
    try:
        if client is None:
            return ""
        _cluster = _userbot_cluster
        if _cluster is None:
            return ""
        _clients_map = getattr(_cluster, "_clients", None)
        if isinstance(_clients_map, dict):
            for _aid, _c in _clients_map.items():
                if (isinstance(_aid, str)
                        and not _aid.startswith("__")
                        and _c is client):
                    return str(_aid)
        _accs = getattr(_cluster, "_accounts", None)
        if isinstance(_accs, dict):
            for _aid, _acc in _accs.items():
                if (isinstance(_aid, str)
                        and not _aid.startswith("__")
                        and isinstance(_acc, dict)
                        and _acc.get("client") is client):
                    return str(_aid)
    except Exception:  # noqa: BLE001
        pass
    return ""


def _v9908_rotation_scope_conflict(client: Any) -> str:
    """v99.08 Patch-9: '' unless the primary-id binding would
    MISattribute *client*.

    The rotation window: ``set_primary_id`` swaps the primary ACCOUNT
    ID but NOT the client object (vc_reset_backend → PRESERVED — the
    live session, its cluster entry and ``_mtproto_client`` stay the
    OLD primary's).  Binding that client to the NEW primary id let
    vc_detect_active_call RE-ANNOTATE the old owner's entities under
    the new primary's scope — the poisoned flat entries the new
    primary then consumed (2026-09-19 production: 27x
    VC_HASH_SCOPE_MISMATCH → "Invalid channel object" → eligible=0
    channel_invalid=25).

    Returns the TRUE owning account id ONLY when a cluster identity
    exists AND differs from the current primary id; '' otherwise (no
    conflict → the historical v99.06 binding stands unchanged —
    including the no-primary "global" fallback and the steady state
    where both sources agree)."""
    try:
        _cid = _v9908_cluster_identity(client)
        if not _cid:
            return ""
        _pid = get_primary_account_id()
        if _pid and str(_pid) != _cid:
            return _cid
    except Exception:  # noqa: BLE001
        pass
    return ""


def _vc_client_scope(client: Any) -> str:
    """Return the resolution scope of *client* (v98.07 FIX-QQ).

    "global"          - the primary MTProto client (_mtproto_client) or a
                        gated proxy wrapping it (client_id="global")
    "acc_<id>"        - a cluster account client (raw client found in the
                        cluster registry, or a gated proxy wrapping it
                        with client_id="cluster:<aid>")
    "client:<id>"     - any other client object (stable per object)
    Never raises; "(unknown)" on lookup failure.

    v98.11 S9 (production (5).log root cause): ``mtproto_get_client()``
    constructs a NEW ``_GatedClientProxy`` on EVERY call - identifying
    scopes by ``id(client)`` gave every voicechat-path resolution an
    UNSTABLE ``client:<proxy-id>`` scope.  Those scopes (a) never matched
    persisted knowledge, (b) were unroutable by the Step-0c known-good
    routing, and (c) were dead after restart - so successful resolution
    never converged into durable knowledge.  The proxy's own
    ``_client_id`` ("global" / "cluster:<aid>") is stable and is now
    consulted FIRST.  The real cluster also stores live clients in
    ``_clients`` (NOT ``_accounts``) - the reverse lookup checks BOTH
    registries (the v98.10 fake-cluster shape, which nests the client
    inside ``_accounts``, keeps working).

    v99.06 FIX-1 (1.4): the primary client NO LONGER self-identifies as
    the chameleon "global".  When get_primary_account_id() can bind the
    primary session to a REAL account id ("acc_<phone>"), that id is the
    scope — so a rotation to a different primary makes the old primary's
    cache entries structurally unshareable (scope mismatch instead of
    the 388x CHANNEL_INVALID cross-account hash consumption proven in
    the 2026-09-09 production log).  "global" remains ONLY as the
    fallback when the primary cannot be identified (single-account
    dev/test trees keep their exact v99.05 behavior).

    v99.08 Patch-9 (RUNTIME-PROVEN, bot-diagnostic (2).log 2026-09-19
    12:29:29-12:36:29): set_primary_id swaps the primary ACCOUNT ID but
    NOT the client object (vc_reset_backend → PRESERVED — the live
    session, the cluster entry and _mtproto_client stay the OLD
    primary's).  The v99.06 binding above then misattributed the OLD
    primary's live client to the NEW primary id, which (a) false-mismatched
    the old owner's own cache reads and (b) let vc_detect_active_call
    RE-ANNOTATE the old owner's entities under the NEW primary's scope
    — the poisoned flat entries the new primary then consumed
    (27x VC_HASH_SCOPE_MISMATCH -> "Invalid channel object" -> eligible=0
    channel_invalid=25).  FIX (conflict-only): when the cluster identity
    of the client EXISTS and DIFFERS from the current primary id, the
    TRUE owning account wins.  No conflict (steady state, or no primary
    set) → the historical v99.06 binding stands unchanged.
    """
    try:
        if client is None:
            return "(unknown)"
        # v98.11 S9: gated proxies carry their stable identity.
        _proxy_cid = getattr(client, "_client_id", None)
        if isinstance(_proxy_cid, str) and _proxy_cid:
            if _proxy_cid == "global":
                # v99.08 Patch-9: rotation-window guard — when the
                # proxy's underlying session is cluster-registered for
                # account X while the primary id says Y (X != Y), the
                # client object did NOT follow the id swap; the TRUE
                # owner X wins.  Every other shape keeps the v99.06
                # binding (including the no-primary "global" fallback).
                try:
                    _v9908_real = getattr(client, "_real_client", None) or client
                    _v9908_x = _v9908_rotation_scope_conflict(_v9908_real)
                    if _v9908_x:
                        return _v9908_x
                except Exception:  # noqa: BLE001
                    pass
                # v99.06 FIX-1: bind the proxy-wrapped primary to its REAL
                # account id when determinable (chameleon elimination).
                _v9906_pid = get_primary_account_id()
                return _v9906_pid if _v9906_pid else "global"
            if _proxy_cid.startswith("cluster:"):
                _aid = _proxy_cid[len("cluster:"):]
                if _aid:
                    return _aid
        # v99.08 Patch-9: rotation-window guard BEFORE the primary-id
        # binding (see _v9908_rotation_scope_conflict).  Self-contained
        # try/except so exec-context harnesses without the helper/global
        # degrade to the exact pre-v99.08 behavior.
        try:
            _v9908_x = _v9908_rotation_scope_conflict(client)
            if _v9908_x:
                return _v9908_x
        except Exception:  # noqa: BLE001
            pass
        if client is _mtproto_client:
            # v99.06 FIX-1: same binding for the raw primary client.
            _v9906_pid = get_primary_account_id()
            return _v9906_pid if _v9906_pid else "global"
        _cluster = _userbot_cluster
        if _cluster is not None:
            try:
                # v98.11 S9: the REAL cluster keeps live clients in
                # ``_clients`` (account_id -> TelegramClient).
                _clients_map = getattr(_cluster, "_clients", None)
                if isinstance(_clients_map, dict):
                    for _aid, _c in _clients_map.items():
                        if (
                                isinstance(_aid, str)
                                and not _aid.startswith("__")
                                and _c is client
                        ):
                            return str(_aid)
            except Exception:  # noqa: BLE001
                pass
            try:
                _accs = getattr(_cluster, "_accounts", None)
                if isinstance(_accs, dict):
                    for _aid, _acc in _accs.items():
                        if (
                                isinstance(_aid, str)
                                and not _aid.startswith("__")
                                and isinstance(_acc, dict)
                                and _acc.get("client") is client
                        ):
                            return str(_aid)
            except Exception:  # noqa: BLE001
                pass
        return f"client:{id(client)}"
    except Exception:  # noqa: BLE001
        return "(unknown)"

def _vc_cache_scope_ok(entry: Any, client: Any) -> bool:
    """True when *entry*'s scope is safe to consume from *client*.

    Entries WITHOUT a scope field are legacy (pre-v98.07) — treated as
    scope-unknown and still consumable (preserves the v97.78 fast path:
    when the hash IS valid for the account, the InputPeer shortcut keeps
    working; the ChannelInvalid retry in the detection callers covers the
    poisoned case). Entries WITH a scope must match the client's scope.
    """
    try:
        if not isinstance(entry, dict):
            return True
        scope = entry.get("scope")
        if not scope or scope == "(unknown)":
            return True
        return scope == _vc_client_scope(client)
    except Exception:  # noqa: BLE001
        return True


_VC_ACCESS_HASH_FILE = Path(config.project_root) / "data" / "vc_access_hashes.json"
# V85.3 FIX BUG DB-5: the second ``_vc_entity_cache`` declaration here
# previously MASKED the first one at line ~12284 (V73 section).  Both
# module-level dicts bound the same name; the second assignment won, so
# V73 ``vc_resolve_chat_entity`` writes were silently lost (written to a
# dict that was then re-bound).  Removed the duplicate — the single
# declaration at line ~12284 is the canonical cache, shared by V73 + V76.


def _v9810_seed_access_state_from_persistence(
        entries: dict[int, dict[str, Any]]) -> int:
    """v98.10 SS12: seed the account-scoped access state from persisted
    (scope-annotated) vc_access_hashes.json entries.  Only entries WITH
    a scope are seeded (legacy unattributed hashes stay hints).  The
    entity OBJECT cannot survive a restart — only the hash/kind/scope
    travel; the first resolution after restart re-materializes the
    entity with ONE typed RPC via Step 0b/0c.  Returns seeded count."""
    _n = 0
    try:
        _now = time.time()
        for _cid, _ent in entries.items():
            try:
                if not isinstance(_ent, dict):
                    continue
                _scope = str(_ent.get("scope") or "")
                if not _scope or _scope == "(unknown)":
                    continue
                # v98.11 S9: only STABLE scope tokens survive a restart.
                # "client:<id>" scopes are per-process object ids (the
                # v98.10 proxy-scope bug) - dead weight after restart and
                # unroutable by Step 0c, so they are NOT seeded (the flat
                # hash itself still loads below as a legacy hint).
                if not (_scope == "global" or _scope.startswith("acc_")):
                    continue
                _ah = _ent.get("access_hash")
                if _ah in (None, ""):
                    continue
                _ah = int(_ah)
                _cid = int(_cid)
                _marked = _cid if _cid < 0 else -1000000000000 - _cid
                _raw = -(_marked + 1000000000000)
                _entry = {
                    "entity": None,
                    "access_hash": _ah,
                    "kind": str(_ent.get("kind") or ""),
                    "scope": _scope,
                    "verified_at": float(_ent.get("saved_at") or _now),
                    "source": "persisted",
                }
                _v9810_access_state[(_scope, _marked)] = _entry
                _v9810_access_state[(_scope, _raw)] = _entry
                _n += 1
            except Exception:  # noqa: BLE001
                continue
        if _n:
            logger.info(
                "ENTITY_ACCESS_STATE_SEEDED entries=%d — account-scoped "
                "resolution knowledge survived the restart (v98.10 SS12)",
                _n,
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("ENTITY_ACCESS_STATE_SEED_FAILED exc=%s", exc)
    return _n



def _load_access_hash_persistence() -> dict[int, dict[str, Any]]:
    """Load persisted access hashes."""
    try:
        if _VC_ACCESS_HASH_FILE.exists():
            data = _json_module.loads(_VC_ACCESS_HASH_FILE.read_text())
            if isinstance(data, dict):
                out_v9810: dict[int, dict[str, Any]] = {
                    int(k): v for k, v in data.items()
                    if isinstance(v, dict) and "access_hash" in v}
                # v98.10 SS12: entries carrying a ``scope`` ALSO seed the
                # account-scoped access state so restarts know WHICH
                # account each hash works for (successful resolution
                # keeps stopping future retries).  Legacy entries (no
                # scope) load exactly as before (SS31: additive fields,
                # no invalidation, no format break).
                _v9810_seed_access_state_from_persistence(out_v9810)
                return out_v9810
    except Exception as exc:
        # SEC-E-002: previously `except Exception: pass` silently swallowed
        # JSON / IO errors — a corrupted persistence file looked identical
        # to a missing one, hiding data-loss bugs.  Log at WARNING so
        # operators see when the file fails to parse.
        logger.warning("VC_ACCESS_HASH_LOAD_FAILED exc=%s", exc)
    return {}


def _save_access_hash_persistence(hashes: dict[int, dict[str, Any]]) -> None:
    """Persist access hashes to disk."""
    try:
        _VC_ACCESS_HASH_FILE.parent.mkdir(parents=True, exist_ok=True)
        _VC_ACCESS_HASH_FILE.write_text(
            _json_module.dumps({str(k): v for k, v in hashes.items()},
                               indent=2, default=str)
        )
    except Exception as exc:
        logger.warning("VC_ACCESS_HASH_SAVE_FAILED exc=%s", exc)


# Load persisted access hashes at module load.
try:
    for k, v in _load_access_hash_persistence().items():
        _vc_entity_cache[k] = v
except Exception:
    pass


def _persist_access_hash(chat_id: int, entity: Any, source: str,
                         scope: str = "") -> None:
    """V76 PART 5 step 9: Persist a resolved access_hash to disk.

    v97 CRITICAL FIX (ROOT CAUSE of Auto Discovery freeze):
    Previously, this function did a FULL read-modify-write of the JSON
    persistence file on EVERY call. With 1000+ entity resolutions per
    discovery cycle and a growing file (up to 5000 entries ≈ 1MB), each
    call took 50-200ms of SYNCHRONOUS I/O on the event loop thread.
    1000 calls × 100ms = 100 seconds of event loop blocking per cycle.
    This caused EVENT_LOOP_LAG of 2+ seconds and permanent unresponsiveness.

    Fix: only update the in-memory cache here. The persistence file is
    saved periodically by _flush_access_hash_persistence() (called from
    the reconcile loop every 60s) via asyncio.to_thread.

    v98.10 §7/§12: optional ``scope`` — the ACCOUNT that resolved the
    entity ("global" / "acc_<id>" / "client:<id>").  Persisted with the
    entry so the next process restart seeds the account-scoped access
    state and successful resolutions STOP future retries.  Empty scope
    = legacy (unattributed) — the v98.07 scope gate treats it as
    scope-unknown (unchanged behavior for pre-v98.10 files).
    """
    access_hash = getattr(entity, "access_hash", None)
    if not access_hash or not chat_id:
        return
    try:
        _vc_entity_cache[chat_id] = {
            "entity": entity, "access_hash": access_hash, "source": source,
            # v98.10: account attribution (§7) — additive field.
            **({"scope": scope} if scope else {}),
        }
        # v97: mark the persistence file as dirty — it will be flushed
        # by the reconcile loop, NOT here. This eliminates the per-call
        # read-modify-write that blocked the event loop.
        global _access_hash_dirty
        _access_hash_dirty = True
        logger.debug("ENTITY_ACCESS_HASH_CACHED chat_id=%s source=%s%s",
                     chat_id, source,
                     f" scope={scope}" if scope else "")
    except Exception as exc:
        logger.debug("ENTITY_ACCESS_HASH_CACHE_FAILED chat_id=%s exc=%s", chat_id, exc)


# v97: dirty flag for batched persistence — set by _persist_access_hash,
# flushed by _flush_access_hash_persistence() from the reconcile loop.
_access_hash_dirty: bool = False
_user_entity_dirty: bool = False


async def _flush_access_hash_persistence() -> None:
    """v97: flush access hash cache to disk in a background thread.

    Called from the VC reconcile loop (every 60s). Uses asyncio.to_thread
    so the synchronous file I/O does NOT block the event loop.
    """
    global _access_hash_dirty
    if not _access_hash_dirty:
        return
    _access_hash_dirty = False
    try:
        # Build the serializable dict from the in-memory cache.
        hashes = {}
        for chat_id, entry in _vc_entity_cache.items():
            if isinstance(entry, dict) and "access_hash" in entry:
                _persist_entry_v9810 = {
                    "access_hash": str(entry["access_hash"]),
                    "source": entry.get("source", ""),
                    "entity_type": type(entry.get("entity")).__name__,
                    "saved_at": time.time(),
                }
                # v98.10 SS7/SS12: additive account attribution — old
                # readers ignore the new fields (SS31 compatible).
                _scope_v9810 = entry.get("scope")
                if _scope_v9810:
                    _persist_entry_v9810["scope"] = str(_scope_v9810)
                    try:
                        _persist_entry_v9810["kind"] = (
                            "channel" if int(chat_id) <= -1000000000000
                            else "chat")
                    except (TypeError, ValueError):
                        _persist_entry_v9810["kind"] = ""
                hashes[chat_id] = _persist_entry_v9810
        # Offload the actual file write to a thread.
        await asyncio.to_thread(_save_access_hash_persistence, hashes)
    except Exception as exc:  # noqa: BLE001
        logger.debug("VC_ACCESS_HASH_FLUSH_FAILED: %s", exc)


# ---------------------------------------------------------------------------
# v98.11 S24/S6: per-scope dialogs index + typed fast-recovery helpers.
#
# Production (5).log evidence: every resolve_entity_full call ran
# ``client.iter_dialogs(limit=300)`` (Step 4) - a real RPC costing ~4-5s
# per entity per account; the 64-entity first Join-All cycle burned
# ~128 dialogs scans (~9 of the ~9.3s per-entity rotation cost).  The
# index below scans ONCE per (scope, TTL) and serves every subsequent
# Step 4 from memory.  Bounded: LRU eviction, max 16 scopes, TTL clamped
# in config (60..3600s, default 300s).
# ---------------------------------------------------------------------------
_v9811_dialogs_index: dict[str, tuple[float, dict[int, Any]]] = {}
_V9811_DIALOGS_INDEX_MAX_SCOPES = 16


def _v9908_entity_cache_max_entries() -> int:
    """v99.08 sustainability item 8: VC_ENTITY_CACHE_MAX_ENTRIES (default
    5000, clamp 100..200000) — the SAME knob voicechat's mirrors use
    (one budget for the three entity mirrors).  Bounds
    ``_vc_entity_cache_by_client`` here (mtproto cannot import voicechat
    — circular)."""
    try:
        _raw = int(os.getenv("VC_ENTITY_CACHE_MAX_ENTRIES", "5000") or 5000)
    except Exception:  # noqa: BLE001
        _raw = 5000
    return max(100, min(200000, _raw))


def _v9908_bound_by_client_cache() -> None:
    """v99.08 sustainability item 8: size-bound _vc_entity_cache_by_client
    (oldest-insertion-first — entries carry no timestamp; dict order is
    chronological for fresh inserts).  Never raises."""
    try:
        _cache = _vc_entity_cache_by_client
        _max = _v9908_entity_cache_max_entries()
        if len(_cache) <= _max:
            return
        _drop_n = len(_cache) - _max
        for _k in list(_cache.keys())[:_drop_n]:
            _cache.pop(_k, None)
    except Exception:  # noqa: BLE001
        pass


def _v9811_dialogs_index_ttl() -> float:
    return _v9810_cfg("vc_entity_dialogs_index_ttl", 300.0)


def _v9811_dialogs_index_invalidate(scope: str = "") -> int:
    """Drop stale dialogs indexes (all, or one scope).  Bounded, never raises."""
    _n = 0
    try:
        if scope:
            if _v9811_dialogs_index.pop(str(scope), None) is not None:
                _n += 1
        else:
            _n = len(_v9811_dialogs_index)
            _v9811_dialogs_index.clear()
    except Exception:  # noqa: BLE001
        pass
    return _n


def _v9811_want_ids(chat_id: int, marked_chat_id: int,
                    identity: dict | None) -> set[int]:
    """v98.11: EVERY id form the dialogs step may legitimately match.

    The v98.10 Step-4 matcher only compared against ``chat_id`` and
    ``marked_chat_id`` - but ``marked_chat_id`` is only computed for
    POSITIVE chat_ids, so a MARKED-form ref (what resolve_vc_entity
    always passes) could never match a dialog entity (whose ``id`` is
    the RAW positive form).  The matcher now consults the canonical
    identity's raw/marked ids plus both derived forms.
    """
    _want: set[int] = set()
    try:
        if isinstance(chat_id, int) and chat_id:
            _want.add(chat_id)
            if chat_id <= -1000000000000:
                _want.add(-(chat_id + 1000000000000))
            elif chat_id < 0:
                _want.add(-chat_id)
            elif 0 < chat_id < 1000000000000:
                _want.add(-1000000000000 - chat_id)
        if isinstance(marked_chat_id, int) and marked_chat_id:
            _want.add(marked_chat_id)
            _want.add(abs(marked_chat_id) % 1000000000000)
        if isinstance(identity, dict):
            _raw = int(identity.get("raw_id") or 0)
            _marked = int(identity.get("marked_id") or 0)
            if _raw:
                _want.add(_raw)
            if _marked:
                _want.add(_marked)
    except Exception:  # noqa: BLE001
        pass
    _want.discard(0)
    return _want


async def _v9811_dialogs_lookup(client: Any, want_ids: set[int],
                                scope: str) -> Any | None:
    """ONE dialogs scan per (scope, TTL); serves every lookup from the
    in-memory index afterwards.  Returns the matched entity or None.
    Never raises (scan failures degrade to a per-call miss)."""
    if not want_ids:
        return None
    try:
        _now = time.monotonic()
        _entry = _v9811_dialogs_index.get(scope)
        if _entry is None or (_now - _entry[0]) > _v9811_dialogs_index_ttl():
            _idx: dict[int, Any] = {}
            async for dialog in client.iter_dialogs(limit=300):
                _ent = getattr(dialog, "entity", None)
                _eid = int(getattr(_ent, "id", 0) or 0)
                if _eid and _ent is not None:
                    _idx[_eid] = _ent
            _v9811_dialogs_index[scope] = (_now, _idx)
            if len(_v9811_dialogs_index) > _V9811_DIALOGS_INDEX_MAX_SCOPES:
                _drop = sorted(_v9811_dialogs_index.items(),
                               key=lambda kv: -kv[1][0])[_V9811_DIALOGS_INDEX_MAX_SCOPES:]
                for _k, _ in _drop:
                    _v9811_dialogs_index.pop(_k, None)
            _entry = _v9811_dialogs_index[scope]
        _idx2 = _entry[1] if _entry else {}
        for _wid in want_ids:
            _hit = _idx2.get(_wid)
            if _hit is not None:
                return _hit
        return None
    except Exception as _exc:  # noqa: BLE001
        # A failed scan (disconnect / FloodWait) must NOT poison the
        # index: drop the scope entry so the next call re-scans.
        try:
            _v9811_dialogs_index.pop(scope, None)
        except Exception:  # noqa: BLE001
            pass
        logger.debug("ENTITY_DIALOGS_INDEX_SCAN_FAILED scope=%s exc=%s",
                     scope, _exc)
        return None


async def resolve_entity_full(client: Any, chat_ref: str | int,
                               identity: dict | None = None,
                               rpc_counter: dict | None = None) -> Any:
    """V76 PART 5: Complete 9-step entity resolution pipeline.

    Resolution order:
      1. Persistent cache → ENTITY_CACHE_HIT
      2. Forwarded-user cache → (checked via _user_entity_cache)
      3. Message link resolver → (handled by caller)
      4. Dialogs → ENTITY_DIALOG_HIT
      5. Contacts → ENTITY_CONTACT_HIT
      6. Common groups → ENTITY_GROUP_HIT
      7. Username lookup → ENTITY_USERNAME_HIT
      8. get_entity() → ENTITY_FETCH_SUCCESS / ENTITY_FETCH_FAILED
      9. get_input_entity() → last resort

    Persists successful access hashes (step 9b: _persist_access_hash).
    Never silently fails — raises VCTransportError with exact reason.

    v98.10: optional ``identity`` (canonical §6 identity, computed when
    absent) + ``rpc_counter`` (§22 per-resolution RPC accounting).  The
    step-6 probe is now TYPE-CORRECT: a raw positive int is never passed
    to ``GetFullChannelRequest`` — Telethon resolves those as PeerUser
    (an ``users.GetUsersRequest`` RPC that returns UserEmpty plus the
    misleading "Could not find the input entity for PeerUser" text; the
    production log showed 46 of these per run).  The typed form
    (``InputPeerChannel`` with a known-good hash, else ``PeerChannel``)
    keeps the SAME session-row hit rate (Telethon matches by the typed
    key) with none of the user/channel ambiguity (§5/§6).
    """
    from telethon.tl.functions.channels import GetFullChannelRequest
    from telethon.tl.functions.messages import GetFullChatRequest
    from telethon.errors import (
        ChannelInvalidError, ChannelPrivateError, ChatIdInvalidError,
        UsernameInvalidError, PeerIdInvalidError,
    )

    chat_id = 0
    if isinstance(chat_ref, int):
        chat_id = chat_ref
    elif isinstance(chat_ref, str) and chat_ref.lstrip("-").isdigit():
        chat_id = int(chat_ref)

    logger.info("ENTITY_RESOLVE_START chat_ref=%s chat_id=%s", chat_ref, chat_id)

    # v98.10 §6: canonical identity (typed, mark-derived).  Computed once;
    # callers that already have one (resolve_vc_entity) pass it through so
    # the candidate's identity travels WITH the resolution (§13 — do not
    # throw away information that was just obtained).
    if not isinstance(identity, dict):
        identity = _vc_entity_identity(chat_ref, chat_id=chat_id)
    _v9810_rpc_counter = rpc_counter if isinstance(rpc_counter, dict) \
        else {"rpcs": 0, "failed_rpcs": 0}
    _v9810_scope = _vc_client_scope(client)

    async def _rpc(fn: Callable, *args, **kwargs) -> Any:
        # v98.10 §22: count each RPC (semantics unchanged).
        _v9810_rpc_counter["rpcs"] = int(_v9810_rpc_counter.get("rpcs", 0)) + 1
        _v9810_stats_bump("rpcs")
        try:
            return await mtproto_call_with_retry(fn, *args, **kwargs)
        except Exception:
            _v9810_rpc_counter["failed_rpcs"] = \
                int(_v9810_rpc_counter.get("failed_rpcs", 0)) + 1
            _v9810_stats_bump("failed_rpcs")
            raise

    _v9810_last_exc: BaseException | None = None

    def _v9810_note_exc(exc: BaseException) -> None:
        """v98.10 §9: track the most informative step failure.  A cast
        TypeError (REPRESENTATION_ERROR) is deterministic — it outranks
        later generic cache-miss ValueErrors from subsequent steps, so
        the terminal class reflects the ROOT cause, not the last noise."""
        nonlocal _v9810_last_exc
        try:
            if _v9810_last_exc is not None and \
                    _vc_resolution_outcome(_v9810_last_exc, identity) == \
                    _VC_RES_REPRESENTATION_ERROR:
                return
        except Exception:  # noqa: BLE001
            pass
        _v9810_last_exc = exc

    # V83 FIX: For VC targets, chat_id may be a CANONICAL positive ID (stripped
    # of -100 prefix by _vc_canonical_group_id). We need to try BOTH the
    # canonical positive ID AND the marked negative ID (-100<id>).
    # Also try as InputPeerChannel if we have a cached access_hash.
    marked_chat_id = 0
    if chat_id and chat_id > 0 and chat_id < 1000000000000:
        # This looks like a raw channel/supergroup ID → construct the marked form.
        marked_chat_id = -1000000000000 - chat_id

    # V85.4 FIX (Req 9 — multi-account cache isolation): access hashes are
    # Telegram-session-specific.  Account A's access_hash for a channel is
    # DIFFERENT from account B's.  The global _vc_entity_cache (keyed only by
    # chat_id) allowed cross-account contamination: account B would read
    # account A's cached access_hash, construct an InputPeerChannel with the
    # WRONG hash, and get PeerIdInvalidError.  We now check a per-client
    # scoped cache FIRST so each account only reads its own access hashes.
    # The global cache remains as a fallback for legacy single-account
    # deployments.
    # v99 RC-C FIX: the key is the STABLE scope token ("global" / "acc_<id>"),
    # NOT id(client) — mtproto_get_client() mints a NEW _GatedClientProxy
    # per call (unstable ids), and CPython id-reuse after proxy GC could
    # serve a DIFFERENT account's scoped entry.  Scope tokens are stable
    # per account for the process lifetime.
    _client_key = _vc_client_scope(client) if client is not None else "(none)"
    for cid in [chat_id, marked_chat_id]:
        if cid:
            scoped = _vc_entity_cache_by_client.get((_client_key, cid))
            if scoped and scoped.get("entity") is not None:
                logger.info("ENTITY_CACHE_HIT_SCOPED chat_id=%s scope=%s", cid, _client_key)
                return scoped["entity"]

    # Step 1: Persistent cache — try both canonical + marked ID.
    # v99.08 Patch-7 (RUNTIME-PROVEN shape, bot-diagnostic (2).log
    # 2026-09-19): this read was UNGATED — a foreign-scope flat entry
    # (old primary's access_hash surviving a rotation) was returned to
    # ANY consumer, and GetFullChannelRequest then failed with
    # CHANNEL_INVALID ("Invalid channel object").  The v98.07 FIX-QQ
    # gate existed only in resolve_vc_entity; resolve_entity_full (the
    # 9-step ladder used by the non-VC resolvers) bypassed it.  FIX:
    # every flat read is now gated by _vc_cache_scope_ok — mismatch →
    # skip the hit + warn (the ladder resolves fresh for THIS client).
    for cid in [chat_id, marked_chat_id]:
        if cid and cid in _vc_entity_cache:
            cached = _vc_entity_cache[cid]
            if not _vc_cache_scope_ok(cached, client):
                logger.warning(
                    "VC_HASH_SCOPE_MISMATCH chat_id=%s entry_scope=%s "
                    "consumer_scope=%s — skipping cache hit "
                    "(v99.08 Patch-7: resolve_entity_full flat read "
                    "scope-gated)",
                    cid, cached.get("scope") if isinstance(cached, dict)
                    else None, _vc_client_scope(client),
                )
                continue
            cached_entity = cached.get("entity")
            if cached_entity is not None:
                logger.info("ENTITY_CACHE_HIT chat_id=%s", cid)
                # Also cache under the canonical ID for future lookups.
                if cid != chat_id:
                    _vc_entity_cache[chat_id] = cached
                # V85.4: also populate the scoped cache so the NEXT call from
                # the same client hits the scoped path.
                _vc_entity_cache_by_client[(_client_key, chat_id)] = cached
                _v9908_bound_by_client_cache()  # v99.08 item 8
                return cached_entity

    # Step 2: Forwarded-user cache (user_entity_cache).
    if chat_id and chat_id in _user_entity_cache:
        cached = _user_entity_cache[chat_id]
        access_hash_str = cached.get("access_hash", "")
        if access_hash_str:
            try:
                access_hash = int(access_hash_str)
                # Try to get the full entity via InputPeerUser.
                from telethon.tl.types import InputPeerUser
                try:
                    input_peer = InputPeerUser(user_id=chat_id, access_hash=access_hash)
                    entity = await mtproto_call_with_retry(client.get_entity, input_peer)
                    if entity is not None:
                        _vc_entity_cache[chat_id] = {
                            "entity": entity, "access_hash": access_hash,
                            "source": "forward_cache",
                        }
                        logger.info("ENTITY_CACHE_HIT chat_id=%s source=forward_cache",
                                    chat_id)
                        return entity
                except Exception:
                    pass
            except (ValueError, TypeError):
                pass

    # v98.11 S26: the scoped/flat caches did not contain this entity
    # for THIS client - the ladder (refresh path) is engaged.  A CACHE
    # MISS is explicitly NOT an access statement (S4).
    logger.info("ENTITY_RESOLVE_CACHE_MISS chat_id=%s scope=%s - caches "
                "missed, refresh ladder engaged (v98.11 S26)",
                chat_id, _v9810_scope)
    # Step 4: Dialogs (v98.11 S24: ONE scan per (scope, TTL) via the
    # dialogs index; the v98.10 code re-scanned 300 dialogs on EVERY
    # resolution - ~4-5s per entity per account, ~128 scans for the
    # production 64-entity first cycle).  The matcher now accepts EVERY
    # legitimate id form (the v98.10 matcher could never match a
    # MARKED-form ref because marked_chat_id was only computed for
    # positive chat_ids).
    try:
        _want_ids = _v9811_want_ids(chat_id, marked_chat_id, identity)
        ent = await _v9811_dialogs_lookup(client, _want_ids, _v9810_scope)
        if ent is not None:
            _vc_entity_cache[chat_id] = {
                "entity": ent,
                "access_hash": getattr(ent, "access_hash", None),
                "source": "dialog",
                "scope": _v9810_scope,  # v98.10: scope-annotate
            }
            if marked_chat_id:
                _vc_entity_cache[marked_chat_id] = _vc_entity_cache[chat_id]
            logger.info("ENTITY_DIALOG_HIT chat_id=%s access_hash=%s",
                        chat_id, _redact_ah(getattr(ent, "access_hash", None)))
            _persist_access_hash(chat_id, ent, "dialog",
                                 scope=_v9810_scope)
            _v9810_access_remember(_v9810_scope, identity, ent, "dialog")
            return ent
    except Exception as exc:
        _v9810_note_exc(exc)
        logger.debug("ENTITY_DIALOG_SEARCH_FAILED chat_id=%s exc=%s", chat_id, exc)

    # Step 5: Contacts.
    if chat_id and chat_id > 0:
        try:
            # v99.11 FIX(P1): get_contacts was REMOVED in Telethon 1.x —
            # use the supported ladder (iter_contacts → GetContactsRequest).
            contacts = await _telethon_fetch_contacts(client)
            for contact in contacts:
                if getattr(contact, "id", 0) == chat_id:
                    _vc_entity_cache[chat_id] = {
                        "entity": contact,
                        "access_hash": getattr(contact, "access_hash", None),
                        "source": "contact",
                        "scope": _v9810_scope,  # v98.10: scope-annotate
                    }
                    logger.info("ENTITY_CONTACT_HIT chat_id=%s access_hash=%s",
                                chat_id, _redact_ah(getattr(contact, "access_hash", None)))
                    _persist_access_hash(chat_id, contact, "contact",
                                         scope=_v9810_scope)
                    return contact
        except Exception as exc:
            logger.debug("ENTITY_CONTACT_SEARCH_FAILED chat_id=%s exc=%s", chat_id, exc)

    # Step 6: Common groups.
    #
    # v98.10 §5/§6 (THE 46× "Could not find the input entity for
    # PeerUser(user_id=…)" FIX): never pass a RAW POSITIVE INT to
    # GetFullChannelRequest — Telethon's get_input_entity maps positive
    # ints to PeerUser (an users.GetUsersRequest RPC returning UserEmpty
    # + the misleading PeerUser cache-miss text), and the session-row
    # scan for a bare int is exact=False across ALL THREE peer kinds —
    # a same-numeric-id USER could false-match a channel probe.  The
    # typed form below keeps the SAME hit rate (Telethon matches the
    # session rows by the typed key) with correct error typing:
    #   * channel kind + scope-valid hash → InputPeerChannel (1 RPC,
    #     no session dependency)
    #   * channel kind, no hash → PeerChannel (session-row lookup; on
    #     miss Telethon issues GetChannelsRequest(hash=0) and raises a
    #     type-correct PeerChannel error)
    #   * basic-group kind (legacy -<id> mark) → GetFullChatRequest
    #   * positive/unknown kind with NO hash → skip the channel probe
    #     entirely (the user path is steps 5/8; a hashless positive id
    #     is ambiguous and must NOT be guessed as a channel).
    if chat_id:
        _v9810_kind = str(identity.get("kind") or "")
        _v9810_probe: Any = None
        full_result: Any = None
        try:
            if _v9810_kind == "channel":
                # prefer a scope-VALID hash (§7): the flat entry's hash is
                # only used when its scope permits THIS client.
                _ah6 = 0
                _flat6 = _vc_entity_cache.get(chat_id, {})
                if isinstance(_flat6, dict) and _flat6.get("access_hash") \
                        and _vc_cache_scope_ok(_flat6, client):
                    try:
                        _ah6 = int(_flat6["access_hash"])
                    except (TypeError, ValueError):
                        _ah6 = 0
                _v9810_probe = _v9810_typed_input_peer(
                    identity, _ah6) or _v9810_typed_peer(identity)
                if _v9810_probe is not None:
                    full_result = await _rpc(
                        client, GetFullChannelRequest(channel=_v9810_probe))
            elif _v9810_kind == "chat":
                # Basic group: GetFullChatRequest is the CORRECT request
                # (a channel-specific RPC on a chat object is the §5
                # "Invalid channel object" signature).
                _raw6 = int(identity.get("raw_id") or 0) or abs(chat_id)
                full_result = await _rpc(
                    client, GetFullChatRequest(chat_id=_raw6))
                _v9810_probe = full_result
            if full_result is not None and hasattr(full_result, "chats"):
                for ch in full_result.chats:
                    _chid = getattr(ch, "id", 0)
                    if _chid == (identity.get("raw_id") or 0) or _chid == chat_id:
                        _vc_entity_cache[chat_id] = {
                            "entity": ch,
                            "access_hash": getattr(ch, "access_hash", None),
                            "source": "group_full",
                            # v98.10: scope-annotate (the v98.07 gate needs
                            # this to stop cross-scope replay).
                            "scope": _v9810_scope,
                        }
                        logger.info("ENTITY_GROUP_HIT chat_id=%s access_hash=%s "
                                    "source=GetFullChannelRequest",
                                    chat_id, _redact_ah(getattr(ch, "access_hash", None)))
                        _persist_access_hash(chat_id, ch, "group_full",
                                             scope=_v9810_scope)
                        _v9810_access_remember(_v9810_scope, identity, ch,
                                               "group_full")
                        return ch
        except (ChannelInvalidError, ChannelPrivateError, ChatIdInvalidError):
            pass
        except Exception as exc:
            _v9810_note_exc(exc)
            logger.debug("ENTITY_GROUP_SEARCH_FAILED chat_id=%s exc=%s", chat_id, exc)

        if chat_id > 0:
            try:
                full_result = await _rpc(client, GetFullChatRequest(chat_id=chat_id))
                if full_result and hasattr(full_result, "chats"):
                    for ch in full_result.chats:
                        if getattr(ch, "id", 0) == chat_id:
                            _vc_entity_cache[chat_id] = {
                                "entity": ch,
                                "access_hash": getattr(ch, "access_hash", None),
                                "source": "chat_full",
                                "scope": _v9810_scope,
                            }
                            logger.info("ENTITY_GROUP_HIT chat_id=%s source=GetFullChatRequest",
                                        chat_id)
                            _persist_access_hash(chat_id, ch, "chat_full",
                                                 scope=_v9810_scope)
                            return ch
            except Exception as exc:
                _v9810_note_exc(exc)
                logger.debug("ENTITY_CHAT_FULL_FAILED chat_id=%s exc=%s", chat_id, exc)

    # Step 7: Username lookup.
    if isinstance(chat_ref, str) and (chat_ref.startswith("@") or
                                       not chat_ref.lstrip("-").isdigit()):
        username = chat_ref.lstrip("@")
        try:
            entity = await _rpc(client.get_entity, f"@{username}")
            if entity is not None:
                ent_id = getattr(entity, "id", 0)
                _vc_entity_cache[ent_id or chat_id] = {
                    "entity": entity,
                    "access_hash": getattr(entity, "access_hash", None),
                    "source": "username",
                    "scope": _v9810_scope,  # v98.10: scope-annotate
                }
                logger.info("ENTITY_USERNAME_HIT chat_ref=%s chat_id=%s access_hash=%s",
                            chat_ref, ent_id, _redact_ah(getattr(entity, "access_hash", None)))
                _persist_access_hash(ent_id or chat_id, entity, "username",
                                     scope=_v9810_scope)
                return entity
        except (UsernameInvalidError, PeerIdInvalidError):
            pass
        except Exception as exc:
            _v9810_note_exc(exc)
            logger.debug("ENTITY_USERNAME_FAILED chat_ref=%s exc=%s", chat_ref, exc)

    # Step 8: Full get_entity fetch — try both canonical + marked ID.
    for try_ref in [chat_ref, marked_chat_id]:
        if not try_ref:
            continue
        try:
            entity = await _rpc(client.get_entity, try_ref)
            if entity is not None:
                ent_id = getattr(entity, "id", 0)
                _cache_entry = {
                    "entity": entity,
                    "access_hash": getattr(entity, "access_hash", None),
                    "source": "fetch",
                    "scope": _v9810_scope,  # v98.10: scope-annotate
                }
                _vc_entity_cache[ent_id or chat_id] = _cache_entry
                if marked_chat_id:
                    _vc_entity_cache[marked_chat_id] = _cache_entry
                # V85.4 (Req 9): mirror into the per-client scoped cache.
                _vc_entity_cache_by_client[(_client_key, ent_id or chat_id)] = _cache_entry
                if marked_chat_id:
                    _vc_entity_cache_by_client[(_client_key, marked_chat_id)] = _cache_entry
                _v9908_bound_by_client_cache()  # v99.08 item 8
                logger.info("ENTITY_FETCH_SUCCESS chat_ref=%s chat_id=%s access_hash=%s",
                            try_ref, ent_id, _redact_ah(getattr(entity, "access_hash", None)))
                _persist_access_hash(ent_id or chat_id, entity, "fetch",
                                     scope=_v9810_scope)
                _v9810_access_remember(_v9810_scope, identity, entity, "fetch")
                return entity
        except (ChannelInvalidError, ChannelPrivateError, ChatIdInvalidError,
                UsernameInvalidError, PeerIdInvalidError) as exc:
            _v9810_note_exc(exc)
            logger.debug("ENTITY_FETCH_FAILED try_ref=%s exc=%s: %s",
                         try_ref, type(exc).__name__, str(exc)[:80])
        except Exception as exc:
            _v9810_note_exc(exc)
            logger.debug("ENTITY_FETCH_FAILED try_ref=%s exc=%s: %s",
                         try_ref, type(exc).__name__, str(exc)[:80])

    # Step 9: get_input_entity (last resort) — try both canonical + marked ID.
    for try_ref in [chat_ref, marked_chat_id]:
        if not try_ref:
            continue
        try:
            input_entity = await _rpc(client.get_input_entity, try_ref)
            if input_entity is not None:
                ent_id = getattr(input_entity, "user_id", None) or \
                         getattr(input_entity, "channel_id", None) or \
                         getattr(input_entity, "chat_id", None) or 0
                access_hash = getattr(input_entity, "access_hash", None)
                if ent_id and access_hash:
                    _vc_entity_cache[ent_id] = {
                        "entity": input_entity,
                        "access_hash": access_hash,
                        "source": "input_entity",
                        "scope": _v9810_scope,  # v98.10: scope-annotate
                    }
                    if chat_id:
                        _vc_entity_cache[chat_id] = _vc_entity_cache[ent_id]
                    if marked_chat_id:
                        _vc_entity_cache[marked_chat_id] = _vc_entity_cache[ent_id]
                    logger.info("ENTITY_FETCH_SUCCESS try_ref=%s chat_id=%s "
                                "source=get_input_entity access_hash=%s",
                                try_ref, ent_id, _redact_ah(access_hash))
                    _persist_access_hash(ent_id, input_entity, "input_entity",
                                         scope=_v9810_scope)
                    try:
                        full_entity = await _rpc(client.get_entity, input_entity)
                        if full_entity is not None:
                            _vc_entity_cache[ent_id]["entity"] = full_entity
                            return full_entity
                    except Exception:
                        pass
                    return input_entity
        except Exception as exc:
            _v9810_note_exc(exc)
            logger.debug("ENTITY_INPUT_ENTITY_FAILED try_ref=%s exc=%s", try_ref, exc)

    # v98.10 §9: classify the terminal failure from the LAST observed
    # step exception so the CALLER can route on the actual failure class
    # (representation vs access vs temporary) — never collapsed into a
    # blind "try another resolver".  The class prefix rides the message
    # (existing text preserved for log-greps).
    _v9810_cls = _vc_resolution_outcome(_v9810_last_exc, identity)
    _v9810_stats_bump("failures")
    if _v9810_cls == _VC_RES_LOCAL_MISS:
        logger.info(
            "ENTITY_RESOLVE_LOCAL_MISS chat_id=%s class=%s - the 9-step "
            "refresh found no server denial; TELETHON LOCAL cache miss "
            "(v98.11 S4: cache miss is not access denial)",
            chat_id, _v9810_cls)
    logger.error("ENTITY_RESOLVE_FAILED chat_ref=%s chat_id=%s "
                 "reason=all_9_steps_failed class=%s rpcs=%d "
                 "failed_rpcs=%d (v98.10 §9)",
                 chat_ref, chat_id, _v9810_cls,
                 int(_v9810_rpc_counter.get("rpcs", 0)),
                 int(_v9810_rpc_counter.get("failed_rpcs", 0)))
    raise VCTransportError(
        f"[class={_v9810_cls}] Could not find input entity for chat "
        f"{chat_ref} (chat_id={chat_id}). All 9 resolution steps failed. "
        f"Telegram does not expose enough information to resolve this user. "
        f"Try: forward a message from the user, share a group with the "
        f"user, or use @username."
    )


# ===========================================================================
# V76 PART 6-9: Forwarded message resolution + common group resolution
# + user_entity_cache.json persistence
# ===========================================================================

_USER_ENTITY_CACHE_FILE = Path(config.project_root) / "data" / "user_entity_cache.json"


def _load_user_entity_cache() -> dict[int, dict[str, Any]]:
    """V76 PART 8: Load persisted user entity cache from disk."""
    try:
        if _USER_ENTITY_CACHE_FILE.exists():
            data = _json_module.loads(_USER_ENTITY_CACHE_FILE.read_text())
            if isinstance(data, dict):
                result: dict[int, dict[str, Any]] = {}
                for k, v in data.items():
                    try:
                        if not isinstance(v, dict) or "access_hash" not in v:
                            continue  # Remove corrupted entry.
                        result[int(k)] = v
                    except (ValueError, TypeError):
                        continue
                return result
    except Exception as exc:
        logger.warning("USER_ENTITY_CACHE_LOAD_FAILED exc=%s", exc)
    return {}


def _save_user_entity_cache(cache: dict[int, dict[str, Any]]) -> None:
    """V76 PART 8: Persist user entity cache to disk."""
    try:
        _USER_ENTITY_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _USER_ENTITY_CACHE_FILE.write_text(
            _json_module.dumps({str(k): v for k, v in cache.items()},
                               indent=2, default=str)
        )
    except Exception as exc:
        logger.warning("USER_ENTITY_CACHE_SAVE_FAILED exc=%s", exc)


_user_entity_cache: dict[int, dict[str, Any]] = _load_user_entity_cache()


def _persist_user_entity(user_id: int, access_hash: Any, username: str = "",
                          source: str = "unknown") -> None:
    """V76 PART 8: Persist a resolved user entity to cache + disk.

    v97 CRITICAL FIX (same root cause as _persist_access_hash):
    Previously called _save_user_entity_cache() on EVERY call — a synchronous
    read-modify-write of a growing JSON file on the event loop thread.
    Now only updates the in-memory cache; persistence is batched and flushed
    by _flush_user_entity_persistence() from the reconcile loop.
    """
    if not user_id or not access_hash:
        return
    now = time.time()
    existing = _user_entity_cache.get(user_id, {})
    _user_entity_cache[user_id] = {
        "user_id": user_id,
        "access_hash": str(access_hash),
        "username": username or existing.get("username", ""),
        "source": source,
        "first_seen": existing.get("first_seen", now),
        "last_seen": now,
    }
    # v97: mark dirty — flushed by reconcile loop, not here.
    global _user_entity_dirty
    _user_entity_dirty = True
    logger.debug("USER_ENTITY_CACHED user_id=%s source=%s", user_id, source)


async def _flush_user_entity_persistence() -> None:
    """v97: flush user entity cache to disk in a background thread."""
    global _user_entity_dirty
    if not _user_entity_dirty:
        return
    _user_entity_dirty = False
    try:
        await asyncio.to_thread(_save_user_entity_cache, dict(_user_entity_cache))
    except Exception as exc:  # noqa: BLE001
        logger.debug("USER_ENTITY_FLUSH_FAILED: %s", exc)


async def resolve_forwarded_sender(client: Any, message: Any) -> dict[str, Any]:
    """V79 FIX 1: Extract + persist the sender entity from a forwarded message.

    ROOT CAUSE of "Could not extract sender from forward":
    - Telethon's fwd_from.from_id is a PeerUser (not a User object) — it only has
      user_id + access_hash, NOT the full entity. The old code treated it as a User.
    - forward_origin structure varies by Telethon version — some versions use
      sender_id, others use MessagePeer, others use sender_user.
    - message.sender may contain the original sender if the message was forwarded
      from a user the client can see.

    V79 fix: Try ALL of these in order:
      1. message.sender (if it's a User, not the forwarding user)
      2. fwd_from.from_id (PeerUser) → extract user_id + access_hash
      3. fwd_from.forward_from (legacy Telethon < 1.20)
      4. message.forward_origin → sender_id/sender_user
      5. message.forward_sender_name (name only fallback)
      6. message.sender_id → client.get_entity(sender_id)
      7. If user_id found but no access_hash → find_user_in_common_groups()

    Returns: {ok, user_id, access_hash, username, source, error, diagnostics}
    """
    result: dict[str, Any] = {
        "ok": False, "user_id": 0, "access_hash": None,
        "username": "", "source": "forward", "error": "",
        "diagnostics": {"forward_type": "", "steps_tried": [], "sender_found": False},
    }
    diag = result["diagnostics"]
    try:
        # Determine the forward type for diagnostics.
        fwd_from = getattr(message, "forward", None) or getattr(message, "fwd_from", None)
        forward_origin = getattr(message, "forward_origin", None)
        if fwd_from is not None:
            diag["forward_type"] = "fwd_from"
        elif forward_origin is not None:
            diag["forward_type"] = "forward_origin"
        else:
            diag["forward_type"] = "none"
            result["error"] = "No forward info on message"
            logger.info("FORWARD_ENTITY_FAILED reason=no_forward_info")
            return result

        user_id = 0
        access_hash = None
        username = ""

        # Step 1: Try message.sender (if it's a User and not the forwarding user).
        diag["steps_tried"].append("message.sender")
        sender = getattr(message, "sender", None)
        if sender is not None:
            sender_id = getattr(sender, "id", 0)
            # Check if sender is the original sender (not the person who forwarded).
            # We can't always tell, but if fwd_from exists, message.sender is the
            # forwarding user. Try it anyway — if get_entity succeeds, we have the entity.
            if sender_id and not getattr(sender, "is_self", False):
                # Try to get the full entity.
                try:
                    full_sender = await client.get_entity(sender_id)
                    if full_sender is not None:
                        user_id = getattr(full_sender, "id", 0) or sender_id
                        access_hash = getattr(full_sender, "access_hash", None)
                        username = getattr(full_sender, "username", "") or ""
                        if user_id:
                            diag["sender_found"] = True
                            diag["steps_tried"].append("message.sender:hit")
                except Exception:
                    pass

        # Step 2: Try fwd_from.from_id (PeerUser — has user_id + access_hash).
        if not user_id and fwd_from is not None:
            diag["steps_tried"].append("fwd_from.from_id")
            from_id = getattr(fwd_from, "from_id", None)
            if from_id is not None:
                # PeerUser has user_id + access_hash.
                uid = getattr(from_id, "user_id", 0) or 0
                ah = getattr(from_id, "access_hash", None)
                if uid:
                    user_id = uid
                    access_hash = ah
                    diag["sender_found"] = True
                    diag["steps_tried"].append(f"fwd_from.from_id:hit(user_id={uid})")
                    # Try to get the full entity for username.
                    if access_hash:
                        try:
                            from telethon.tl.types import InputPeerUser
                            input_peer = InputPeerUser(user_id=uid, access_hash=access_hash)
                            full_sender = await client.get_entity(input_peer)
                            if full_sender is not None:
                                username = getattr(full_sender, "username", "") or ""
                        except Exception:
                            pass

        # Step 3: Try fwd_from.forward_from (legacy Telethon < 1.20).
        if not user_id and fwd_from is not None:
            diag["steps_tried"].append("fwd_from.forward_from")
            ff = getattr(fwd_from, "forward_from", None)
            if ff is not None:
                uid = getattr(ff, "id", 0) or 0
                ah = getattr(ff, "access_hash", None)
                un = getattr(ff, "username", "") or ""
                if uid:
                    user_id = uid
                    access_hash = ah
                    username = un
                    diag["sender_found"] = True
                    diag["steps_tried"].append(f"fwd_from.forward_from:hit(user_id={uid})")

        # Step 4: Try message.forward_origin (Telethon >= 1.30).
        if not user_id and forward_origin is not None:
            diag["steps_tried"].append("forward_origin")
            # Try various attribute names across Telethon versions.
            sender_id = getattr(forward_origin, "sender_id", None)
            sender_user = getattr(forward_origin, "sender_user", None)
            sender_peer = getattr(forward_origin, "from", None)

            if sender_user is not None:
                uid = getattr(sender_user, "id", 0) or 0
                ah = getattr(sender_user, "access_hash", None)
                un = getattr(sender_user, "username", "") or ""
                if uid:
                    user_id = uid
                    access_hash = ah
                    username = un
                    diag["sender_found"] = True
                    diag["steps_tried"].append(f"forward_origin.sender_user:hit(user_id={uid})")
            elif sender_id:
                # sender_id is just an int — try to resolve.
                try:
                    full_sender = await client.get_entity(sender_id)
                    if full_sender is not None:
                        user_id = getattr(full_sender, "id", 0) or sender_id
                        access_hash = getattr(full_sender, "access_hash", None)
                        username = getattr(full_sender, "username", "") or ""
                        if user_id:
                            diag["sender_found"] = True
                            diag["steps_tried"].append(f"forward_origin.sender_id:hit(user_id={user_id})")
                except Exception:
                    user_id = sender_id
                    diag["sender_found"] = True
                    diag["steps_tried"].append(f"forward_origin.sender_id:partial(user_id={sender_id})")

        # Step 5: Try message.sender_id as last resort.
        if not user_id:
            diag["steps_tried"].append("message.sender_id")
            sender_id = getattr(message, "sender_id", None)
            if sender_id and isinstance(sender_id, int):
                try:
                    full_sender = await client.get_entity(sender_id)
                    if full_sender is not None:
                        user_id = getattr(full_sender, "id", 0) or sender_id
                        access_hash = getattr(full_sender, "access_hash", None)
                        username = getattr(full_sender, "username", "") or ""
                        if user_id:
                            diag["sender_found"] = True
                            diag["steps_tried"].append(f"message.sender_id:hit(user_id={user_id})")
                except Exception:
                    pass

        # Step 6: Name-only fallback.
        if not user_id:
            diag["steps_tried"].append("forward_sender_name")
            sender_name = (
                getattr(fwd_from, "sender_name", None) if fwd_from else None
            ) or getattr(message, "forward_sender_name", None)
            if sender_name:
                result["error"] = f"Forward sender name only: '{sender_name}' (no user_id)"
                logger.info("FORWARD_ENTITY_FAILED reason=name_only name=%s", sender_name)
                return result

        if not user_id:
            result["error"] = "Could not extract sender from forward"
            logger.info("FORWARD_ENTITY_FAILED reason=no_sender_extracted steps=%s",
                        diag["steps_tried"])
            return result

        # Step 7: If no access_hash, try common groups.
        if not access_hash:
            diag["steps_tried"].append("common_groups")
            logger.info("FORWARD_ENTITY_NO_ACCESS_HASH user_id=%s — trying groups", user_id)
            found = await find_user_in_common_groups(client, user_id)
            if found:
                access_hash = found.get("access_hash")
                diag["steps_tried"].append("common_groups:hit")
                logger.info("FORWARD_ENTITY_ACCESS_HASH_FOUND user_id=%s via=group", user_id)
            else:
                diag["steps_tried"].append("common_groups:miss")

        result["user_id"] = user_id
        result["access_hash"] = access_hash
        result["username"] = username
        result["ok"] = True

        logger.info("FORWARD_ENTITY_FOUND user_id=%s access_hash=%s username=@%s "
                    "steps=%s",
                    user_id, _redact_ah(access_hash), username or "(none)", diag["steps_tried"])

        if access_hash:
            _persist_user_entity(user_id, access_hash, username, "forward")
            logger.info("FORWARD_ENTITY_CACHED user_id=%s", user_id)
            logger.info("FORWARD_ENTITY_PERSISTED user_id=%s source=forward", user_id)

    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        logger.warning("FORWARD_ENTITY_FAILED exc=%s: %s",
                       type(exc).__name__, str(exc)[:120])
    return result


async def find_user_in_common_groups(client: Any,
                                      user_id: int) -> dict[str, Any] | None:
    """V76 PART 7: Find a user in common groups to extract their access_hash.

    Returns: {group_name, group_id, user_id, access_hash} or None.
    """
    logger.info("COMMON_GROUP_SCAN_START user_id=%s", user_id)
    try:
        async for dialog in client.iter_dialogs(limit=200):
            entity = dialog.entity
            entity_type = type(entity).__name__
            if entity_type not in ("Chat", "Channel"):
                continue
            group_id = getattr(entity, "id", 0)
            group_name = getattr(entity, "title", "") or f"chat_{group_id}"
            try:
                participants = await client.get_participants(entity, limit=200)
                for p in participants:
                    if getattr(p, "id", 0) == user_id:
                        access_hash = getattr(p, "access_hash", None)
                        if access_hash:
                            result = {
                                "group_name": group_name, "group_id": group_id,
                                "user_id": user_id, "access_hash": access_hash,
                            }
                            logger.info("COMMON_GROUP_FOUND user_id=%s group=%s "
                                        "access_hash=%s", user_id, group_name, _redact_ah(access_hash))
                            _persist_user_entity(user_id, access_hash, "", "group")
                            logger.info("ENTITY_GROUP_HIT user_id=%s source=common_group",
                                        user_id)
                            logger.info("ENTITY_ACCESS_HASH_SAVED user_id=%s source=group",
                                        user_id)
                            logger.info("COMMON_GROUP_SCAN_COMPLETE user_id=%s found=true",
                                        user_id)
                            return result
            except Exception:
                continue
        logger.info("COMMON_GROUP_NOT_FOUND user_id=%s", user_id)
        logger.info("COMMON_GROUP_SCAN_COMPLETE user_id=%s found=false", user_id)
        return None
    except Exception as exc:
        logger.warning("COMMON_GROUP_SCAN_FAILED user_id=%s exc=%s: %s",
                       user_id, type(exc).__name__, str(exc)[:120])
        return None


# ===========================================================================
# V76 PART 1-3: VCCoverageManager + reconciliation worker + retry queue
# ===========================================================================


async def resolve_message_link_sender(link: str) -> dict[str, Any]:
    """V77 PART 1: Resolve a message link → extract the sender entity.

    Supported link formats:
      - https://t.me/c/<chat_id>/<msg_id>   (private channel)
      - https://t.me/<public_username>/<msg_id>  (public channel)
      - https://t.me/<username>             (profile link — no message)

    Flow:
      1. Parse the link
      2. Resolve the chat entity
      3. Fetch the message
      4. Extract the sender
      5. Extract access_hash
      6. Persist to user_entity_cache

    Returns: {ok, user_id, username, access_hash, source, error}
    """
    result: dict[str, Any] = {
        "ok": False, "user_id": 0, "username": None,
        "access_hash": None, "source": "message_link", "error": "",
    }
    import re as _re
    logger.info("MESSAGE_LINK_RESOLVE_START link=%s", link[:120])

    try:
        from telethon.tl.functions.messages import GetMessagesRequest
        from telethon.tl.functions.channels import GetMessagesRequest as GetChannelMessagesRequest
    except ImportError:
        result["error"] = "Telethon GetMessagesRequest not available"
        logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=import_error", link[:80])
        return result

    client = mtproto_get_client()
    if client is None:
        result["error"] = "MTProto client unavailable"
        logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=client_unavailable", link[:80])
        return result

    try:
        # Parse the link.
        # Private: https://t.me/c/1234567890/123
        m_private = _re.search(r"t\.me/c/(\d+)/(\d+)", link)
        # Public: https://t.me/username/123
        m_public = _re.search(r"t\.me/([^/]+)/(\d+)", link)
        # Profile link (no message): https://t.me/username
        m_profile = _re.search(r"t\.me/([^/]+)/?$", link)

        chat_ref = None
        msg_id = 0

        if m_private:
            chat_id_raw = int(m_private.group(1))
            msg_id = int(m_private.group(2))
            # Private channel — marked ID is -100<chat_id>.
            chat_ref = -1000000000000 - chat_id_raw
        elif m_public:
            username = m_public.group(1)
            msg_id = int(m_public.group(2))
            chat_ref = f"@{username}"
        elif m_profile:
            # Profile link — just resolve the username, no message.
            username = m_profile.group(1)
            try:
                entity = await resolve_entity_full(client, f"@{username}")
                user_id = getattr(entity, "id", 0)
                access_hash = getattr(entity, "access_hash", None)
                un = getattr(entity, "username", "") or ""
                if user_id and access_hash:
                    _persist_user_entity(user_id, access_hash, un, "message_link")
                    result.update({
                        "ok": True, "user_id": user_id,
                        "username": un or None,
                        "access_hash": access_hash,
                    })
                    logger.info("MESSAGE_LINK_RESOLVE_SUCCESS link=%s user_id=%s "
                                "source=profile_link", link[:80], user_id)
                    return result
            except Exception as exc:
                result["error"] = f"Profile resolve failed: {exc}"
                logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s exc=%s",
                               link[:80], str(exc)[:100])
                return result
        else:
            result["error"] = f"Unrecognized link format: {link[:80]}"
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=unrecognized", link[:80])
            return result

        # Resolve the chat entity.
        try:
            chat_entity = await resolve_entity_full(client, chat_ref)
        except VCTransportError as exc:
            result["error"] = str(exc)[:200]
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=chat_unresolved "
                           "exc=%s", link[:80], str(exc)[:100])
            return result

        # Fetch the message.
        try:
            messages = await client.get_messages(chat_entity, ids=msg_id)
        except Exception as exc:
            result["error"] = f"Message fetch failed: {type(exc).__name__}: {str(exc)[:100]}"
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=message_fetch_failed "
                           "exc=%s", link[:80], str(exc)[:100])
            return result

        # Telethon returns a single Message (or None) when ids=<int>.
        message = None
        if isinstance(messages, list):
            message = messages[0] if messages else None
        else:
            message = messages

        if message is None:
            result["error"] = f"Message {msg_id} not found in chat"
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=message_not_found",
                           link[:80])
            return result

        # Extract the sender.
        sender = getattr(message, "sender", None)
        sender_id = getattr(message, "sender_id", None)

        if sender is None and sender_id:
            try:
                sender = await client.get_entity(sender_id)
            except Exception:
                pass

        if sender is None:
            # Try forward info.
            fwd_result = await resolve_forwarded_sender(client, message)
            if fwd_result.get("ok"):
                result.update({
                    "ok": True,
                    "user_id": fwd_result["user_id"],
                    "username": fwd_result.get("username") or None,
                    "access_hash": fwd_result.get("access_hash"),
                })
                logger.info("MESSAGE_LINK_RESOLVE_SUCCESS link=%s user_id=%s "
                            "source=forward_fallback", link[:80], result["user_id"])
                return result
            result["error"] = "Could not extract sender from message"
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=no_sender", link[:80])
            return result

        user_id = getattr(sender, "id", 0) or 0
        access_hash = getattr(sender, "access_hash", None)
        username = getattr(sender, "username", "") or None

        if not user_id:
            result["error"] = "Sender has no user_id"
            logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s reason=no_user_id", link[:80])
            return result

        # Persist.
        if access_hash:
            _persist_user_entity(user_id, access_hash, username or "", "message_link")
        else:
            # Try common groups to find access_hash.
            found = await find_user_in_common_groups(client, user_id)
            if found:
                access_hash = found.get("access_hash")

        result.update({
            "ok": True, "user_id": user_id,
            "username": username, "access_hash": access_hash,
        })
        logger.info("MESSAGE_SENDER_EXTRACTED user_id=%s access_hash=%s username=@%s",
                    user_id, _redact_ah(access_hash), username or "(none)")
        logger.info("MESSAGE_ENTITY_CACHED user_id=%s source=message_link", user_id)
        logger.info("MESSAGE_LINK_RESOLVE_SUCCESS link=%s user_id=%s", link[:80], user_id)
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        logger.warning("MESSAGE_LINK_RESOLVE_FAILED link=%s exc=%s: %s",
                       link[:80], type(exc).__name__, str(exc)[:100])
    return result


# ===========================================================================
# V77 PART 2: Profile auto-open after resolution
# ===========================================================================


async def resolve_across_accounts(chat_ref: str | int,
                                  identity: dict | None = None,
                                  rpc_counter: dict | None = None,
                                  access_hash: int = 0,
                                  ) -> dict[str, Any]:
    """V82 ISSUE 2: Try resolution across ALL healthy cluster accounts.

    For each healthy account:
      1. Get the account's TelegramClient
      2. Try resolve_entity_full
      3. Stop on first success
      4. Cache the result

    Only fail when ALL accounts fail.

    Returns: {ok, entity, account_id, source, error, scope?}

    v98.10 §12/§40: the success is persisted ACCOUNT-SCOPED (the
    resolving account's scope + hash + entity + verified_at feed the
    scoped access state, so the NEXT request routes directly to that
    account via Step 0c instead of re-burning the ladder), and the
    flat cache is now keyed by BOTH the raw and the MARKED id with a
    scope annotation (the marked form is what resolve_vc_entity Step 1
    looks up — the v98.09 rotation wrote only the positive key, which
    the lookup never found: the 46× repeat-cascade root cause).
    Rotation remains ACCOUNT-ORDERED (first healthy account wins) and
    FloodWait-aware (ERR-E-002 preserved).
    """
    # ERR-E-002: needed for the dedicated FloodWaitError except clause below
    # so we can mark the cluster account as cooling down instead of just
    # logging.
    from telethon.errors import FloodWaitError

    result: dict[str, Any] = {
        "ok": False, "entity": None, "account_id": "", "source": "", "error": "",
    }
    try:
        cluster = get_userbot_cluster()
        healthy = cluster.get_healthy_accounts()
        if not healthy:
            result["error"] = "No healthy accounts available for resolution."
            return result

        for acc in healthy:
            aid = acc["account_id"]
            client = cluster.get_client(aid)
            if client is None:
                logger.info("ACCOUNT_RESOLUTION_ATTEMPT account=%s skipped=no_client", aid)
                continue
            logger.info("ACCOUNT_RESOLUTION_ATTEMPT account=%s chat_ref=%s",
                        aid, str(chat_ref)[:50])
            # ----------------------------------------------------------
            # v98.11 S6/S39 FAST RECOVERY: typed probe BEFORE the ladder.
            # Production (5).log: the rotation side burned the FULL
            # 9-step ladder (a ~5s dialogs scan + typed probe) per
            # account, when the winning account resolves with ONE typed
            # InputPeerChannel RPC when it holds (or is the owner of) a
            # usable hash.  Hash candidates, in safety order:
            #   1. THIS account's scoped known-good hash (verified)
            #   2. the flat-cache hash when THIS account may consume it
            #      (own/legacy scope - S7/S8, never a foreign replay)
            #   3. the caller-provided hash when THIS account has NOT
            #      recently rejected it (the requester's rejection says
            #      nothing about THIS account - S8 "unless explicitly
            #      proven valid": the probe itself is the proof, and a
            #      rejection is recorded scope-locally, bounded)
            # A rejected hash only poisons the REJECTING scope.
            # ----------------------------------------------------------
            try:
                _ident_rot0 = identity if isinstance(identity, dict) \
                    else _vc_entity_identity(chat_ref)
                _probe_scope = _vc_client_scope(client)
                _probe_hash = 0
                _probe_src = ""
                _own_rot = _v9810_access_get(_probe_scope,
                                             int(_ident_rot0.get("marked_id") or 0))
                if isinstance(_own_rot, dict) and int(_own_rot.get("access_hash") or 0):
                    _probe_hash = int(_own_rot["access_hash"])
                    _probe_src = "scoped_state"
                if not _probe_hash:
                    _flat_rot = _vc_entity_cache.get(
                        int(_ident_rot0.get("marked_id") or 0), {})
                    if isinstance(_flat_rot, dict) \
                            and _flat_rot.get("access_hash") \
                            and _vc_cache_scope_ok(_flat_rot, client):
                        try:
                            _probe_hash = int(_flat_rot["access_hash"])
                            _probe_src = "flat_scope_ok"
                        except (TypeError, ValueError):
                            _probe_hash = 0
                if not _probe_hash and access_hash \
                        and not _v9810_hash_invalid_check(
                            _probe_scope,
                            int(_ident_rot0.get("marked_id") or 0),
                            int(access_hash)):
                    _probe_hash = int(access_hash)
                    _probe_src = "provided"
                if _probe_hash:
                    _inp_rot = _v9810_typed_input_peer(_ident_rot0, _probe_hash)
                    if _inp_rot is not None:
                        try:
                            logger.info(
                                "ENTITY_RESOLVE_TYPE_KNOWN chat_id=%s kind=%s "
                                "scope=%s source=rotation_probe (v98.11 S6 - "
                                "typed fast recovery before the ladder)",
                                _ident_rot0.get("marked_id"),
                                _ident_rot0.get("kind"), _probe_scope,
                            )
                            _ent_rot = await asyncio.wait_for(
                                _v9810_rpc_wrap(
                                    rpc_counter if isinstance(rpc_counter, dict)
                                    else {}, client.get_entity, _inp_rot),
                                timeout=_v9810_probe_timeout(),
                            )
                        except asyncio.CancelledError:
                            raise
                        except Exception as _probe_exc:
                            _cls_p = _vc_resolution_outcome(
                                _probe_exc, _ident_rot0, had_hash=True)
                            # FLOOD_WAIT re-raises to the probe block's
                            # outer handler, which COOLS the account
                            # (v98.11 S19 / ERR-E-002).
                            if _cls_p == _VC_RES_FLOOD_WAIT:
                                raise _probe_exc
                            if _cls_p in (_VC_RES_HASH_INVALID,
                                          _VC_RES_NOT_ACCESSIBLE):
                                # scope-local rejection only (S10).
                                _v9810_hash_invalid_record(
                                    _probe_scope,
                                    int(_ident_rot0.get("marked_id") or 0),
                                    _probe_hash)
                            logger.debug(
                                "ENTITY_RESOLVE_ROTATION_PROBE_FAILED "
                                "account=%s class=%s exc=%s",
                                aid, _cls_p, str(_probe_exc)[:120])
                            _ent_rot = None
                        if _ent_rot is not None:
                            result["ok"] = True
                            result["entity"] = _ent_rot
                            result["account_id"] = aid
                            result["source"] = "account_rotation"
                            result["scope"] = aid
                            logger.info(
                                "ACCOUNT_RESOLUTION_SUCCESS account=%s "
                                "chat_ref=%s probe=%s",
                                aid, str(chat_ref)[:50], _probe_src)
                            logger.info(
                                "ENTITY_RESOLVE_HASH_REFRESH chat_id=%s "
                                "scope=%s via=rotation_probe source=%s "
                                "(v98.11 S6 - typed recovery, no ladder)",
                                _ident_rot0.get("marked_id"), _probe_scope,
                                _probe_src)
                            _marked_rot0 = int(_ident_rot0.get("marked_id") or 0)
                            _ent_id0 = int(getattr(_ent_rot, "id", 0) or 0)
                            _entry_rot0: dict[str, Any] = {
                                "entity": _ent_rot,
                                "access_hash": getattr(_ent_rot, "access_hash", None),
                                "source": f"account_rotation:{aid}",
                                "scope": _vc_client_scope(client),
                            }
                            if _ent_id0:
                                _vc_entity_cache[_ent_id0] = _entry_rot0
                            if _marked_rot0 and _marked_rot0 != _ent_id0:
                                _vc_entity_cache[_marked_rot0] = _entry_rot0
                            _persist_access_hash(
                                _marked_rot0 or _ent_id0, _ent_rot,
                                f"rotation_probe:{_probe_src}",
                                scope=_vc_client_scope(client))
                            _v9810_access_remember(
                                _vc_client_scope(client), _ident_rot0,
                                _ent_rot, f"account_rotation:{aid}")
                            return result
            except asyncio.CancelledError:
                raise
            except Exception as _rot_probe_exc:  # noqa: BLE001
                _cls_outer = ""
                try:
                    _cls_outer = _v9810_extract_outcome_class(
                        _rot_probe_exc) or _vc_resolution_outcome(
                        _rot_probe_exc, _ident_rot0, had_hash=True)
                except Exception:  # noqa: BLE001
                    _cls_outer = ""
                if _cls_outer == _VC_RES_FLOOD_WAIT:
                    # v98.11 S19 (ERR-E-002 preserved): a FloodWaited
                    # account COOLS for the requested window instead of
                    # being retried on the next chat_ref (the probe and
                    # ladder try-blocks are siblings, so the cooling is
                    # applied HERE - same semantics as the ladder's
                    # dedicated except FloodWaitError clause below).
                    _fw_wait0 = int(getattr(_rot_probe_exc, "seconds", 0) or 0)
                    if _fw_wait0 <= 0:
                        import re as _re_fw0
                        _m_fw0 = _re_fw0.search(
                            r"retry after (\d+)", str(_rot_probe_exc))
                        _fw_wait0 = int(_m_fw0.group(1)) if _m_fw0 else 30
                    cluster.update_status(
                        aid, STATUS_FLOODWAIT,
                        floodwait_until=time.time() + _fw_wait0 + 1,
                    )
                    logger.info(
                        "ACCOUNT_RESOLUTION_FLOODWAIT account=%s wait=%ds "
                        "(v98.11 S19 - typed-probe FloodWait cooled)",
                        aid, _fw_wait0)
                    continue
                logger.debug("ENTITY_RESOLVE_ROTATION_PROBE_ERROR account=%s "
                             "exc=%s", aid, _rot_probe_exc)
            try:
                entity = await resolve_entity_full(
                    client, chat_ref, identity=identity,
                    rpc_counter=rpc_counter)
                if entity is not None:
                    result["ok"] = True
                    result["entity"] = entity
                    result["account_id"] = aid
                    result["source"] = "account_rotation"
                    result["scope"] = aid
                    logger.info("ACCOUNT_RESOLUTION_SUCCESS account=%s chat_ref=%s",
                                aid, str(chat_ref)[:50])
                    # Cache for future lookups.
                    ent_id = getattr(entity, "id", 0)
                    # v98.10 §6: canonical identity for the cache keys.
                    _ident_rot = identity if isinstance(identity, dict) else \
                        _vc_entity_identity(chat_ref)
                    _marked_rot = int(_ident_rot.get("marked_id") or 0)
                    if ent_id or _marked_rot:
                        _entry_rot: dict[str, Any] = {
                            "entity": entity,
                            "access_hash": getattr(entity, "access_hash", None),
                            "source": f"account_rotation:{aid}",
                            # v98.10 §7: the resolving account OWNS this
                            # hash — the v98.07 scope gate finally sees it.
                            "scope": _vc_client_scope(client),
                        }
                        if ent_id:
                            _vc_entity_cache[ent_id] = _entry_rot
                        if _marked_rot and _marked_rot != ent_id:
                            # v98.10 §12: the MARKED key is what
                            # resolve_vc_entity Step 1 looks up (the v98.09
                            # code wrote only the positive key → lookup
                            # miss → the cascade REPEATED every cycle).
                            _vc_entity_cache[_marked_rot] = _entry_rot
                        # §12: persist the working account so Step 0c
                        # routes the NEXT request here in ONE RPC.
                        _v9810_access_remember(
                            _vc_client_scope(client), _ident_rot, entity,
                            f"account_rotation:{aid}")
                    return result
            except FloodWaitError as fw:
                # ERR-E-002: surface the FloodWait into the cluster status so
                # the account is skipped for the cooldown window rather than
                # being retried immediately on the next chat_ref.
                cluster.update_status(
                    aid, STATUS_FLOODWAIT,
                    floodwait_until=time.time() + fw.seconds + 1,
                )
                logger.info("ACCOUNT_RESOLUTION_FLOODWAIT account=%s wait=%ds",
                            aid, fw.seconds)
                continue
            except Exception as exc:
                # v98.11 S19 (ERR-E-002): the ladder wraps failures in
                # VCTransportError("[class=FLOOD_WAIT] ...") - unwrap the
                # class so a FloodWaited account still COOLS instead of
                # being retried on the next chat_ref.
                _cls_fw = _v9810_extract_outcome_class(exc) or \
                    _vc_resolution_outcome(exc, identity, had_hash=False)
                if _cls_fw == _VC_RES_FLOOD_WAIT:
                    _fw_wait = int(getattr(exc, "seconds", 0) or 0)
                    if _fw_wait <= 0:
                        import re as _re_fw
                        _m_fw = _re_fw.search(
                            r"retry after (\d+)", str(exc))
                        _fw_wait = int(_m_fw.group(1)) if _m_fw else 30
                    cluster.update_status(
                        aid, STATUS_FLOODWAIT,
                        floodwait_until=time.time() + _fw_wait + 1,
                    )
                    logger.info(
                        "ACCOUNT_RESOLUTION_FLOODWAIT account=%s wait=%ds "
                        "(v98.11 S19 - wrapped FloodWait cooled)",
                        aid, _fw_wait)
                    continue
                logger.info("ACCOUNT_RESOLUTION_FAILED account=%s exc=%s: %s",
                            aid, type(exc).__name__, str(exc)[:80])
                continue

        result["error"] = f"All {len(healthy)} healthy accounts failed to resolve."
    except Exception as exc:
        result["error"] = f"resolve_across_accounts error: {type(exc).__name__}: {str(exc)[:100]}"
    return result


# ===========================================================================
# V82 ISSUE 3+5: FloodWait failover + verification
# ===========================================================================


async def resolve_forwarded_sender_full(client: Any, message: Any) -> dict[str, Any]:
    """V82.1 ISSUE 1: Enhanced forwarded-message sender extraction.

    Delegates to the existing resolve_forwarded_sender() (V79, 7-step) but adds:
      - Hidden-forward fallback (forward_origin with no sender_id)
      - Protected-forward fallback (forward_sender_name only)
      - Auto common-group recovery when access_hash is missing
      - Full resolution diagnostics

    Returns: {ok, user_id, access_hash, username, source, error, diagnostics}
    """
    # Delegate to the existing V79 resolver.
    result = await resolve_forwarded_sender(client, message)
    if result.get("ok"):
        # Already resolved — add diagnostics.
        result["diagnostics"] = {
            "forward_type": "resolved",
            "steps_tried": ["delegated_to_v79"],
            "access_hash_found": result.get("access_hash") is not None,
        }
        return result

    # V82.1: If the V79 resolver failed, try additional fallbacks.
    logger.info("FORWARD_ROUTER_HIT — V79 resolver failed, trying V82.1 fallbacks")

    # Fallback 1: Try message.sender_id → get_entity via resolve_entity_full.
    sender_id = getattr(message, "sender_id", None)
    if sender_id and isinstance(sender_id, int):
        logger.info("FORWARD_ENTITY_FOUND user_id=%s source=sender_id_fallback", sender_id)
        try:
            entity = await resolve_entity_full(client, sender_id)
            if entity is not None:
                user_id = getattr(entity, "id", 0) or sender_id
                access_hash = getattr(entity, "access_hash", None)
                username = getattr(entity, "username", "") or ""
                if access_hash:
                    _persist_user_entity(user_id, access_hash, username, "forward")
                    logger.info("FORWARD_ENTITY_CACHED user_id=%s", user_id)
                result["ok"] = True
                result["user_id"] = user_id
                result["access_hash"] = access_hash
                result["username"] = username
                result["source"] = "forward_sender_id_fallback"
                result["diagnostics"] = {
                    "forward_type": "sender_id_fallback",
                    "steps_tried": ["v79_failed", "sender_id_fallback:hit"],
                    "access_hash_found": access_hash is not None,
                }
                return result
        except Exception as exc:
            logger.debug("FORWARD sender_id_fallback failed: %s", exc)

    # Fallback 2: Auto common-group recovery.
    if sender_id and isinstance(sender_id, int):
        logger.info("AUTO_GROUP_SCAN_START user_id=%s source=forward_fallback", sender_id)
        found = await find_user_in_common_groups(client, sender_id)
        if found:
            access_hash = found.get("access_hash")
            logger.info("AUTO_GROUP_MATCH user_id=%s group=%s",
                        sender_id, found.get("group_name", ""))
            _persist_user_entity(sender_id, access_hash, "", "forward")
            logger.info("FORWARD_ENTITY_CACHED user_id=%s", sender_id)
            result["ok"] = True
            result["user_id"] = sender_id
            result["access_hash"] = access_hash
            result["source"] = "forward_common_group_fallback"
            result["diagnostics"] = {
                "forward_type": "common_group_fallback",
                "steps_tried": ["v79_failed", "sender_id_fallback:miss",
                                "common_group:hit"],
                "access_hash_found": True,
            }
            return result
        else:
            logger.info("AUTO_GROUP_NO_MATCH user_id=%s", sender_id)

    logger.info("FORWARD_RESOLUTION_FAILED — all fallbacks exhausted")
    result["diagnostics"] = {
        "forward_type": "all_failed",
        "steps_tried": ["v79_failed", "sender_id_fallback:miss", "common_group:miss"],
        "access_hash_found": False,
    }
    return result


# ===========================================================================
# V82.1 ISSUE 2+3+4: resolve_user_id_full — 10-step user-ID resolution
# ===========================================================================

async def resolve_user_id_full(client: Any, user_id: int) -> dict[str, Any]:
    """V82.1 ISSUE 2: Resolve a numeric user ID using ALL available strategies.

    Resolution order (10 steps):
      1. Persistent cache (_vc_entity_cache)
      2. Forward cache (_user_entity_cache)
      3. Message-link cache (not applicable for user IDs — skipped)
      4. Dialog cache (iter_dialogs)
      5. Contacts (get_contacts)
      6. Common groups (find_user_in_common_groups)
      7. Stored entities (vc_access_hashes.json)
      8. Username mapping (not applicable for user IDs — skipped)
      9. get_entity()
     10. get_input_entity()

    Plus ISSUE 3: Access-hash recovery — tries common groups before failing.
    Plus ISSUE 4: Auto common-group search.

    Only fails after ALL stages.

    Returns: {ok, entity, access_hash, source, error}
    """
    result: dict[str, Any] = {
        "ok": False, "entity": None, "access_hash": None, "source": "", "error": "",
    }
    logger.info("USER_ID_RESOLVE_START user_id=%s", user_id)

    # Step 1: Persistent cache.
    if user_id in _vc_entity_cache:
        cached = _vc_entity_cache[user_id]
        cached_entity = cached.get("entity")
        if cached_entity is not None:
            result["ok"] = True
            result["entity"] = cached_entity
            result["access_hash"] = cached.get("access_hash")
            result["source"] = "persistent_cache"
            logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=persistent_cache", user_id)
            return result

    # Step 2: Forward cache.
    if user_id in _user_entity_cache:
        cached = _user_entity_cache[user_id]
        access_hash_str = cached.get("access_hash", "")
        if access_hash_str:
            try:
                access_hash = int(access_hash_str)
                from telethon.tl.types import InputPeerUser
                try:
                    input_peer = InputPeerUser(user_id=user_id, access_hash=access_hash)
                    entity = await client.get_entity(input_peer)
                    if entity is not None:
                        _vc_entity_cache[user_id] = {
                            "entity": entity, "access_hash": access_hash,
                            "source": "forward_cache",
                        }
                        result["ok"] = True
                        result["entity"] = entity
                        result["access_hash"] = access_hash
                        result["source"] = "forward_cache"
                        logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=forward_cache",
                                    user_id)
                        return result
                except Exception:
                    pass
            except (ValueError, TypeError):
                pass

    # Step 4: Dialog cache.
    try:
        async for dialog in client.iter_dialogs(limit=300):
            ent = dialog.entity
            if getattr(ent, "id", 0) == user_id:
                _vc_entity_cache[user_id] = {
                    "entity": ent,
                    "access_hash": getattr(ent, "access_hash", None),
                    "source": "dialog",
                }
                result["ok"] = True
                result["entity"] = ent
                result["access_hash"] = getattr(ent, "access_hash", None)
                result["source"] = "dialog"
                logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=dialog", user_id)
                _persist_access_hash(user_id, ent, "dialog")
                return result
    except Exception:
        pass

    # Step 5: Contacts.
    try:
        # v99.11 FIX(P1): get_contacts was REMOVED in Telethon 1.x —
        # use the supported ladder (iter_contacts → GetContactsRequest).
        contacts = await _telethon_fetch_contacts(client)
        for contact in contacts:
            if getattr(contact, "id", 0) == user_id:
                _vc_entity_cache[user_id] = {
                    "entity": contact,
                    "access_hash": getattr(contact, "access_hash", None),
                    "source": "contact",
                }
                result["ok"] = True
                result["entity"] = contact
                result["access_hash"] = getattr(contact, "access_hash", None)
                result["source"] = "contact"
                logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=contact", user_id)
                _persist_access_hash(user_id, contact, "contact")
                return result
    except Exception:
        pass

    # Step 6+ISSUE 3+4: Access-hash recovery via common groups.
    logger.info("ACCESS_HASH_RECOVERY_START user_id=%s", user_id)
    logger.info("AUTO_GROUP_SCAN_START user_id=%s source=user_id_resolution", user_id)
    found = await find_user_in_common_groups(client, user_id)
    if found:
        access_hash = found.get("access_hash")
        logger.info("AUTO_GROUP_MATCH user_id=%s group=%s", user_id,
                    found.get("group_name", ""))
        logger.info("ACCESS_HASH_RECOVERY_SUCCESS user_id=%s access_hash=%s",
                    user_id, _redact_ah(access_hash))
        # Now try get_entity with the recovered access_hash.
        try:
            from telethon.tl.types import InputPeerUser
            input_peer = InputPeerUser(user_id=user_id, access_hash=access_hash)
            entity = await client.get_entity(input_peer)
            if entity is not None:
                _vc_entity_cache[user_id] = {
                    "entity": entity, "access_hash": access_hash,
                    "source": "common_group",
                }
                result["ok"] = True
                result["entity"] = entity
                result["access_hash"] = access_hash
                result["source"] = "common_group"
                logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=common_group",
                            user_id)
                return result
        except Exception:
            pass
    else:
        logger.info("AUTO_GROUP_NO_MATCH user_id=%s", user_id)
        logger.info("ACCESS_HASH_RECOVERY_FAILED user_id=%s reason=no_common_groups",
                    user_id)

    # Step 9: get_entity().
    try:
        entity = await client.get_entity(user_id)
        if entity is not None:
            _vc_entity_cache[user_id] = {
                "entity": entity,
                "access_hash": getattr(entity, "access_hash", None),
                "source": "get_entity",
            }
            result["ok"] = True
            result["entity"] = entity
            result["access_hash"] = getattr(entity, "access_hash", None)
            result["source"] = "get_entity"
            logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=get_entity", user_id)
            _persist_access_hash(user_id, entity, "get_entity")
            return result
    except Exception:
        pass

    # Step 10: get_input_entity().
    try:
        input_entity = await client.get_input_entity(user_id)
        if input_entity is not None:
            access_hash = getattr(input_entity, "access_hash", None)
            if access_hash:
                _vc_entity_cache[user_id] = {
                    "entity": input_entity, "access_hash": access_hash,
                    "source": "get_input_entity",
                }
                result["ok"] = True
                result["entity"] = input_entity
                result["access_hash"] = access_hash
                result["source"] = "get_input_entity"
                logger.info("USER_ID_RESOLVE_SUCCESS user_id=%s source=get_input_entity",
                            user_id)
                _persist_access_hash(user_id, input_entity, "get_input_entity")
                return result
    except Exception:
        pass

    logger.error("USER_ID_RESOLVE_FAILED user_id=%s reason=all_10_steps_failed", user_id)
    result["error"] = (
        f"User ID {user_id} could not be resolved after all 10 steps. "
        f"Telegram does not expose enough information. Try: forward a message "
        f"from the user, send a message link, or use @username."
    )
    return result


# ===========================================================================
# v98.10 — ENTITY-RESOLUTION HARDENING (§§5-13, §15, §21-22, §41-43)
#
# Forensic evidence (bot-diagnostic (3).log, 2026-09-03 04:52→04:59,
# v98.09-P3 runtime, voicechat sha256 87ea047c…):
#   * 46× ``VC_ENTITY_RESOLVE input_peer_with_provided_hash failed:
#     Invalid channel object (caused by GetChannelsRequest)`` — the
#     vc_groups access_hash resolved by account B in a PREVIOUS run was
#     persisted in the GLOBAL flat cache / DB with NO account
#     attribution and replayed against account A's client. Telegram
#     access hashes are ACCOUNT-SCOPED for non-member channels (the
#     v98.07 FIX-QQ model, one layer up).
#   * 46× full 9-step ladder on A → ``all_9_steps_failed`` + 138×
#     ``Could not find the input entity`` — including step 6's
#     REPRESENTATION error: ``GetFullChannelRequest(channel=<raw
#     positive int>)`` makes Telethon resolve the int as PeerUser
#     (``users.GetUsersRequest`` RPC returning UserEmpty + the
#     misleading "PeerUser(user_id=…)" cache-miss text). A bare
#     positive int can ALSO false-match a same-numeric-id USER in the
#     session rows (exact=False scans all three peer kinds).
#   * 46× account rotation → account B's ladder → GetFullChannelRequest
#     success → result cached under the POSITIVE ent_id (the lookup key
#     is the MARKED id) with NO scope → the NEXT cycle repeats the
#     entire cascade. Successful resolution never stopped the retries.
#
# The hardening (ALL additive — the legacy ladder remains the fallback;
# every preserved v98.07/98.08 semantics — scope-gated flat cache,
# negative backoff, rotation, FloodWait, breaker — is unchanged):
#   * _vc_entity_identity       — canonical typed identity (§6): the
#     marked form determines channel/basic-group/user; ``abs(id)`` is
#     never treated as type proof.
#   * _vc_resolution_outcome()  — explicit outcome classes (§9).
#   * _v9810_access_state_*     — account-scoped access state (§7):
#     (scope, marked_id) → {entity, access_hash, kind, verified_at…},
#     TTL + bounded size + persistence into the EXISTING
#     vc_access_hashes.json (additive "scope"/"kind" fields, §31).
#   * _v9810_hash_invalid_*     — scoped stale-hash hints (§10/§11):
#     "this hash was REJECTED for this scope" with a short TTL, so a
#     foreign hash is not replayed from the same scope while fresh.
#   * single-flight             — concurrent resolutions of the same
#     (scope, entity) share ONE flight; the result fans out (§41/§43).
#   * resolve_vc_entity Step 0  — known-good account routing (§15):
#     own-scope hit → zero RPCs; other-scope hit → ONE typed get_entity
#     on THAT account's client, returning source=account_rotation:<aid>
#     so the EXISTING v98.07 detection routing applies.
#   * typed probes              — step 6 uses PeerChannel/InputPeerChannel
#     (never a raw positive int) (§5/§6).
#   * RPC accounting            — ENTITY_RESOLVE_* forensic markers +
#     per-call counts (§21/§22).
# ===========================================================================

# §9 outcome classes (explicit; never collapsed into "try another
# resolver" without knowing WHY the previous one failed).
_VC_RES_RESOLVED = "RESOLVED"
_VC_RES_RESOLVED_FROM_CACHE = "RESOLVED_FROM_CACHE"
_VC_RES_RESOLVED_FROM_SCOPE_STATE = "RESOLVED_FROM_SCOPE_STATE"
_VC_RES_RESOLVED_FROM_ACCESS_HASH = "RESOLVED_FROM_ACCESS_HASH"
_VC_RES_RESOLVED_VIA_ROTATION = "RESOLVED_VIA_ROTATION"
_VC_RES_NEEDS_REFRESH = "NEEDS_REFRESH"
_VC_RES_NOT_ACCESSIBLE = "NOT_ACCESSIBLE"
_VC_RES_PRIVATE = "PRIVATE"
_VC_RES_INVALID_ENTITY_TYPE = "INVALID_ENTITY_TYPE"
_VC_RES_NOT_FOUND = "NOT_FOUND"
_VC_RES_TEMPORARY_RPC_FAILURE = "TEMPORARY_RPC_FAILURE"
_VC_RES_FLOOD_WAIT = "FLOOD_WAIT"
_VC_RES_HASH_INVALID = "HASH_INVALID"
_VC_RES_REPRESENTATION_ERROR = "REPRESENTATION_ERROR"
# v98.11 S4: Telethon LOCAL session-cache miss ("Could not find the
# input entity for PeerChannel/PeerUser/...") - a LOCAL lookup failure
# that says NOTHING about server-side accessibility.  Distinct from
# NOT_ACCESSIBLE (server-confirmed denial) so the rotation gate can
# treat "local miss" and "access denied" differently (S4/S5).
_VC_RES_LOCAL_MISS = "LOCAL_MISS"


def _vc_entity_identity(chat_ref: Any, chat_id: int = 0,
                        access_hash: int = 0) -> dict[str, Any]:
    """v98.10 §6: canonical internal entity identity.

    The canonical representation preserves enough information to
    distinguish channel/supergroup vs basic group vs user WITHOUT
    relying on ``abs(chat_id)`` as type proof:

      kind == "channel"  — marked -100<id> form (or a Telethon Channel
                           entity, or a positive id WITH a known channel
                           access hash — VC discovery stores raw ids)
      kind == "chat"     — legacy basic-group -<id> (no -100 mark)
      kind == "user"     — Telethon User entity or an explicit
                           PeerUser-typed probe by the CALLER
      kind == "unknown"  — a bare positive int (could be a user id OR a
                           raw channel id) — callers must NOT guess; the
                           resolver probes the typed forms in order and
                           classifies failures instead of assuming.

    Never raises; on garbage input returns kind="unknown" with raw ids.
    """
    ident: dict[str, Any] = {
        "raw_id": 0, "marked_id": 0, "kind": "unknown",
        "ref": chat_ref, "access_hash": int(access_hash or 0),
    }
    try:
        # Telethon entity object → type from the class itself.
        _cls = type(chat_ref).__name__ if chat_ref is not None else ""
        if _cls == "Channel":
            _eid = int(getattr(chat_ref, "id", 0) or 0)
            ident.update(raw_id=_eid, marked_id=-1000000000000 - _eid,
                         kind="channel")
            _ah = getattr(chat_ref, "access_hash", None)
            if _ah and not ident["access_hash"]:
                ident["access_hash"] = int(_ah)
            return ident
        if _cls == "Chat":
            _eid = int(getattr(chat_ref, "id", 0) or 0)
            ident.update(raw_id=_eid, marked_id=-_eid, kind="chat")
            return ident
        if _cls == "User":
            _eid = int(getattr(chat_ref, "id", 0) or 0)
            ident.update(raw_id=_eid, marked_id=0, kind="user")
            return ident

        _cid = 0
        if isinstance(chat_id, int) and chat_id:
            _cid = int(chat_id)
        elif isinstance(chat_ref, int):
            _cid = int(chat_ref)
        elif isinstance(chat_ref, str) and chat_ref.lstrip("-").isdigit():
            _cid = int(chat_ref)
        if not _cid:
            return ident
        if _cid <= -1000000000000:
            # marked channel/supergroup form -100<id>
            _raw = -(_cid + 1000000000000)
            ident.update(raw_id=_raw, marked_id=_cid, kind="channel")
        elif _cid < 0:
            # legacy basic-group form -<id>
            ident.update(raw_id=-_cid, marked_id=_cid, kind="chat")
        elif _cid > 0 and access_hash:
            # VC discovery stores raw positive channel ids with an
            # access hash — the hash is channel-shaped positive-type
            # evidence (a bare positive id without a hash stays
            # "unknown": it may equally be a user id).
            ident.update(raw_id=_cid, marked_id=-1000000000000 - _cid,
                         kind="channel")
        else:
            ident.update(raw_id=_cid, marked_id=-1000000000000 - _cid,
                         kind="unknown")
        return ident
    except Exception:  # noqa: BLE001
        return ident


def _vc_resolution_outcome(exc: BaseException | None, ident: dict | None,
                           had_hash: bool = False) -> str:
    """v98.10 §9: classify a resolution failure into an explicit outcome
    class. The next action (retry / refresh hash / rotate account /
    stop) depends on this class — see resolve_vc_entity Step 4.

    Defensive: Telethon exception class names vary across versions, so
    the class name AND the message text are both matched (the same
    approach as voicechat._vc_is_channel_invalid_exc).
    """
    if exc is None:
        return _VC_RES_RESOLVED
    _name = type(exc).__name__
    _msg = str(exc)
    _low = _msg.lower()
    try:
        if _name == "FloodWaitError" or "retry after" in _low and "too many requests" in _low:
            return _VC_RES_FLOOD_WAIT
        if _name in ("ChannelPrivateError", "UserBannedInChannelError",
                     "ChatAdminRequiredError") or "private" in _low and "member" in _low:
            return _VC_RES_PRIVATE
        if _name in ("ChatIdInvalidError", "UsernameInvalidError",
                     "UserIdInvalidError") or "does not exist" in _low:
            return _VC_RES_NOT_FOUND
        if _name in ("ChannelInvalidError",) or "invalid channel object" in _low:
            # "Invalid channel object" = the server rejected the
            # (channel, hash) pair. With a NON-ZERO provided hash this is
            # HASH_INVALID (the hash is foreign/stale for THIS account —
            # the §5 signature); with hash=0 it is NOT_ACCESSIBLE (the
            # account cannot see the channel at all).
            return _VC_RES_HASH_INVALID if had_hash else _VC_RES_NOT_ACCESSIBLE
        if _name in ("TypeError", "ValueError") and (
                "cast" in _low or "not serializable" in _low
                or "cannot cast" in _low):
            return _VC_RES_REPRESENTATION_ERROR
        if _name in ("ConnectionError", "ConnectionResetError",
                     "ConnectionAbortedError", "TimeoutError",
                     "asyncio.TimeoutError") or "not connected" in _low \
                or "disconnected" in _low or "timed out" in _low:
            return _VC_RES_TEMPORARY_RPC_FAILURE
        if "could not find the input entity" in _low or "input entity" in _low:
            # v98.11 S4: Telethon raised this from the LOCAL session/entity
            # cache (get_input_entity - NO RPC).  It is a CACHE_MISS:
            # PeerUser-vs-PeerChannel is only a hint in the MESSAGE
            # text, never type proof (S6); a local miss proves nothing
            # about server-side accessibility
            return _VC_RES_LOCAL_MISS
        if "peeruser" in _low or "peerchannel" in _low or "peerchat" in _low:
            return _VC_RES_LOCAL_MISS
        # v98.11 S4/S7: this ValueError is raised by Telethon from its
        # LOCAL session/entity cache lookup (get_input_entity consults
        # the session database - NO RPC).  It is a CACHE_MISS, not an
        # access denial: the account may still fully access the
        # entity with a valid scoped hash (the typed InputPeer path
        # does not consult the local cache).  Classified LOCAL_MISS
        # so the rotation gate requires actual account-scoped
        # evidence before rotating (S5: PEER_NOT_FOUND_LOCALLY !=
        # NOT_ACCESSIBLE).
    except Exception:  # noqa: BLE001
        pass
    return _VC_RES_TEMPORARY_RPC_FAILURE


# (v98.10 state declarations moved to the entity-cache section,
# before the module-level persistence load — see below.)


def _v9810_cfg(name: str, default: float) -> float:
    """Best-effort config read with a hard clamp floor (§32)."""
    try:
        _v = float(getattr(config, name, default))
    except Exception:  # noqa: BLE001
        _v = default
    try:
        return _v if _v > 0 else default
    except Exception:  # noqa: BLE001
        return default


def _v9810_access_ttl() -> float:
    return _v9810_cfg("vc_entity_scope_state_ttl", 21600.0)


def _v9810_hash_invalid_ttl() -> float:
    return _v9810_cfg("vc_entity_hash_invalid_ttl", 300.0)


def _v9810_access_max_entries() -> int:
    return int(_v9810_cfg("vc_entity_scope_state_max_entries", 20000.0))

def _v9810_probe_timeout() -> float:
    """v98.11 S6/S29: typed fast-recovery probe timeout (clamped 2..30s)."""
    return _v9810_cfg("vc_entity_probe_timeout", 8.0)


def _v9810_extract_outcome_class(exc: BaseException | None) -> str:
    """v98.10 SS9: the 9-step ladder classifies its terminal failure and
    rides the class as a ``[class=X]`` prefix on the raised
    VCTransportError.  Re-classifying the WRAPPED message would lose it
    (the generic "Could not find input entity" text maps to
    NOT_ACCESSIBLE); extract the prefix first so the ROOT class (e.g. a
    deterministic REPRESENTATION_ERROR) survives the boundary."""
    try:
        _msg = str(exc or "")
        _i = _msg.find("[class=")
        if _i >= 0:
            _j = _msg.find("]", _i)
            if _j > _i:
                return _msg[_i + len("[class="):_j].strip()
    except Exception:  # noqa: BLE001
        pass
    return ""


def _v9810_access_remember(scope: str, ident: dict, entity: Any,
                           source: str) -> None:
    """§12: record a successful (scope, entity) resolution.  The next
    request for this entity from THIS scope (or routed from another
    consumer via §15 Step 0) reuses it instead of re-burning the
    ladder.  Bounded: oldest-entry eviction by verified_at."""
    try:
        _marked = int(ident.get("marked_id") or 0)
        _raw = int(ident.get("raw_id") or 0)
        if not _marked or not scope or scope == "(unknown)":
            return
        _ah = int(getattr(entity, "access_hash", None) or 0) \
            or int(ident.get("access_hash") or 0)
        _entry = {
            "entity": entity,
            "access_hash": _ah,
            "kind": str(ident.get("kind") or ""),
            "scope": str(scope),
            "verified_at": time.time(),
            "source": str(source)[:80],
        }
        _v9810_access_state[(str(scope), _marked)] = _entry
        # raw-id mirror (some callers address the raw form)
        if _raw:
            _v9810_access_state[(str(scope), _raw)] = _entry
        # bound the store (§32: no unlimited structures)
        _max = _v9810_access_max_entries()
        if len(_v9810_access_state) > _max:
            _drop = sorted(_v9810_access_state.items(),
                           key=lambda kv: kv[1].get("verified_at", 0.0))
            for _k, _ in _drop[:len(_v9810_access_state) - _max]:
                _v9810_access_state.pop(_k, None)
    except Exception as exc:  # noqa: BLE001
        logger.debug("ENTITY_ACCESS_STATE_REMEMBER_FAILED exc=%s", exc)


def _v9810_access_get(scope: str, chat_id: int) -> dict | None:
    """§7: the account-scoped entry for (scope, chat_id) — marked form
    first, raw form as mirror.  None when absent."""
    try:
        _ent = _v9810_access_state.get((str(scope), int(chat_id)))
        if _ent is None and int(chat_id) > 0:
            _ent = _v9810_access_state.get(
                (str(scope), -1000000000000 - int(chat_id)))
        return _ent
    except Exception:  # noqa: BLE001
        return None


def _v9810_access_other_scopes(chat_id: int, exclude_scope: str,
                               limit: int = 2) -> list[dict]:
    """§15: known-good entries for OTHER scopes (most recently verified
    first, bounded).  Used for targeted account routing — never a blind
    for-account-in-accounts retry (§40)."""
    try:
        _marked = int(chat_id) if int(chat_id) < 0 \
            else -1000000000000 - int(chat_id)
        _raw = -(_marked + 1000000000000)
        _cands: dict[str, dict] = {}
        for _key, _ent in _v9810_access_state.items():
            if _key[0] == exclude_scope or _key[1] not in (_marked, _raw):
                continue
            if not isinstance(_ent, dict) or not _ent.get("access_hash"):
                continue
            _prev = _cands.get(_key[0])
            if _prev is None or _ent.get("verified_at", 0.0) > \
                    _prev.get("verified_at", 0.0):
                _cands[_key[0]] = _ent
        _out = sorted(_cands.values(),
                      key=lambda e: -float(e.get("verified_at", 0.0)))
        return _out[:max(1, limit)]
    except Exception:  # noqa: BLE001
        return []


def _v9810_access_invalidate(scope: str, chat_id: int) -> int:
    """§10: invalidate ONLY the account-scoped entry (stale-hash
    refresh), never the whole entity's knowledge."""
    _n = 0
    try:
        _marked = int(chat_id) if int(chat_id) < 0 \
            else -1000000000000 - int(chat_id)
        _raw = -(_marked + 1000000000000)
        for _k in ((str(scope), _marked), (str(scope), _raw),
                   (str(scope), int(chat_id))):
            if _v9810_access_state.pop(_k, None) is not None:
                _n += 1
    except Exception:  # noqa: BLE001
        pass
    return _n


def _v9810_hash_invalid_check(scope: str, chat_id: int,
                              access_hash: int) -> bool:
    """§10/§11: True when THIS (scope, entity, hash) was recently
    REJECTED — the resolver skips replaying that hash from this scope
    (short TTL; the OWNING scope is unaffected)."""
    try:
        if not access_hash:
            return False
        _key = (str(scope), int(chat_id) if int(chat_id) < 0
                else -1000000000000 - int(chat_id))
        _ent = _v9810_hash_invalid.get(_key)
        if not _ent:
            return False
        if time.time() - float(_ent.get("ts", 0.0)) > _v9810_hash_invalid_ttl():
            _v9810_hash_invalid.pop(_key, None)
            return False
        return int(_ent.get("hash", 0) or 0) == int(access_hash)
    except Exception:  # noqa: BLE001
        return False


def _v9811_scope_hash_rejected(scope: str, chat_id: int) -> bool:
    """v98.11 S5: True when THIS scope recently REJECTED any hash for
    this entity (the S10 hint store, any hash, within the TTL).  This is
    the account-scoped EVIDENCE the rotation gate requires before
    rotating on a LOCAL_MISS outcome: a local session-cache miss alone
    proves nothing about accessibility, but a server-verified hash
    rejection for this scope + a failed refresh is an account-scoped
    resolution failure (S5 last bullet).  Never raises."""
    try:
        _key_base = int(chat_id) if int(chat_id) < 0 \
            else -1000000000000 - int(chat_id)
        _ent = _v9810_hash_invalid.get((str(scope), _key_base))
        if not _ent:
            return False
        return (time.time() - float(_ent.get("ts", 0.0))) <= \
            _v9810_hash_invalid_ttl()
    except Exception:  # noqa: BLE001
        return False


def _v9810_hash_invalid_record(scope: str, chat_id: int,
                               access_hash: int) -> None:
    """§10/§11: record a hash REJECTION for (scope, entity).  Bounded
    TTL — NEVER a permanent exclusion (transient server hiccups must
    not freeze an entity; §11)."""
    try:
        if not access_hash:
            return
        _key = (str(scope), int(chat_id) if int(chat_id) < 0
                else -1000000000000 - int(chat_id))
        _v9810_hash_invalid[_key] = {
            "hash": int(access_hash), "ts": time.time(),
        }
        # bound: same max as the access state
        _max = _v9810_access_max_entries()
        if len(_v9810_hash_invalid) > _max:
            _drop = sorted(_v9810_hash_invalid.items(),
                           key=lambda kv: kv[1].get("ts", 0.0))
            for _k, _ in _drop[:len(_v9810_hash_invalid) - _max]:
                _v9810_hash_invalid.pop(_k, None)
        logger.info(
            "ENTITY_RESOLVE_HASH_INVALID chat_id=%s scope=%s hash=%s "
            "ttl=%.0fs — hash rejected for THIS scope only (v98.10 §10; "
            "owner scope unaffected; NOT an exclusion)",
            chat_id, scope, _redact_ah(access_hash),
            _v9810_hash_invalid_ttl(),
        )
    except Exception as exc:  # noqa: BLE001
        logger.debug("ENTITY_HASH_INVALID_RECORD_FAILED exc=%s", exc)


def _v9810_stats_bump(name: str, by: int = 1) -> None:
    try:
        _v9810_resolution_stats[name] = \
            _v9810_resolution_stats.get(name, 0) + by
    except Exception:  # noqa: BLE001
        pass


def _v9810_rpc_wrap(counter: dict, fn: Callable, *args,
                    **kwargs) -> Any:
    """§21/§22: account for ONE mtproto RPC inside a resolution.  The
    REAL mtproto_call_with_retry semantics (FloodWait gate, global
    semaphore, bounded retries) are unchanged — this only counts."""
    async def _run() -> Any:
        counter["rpcs"] = int(counter.get("rpcs", 0)) + 1
        _v9810_stats_bump("rpcs")
        try:
            return await mtproto_call_with_retry(fn, *args, **kwargs)
        except Exception:
            counter["failed_rpcs"] = int(counter.get("failed_rpcs", 0)) + 1
            _v9810_stats_bump("failed_rpcs")
            raise
    return _run()


def _v9810_typed_input_peer(ident: dict, access_hash: int) -> Any | None:
    """§6: construct the CORRECT Telethon input type for the identity.
    channel → InputPeerChannel(raw, hash); chat → InputPeerChat(raw);
    user → InputPeerUser(raw, hash).  None when the kind is unknown or
    the required hash is missing (the caller falls back to the typed
    Peer probe).  Never a bare positive int (Telethon maps those to
    PeerUser).

    v98.10 (fix during driver bring-up): ONLY the EXPLICIT ``access_hash``
    argument is used — NEVER ``ident["access_hash"]`` (the caller-provided
    DB hash may be FOREIGN to this account; silently re-attaching it
    re-creates the 46× "Invalid channel object" replay one layer down).
    Scope validity is the CALLER's decision (Step 0b/0c pass scoped
    known-good hashes; the ladder passes only scope-checked flat hashes)."""
    try:
        from telethon.tl.types import (
            InputPeerChannel, InputPeerChat, InputPeerUser,
        )
        _kind = ident.get("kind")
        _raw = int(ident.get("raw_id") or 0)
        _ah = int(access_hash or 0)
        if not _raw:
            return None
        if _kind == "channel" and _ah:
            return InputPeerChannel(channel_id=_raw, access_hash=_ah)
        if _kind == "chat":
            return InputPeerChat(chat_id=_raw)
        if _kind == "user" and _ah:
            return InputPeerUser(user_id=_raw, access_hash=_ah)
        return None
    except ImportError:
        return None
    except Exception:  # noqa: BLE001
        return None


def _v9810_typed_peer(ident: dict) -> Any | None:
    """§6: the typed PEER object (no hash required) for session-cache
    lookups — Telethon matches the session rows by the typed key."""
    try:
        from telethon.tl.types import PeerChannel, PeerChat, PeerUser
        _kind = ident.get("kind")
        _raw = int(ident.get("raw_id") or 0)
        if not _raw:
            return None
        if _kind == "channel":
            return PeerChannel(channel_id=_raw)
        if _kind == "chat":
            return PeerChat(chat_id=_raw)
        if _kind == "user":
            return PeerUser(user_id=_raw)
        return None
    except ImportError:
        return None
    except Exception:  # noqa: BLE001
        return None


async def _v9810_scope_route(client: Any, ident: dict, scope: str,
                             counter: dict, result: dict) -> bool:
    """v98.10 §15 Step 0: account-scoped known-good routing.

    (a) own-scope entry with the entity object → return it (0 RPCs).
    (b) own-scope entry with a hash → ONE typed get_entity on THIS
        client; ChannelInvalid → invalidate ONLY that scope's entry
        (§10) and report NEEDS_REFRESH (caller continues the ladder).
    (c) other-scope known-good entry → ONE typed get_entity on THAT
        account's client; success returns source=
        "account_rotation:<aid>" so the EXISTING v98.07 detection
        routing applies (§12: successful resolution stops retries).
    Returns True when the caller may return *result* as resolved.
    """
    _marked = int(ident.get("marked_id") or 0)
    if not _marked or scope in ("", "(unknown)"):
        return False
    _own = _v9810_access_get(scope, _marked)
    if isinstance(_own, dict):
        _own_ent = _own.get("entity")
        _own_ah = int(_own.get("access_hash") or 0)
        _own_age = time.time() - float(_own.get("verified_at", 0.0))
        _own_fresh = _own_age <= _v9810_access_ttl()
        if _own_ent is not None and _own_fresh:
            _v9810_stats_bump("scope_state_hits")
            _v9810_stats_bump("cache_hits")
            result["ok"] = True
            result["entity"] = _own_ent
            result["source"] = "scope_state"
            result["scope"] = str(scope)
            # v99.08 Patch-8: account_id alias — every caller treats
            # account_id as authoritative.
            result["account_id"] = str(scope)
            result["outcome"] = _VC_RES_RESOLVED_FROM_SCOPE_STATE
            logger.info(
                "ENTITY_RESOLVE_CACHE_HIT chat_id=%s scope=%s "
                "source=scope_state age=%.0fs (v98.10 §15 Step 0a — 0 RPCs)",
                _marked, scope, _own_age,
            )
            return True
        if _own_ah:
            # §19: entity metadata TTL is LONG but bounded — a stale
            # entry revalidates with ONE typed RPC (0b) instead of being
            # returned blind (the hash itself is what the server checks).
            _inp = _v9810_typed_input_peer(ident, _own_ah)
            if _inp is not None:
                try:
                    logger.info(
                        "ENTITY_RESOLVE_TYPE_KNOWN chat_id=%s kind=%s "
                        "scope=%s (v98.10 §6)",
                        _marked, ident.get("kind"), scope,
                    )
                    _ent = await asyncio.wait_for(
                        _v9810_rpc_wrap(counter, client.get_entity, _inp),
                        timeout=8.0,
                    )
                    if _ent is not None:
                        _v9810_access_remember(scope, ident, _ent, "scope_state")
                        _v9810_stats_bump("scope_state_hits")
                        result["ok"] = True
                        result["entity"] = _ent
                        result["source"] = "scope_state_hash"
                        result["scope"] = str(scope)
                        # v99.08 Patch-8: account_id alias.
                        result["account_id"] = str(scope)
                        result["outcome"] = _VC_RES_RESOLVED_FROM_SCOPE_STATE
                        logger.info(
                            "ENTITY_RESOLVE_HASH_HIT chat_id=%s scope=%s "
                            "(v98.10 §15 Step 0b — 1 RPC, no failure ladder)",
                            _marked, scope,
                        )
                        return True
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001
                    _cls = _vc_resolution_outcome(exc, ident, had_hash=True)
                    if _cls in (_VC_RES_HASH_INVALID, _VC_RES_NOT_ACCESSIBLE,
                            _VC_RES_LOCAL_MISS):
                        _n = _v9810_access_invalidate(scope, _marked)
                        _v9810_hash_invalid_record(scope, _marked, _own_ah)
                        logger.info(
                            "ENTITY_RESOLVE_HASH_INVALID chat_id=%s scope=%s "
                            "invalidated=%d — stale for this scope only, "
                            "refreshing (v98.10 §10)",
                            _marked, scope, _n,
                        )
                        result["needs_refresh"] = True
                    # else: transient — keep the entry, fall through.
    # (c) other-scope known-good routing (§12/§15/§40: TARGETED).
    for _other in _v9810_access_other_scopes(_marked, scope):
        _aid = str(_other.get("scope") or "")
        _oah = int(_other.get("access_hash") or 0)
        if not _oah:
            continue
        try:
            if _aid.startswith("acc_"):
                _cluster = get_userbot_cluster()
                _c = _cluster.get_client(_aid) if _cluster is not None else None
                if _c is None:
                    continue
            elif _aid == "global":
                # v99.06 FIX-1 (1.7): translate the stored chameleon token
                # BEFORE routing.  A scope=global entry was earned by SOME
                # past primary; the CURRENT primary's client must not
                # consume it after a rotation (the 2026-09-09 production
                # log: 388x CHANNEL_INVALID from exactly this path —
                # _mtproto_client is ALWAYS "the current primary", so the
                # OLD primary's hashes kept validating against the NEW
                # primary's session).
                _v9906_real = get_primary_account_id() or "global"
                if _v9906_real != "global":
                    _v9906_cluster = get_userbot_cluster()
                    _v9906_rc = (_v9906_cluster.get_client(_v9906_real)
                                 if _v9906_cluster is not None else None)
                    if _v9906_rc is None or _v9906_rc is client:
                        # Owner not live, or the consumer IS the real owner
                        # (post-rotation new primary): NOT an "other scope"
                        # — never a stale cross-scope cache hit.  The caller
                        # falls through to a FRESH resolve (A5 contract).
                        continue
                    _c = _v9906_rc
                    # Remember/invalidate under the REAL owner id.
                    _aid = _v9906_real
                else:
                    # Primary unidentifiable — legacy v99.05 behavior.
                    _c = _mtproto_client
                    if _c is None or _c is client:
                        continue  # same client → not "other scope" after all
            else:
                # "client:<id>" tokens have no stable cross-call handle.
                continue
            _age_c = max(0.0, time.time() - float(_other.get("verified_at", 0.0)))
            logger.info(
                "ENTITY_RESOLVE_ACCOUNT_SWITCH chat_id=%s from_scope=%s "
                "to_account=%s reason=known_good_scope verified_at=%.0fs "
                "ago (v98.10 §15 Step 0c — targeted routing, not a blind "
                "rotation)",
                _marked, scope, _aid, _age_c,
            )
            # §20: a FRESH entity object remembered for this scope is
            # returned directly (0 entity-resolution RPCs — the P3 tier-0
            # philosophy: within the freshness window, trust the verified
            # data; the CONSUMER's detection validates it).  Stale or
            # object-less entries (restart) revalidate with ONE typed RPC.
            _other_ent = _other.get("entity")
            if _other_ent is not None and _age_c <= _v9810_access_ttl():
                if _aid == "global":
                    result["source"] = "scope_state"
                    result["scope"] = "global"
                    result["outcome"] = _VC_RES_RESOLVED_FROM_SCOPE_STATE
                else:
                    result["source"] = f"account_rotation:{_aid}"
                    result["scope"] = _aid
                    result["outcome"] = _VC_RES_RESOLVED_VIA_ROTATION
                result["ok"] = True
                result["entity"] = _other_ent
                # v99.08 Patch-8: account_id alias — same value as scope
                # (the account that SUPPLIED the entity).
                result["account_id"] = str(result.get("scope") or "")
                _v9810_stats_bump("scope_state_hits")
                logger.info(
                    "ENTITY_RESOLVE_CACHE_HIT chat_id=%s scope=%s "
                    "source=scope_state age=%.0fs (v98.10 §15 Step 0c — "
                    "fresh known-good object, 0 RPCs)",
                    _marked, _aid, _age_c,
                )
                return True
            _inp = _v9810_typed_input_peer(ident, _oah)
            if _inp is None:
                continue
            _ent = await asyncio.wait_for(
                _v9810_rpc_wrap(counter, _c.get_entity, _inp),
                timeout=8.0,
            )
            if _ent is not None:
                _v9810_access_remember(_aid, ident, _ent,
                                       "known_good_route")
                result["ok"] = True
                result["entity"] = _ent
                if _aid == "global":
                    # Global route: no cluster account to rotate to — the
                    # consumer detects on its own client (source=scope_state
                    # keeps the v98.07 detection routing on the caller, which
                    # IS the primary for every Join-All classification call).
                    result["source"] = "scope_state"
                    result["scope"] = "global"
                    result["outcome"] = _VC_RES_RESOLVED_FROM_SCOPE_STATE
                else:
                    # EXACT source format the v98.07 detection routing parses.
                    result["source"] = f"account_rotation:{_aid}"
                    result["scope"] = _aid
                    result["outcome"] = _VC_RES_RESOLVED_VIA_ROTATION
                # v99.08 Patch-8: account_id alias.
                result["account_id"] = str(result.get("scope") or "")
                _v9810_stats_bump("scope_state_hits")
                logger.info(
                    "VC_ENTITY_RESOLVE_SUCCESS chat_id=%s source=%s "
                    "reason=known_good (v98.10 §12 — successful resolution "
                    "persisted, no retry ladder)", _marked, result["source"],
                )
                return True
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            _cls = _vc_resolution_outcome(exc, ident, had_hash=True)
            if _cls in (_VC_RES_HASH_INVALID, _VC_RES_NOT_ACCESSIBLE,
                            _VC_RES_LOCAL_MISS):
                _v9810_access_invalidate(_aid, _marked)
                _v9810_hash_invalid_record(_aid, _marked, _oah)
            # else transient — try the next candidate scope.
            continue
    return False


# ===========================================================================
# v99.11 FIX(P1) — Telethon contacts retrieval ladder (get_contacts removed)
# ====================================================================================

async def _telethon_fetch_contacts(client: Any) -> list:
    """v99.11 FIX(P1): Telethon 1.x contacts retrieval — the supported ladder.

    Production evidence (2026-09-21 bot-diagnostic.log.3, 11:33:37):
      ``ENTITY_CONTACT_SEARCH_FAILED chat_id=1549865674 …
      exc=AttributeError: 'TelegramClient' object has no attribute
      'get_contacts'`` — Telethon REMOVED ``TelegramClient.get_contacts``
      in the 1.x line (present in 1.23, gone by 1.24; this project pins
      ``telethon>=1.34.0,<2.0`` with production 1.44.0, requirements.txt
      §v98.13-PIN).  The v99.10 code called the removed API at three
      sites; the exception fell into the guarded fallback paths, so
      contact-based entity resolution silently NEVER worked.

    Supported mechanism on the pinned 1.x line:
      1. ``client.iter_contacts()`` — the supported async iterator
         (exists throughout 1.x); materialized with a 5000-item cap so
         a pathological contact list cannot balloon memory.
      2. Raw-API fallback — ``functions.contacts.GetContactsRequest``
         invoked via ``await client(...)`` and reading ``.users`` — for
         driver/stub clients that only implement the raw call interface
         (harness drivers, older 1.x builds).

    This helper NEVER touches ``get_contacts`` (the attribute does not
    exist on the pinned versions).  Raises whatever the client raises —
    callers keep their existing guarded-fallback semantics.
    """
    # Ladder step 1: the supported 1.x async iterator.
    try:
        if hasattr(client, "iter_contacts"):
            out: list = []
            async for contact in client.iter_contacts():  # type: ignore[attr-defined]
                out.append(contact)
                if len(out) >= 5000:  # bounded materialization
                    break
            return out
    except asyncio.CancelledError:
        raise
    except Exception:
        pass  # fall through to the raw-API ladder step
    # Ladder step 2: the raw API via the client's __call__ interface.
    try:
        from telethon import functions as _tl_functions  # noqa: PLC0415
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            "no supported contacts API: iter_contacts unavailable and "
            "telethon raw functions not importable (v99.11 FIX-P1)"
        ) from exc
    result = await client(_tl_functions.contacts.GetContactsRequest(hash=0))
    return list(getattr(result, "users", None) or [])


# ===========================================================================
# V82.1 ISSUE 6: resolve_vc_entity — VC-specific entity resolution
# ===========================================================================

async def resolve_vc_entity(client: Any, chat_ref: str | int,
                             chat_id: int = 0,
                             access_hash: int = 0) -> dict[str, Any]:
    """V82.1 ISSUE 6: Resolve a VC target entity with VC-specific strategies.

    VCs are typically channels/supergroups. This resolver:
      1. Checks if the discovery already returned the entity (reuse, don't re-resolve)
      2. Tries InputPeerChannel / InputPeerChat construction
      3. Falls back to resolve_entity_full (9-step)
      4. Falls back to resolve_across_accounts (multi-account)

    v97.37 FIX: added ``access_hash`` parameter. When the caller provides a
    known access_hash (e.g. from the VC discovery snapshot), it's used to
    construct ``InputPeerChannel(raw_id, access_hash)`` directly — this
    succeeds even if the session cache doesn't have the entity. Without this,
    a raw positive channel ID (e.g. 1393246704) was misclassified as a basic
    Chat (InputPeerChat) instead of a Channel (InputPeerChannel), causing
    "Could not find the input entity for PeerChannel" failures.

    Returns: {ok, entity, source, error, scope?, outcome?, rpcs?, duration_ms?}
    """
    result: dict[str, Any] = {
        "ok": False, "entity": None, "source": "", "error": "",
    }
    logger.info("VC_ENTITY_RESOLVE_START chat_ref=%s chat_id=%s access_hash=%s",
                chat_ref, chat_id, "yes" if access_hash else "no")

    # ------------------------------------------------------------------
    # v98.10 — single-flight (§41/§43) + scoped known-good routing
    # (§15 Step 0) + forensic accounting (§21/§22).
    # ------------------------------------------------------------------
    _t0 = time.monotonic()
    _rpc_counter: dict[str, int] = {"rpcs": 0, "failed_rpcs": 0}
    _v9810_stats_bump("attempts")
    _ident = _vc_entity_identity(chat_ref, chat_id=chat_id,
                                 access_hash=access_hash)
    _scope = _vc_client_scope(client)
    _sf_key = (_scope, int(_ident.get("marked_id") or 0))
    _sf_fut = None

    # v98.10 §41/§43: single-flight — concurrent resolutions of the SAME
    # (scope, entity) share ONE flight (Task A leads; Tasks B/C join and
    # all receive the same result).  Keyed per (entity, scope) so
    # unrelated entities/accounts are NEVER serialized against each
    # other (§43).  Waiters are shielded so ONE waiter's cancellation
    # cannot kill the shared flight.
    if _sf_key[1]:
        _sf_existing = _v9810_resolve_inflight.get(_sf_key)
        if _sf_existing is not None and not _sf_existing.done():
            _v9810_stats_bump("singleflight_joins")
            logger.info(
                "ENTITY_RESOLVE_SINGLEFLIGHT_JOIN chat_id=%s scope=%s "
                "(v98.10 §41 — sharing the in-flight resolution)",
                _sf_key[1], _sf_key[0],
            )
            try:
                # Bounded join, v97.73 NO-SHIELD COMPLIANT: the waiter
                # awaits a private MIRROR future wired to the leader's
                # flight via a done-callback.  A waiter timeout/cancel
                # can only cancel ITS OWN mirror — the shared leader
                # flight is structurally impossible to cancel from a
                # waiter (which is what shield would have bought, minus
                # the shield).  The leader's finally resolves the flight
                # on EVERY exit path; the 30s cap is belt-and-braces
                # against a hard-killed leader task (§41: bounded
                # cleanup, no leaked in-flight entries, no hang).
                _sf_mirror = asyncio.get_running_loop().create_future()

                def _sf_on_done(_f: Any, _m: Any = _sf_mirror) -> None:
                    try:
                        if _m.done():
                            return
                        if _f.cancelled():
                            _m.cancel()
                        elif _f.exception() is not None:
                            _m.set_exception(_f.exception())
                        else:
                            _m.set_result(_f.result())
                    except Exception:  # noqa: BLE001
                        pass

                _sf_existing.add_done_callback(_sf_on_done)
                _shared = await asyncio.wait_for(_sf_mirror, timeout=30.0)
                if isinstance(_shared, dict):
                    _shared = dict(_shared)
                    _shared["singleflight"] = True
                return _shared
            except asyncio.CancelledError:
                raise
            except Exception:
                # Leader failed (or the bounded join timed out) — fall
                # through and lead our own attempt.
                pass
        try:
            _sf_fut = asyncio.get_running_loop().create_future()
            _v9810_resolve_inflight[_sf_key] = _sf_fut
        except Exception:  # noqa: BLE001
            _sf_fut = None
    try:

        # Step 1: Check if already cached.
        if chat_id and chat_id in _vc_entity_cache:
            cached = _vc_entity_cache[chat_id]
            # v98.07 FIX-QQ: SCOPE GATE — an entity resolved under account scope X
            # carries X's access_hash. Consuming it from client Y
            # (GetFullChannelRequest) → ChannelInvalidError ("Invalid channel
            # object"). The v98.06 log showed 237 discovery skips + 179
            # REDETECT_FAILED from exactly this cross-scope consumption.
            # Mismatch → SKIP the cache hit and re-resolve for THIS client
            # (Steps 2-4 below). Legacy entries without a scope field still hit
            # (the v97.78 fast path is preserved when the hash IS valid).
            if not _vc_cache_scope_ok(cached, client):
                logger.warning(
                    "VC_HASH_SCOPE_MISMATCH chat_id=%s entry_scope=%s "
                    "consumer_scope=%s — skipping cache hit, re-resolving for "
                    "this client (v98.07 FIX-QQ)",
                    chat_id, cached.get("scope"), _vc_client_scope(client),
                )
            else:
                cached_entity = cached.get("entity")
                if cached_entity is not None:
                    result["ok"] = True
                    result["entity"] = cached_entity
                    result["source"] = "cache"
                    result["scope"] = cached.get("scope") or _vc_client_scope(client)
                    logger.info("VC_ENTITY_RESOLVE_CACHE_HIT chat_id=%s", chat_id)
                    logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_id=%s source=cache", chat_id)
                    # §12: the flat hit is also account-scoped knowledge.
                    _v9810_access_remember(
                        result.get("scope") or _scope, _ident, cached_entity,
                        "flat_cache")
                    _v9810_stats_bump("cache_hits")
                    result["outcome"] = _VC_RES_RESOLVED_FROM_CACHE
                    return result

        # ------------------------------------------------------------------
        # v98.10 §15 Step 0: ACCOUNT-SCOPED KNOWN-GOOD ROUTING — run AFTER
        # the flat cache (cheapest, 0 RPC) and BEFORE the provided-hash
        # InputPeer attempt (which is the 46× "Invalid channel object"
        # source when the DB hash is foreign to this account).  Zero-RPC
        # when the entity object is remembered for this scope; ONE typed
        # RPC when routing to the account that ACTUALLY resolved the
        # entity in a previous run (§12 — successful resolution stops
        # future retries).
        # ------------------------------------------------------------------
        try:
            if await _v9810_scope_route(client, _ident, _scope,
                                        _rpc_counter, result):
                result["rpcs"] = int(_rpc_counter.get("rpcs", 0))
                result["duration_ms"] = (time.monotonic() - _t0) * 1000.0
                _v9810_stats_bump("successes")
                _v9810_stats_bump("cache_hits")
                return result
        except asyncio.CancelledError:
            raise
        except Exception as _exc:  # noqa: BLE001
            logger.debug("ENTITY_RESOLVE_STEP0_FAILED chat_id=%s exc=%s",
                         _ident.get("marked_id"), _exc)

        # v98.10 §10/§11: skip replaying a hash that was recently REJECTED
        # for THIS scope (the 46× "Invalid channel object" signature) — the
        # owning scope is unaffected; TTL-bounded, never an exclusion.
        _v9810_skip_provided_hash = _v9810_hash_invalid_check(
            _scope, int(_ident.get("marked_id") or 0), int(access_hash or 0))
        if _v9810_skip_provided_hash and access_hash:
            _v9810_stats_bump("hash_invalid_skips")
            logger.info(
                "ENTITY_RESOLVE_NEGATIVE_CACHE_HIT chat_id=%s scope=%s "
                "hash=%s — recently rejected for this scope, skipping the "
                "replay (v98.10 §11; TTL-bounded hint, NOT an exclusion)",
                _ident.get("marked_id"), _scope, _redact_ah(access_hash),
            )

        # v98.11 S4: the Step-2 typed probe's observed class (server-side
        # denials only; see the handler below).
        _v9811_step2_cls = ""
        # Step 2: Try InputPeerChannel / InputPeerChat construction.
        if chat_id:
            try:
                from telethon.tl.types import InputPeerChannel, InputPeerChat
                # v97.37: if the caller provided an access_hash, use it directly
                # to construct InputPeerChannel. This works for raw positive
                # channel IDs (which were previously misclassified as basic Chat).
                # v99 RC-C: skip replaying a hash that provably belongs to a
                # FOREIGN account — if the flat cache holds a scope-annotated
                # entry with THIS hash under a different scope, replaying it
                # through THIS client yields CHANNEL_INVALID ("Invalid channel
                # object").  Let the ladder below resolve fresh for THIS
                # account instead.
                _v99_hash_foreign = False
                try:
                    for _fk in (chat_id, int(_ident.get("marked_id") or 0)):
                        if not _fk:
                            continue
                        _fe = _vc_entity_cache.get(int(_fk))
                        if (isinstance(_fe, dict)
                                and _fe.get("access_hash")
                                and int(_fe.get("access_hash") or 0)
                                    == int(access_hash)):
                            _fsc = str(_fe.get("scope") or "")
                            if _fsc and _fsc != "(unknown)" and _fsc != _scope:
                                _v99_hash_foreign = True
                                logger.info(
                                    "ENTITY_RESOLVE_PROVIDED_HASH_FOREIGN_SCOPE "
                                    "chat_id=%s scope=%s owner=%s — skipping "
                                    "the foreign-hash replay (v99 RC-C)",
                                    chat_id, _scope, _fsc,
                                )
                                break
                except Exception:  # noqa: BLE001
                    _v99_hash_foreign = False
                if access_hash and not _v9810_skip_provided_hash \
                        and not _v99_hash_foreign:
                    try:
                        # Determine the raw_id: if chat_id is marked (-100<id>),
                        # extract the raw_id; if it's already raw (positive),
                        # use it directly.
                        raw_id = abs(chat_id) % 1000000000000 if chat_id < 0 else chat_id
                        input_peer = InputPeerChannel(
                            channel_id=raw_id, access_hash=int(access_hash))
                        entity = await _v9810_rpc_wrap(
                            _rpc_counter, client.get_entity, input_peer)
                        if entity is not None:
                            _vc_entity_cache[chat_id] = {
                                "entity": entity, "access_hash": access_hash,
                                "source": "input_peer_channel_with_provided_hash",
                                # v98.07 FIX-QQ: scope-annotate every cache write.
                                "scope": _vc_client_scope(client),
                            }
                            result["ok"] = True
                            result["entity"] = entity
                            result["source"] = "input_peer_channel_with_provided_hash"
                            # §12: remember the account this hash WORKS for.
                            _v9810_access_remember(_scope, _ident, entity,
                                                   "provided_hash")
                            result["outcome"] = _VC_RES_RESOLVED_FROM_ACCESS_HASH
                            logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_id=%s "
                                        "source=input_peer_channel_with_provided_hash", chat_id)
                            return result
                    except Exception as exc:  # noqa: BLE001
                        # v98.10 §9/§10: classify — a rejected (channel, hash)
                        # pair is HASH_INVALID for THIS scope only; record the
                        # scoped hint so the NEXT attempt skips the replay.
                        _cls2 = _vc_resolution_outcome(exc, _ident, had_hash=True)
                        if _cls2 == _VC_RES_HASH_INVALID and access_hash:
                            _v9810_hash_invalid_record(
                                _scope, int(_ident.get("marked_id") or 0),
                                int(access_hash))
                        # v98.11 S4: a SERVER-VERIFIED denial observed on
                        # the typed probe (PRIVATE / NOT_ACCESSIBLE /
                        # NOT_FOUND / HASH_INVALID) outranks the ladder's
                        # later LOCAL cache-miss noise - the composite
                        # class reflects the ROOT cause, exactly like the
                        # ladder's own REPRESENTATION_ERROR precedence.
                        if _cls2 in (_VC_RES_PRIVATE, _VC_RES_NOT_ACCESSIBLE,
                                     _VC_RES_NOT_FOUND, _VC_RES_HASH_INVALID):
                            _v9811_step2_cls = _cls2
                        logger.debug("VC_ENTITY_RESOLVE input_peer_with_provided_hash failed: %s", exc)
                # For supergroups/channels: marked ID is -100<id>.
                if chat_id < 0:
                    raw_id = abs(chat_id) % 1000000000000
                    _v9810_flat_entry = _vc_entity_cache.get(chat_id, {})
                    cached_ah = _v9810_flat_entry.get("access_hash", 0)
                    # v98.10 §7: a flat-cache hash is only safe for THIS
                    # client when its scope entry permits it (foreign-scope
                    # hashes are the 46× "Invalid channel object" source);
                    # a recently-rejected hash is skipped outright (§10).
                    if cached_ah and not _vc_cache_scope_ok(_v9810_flat_entry, client):
                        _v9810_stats_bump("hash_invalid_skips")
                        logger.info(
                            "ENTITY_RESOLVE_NEGATIVE_CACHE_HIT chat_id=%s scope=%s "
                            "hash=flat — foreign-scope hash not replayed "
                            "(v98.10 §7)", chat_id, _scope,
                        )
                        cached_ah = 0
                    if cached_ah and _v9810_hash_invalid_check(
                            _scope, int(_ident.get("marked_id") or 0),
                            int(cached_ah)):
                        _v9810_stats_bump("hash_invalid_skips")
                        cached_ah = 0
                    if cached_ah:
                        try:
                            # V85.3 FIX BUG ENT-12: persisted access_hash entries
                            # are stored as STRING (via str() in _persist_access_hash).
                            # InputPeerChannel requires an int — a string here
                            # causes a Telethon serialization TypeError after a
                            # process restart.
                            input_peer = InputPeerChannel(
                                channel_id=raw_id, access_hash=int(cached_ah))
                            entity = await _v9810_rpc_wrap(
                                _rpc_counter, client.get_entity, input_peer)
                            if entity is not None:
                                _vc_entity_cache[chat_id] = {
                                    "entity": entity, "access_hash": cached_ah,
                                    "source": "input_peer_channel",
                                    "scope": _vc_client_scope(client),
                                }
                                result["ok"] = True
                                result["entity"] = entity
                                result["source"] = "input_peer_channel"
                                _v9810_access_remember(_scope, _ident, entity,
                                                       "flat_hash")
                                result["outcome"] = _VC_RES_RESOLVED_FROM_ACCESS_HASH
                                logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_id=%s "
                                            "source=input_peer_channel", chat_id)
                                return result
                        except Exception:
                            pass
                elif chat_id > 0:
                    # Basic chat (not supergroup).
                    try:
                        input_peer = InputPeerChat(chat_id=chat_id)
                        entity = await _v9810_rpc_wrap(
                            _rpc_counter, client.get_entity, input_peer)
                        if entity is not None:
                            _vc_entity_cache[chat_id] = {
                                "entity": entity,
                                "access_hash": getattr(entity, "access_hash", None),
                                "source": "input_peer_chat",
                                "scope": _vc_client_scope(client),
                            }
                            result["ok"] = True
                            result["entity"] = entity
                            result["source"] = "input_peer_chat"
                            _v9810_access_remember(_scope, _ident, entity,
                                                   "input_peer_chat")
                            result["outcome"] = _VC_RES_RESOLVED_FROM_ACCESS_HASH
                            logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_id=%s "
                                        "source=input_peer_chat", chat_id)
                            return result
                    except Exception:
                        pass
            except ImportError:
                pass

        # Step 3: Try resolve_entity_full (9-step pipeline).
        _step3_exc: Exception | None = None
        try:
            entity = await resolve_entity_full(client, chat_ref,
                                               identity=_ident,
                                               rpc_counter=_rpc_counter)
            if entity is not None:
                result["ok"] = True
                result["entity"] = entity
                result["source"] = "resolve_entity_full"
                _v9810_access_remember(_scope, _ident, entity,
                                       "resolve_entity_full")
                result["outcome"] = _VC_RES_RESOLVED
                logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_ref=%s source=resolve_entity_full",
                            chat_ref)
                return result
        except VCTransportError as _exc:
            _step3_exc = _exc
        except Exception as exc:
            _step3_exc = exc
            logger.debug("VC_ENTITY_RESOLVE resolve_entity_full failed: %s", exc)

        # v98.10 §8/§40: PREVENT FALSE ACCOUNT ROTATION — rotate ONLY when
        # the failure classification justifies trying another account
        # (access/not-found/private/floodwait).  A REPRESENTATION error
        # (wrong Telethon input type) or an INVALID_ENTITY_TYPE cannot be
        # fixed by another account — rotating for those is exactly the
        # expensive multi-account churn the diagnostic log showed.
        _step3_cls = _v9810_extract_outcome_class(_step3_exc) or \
            _vc_resolution_outcome(_step3_exc, _ident, had_hash=False)
        # v98.11 S4 composite: a server-verified denial from the Step-2
        # probe outranks the ladder's LOCAL_MISS terminal noise (V7: a
        # channel PRIVATE for this account reads as PRIVATE at the gate,
        # so the fallback is JUSTIFIED - not a blind local-miss rotation).
        if _step3_cls == _VC_RES_LOCAL_MISS and _v9811_step2_cls:
            _step3_cls = _v9811_step2_cls
        if _step3_exc is not None and _step3_cls in (
                _VC_RES_REPRESENTATION_ERROR, _VC_RES_INVALID_ENTITY_TYPE):
            _v9810_stats_bump("representation_errors")
            logger.info(
                "ENTITY_RESOLVE_REPRESENTATION_ERROR chat_ref=%s class=%s — "
                "account rotation SKIPPED (a wrong Telethon input type cannot "
                "be fixed by another account; v98.10 §8)",
                chat_ref, _step3_cls,
            )
            result["error"] = f"[{_step3_cls}] {str(_step3_exc)[:160]}"
            result["outcome"] = _step3_cls
            logger.error("VC_ENTITY_RESOLVE_FAILED chat_ref=%s reason=%s",
                         chat_ref, _step3_cls)
            return result

        # ----------------------------------------------------------
        # v98.11 S4/S5: LOCAL_MISS must NOT rotate by itself.  Telethon's
        # "Could not find the input entity for PeerChannel" is a LOCAL
        # session-cache miss (no RPC, no server denial) - the account may
        # still access the entity with a scoped hash (the typed InputPeer
        # path bypasses the local cache entirely).  Rotation is justified
        # ONLY with account-scoped EVIDENCE: this scope recently REJECTED
        # a hash (server-verified, S10) AND the deterministic refresh
        # (the ladder we just ran) failed - the composite
        # "account-scoped resolution failure" (S5).  Without that
        # evidence the failure is returned classified; callers retry
        # within their bounded budgets (no global state churn).
        # ----------------------------------------------------------
        if _step3_exc is not None and _step3_cls in (
                _VC_RES_LOCAL_MISS, _VC_RES_TEMPORARY_RPC_FAILURE) \
                and not (_step3_cls == _VC_RES_LOCAL_MISS
                         and _v9811_scope_hash_rejected(
                             _scope, int(_ident.get("marked_id") or 0))):
            _v9810_stats_bump("local_miss_no_rotation")
            logger.info(
                "ENTITY_RESOLVE_LOCAL_MISS chat_id=%s scope=%s class=%s - "
                "%s; account rotation SKIPPED (v98.11 S5/S18: a local "
                "session-cache miss is not an access denial, and a "
                "transient network failure is not account-scoped "
                "evidence)",
                chat_id or _ident.get("marked_id"), _scope, _step3_cls,
                "local session-cache miss WITHOUT account-scoped "
                "rejection evidence"
                if _step3_cls == _VC_RES_LOCAL_MISS else
                "transient RPC failure (entry kept, retry within the "
                "existing bounded budgets)",
            )
            result["error"] = f"[{_step3_cls}] {str(_step3_exc)[:160]}"
            result["outcome"] = _step3_cls
            logger.error("VC_ENTITY_RESOLVE_FAILED chat_ref=%s reason=%s "
                         "(classified, no rotation)", chat_ref, _step3_cls)
            return result

        # Step 4: Try resolve_across_accounts (multi-account).
        _v9811_rot_evidence = (
            "local_miss+scoped_hash_rejection" if _step3_cls == _VC_RES_LOCAL_MISS
            else str(_step3_cls or "unclassified failure"))
        logger.info(
            "VC_ENTITY_RESOLVE_ROTATED chat_ref=%s - trying all accounts "
            "(class=%s, evidence=%s, v98.11 S5: rotation justified by "
            "account-scoped failure evidence)",
            chat_ref, _step3_cls or "unknown", _v9811_rot_evidence)
        _v9810_stats_bump("rotations")
        rotation = await resolve_across_accounts(
            chat_ref, identity=_ident, rpc_counter=_rpc_counter,
            access_hash=int(access_hash or 0))
        if rotation.get("ok"):
            result["ok"] = True
            result["entity"] = rotation["entity"]
            result["source"] = f"account_rotation:{rotation['account_id']}"
            result["scope"] = rotation.get("scope") or ""
            result["outcome"] = _VC_RES_RESOLVED_VIA_ROTATION
            logger.info("VC_ENTITY_RESOLVE_SUCCESS chat_ref=%s source=account_rotation",
                        chat_ref)
            return result

        logger.error("VC_ENTITY_RESOLVE_FAILED chat_ref=%s reason=all_strategies_failed",
                     chat_ref)
        result["error"] = "All VC entity resolution strategies failed."
        result["outcome"] = _step3_cls or _VC_RES_NOT_FOUND
        return result

    except asyncio.CancelledError:
        if _sf_fut is not None and not _sf_fut.done():
            _sf_fut.cancel()
        raise
    except BaseException as _sf_exc:  # noqa: BLE001
        if _sf_fut is not None and not _sf_fut.done():
            _sf_fut.set_exception(_sf_exc)
        raise
    finally:
        # v98.10 §41: fan the result out to every waiter, then release
        # the inflight slot (bounded — no stale entries can leak).
        if _sf_fut is not None:
            _v9810_resolve_inflight.pop(_sf_key, None)
            if not _sf_fut.done():
                _sf_fut.set_result(result)
        # v98.10 §21/§22: per-resolution forensic accounting (chat_id,
        # scope, rpcs, failed_rpcs, outcome, duration_ms — no secrets,
        # hashes redacted elsewhere).
        try:
            result["rpcs"] = int(_rpc_counter.get("rpcs", 0))
            result["duration_ms"] = (time.monotonic() - _t0) * 1000.0
            if result.get("ok"):
                _v9810_stats_bump("successes")
            else:
                _v9810_stats_bump("failures")
            _v9810_resolution_latency_ms.append(result["duration_ms"])
            if len(_v9810_resolution_latency_ms) > 512:
                del _v9810_resolution_latency_ms[:-256]
            logger.info(
                "ENTITY_RESOLVE_RPC_COUNT chat_id=%s scope=%s rpcs=%d "
                "failed_rpcs=%d outcome=%s duration_ms=%.1f (v98.10 §22)",
                chat_id or _ident.get("marked_id") or 0, _scope,
                int(_rpc_counter.get("rpcs", 0)),
                int(_rpc_counter.get("failed_rpcs", 0)),
                result.get("outcome")
                or ("RESOLVED" if result.get("ok") else "FAILED"),
                result.get("duration_ms", 0.0),
            )
        except Exception:  # noqa: BLE001
            pass
    return result

# ===========================================================================
# V82.1 ISSUE 9: Public group auto-join
# ===========================================================================
