"""Utility functions — extracted from _bot_core.py.

Contains:
  - File utilities (safe_filename, unique_path, remove_path, cleanup_directory)
  - Supervised task registry (supervised_create_task, _active_tasks)
  - Periodic cleanup (periodic_cleanup)
  - Safe send/edit/reply (safe_reply_text, safe_edit_message_text, safe_send_message)
  - UI ownership registry (_ui_claim, _ui_check, _ui_release)
  - Bot registry (register_bot, get_bot)
  - Media type detection (telegram_media_type, extension_category)
"""

from __future__ import annotations

import asyncio
import functools
import logging
import os
import re
import shutil
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Awaitable, Callable, Iterable, Optional, TypeVar

from telegram.error import BadRequest, Forbidden, NetworkError, TimedOut, RetryAfter

from .config import _env_bool, config

logger = logging.getLogger("mediagrab")

# ===========================================================================
# Logging infrastructure (moved from _bot_core.py)
# ===========================================================================

_LOG_FMT = (
    "%(asctime)s | %(levelname)-7s | %(name)-18s | "
    "%(funcName)s:%(lineno)d | %(message)s"
)
_DATE_FMT = "%Y-%m-%d %H:%M:%S"


def setup_logging() -> logging.Logger:
    """V45 Fix #11/#13/#14: unified logging with terminal+bot.log parity."""
    logging.raiseExceptions = False

    root = logging.getLogger()
    if getattr(root, "_mediagrab_configured", False):
        return logging.getLogger("mediagrab")

    # v97.88: DIAGNOSTIC_BOOT — emit at the ABSOLUTE earliest point, BEFORE
    # any file operations, to prove this code is reached.
    import os as _os
    _pid = _os.getpid()
    _cwd = _os.getcwd()
    _raw_env = _os.environ.get("DIAGNOSTIC_LOGGING", "")
    _parsed_env = _raw_env.strip().lower() in ("1", "true", "yes", "on") if _raw_env else False
    print(
        f"DIAGNOSTIC_BOOT pid={_pid} cwd={_cwd} "
        f"raw_env=DIAGNOSTIC_LOGGING={_raw_env!r} "
        f"parsed={_parsed_env} "
        f"python={sys.executable}",
        file=sys.stderr,
    )
    diagnostic = _parsed_env
    if diagnostic:
        console_level = getattr(logging, config.log_level, logging.INFO)
    else:
        console_level = logging.ERROR
    root.setLevel(logging.DEBUG)

    formatter = logging.Formatter(_LOG_FMT, datefmt=_DATE_FMT)

    dedup_filter = _ErrorDedupFilter()
    root.addFilter(dedup_filter)

    console = logging.StreamHandler(sys.stderr)
    console.setLevel(console_level)
    console.setFormatter(formatter)
    root.addHandler(console)

    _bot_log_path = None
    _bot_log_active = False
    try:
        log_file = config.project_root / "bot.log"
        log_file = log_file.resolve()
        log_file.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write("")
                f.flush()
        except OSError as probe_exc:
            print(
                f"CRITICAL: bot.log write probe failed at {log_file}: "
                f"{type(probe_exc).__name__}: {probe_exc}",
                file=sys.stderr,
            )
        else:
            file_handler = RotatingFileHandler(
                log_file, maxBytes=5_000_000, backupCount=3, encoding="utf-8"
            )
            file_handler.setLevel(logging.ERROR)
            file_handler.setFormatter(formatter)
            root.addHandler(file_handler)
            _bot_log_path = str(log_file)
            _bot_log_active = True
    except OSError as exc:
        print(
            f"CRITICAL: bot.log file logging unavailable: "
            f"{type(exc).__name__}: {exc}",
            file=sys.stderr,
        )

    root._bot_log_path = _bot_log_path  # type: ignore[attr-defined]
    root._bot_log_active = _bot_log_active  # type: ignore[attr-defined]

    _diag_log_path = None
    if diagnostic:
        # v97.88: report diagnostic path details BEFORE attempting creation
        _diag_configured_path = config.project_root / "bot-diagnostic.log"
        _diag_absolute_path = str(_diag_configured_path.resolve())
        _diag_parent = str(_diag_configured_path.parent)
        _diag_parent_exists = _diag_configured_path.parent.exists()
        _diag_parent_writable = _os.access(_diag_parent, _os.W_OK) if _diag_parent_exists else False
        print(
            f"DIAGNOSTIC_PATH configured_path={_diag_configured_path} "
            f"absolute_path={_diag_absolute_path} "
            f"parent={_diag_parent} "
            f"parent_exists={_diag_parent_exists} "
            f"parent_writable={_diag_parent_writable}",
            file=sys.stderr,
        )
        try:
            diag_file = config.project_root / "bot-diagnostic.log"
            diag_file = diag_file.resolve()
            diag_file.parent.mkdir(parents=True, exist_ok=True)
            diag_handler = RotatingFileHandler(
                diag_file, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
            )
            diag_handler.setLevel(logging.DEBUG)
            diag_handler.setFormatter(formatter)
            root.addHandler(diag_handler)
            _diag_log_path = str(diag_file)
            # v97.88: report file creation success + flush
            print(
                f"DIAGNOSTIC_FILE_CREATE_RESULT success=true path={_diag_log_path}",
                file=sys.stderr,
            )
            _init_msg = (
                f"DIAGNOSTIC_LOGGING_INITIALIZED enabled=true "
                f"log_path={_diag_log_path} "
                f"cwd={_cwd} "
                f"pid={_pid} "
                f"logger=root "
                f"level=DEBUG "
                f"handlers={len(root.handlers)}"
            )
            print(_init_msg, file=sys.stderr)
            logging.getLogger("mediagrab").info(_init_msg)
            diag_handler.flush()
        except OSError as exc:
            # v97.88: DON'T silently swallow — print to stderr + try /tmp fallback
            print(
                f"DIAGNOSTIC_FILE_CREATE_RESULT success=false "
                f"path={_diag_absolute_path} "
                f"exception={type(exc).__name__}: {exc} "
                f"errno={exc.errno}",
                file=sys.stderr,
            )
            # v97.88: FALLBACK — create a diagnostic file in /tmp
            _fallback_path = f"/tmp/mediagrab_diagnostic_{_pid}.log"
            try:
                _fallback_handler = RotatingFileHandler(
                    _fallback_path, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
                )
                _fallback_handler.setLevel(logging.DEBUG)
                _fallback_handler.setFormatter(formatter)
                root.addHandler(_fallback_handler)
                _diag_log_path = _fallback_path
                print(
                    f"DIAGNOSTIC_FALLBACK_FILE_CREATED path={_fallback_path}",
                    file=sys.stderr,
                )
                _fb_msg = (
                    f"DIAGNOSTIC_LOGGING_INITIALIZED enabled=true "
                    f"log_path={_fallback_path} (FALLBACK) "
                    f"original_path_failed={_diag_absolute_path} "
                    f"pid={_pid}"
                )
                print(_fb_msg, file=sys.stderr)
                logging.getLogger("mediagrab").info(_fb_msg)
                _fallback_handler.flush()
            except OSError as exc2:
                print(
                    f"DIAGNOSTIC_FALLBACK_FAILED path={_fallback_path} "
                    f"exception={type(exc2).__name__}: {exc2}",
                    file=sys.stderr,
                )
    else:
        # v97.84: log that diagnostic logging is DISABLED
        print(
            "DIAGNOSTIC_LOGGING_INITIALIZED enabled=false "
            "(set DIAGNOSTIC_LOGGING=true in .env to enable)",
            file=sys.stderr,
        )
    root._diag_log_path = _diag_log_path  # type: ignore[attr-defined]

    # v97.92 RUNTIME-PROVEN: the diagnostic log (bot-diagnostic (4).log)
    # showed MASSIVE aiosqlite DEBUG volume — every SQL PRAGMA + execute +
    # fetchall + close produced 2 log lines, drowning the actual signal.
    # The diagnostic file handler is DEBUG-level, so third-party DEBUG
    # output flows straight to disk. Suppress all known noisy loggers to
    # WARNING so the diagnostic log stays usable when the bot is failing.
    for noisy in (
        "PIL", "httpx", "httpcore", "urllib3",
        # v97.92 NEW: aiosqlite logs every SQL op at DEBUG (2 lines per op).
        # The runtime log showed ~60% of all diagnostic lines were aiosqlite.
        "aiosqlite",
        # v97.92 NEW: apscheduler logs every job tick at INFO.
        "apscheduler", "apscheduler.scheduler", "apscheduler.executors",
        # v97.92 NEW: python-telegram-bot logs every Bot API call at DEBUG.
        "telegram", "telegram.ext", "telegram.ext.Application",
        # v97.92 NEW: asyncio selector debug (only emits at DEBUG, but be safe).
        "asyncio",
    ):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    for telethon_logger in (
        "telethon", "telethon.network", "telethon.network.mtprotosender",
        "telethon.extensions", "telethon.client", "telethon.client.updates",
        "telethon.client.users", "telethon.crypto", "telethon.session",
        "telethon.hints", "telethon.tl", "telethon.requestiter",
    ):
        logging.getLogger(telethon_logger).setLevel(logging.WARNING)
    # v97.91: suppress pytgcalls DEBUG spam — the _handle_mtproto_updates
    # callback logs EVERY received update at DEBUG level, producing 5795+
    # log lines per minute during active VC. This alone doesn't cause the
    # dispatch explosion, but it contributes to event-loop pressure when
    # the diagnostic file handler writes each line synchronously.
    logging.getLogger("pytgcalls").setLevel(logging.WARNING)

    _install_exception_hooks()

    root._mediagrab_configured = True  # type: ignore[attr-defined]
    return logging.getLogger("mediagrab")


def _install_exception_hooks() -> None:
    """V45 Fix #12: install sys.excepthook, threading.excepthook, asyncio handler."""
    import threading as _threading

    _orig_excepthook = sys.excepthook

    def _excepthook(exc_type, exc_value, exc_tb):
        logger.critical(
            "UNHANDLED_EXCEPTION type=%s value=%s",
            exc_type.__name__, str(exc_value)[:200],
            exc_info=(exc_type, exc_value, exc_tb),
        )
        _orig_excepthook(exc_type, exc_value, exc_tb)

    sys.excepthook = _excepthook

    _orig_threading_excepthook = _threading.excepthook

    def _threading_excepthook(args):
        logger.critical(
            "UNHANDLED_THREAD_EXCEPTION thread=%s type=%s value=%s",
            args.thread.name if args.thread else "?",
            args.exc_type.__name__ if args.exc_type else "?",
            str(args.exc_value)[:200] if args.exc_value else "?",
            exc_info=(args.exc_type, args.exc_value, args.exc_traceback),
        )
        _orig_threading_excepthook(args)

    _threading.excepthook = _threading_excepthook


def _asyncio_exception_handler(loop, context):
    """V45 Fix #12: asyncio loop exception handler.

    v97.57: suppress ConnectionResetError/ConnectionAbortedError which are
    known transient network errors during Telethon disconnect/reconnect.
    These originate from Telethon's internal Futures (not application Tasks)
    and cannot be prevented by the application. Logging them as CRITICAL
    creates false alarms.

    v97.92: also capture ``context.get("future")`` for richer diagnostics.
    asyncio sets ``task`` for Task exceptions and ``future`` for Future
    exceptions — Telethon's socket recv futures (during disconnect) only
    have ``future`` set, which is why the runtime log showed ``task=?``.

    v98.02 FIX-P (ISSUE 6 — asyncio exception handler improvement,
    RUNTIME-CORRELATED via bot-diagnostic (15).log):
      The v98.01 handler logged CRITICAL but did NOT retrieve the future's
      exception. asyncio emits "Future exception was never retrieved" when
      a future is GC'd with an un-retrieved exception. The handler at
      least retrieves it (calling future.exception()) so asyncio stops
      emitting the warning. The exception is already logged at CRITICAL
      here, so retrieving it doesn't change observability — it just
      prevents the duplicate "never retrieved" warning on GC. Per the
      user's directive #6 (additional bugs): the IncompleteReadError
      future:236160 at 11:40:06 was never retrieved, which means Telethon
      internal state was left in an inconsistent state. FIX-P retrieves
      the exception to mark it as handled.
    """
    exc = context.get("exception")
    task = context.get("task")
    future = context.get("future")
    msg = context.get("message", "Unhandled exception in asyncio")
    # v97.92: prefer task name, fall back to future's coro/thread name.
    task_name = "?"
    if task and hasattr(task, "get_name"):
        try:
            task_name = task.get_name()
        except Exception:  # noqa: BLE001
            task_name = "?"
    elif future is not None:
        # v97.92: extract identity from the future for Telethon socket futures.
        _coro = getattr(future, "get_coro", lambda: None)() if hasattr(future, "get_coro") else None
        if _coro is not None:
            task_name = getattr(_coro, "__qualname__", "?") or "?"
        else:
            task_name = f"future:{id(future) & 0xffffff:06x}"
    if exc:
        # v97.57: suppress known transient network errors during disconnect
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
            logger.debug(
                "ASYNCIO_NETWORK_ERROR (suppressed) task=%s type=%s value=%s",
                task_name, type(exc).__name__, str(exc)[:100],
            )
            # v98.02 FIX-P: still retrieve the future's exception to mark
            # it as handled (prevents "Future exception was never
            # retrieved" duplicate warning on GC).
            if future is not None and not future.cancelled():
                try:
                    future.exception()
                except Exception:  # noqa: BLE001
                    pass
            return
        logger.critical(
            "ASYNCIO_UNHANDLED_EXCEPTION task=%s msg=%s type=%s value=%s",
            task_name, msg[:100], type(exc).__name__, str(exc)[:200],
            exc_info=exc,
        )
        # v98.02 FIX-P: retrieve the future's exception to mark it as
        # handled. This prevents the duplicate "Future exception was never
        # retrieved" warning when the future is GC'd. The exception is
        # already logged at CRITICAL above, so this is observability-neutral
        # but state-correct (asyncio's internal _PendingClientsflag is
        # cleared).
        if future is not None and not future.cancelled():
            try:
                future.exception()
            except Exception:  # noqa: BLE001
                pass
    else:
        logger.error("ASYNCIO_UNHANDLED_ERROR task=%s msg=%s", task_name, msg[:200])


def _install_asyncio_handler() -> None:
    """V47 Fix: install the asyncio exception handler from inside a running loop.

    v97.59 §7: also install a DEDICATED bounded ThreadPoolExecutor for offloaded
    sync work (dashboard snapshots, heartbeat, history, DB writes). The default
    executor is unbounded — under load, dozens of to_thread calls can saturate
    it, causing event-loop starvation (the 11.29s lag the runtime log showed).
    A dedicated bounded executor (max 8 workers) caps concurrency + prevents
    one slow sync operation from starving others.
    """
    try:
        loop = asyncio.get_running_loop()
        loop.set_exception_handler(_asyncio_exception_handler)
        # v97.59 §7: dedicated bounded executor for sync offloads.
        from concurrent.futures import ThreadPoolExecutor
        _dedicated_executor = ThreadPoolExecutor(
            max_workers=8,
            thread_name_prefix="mg_offload",
        )
        loop.set_default_executor(_dedicated_executor)
        logger.info(
            "Asyncio handler + dedicated bounded executor installed "
            "(max_workers=8, prefix=mg_offload).",
        )
    except RuntimeError:
        logger.warning("Could not install asyncio exception handler — no running loop.")


class _ErrorDedupFilter(logging.Filter):
    """V42 Fix #20 + V43 Fix #9: deduplicate repeated identical errors."""

    _BYPASS = "_dedup_bypass"

    def __init__(self) -> None:
        super().__init__()
        self._seen: dict[str, dict] = {}
        self._window = 600.0
        self._time = time.monotonic

    def filter(self, record: logging.LogRecord) -> bool:
        if getattr(record, "_dedup_bypass", False):
            return True
        if record.levelno < logging.WARNING:
            return True
        try:
            msg_text = record.getMessage()[:200]
        except Exception:
            msg_text = f"<getMessage failed: {record.msg!r} args={record.args!r}>"
        key = f"{record.name}:{record.levelname}:{msg_text}"
        now = self._time()
        if len(self._seen) > 4096:
            for k in [k for k, v in self._seen.items() if now - v["first_ts"] > self._window]:
                del self._seen[k]
        entry = self._seen.get(key)
        if entry is None:
            self._seen[key] = {"count": 1, "first_ts": now, "last_logged": now}
            return True
        elapsed = now - entry["first_ts"]
        if elapsed < self._window:
            entry["count"] += 1
            return False
        else:
            count = entry["count"]
            if count > 1:
                summary = (f"Suppressed {count - 1} repeated "
                           f"{record.levelname} errors in {self._window/60:.0f} minutes")
                summary_record = logging.LogRecord(
                    name=record.name, level=record.levelno, pathname="",
                    lineno=0, msg=summary, args=None, exc_info=None,
                )
                summary_record._dedup_bypass = True  # type: ignore[attr-defined]
                logging.getLogger(record.name).handle(summary_record)
            self._seen[key] = {"count": 1, "first_ts": now, "last_logged": now}
            return True


def _sanitize_error(error: str) -> str:
    """V62 Fix #17: sanitize an error string — remove ALL secrets."""
    if not error:
        return ""
    s = str(error)[:500]
    s = re.sub(r'\b(sk-or-v1-[A-Za-z0-9_\-]{6,})\b', '[REDACTED_KEY]', s, flags=re.IGNORECASE)
    s = re.sub(r'\b(sk-[A-Za-z0-9_\-]{6,})\b', '[REDACTED_KEY]', s, flags=re.IGNORECASE)
    s = re.sub(r'\b(AIza[A-Za-z0-9_\-]{6,})\b', '[REDACTED_KEY]', s, flags=re.IGNORECASE)
    s = re.sub(r'\b(xai-[A-Za-z0-9_\-]{6,})\b', '[REDACTED_KEY]', s, flags=re.IGNORECASE)
    s = re.sub(r'(authorization|x-api-key|api[_-]?key|bearer|token)["\']?\s*[:=]\s*["\']?[A-Za-z0-9_\-\.]+', r'\1=[REDACTED]', s, flags=re.IGNORECASE)
    s = re.sub(r'([?&](?:api[_-]?key|key|token|access_token|secret)=[^&\s"\'<>]+)', '[REDACTED_QUERY]', s, flags=re.IGNORECASE)
    s = re.sub(r'(["\'](?:api[_-]?key|key|token|secret|authorization|password)["\']\s*:\s*["\'])([^"\']+)(["\'])', r'\1[REDACTED]\3', s, flags=re.IGNORECASE)
    s = re.sub(r'\b([A-Za-z0-9_\-]{40,})\b', '[REDACTED_TOKEN]', s)
    return s.strip()

# Injected config
_config = None


def _set_config(config):
    global _config
    _config = config

# ===========================================================================
# Utils — filenames
# ===========================================================================

_FORBIDDEN_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}
_MAX_NAME_LEN = 180


# ===========================================================================
# Phase 5 (P1 — Strong-reference task supervision registry)
# ===========================================================================
# Fire-and-forget asyncio tasks MUST be strongly referenced or Python's GC
# may collect them mid-execution (the task is created on the event loop but
# nothing holds a reference).  This registry keeps strong references until
# the task completes, logs unexpected exceptions, and discards the reference
# in a done-callback.  Singleton/app-owned tasks (MTProto health, VC reconcile,
# VC tour, Talkative cleanup, _app_bg_tasks) are NOT registered here — they
# have their own explicit owners.  Only true fire-and-forget tasks (download,
# analysis, toolbox, link-download workers) use this registry.
_active_tasks: set[asyncio.Task] = set()
# V56 Fix: module-level background-task registry (replaces app._bg_tasks).
# PTB Application is slot-based and does not allow custom attributes.
_app_bg_tasks: list[asyncio.Task] = []
_supervised_task_counts = {"created": 0, "failed": 0, "cancelled": 0}
# RELI-J-006: idempotency guard for _post_init — prevents double initialization
# when PTB calls it more than once (e.g. polling restart paths). Reset to False
# in _post_stop so a subsequent startup re-initializes cleanly.
_post_init_done: bool = False


def supervised_create_task(coro: Awaitable, *, name: str = "") -> asyncio.Task:
    """Create a fire-and-forget task with a strong reference + done callback.

    The task is added to ``_active_tasks`` immediately (strong ref) and
    removed in the done callback after exception logging.  CancelledError
    is handled normally (not logged as a failure).  Unexpected exceptions
    are logged with the task name so they are never silently lost
    ("Task exception was never retrieved" is eliminated for these tasks).

    Use this for TRUE fire-and-forget tasks only.  Tasks that are
    immediately awaited via gather, object-owned timer tasks, app-owned
    background tasks, and singleton service tasks should NOT use this —
    they have their own ownership.
    """
    task_name = name or getattr(coro, "__name__", "") or "supervised_task"
    # CODE-A-008: Python 3.8+ always supports the name= kwarg, so the dead
    # TypeError fallback has been removed.
    task = asyncio.create_task(coro, name=task_name)  # type: ignore[arg-type]
    _active_tasks.add(task)
    _supervised_task_counts["created"] += 1

    def _on_done(t: asyncio.Task) -> None:
        _active_tasks.discard(t)
        if t.cancelled():
            _supervised_task_counts["cancelled"] += 1
            return
        exc = t.exception()
        if exc is not None:
            _supervised_task_counts["failed"] += 1
            if not isinstance(exc, asyncio.CancelledError):
                logger.warning(
                    "SUPERVISED_TASK_FAILED name=%s exc=%s: %s",
                    task_name, type(exc).__name__, str(exc)[:200],
                )

    task.add_done_callback(_on_done)
    return task


def safe_filename(name: str, fallback: str = "file") -> str:
    """Return a filesystem-safe filename."""
    if not name:
        return fallback
    cleaned = _FORBIDDEN_CHARS.sub("_", name).rstrip(" .").lstrip(" ")
    if not cleaned:
        cleaned = fallback
    base, dot, ext = cleaned.rpartition(".")
    if not base:  # no extension / hidden file
        base, ext = cleaned, ""
        dot = ""
    if base.upper() in _RESERVED_NAMES:
        base = f"_{base}"
        cleaned = f"{base}{dot}{ext}" if dot else base
    if len(cleaned) > _MAX_NAME_LEN:
        if ext:
            base = base[: _MAX_NAME_LEN - len(ext) - 1]
            cleaned = f"{base}.{ext}"
        else:
            cleaned = cleaned[:_MAX_NAME_LEN]
    return cleaned


def unique_path(directory, filename: str):
    """Append (1), (2)… before the extension if the file already exists."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / filename
    if not target.exists():
        return target
    stem, dot, ext = filename.rpartition(".")
    suffix = f".{ext}" if dot else ""
    counter = 1
    # CODE-A-016: bound the loop to prevent an infinite spin if (very
    # improbably) a million candidates all already exist.
    while counter < 1_000_000:
        candidate = directory / f"{stem} ({counter}){suffix}"
        if not candidate.exists():
            return candidate
        counter += 1
    raise OSError(
        f"unique_path: could not find a free name for {filename!r} "
        f"in {directory} after 1,000,000 attempts"
    )


_EXTENSION_CATEGORIES: dict[str, str] = {}

_VIDEO_EXTS = {"mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "m4v", "mpg", "mpeg", "ts", "3gp"}
_AUDIO_EXTS = {"mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "wma"}
_ARCHIVE_EXTS = {"zip", "rar", "7z", "tar", "gz", "bz2", "xz"}
_DOC_EXTS = {"pdf", "epub", "txt", "doc", "docx", "rtf", "mobi", "azw3"}
_APP_EXTS = {"apk", "xapk", "apks", "ipa", "deb", "rpm", "dmg", "exe", "msi"}
_IMAGE_EXTS = {"jpg", "jpeg", "png", "webp", "bmp", "gif", "tiff", "heic"}
_ISO_EXTS = {"iso", "img", "bin", "vhd", "vmdk"}
_SUBTITLE_EXTS = {"srt", "ass", "ssa", "vtt", "sub"}

for _ext in _VIDEO_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "video"
for _ext in _AUDIO_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "audio"
for _ext in _ARCHIVE_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "archive"
for _ext in _DOC_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "document"
for _ext in _APP_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "app"
for _ext in _IMAGE_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "image"
for _ext in _ISO_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "iso"
for _ext in _SUBTITLE_EXTS:
    _EXTENSION_CATEGORIES[_ext] = "subtitle"


def extension_category(filename: str | None) -> str:
    """Classify a filename by its extension. Falls back to 'document'."""
    if not filename:
        return "document"
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return _EXTENSION_CATEGORIES.get(ext, "document")


def telegram_media_type(message) -> str | None:
    """Map a python-telegram-bot Message to a media-type string."""
    if message is None:
        return None
    if message.video:
        return "video"
    if message.animation:  # GIF
        return "gif"
    if message.sticker:
        return "sticker"
    if message.video_note:
        return "video_note"
    if message.voice:
        return "voice"
    if message.audio:
        return "audio"
    if message.photo:
        return "photo"
    if message.document:
        return "document"
    return None


SUPPORTED_FORMATS_DESC: tuple[tuple[str, Iterable[str]], ...] = (
    ("Videos", _VIDEO_EXTS),
    ("Audio", _AUDIO_EXTS),
    ("Archives", _ARCHIVE_EXTS),
    ("Documents", _DOC_EXTS),
    ("Apps", _APP_EXTS),
    ("Images", _IMAGE_EXTS),
    ("Disc Images", _ISO_EXTS),
    ("Subtitles", _SUBTITLE_EXTS),
    ("Telegram native", {"photo", "voice", "video_note", "sticker", "animation"}),
)


# ===========================================================================
# Utils — cleanup
# ===========================================================================


def _safe_remove(path: Path) -> None:
    try:
        # CODE-A-003: handle symlinks FIRST — is_file()/is_dir() follow the
        # link target, which can cause us to delete the wrong thing (or fail
        # to delete the link itself). Unlink the link directly.
        if path.is_symlink():
            path.unlink(missing_ok=True)
        elif path.is_file():
            path.unlink(missing_ok=True)
        elif path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
    except OSError as exc:
        logger.warning("Could not remove %s: %s", path, exc)


async def remove_path(path) -> None:
    """Asynchronously delete a file or directory tree."""
    if path is None:
        return
    p = Path(path)
    if not p.exists():
        return
    await asyncio.to_thread(_safe_remove, p)


async def cleanup_paths(*paths) -> None:
    """Convenience wrapper to delete many paths concurrently."""
    await asyncio.gather(*(_remove_safe(p) for p in paths), return_exceptions=True)


async def _remove_safe(path) -> None:
    try:
        await remove_path(path)
    except Exception as exc:  # noqa: BLE001
        logger.debug("cleanup ignored %s: %s", path, exc)


async def cleanup_directory(directory, max_age_seconds: int) -> int:
    """Delete files inside *directory* older than *max_age_seconds*."""
    directory = Path(directory)
    if not directory.exists():
        return 0
    now = time.time()

    # PERF-A-001: offload the synchronous iterdir()+stat() scan to a worker
    # thread so the event loop is not blocked while walking large download /
    # frames directories. Removals are then awaited concurrently.
    def _scan() -> list:
        stale: list = []
        for entry in directory.iterdir():
            try:
                mtime = entry.stat().st_mtime
            except OSError:
                continue
            if now - mtime > max_age_seconds:
                stale.append(entry)
        return stale

    stale = await asyncio.to_thread(_scan)
    if stale:
        await asyncio.gather(
            *(remove_path(p) for p in stale), return_exceptions=True
        )
    return len(stale)


# v99.11 P1 — the dedicated-connection WAL checkpoint.
_WAL_CHECKPOINT_RETRIES = 3
_WAL_CHECKPOINT_RETRY_SLEEP = 30.0  # seconds (thread-side; off the loop)
_WAL_CHECKPOINT_CONN_TIMEOUT = 10.0  # the dedicated connection's busy timeout


def _wal_checkpoint_blocking(db_path: str) -> tuple[int, int, int]:
    """Blocking core: TRUNCATE checkpoint on a DEDICATED sqlite3
    connection (runs inside asyncio.to_thread — never the event loop).

    A cross-connection conflict NEVER raises here: SQLite returns the
    ``(busy, log_frames, checkpointed)`` row instead (busy=1 → other
    connections still hold the WAL; retry later).
    """
    import sqlite3 as _sqlite3
    conn = _sqlite3.connect(db_path, timeout=_WAL_CHECKPOINT_CONN_TIMEOUT)
    try:
        cur = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        row = cur.fetchone()
        cur.close()
        return (int(row[0]), int(row[1]), int(row[2])) if row else (0, 0, 0)
    finally:
        conn.close()


async def run_wal_checkpoint() -> tuple[int, int, int]:
    """v99.11 P1: the periodic WAL checkpoint, self-lock-proof.

    Runs ``PRAGMA wal_checkpoint(TRUNCATE)`` on a DEDICATED short-lived
    connection (NOT the shared aiosqlite connection — see the fix block
    in periodic_cleanup), with bounded retry/backoff when the checkpoint
    reports busy, and INFO/WARNING observability of every outcome:

      * success (busy=0)  → WAL_CHECKPOINT_OK busy=0 log=N ckpt=N
      * busy persisting   → WAL_CHECKPOINT_BUSY (after retries)
      * exception         → raises to the caller (logged WARNING there)
    """
    from .db_layer import _effective_config
    db_path = str(_effective_config().db_path)
    last: tuple[int, int, int] = (0, 0, 0)
    for attempt in range(1, _WAL_CHECKPOINT_RETRIES + 1):
        last = await asyncio.to_thread(_wal_checkpoint_blocking, db_path)
        busy, log_frames, checkpointed = last
        if not busy:
            logger.info(
                "WAL_CHECKPOINT_OK busy=%d log_frames=%d checkpointed=%d "
                "attempt=%d (v99.11 dedicated-connection checkpoint)",
                busy, log_frames, checkpointed, attempt,
            )
            return last
        if attempt < _WAL_CHECKPOINT_RETRIES:
            await asyncio.sleep(0)  # yield; sleep happens in the thread
            await asyncio.to_thread(time.sleep, _WAL_CHECKPOINT_RETRY_SLEEP)
    logger.warning(
        "WAL_CHECKPOINT_BUSY busy=1 log_frames=%d checkpointed=%d "
        "retries=%d — other connections still hold the WAL; next cleanup "
        "cycle retries (v99.11; NOT an error — bounded, observable)",
        last[1], last[2], _WAL_CHECKPOINT_RETRIES,
    )
    return last


async def periodic_cleanup(downloads_dir, frames_dir, interval: int = 600,
                           max_age: int = 3600) -> None:
    """Background loop that periodically purges stale temp files.

    Phase 6 (P1 — state cache pruning): also prunes stale IDLE user state
    entries on each cycle to bound memory growth from long-running bots
    with many transient users.  Active workflow states are NEVER pruned.
    """
    logger.info("Periodic cleanup task started (interval=%ss, max_age=%ss)",
                interval, max_age)
    while True:
        try:
            await asyncio.sleep(interval)
            d = await cleanup_directory(downloads_dir, max_age)
            f = await cleanup_directory(frames_dir, max_age)
            if d or f:
                logger.info("Cleanup removed %d downloads, %d frames", d, f)
            # Phase 6 — prune stale IDLE user state entries.
            try:
                from .states import prune_stale_user_states
                counts = prune_stale_user_states()
                if counts["activity"]:
                    logger.debug(
                        "State cache pruned: states=%d tools=%d "
                        "downloads=%d activity=%d",
                        counts["states"], counts["tools"],
                        counts["downloads"], counts["activity"],
                    )
            except Exception as exc:  # noqa: BLE001
                logger.debug("State cache prune error: %s", exc)
            # v97 CHAOS-3 FIX: periodic WAL checkpoint(TRUNCATE) to bound WAL
            # file growth. Without this, the WAL file grows monotonically and
            # never shrinks below its high-water mark, degrading read
            # performance over weeks of operation.
            #
            # v99.11 P1 (THE SQLITE_SELF-LOCK FIX): the checkpoint previously
            # ran ``PRAGMA wal_checkpoint(TRUNCATE)`` ON THE SHARED aiosqlite
            # connection — while other coroutines held open read cursors /
            # implicit write transactions on it.  That is SQLITE_LOCKED
            # ("database table is locked"), a SELF-lock: the busy handler
            # CANNOT resolve it (empirically verified: same-connection
            # checkpoint with an open cursor/txn raises immediately
            # regardless of busy_timeout; mode PASSIVE/FULL/RESTART
            # identical) — production evidence: "WAL checkpoint error:
            # database table is locked" repeatedly through the
            # 2026-09-21 reconcile-active logs, swallowed at DEBUG.
            # The fix: the checkpoint now runs on a DEDICATED short-lived
            # sqlite3 connection (via asyncio.to_thread — never the event
            # loop), where cross-connection contention degrades to a
            # (busy, log, ckpt) result row instead of an exception, with
            # bounded retry/backoff and INFO-level observability.
            try:
                await run_wal_checkpoint()
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "WAL_CHECKPOINT_ERROR exc=%s: %s (v99.11 dedicated-"
                    "connection checkpoint; next cycle retries)",
                    type(exc).__name__, str(exc)[:160],
                )
            # v97.30: prune the media cache (LRU eviction to 500 entries).
            # The function was defined in db_layer.py but NEVER CALLED —
            # the cache could grow unbounded over months of operation.
            try:
                from .db_layer import media_cache_cleanup
                removed = await media_cache_cleanup(max_entries=500)
                if removed:
                    logger.info("Media cache LRU pruned: %d entries removed", removed)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Media cache cleanup error: %s", exc)
        except asyncio.CancelledError:
            logger.info("Periodic cleanup task cancelled")
            raise
        except Exception as exc:  # noqa: BLE001
            logger.exception("Cleanup loop error: %s", exc)


def human_size(num_bytes: int | float) -> str:
    """Human-readable file size."""
    if num_bytes is None:
        return "—"
    value = float(num_bytes)
    # CODE-A-015: negative sizes are nonsensical — return a sentinel.
    if value < 0:
        return "—"
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if value < 1024 or unit == "PB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{value:.1f} PB"


# ===========================================================================
# Utils — safe_send (Task ID 6)
# ===========================================================================
# Safe message-sending utilities.
#
# Solves the recurring ``Can't parse entities`` BadRequest errors caused by
# user-generated text (URLs, usernames, captions, filenames, chat titles)
# containing Markdown special characters that Telegram interprets as formatting
# markup.
#
# Public API:
#   * md_escape         — escape Markdown special chars in dynamic text.
#   * html_escape       — escape HTML entities.
#   * safe_send_message / safe_edit_message_text / safe_reply_text /
#     safe_send_document — try Markdown, fall back to plain text on parse error.
#
# Each ``safe_*`` wrapper first tries with ``parse_mode="Markdown"``. If
# Telegram rejects the message with a ``BadRequest`` mentioning entities, it
# automatically retries with ``parse_mode=None`` (plain text) so the user
# always sees something. Transient network / rate-limit errors are also
# swallowed gracefully so a single bad update never crashes an update handler.
# ---------------------------------------------------------------------------

# Markdown v1 special characters (parse_mode="Markdown").
# Text escaping — extracted to mediagrab_bot/text_utils.py
from mediagrab_bot.text_utils import md_escape, html_escape, _MD_V1_SPECIALS



# Phase 23 (Task ID 14) — secret-redaction patterns.  Applied to any text
# before it is logged to the error viewer, dashboard diagnostics, or
# exported logs.  Matches bot tokens (NNNNNN:AAA...), long hex/base64
# session strings, and common API-key prefixes.
_SECRET_PATTERNS = [
    # Bot token: 123456789:ABCdef... (digits colon 35+ alphanumeric/_-)
    re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b"),
    # Telegram API hash (32 hex chars)
    re.compile(r"\b[0-9a-fA-F]{32}\b"),
    # Gemini API key (AIza + 35 chars)
    re.compile(r"AIza[0-9A-Za-z_-]{30,}"),
    # Groq API key (gsk_ + 50 chars)
    re.compile(r"gsk_[A-Za-z0-9]{40,}"),
    # OpenRouter API key (sk-or- + chars)
    re.compile(r"sk-or-[A-Za-z0-9-_]{30,}"),
    # Generic sk- keys (OpenAI-style)
    re.compile(r"sk-[A-Za-z0-9]{40,}"),
    # Long base64-ish session strings (80+ chars, no spaces)
    re.compile(r"\b[A-Za-z0-9+/=_-]{80,}\b"),
]


def _redact_secrets(text: Any) -> str:
    """Redact known secret patterns from *text* before logging/display.

    Replaces matches with ``[REDACTED:<type>]`` so diagnostics remain
    useful without leaking credentials.  Used by the error viewer,
    dashboard, and export-logs handlers.
    """
    if text is None:
        return ""
    s = str(text)
    for pat in _SECRET_PATTERNS:
        s = pat.sub("[REDACTED]", s)
    return s


def _is_parse_error(exc: Exception) -> bool:
    """True if *exc* is a Markdown/HTML entity-parsing BadRequest."""
    if not isinstance(exc, BadRequest):
        return False
    msg = str(exc).lower()
    return "can't parse entities" in msg or "entity" in msg


async def safe_send_message(
    bot, chat_id, text, *,
    parse_mode: str | None = "Markdown",
    reply_markup=None,
    reply_to_message_id: int | None = None,
    disable_notification: bool = False,
    **kwargs: Any,
):
    """Send a message, falling back to plain text if Markdown parsing fails.

    Also swallows network/rate-limit errors gracefully (logs them) so a
    transient Telegram hiccup never crashes an update handler.
    """
    try:
        return await bot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
            disable_notification=disable_notification,
            **kwargs,
        )
    except BadRequest as exc:
        if _is_parse_error(exc):
            logger.warning(
                "Markdown parse failed (%s); retrying as plain text. "
                "Text preview: %.80r", exc, _redact_secrets(text),
            )
            try:
                return await bot.send_message(
                    chat_id=chat_id,
                    text=text,
                    parse_mode=None,
                    reply_markup=reply_markup,
                    reply_to_message_id=reply_to_message_id,
                    disable_notification=disable_notification,
                    **kwargs,
                )
            except Exception as exc2:  # noqa: BLE001
                logger.error("safe_send_message plain-text fallback failed: %s", exc2)
                return None
        logger.warning("safe_send_message BadRequest: %s", exc)
        return None
    except RetryAfter as exc:
        logger.info("Rate limited on send_message: %ss", exc.retry_after)
        # Phase 11 — respect the server-provided wait, capped at 30s.
        # ASYNC-A-002: a hostile / huge retry_after would otherwise stall a
        # handler indefinitely; 30s is a safe ceiling that still retries.
        await asyncio.sleep(min(exc.retry_after + 1, 30))
        try:
            return await bot.send_message(
                chat_id=chat_id, text=text, parse_mode=parse_mode,
                reply_markup=reply_markup, reply_to_message_id=reply_to_message_id,
                disable_notification=disable_notification, **kwargs,
            )
        except Exception as exc2:  # noqa: BLE001
            logger.error("safe_send_message retry failed: %s", exc2)
            return None
    except (NetworkError, TimedOut) as exc:
        logger.warning("safe_send_message network error: %s", exc)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.error("safe_send_message unexpected error: %s", exc, exc_info=True)
        return None


# ===========================================================================
# V40 Fix #1 — Central UI ownership registry (Go Back / menu rollback guard)
# ===========================================================================
# Every background-refreshed Telegram message (Live VC Dashboard, Join-All
# progress, and any future live view) is assigned a monotonically-increasing
# ``view_token`` keyed by (chat_id, message_id).  The background refresher
# captures the token at start and re-checks it before EVERY edit.  Any
# user-initiated navigation that edits the same message bumps the token via
# ``_ui_invalidate`` (called from ``safe_edit_message_text`` and
# ``_menu_edit``), so a stale refresher immediately loses ownership and
# stops — it can never overwrite a newer view.
#
# Invariant: only explicit user navigation may change the on-screen view of
# a live-refreshed message.  A background refresher that lost ownership MUST
# stop without editing.
_ui_owners: dict[tuple[int, int], int] = {}


def _ui_claim(chat_id: int, message_id: int) -> int:
    """Assign (bump) the view-token for a message and return the new token.

    Used by live-view refreshers when they start: they capture the returned
    token and later verify it via :func:`_ui_check` before each edit.
    """
    key = (int(chat_id), int(message_id))
    new_token = _ui_owners.get(key, 0) + 1
    _ui_owners[key] = new_token
    # MEM-A-002: bound the registry so long-running bots don't leak memory.
    if len(_ui_owners) > 4096:
        _ui_owners_sweep()
    return new_token


def _ui_invalidate(chat_id: int, message_id: int) -> int:
    """Bump the view-token for a message so any running refresher loses ownership.

    Called by every user-initiated navigation edit (``safe_edit_message_text``,
    ``_menu_edit``).  Returns the new token (mostly for logging/tests).
    """
    return _ui_claim(chat_id, message_id)


def _ui_check(chat_id: int, message_id: int, token: int) -> bool:
    """True iff ``token`` is still the current owner of the message."""
    key = (int(chat_id), int(message_id))
    return _ui_owners.get(key, 0) == int(token)


def _ui_release(chat_id: int, message_id: int) -> None:
    """Drop ownership tracking for a message (e.g. on close/delete)."""
    _ui_owners.pop((int(chat_id), int(message_id)), None)


def _ui_owners_sweep(max_entries: int = 4096) -> None:
    """MEM-A-002: bound _ui_owners by dropping oldest entries when over cap.

    Python 3.7+ dicts preserve insertion order; re-claiming an existing key
    moves it to the end, so the front of the dict holds the least-recently-
    touched entries.  Called from ``_ui_claim`` on every new claim.
    """
    while len(_ui_owners) > max_entries:
        try:
            _ui_owners.pop(next(iter(_ui_owners)))
        except (StopIteration, RuntimeError):
            break


async def safe_edit_message_text(
    bot, chat_id, message_id, text, *,
    parse_mode: str | None = "Markdown",
    reply_markup=None,
    invalidate_ui: bool = True,
    **kwargs: Any,
):
    """Edit a message, falling back to plain text if Markdown parsing fails.

    Also tolerates ``MessageNotModified`` and ``Message to edit not found``
    gracefully.

    V40 Fix #1: bumps the central UI view-token before editing so any stale
    background refresher for this message stops itself before overwriting
    the new view.

    V59 Fix #1: add ``invalidate_ui`` parameter. Background refresh tasks
    must pass ``invalidate_ui=False`` to avoid invalidating their own
    ownership token. User-driven navigation uses the default ``True``.
    """
    if invalidate_ui:
        try:
            _ui_invalidate(chat_id, message_id)
        except Exception:  # noqa: BLE001
            pass
    try:
        return await bot.edit_message_text(
            chat_id=chat_id, message_id=message_id, text=text,
            parse_mode=parse_mode, reply_markup=reply_markup, **kwargs,
        )
    except BadRequest as exc:
        msg = str(exc).lower()
        if _is_parse_error(exc):
            logger.warning(
                "Markdown parse failed on edit (%s); retrying as plain text.", exc
            )
            try:
                return await bot.edit_message_text(
                    chat_id=chat_id, message_id=message_id, text=text,
                    parse_mode=None, reply_markup=reply_markup, **kwargs,
                )
            except BadRequest as exc2:
                msg2 = str(exc2).lower()
                if "not modified" in msg2 or "message is not modified" in msg2:
                    # V48 Fix: "Message is not modified" is a harmless no-op.
                    logger.debug("safe_edit plain-text fallback: not modified (ignored).")
                    return None
                if "message to edit not found" in msg2:
                    logger.debug("safe_edit plain-text fallback: message gone (ignored).")
                    return None
                logger.warning("safe_edit plain-text fallback BadRequest: %s", exc2)
                return None
            except Exception as exc2:  # noqa: BLE001
                # V48 Fix: check for "not modified" before logging as ERROR.
                msg2 = str(exc2).lower()
                if "not modified" in msg2 or "message is not modified" in msg2:
                    logger.debug("safe_edit plain-text fallback: not modified (ignored).")
                    return None
                logger.error("safe_edit plain-text fallback failed: %s", exc2)
                return None
        if "not modified" in msg:
            logger.debug("edit_message_text: not modified (ignored).")
            return None
        if "message to edit not found" in msg or "message is not modified" in msg:
            logger.debug("edit_message_text: message gone (ignored).")
            return None
        logger.warning("safe_edit_message_text BadRequest: %s", exc)
        return None
    except RetryAfter as exc:
        logger.info("Rate limited on edit_message_text: %ss", exc.retry_after)
        await asyncio.sleep(min(exc.retry_after + 1, 30))
        try:
            return await bot.edit_message_text(
                chat_id=chat_id, message_id=message_id, text=text,
                parse_mode=parse_mode, reply_markup=reply_markup, **kwargs,
            )
        except Exception as exc2:  # noqa: BLE001
            logger.error("safe_edit_message_text retry failed: %s", exc2)
            return None
    except (NetworkError, TimedOut) as exc:
        logger.warning("safe_edit_message_text network error: %s", exc)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.error("safe_edit_message_text unexpected error: %s", exc, exc_info=True)
        return None


async def safe_reply_text(
    message, text, *,
    parse_mode: str | None = "Markdown",
    reply_markup=None,
    quote: bool = False,
    **kwargs: Any,
):
    """Reply to a message, falling back to plain text if Markdown fails."""
    try:
        return await message.reply_text(
            text=text, parse_mode=parse_mode,
            reply_markup=reply_markup, quote=quote, **kwargs,
        )
    except BadRequest as exc:
        if _is_parse_error(exc):
            logger.warning(
                "Markdown parse failed on reply (%s); retrying as plain text.", exc
            )
            try:
                return await message.reply_text(
                    text=text, parse_mode=None,
                    reply_markup=reply_markup, quote=quote, **kwargs,
                )
            except Exception as exc2:  # noqa: BLE001
                logger.error("safe_reply_text plain-text fallback failed: %s", exc2)
                return None
        logger.warning("safe_reply_text BadRequest: %s", exc)
        return None
    except RetryAfter as exc:
        logger.info("Rate limited on reply_text: %ss", exc.retry_after)
        # Phase 11 — respect the server-provided wait, capped at 30s (ASYNC-A-002).
        await asyncio.sleep(min(exc.retry_after + 1, 30))
        try:
            return await message.reply_text(
                text=text, parse_mode=parse_mode,
                reply_markup=reply_markup, quote=quote, **kwargs,
            )
        except Exception as exc2:  # noqa: BLE001
            logger.error("safe_reply_text retry failed: %s", exc2)
            return None
    except (NetworkError, TimedOut) as exc:
        logger.warning("safe_reply_text network error: %s", exc)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.error("safe_reply_text unexpected error: %s", exc, exc_info=True)
        return None


async def safe_send_document(
    bot, chat_id, document, *,
    filename: str | None = None,
    caption: str | None = None,
    parse_mode: str | None = "Markdown",
    reply_markup=None,
    **kwargs: Any,
):
    """Send a document, falling back to plain-text caption if Markdown fails."""
    try:
        return await bot.send_document(
            chat_id=chat_id, document=document, filename=filename,
            caption=caption, parse_mode=parse_mode,
            reply_markup=reply_markup, **kwargs,
        )
    except BadRequest as exc:
        if _is_parse_error(exc):
            logger.warning(
                "Markdown parse failed on document caption (%s); "
                "retrying as plain text.", exc
            )
            try:
                return await bot.send_document(
                    chat_id=chat_id, document=document, filename=filename,
                    caption=caption, parse_mode=None,
                    reply_markup=reply_markup, **kwargs,
                )
            except Exception as exc2:  # noqa: BLE001
                logger.error("safe_send_document fallback failed: %s", exc2)
                return None
        logger.warning("safe_send_document BadRequest: %s", exc)
        return None
    except RetryAfter as exc:
        logger.info("Rate limited on send_document: %ss", exc.retry_after)
        await asyncio.sleep(min(exc.retry_after + 1, 30))
        try:
            return await bot.send_document(
                chat_id=chat_id, document=document, filename=filename,
                caption=caption, parse_mode=parse_mode,
                reply_markup=reply_markup, **kwargs,
            )
        except Exception as exc2:  # noqa: BLE001
            logger.error("safe_send_document retry failed: %s", exc2)
            return None
    except (NetworkError, TimedOut) as exc:
        logger.warning("safe_send_document network error: %s", exc)
        return None
    except Exception as exc:  # noqa: BLE001
        logger.error("safe_send_document unexpected error: %s", exc, exc_info=True)
        return None


# ===========================================================================
# Utils — bot_registry (Task ID 10)
# ===========================================================================
# Stores a reference to the running ``telegram.Bot`` instance so that
# background services (like the MTProto self-destruct capture handler) can
# send messages without needing access to the PTB ``Application`` object
# (which has no public ``get_application()`` singleton accessor).
#
# Usage:
#   * In ``_post_init``:  ``register_bot(app.bot)``
#   * In background code: ``bot = get_bot()`` (may be None until registered)


_bot_instance: Optional[Any] = None


def register_bot(bot) -> None:
    """Store a reference to the running Bot instance."""
    global _bot_instance
    _bot_instance = bot


def get_bot():
    """Return the running Bot instance, or None if not registered yet."""
    return _bot_instance


def is_available() -> bool:
    """True if a Bot instance has been registered."""
    return _bot_instance is not None


# --- Bot identity (Task ID 16 — Talkative trigger detection) ----------------
# Populated in ``_post_init`` after ``register_bot``. Used by
# ``talkative_detect_trigger`` to recognise replies to the bot's own messages,
# @mentions of the bot, and uses of the bot's display name.
# These are the BOT API bot's identity — used for Bot API trigger detection.
_bot_id: Optional[int] = None
_bot_username: Optional[str] = None
_bot_display_name: str = ""

# --- Telethon Userbot Identity (Talkative V2) ---
# Cached at registration time. Used by _talkative_userbot_detect_trigger for
# mention/name/reply detection. NEVER reuse Bot API bot identity for the
# userbot — the userbot has its own ID/username/display name.
_userbot_id: Optional[int] = None
_userbot_username: Optional[str] = None
_userbot_display_name: str = ""


async def _cache_userbot_identity() -> None:
    """Cache the Telethon userbot's own ID, username, and display name.

    Called once at handler registration time. Used for:
    - Self-message filtering (skip messages from the userbot itself)
    - Reply-to-userbot detection (check if replied-to message was from userbot)
    - Mention detection (check if @userbot_username is in text)
    - Name detection (check if userbot display name is in text)
    """
    global _userbot_id, _userbot_username, _userbot_display_name
    from .mtproto import mtproto_get_client
    client = mtproto_get_client()
    if client is None:
        return
    try:
        # v97 CRITICAL FIX: wrap get_me() in a timeout. Previously this
        # had no timeout — if the Telethon connection was flaky after
        # mtproto_start() succeeded, this call could hang indefinitely,
        # blocking _post_init and preventing run_polling() from starting.
        # This was a root cause of "bot hangs at startup" when
        # TALKATIVE_ENABLED=true and MTProto is configured.
        me = await asyncio.wait_for(client.get_me(), timeout=10)
        _userbot_id = getattr(me, "id", None)
        _userbot_username = getattr(me, "username", None)
        first = getattr(me, "first_name", "") or ""
        last = getattr(me, "last_name", "") or ""
        _userbot_display_name = (f"{first} {last}").strip() or _userbot_username or ""
        logger.info("TALKATIVE_USERBOT_IDENTITY cached id=%s username=@%s name=%s",
                    _userbot_id, _userbot_username, _userbot_display_name[:40])
    except Exception as exc:  # noqa: BLE001
        logger.warning("TALKATIVE_USERBOT_IDENTITY cache failed: %s", exc)
