"""MediaGrab AI Bot — production-grade modular Telegram bot."""

from __future__ import annotations

# v98.12 §21 (DEPLOYMENT IDENTITY FIX): the version string was frozen at
# v98.09 through v98.10/v98.11 (patch-release precedent for failure-set
# byte-comparability) while the deployed source evolved — (6).log proved
# the runtime reported version=v98.09 with mtproto_sha256 of the v98.11
# tree (a MIXED identity that made log forensics ambiguous). From v98.12
# the version string tracks the artifact; identity is additionally
# protected by the build stamp (build_stamp.json, verified at startup).
__bot_version__ = "v99.11.1"
# v99.07 FIX-32: __version__ previously drifted as a separate literal
# ("2.1.1") while build_stamp.json verified only __bot_version__ — two
# version claims, one of them stale. __version__ is now DERIVED from the
# single source (__bot_version__).
__version__ = __bot_version__

# Real modules
from .config import config, Config
from .bootstrap import (
    RuntimeController,
    RuntimeControllerV96,
    TaskSupervisor,
    supervised_create_task,
    main,
    build_application,
)
# v97: Join-All resilient worker subsystem.
from .join_all_worker import (
    CircuitBreaker,
    CircuitBreakerState,
    CancellationToken,
    CheckpointManager,
    JoinAllWorkerState,
    RetryPolicy,
    WorkerStateMachine,
)

__all__ = [
    "__version__",
    "__bot_version__",
    "config",
    "Config",
    "RuntimeController",
    "RuntimeControllerV96",
    "TaskSupervisor",
    "supervised_create_task",
    "main",
    "build_application",
    # v97
    "CircuitBreaker",
    "CircuitBreakerState",
    "CancellationToken",
    "CheckpointManager",
    "JoinAllWorkerState",
    "RetryPolicy",
    "WorkerStateMachine",
]
