#!/usr/bin/env python3
"""v99.04 — FULL VC SYSTEM MISSION regression suite (RC-14 .. RC-18).

Every test in this file targets a gap that was RUNTIME-PROVEN by the
2026-09-11 production diagnostic log "bot-diagnostic (1).log"
(5,549 lines, 02:45:10 → 07:16:48, FOUR runs: two v99.02 + two v99.03):

  RC-14 The operator's deployment channel transfers .py FILES ONLY —
        FOUR consecutive partial deployments (v99.01, v99.02 ×2, v99.03
        ×2 restarts) all shipped without assets/vc_silence_600s.opus,
        and NO deployment ZIP ever existed on the box
        (DEPLOY_SELF_HEAL_FAILED reason=no_deployment_zip_found at BOTH
        v99.03 boots), so the v99.03 RC-9 ZIP-only heal could never
        fire. v99.04 ships the stamped asset ALSO as base64 text inside
        asset_embedded.py; the heal tries ZIP first, then the embed; the
        sha256-vs-stamp verification is PRESERVED (identity checking is
        NOT weakened — a corrupted embed is refused and RC-8 applies).
  RC-15 Production printed ACCOUNT_SESSION_HEALTH expected_cluster=0
        while USERBOT_CLUSTER loaded 1 accounts and the SAME line showed
        cluster_account_id=acc_919006065076. Root cause (reproduced
        offline exactly): _accounts' __-prefixed special keys hold
        STRINGS ("__primary__": "acc_…") → _acc.get() raised
        AttributeError mid-loop → swallowed AFTER the real account was
        added to cluster_paths → expected_cluster never assigned. The
        v99.03 _FakeCluster tests had no __ key, so they never caught
        it. Fix: skip __/non-dict entries; expected_cluster counts REAL
        accounts; cluster_accounts= added to the line; the `}}`
        cosmetic fixed.
  RC-16 /cluster add on a phone whose session has a live authorized
        owner returned "already_connected:<user>" WITHOUT registering
        (production: tried TWICE for +918335829278, accounts.json
        stayed at 1, the operator then DELETED the healthy session).
        v99.04 RC-16: register the account reusing the live client (the same
        registry-reuse state the system itself creates at startup),
        return "registered:<aid>"; already-registered keeps the
        already_connected reply (now informational in the UI).
  RC-17 The boot identity was decided ONCE; the only repair path was a
        restart (the operator restarted twice in 2 minutes). v99.04: a
        recovery loop re-verifies every 120s while mismatched, re-runs
        the RC-9/RC-14 heal, and publishes the verified state the
        moment the tree matches the stamp — joins resume WITHOUT a
        restart (the RC-8 gate re-reads deploy_health per join).
  RC-18 The ACCOUNT_SESSION_HEALTH emit cosmetics (single brace,
        cluster_accounts field) — folded into the RC-15 tests.

Method: behavioural tests against the REAL modules (the heal/recovery
functions exec-extracted from bootstrap.py so the SHIPPED bytes run;
mtproto through the v99.02 real-module fake stack), source contracts
where behaviour is not offline-reproducible, and EFFICACY
FAIL-ON-REVERT tests for RC-14/RC-15/RC-16 (the fix surgically removed
→ the guarded contract observably breaks).

HONEST SCOPE (mission §13): these tests prove the DEPLOYMENT/identity/
session-health/join-admission layers offline. The live Telegram VC
transport remains NOT-PROVEN here — see the release verification
matrix in PATCH_MANIFEST_v99.04.txt.
"""
from __future__ import annotations

import ast
import asyncio
import base64
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import textwrap
import types
import unittest
import zipfile
from pathlib import Path

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
_MT_TEXT = (_SRC / "mtproto.py").read_text(encoding="utf-8")
_HANDLERS_TEXT = (_SRC / "handlers.py").read_text(encoding="utf-8")
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_INIT_TEXT = (_SRC / "__init__.py").read_text(encoding="utf-8")
_STAMP = json.loads((_SRC / "build_stamp.json").read_text(encoding="utf-8"))
_SERVICE_TEXT = (Path(__file__).resolve().parent.parent /
                 "deploy" / "mediagrab.service").read_text(encoding="utf-8")
_REAL_ASSET = (_SRC / "assets" / "vc_silence_600s.opus").read_bytes()
_REAL_ASSET_SHA16 = hashlib.sha256(_REAL_ASSET).hexdigest()[:16]

# Reuse the v99.00 behavioural harness + the v99.02 real-module stack.
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(_SRC))  # for the exec-context deploy_health import
import test_v99_00_vc_pipeline as T  # noqa: E402
import test_v99_02_production_stability as T2  # noqa: E402

# The REAL 226,371-byte silence asset + the shipped embed module.
assert len(_REAL_ASSET) == 226371, len(_REAL_ASSET)
assert _REAL_ASSET_SHA16 == "e6ad24a0ecd48db2", _REAL_ASSET_SHA16


def _exec_bootstrap_functions(source_text: str, wanted: set) -> dict:
    """Exec-extract the RC-9/RC-14/RC-17 functions from the REAL
    bootstrap source so the SHIPPED bytes (not a copy) are what runs."""
    import logging as _logging
    ns: dict = {
        "os": os, "hashlib": hashlib, "json": json,
        "asyncio": asyncio,
        "logger": _logging.getLogger("mediagrab"),
        "__name__": "v9904_boot_extract",
        "__file__": str(_SRC / "bootstrap.py"),
    }
    tree = ast.parse(source_text)
    found = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name in wanted:
            seg = ast.get_source_segment(source_text, node)
            assert seg is not None
            exec(compile(seg, "<bootstrap.py:v99.05>", "exec"), ns)
            found.add(node.name)
    missing = wanted - found
    assert not missing, f"functions missing from bootstrap source: {missing}"
    return ns


def _write_embed_module(module_dir: Path, rel: str, data: bytes,
                        *, sha16: str | None = None, size: int | None = None,
                        b64_override: str | None = None) -> None:
    """Write a scratch asset_embedded.py carrying `data` under `rel`."""
    sha = sha16 or hashlib.sha256(data).hexdigest()[:16]
    sz = size if size is not None else len(data)
    b64 = b64_override or base64.b64encode(data).decode("ascii")
    lines = textwrap.wrap(b64, 76)
    body = "\n".join('    "' + ln + '"' for ln in lines)
    (Path(module_dir) / "asset_embedded.py").write_text(
        f'EMBEDDED_ASSETS = {{\n    "{rel}": {{\n'
        f'        "sha256_16": "{sha}",\n        "size": {sz},\n'
        f'        "b64": (\n{body}\n        ),\n    }},\n}}\n',
        encoding="utf-8")


# ===========================================================================
# RC-14 — the embedded-asset fallback (deployment self-containment)
# ===========================================================================

class TestV9904RC14EmbeddedAsset(unittest.TestCase):
    """The heal's embedded stage — exec-extracted SHIPPED bytes."""

    def setUp(self):
        self.fns = _exec_bootstrap_functions(
            _BOOT_TEXT, {"_v9903_self_heal_disabled",
                         "_v9903_self_heal_zip_candidates",
                         "_v9903_self_heal_assets"})
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)

    def tearDown(self):
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)

    def _tree(self, td: Path) -> Path:
        module_dir = td / "mediagrab_bot"
        (module_dir / "assets").mkdir(parents=True, exist_ok=True)
        return module_dir

    def test_shipped_embed_module_round_trips_the_real_asset(self):
        """The PACKAGED asset_embedded.py decodes to the exact stamped
        asset bytes — the .py-only deployment carries the asset."""
        spec = importlib.util.spec_from_file_location(
            "v9904_ae_shipped", str(_SRC / "asset_embedded.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        entry = mod.EMBEDDED_ASSETS["assets/vc_silence_600s.opus"]
        data = base64.b64decode(entry["b64"])
        self.assertEqual(data, _REAL_ASSET)
        self.assertEqual(entry["sha256_16"], _REAL_ASSET_SHA16)
        self.assertEqual(entry["size"], 226371)
        self.assertEqual(
            _STAMP["assets"]["assets/vc_silence_600s.opus"],
            _REAL_ASSET_SHA16)

    def test_heal_restores_the_real_shipped_asset_without_any_zip(self):
        """THE production scenario (Run 4, 06:27:15): .py files deployed
        (asset_embedded.py among them), the asset file MISSING, NO ZIP
        anywhere. The embedded stage heals it; the healed file's sha256
        equals the stamp."""
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            # the operator's channel delivered the .py files:
            (module_dir / "asset_embedded.py").write_bytes(
                (_SRC / "asset_embedded.py").read_bytes())
            stamp = {"assets/vc_silence_600s.opus": _REAL_ASSET_SHA16}
            runtime = {"assets/vc_silence_600s.opus": "missing"}
            oldcwd = os.getcwd()
            os.chdir(td)  # no ZIP beside the tree (production fact)
            try:
                with self.assertLogs("mediagrab", level="INFO") as logs:
                    res = self.fns["_v9903_self_heal_assets"](
                        stamp, runtime, str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertTrue(res["ok"], res)
            self.assertTrue(str(res["source"]).startswith("embedded:"),
                            res["source"])
            healed = (module_dir / "assets" /
                      "vc_silence_600s.opus").read_bytes()
            self.assertEqual(healed, _REAL_ASSET)
            self.assertEqual(
                hashlib.sha256(healed).hexdigest()[:16], _REAL_ASSET_SHA16)
            self.assertTrue(
                any("DEPLOY_SELF_HEAL" in l and "source=embedded:" in l
                    and "v99.04 RC-14" in l for l in logs.output),
                logs.output)

    def test_heal_from_embedded_with_small_asset(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            payload = os.urandom(4096)
            sha16 = hashlib.sha256(payload).hexdigest()[:16]
            _write_embed_module(module_dir, "assets/x.opus", payload)
            res = self.fns["_v9903_self_heal_assets"](
                {"assets/x.opus": sha16},
                {"assets/x.opus": "missing"}, str(module_dir))
            self.assertTrue(res["ok"], res)
            self.assertEqual(res["reason"], "healed")
            self.assertEqual(
                (module_dir / "assets" / "x.opus").read_bytes(), payload)

    def test_corrupted_embed_is_refused(self):
        """Identity checking is NOT weakened: wrong bytes in the embed
        are refused and NOTHING is written (RC-8 would then apply)."""
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            payload = os.urandom(2048)
            good_sha = hashlib.sha256(payload).hexdigest()[:16]
            # embed DIFFERENT bytes but declare the GOOD stamp sha:
            _write_embed_module(module_dir, "assets/x.opus",
                                b"WRONG-BYTES" * 40)
            res = self.fns["_v9903_self_heal_assets"](
                {"assets/x.opus": good_sha},
                {"assets/x.opus": "missing"}, str(module_dir))
            self.assertFalse(res["ok"])
            self.assertIn("embedded_sha256_mismatch", str(res["reason"]))
            self.assertFalse((module_dir / "assets" / "x.opus").exists())

    def test_declared_size_mismatch_is_refused(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            payload = os.urandom(1024)
            sha16 = hashlib.sha256(payload).hexdigest()[:16]
            _write_embed_module(module_dir, "assets/x.opus", payload,
                                size=999999)
            res = self.fns["_v9903_self_heal_assets"](
                {"assets/x.opus": sha16},
                {"assets/x.opus": "missing"}, str(module_dir))
            self.assertFalse(res["ok"])
            self.assertIn("embedded_size_out_of_bounds",
                          str(res["reason"]))
            self.assertFalse((module_dir / "assets" / "x.opus").exists())

    def test_no_zip_and_no_embed_keeps_the_v9903_reason(self):
        """Contract compatibility: with NEITHER source the heal still
        reports the v99.03 reason (the v99.03 suite asserts it)."""
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    {"assets/vc_silence_600s.opus": "e6ad24a0ecd48db2"},
                    {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(res["ok"])
            self.assertEqual(res.get("reason"), "no_deployment_zip_found")

    def test_kill_switch_blocks_the_embedded_stage_too(self):
        os.environ["VC_DISABLE_DEPLOY_SELF_HEAL"] = "1"
        res = self.fns["_v9903_self_heal_assets"](
            {"assets/vc_silence_600s.opus": "x"},
            {"assets/vc_silence_600s.opus": "missing"}, "/nonexistent")
        self.assertFalse(res["ok"])
        self.assertEqual(res.get("reason"), "disabled_by_env")

    def test_zip_takes_priority_when_both_sources_exist(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)
            zip_payload = os.urandom(512)
            zip_sha = hashlib.sha256(zip_payload).hexdigest()[:16]
            with zipfile.ZipFile(td / "mediagrab_bot_v99.05_deployment.zip",
                                 "w") as zf:
                zf.writestr("mediagrab_bot/assets/x.opus", zip_payload)
            _write_embed_module(module_dir, "assets/x.opus",
                                os.urandom(512))
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    {"assets/x.opus": zip_sha},
                    {"assets/x.opus": "missing"}, str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertTrue(res["ok"], res)
            self.assertIn(str(td / "mediagrab_bot_v99.05_deployment.zip"),
                          str(res["source"]))
            self.assertEqual(
                (module_dir / "assets" / "x.opus").read_bytes(),
                zip_payload)

    def test_rc14_efficacy_embed_absent_fails_again(self):
        """FAIL-ON-REVERT: without the embedded stage (simulated by a
        tree with no asset_embedded.py) the exact same scenario the
        flagship test heals now FAILS — proving the embed is what makes
        .py-only deployments self-contained."""
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = self._tree(td)  # NO asset_embedded.py
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    {"assets/vc_silence_600s.opus": _REAL_ASSET_SHA16},
                    {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(res["ok"])  # v99.03 behaviour = failure
            self.assertFalse(
                (module_dir / "assets" / "vc_silence_600s.opus").exists())

    def test_atomic_write_contract_covers_the_embedded_stage(self):
        self.assertIn("mkstemp", _BOOT_TEXT)
        self.assertIn("os.replace(_v9904_tmp, _v9904_dest)", _BOOT_TEXT)


# ===========================================================================
# RC-15 — account_session_health: the expected_cluster undercount
# ===========================================================================

class TestV9904RC15ExpectedCluster(unittest.TestCase):
    """Behavioural tests against the REAL mtproto (v99.02 fake stack)."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = T2._load_real_voicechat()

    def setUp(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self._active_bak = self.mt._MTPROTO_ACTIVE_SESSION_PATH
        self._find_bak = self.mt._find_all_session_files
        self._cluster_bak = self.mt.get_userbot_cluster

    def tearDown(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = self._active_bak
        self.mt._find_all_session_files = self._find_bak
        self.mt.get_userbot_cluster = self._cluster_bak

    def _install_production_shape(self):
        """The EXACT Run 3 shape: accounts.json carries the real account
        AND the __primary__ special key (whose value is a STRING) — the
        state that produced expected_cluster=0 in production."""
        self.mt._find_all_session_files = lambda: [
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_918335829278.session"),
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_919006065076.session"),
        ]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = (
            "/home/container/mediagrab_bot/data/sessions/"
            "cluster_918335829278.session")

        class _ProdShapeCluster:
            _accounts = {
                "acc_919006065076": {
                    "phone": "+919006065076",
                    "session_file": "/home/container/mediagrab_bot/data/"
                                    "sessions/cluster_919006065076.session",
                },
                "__primary__": "acc_919006065076",  # STRING value!
            }
        self.mt.get_userbot_cluster = lambda: _ProdShapeCluster()
        return _ProdShapeCluster

    def test_production_shape_expected_cluster_counts_real_accounts(self):
        """THE production bug: v99.03 printed expected_cluster=0 here."""
        self._install_production_shape()
        h = self.mt.account_session_health()
        self.assertEqual(h["expected_cluster"], 1)  # v99.03 printed 0
        self.assertEqual(h["cluster_accounts"], 1)
        self.assertEqual(h["live"], 2)
        by_file = {d["file"]: d for d in h["details"]}
        self.assertEqual(by_file["cluster_919006065076.session"]["status"],
                         "cluster_account_id=acc_919006065076")
        self.assertEqual(by_file["cluster_918335829278.session"]["status"],
                         "primary_global")

    def test_multiple_real_accounts_and_special_keys(self):
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_918335829278.session"),
            Path("/x/cluster_919006065076.session"),
        ]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = "/x/cluster_918335829278.session"

        class _Two:
            _accounts = {
                "acc_918335829278": {"phone": "+918335829278",
                                     "session_file": "/x/cluster_918335829278.session"},
                "acc_919006065076": {"phone": "+919006065076",
                                     "session_file": "/x/cluster_919006065076.session"},
                "__primary__": "acc_919006065076",
                "__other__": 42,  # non-string special value
            }
        self.mt.get_userbot_cluster = lambda: _Two()
        h = self.mt.account_session_health()
        self.assertEqual(h["expected_cluster"], 2)
        # the ACTIVE file is primary_global even though registered:
        by_file = {d["file"]: d for d in h["details"]}
        self.assertEqual(by_file["cluster_918335829278.session"]["status"],
                         "primary_global")
        self.assertEqual(by_file["cluster_919006065076.session"]["status"],
                         "cluster_account_id=acc_919006065076")
        # v99.05 RC-F5 SEMANTICS DERIVATION (the FINAL-REBUILD counting
        # contract, mission §7/§8): the dual-role ACTIVE file
        # (primary_global AND a registered cluster account) now carries
        # roles=primary,cluster and its DISTINCT registration counts —
        # 2 registered accounts → cluster_accounts=2 expected_cluster=2
        # (the v99.05 contract counted the dual-role registration as 0,
        # which produced the incoherent production line
        # cluster_accounts=0 expected_cluster=1 while the SAME line
        # showed the cluster account id — "two accounts showing one").
        self.assertEqual(h["cluster_accounts"], 2)
        self.assertEqual(
            by_file["cluster_918335829278.session"].get("roles"),
            "primary,cluster")

    def test_non_dict_non_special_entry_is_skipped_without_crash(self):
        self.mt._find_all_session_files = lambda: [Path("/x/a.session")]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = ""

        class _Corrupt:
            _accounts = {"acc_bad": "not-a-dict",
                         "acc_good": {"phone": "+1", "session_file": "/x/a.session"}}
        self.mt.get_userbot_cluster = lambda: _Corrupt()
        h = self.mt.account_session_health()
        self.assertEqual(h["expected_cluster"], 1)  # only acc_good counts

    def test_emit_line_carries_cluster_accounts_and_single_brace(self):
        self._install_production_shape()
        with self.assertLogs("mediagrab", level="INFO") as logs:
            self.mt._emit_account_session_health()
        line = [l for l in logs.output if "ACCOUNT_SESSION_HEALTH" in l][0]
        self.assertIn("cluster_accounts=1", line)
        self.assertIn("expected_cluster=1", line)
        self.assertNotIn("}}", line)  # the v99.03 double-brace cosmetic
        self.assertIn("v99.04 RC-15", line)
        # v99.05 RC-F5: the emit line now also carries the honest
        # dual-role counting explanation:
        self.assertIn("v99.05 RC-F5", line)

    def test_rc15_efficacy_revert_restores_the_bug(self):
        """FAIL-ON-REVERT: the __/non-dict guard surgically REMOVED from
        a scratch copy of account_session_health → the production bug
        (expected_cluster=0) reappears — proving the guard is what fixes
        the production line."""
        reverted = _MT_TEXT.replace(
            'if str(_aid).startswith("__") or not isinstance(_acc, dict):\n'
            '                        continue\n'
            '                    _sf = str(_acc.get("session_file", "") or "")',
            '_sf = str(_acc.get("session_file", "") or "")', 1)
        self.assertNotEqual(reverted, _MT_TEXT, "guard not found to revert")
        import logging as _lg
        ns: dict = {"os": os, "time": __import__("time"),
                    "logger": _lg.getLogger("mediagrab"),
                    "_SESSION_HEALTH_REGISTRY": {},
                    "_MTPROTO_ACTIVE_SESSION_PATH":
                        "/x/cluster_918335829278.session",
                    "Path": Path, "get_userbot_cluster": lambda: None}
        # account_session_health's dependencies are looked up by global
        # name at call time — provide the two it touches first.
        tree = ast.parse(reverted)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in (
                    "account_session_health",):
                exec(compile(ast.get_source_segment(reverted, node),
                             "<mtproto-reverted>", "exec"), ns)
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_918335829278.session"),
            Path("/x/cluster_919006065076.session"),
        ]
        ns["_find_all_session_files"] = self.mt._find_all_session_files

        class _Prod:
            _accounts = {
                "acc_919006065076": {"session_file":
                                     "/x/cluster_919006065076.session"},
                "__primary__": "acc_919006065076",
            }
        ns["get_userbot_cluster"] = lambda: _Prod()
        h = ns["account_session_health"]()
        self.assertEqual(h["expected_cluster"], 0)  # the bug is back
        self.assertEqual(h["cluster_accounts"], 1)  # paths still populated


# ===========================================================================
# RC-16 — /cluster add registers a live-owned unregistered phone
# ===========================================================================

class TestV9904RC16LoginRegistration(unittest.TestCase):
    """Behavioural tests against the REAL mtproto cluster_start_login."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = T2._load_real_voicechat()
        # cluster_start_login imports TelegramClient at function scope;
        # the fake telethon has none — the constructor is never reached
        # on the already-connected path, but the import must succeed.
        T._install_fake_telethon().TelegramClient = type(
            "TelegramClient", (), {})

    def setUp(self):
        self.mt._cluster_login_cooldowns.clear()
        self._ilsa_bak = self.mt._is_session_live_authorized
        self._lso_bak = self.mt._get_live_session_owner
        self._cluster_bak = self.mt.get_userbot_cluster
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR

    def tearDown(self):
        self.mt._cluster_login_cooldowns.clear()
        self.mt._is_session_live_authorized = self._ilsa_bak
        self.mt._get_live_session_owner = self._lso_bak
        self.mt.get_userbot_cluster = self._cluster_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._SESSION_HEALTH_REGISTRY.clear()

    class _FakeCluster:
        def __init__(self):
            self._accounts: dict = {}
            self._clients: dict = {}
            self.saved = 0

        def add_account(self, phone, session_file, role="BACKUP",
                        username="", user_id=0):
            aid = f"acc_{phone.replace('+', '')}"
            self._accounts[aid] = {"phone": phone,
                                   "session_file": session_file,
                                   "role": role, "username": username,
                                   "user_id": user_id}
            return aid

        def _save(self):
            self.saved += 1

    class _FakeMe:
        id = 8624009332
        username = "Gradieer"

    class _FakeLiveClient:
        async def get_me(self):
            return TestV9904RC16LoginRegistration._FakeMe()

    def _install(self, cluster, *, live=True):
        # mkdtemp (NOT TemporaryDirectory-as-context — that would delete
        # the dir on block exit and the session file with it).
        self._td = Path(tempfile.mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, self._td,
                        ignore_errors=True)
        self.mt._CLUSTER_ACCOUNTS_DIR = self._td
        (self._td / "cluster_918335829278.session").write_bytes(b"x" * 64)
        self.mt._is_session_live_authorized = self._fake_ilsa(live)
        self.mt._get_live_session_owner = (
            lambda base: self._FakeLiveClient() if live else None)
        self.mt.get_userbot_cluster = lambda: cluster

    @staticmethod
    def _fake_ilsa(live):
        async def _inner(base):
            return live
        return _inner

    def test_unregistered_live_phone_is_registered_with_client_reuse(self):
        """THE production gap (03:04:20 + 06:26:31): /cluster add on the
        global primary's phone now REGISTERS the account instead of
        dead-ending on already_connected."""
        cluster = self._FakeCluster()
        self._install(cluster)
        with self.assertLogs("mediagrab", level="INFO") as logs:
            res = asyncio.run(
                self.mt.cluster_start_login(8370454312, "+918335829278"))
        self.assertTrue(res.startswith("registered:"), res)
        aid = res.split("registered:")[1]
        self.assertEqual(aid, "acc_918335829278")
        acc = cluster._accounts[aid]
        self.assertEqual(acc["phone"], "+918335829278")
        self.assertEqual(acc["imported"], True)
        self.assertEqual(acc["status"], "healthy")  # STATUS_HEALTHY
        self.assertEqual(acc["username"], "Gradieer")
        self.assertEqual(acc["user_id"], 8624009332)
        self.assertEqual(acc["role"], "BACKUP")
        # the LIVE client is reused (no duplicate TelegramClient):
        self.assertIsInstance(cluster._clients[aid], self._FakeLiveClient)
        self.assertEqual(cluster.saved, 1)
        # the session health registry recorded the import:
        self.assertEqual(
            self.mt._SESSION_HEALTH_REGISTRY.get(
                "cluster_918335829278.session", {}).get("account_id"), aid)
        self.assertTrue(
            any("ACCOUNT_REGISTERED" in l
                and "source=login_live_owner_reuse" in l
                and "v99.04 RC-16" in l for l in logs.output),
            logs.output)

    def test_already_registered_phone_keeps_already_connected(self):
        cluster = self._FakeCluster()
        self._install(cluster)
        cluster._accounts["acc_918335829278"] = {
            "phone": "+918335829278",
            "session_file": str(self._td / "cluster_918335829278.session"),
        }
        res = asyncio.run(
            self.mt.cluster_start_login(8370454312, "+918335829278"))
        self.assertTrue(res.startswith("already_connected:"), res)
        self.assertIn("Gradieer", res)
        self.assertEqual(cluster.saved, 0)  # no re-registration

    def test_registration_failure_falls_back_to_already_connected(self):
        class _Broken(self._FakeCluster):
            def add_account(self, *a, **kw):
                raise RuntimeError("disk full")
        cluster = _Broken()
        self._install(cluster)
        with self.assertLogs("mediagrab", level="WARNING") as logs:
            res = asyncio.run(
                self.mt.cluster_start_login(8370454312, "+918335829278"))
        self.assertTrue(res.startswith("already_connected:"), res)
        self.assertTrue(any("ACCOUNT_LOGIN_REGISTER_FAILED" in l
                            for l in logs.output), logs.output)

    def test_handlers_render_the_new_outcomes(self):
        """The operator-facing replies: registered → success card;
        already_connected → informational card (v99.03 rendered it as
        '❌ Failed to send code')."""
        self.assertIn('result.startswith("registered:")', _HANDLERS_TEXT)
        self.assertIn("Account added — existing session reused!",
                      _HANDLERS_TEXT)
        self.assertIn('result.startswith("already_connected:")',
                      _HANDLERS_TEXT)
        self.assertIn("Already connected and registered:", _HANDLERS_TEXT)
        self.assertIn("v99.04 RC-16", _HANDLERS_TEXT)

    def test_rc16_efficacy_source_contract(self):
        """FAIL-ON-REVERT source contract: the registration block exists
        exactly once with the reuse semantics."""
        self.assertIn("source=login_live_owner_reuse", _MT_TEXT)
        self.assertIn('return f"registered:{_v9904_aid}"', _MT_TEXT)
        self.assertEqual(_MT_TEXT.count("login_live_owner_reuse"), 1)


# ===========================================================================
# RC-17 — the deploy-health recovery loop (no-restart repair)
# ===========================================================================

class TestV9904RC17RecoveryLoop(unittest.TestCase):
    """The re-verifier + loop — exec-extracted SHIPPED bytes, the REAL
    deploy_health module as the shared-state carrier."""

    def setUp(self):
        self.ns = _exec_bootstrap_functions(
            _BOOT_TEXT, {"_v9903_self_heal_disabled",
                         "_v9903_self_heal_zip_candidates",
                         "_v9903_self_heal_assets",
                         "_v9904_get_deploy_health",
                         "_v9904_reverify_identity",
                         "_v9904_deploy_health_recovery_loop",
                         "_v9904_deploy_recovery_schedule"})
        os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)
        # The SAME module object the exec'd helper resolves via
        # import_module("deploy_health") (sys.path includes _SRC) — a
        # spec_from_file_location instance would be a DIFFERENT object
        # and the loop's state flips would never be visible here.
        import deploy_health as _dh  # noqa: PLC0415
        self.dh = _dh
        self.dh.reset_for_tests()

    def tearDown(self):
        self.dh.reset_for_tests()
        os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)

    def _scratch_tree(self, td: Path, *, module_ok=True) -> Path:
        """A minimal stamped tree: one module + one stamped asset + the
        embedded copy of that asset; the asset FILE is missing."""
        module_dir = td / "mediagrab_bot"
        (module_dir / "assets").mkdir(parents=True, exist_ok=True)
        # The stamp always records the ORIGINAL module hash; a tampered
        # FILE (module_ok=False) then mismatches the stamp (the module
        # hash is what reverify must detect).
        mod_sha = hashlib.sha256(b"# scratch module\n").hexdigest()[:16]
        (module_dir / "__init__.py").write_bytes(
            b"# scratch module\n" if module_ok else b"# TAMPERED\n")
        payload = b"SCRATCH-ASSET-" * 64  # 896 bytes
        sha16 = hashlib.sha256(payload).hexdigest()[:16]
        (module_dir / "build_stamp.json").write_text(json.dumps({
            "version": "",  # version check skipped in exec contexts
            "modules": {"__init__.py": mod_sha},
            "assets": {"assets/x.opus": sha16},
        }))
        _write_embed_module(module_dir, "assets/x.opus", payload)
        return module_dir

    def test_reverify_heals_and_flips_to_verified(self):
        with tempfile.TemporaryDirectory() as td_s:
            module_dir = self._scratch_tree(Path(td_s))
            verdict = self.ns["_v9904_reverify_identity"](str(module_dir))
            self.assertEqual(verdict["state"], "verified", verdict)
            self.assertTrue(verdict["heal"]["ok"], verdict["heal"])
            self.assertIn("embedded:", str(verdict["heal"]["source"]))
            self.assertEqual(
                (module_dir / "assets" / "x.opus").read_bytes(),
                b"SCRATCH-ASSET-" * 64)

    def test_reverify_reports_module_mismatch(self):
        with tempfile.TemporaryDirectory() as td_s:
            module_dir = self._scratch_tree(Path(td_s), module_ok=False)
            verdict = self.ns["_v9904_reverify_identity"](str(module_dir))
            self.assertEqual(verdict["state"], "mismatch", verdict)
            self.assertIn("__init__.py: stamp=", verdict["detail"])
            self.assertIn("actual=", verdict["detail"])

    def test_reverify_unreadable_stamp(self):
        with tempfile.TemporaryDirectory() as td_s:
            md = Path(td_s) / "mediagrab_bot"
            md.mkdir(parents=True)
            verdict = self.ns["_v9904_reverify_identity"](str(md))
            self.assertEqual(verdict["state"], "unreadable", verdict)

    def test_recovery_loop_recovers_without_restart(self):
        """Mission §9: healthy → broken → repaired → automatically
        healthy again — the loop flips the shared state and the RC-8
        gate re-opens WITHOUT a restart."""
        with tempfile.TemporaryDirectory() as td_s:
            module_dir = self._scratch_tree(Path(td_s))
            # the boot verdict was a MISMATCH (asset missing at boot):
            self.dh.set_build_identity("mismatch", "assets/x.opus missing",
                                       stamp_version="v99.06",
                                       runtime_version="v99.06")
            self.assertIsNotNone(self.dh.vc_pipeline_disabled_reason())
            # point the exec'd loop at the scratch tree:
            self.ns["__file__"] = str(module_dir / "bootstrap.py")
            self.ns["_V9904_RECOVERY_INTERVAL_S"] = 0.05
            with self.assertLogs("mediagrab", level="INFO") as logs:
                asyncio.run(asyncio.wait_for(
                    self.ns["_v9904_deploy_health_recovery_loop"](), 5))
            self.assertEqual(self.dh.build_identity_state()["state"],
                             "verified")
            self.assertIsNone(self.dh.vc_pipeline_disabled_reason())
            self.assertTrue(
                any("DEPLOY_HEALTH_RECOVERED" in l and "v99.04 RC-17" in l
                    for l in logs.output), logs.output)
            # the asset was healed by the loop's re-verify:
            self.assertTrue((module_dir / "assets" / "x.opus").exists())

    def test_recovery_loop_stays_quiet_on_persistent_mismatch(self):
        with tempfile.TemporaryDirectory() as td_s:
            module_dir = self._scratch_tree(Path(td_s), module_ok=False)
            self.dh.set_build_identity("mismatch", "module mismatch",
                                       stamp_version="v99.06",
                                       runtime_version="v99.06")
            self.ns["__file__"] = str(module_dir / "bootstrap.py")
            self.ns["_V9904_RECOVERY_INTERVAL_S"] = 0.05

            async def _run_briefly():
                task = asyncio.ensure_future(
                    self.ns["_v9904_deploy_health_recovery_loop"]())
                await asyncio.sleep(0.25)
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
            with self.assertLogs("mediagrab", level="DEBUG") as logs:
                asyncio.run(_run_briefly())
            self.assertEqual(self.dh.build_identity_state()["state"],
                             "mismatch")
            self.assertFalse(
                any("DEPLOY_HEALTH_RECOVERED" in l for l in logs.output))
            self.assertTrue(
                any("DEPLOY_HEALTH_RECOVERY_ATTEMPT" in l
                    for l in logs.output), logs.output)

    def test_schedule_starts_only_on_mismatch_and_is_idempotent(self):
        calls: list = []

        class _FakeTask:
            def done(self):
                return False
        self.ns["supervised_create_task"] = \
            lambda fn, name=None: (calls.append(name), _FakeTask())[1]
        self.ns["_v9904_deploy_recovery_task"] = None
        # healthy → no loop:
        self.dh.set_build_identity("verified", "ok")
        self.ns["_v9904_deploy_recovery_schedule"]()
        self.assertEqual(calls, [])
        # mismatched → loop, exactly once:
        self.dh.set_build_identity("mismatch", "x")
        self.ns["_v9904_deploy_recovery_schedule"]()
        self.ns["_v9904_deploy_recovery_schedule"]()
        self.assertEqual(calls, ["deploy_health_recovery"])


# ===========================================================================
# §GATE + version + packaging contracts
# ===========================================================================

class TestV9904Contracts(unittest.TestCase):

    def test_vc_join_success_still_requires_verified_evidence(self):
        """§7 audit guard: VC_JOIN_SUCCESS must keep asserting
        telegram_verified=true verify_result=present (an unverified join
        NEVER reaches the success site — the §GATE guarantee)."""
        self.assertIn("telegram_verified=true verify_result=present",
                      _VC_TEXT)
        self.assertIn("UNVERIFIED join never reaches this site", _VC_TEXT)

    def test_boot_wires_rc14_and_rc17(self):
        self.assertIn("DEPLOY_SELF_HEAL asset=%s source=embedded:",
                      _BOOT_TEXT)
        self.assertIn("_v9904_deploy_recovery_schedule()", _BOOT_TEXT)
        self.assertIn("DEPLOY_HEALTH_RECOVERY_SCHEDULED", _BOOT_TEXT)
        self.assertIn("DEPLOY_HEALTH_RECOVERED", _BOOT_TEXT)
        # the failed-heal runbook now mentions the embedded path:
        self.assertIn("NOR from the embedded .py copy", _BOOT_TEXT)

    def test_version_tracks_the_artifact(self):
        self.assertIn('__bot_version__ = "v99.11.1"', _INIT_TEXT)
        self.assertEqual(_STAMP.get("version"), "v99.11.1")  # v99.11.1 release bump: tracks CURRENT

    def test_service_version(self):
        self.assertIn("(24/7 supervised, v99.11)", _SERVICE_TEXT)  # v99.11 release bump: tracks CURRENT

    def test_asset_embedded_module_is_packaged(self):
        self.assertTrue((_SRC / "asset_embedded.py").exists())
        text = (_SRC / "asset_embedded.py").read_text(encoding="utf-8")
        self.assertIn("EMBEDDED_ASSETS", text)
        self.assertIn("assets/vc_silence_600s.opus", text)
        self.assertIn("v99.05 RC-14", text)

    def test_embed_generator_tool_is_packaged(self):
        tool = Path(__file__).resolve().parent.parent / "tools" / "embed_asset.py"
        self.assertTrue(tool.exists())
        self.assertIn("asset_embedded.py", tool.read_text(encoding="utf-8"))

    def test_stamp_modules_match_the_runtime_tree(self):
        for rel, expected_sha in (_STAMP.get("modules") or {}).items():
            path = _SRC / rel
            self.assertTrue(path.exists(), f"stamped module missing: {rel}")
            self.assertEqual(
                hashlib.sha256(path.read_bytes()).hexdigest()[:16],
                expected_sha, f"stamped hash drifted for {rel}")

    def test_stamp_asset_matches_the_runtime_tree(self):
        for rel, expected_sha in (_STAMP.get("assets") or {}).items():
            path = _SRC / rel
            self.assertTrue(path.exists(), f"stamped asset missing: {rel}")
            self.assertEqual(
                hashlib.sha256(path.read_bytes()).hexdigest()[:16],
                expected_sha, f"stamped asset hash drifted for {rel}")


if __name__ == "__main__":
    unittest.main()
