"""
v97.61 regression tests — runtime failure fixes against the actual v97.60 log.

These tests prove (REAL PASS) the concrete bugs from the v97.60 runtime log
are fixed at the source level:

  1. TypeError "object NoneType can't be used in 'await' expression"
     Root cause: _vc_release_target_inflight is SYNC (returns None) but was
     awaited at 4 callsites. Fixed: all 4 sites now call it without await.

  2. VC_CALLBACK_HANDLER_TIMEOUT (30s block)
     Root cause: the Bot API handler vc__handle_join_target awaited
     vc_manual_join synchronously inside the PTB update processor.
     Fixed: vc__handle_join_target + vc__leave_current now submit to the
     VC scheduler (fast-ack); the update processor returns immediately.

  3. MTPROTO_GENERATION_STATE instrumentation (§4)
     The health loop now emits generation state with active/retiring/retired
     counts + FAILS if active > 1.

  4. VC_CALLBACK_HANDLER_SLOW instrumentation (§2)
     The callback worker now measures handler duration + warns at >= 2s with
     task ownership.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestTypeErrorAwaitNoneRegression(unittest.TestCase):
    """§6: the exact TypeError from the runtime log must be impossible."""

    def test_no_await_on_sync_release_target_inflight(self):
        """_vc_release_target_inflight is SYNC — must NEVER be awaited."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        # The sync function definition.
        self.assertIn("def _vc_release_target_inflight(gid: int) -> None:", src,
                      "_vc_release_target_inflight must be defined as sync (def, not async def)")
        # NO await of it anywhere.
        self.assertNotIn("await _vc_release_target_inflight", src,
                         "await _vc_release_target_inflight must be removed (it's sync, returns None)")

    def test_release_target_inflight_is_sync(self):
        """The function must be sync (def, not async def)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        # Find the definition — must be "def" not "async def".
        import re
        m = re.search(r"(async\s+)?def\s+_vc_release_target_inflight\s*\(", src)
        self.assertIsNotNone(m, "_vc_release_target_inflight must exist")
        self.assertIsNone(m.group(1),
                          "_vc_release_target_inflight must be SYNC (def, not async def)")


class TestBotAPIFastAck(unittest.TestCase):
    """§2: the Bot API handlers must not block the update processor."""

    def test_join_target_uses_scheduler(self):
        """vc__handle_join_target must submit to the scheduler (not await synchronously)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("VC_BOT_API_JOIN_SCHEDULED", src,
                      "vc__handle_join_target must log VC_BOT_API_JOIN_SCHEDULED")
        # The function must NOT directly await vc_manual_join at the top level
        # (it's inside the scheduler's _join_fn now).
        # Find the function body + verify it creates a VCOpRequest.
        self.assertIn("op_type=\"bot_api_join\"", src,
                      "vc__handle_join_target must submit op_type='bot_api_join'")

    def test_leave_current_uses_scheduler(self):
        """vc__leave_current must submit to the scheduler."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("VC_BOT_API_LEAVE_SCHEDULED", src,
                      "vc__leave_current must log VC_BOT_API_LEAVE_SCHEDULED")
        self.assertIn("op_type=\"bot_api_leave\"", src,
                      "vc__leave_current must submit op_type='bot_api_leave'")


class TestGenerationInstrumentation(unittest.TestCase):
    """§4: MTPROTO_GENERATION_STATE must be emitted + fail if active > 1."""

    def test_generation_state_logged_in_health_loop(self):
        """The health loop must emit MTPROTO_GENERATION_STATE."""
        src_path = os.path.join(_BASE, "mediagrab_bot/mtproto.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("MTPROTO_GENERATION_STATE", src,
                      "health loop must log MTPROTO_GENERATION_STATE")
        self.assertIn("MTPROTO_GENERATION_INVARIANT_VIOLATION", src,
                      "health loop must FAIL if active > 1")
        self.assertIn("active=%d", src,
                      "active count must be in the log")


class TestCallbackHandlerInstrumentation(unittest.TestCase):
    """§2: callback handler duration must be measured + warned at >= 2s."""

    def test_handler_duration_measured(self):
        """The worker must measure handler duration + warn at >= 2s."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("VC_CALLBACK_HANDLER_SLOW", src,
                      "worker must log VC_CALLBACK_HANDLER_SLOW at >= 2s")
        self.assertIn("last_duration", src,
                      "worker must track last_duration")
        self.assertIn("durations", src,
                      "worker must track durations list for p95/p99")


class TestFloodWaitPreserved(unittest.TestCase):
    """§7: FloodWait protection must be preserved."""

    def test_global_floodwait_still_present(self):
        """The global FloodWait gate must NOT be removed."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src,
                      "global FloodWait must be preserved")
        self.assertIn("JOIN_ALL_BREAKER", src,
                      "Join-All breaker must be preserved")
        self.assertIn("vc_is_global_floodwait_active", src,
                      "global FloodWait check must be preserved")


if __name__ == "__main__":
    unittest.main(verbosity=2)
