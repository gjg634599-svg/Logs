"""v98.12 — PRODUCTION HARDENING regression suite (pytest).

Layers:
  §A  behavioral — runs the v98.12 driver (tests/_v9812_driver.py) and the
      long-run stress driver (tests/_v9812_longrun_driver.py) as
      subprocesses (exit code = failed-case count; the drivers exec the
      REAL shipped source with a stubbed dependency namespace).
  §B  source contracts — the (6).log root-cause fixes pinned at source
      level (the v98.x suite style: AST-verified structure, never string
      scraping of behavior that isn't structural).
  §C  preservation guards — v98.11 resolver fixes + v98.05/v98.08/v98.09
      invariants that v98.12 must NOT regress.
  §D  deployment identity — version, build stamp machinery, systemd unit,
      supervisor detection.

PROMPT 5 (v98.12) §30 matrix mapping (V-numbers → tests):
  V3/V8/V10/V11  → §C preservation + driver C15
  V16/V17/V18/V19 → driver C2/C3/C4 + §B wiring
  V20/V21        → driver C3/C5/C7 + §B gate
  V22 (old generation) → §B stale-cleanup owner guard (pre-existing
                   v98.01 FIX-J preserved + still gated)
  V23/V24        → driver C9 + §C coordinator single-flight (C11)
  V26/V29        → driver C10/C12 + §B watchdog adaptive cadence
  V28            → driver C9 (account isolation) + §B
  V32            → §D
  V33            → §B startup contract (bootstrap unchanged fast path)
  V34/V38        → §C fastpath suite re-run (dedicated suites cover)
  V40            → §A long-run stress (2000 simulated cycles)
"""
from __future__ import annotations

import ast
import os
import subprocess
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_SRC = _ROOT / "mediagrab_bot"
_TESTS = _ROOT / "tests"


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read()


_VC = _read(str(_SRC / "voicechat.py"))
# v99.09 test maintenance: the verify_joined signature pin
# (chat_id, *, _v9909_delegated=False) — keyword-only guard
# param, POSITIONAL chat_id unchanged; contracts unchanged.

_MT = _read(str(_SRC / "mtproto.py"))
_GEN = _read(str(_SRC / "mtproto_generation.py"))
_BOOT = _read(str(_SRC / "bootstrap.py"))
_INIT = _read(str(_SRC / "__init__.py"))


# ---------------------------------------------------------------------------
# §A — behavioral: the drivers (REAL shipped functions, stubbed world)
# ---------------------------------------------------------------------------
class TestVC9812Driver(unittest.TestCase):
    """§A: the v98.12 driver must pass 15/15 (exit 0)."""

    def test_driver_all_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, str(_TESTS / "_v9812_driver.py")],
            capture_output=True, text=True, timeout=180, cwd=str(_ROOT))
        self.assertEqual(proc.returncode, 0,
                         f"driver failures:\n{proc.stdout[-2000:]}")
        self.assertIn("15/15 cases pass", proc.stdout)

    def test_driver_covers_the_6log_root_causes(self):
        """The driver's case set names the (6).log root-cause matrix."""
        src = _read(str(_TESTS / "_v9812_driver.py"))
        for marker in (
            "C3_stale_identity_groupcall_invalid_refreshes",   # V20
            "C4_inconclusive_recheck_preserves",               # V18/V19
            "C9_account_reconnect_single_flight",              # V24
            "C10_timeout_classified_network_unreachable",      # V29
            "C13_deployment_identity_contract",                # V32
            "C15_v9811_resolver_fixes_preserved",              # V5-V15
        ):
            self.assertIn(marker, src)


class TestVC9812LongRunStress(unittest.TestCase):
    """§A: §31 long-run stress (SIMULATED/CONTROLLED) — 10/10 checks."""

    def test_longrun_stress_passes(self):
        proc = subprocess.run(
            [sys.executable, str(_TESTS / "_v9812_longrun_driver.py"), "600"],
            capture_output=True, text=True, timeout=300, cwd=str(_ROOT))
        self.assertEqual(proc.returncode, 0,
                         f"longrun failures:\n{proc.stdout[-2500:]}")
        self.assertIn("LONGRUN RESULT: PASS", proc.stdout)
        # the §31 accounting fields must all be reported
        for field in ("tasks_created", "joins", "rejoins", "false_stale",
                      "real_stale", "identity_refreshes", "rpc_getgroupcall"):
            self.assertIn(f"{field}=", proc.stdout)
        self.assertIn("false_stale=0", proc.stdout)


# ---------------------------------------------------------------------------
# §B — source contracts: the (6).log root-cause fixes
# ---------------------------------------------------------------------------
class TestVC9812EvidenceModel(unittest.TestCase):
    """§5: the evidence-strength model + non-destructive UNKNOWN."""

    def test_evidence_registry_module_state(self):
        self.assertIn("_vc_last_verify_evidence: dict[int, dict[str, Any]] = {}", _VC)
        self.assertIn("def _vc_record_verify_evidence(", _VC)

    def test_call_gone_evidence_check_function_exists(self):
        self.assertIn("async def _vc_call_gone_evidence_check(", _VC)
        # the three evidence outcomes with §5 semantics
        for s in ('"refreshed"', '"strong_negative"', '"inconclusive"'):
            self.assertIn(s, _VC)

    def test_groupcallinvalid_branch_runs_evidence_check(self):
        idx = _VC.find("if _corr is False:")
        self.assertGreater(idx, 0)
        following = _VC[idx:idx + 3600]
        self.assertIn("_vc_call_gone_evidence_check(", following)
        self.assertIn("return True", following)        # refreshed/weak preserve
        self.assertIn("return None", following)        # strong negative only

    def test_worker_gate_preserves_weak_evidence(self):
        self.assertIn('_v9812_ev_strength == "strong_negative"', _VC)
        self.assertIn("0.0 <= _v9812_ev_age <= 30.0", _VC)
        self.assertIn('result_state = "joined_unverified"', _VC)
        self.assertIn("VC_JOIN_ALL_TARGET_VERIFY_DEFERRED", _VC)

    def test_worker_registers_unverified_as_joined(self):
        idx = _VC.find('elif result_state == "joined_unverified":')
        self.assertGreater(idx, 0)
        self.assertIn("_reg_state = \"joined\"", _VC[idx:idx + 500])

    def test_fixcc_recovery_now_gated_not_unconditional(self):
        """The v98.05 FIX-CC post-verify recovery still exists but is now
        INSIDE the strong-negative else-branch of the evidence gate (the
        join-path occurrence — the snapshot-path FIX-DD occurrence at the
        top of the worker is a different, registry-gated call site that
        only fires for non-joined registry states)."""
        # scope: the confirmation_unknown branch INSIDE the Join-All worker
        # (other functions map result_state too — e.g. the coordinator
        # completion mapping — so the find is anchored to the worker def).
        worker_idx = _VC.find("async def _vc_join_all_active_worker(")
        self.assertGreater(worker_idx, 0)
        # locate THE evidence-gated occurrence (the worker has other
        # confirmation_unknown mappings — the distributed progress counter;
        # the gated one is identified by its evidence-gate marker).
        idx = worker_idx
        found = -1
        while True:
            idx = _VC.find('if result_state == "confirmation_unknown":', idx + 1)
            if idx < 0:
                break
            if "_v9812_ev_rec" in _VC[idx:idx + 2400]:
                found = idx
                break
        idx = found
        self.assertGreater(idx, 0, "evidence-gated confirmation_unknown branch not found")
        branch = _VC[idx:idx + 6500]
        preserve_idx = branch.find('result_state = "joined_unverified"')
        recovery_idx = branch.find("_vc_stale_container_recovery(")
        self.assertGreater(preserve_idx, 0)
        self.assertGreater(recovery_idx, 0)
        self.assertLess(preserve_idx, recovery_idx,
                        "the preserve (weak-evidence) arm must precede the "
                        "destructive recovery arm inside the branch")
        # the evidence gate conditions exist in the branch
        self.assertIn('_v9812_ev_strength == "strong_negative"', branch)
        self.assertIn("0.0 <= _v9812_ev_age <= 30.0", branch)


class TestVC9812AccountAwareVerification(unittest.TestCase):
    """§3/§6: owner-account verification (the wrong-account fix)."""

    def test_corroboration_accepts_account_id(self):
        idx = _VC.find("async def _vc_telegram_call_still_valid(")
        self.assertGreater(idx, 0)
        head = _VC[idx:idx + 400]
        self.assertIn("account_id: str = \"\"", head)

    def test_corroboration_resolves_owner_client_first(self):
        idx = _VC.find("async def _vc_telegram_call_still_valid(")
        seg = _VC[idx:idx + 3500]
        self.assertIn("get_userbot_cluster()", seg)
        self.assertIn("get_client(account_id)", seg)
        self.assertIn("VC_CORROBORATE_CLIENT_GLOBAL_FALLBACK", seg)

    def test_verify_joined_resolves_owner_account(self):
        idx = _VC.find("async def verify_joined(self, chat_id: int, *,", 4000)
        seg = _VC[idx:idx + 22000]
        self.assertIn("_v9812_owner_account", seg)
        self.assertIn("_vc_active_join_backends_by_chat.get", seg)
        # registry owner fallback (DB-persisted, restart-surviving)
        self.assertIn('getattr(rec, "account_id", None)', seg)
        # BOTH account-sensitive checks receive the owner
        self.assertGreaterEqual(seg.count("account_id=_v9812_owner_account"), 2)

    def test_evidence_check_uses_owner_account_client(self):
        idx = _VC.find("async def _vc_call_gone_evidence_check(")
        seg = _VC[idx:idx + 7500]
        self.assertIn("get_client(account_id)", seg)
        self.assertIn("VC_CALL_GONE_REDETECT_STRONG_NEGATIVE", seg)
        self.assertIn("VC_CALL_GONE_REDETECT_INCONCLUSIVE", seg)
        self.assertIn("VC_JOIN_IDENTITY_REFRESHED", seg)

    def test_identity_refresh_updates_registry_and_backend(self):
        idx = _VC.find("async def _vc_call_gone_evidence_check(")
        seg = _VC[idx:idx + 7500]
        self.assertIn("vc_registry_register(", seg)
        self.assertIn("_current_call_id = _new_call_id", seg)


class TestVC9812ReconnectHardening(unittest.TestCase):
    """§11-§13: reconnect self-healing (the 39-generation churn fix)."""

    def test_failure_class_recorded_from_exception(self):
        self.assertIn("_last_failure_class: dict[str, NetworkFailureClass] = {}", _GEN)
        self.assertIn("NETWORK_UNREACHABLE", _GEN)
        # classification happens IN the except branch (from the exception)
        idx = _GEN.find("except Exception as exc:")
        self.assertGreater(idx, 0)
        seg = _GEN[idx:idx + 1800]
        self.assertIn("asyncio.TimeoutError", seg)
        self.assertIn("_last_failure_class[key] = NetworkFailureClass.NETWORK_UNREACHABLE", seg)

    def test_backoff_prefers_recorded_class(self):
        self.assertIn("_v9812_cls = self._last_failure_class.get(key)", _GEN)
        self.assertIn("failure_class = _v9812_cls", _GEN)

    def test_success_clears_failure_class(self):
        self.assertIn("self._last_failure_class.pop(key, None)", _GEN)

    def test_watchdog_adaptive_cadence(self):
        idx = _MT.find("async def _mtproto_watchdog_loop")
        seg = _MT[idx:idx + 4200]
        self.assertIn("_v9812_wd_interval = 30.0 if _v9812_wd_consec_disc >= 6 else 10.0", seg)
        self.assertIn("MTPROTO_WATCHDOG_RECOVERED", seg)
        # first-detection latency stays fast (the else 10.0 arm)
        self.assertIn("else 10.0", seg)

    def test_account_reconnect_single_flight(self):
        self.assertIn("_vc_account_reconnect_inflight: set[str] = set()", _VC)
        idx = _VC.find("async def _vc_reconnect_account(")
        seg = _VC[idx:idx + 2200]
        self.assertIn("in _vc_account_reconnect_inflight", seg)
        self.assertIn("VC_ACCOUNT_RECONNECT_SINGLE_FLIGHT_SKIP", seg)
        # the key is ALWAYS released (finally)
        self.assertIn("_vc_account_reconnect_inflight.discard(_v9812_gate_key)", _VC)

    def test_reconnect_error_log_carries_failure_class(self):
        self.assertIn('"MTPROTO_RECONNECT_ERROR key=%s gen=%s exc=%s failure_class=%s: %s"', _GEN)


class TestVC9812StartupResponsiveness(unittest.TestCase):
    """§23: startup path unchanged (identity block is O(hash) only)."""

    def test_identity_block_has_no_blocking_io(self):
        """The v98.12 identity additions read only small local files —
        no network, no full dialog scans, no DB rebuilds (AST: no await
        inside the identity block)."""
        idx = _BOOT.find("DEPLOYMENT_IDENTITY — emit at startup")
        end = _BOOT.find("VC_ARCH_CONFIG_VALIDATED", idx)
        self.assertGreater(idx, 0)
        seg = _BOOT[idx:end]
        self.assertNotIn("await ", seg)
        self.assertNotIn("iter_dialogs", seg)
        self.assertNotIn("requests.", seg)


# ---------------------------------------------------------------------------
# §C — preservation guards (v98.11 resolver + prior invariants)
# ---------------------------------------------------------------------------
class TestVC9812Preservation(unittest.TestCase):
    """v98.11 fixes + prior v98.x invariants must remain intact."""

    def test_v9811_resolver_markers(self):
        for marker in (
            "ENTITY_RESOLVE_LOCAL_MISS", "_VC_RES_LOCAL_MISS",
            "rotation_probe", "_vc_client_scope",
            "ENTITY_RESOLVE_HASH_REFRESH", "ENTITY_RESOLVE_TYPE_KNOWN",
        ):
            self.assertIn(marker, _MT)

    def test_dialogs_index_preserved(self):
        self.assertIn("dialogs_index", _MT)

    def test_stale_cleanup_owner_guard_preserved(self):
        """v98.01 FIX-J: stale cleanup still resolves the OWNER backend."""
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_OWNER", _VC)
        self.assertIn("_vc_active_join_backends_by_chat.get(chat_id)", _VC)

    def test_join_rotation_ownership_preserved(self):
        # v99: the ownership writes moved to the canonical pipeline
        # (join dispatch records the OWNING backend per chat); the
        # CONTRACT (rotated ownership discoverable) is unchanged.
        self.assertIn("VC_ACTIVE_JOIN_BACKEND_SET", _VC)
        self.assertIn("VC_BACKEND_OWNER_SET", _VC)
        pipe = _read(_SRC / "vc_pipeline.py")
        self.assertIn("_vc_active_join_backends_by_chat[marked_chat] = backend", pipe)

    def test_verify_delegate_to_owner_backend_preserved(self):
        idx = _VC.find("async def verify_joined(self, chat_id: int, *,", 4000)
        # v99.09 test maintenance (FIX-C): 3600 -> 6000 — the form-aware
        # ownership lookup + delegation-guard comment block grew the
        # method's head; the delegation CONTRACT is unchanged.
        seg = _VC[idx:idx + 6000]
        self.assertIn("VC_VERIFY_DELEGATED", seg)
        # v99.09 test maintenance (FIX-C): the delegation call now carries
        # the one-hop loop-guard kwarg — `_owner_backend.verify_joined(
        # chat_id, _v9909_delegated=True)`. Contract unchanged: the
        # per-chat OWNER backend still receives the delegation.
        self.assertIn("_owner_backend.verify_joined(", seg)
        self.assertIn("_v9909_delegated=True", seg)

    def test_manual_join_ux_status_fn_contract(self):
        """§26: the shared executor accepts status_fn + emits the lifecycle."""
        idx = _VC.find("async def _vc_execute_manual_join(")
        seg = _VC[idx:idx + 16000]
        self.assertIn("status_fn: Any = None", seg)
        for stage in ("🔎 Finding the best account", "🎙️ Connecting to voice chat",
                      "⚡ Joining", "✅ Connected"):
            self.assertIn(stage, seg)
        self.assertIn("The bot will retry automatically.", seg)

    def test_telethon_join_wires_status_fn(self):
        self.assertIn("status_fn=_status_fn,", _VC)

    def test_botapi_join_wires_status_fn(self):
        self.assertIn("status_fn=(_botapi_status_fn if _v9812_use_status else None),", _BOOT)


# ---------------------------------------------------------------------------
# §D — deployment identity (§21/§22)
# ---------------------------------------------------------------------------
class TestVC9812DeploymentIdentity(unittest.TestCase):
    """Version, build stamp, supervisor, systemd 24/7 contract."""

    def test_version_is_v98_12(self):
        # v98.13 release bump: the package version moved to v98.13 (the
        # VC-JOIN-VERIFICATION release); the assertion tracks CURRENT.
        # v99.11 release bump: the stability-persistence release
        # (resource admission guard, leave policy, crash-loop guard).
        self.assertIn('__bot_version__ = "v99.11.1"', _INIT)
        self.assertNotIn('__bot_version__ = "v99.10"', _INIT)

    def test_identity_line_derives_from_package_version(self):
        self.assertIn("DEPLOYMENT_IDENTITY version={_v9812_pkg_version}", _BOOT)

    def test_build_stamp_verification_logic(self):
        self.assertIn("BUILD_IDENTITY_MISMATCH", _BOOT)
        self.assertIn("BUILD_IDENTITY_VERIFIED", _BOOT)
        self.assertIn("build_stamp.json", _BOOT)
        # missing stamp is a WARN-level state, never a crash (dev trees)
        self.assertIn("build_stamp.json not packaged", _BOOT)

    def test_identity_reports_supervisor_and_start_time(self):
        self.assertIn("supervisor={_v9812_supervisor}", _BOOT)
        self.assertIn("started_at=", _BOOT)

    def test_stamper_tool_contract(self):
        stamp = _read(str(_ROOT / "tools" / "stamp_build.py"))
        self.assertIn("build_stamp.json", stamp)
        self.assertIn("mtproto_generation.py", stamp)
        self.assertIn("__bot_version__", stamp)

    def test_systemd_unit_24_7_contract(self):
        unit = _read(str(_ROOT / "deploy" / "mediagrab.service"))
        self.assertIn("Restart=always", unit)
        self.assertIn("RestartSec=10", unit)
        self.assertIn("StartLimitIntervalSec=0", unit)
        self.assertIn("TimeoutStopSec=30", unit)
        # v99.11 release bump: the unit description tracks CURRENT.
        self.assertIn("v99.11", unit)

    def test_installer_script_contract(self):
        inst = _read(str(_ROOT / "deploy" / "install_supervisor.sh"))
        self.assertIn("daemon-reload", inst)
        self.assertIn("systemctl enable mediagrab", inst)

    def test_build_stamp_consistency(self):
        """The stamp is OPTIONAL (missing = documented dev-tree state) but
        when PRESENT it must be CONSISTENT: the version matches the package
        and every stamped module hash matches the actual file — exactly what
        bootstrap's startup verification recomputes (BUILD_IDENTITY_*)."""
        import hashlib
        import json
        stamp_path = _SRC / "build_stamp.json"
        if not stamp_path.exists():
            return  # dev tree without a stamp — documented, valid
        with open(stamp_path, encoding="utf-8") as f:
            stamp = json.load(f)
        # v99: the stamped version tracks the CURRENT artifact (v99.03 —
        # the deployment-hygiene release: RC-8 fail-fast, RC-9
        # self-heal, RC-10/11 account visibility, RC-12/13 noise+cycle
        # hygiene).
        self.assertEqual(stamp.get("version"), "v99.11.1")
        for rel, expected_sha in (stamp.get("modules") or {}).items():
            path = _SRC / rel
            self.assertTrue(path.exists(), f"stamped module missing: {rel}")
            actual = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
            self.assertEqual(str(expected_sha), actual,
                             f"stamp mismatch for {rel}: the packaged build "
                             f"was modified after stamping")


if __name__ == "__main__":
    unittest.main()
