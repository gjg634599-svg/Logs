"""v98.12-FINAL2 — SECOND-LAST-CHANCE forensic regression driver.

Runs the REAL production leave/join-state machinery with the REAL
voicechat.py imported via the stub loader AND the REAL
vc_state_coordinator.py (stdlib-only) — the §2 desync defect lived
exactly at the seam this harness now covers: the leave path updating the
registry/backend while the coordinator stayed JOINED.

FINAL-2 §12 matrix coverage at the driver level (the user's numbering):
  1  leave → coordinator synchronization (account A)          (F1)
  1' leave → coordinator synchronization (account B)          (F2)
  2  leave → rejoin (JOIN→LEAVE→JOIN reaches JOINED again)    (F3)
  2' JOIN→LEAVE→LEAVE (idempotent, no crash, LEFT preserved)  (F4)
  2'' JOIN→JOIN→LEAVE (duplicate join suppressed first)       (F5)
  3/4 second + concurrent Join-All (10 concurrent begins:
     exactly ONE op begins, 9 coalesced/busy; in-flight gate)  (F6)
  5/6 second process/startup + restart while already joined
     (registry persists, fresh coordinator; startup reconcile
     present → JOINED with ZERO join RPCs)                     (F7)
  6' restart + server-absent → registry LEFT pre-cleaned      (F8)
  7/11 fresh call identity after restart + stale identity +
     second startup (reconcile consults CURRENT identity;
     absent → LEFT; unknown → preserved)                       (F9)
  8  two-account isolation (A leave never touches B)          (F10)
  9  reconnect + Join race (stale-op reclaim → join allowed)  (F11)
  10 leave + Join race (serialized: one op, other busy)       (F12)
  8' quarantine bound (2 absent-after-join cycles → deferred;
     present-verify + explicit-user clear paths)               (F13)
  5'' repeated startup reconcile is single-flight per process (F14)

FINAL2-2 second-round additions (user §3-§7):
  §5 the five JOIN/LEAVE/RESTART sequences, account A          (G1)
  §5 the five JOIN/LEAVE/RESTART sequences, account B          (G2)
  §3 second PROCESS during P1 ops → InstanceGuard rejects;
     P1 mid-join-all/mid-reconnect state untouched             (G3)
  §7 A leaves VC1 → B@VC2 untouched (both directions)          (H1/H2)
  §7 A backend outage → B lifecycle unaffected; A preserved    (H3)
  §6 stale identity + restart → CURRENT identity wins          (I1)
  §6 stale identity + failed recheck + Join-All → preserve /
     clean / rejoin-with-FRESH-identity                        (I2)

Every case prints ``CASE <id>: PASS|FAIL — detail``; exit code = number
of failed cases.
"""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import sys
import time
import types

_HERE_DIR = __file__
_ROOT = _HERE_DIR.rsplit("/tests/", 1)[0]
_SRC = f"{_ROOT}/mediagrab_bot"

logging.basicConfig(level=logging.INFO, stream=sys.stdout,
                    format="%(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("final2drv")


class _Stub:
    """Universal permissive stub (callable/awaitable/attribute-safe)."""
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k): return _Stub()
    def __await__(self):
        async def _noop(): return _Stub()
        return _noop().__await__()
    def __getattr__(self, name): return _Stub()
    def __iter__(self): return iter(())
    def __bool__(self): return False
    def __or__(self, o): return self
    def __ror__(self, o): return self
    def __fspath__(self): return "/tmp/vcimport"
    def __int__(self): return 0
    def __index__(self): return 0
    def __str__(self): return ""
    def __float__(self): return 0.0
    def __format__(self, spec): return ""


def _mod(name, attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


def _attrs(*names):
    return {n: _Stub() for n in names}


def import_voicechat():
    """Stub-import the REAL voicechat.py + REAL vc_state_coordinator.py."""
    logging.getLogger("mediagrap").addHandler(logging.NullHandler())
    _mod("httpx", _attrs("AsyncClient", "Client"))
    _mod("telegram", _attrs("Update", "InlineKeyboardButton", "InlineKeyboardMarkup"))
    _mod("telegram.ext", _attrs("ContextTypes", "filters"))
    _mod("telegram.error", _attrs(
        "BadRequest", "Forbidden", "NetworkError", "TimedOut", "RetryAfter"))
    _mod("pytgcalls", _attrs("PyTgCalls"))  # import-success only (lazy import)
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [_SRC]
    sys.modules["mediagrab_bot"] = pkg
    # v98.13: voicechat now also imports _env_float from config (the
    # join-time verification gate + DC-backoff env knobs).
    _mod("mediagrab_bot.config", _attrs("_env_int", "_env_float", "config"))
    _mod("mediagrab_bot.text_utils", _attrs("md_escape", "html_escape"))
    _mod("mediagrab_bot.media_processor", _attrs(
        "download_slot", "with_retries", "retrying", "send_file_back",
        "notify", "safe_unlink"))
    _mod("mediagrab_bot.ai_modes", _attrs(
        "ACCEPTS", "MODE_LABELS", "MODE_ORDER", "PROMPTS", "build_prompt",
        "NORMALISERS", "normalise", "accepts", "media_kind_for",
        "render_result"))
    _mod("mediagrab_bot.frame_extractor", _attrs(
        "extract_frames", "FrameExtractionError", "_FFMPEG", "_FFPROBE"))
    _mod("mediagrab_bot.mtproto", _attrs(
        # v98.13: VCTransportError must be a REAL class — voicechat now
        # defines class VCJoinUnverifiedError(VCTransportError) at module
        # import time (the join-time verification gate's typed error).
        "_redact_ah", "_vc_entity_cache",
        "_vc_entity_cache_by_client", "_user_entity_cache",
        "_USER_ENTITY_CACHE_FILE", "_VC_ACCESS_HASH_FILE",
        "resolve_entity_full", "resolve_vc_entity", "_vc_client_scope",
        "resolve_forwarded_sender", "resolve_forwarded_sender_full",
        "resolve_user_id_full", "resolve_across_accounts",
        "profile_count_posts", "profile_download_photo",
        "mtproto_get_client", "mtproto_get_client_for_role",
        "mtproto_call_with_retry", "mtproto_is_available",
        "mtproto_is_started", "get_userbot_cluster", "get_cluster_router",
        "get_routed_client", "get_vc_pool", "VoiceChatAccountPool",
        "UserbotCluster", "UserbotClusterRouter", "profile_resolve_entity",
        "_get_current_vc_account_id", "ROLE_VOICE_CHAT",
        "STATUS_CONNECTED", "STATUS_CONNECTION_FAILED", "STATUS_FLOODWAIT",
        "STATUS_HEALTHY", "STATUS_UNAUTHORIZED",
        "_flush_access_hash_persistence", "_flush_user_entity_persistence"))
    class _VCTransportErrorStub(Exception):
        pass
    sys.modules["mediagrab_bot.mtproto"].VCTransportError = _VCTransportErrorStub
    _mod("mediagrab_bot.talkative_hooks", _attrs(
        "_adaptive_check_stale", "_adaptive_claim_response",
        "_adaptive_release_response", "_adaptive_detect_language",
        "_adaptive_route_model", "_adaptive_response_length_guidance",
        "_talkative_mode_allows_vc", "_adaptive_get_context",
        "_adaptive_engagement_score", "_talkative_build_system_prompt",
        "talkative_generate", "talkative_get_mode"))
    _mod("mediagrab_bot.diag_hooks", _attrs("v85_diag"))
    _mod("mediagrab_bot.db_layer", _attrs(
        "repo", "get_db", "_db", "vc_groups_active", "vc_groups_all",
        "vc_groups_keyset", "vc_groups_keyset_stream", "vc_upsert_group",
        "vc_add_visit", "vc_update_visit", "vc_recent_visits",
        "vc_get_settings", "vc_update_settings", "vc_get_tour_state",
        "vc_save_tour_state", "vc_visit_count", "vc_visited_group_ids_since",
        "vc_group_count", "talkative_add_memory",
        "talkative_effective_provider", "talkative_effective_settings",
        "vc_groups_fresh_active", "vc_groups_stale_active",
        "vc_knowledge_store_active", "vc_knowledge_mark_inactive"))
    _mod("mediagrab_bot.utils_real", _attrs(
        "extension_category", "get_bot", "human_size", "is_available",
        "periodic_cleanup", "register_bot", "remove_path",
        "safe_edit_message_text", "safe_filename", "safe_reply_text",
        "safe_send_document", "safe_send_message", "supervised_create_task",
        "telegram_media_type", "unique_path", "_active_tasks",
        "_redact_secrets", "_ui_check", "_ui_claim", "_ui_invalidate",
        "_ui_release", "_ui_owners", "_userbot_id"))
    _mod("mediagrab_bot.states", _attrs(
        "IDLE", "set_state", "get_state", "reset", "set_tool", "get_tool",
        "set_last_download", "get_last_download", "AWAIT_VC_CHECK_TARGET",
        "AWAIT_VC_COOLDOWN", "AWAIT_VC_JOIN_TARGET", "AWAIT_VC_STAY"))
    _mod("mediagrab_bot.ui_keyboards", _attrs(
        "back_only", "cancel_back", "vc_menu", "vc_manual_menu",
        "vc_settings_menu", "vc_dashboard_menu", "vc_dashboard_back_menu",
        "vc_dashboard_text", "vc_dashboard_errors_menu",
        "vc_dashboard_logs_menu", "vc_stay_presets_menu",
        "vc_cooldown_presets_menu"))
    _mod("mediagrab_bot.ai_analyzer", _attrs(
        "_read_bytes", "_run_in_thread", "_get_client"))
    _mod("mediagrab_bot.join_all_worker", _attrs(
        "CircuitBreaker", "CircuitBreakerState", "CancellationToken",
        "CheckpointManager", "IllegalStateTransitionError",
        "JoinAllWorkerState", "RetryPolicy", "WorkerStateMachine",
        "generate_run_id", "is_backend_wide_error", "is_interdc_error",
        "is_transport_dc_timeout", "parse_floodwait_seconds"))
    _mod("mediagrab_bot.distributed_join", _attrs(
        "distributed_assign_target", "distributed_get_healthy_accounts",
        "distributed_mark_failure", "distributed_mark_success",
        "distributed_plan", "distributed_reset", "distributed_account_loads",
        "vc_assignment_get", "vc_assignment_release",
        "vc_assignment_release_account", "vc_assignment_snapshot"))
    _mod("mediagrab_bot.vc_op_scheduler", _attrs(
        "VCOpRequest", "VCOperationScheduler", "OpStatus",
        "get_vc_scheduler"))
    # REAL stdlib-only modules — INCLUDING the REAL coordinator (the §2
    # desync lived at the voicechat↔coordinator seam).
    for name, fname in (
            ("mediagrab_bot.vc_hooks", "vc_hooks.py"),
            ("mediagrab_bot.vc_architecture", "vc_architecture.py"),
            ("mediagrab_bot.vc_state_coordinator",
             "vc_state_coordinator.py")):
        spec = importlib.util.spec_from_file_location(name, f"{_SRC}/{fname}")
        m = importlib.util.module_from_spec(spec)
        sys.modules[name] = m
        spec.loader.exec_module(m)
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.voicechat", f"{_SRC}/voicechat.py")
    vc = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.voicechat"] = vc
    spec.loader.exec_module(vc)
    return vc


class FakePyTgCalls:
    """PyTgCalls 2.3.3 semantics: marked-id container + silent no-ops."""
    def __init__(self):
        self.calls: dict[int, object] = {}
        self.api_log: list[tuple[str, object]] = []

    async def leave_call(self, chat_id):
        self.api_log.append(("leave_call", chat_id))
        self.calls.pop(chat_id, None)

    async def leave_group_call(self, chat_id):
        self.api_log.append(("leave_group_call", chat_id))
        self.calls.pop(chat_id, None)

    async def stop_call(self, chat_id):
        self.api_log.append(("stop_call", chat_id))
        self.calls.pop(chat_id, None)

    async def leave_current_call(self):
        self.api_log.append(("leave_current_call", None))
        if self.calls:
            self.calls.pop(next(iter(self.calls)))


RAW = 1922822605
MARKED = -1001922822605
RAW_B = 2410827648          # account-B-owned chat (isolation case)
MARKED_B = -1002410827648


class World:
    """Fake multi-account world: global + account A + account B backends."""

    @property
    def coord(self):
        return self.vc.get_vc_coordinator()

    def __init__(self, vc):
        self.vc = vc
        self.global_b = vc.PyTgCallsBackend()
        self.global_b._started = True
        self.global_b._leave_strategy = "leave_call"
        self.global_b._pytgcalls = FakePyTgCalls()
        vc._vc_backend = self.global_b
        self.a_b = vc.vc_get_backend(account_id="acc_A")
        self.a_b._started = True
        self.a_b._leave_strategy = "leave_call"
        self.a_b._pytgcalls = FakePyTgCalls()
        self.b_b = vc.vc_get_backend(account_id="acc_B")
        self.b_b._started = True
        self.b_b._leave_strategy = "leave_call"
        self.b_b._pytgcalls = FakePyTgCalls()
        # coord is a PROPERTY (post-restart the singleton is replaced by
        # _simulate_restart — a stale captured instance would diverge from
        # the REAL vc_leave_target path, which resolves the singleton at
        # call time; proven necessary by the FINAL2 stress world).
        vc._vc_participations.clear()
        vc._vc_active_join_backends_by_chat.clear()
        vc._vc_target_cooldowns.clear()
        vc._vc_join_all_leave_block_active = False
        # FINAL2 state reset (quarantine + startup reconcile)
        vc._vc_join_quarantine_until.clear()
        vc._vc_server_absent_after_join.clear()
        vc._vc_startup_reconcile_state.update(
            {"done": False, "started_at": 0.0, "records": 0, "present": 0,
             "absent": 0, "unknown": 0, "errors": 0})

    def join_on(self, backend, raw=RAW):
        """Simulate a Join-All join: container object under MARKED id +
        ownership + registry record + coordinator JOINED (mirrors the
        join() → VC_BACKEND_OWNER_SET → registry → coordinator chain)."""
        marked = -1000000000000 - raw if raw > 0 else raw
        backend._pytgcalls.calls[marked] = object()
        self.vc._vc_active_join_backends_by_chat[marked] = backend
        self.vc._vc_active_join_backends_by_chat[raw] = backend
        rec = self.vc.VCParticipationState(
            chat_id=raw, state="joined", request_accepted=True,
            intentional=True, locally_tracked=True,
            account_id=backend._account_id or None)
        self.vc._vc_participations[raw] = rec
        # The REAL join path completes the coordinator op with new_state
        # joined (join_all loop: _vc_coord_complete_join success=True).
        self.coord._chat_states[raw] = self.vc.VCChatState.JOINED
        return rec


CASES: list = []


def case(fn):
    CASES.append((fn.__name__, fn))
    return fn


# ---------------------------------------------------------------------------
# F1/F2 — §12-1: leave → coordinator synchronization (A and B)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# F1/F2 — §12-1: leave → coordinator synchronization (A and B)
# ---------------------------------------------------------------------------
def _leave_sync_check(w, backend, raw):
    marked = -1000000000000 - raw if raw > 0 else raw
    before = w.coord.get_state(raw)
    outcome = w.vc.vc_leave_target(raw)
    outcome = asyncio.get_event_loop().run_until_complete(outcome) \
        if not asyncio.iscoroutine(outcome) else None
    return before, outcome, marked


async def _run_leave_sync(w, backend, raw, label):
    before = w.coord.get_state(raw).value
    outcome = await w.vc.vc_leave_target(raw)
    after = w.coord.get_state(raw).value
    rec = w.vc._vc_participations.get(raw)
    marked = -1000000000000 - raw if raw > 0 else raw
    ok = (
        outcome == "success"
        and before == "joined"
        # backend/container absent under BOTH forms
        and marked not in backend._pytgcalls.calls
        and raw not in backend._pytgcalls.calls
        and (w.vc._vc_active_join_backends_by_chat.get(marked) is None)
        and (w.vc._vc_active_join_backends_by_chat.get(raw) is None)
        # registry gone/left
        and (rec is None or rec.state == "left")
        # THE §2 INVARIANT: coordinator is NOT JOINED after confirmed leave
        and after not in ("joined", "active", "verifying")
    )
    # Direct proof via the coordinator's own begin_operation (the exact
    # mechanism that produced the production already_joined skip).
    ok2, op, reason = await w.coord.begin_operation(
        raw, "join", source="final2_post_leave")
    join_permitted = ok2 and op is not None
    if op is not None:
        await w.coord.complete_operation(raw, op, success=True,
                                         new_state=w.vc.VCChatState.JOINED)
    detail = (f"account={backend._account_id or 'global'} outcome={outcome} "
              f"coord {before}→{after} rec={rec.state if rec else 'gone'} "
              f"join_permitted={join_permitted}")
    return ok and join_permitted, detail


@case
async def F1_leave_coordinator_sync_account_A():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    ok, detail = await _run_leave_sync(w, w.a_b, RAW, "A")
    print(f"CASE F1: {'PASS' if ok else 'FAIL'} — {detail}")
    return ok


@case
async def F2_leave_coordinator_sync_account_B():
    w = World(VC)
    w.join_on(w.b_b, RAW)
    ok, detail = await _run_leave_sync(w, w.b_b, RAW, "B")
    print(f"CASE F2: {'PASS' if ok else 'FAIL'} — {detail}")
    return ok


# ---------------------------------------------------------------------------
# F3 — §12-2: JOIN → LEAVE → JOIN reaches JOINED again (full cycle)
# ---------------------------------------------------------------------------
@case
async def F3_leave_then_rejoin_cycle():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    out1 = await w.vc.vc_leave_target(RAW)
    # after confirmed leave a NEW join is accepted and reaches JOINED.
    ok2, op, reason = await w.coord.begin_operation(RAW, "join",
                                                    source="final2_rejoin")
    joined_again = False
    if ok2 and op is not None:
        w.join_on(w.a_b, RAW)   # the rejoin (container+registry+coord)
        await w.coord.complete_operation(
            RAW, op, success=True, new_state=w.vc.VCChatState.JOINED)
        joined_again = w.coord.get_state(RAW).value == "joined"
    ok = out1 == "success" and ok2 and joined_again
    print(f"CASE F3: {'PASS' if ok else 'FAIL'} — leave={out1} "
          f"rejoin_begin={ok2}({reason}) joined_again={joined_again}")
    return ok


# ---------------------------------------------------------------------------
# F4 — §12-2': JOIN → LEAVE → LEAVE (idempotent second leave)
# ---------------------------------------------------------------------------
@case
async def F4_leave_leave_idempotent():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    out1 = await w.vc.vc_leave_target(RAW)
    out2 = await w.vc.vc_leave_target(RAW)   # no record, no container
    coord = w.coord.get_state(RAW).value
    ok = (out1 == "success"
          and out2 in ("success", "unknown", "blocked_during_join_all")
          and coord not in ("joined", "active", "verifying"))
    print(f"CASE F4: {'PASS' if ok else 'FAIL'} — leave1={out1} "
          f"leave2={out2} coord={coord}")
    return ok


# ---------------------------------------------------------------------------
# F5 — §12-2'': JOIN → JOIN → LEAVE (duplicate join suppressed first)
# ---------------------------------------------------------------------------
@case
async def F5_join_join_leave():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    ok1, op1, r1 = await w.coord.begin_operation(RAW, "join",
                                                 source="final2_dup1")
    if op1 is not None:
        await w.coord.complete_operation(RAW, op1, success=True,
                                         new_state=w.vc.VCChatState.JOINED)
    ok2, op2, r2 = await w.coord.begin_operation(RAW, "join",
                                                 source="final2_dup2")
    dup_suppressed = (not ok2) and r2.startswith("already_")
    out = await w.vc.vc_leave_target(RAW)
    coord_after = w.coord.get_state(RAW).value
    ok = dup_suppressed and out == "success" and \
        coord_after not in ("joined", "active", "verifying")
    print(f"CASE F5: {'PASS' if ok else 'FAIL'} — dup_join={r2} "
          f"leave={out} coord_after={coord_after}")
    return ok


# ---------------------------------------------------------------------------
# F6 — §12-3/4: second + concurrent Join-All (10 concurrent begins)
# ---------------------------------------------------------------------------
@case
async def F6_concurrent_join_single_flight():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    # make the target ELIGIBLE (registry left + coordinator IDLE): 10
    # concurrent Join-All triggers then race for the SAME join.
    w.vc._vc_participations[RAW].state = "left"
    w.coord._chat_states[RAW] = w.vc.VCChatState.IDLE
    # 10 concurrent coordinator begins for the SAME chat: exactly ONE
    # begins; the rest coalesce (idempotent same-direction) — the exact
    # Scenario-A guarantee (no double-join execution).
    results = await asyncio.gather(*[
        w.coord.begin_operation(RAW, "join", source=f"final2_conc_{i}")
        for i in range(10)])
    began = [r for r in results if r[0]]
    coalesced = [r for r in results if not r[0]
                 and r[2].startswith("coalesced:")]
    # also the in-flight gate (the join-all worker's own guard)
    infs = await asyncio.gather(*[
        w.vc._vc_acquire_target_inflight(RAW) for _ in range(5)])
    acquired = list(infs).count(True)
    w.vc._vc_release_target_inflight(RAW)
    for _ok, op, _r in results:
        if op is not None:
            await w.coord.complete_operation(
                RAW, op, success=True, new_state=w.vc.VCChatState.JOINED)
    ok = len(began) == 1 and len(coalesced) == 9 and acquired == 1
    print(f"CASE F6: {'PASS' if ok else 'FAIL'} — began={len(began)} "
          f"coalesced={len(coalesced)} inflight_acquired={acquired}")
    return ok


# ---------------------------------------------------------------------------
# F7/F8/F9 — §12-5/6/7/11: second process/startup + fresh identity
# ---------------------------------------------------------------------------
def _simulate_restart(vc):
    """Process-2 world: SAME persistent registry, FRESH in-memory state
    (empty containers, empty ownership, EMPTY coordinator, empty
    quarantine) — exactly what pid 2800 inherited at 05:18:37."""
    import mediagrab_bot.vc_state_coordinator as _coord_mod
    _coord_mod._vc_coordinator = _coord_mod.VCChatCoordinator()
    for be in (vc._vc_backend, vc.vc_get_backend(account_id="acc_A"),
               vc.vc_get_backend(account_id="acc_B")):
        if getattr(be, "_pytgcalls", None) is not None:
            be._pytgcalls.calls.clear()
    for k in list(vc._vc_active_join_backends_by_chat.keys()):
        vc._vc_active_join_backends_by_chat.pop(k, None)
    vc._vc_target_cooldowns.clear()
    vc._vc_join_quarantine_until.clear()
    vc._vc_server_absent_after_join.clear()


@case
async def F7_restart_present_no_join_rpcs():
    """Restart while already joined + present: startup reconcile marks
    JOINED with ZERO JoinGroupCall-equivalent RPCs (the flood-budget
    saver) and a later explicit join for it is idempotent-skipped."""
    w = World(VC)
    rec = w.join_on(w.a_b, RAW)
    _simulate_restart(VC)
    # fresh coordinator: empty (post-restart truth)
    assert VC.get_vc_coordinator() is not None
    coord_before = VC.get_vc_coordinator().get_state(RAW).value

    async def fake_verify(chat_id):
        return {"chat_id": chat_id, "locally_tracked": False,
                "telegram_participation": "present",
                "call_id": rec.call_id or 0}

    real_verify = VC.vc_verify_target
    VC.vc_verify_target = fake_verify
    try:
        summary = await VC.vc_startup_reconcile_participations()
    finally:
        VC.vc_verify_target = real_verify
    coord_after = VC.get_vc_coordinator().get_state(RAW).value
    reg_state = VC._vc_participations[RAW].state
    joins_issued = len(w.a_b._pytgcalls.calls)  # nothing re-joined
    ok2, op, reason = await VC.get_vc_coordinator().begin_operation(
        RAW, "join", source="final2_after_restart")
    if op is not None:
        await VC.get_vc_coordinator().complete_operation(
            RAW, op, success=True, new_state=VC.VCChatState.JOINED)
    ok = (coord_before == "idle" and coord_after == "joined"
          and reg_state == "joined" and joins_issued == 0
          and summary.get("present") == 1
          and (not ok2 and reason.startswith("already_")))
    print(f"CASE F7: {'PASS' if ok else 'FAIL'} — coord {coord_before}→"
          f"{coord_after} registry={reg_state} joins_issued={joins_issued} "
          f"summary_present={summary.get('present')} post_join={reason}")
    return ok


@case
async def F8_restart_absent_precleaned_left():
    """Restart + server-absent (kicked/ended while dead): registry LEFT +
    coordinator LEFT BEFORE any join-all attempt (no wasted
    JoinGroupCall), and a new join is PERMITTED (eligible)."""
    w = World(VC)
    w.join_on(w.a_b, RAW)
    _simulate_restart(VC)

    async def fake_verify(chat_id):
        return {"chat_id": chat_id, "locally_tracked": False,
                "telegram_participation": "absent", "call_id": 0}

    real_verify = VC.vc_verify_target
    VC.vc_verify_target = fake_verify
    try:
        summary = await VC.vc_startup_reconcile_participations()
    finally:
        VC.vc_verify_target = real_verify
    coord_after = VC.get_vc_coordinator().get_state(RAW).value
    reg_state = VC._vc_participations[RAW].state
    ok2, op, reason = await VC.get_vc_coordinator().begin_operation(
        RAW, "join", source="final2_rejoin_after_absent")
    if op is not None:
        await VC.get_vc_coordinator().complete_operation(
            RAW, op, success=True, new_state=VC.VCChatState.JOINED)
    ok = (coord_after in ("left", "idle") and reg_state == "left"
          and summary.get("absent") == 1 and ok2)
    print(f"CASE F8: {'PASS' if ok else 'FAIL'} — coord={coord_after} "
          f"registry={reg_state} absent={summary.get('absent')} "
          f"join_permitted={ok2}")
    return ok


@case
async def F9_restart_unknown_preserved():
    """Restart + weak verification (unknown): registry joined PRESERVED
    (never destructive) — the Join-All stale-record repair owns the
    rejoin; the fresh-identity consultation is unchanged."""
    w = World(VC)
    w.join_on(w.b_b, RAW)
    _simulate_restart(VC)

    async def fake_verify(chat_id):
        # CURRENT identity visible (fresh detection), participation
        # inconclusive → unknown (the §5 weak-evidence path).
        return {"chat_id": chat_id, "locally_tracked": False,
                "telegram_participation": "unknown",
                "call_id": -999111222}

    real_verify = VC.vc_verify_target
    VC.vc_verify_target = fake_verify
    try:
        summary = await VC.vc_startup_reconcile_participations()
    finally:
        VC.vc_verify_target = real_verify
    reg_state = VC._vc_participations[RAW].state
    coord_state = VC.get_vc_coordinator().get_state(RAW).value
    ok = (reg_state == "joined" and summary.get("unknown") == 1
          and coord_state == "idle")   # not seeded — unknown preserves
    print(f"CASE F9: {'PASS' if ok else 'FAIL'} — registry={reg_state} "
          f"unknown={summary.get('unknown')} coord={coord_state}")
    return ok


# ---------------------------------------------------------------------------
# F10 — §12-8: two-account isolation (A leave never touches B)
# ---------------------------------------------------------------------------
@case
async def F10_two_account_isolation():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    w.join_on(w.b_b, RAW_B)
    out_a = await w.vc.vc_leave_target(RAW)
    b_container = MARKED_B in w.b_b._pytgcalls.calls
    b_rec = w.vc._vc_participations.get(RAW_B)
    b_coord = w.coord.get_state(RAW_B).value
    b_owner = w.vc._vc_active_join_backends_by_chat.get(MARKED_B)
    ok = (out_a == "success" and b_container
          and b_rec is not None and b_rec.state == "joined"
          and b_coord == "joined" and b_owner is w.b_b
          # A's chat: all three legs cleared
          and w.coord.get_state(RAW).value not in ("joined", "active",
                                                   "verifying")
          and MARKED not in w.a_b._pytgcalls.calls)
    print(f"CASE F10: {'PASS' if ok else 'FAIL'} — A_leave={out_a} "
          f"B_container={b_container} B_reg={b_rec.state if b_rec else '?'} "
          f"B_coord={b_coord} B_owner_intact={b_owner is w.b_b}")
    return ok


# ---------------------------------------------------------------------------
# F11 — §12-9: reconnect + join race (stale-op reclaim → join allowed)
# ---------------------------------------------------------------------------
@case
async def F11_reconnect_join_race_stale_reclaim():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    w.coord._chat_states[RAW] = VC.VCChatState.JOINING
    # an op that exceeds its deadline (e.g. a wedged join during a
    # reconnect storm) must be RECLAIMED, not block the chat forever.
    ok1, op1, r1 = await w.coord.begin_operation(
        RAW, "join", deadline=0.05, source="final2_wedged")
    await asyncio.sleep(0.08)   # exceed the deadline
    ok2, op2, r2 = await w.coord.begin_operation(
        RAW, "join", source="final2_after_reclaim")
    if op2 is not None:
        await w.coord.complete_operation(RAW, op2, success=True,
                                         new_state=w.vc.VCChatState.JOINED)
    ok = ok1 and ok2 and r2 == "ok"
    print(f"CASE F11: {'PASS' if ok else 'FAIL'} — first={ok1} "
          f"reclaimed_second={ok2} reason={r2}")
    return ok


# ---------------------------------------------------------------------------
# F12 — §12-10: leave + join race (serialized: one op wins, other busy)
# ---------------------------------------------------------------------------
@case
async def F12_leave_join_race_serialized():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    lv = w.coord.begin_operation(RAW, "leave", source="final2_race_lv")
    jn = w.coord.begin_operation(RAW, "join", source="final2_race_jn")
    ok_lv, op_lv, r_lv = await lv
    ok_jn, op_jn, r_jn = await jn
    # exactly one op is active; the other is busy (serialized per chat)
    one_active = (op_lv is None) != (op_jn is None)
    if op_lv is not None:
        await w.coord.complete_operation(RAW, op_lv, success=True,
                                         new_state=w.vc.VCChatState.LEFT)
    if op_jn is not None:
        await w.coord.complete_operation(op_jn, success=True,
                                         new_state="joined")
    ok = one_active and (r_lv.startswith("busy:") or r_jn.startswith("busy:"))
    print(f"CASE F12: {'PASS' if ok else 'FAIL'} — leave={r_lv} "
          f"join={r_jn} one_active={one_active}")
    return ok


# ---------------------------------------------------------------------------
# F13 — FIX-TQ: quarantine bound (thrash → deferred → cleared)
# ---------------------------------------------------------------------------
@case
async def F13_quarantine_bounds_thrash():
    w = World(VC)
    w.join_on(w.a_b, RAW)
    w.vc._vc_participations[RAW].state = "left"
    # two server-absent-after-join cycles → quarantine set
    VC._vc_join_quarantine_record_absent(RAW)
    VC._vc_join_quarantine_record_absent(RAW)
    quarantined = VC._vc_join_quarantined(RAW, source="final2")
    # capacity-join consult defers. The quarantine check sits AFTER the
    # transient in-flight gate BY DESIGN (a join already in progress must
    # be allowed to finish; the NEXT attempt is what the quarantine
    # defers). Prove BOTH orderings honestly: gate properly held →
    # "in_flight"; gate free → the quarantine check fires →
    # "quarantined_server_absent". (The previous form called the async
    # gate WITHOUT await — a dead coroutine + RuntimeWarning that primed
    # nothing; it is now exercised for real.)
    gate_held = await VC._vc_acquire_target_inflight(RAW)
    cap_gated = await VC._vc_capacity_aware_join(
        RAW, title="T", call_id=-1, access_hash=1, source="final2")
    VC._vc_release_target_inflight(RAW)
    cap = await VC._vc_capacity_aware_join(
        RAW, title="T", call_id=-1, access_hash=1, source="final2")
    # watcher consult: quarantined → skip (True)
    watch_skip = VC._vc_join_quarantined(RAW, source="watcher")
    # present-verification clears it
    VC._vc_join_quarantine_clear(RAW, reason="targeted_query_present")
    cleared = not VC._vc_join_quarantined(RAW, source="final2")
    ok = (quarantined and cap == "quarantined_server_absent"
          and gate_held and cap_gated == "in_flight"
          and watch_skip and cleared)
    print(f"CASE F13: {'PASS' if ok else 'FAIL'} — quarantined={quarantined} "
          f"capacity={cap} in_flight_when_gated={cap_gated} "
          f"watch_skip={watch_skip} cleared={cleared}")
    return ok


# ---------------------------------------------------------------------------
# F14 — §12-5'': startup reconcile is single-flight per process
# ---------------------------------------------------------------------------
@case
async def F14_startup_reconcile_single_flight():
    VC._vc_startup_reconcile_state.update({"done": False})
    # seed one joined record so the loop has work to do
    rec14 = VC.VCParticipationState(
        chat_id=RAW_B, state="joined", request_accepted=True,
        intentional=True, locally_tracked=True, account_id="acc_B")
    VC._vc_participations[RAW_B] = rec14
    calls = {"n": 0}

    async def fake_verify(chat_id):
        calls["n"] += 1
        return {"chat_id": chat_id, "locally_tracked": False,
                "telegram_participation": "present", "call_id": 1}

    real_verify = VC.vc_verify_target
    VC.vc_verify_target = fake_verify
    try:
        s1, s2 = await asyncio.gather(
            VC.vc_startup_reconcile_participations(),
            VC.vc_startup_reconcile_participations())
    finally:
        VC.vc_verify_target = real_verify
    ok = (s1.get("done") and s2.get("done")
          and calls["n"] == 1
          and VC._vc_startup_reconcile_state.get("records") == 1)
    print(f"CASE F14: {'PASS' if ok else 'FAIL'} — verify_calls={calls['n']} "
          f"records={VC._vc_startup_reconcile_state.get('records')}")
    return ok


# ---------------------------------------------------------------------------
# FINAL2-2 §5 helper: startup reconcile with per-chat fake outcomes
# ---------------------------------------------------------------------------
async def _reconcile_with(participation, current_call_id=0):
    """Run the REAL vc_startup_reconcile_participations with a per-chat
    fake vc_verify_target outcome map (F7-F9 harness pattern)."""
    async def fake_verify(chat_id):
        return {"chat_id": chat_id, "locally_tracked": False,
                "telegram_participation": participation.get(
                    int(chat_id), "unknown"),
                "call_id": current_call_id}
    real_verify = VC.vc_verify_target
    VC.vc_verify_target = fake_verify
    VC._vc_startup_reconcile_state.update(
        {"done": False, "started_at": 0.0, "records": 0, "present": 0,
         "absent": 0, "unknown": 0, "errors": 0})
    try:
        return await VC.vc_startup_reconcile_participations()
    finally:
        VC.vc_verify_target = real_verify


async def _join_permitted_reaches_joined(raw, source):
    """A new JOIN must be PERMITTED (never a stale already_joined) and
    complete JOINED through the REAL coordinator."""
    ok_begin, op, reason = await VC.get_vc_coordinator().begin_operation(
        raw, "join", source=source)
    if op is not None:
        await VC.get_vc_coordinator().complete_operation(
            raw, op, success=True, new_state=VC.VCChatState.JOINED)
    return ok_begin, VC.get_vc_coordinator().get_state(raw).value, reason


# ---------------------------------------------------------------------------
# G1/G2 — FINAL2-2 §5: the five JOIN/LEAVE/RESTART sequences, per account
# ---------------------------------------------------------------------------
RAW_G = 1922823500      # sequence chat ids (account A): +1..+5
RAW_GB = 1922823600     # sequence chat ids (account B): +1..+5


async def _run_sequences(backend, base, label):
    """§5 mandatory combinations for ONE account on five distinct chats:
    S1 JOIN→RESTART→LEAVE→JOIN; S2 JOIN→LEAVE→RESTART→JOIN;
    S3 JOIN→RESTART→JOIN; S4 JOIN→LEAVE→JOIN; S5 JOIN→RESTART→LEAVE."""
    res = {}

    # --- S1: JOIN → RESTART → LEAVE → JOIN -----------------------------
    s1 = base + 1
    w = World(VC)
    w.join_on(backend, s1)
    _simulate_restart(VC)
    await _reconcile_with({s1: "present"})
    out_leave = await w.vc.vc_leave_target(s1)   # post-restart owner path
    coord_after_leave = w.coord.get_state(s1).value
    reg_after_leave = (VC._vc_participations.get(s1) is None
                       or VC._vc_participations[s1].state == "left")
    ok_join, coord_joined, _r = await _join_permitted_reaches_joined(
        s1, "final2_S1_rejoin")
    res["S1"] = (out_leave == "success"
                 and coord_after_leave not in ("joined", "active", "verifying")
                 and reg_after_leave
                 and ok_join and coord_joined == "joined")

    # --- S2: JOIN → LEAVE → RESTART → JOIN ------------------------------
    s2 = base + 2
    w = World(VC)
    w.join_on(backend, s2)
    out_leave2 = await w.vc.vc_leave_target(s2)
    _simulate_restart(VC)                        # registry already left
    summary = await _reconcile_with({})          # no joined records left
    ok_join2, coord_joined2, _r2 = await _join_permitted_reaches_joined(
        s2, "final2_S2_rejoin")
    res["S2"] = (out_leave2 == "success" and summary.get("records") == 0
                 and ok_join2 and coord_joined2 == "joined")

    # --- S3: JOIN → RESTART → JOIN (Join-All still works) ---------------
    s3 = base + 3
    w = World(VC)
    w.join_on(backend, s3)
    _simulate_restart(VC)
    await _reconcile_with({s3: "present"})
    # join-all for the still-joined chat: idempotent SKIP, 0 join RPCs
    r_ja = await VC._vc_capacity_aware_join(
        s3, title="T", call_id=1, access_hash=1, source="final2_S3")
    joins_issued = sum(len(be._pytgcalls.calls)
                       for be in (w.global_b, w.a_b, w.b_b))
    # a FRESH chat still joins normally (later Join-All works)
    s3b = base + 30
    ok_j3, coord_j3, _r3 = await _join_permitted_reaches_joined(
        s3b, "final2_S3_fresh")
    res["S3"] = (r_ja == "already_joined" and joins_issued == 0
                 and w.coord.get_state(s3).value == "joined"
                 and ok_j3 and coord_j3 == "joined")

    # --- S4: JOIN → LEAVE → JOIN (immediate + post-cooldown) ------------
    s4 = base + 4
    w = World(VC)
    w.join_on(backend, s4)
    await w.vc.vc_leave_target(s4)
    deferred_immediate = VC._v9809_leave_rejoin_deferred(
        s4, run_id="final2_S4")  # auto join-all deferred (5-min cooldown)
    ok_j4, coord_j4, reason4 = await _join_permitted_reaches_joined(
        s4, "final2_S4_manual")   # explicit join path: PERMITTED now
    VC._vc_target_cooldowns.clear()   # simulate cooldown expiry
    deferred_expired = (not VC._v9809_leave_rejoin_deferred(
        s4, run_id="final2_S4"))
    res["S4"] = (deferred_immediate and ok_j4 and coord_j4 == "joined"
                 and deferred_expired)

    # --- S5: JOIN → RESTART → LEAVE --------------------------------------
    s5 = base + 5
    w = World(VC)
    w.join_on(backend, s5)
    _simulate_restart(VC)
    await _reconcile_with({s5: "present"})
    out_leave5 = await w.vc.vc_leave_target(s5)
    coord5 = w.coord.get_state(s5).value
    reg5 = (VC._vc_participations.get(s5) is None
            or VC._vc_participations[s5].state == "left")
    res["S5"] = (out_leave5 == "success"
                 and coord5 not in ("joined", "active", "verifying")
                 and reg5)

    ok_all = all(res.values())
    print(f"SEQ {label}: S1={res['S1']} S2={res['S2']} S3={res['S3']} "
          f"S4={res['S4']} S5={res['S5']}")
    return ok_all


@case
async def G1_sequences_account_A():
    w = World(VC)
    ok = await _run_sequences(w.a_b, RAW_G, "A")
    print(f"CASE G1: {'PASS' if ok else 'FAIL'} — five §5 sequences on "
          f"account A")
    return ok


@case
async def G2_sequences_account_B():
    w = World(VC)
    ok = await _run_sequences(w.b_b, RAW_GB, "B")
    print(f"CASE G2: {'PASS' if ok else 'FAIL'} — five §5 sequences on "
          f"account B")
    return ok


# ---------------------------------------------------------------------------
# G3 — FINAL2-2 §3 Scenario B: second PROCESS while P1 runs mid-operations
# ---------------------------------------------------------------------------
def _import_bootstrap():
    """Stub-import the REAL bootstrap.py (InstanceGuard + the V85 startup
    machinery). The FINAL2-2 §3 second-process behavioral test needs the
    REAL guard class, not a source-contract."""
    te = sys.modules.get("telegram.ext")
    for n in ("Application", "ApplicationBuilder", "CallbackQueryHandler",
              "CommandHandler", "InlineQueryHandler", "MessageHandler"):
        setattr(te, n, _Stub())
    # v99.07 FIX-33 test maintenance: bootstrap now imports
    # supervised_create_task from its DEFINING module (utils_real) —
    # the stub gains it (the handlers stub keeps its copy for other
    # importers).
    _mod("mediagrab_bot.utils_real", _attrs(
        "register_bot", "safe_reply_text", "safe_edit_message_text",
        "safe_send_message", "periodic_cleanup", "setup_logging",
        "_install_asyncio_handler", "_ErrorDedupFilter",
        "supervised_create_task"))
    _mod("mediagrab_bot.ui_keyboards", _attrs("vc_menu"))
    _mod("mediagrab_bot.talkative", _attrs(
        "talkative_apply_effective_runtime", "talkative_effective_enabled",
        "talkative_effective_provider", "_talkative_cleanup_task",
        "_talkative_fetch_bot_identity", "_talkative_handle_message_wrapper",
        "_talkative_start_cleanup_task", "_talkative_stop_cleanup_task",
        "_provider_get_state", "_provider_init_states",
        "_provider_record_failure", "_media_seed_default_library",
        "talkative_handler"))
    _mod("mediagrab_bot.multimodal", _attrs(
        "register_multimodal_handler", "_app_voice_enroll_register",
        "_voice_enroll_selfcheck_async"))
    _mod("mediagrab_bot.handlers", _attrs(
        "start_command", "route_callback", "route_message", "help_command",
        "_menu_edit", "repo", "kb", "msg", "states", "admin_handler",
        "inline_handler", "mtproto_handler", "scheduled_handler",
        "_dashboard_snapshot_start", "_dashboard_live_start",
        "_dashboard_live_stop", "_bot_heartbeat_start",
        "_bot_history_start", "mtproto_manager", "_active_tasks",
        "supervised_create_task"))
    _db = sys.modules["mediagrab_bot.db_layer"]
    for n in ("init_db", "close_db"):
        setattr(_db, n, _Stub())
    _mt = sys.modules["mediagrab_bot.mtproto"]
    for n in ("mtproto_take_screenshot", "ROLE_PRIMARY",
              "STATUS_DISCONNECTED"):
        setattr(_mt, n, _Stub())
    _fe = sys.modules["mediagrab_bot.frame_extractor"]
    setattr(_fe, "witai_service", _Stub())
    _dh = sys.modules["mediagrab_bot.diag_hooks"]
    setattr(_dh, "register_diag_hooks", _Stub())
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.bootstrap", f"{_SRC}/bootstrap.py")
    m = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.bootstrap"] = m
    spec.loader.exec_module(m)
    return m


@case
async def G3_second_process_rejected_during_ops():
    """§3 Scenario B: while P1 runs (mid-Join-All AND mid-reconnect), a
    second startup is REJECTED by the REAL InstanceGuard; P1's VC state
    is untouched. The cross-process PID guard (main() → sys.exit(2)
    BEFORE app.run_polling/cluster/VC init) is source-order-proven in
    the hardening suite (§B test_pid_guard_precedes_vc_startup)."""
    boot = _import_bootstrap()
    w = World(VC)
    w.join_on(w.a_b, RAW)
    # P1 acquires ownership (the REAL guard class from REAL bootstrap)
    r1 = await boot.InstanceGuard.acquire()
    # P1 mid-join-all + mid-reconnect state
    VC._vc_join_all_running = True
    coord_before = w.coord.get_state(RAW).value
    # P2 (a second startup in the same process — the in-process duplicate
    # path the guard exists for; cross-process = the PID guard):
    r2 = await boot.InstanceGuard.acquire()
    untouched = (VC._vc_join_all_running is True
                 and w.coord.get_state(RAW).value == coord_before
                 and w.vc._vc_active_join_backends_by_chat.get(RAW)
                 is w.a_b)
    await boot.InstanceGuard.release()
    VC._vc_join_all_running = False
    ok = (r1 == "INSTANCE_OK"
          and r2 == "INSTANCE_ALREADY_RUNNING" and untouched)
    print(f"CASE G3: {'PASS' if ok else 'FAIL'} — first={r1} "
          f"second={r2} p1_state_untouched={untouched}")
    return ok


# ---------------------------------------------------------------------------
# H1/H2/H3 — FINAL2-2 §7: two-account isolation, both directions + outage
# ---------------------------------------------------------------------------
@case
async def H1_A_leaves_VC1_B_untouched_in_VC2():
    w = World(VC)
    w.join_on(w.a_b, RAW)      # A @ VC1
    w.join_on(w.b_b, RAW_B)    # B @ VC2
    b_container_before = -1000000000000 - RAW_B in w.b_b._pytgcalls.calls
    out = await w.vc.vc_leave_target(RAW)
    b_state = (VC._vc_participations.get(RAW_B) is not None
               and VC._vc_participations[RAW_B].state == "joined")
    b_coord = w.coord.get_state(RAW_B).value == "joined"
    b_container_after = -1000000000000 - RAW_B in w.b_b._pytgcalls.calls
    b_owner = w.vc._vc_active_join_backends_by_chat.get(RAW_B) is w.b_b
    b_api_clean = len(w.b_b._pytgcalls.api_log) == 0   # zero B-side calls
    a_left = (out == "success"
              and w.coord.get_state(RAW).value not in (
                  "joined", "active", "verifying"))
    ok = (a_left and b_state and b_coord and b_container_before
          and b_container_after and b_owner and b_api_clean)
    print(f"CASE H1: {'PASS' if ok else 'FAIL'} — a_left={a_left} "
          f"b_registry={b_state} b_coord={b_coord} "
          f"b_container={b_container_after} b_owner={b_owner} "
          f"b_api_calls={len(w.b_b._pytgcalls.api_log)}")
    return ok


@case
async def H2_B_leaves_VC2_A_untouched_in_VC1():
    w = World(VC)
    w.join_on(w.a_b, RAW)      # A @ VC1
    w.join_on(w.b_b, RAW_B)    # B @ VC2
    out = await w.vc.vc_leave_target(RAW_B)   # B leaves VC2
    a_state = (VC._vc_participations.get(RAW) is not None
               and VC._vc_participations[RAW].state == "joined")
    a_coord = w.coord.get_state(RAW).value == "joined"
    a_container = -1000000000000 - RAW in w.a_b._pytgcalls.calls
    a_owner = w.vc._vc_active_join_backends_by_chat.get(RAW) is w.a_b
    a_api_clean = len(w.a_b._pytgcalls.api_log) == 0
    b_left = (out == "success"
              and w.coord.get_state(RAW_B).value not in (
                  "joined", "active", "verifying"))
    ok = (b_left and a_state and a_coord and a_container
          and a_owner and a_api_clean)
    print(f"CASE H2: {'PASS' if ok else 'FAIL'} — b_left={b_left} "
          f"a_registry={a_state} a_coord={a_coord} "
          f"a_container={a_container} a_owner={a_owner} "
          f"a_api_calls={len(w.a_b._pytgcalls.api_log)}")
    return ok


@case
async def H3_A_backend_outage_B_unaffected():
    """A-backend outage (reconnect-storm effect on VC ops): reconcile
    honestly reports A unknown (preserved — weak evidence is NEVER
    destructive) while B verifies present; B's leave/rejoin lifecycle
    runs normally DURING the A outage; zero cross-account operations."""
    w = World(VC)
    w.join_on(w.a_b, RAW)
    w.join_on(w.b_b, RAW_B)
    w.a_b._started = False     # A offline
    summary = await _reconcile_with({RAW: "unknown", RAW_B: "present"})
    a_preserved = (VC._vc_participations.get(RAW) is not None
                   and VC._vc_participations[RAW].state == "joined")
    b_joined = (w.coord.get_state(RAW_B).value == "joined")
    # B lifecycle during A outage: leave VC2 → success; coordinator LEFT
    out_b = await w.vc.vc_leave_target(RAW_B)
    b_left = (out_b == "success"
              and w.coord.get_state(RAW_B).value not in (
                  "joined", "active", "verifying"))
    a_still = (VC._vc_participations.get(RAW) is not None
               and VC._vc_participations[RAW].state == "joined")
    # A recovery: A backend back + verify present → preserved-join stays
    w.a_b._started = True
    summary2 = await _reconcile_with({RAW: "present"})
    a_coord = w.coord.get_state(RAW).value == "joined"
    ok = (a_preserved and b_joined and b_left and a_still and a_coord
          and summary.get("unknown") == 1 and summary.get("present") == 1
          and summary2.get("present") >= 1
          and len(w.b_b._pytgcalls.api_log) >= 0
          and RAW not in [c[1] for c in w.b_b._pytgcalls.api_log])
    print(f"CASE H3: {'PASS' if ok else 'FAIL'} — a_preserved={a_preserved} "
          f"b_joined={b_joined} b_left={b_left} a_untouched={a_still} "
          f"summary={summary.get('present')}p/{summary.get('unknown')}u")
    return ok


# ---------------------------------------------------------------------------
# I1/I2 — FINAL2-2 §6: stale call identity never masquerades as current
# ---------------------------------------------------------------------------
@case
async def I1_stale_identity_restart_current_wins():
    """Old call_id in the registry + NEW active call + process restart:
    startup reconcile consults the CURRENT identity (present) — the stale
    registry identity never produces a false call-gone/absent; the join
    is preserved with ZERO join RPCs."""
    w = World(VC)
    rec = w.join_on(w.a_b, RAW)
    rec.call_id = 111                    # STALE identity in the registry
    _simulate_restart(VC)
    summary = await _reconcile_with({RAW: "present"}, current_call_id=999)
    joined_kept = (VC._vc_participations.get(RAW) is not None
                   and VC._vc_participations[RAW].state == "joined")
    coord_joined = w.coord.get_state(RAW).value == "joined"
    zero_joins = sum(len(be._pytgcalls.calls)
                     for be in (w.global_b, w.a_b, w.b_b)) == 0
    ok = (summary.get("present") == 1 and joined_kept and coord_joined
          and zero_joins)
    print(f"CASE I1: {'PASS' if ok else 'FAIL'} — present="
          f"{summary.get('present')} registry_joined={joined_kept} "
          f"coord={w.coord.get_state(RAW).value} joins_issued={zero_joins}")
    return ok


@case
async def I2_stale_identity_recheck_fails_join_all():
    """Old identity + new active call + FAILED recheck + Join-All:
    (a) weak recheck → the believed-join is PRESERVED (join-all skips it
    — already_joined, ZERO join RPCs — no false call-gone cleanup);
    (b) a genuine server-absent confirm cleans it LEFT;
    (c) the next join-all join for a FRESHLY detected call uses the FRESH
    identity (never the stale one)."""
    w = World(VC)
    rec = w.join_on(w.a_b, RAW)
    rec.call_id = 111                    # STALE
    # (a) weak/failed recheck: registry joined + request_accepted →
    #     join-all SKIP (preserve), zero NEW join RPCs (container count
    #     unchanged — the only entry is the pre-existing believed-join)
    joins_before = sum(len(be._pytgcalls.calls)
                       for be in (w.global_b, w.a_b, w.b_b))
    r_a = await VC._vc_capacity_aware_join(
        RAW, title="T", call_id=111, access_hash=5, source="final2_I2a")
    joins_a = sum(len(be._pytgcalls.calls)
                  for be in (w.global_b, w.a_b, w.b_b))
    # (b) genuine server-side absent confirm → cleaned LEFT
    VC._vc_startup_reconcile_state.update({"done": False})
    summary = await _reconcile_with({RAW: "absent"})
    reg_left = (VC._vc_participations.get(RAW) is None
                or VC._vc_participations[RAW].state == "left")
    coord_left = w.coord.get_state(RAW).value not in (
        "joined", "active", "verifying")
    # (c) fresh detection (call_id=999) → the join is issued with the
    #     FRESH identity (patched global backend records the identity)
    recorded = {}

    async def fake_join(chat_ref, *, call_id, access_hash, muted=True):
        recorded["call_id"] = call_id
        recorded["access_hash"] = access_hash
        return True

    async def fake_start():
        return None

    async def fake_avail():
        return True

    _g = w.global_b
    _start_b, _avail_b, _join_b = _g.start, _g.is_available, _g.join
    _g.start, _g.is_available, _g.join = fake_start, fake_avail, fake_join
    # real ints for the capacity computation + a real healthy-account
    # list (the _Stub defaults cannot feed max()/len() — this is the
    # join-path arithmetic, not the mechanism under test)
    _cfg_cap = VC.config.vc_multi_max_targets
    _cfg_tmo = VC.config.vc_multi_join_timeout
    VC.config.vc_multi_max_targets = 3
    VC.config.vc_multi_join_timeout = 30
    _real_cluster_fn = VC.get_userbot_cluster

    def fake_cluster():
        class _C:
            def get_healthy_accounts(self):
                return ["acc_A", "acc_B"]
        return _C()
    VC.get_userbot_cluster = fake_cluster
    try:
        r_c = await VC._vc_capacity_aware_join(
            RAW, title="T", call_id=999, access_hash=7, source="final2_I2c")
    finally:
        _g.start, _g.is_available, _g.join = _start_b, _avail_b, _join_b
        VC.config.vc_multi_max_targets = _cfg_cap
        VC.config.vc_multi_join_timeout = _cfg_tmo
        VC.get_userbot_cluster = _real_cluster_fn
    fresh_used = recorded.get("call_id") == 999
    reg_fresh = (VC._vc_participations.get(RAW) is not None
                 and VC._vc_participations[RAW].state == "joined")
    ok = (r_a == "already_joined" and joins_a == joins_before
          and summary.get("absent") == 1 and reg_left and coord_left
          and r_c == "joined" and fresh_used and reg_fresh)
    print(f"CASE I2: {'PASS' if ok else 'FAIL'} — preserved={r_a} "
          f"joins_unchanged={joins_a == joins_before} "
          f"absent_cleaned={reg_left} "
          f"rejoin={r_c} fresh_identity={recorded.get('call_id')}")
    return ok


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
VC = import_voicechat()


async def _run_all():
    passed = 0
    failed = 0
    for name, fn in CASES:
        try:
            ok = await fn()
        except Exception as exc:  # noqa: BLE001
            ok = False
            print(f"CASE {name}: FAIL — exception {type(exc).__name__}: {exc}")
        if ok:
            passed += 1
        else:
            failed += 1
    total = len(CASES)
    print(f"\nFINAL2 DRIVER RESULT: {'PASS' if failed == 0 else 'FAIL'} "
          f"— {passed}/{total} cases pass")
    return failed


def main() -> int:
    # VC is imported at module bottom; ensure World cases see it.
    globals()["VC"] = VC
    return asyncio.run(_run_all())


if __name__ == "__main__":
    sys.exit(main())
