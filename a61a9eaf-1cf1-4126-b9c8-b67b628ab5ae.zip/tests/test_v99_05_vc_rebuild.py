"""v99.05 — THE FINAL REBUILD verification suite (mission §18).

Every focused failure mode from the FINAL mission's test matrix, targeted
at the CONFIRMED root causes of the 2026-09-12 v99.04 production run
(bot-diagnostic (2).log — the first run that reached the VC transport
layer and proved the joins were REAL while the BLIND verifier destroyed
them):

  RC-F1  Telethon GroupCallParticipant identifies participants via
         ``peer`` (PeerUser/PeerChannel/PeerChat) — it has NO ``user_id``
         attribute.  ALL matching sites read getattr(p, "user_id") →
         NEVER matched → presence UNDETECTABLE since v98.01 → 0×
         VC_PARTICIPATION_PRESENT across ALL production history →
         9/9 REAL joins destroyed as "phantoms" on 2026-09-12.
  RC-F2  The v99.02 no-match→absent streak escalation was built on the
         misreading "Telegram's ids-filter is not honored" — the filter
         WAS honored; the returned participant WAS us; the code could not
         recognize itself.
  RC-F3  The absent path re-registered state=joined + logged "join
         PRESERVED" while the pipeline cleaned up 200ms later (split-brain
         bookkeeping; coverage reconcile showed active=6 joined=6 after
         3 FAILED targets).
  RC-F4  GroupcallInvalid on a verify query = STALE CALL IDENTITY, not
         absence; identity hygiene (re-detect the CURRENT pair + re-verify)
         now lives in the pipeline; the (id, access_hash) PAIR is the
         identity (comparing only the id produced the misleading
         "IDENTITY_REFRESHED old==new" production line).
  RC-F5  Account registry: __primary__ is now a schema-conformant DICT;
         dual-role files (primary AND registered cluster account) count
         their DISTINCT registration — the "two accounts showing one"
         fix.
  RC-F6  Attempt correlation ids + success-evidence fields on
         VC_ATTEMPT_FINAL / VC_JOIN_SUCCESS (mission §3/§16).

Sections:
  A — RC-F1 matching semantics (REAL Telethon object shapes).
  B — the REAL vc_check_telegram_participation against a REAL-shape RPC
      layer (broad scan / targeted query / stale-call / foreign-result /
      wrong-call / wrong-account).
  C — pipeline-level behaviours via the v99 harness (attempt ids, stale
      identity rediscovery, call rotation, UNKNOWN-honesty, concurrency).
  D — account registry schema + honest counting.
  E — source contracts for the new observability + the REMOVED phantom
      register.
"""

import asyncio
import importlib.util
import os
import re
import sys
import time
import types
import unittest
from pathlib import Path
from typing import Any, Optional

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
_MT_TEXT = (_SRC / "mtproto.py").read_text(encoding="utf-8")


def _grab_fn(src: str, name: str) -> str:
    m = re.search(rf"^(?:async )?def {name}\(.*?(?=^(?:async )?def |^class |\Z)",
                  src, re.M | re.S)
    if m is None:
        raise AssertionError(f"function {name} not found")
    return m.group(0)


# ---------------------------------------------------------------------------
# REAL-shape Telethon fakes (peer-based participants — the v99.05 point)
# ---------------------------------------------------------------------------

class _PeerUser:
    def __init__(self, user_id: int):
        self.user_id = user_id


class _PeerChannel:
    def __init__(self, channel_id: int):
        self.channel_id = channel_id


class _GroupCallParticipant:
    """The REAL Telethon shape: identity in ``peer`` — NO ``user_id``."""

    def __init__(self, peer, *, is_self=False, just_joined=False,
                 left=False, source=1, date=None):
        self.peer = peer
        self.is_self = is_self
        self.just_joined = just_joined
        self.left = left
        self.source = source
        self.date = date
        self.muted = False
        self.video_joined = False
        # DELIBERATELY no `user_id` attribute — matching the real object.


class _GroupCallResult:
    """phone.GroupCall: participants + participants_next_offset."""

    def __init__(self, participants, next_offset=""):
        self.participants = participants
        self.participants_next_offset = next_offset


class _GroupParticipantsResult:
    """phone.GroupParticipants: count + participants + next_offset."""

    def __init__(self, participants, count=None, next_offset=""):
        self.participants = participants
        self.count = count
        self.next_offset = next_offset


class _GroupcallInvalidError(Exception):
    pass


class _GetGroupCallRequest:
    def __init__(self, call=None, limit=0):
        self.call = call
        self.limit = limit


class _GetGroupParticipantsRequest:
    def __init__(self, call=None, ids=None, sources=None, offset="",
                 limit=0):
        self.call = call
        self.ids = list(ids or [])
        self.sources = list(sources or [])
        self.offset = offset
        self.limit = limit


class _InputGroupCall:
    def __init__(self, id=0, access_hash=0):
        self.id = id
        self.access_hash = access_hash


def _install_realshape_telethon():
    """A fake telethon whose OBJECT SHAPES match the installed 1.44.0
    (validated in PHASE 2 against audit/vcenv): GroupCallParticipant has
    peer, NOT user_id."""
    if "telethon" in sys.modules and getattr(
            sys.modules["telethon"], "__mg_v9905__", False):
        return sys.modules["telethon"]
    telethon = types.ModuleType("telethon")
    telethon.__mg_v9905__ = True
    tl = types.ModuleType("telethon.tl")
    types_mod = types.ModuleType("telethon.tl.types")
    types_mod.Channel = type("Channel", (), {})
    types_mod.InputGroupCall = _InputGroupCall
    types_mod.PeerUser = _PeerUser
    types_mod.PeerChannel = _PeerChannel
    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = _GetGroupCallRequest
    phone_mod.GetGroupParticipantsRequest = _GetGroupParticipantsRequest
    functions_mod = types.ModuleType("telethon.tl.functions")
    errors_mod = types.ModuleType("telethon.errors")
    errors_mod.FloodWaitError = type("FloodWaitError", (Exception,), {})
    errors_mod.GroupcallInvalidError = _GroupcallInvalidError
    sys.modules["telethon"] = telethon
    sys.modules["telethon.tl"] = tl
    sys.modules["telethon.tl.types"] = types_mod
    sys.modules["telethon.tl.functions"] = functions_mod
    sys.modules["telethon.tl.functions.phone"] = phone_mod
    sys.modules["telethon.errors"] = errors_mod
    return telethon


# ---------------------------------------------------------------------------
# Section A — RC-F1 matching semantics (the THE-fix unit tests)
# ---------------------------------------------------------------------------

class TestRCF1MatchingSemantics(unittest.TestCase):
    """The peer-based matcher — unit-level, real Telethon shapes."""

    @classmethod
    def setUpClass(cls):
        ns: dict = {"Any": object}
        exec(_grab_fn(_VC_TEXT, "_participant_matches_self"), ns)
        exec(_grab_fn(_VC_TEXT, "_participant_identity_evidence"), ns)
        cls.matches = staticmethod(ns["_participant_matches_self"])
        cls.evidence = staticmethod(
            ns["_participant_identity_evidence"])
        cls.MY = 8699582859

    def test_a1_real_shape_self_matches(self):
        p = _GroupCallParticipant(_PeerUser(self.MY), just_joined=True)
        self.assertTrue(self.matches(p, self.MY))

    def test_a2_historical_bug_documented_in_object_shape(self):
        # The regression-documentation test: the REAL object has NO
        # user_id attribute — the historical matcher could NEVER match.
        p = _GroupCallParticipant(_PeerUser(self.MY))
        self.assertIsNone(getattr(p, "user_id", None),
                          "the real Telethon GroupCallParticipant must "
                          "expose peer (not user_id) — if this changes, "
                          "re-audit the matching layer")

    def test_a3_is_self_flag_matches(self):
        p = _GroupCallParticipant(_PeerUser(999), is_self=True)
        self.assertTrue(self.matches(p, self.MY))

    def test_a4_foreign_user_never_matches(self):
        p = _GroupCallParticipant(_PeerUser(111))
        self.assertFalse(self.matches(p, self.MY))

    def test_a5_wrong_account_verification_fails(self):
        # account A (111) joined; verification asks "is account B (222)
        # present?" — must FAIL (mission §18 #23).
        p = _GroupCallParticipant(_PeerUser(111))
        self.assertFalse(self.matches(p, 222))
        p2 = _GroupCallParticipant(_PeerUser(222), is_self=False)
        self.assertFalse(self.matches(p2, 111))

    def test_a6_peer_channel_participant_not_us(self):
        p = _GroupCallParticipant(_PeerChannel(4460369026))
        self.assertFalse(self.matches(p, self.MY))

    def test_a7_legacy_harness_shape_backcompat(self):
        class _LegacyParticipant:
            def __init__(self, uid):
                self.user_id = uid
        self.assertTrue(self.matches(_LegacyParticipant(self.MY), self.MY))
        self.assertFalse(self.matches(_LegacyParticipant(1), self.MY))

    def test_a8_identity_evidence_string(self):
        p = _GroupCallParticipant(_PeerUser(self.MY), just_joined=True,
                                  source=77)
        ev = self.evidence(p)
        self.assertIn("PeerUser", ev)
        self.assertIn(str(self.MY), ev)
        self.assertIn("just_joined", ev)
        self.assertIn("source=77", ev)

    def test_a9_zero_and_invalid_ids_never_match(self):
        p = _GroupCallParticipant(_PeerUser(0))
        self.assertFalse(self.matches(p, 0))
        self.assertFalse(self.matches(p, None))
        self.assertFalse(self.matches(p, "not-a-number"))


# ---------------------------------------------------------------------------
# Section B — the REAL vc_check_telegram_participation (REAL-shape RPC)
# ---------------------------------------------------------------------------

class _RecordingClient:
    """A fake Telethon client whose __call__ serves configured results and
    records every request — with REAL-shape participants."""

    def __init__(self, *, my_id, me_user=None):
        self.my_id = my_id
        self.name = f"client_{my_id}"
        self.requests: list = []
        self.broad_results: list = []       # per GetGroupCallRequest call
        self.targeted_results: list = []    # per GetGroupParticipantsRequest
        self.broad_exc: list = []
        self.targeted_exc: list = []
        self._me = me_user or types.SimpleNamespace(id=my_id)

    async def __call__(self, request):
        self.requests.append(request)
        if isinstance(request, _GetGroupCallRequest):
            if self.broad_exc:
                exc = self.broad_exc.pop(0)
                if exc is not None:
                    raise exc
            return self.broad_results.pop(0) if self.broad_results \
                else _GroupCallResult([])
        if isinstance(request, _GetGroupParticipantsRequest):
            if self.targeted_exc:
                exc = self.targeted_exc.pop(0)
                if exc is not None:
                    raise exc
            return self.targeted_results.pop(0) if self.targeted_results \
                else _GroupParticipantsResult([])
        raise RuntimeError(f"unexpected request {request!r}")

    async def get_me(self):
        return self._me

    async def get_input_entity(self, x):
        return _PeerUser(self.my_id)

    def is_connected(self):
        return True


def _make_streak_recorder(streak_state):
    """Bridge the test's streak control into the extracted check: a
    callable streak_state is INVOKED (recording semantics); a dict is
    returned as-is (pre-seeded state); None → the count-1 default."""
    if callable(streak_state):
        return streak_state
    if streak_state is not None:
        return lambda chat_id, call_id, mid: streak_state
    return lambda chat_id, call_id, mid: {"count": 1}


class TestRealVerification(unittest.TestCase):
    """Runs the REAL vc_check_telegram_participation with REAL-shape
    Telethon objects — the layer every previous test suite STUBBED (the
    RC-F7 test blind spot)."""

    @classmethod
    def setUpClass(cls):
        _install_realshape_telethon()
        cls.MY = 8624009332

    def _exec_check(self, *, my_id=None, streak_state=None):
        my_id = my_id if my_id is not None else self.MY

        async def _mtproto_call_with_retry(func, req, **kw):
            return await func(req)

        ns: dict = {
            "asyncio": asyncio, "Optional": Optional, "Any": object,
            "logger": types.SimpleNamespace(
                info=lambda *a, **k: None, debug=lambda *a, **k: None,
                warning=lambda *a, **k: None),
            "get_userbot_cluster": lambda: None,
            "mtproto_get_client": lambda: None,
            "mtproto_get_client_legacy": lambda: None,
            "vc_get_backend": lambda account_id="": None,
            "mtproto_call_with_retry": _mtproto_call_with_retry,
            "_vc_my_user_id": my_id,
            "time": time,
            "_vc_now_iso": lambda: "2026-09-12T00:00:00",
            "_vc_last_participation_check": {},
            "_vc_join_quarantine_clear": lambda *a, **k: None,
            "_vc_targeted_absent_streak_reset": lambda *a, **k: None,
            "_vc_targeted_absent_streak_record": (
                _make_streak_recorder(streak_state)),
            "_VC_TARGETED_ABSENT_THRESHOLD": 3,
        }
        code = (
            _grab_fn(_VC_TEXT, "_participant_matches_self") + "\n\n" +
            _grab_fn(_VC_TEXT, "_participant_identity_evidence") + "\n\n" +
            _grab_fn(_VC_TEXT, "vc_check_telegram_participation"))
        # strip the function-internal relative imports so the fake
        # telethon modules in sys.modules are used
        code = "\n".join(
            ln for ln in code.split("\n")
            if "from .mtproto import" not in ln
            and "from .voicechat import" not in ln)
        exec(compile(code, "<v9905-vc-extract>", "exec"), ns)
        return ns["vc_check_telegram_participation"], ns

    def _check_with_client(self, client, *, call_id=-710395016765712014,
                           access_hash=4242, my_id=None, streak_state=None,
                           account_id="acc_X"):
        check, ns = self._exec_check(my_id=my_id, streak_state=streak_state)
        return asyncio.run(check(
            -1004460369026, call_id=call_id, access_hash=access_hash,
            account_id=account_id, client=client)), ns

    def test_b1_broad_scan_detects_presence(self):
        """Scenario 1 (active call + successful join): the broad scan's
        recent-speakers window CONTAINS us (peer shape) → present."""
        c = _RecordingClient(my_id=self.MY)
        c.broad_results = [_GroupCallResult([
            _GroupCallParticipant(_PeerUser(111)),
            _GroupCallParticipant(_PeerUser(self.MY), just_joined=True),
            _GroupCallParticipant(_PeerUser(222)),
        ])]
        out, ns = self._check_with_client(c)
        self.assertEqual(out, "present")
        ev = ns["_vc_last_participation_check"]
        self.assertEqual(ev["result"], "present")
        self.assertIn("PeerUser", ev["participant_identity"])

    def test_b2_targeted_query_self_participant_present(self):
        """THE 2026-09-12 scenario INVERTED: the targeted ids=[self] query
        returns OUR participant (the historical blind matcher called this
        'no matching participant' and destroyed the join)."""
        c = _RecordingClient(my_id=self.MY)
        # broad scan: 6 foreign participants, incomplete (no server_count,
        # participants_next_offset non-empty → truncated)
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(i)) for i in
             (111, 222, 333, 444, 555, 666)],
            next_offset="offset-1")]
        c.targeted_results = [
            _GroupParticipantsResult(
                [_GroupCallParticipant(_PeerUser(self.MY),
                                       just_joined=True)],
                count=7)]
        out, ns = self._check_with_client(c)
        self.assertEqual(out, "present")
        ev = ns["_vc_last_participation_check"]
        self.assertIn("just_joined", ev["participant_identity"])

    def test_b3_targeted_empty_list_streak_converges_absent(self):
        """Scenario: Telegram's DIRECT negative answer (empty list for
        ids=[self]) × 3 (streak threshold) → authoritative absent (the
        FIX-L convergence, preserved)."""
        streak = {"count": 0, "call_id": -710395016765712014}
        c = _RecordingClient(my_id=self.MY)
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(i)) for i in (111, 222)],
            next_offset="off")]
        c.targeted_results = [_GroupParticipantsResult([], count=2)]

        def record(chat_id, call_id, mid):
            streak["count"] += 1
            streak["call_id"] = call_id
            return dict(streak)

        # run twice: first (streak<3 → unknown), then with streak pre-set
        out1, _ = self._check_with_client(c, streak_state=record)
        self.assertEqual(out1, "unknown")
        streak["count"] = 2
        c2 = _RecordingClient(my_id=self.MY)
        c2.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(i)) for i in (111, 222)],
            next_offset="off")]
        c2.targeted_results = [_GroupParticipantsResult([], count=2)]
        out2, _ = self._check_with_client(c2, streak_state=record)
        self.assertEqual(out2, "absent")

    def test_b4_targeted_foreign_result_is_unknown_never_absent(self):
        """RC-F2: a non-empty targeted answer with no self is NOT absence
        evidence — the v99.02 no-match→absent escalation is REMOVED."""
        streak = {"count": 99, "call_id": -710395016765712014}  # high
        c = _RecordingClient(my_id=self.MY)
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(i)) for i in (111, 222)],
            next_offset="off")]
        # targeted returns OTHER participants (foreign) — even with a
        # huge streak this must stay UNKNOWN:
        c.targeted_results = [_GroupParticipantsResult(
            [_GroupCallParticipant(_PeerUser(999))], count=3)]
        out, ns = self._check_with_client(c, streak_state=streak)
        self.assertEqual(out, "unknown",
                         "a foreign-result must NEVER escalate to absent")

    def test_b5_groupcall_invalid_broad_scan_is_stale_call(self):
        """RC-F4: GroupcallInvalid on the broad scan = STALE CALL IDENTITY
        → unknown + the stale_call evidence flag (historically: absent)."""
        c = _RecordingClient(my_id=self.MY)
        c.broad_exc = [_GroupcallInvalidError("group call is invalid")]
        out, ns = self._check_with_client(c)
        self.assertEqual(out, "unknown",
                         "GroupcallInvalid must NOT be absence")
        ev = ns["_vc_last_participation_check"]
        self.assertTrue(ev.get("stale_call"),
                        "the stale_call evidence flag must be set for the "
                        "pipeline's identity hygiene")

    def test_b6_groupcall_invalid_targeted_is_stale_call(self):
        c = _RecordingClient(my_id=self.MY)
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(111))], next_offset="off")]
        c.targeted_exc = [_GroupcallInvalidError("group call is invalid")]
        out, ns = self._check_with_client(c)
        self.assertEqual(out, "unknown")
        ev = ns["_vc_last_participation_check"]
        self.assertTrue(ev.get("stale_call"))

    def test_b7_verification_against_wrong_call_identity_fails(self):
        """Mission §18 #22: verification against the WRONG call must fail.
        We are a participant of call A; the query runs against call B —
        Telegram answers for call B (which we are not in) → not present."""
        c = _RecordingClient(my_id=self.MY)
        # the targeted query for call B returns call B's participants —
        # foreign ones (we are NOT in call B):
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(111))], next_offset="off")]
        c.targeted_results = [_GroupParticipantsResult(
            [_GroupCallParticipant(_PeerUser(111))], count=1)]
        out, _ = self._check_with_client(c, call_id=-999, access_hash=888)
        self.assertNotEqual(out, "present")

    def test_b8_verification_with_wrong_account_fails(self):
        """Mission §18 #23: verification with the WRONG account must fail.
        Account A (111) joined; verification runs through account B's
        client (get_me → B's id) — the participant peer belongs to A →
        no match, never present."""
        c = _RecordingClient(my_id=111)  # account A's client: A joined
        # the broad scan shows A as participant (NOT B):
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(111))])]
        # the targeted query through A's client for ids=[A]... — the
        # check asks "is THIS client's account (A) present?": it IS.
        # The WRONG-account case is the inverse: B's client asking.
        out_a, _ = self._check_with_client(c)
        self.assertEqual(out_a, "present")  # sanity: A verifying A → yes
        # now account B's client verifies the same call — the only
        # participant is A → B is NOT present:
        cb = _RecordingClient(my_id=222)
        cb.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(111))])]
        cb.targeted_results = [_GroupParticipantsResult(
            [_GroupCallParticipant(_PeerUser(111))], count=1)]
        out_b, _ = self._check_with_client(cb)
        self.assertNotEqual(out_b, "present",
                            "account B must NOT verify account A's join")

    def test_b9_targeted_ids_use_self_input_peer(self):
        """RC-F4b: the targeted query resolves our own InputPeer first
        (client.get_input_entity('me')) and passes it in ids."""
        c = _RecordingClient(my_id=self.MY)
        c.broad_results = [_GroupCallResult(
            [_GroupCallParticipant(_PeerUser(111))], next_offset="off")]
        c.targeted_results = [_GroupParticipantsResult(
            [_GroupCallParticipant(_PeerUser(self.MY))], count=1)]
        self._check_with_client(c)
        targeted = [r for r in c.requests
                    if isinstance(r, _GetGroupParticipantsRequest)]
        self.assertTrue(targeted)
        ids = targeted[0].ids
        self.assertEqual(len(ids), 1)
        # the explicit self InputPeer (a _PeerUser in the fake) or the
        # legacy int fallback — NEVER empty:
        self.assertTrue(isinstance(ids[0], (_PeerUser, int)))


# ---------------------------------------------------------------------------
# Section C — pipeline-level behaviours (v99 harness reuse)
# ---------------------------------------------------------------------------

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_v99_00_vc_pipeline import (  # noqa: E402
    FakeBackend, FakeClient, FakeChannelEntity, FakeCluster, Harness,
    PipelineTestBase,
)


class TestAttemptCorrelationAndEvidence(PipelineTestBase):
    """RC-F6 — mission §16: every attempt carries a correlation id; the
    success event carries reconstruction evidence (mission §3)."""

    def _capture_logs(self):
        logs: list = []

        class _L:
            def info(self, msg, *a, **k):
                logs.append(msg % a if a else msg)

            def warning(self, *a, **k):
                pass

            def debug(self, *a, **k):
                pass

            def error(self, *a, **k):
                pass
        import mediagrab_bot_harness.vc_pipeline as vcp
        old = vcp.logger
        vcp.logger = _L()
        return logs, old, vcp

    def test_c1_attempt_id_on_every_stage_event(self):
        async def run():
            self.h.verify_sequence = ["present"]
            logs, old, vcp = self._capture_logs()
            try:
                out = await self._join()
                self.assertEqual(out.verdict, "joined")
                self.assertTrue(out.attempt_id)
                stage_lines = [ln for ln in logs if ln.startswith(
                    ("VC_ATTEMPT_START", "VC_TARGET_RESOLVED",
                     "VC_ACCOUNT_SELECTED", "VC_CALL_RESOLVED",
                     "VC_JOIN_RPC_START", "VC_JOIN_RPC_RESULT",
                     "VC_VERIFY_START", "VC_VERIFY_RESULT",
                     "VC_ATTEMPT_FINAL"))]
                self.assertGreaterEqual(len(stage_lines), 7)
                # EVERY stage event carries the SAME attempt_id
                for ln in stage_lines:
                    self.assertIn(f"attempt_id={out.attempt_id}", ln,
                                  f"missing attempt_id: {ln[:80]}")
                # the final line carries the success evidence fields
                final = [ln for ln in stage_lines
                         if ln.startswith("VC_ATTEMPT_FINAL")][0]
                self.assertIn("verification_method=", final)
                self.assertIn("participant_identity=", final)
                self.assertIn("telegram_participant=present", final)
                return out
            finally:
                vcp.logger = old
        asyncio.run(run())

    def test_c2_success_evidence_captured_from_verify(self):
        async def run():
            self.h.verify_sequence = ["present"]
            # the harness check stub does not write the evidence dict —
            # seed it the way the REAL check does:
            self.h.fake_voicechat._vc_last_participation_check = {
                "chat_id": -1001234567890, "result": "present",
                "participant_identity": "peer=PeerUser(8624009332) "
                                        "flags=just_joined",
                "checked_at": "2026-09-12T05:00:00",
            }
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(out.verification_method,
                             "telegram_participant_query")
            self.assertIn("PeerUser", out.participant_identity)
            self.assertEqual(out.verification_timestamp,
                             "2026-09-12T05:00:00")
            return out
        asyncio.run(run())


class TestStaleIdentityHygiene(PipelineTestBase):
    """RC-F4 — mission §13 STALE_CALL + §4 call-rotation."""

    def test_c3_stale_identity_absent_then_present_on_current(self):
        """Scenario 3/4 (stale call id / call changes between discovery
        and join): the absent verdict is queried against a STALE pair;
        hygiene adopts the CURRENT pair and the re-verify finds us."""
        async def run():
            # verify: absent (stale identity) then present (current)
            self.h.verify_sequence = ["absent", "present"]
            # the CURRENT identity differs from the caller-provided
            # (-42/999) — the call rotated:
            self.h.detect_result = {"call_id": -77, "access_hash": 4321,
                                    "members": 5}
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            # the verify adopted the CURRENT pair (the second check
            # queried -77, not the stale -42):
            checks = [v for v in self.h.verify_calls]
            self.assertEqual(len(checks), 2)
            self.assertEqual(checks[1][1], -77)
            self.assertEqual(out.call_id, -77)
            return out
        asyncio.run(run())

    def test_c4_probe_inconclusive_degrades_to_unknown(self):
        """Mission §15: a failed identity probe must NOT trust the absent
        verdict — UNKNOWN (non-destructive)."""
        async def run():
            self.h.verify_sequence = ["absent"]
            # the hygiene PROBE's resolve fails (the probe resolves the
            # entity WITHOUT a provided hash — access_hash=0 — while the
            # main flow's first-attempt resolve carries the provided hash):
            async def probe_only_failure(client, chat_ref, chat_id=0,
                                         access_hash=0):
                if access_hash == 0:
                    return {"ok": False, "error": "probe_network_down"}
                raw = abs(int(chat_id)) % 10**12 if chat_id < 0 else int(
                    chat_id or 123)
                return {"ok": True,
                        "entity": FakeChannelEntity(raw, 555),
                        "source": "fresh"}
            self.h.fake_mtproto.resolve_vc_entity = probe_only_failure
            self.h.fake_voicechat.resolve_vc_entity = probe_only_failure
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
            # UNKNOWN semantics: the unverified raise (never absent-
            # destructive cleanup on weak evidence)
            self.assertIn("did NOT confirm", str(cm.exception))
            # registry NOT joined
            rec = self.h.registry.records.get(-1001234567890, {})
            self.assertNotEqual(rec.get("state"), "joined")
        asyncio.run(run())

    def test_c5_stable_identity_absent_stands(self):
        """The absent verdict with a STABLE current identity stands —
        genuinely-failed-join cleanup (mission §15 explicit reason)."""
        async def run():
            self.h.verify_sequence = ["absent", "absent"]
            self.h.detect_result = {"call_id": -42, "access_hash": 999,
                                    "members": 5}
            with self.assertRaises(self.h.VCTransportError):
                await self._join()
            self.assertIn(-1001234567890, self.backend.leave_calls)
            self.assertNotIn(-1001234567890, self.backend.container)
        asyncio.run(run())


class TestUnknownHonesty(PipelineTestBase):
    """Mission §18 #24: UNKNOWN must never become SUCCESS."""

    def test_c6_unknown_after_bounded_retries_is_unverified(self):
        async def run():
            self.h.verify_sequence = ["unknown", "unknown", "unknown",
                                      "unknown", "unknown"]
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
            self.assertIn("did NOT confirm", str(cm.exception))
            # registry never says joined
            rec = self.h.registry.records.get(-1001234567890, {})
            self.assertNotEqual(rec.get("state"), "joined")
            # NOT cleaned (unknown preserves local state for reconcile)
            self.assertNotIn(-1001234567890, self.backend.leave_calls)
        asyncio.run(run())

    def test_c7_delayed_visibility_converges_present(self):
        """Scenario 2 (delayed participant visibility): unknown → present
        within the bounded retry loop → SUCCESS."""
        async def run():
            # the harness default caps verify attempts at 1 — this
            # scenario needs the bounded retry loop (unknown → retry →
            # present): restore the production default.
            os.environ["VC_JOIN_TG_VERIFY_ATTEMPTS"] = "3"
            os.environ["VC_JOIN_TG_VERIFY_BUDGET"] = "8"
            try:
                self.h.verify_sequence = ["unknown", "present"]
                self.h.detect_result = {"call_id": -42, "access_hash": 999}
                out = await self._join()
                self.assertEqual(out.verdict, "joined")
                self.assertEqual(out.verification_result, "present")
                return out
            finally:
                os.environ["VC_JOIN_TG_VERIFY_ATTEMPTS"] = "1"
                os.environ["VC_JOIN_TG_VERIFY_BUDGET"] = "2"
        asyncio.run(run())


class TestConcurrency(PipelineTestBase):
    """Mission §18 #20: concurrent join requests cannot corrupt state."""

    def test_c8_concurrent_same_chat_joins_coalesce(self):
        async def run():
            self.h.verify_sequence = ["present"]
            t1 = asyncio.ensure_future(self._join())
            t2 = asyncio.ensure_future(self._join())
            outs = await asyncio.gather(t1, t2, return_exceptions=True)
            ok = [o for o in outs if not isinstance(o, Exception)]
            self.assertEqual(len(ok), 2, f"outs={outs!r}")
            # ONE dispatch (the coalesced duplicate never re-dispatches)
            self.assertEqual(len(self.backend.dispatches), 1)
            return ok
        asyncio.run(run())


# ---------------------------------------------------------------------------
# Section D — account registry (RC-F5)
# ---------------------------------------------------------------------------

_MT_CACHE: dict = {}


def _load_real_mtproto():
    """Import the REAL mtproto.py against the fake telethon stack (the
    proven v99.02 loader mechanism, self-contained).  The fake telethon
    gets the phone request classes so module-level imports resolve."""
    if "mt" in _MT_CACHE:
        return _MT_CACHE["mt"]

    class _FakeReq:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = type("GetGroupCallRequest", (_FakeReq,), {})
    phone_mod.GetGroupParticipantsRequest = type(
        "GetGroupParticipantsRequest", (_FakeReq,), {})
    sys.modules.setdefault("telethon", types.ModuleType("telethon"))
    sys.modules.setdefault("telethon.tl", types.ModuleType("telethon.tl"))
    sys.modules.setdefault("telethon.tl.types",
                           types.ModuleType("telethon.tl.types"))
    sys.modules.setdefault("telethon.errors",
                           types.ModuleType("telethon.errors"))
    sys.modules.setdefault("telethon.tl.functions",
                           types.ModuleType("telethon.tl.functions"))
    sys.modules["telethon.tl.functions.phone"] = phone_mod
    sys.modules["telethon.tl.types"].InputGroupCall = type(
        "InputGroupCall", (_FakeReq,), {})
    if not hasattr(sys.modules["telethon.errors"], "FloodWaitError"):
        sys.modules["telethon.errors"].FloodWaitError = type(
            "FloodWaitError", (Exception,), {})

    ptg = types.ModuleType("pytgcalls")
    ptg.__version__ = "2.3.3-fake"
    sys.modules.setdefault("pytgcalls", ptg)
    for sub in ("pytgcalls.types", "pytgcalls.types.input_stream",
                "pytgcalls.mtypes", "pytgcalls.helpers"):
        sys.modules.setdefault(sub, types.ModuleType(sub))

    _MT_CACHE["purged"] = {
        k: v for k, v in sys.modules.items()
        if k == "v9905_mt_pkg" or k.startswith("v9905_mt_pkg.")
    }
    pkg = types.ModuleType("v9905_mt_pkg")
    pkg.__path__ = [str(_SRC)]
    sys.modules["v9905_mt_pkg"] = pkg
    for name in ("config", "db_layer", "mtproto"):
        spec = importlib.util.spec_from_file_location(
            f"v9905_mt_pkg.{name}", str(_SRC / f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"v9905_mt_pkg.{name}"] = mod
        spec.loader.exec_module(mod)
    _MT_CACHE["mt"] = sys.modules["v9905_mt_pkg.mtproto"]
    return _MT_CACHE["mt"]


class TestAccountRegistrySchema(unittest.TestCase):
    """__primary__ dict schema + honest counting."""

    @classmethod
    def setUpClass(cls):
        cls.mt = _load_real_mtproto()

    def setUp(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self._active_bak = self.mt._MTPROTO_ACTIVE_SESSION_PATH
        self._find_bak = self.mt._find_all_session_files
        self._cluster_bak = self.mt.get_userbot_cluster
        # Redirect persistence to a temp dir so set_primary_id's _save()
        # never writes accounts.json into the work tree (runtime-state
        # leakage guard).
        import tempfile
        self._tmp = tempfile.mkdtemp(prefix="v9905_accounts_")
        self._file_bak = self.mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR
        self.mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        self.mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"

    def tearDown(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = self._active_bak
        self.mt._find_all_session_files = self._find_bak
        self.mt.get_userbot_cluster = self._cluster_bak
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        import shutil
        shutil.rmtree(self._tmp, ignore_errors=True)

    def _fresh_cluster(self, accounts: dict):
        cluster = self.mt.UserbotCluster()
        cluster._accounts = dict(accounts)
        cluster._clients = {}
        return cluster

    def test_d1_primary_entry_is_dict_schema(self):
        cluster = self._fresh_cluster({
            "acc_1": {"phone": "+111", "session_file": "/x/a.session",
                      "status": "healthy", "role": "primary",
                      "created_at": 1.0},
        })
        self.assertTrue(cluster.set_primary_id("acc_1"))
        v = cluster._accounts[self.mt._PRIMARY_KEY]
        self.assertIsInstance(v, dict,
                              "the persisted primary must be a DICT "
                              "(schema-conformant)")
        self.assertEqual(v.get("account_id"), "acc_1")
        # get_primary_id reads it back:
        self.assertEqual(cluster.get_primary_id(), "acc_1")

    def test_d2_legacy_string_primary_still_readable(self):
        cluster = self._fresh_cluster({
            "acc_1": {"phone": "+111", "session_file": "/x/a.session",
                      "status": "healthy", "role": "primary",
                      "created_at": 1.0},
            # the LEGACY persisted form (pre-v99.05 accounts.json):
            "__primary__": "acc_1",
        })
        self.assertEqual(cluster.get_primary_id(), "acc_1")

    def test_d3_production_dual_role_shape_counts_once(self):
        """THE 2026-09-12 production shape: ONE session file, live,
        primary_global AND registered as acc_919006065076 →
        cluster_accounts=1 expected_cluster=1, roles=primary,cluster."""
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_919006065076.session")]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = \
            "/x/cluster_919006065076.session"
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self.mt._register_session_status(
            "cluster_919006065076.session", "imported",
            username="Official_Ishitaa", user_id=8699582859,
            account_id="acc_919006065076")

        class _One:
            _accounts = {
                "acc_919006065076": {
                    "phone": "+919006065076",
                    "session_file": "/x/cluster_919006065076.session"},
                "__primary__": {"account_id": "acc_919006065076"},
            }
        self.mt.get_userbot_cluster = lambda: _One()
        h = self.mt.account_session_health()
        self.assertEqual(h["total_files"], 1)
        self.assertEqual(h["live"], 1)
        self.assertEqual(h["cluster_accounts"], 1,
                         "the dual-role registration must count ONCE")
        self.assertEqual(h["expected_cluster"], 1)
        d = h["details"][0]
        self.assertEqual(d["status"], "primary_global")
        self.assertEqual(d["account_id"], "acc_919006065076")
        self.assertEqual(d["roles"], "primary,cluster")

    def test_d4_two_accounts_report_two(self):
        """Mission §8: after adding a second account, health reports
        cluster_accounts=2 expected_cluster=2 when two valid accounts
        actually exist."""
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_919006065076.session"),
            Path("/x/cluster_918335829278.session"),
        ]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = \
            "/x/cluster_919006065076.session"
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self.mt._register_session_status(
            "cluster_919006065076.session", "imported",
            username="Official_Ishitaa", user_id=8699582859,
            account_id="acc_919006065076")
        self.mt._register_session_status(
            "cluster_918335829278.session", "imported",
            username="Gradieer", user_id=918335829278,
            account_id="acc_918335829278")

        class _Two:
            _accounts = {
                "acc_919006065076": {
                    "phone": "+919006065076",
                    "session_file": "/x/cluster_919006065076.session"},
                "acc_918335829278": {
                    "phone": "+918335829278",
                    "session_file": "/x/cluster_918335829278.session"},
                "__primary__": {"account_id": "acc_919006065076"},
            }
        self.mt.get_userbot_cluster = lambda: _Two()
        h = self.mt.account_session_health()
        self.assertEqual(h["cluster_accounts"], 2)
        self.assertEqual(h["expected_cluster"], 2)
        by_file = {d["file"]: d for d in h["details"]}
        self.assertEqual(
            by_file["cluster_919006065076.session"]["roles"],
            "primary,cluster")
        self.assertEqual(
            by_file["cluster_918335829278.session"]["status"],
            "cluster_account_id=acc_918335829278")

    def test_d5_special_keys_never_crash_enumeration(self):
        """Non-dict / __-prefixed values in _accounts never crash the
        health loop (RC-15 preserved under the new counting)."""
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_919006065076.session")]
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = ""
        self.mt._SESSION_HEALTH_REGISTRY.clear()

        class _Weird:
            _accounts = {
                "acc_1": {"phone": "+111",
                          "session_file": "/x/cluster_919006065076.session"},
                "__primary__": {"account_id": "acc_1"},
                "__meta__": 42,          # non-dict special value
                "__strange__": "hello",  # string special value
            }
        self.mt.get_userbot_cluster = lambda: _Weird()
        h = self.mt.account_session_health()  # must NOT raise
        self.assertEqual(h["expected_cluster"], 1)


# ---------------------------------------------------------------------------
# Section E — source contracts (removed phantom register + observability)
# ---------------------------------------------------------------------------

class TestFinalRebuildContracts(unittest.TestCase):

    def test_e1_absent_path_no_phantom_registry_register(self):
        """RC-F3: the pipeline's absent path must NOT go through
        _vc_call_gone_evidence_check (whose register wrote state=joined on
        absent verdicts — the 2026-09-12 phantom bookkeeping)."""
        gate_src = _grab_fn(_PIPE_TEXT, "_verify_participation")
        self.assertNotIn("_vc_call_gone_evidence_check(", gate_src,
                         "the absent path must use the PURE identity probe")
        run_src = _grab_fn(_PIPE_TEXT, "run_vc_join")
        # the absent branch cleans up with an explicit reason:
        self.assertIn("VC_JOIN_CLEANUP_REASON", run_src)
        self.assertIn("reason=telegram_absent", run_src)

    def test_e2_evidence_check_pair_semantics(self):
        """RC-F4: the (id, access_hash) PAIR is the identity — the
        misleading old==new 'IDENTITY_REFRESHED' wording is replaced by
        CHANGED/CONFIRMED."""
        ev_src = _grab_fn(_VC_TEXT, "_vc_call_gone_evidence_check")
        self.assertIn("_pair_changed", ev_src)
        self.assertIn("VC_CALL_IDENTITY_CHANGED", ev_src)
        self.assertIn("VC_CALL_IDENTITY_CONFIRMED", ev_src)
        # the old EMIT (format-string call) is gone:
        self.assertNotIn(
            '"VC_JOIN_IDENTITY_REFRESHED chat_id=%s old_call_id=%s "',
            ev_src)

    def test_e3_matching_sites_use_peer_matcher(self):
        """RC-F1: ALL participant matching sites go through the
        peer-based matcher (no raw getattr(p, \"user_id\") reads)."""
        self.assertIn("if _participant_matches_self(p, my_id):", _VC_TEXT)
        self.assertIn("_participant_matches_self(_p, my_id)", _VC_TEXT)
        self.assertIn(
            "any(_participant_matches_self(p, my_id) for p in participants)",
            _VC_TEXT)
        # the historical blind checks are GONE (the exact CODE forms; the
        # remaining getattr(p, "user_id") mentions are documentation
        # comments + the matcher's intentional legacy-fallback branch):
        self.assertNotIn('if getattr(p, "user_id", None) == my_id:',
                         _VC_TEXT)
        self.assertNotIn(
            'found = any(getattr(p, "user_id", 0) == my_id '
            'for p in participants)', _VC_TEXT)
        self.assertNotIn(
            '_found_self = any(\n                getattr(_p, "user_id", '
            'None) == my_id', _VC_TEXT)

    def test_e4_no_match_streak_escalation_removed(self):
        """RC-F2: ABSENT_VIA_TARGETED_NO_MATCH (the escalation that
        destroyed 9 REAL joins) is REMOVED; the foreign-result branch
        returns unknown."""
        self.assertNotIn("VC_PARTICIPATION_ABSENT_VIA_TARGETED_NO_MATCH",
                         _VC_TEXT)
        self.assertIn("VC_PARTICIPATION_TARGETED_FOREIGN_RESULT", _VC_TEXT)

    def test_e5_vc_join_success_carries_evidence_fields(self):
        self.assertIn("VC_JOIN_SUCCESS chat_id=%s call_id=%s strategy=%s ",
                      _VC_TEXT)
        self.assertIn("attempt_id=%s verification_method=%s ", _VC_TEXT)
        self.assertIn("participant_identity=%s verification_timestamp=%s "
                      "rpc_result=%s", _VC_TEXT)

    def test_e6_attempt_events_present(self):
        for stage in ("VC_ATTEMPT_START", "VC_TARGET_RESOLVED",
                      "VC_ACCOUNT_SELECTED", "VC_CALL_RESOLVED",
                      "VC_JOIN_RPC_START", "VC_JOIN_RPC_RESULT",
                      "VC_VERIFY_START", "VC_VERIFY_RESULT",
                      "VC_ATTEMPT_FINAL"):
            self.assertIn(stage, _PIPE_TEXT, f"missing stage {stage}")

    def test_e7_groupcallinvalid_not_absent_anywhere_in_verify(self):
        """RC-F4: neither query path maps GroupcallInvalid to absent —
        STALE_CALL is the verdict + evidence flag."""
        check_src = _grab_fn(_VC_TEXT, "vc_check_telegram_participation")
        self.assertIn("VC_PARTICIPATION_STALE_CALL ", check_src)
        self.assertIn("VC_PARTICIPATION_STALE_CALL_VIA_TARGETED", check_src)
        self.assertIn('"stale_call": True', check_src)

    def test_e8_verify_hygiene_pure_no_registry_writes(self):
        """Mission §2 single-source-of-truth: _current_call_identity is a
        PURE probe — no vc_registry_register, no backend mutation."""
        probe_src = _grab_fn(_PIPE_TEXT, "_current_call_identity")
        self.assertNotIn("vc_registry_register", probe_src)
        self.assertNotIn("_vc_active_join_backends_by_chat", probe_src)

    def test_e9_version_is_v9905(self):
        init = (_SRC / "__init__.py").read_text(encoding="utf-8")
        self.assertIn('__bot_version__ = "v99.11.1"', init)

    def test_e10_primary_helpers_exist(self):
        self.assertIn("def _primary_value(", _MT_TEXT)
        self.assertIn("def _primary_entry(", _MT_TEXT)
        self.assertIn("_primary_entry(first_aid)", _MT_TEXT)


if __name__ == "__main__":
    unittest.main()
