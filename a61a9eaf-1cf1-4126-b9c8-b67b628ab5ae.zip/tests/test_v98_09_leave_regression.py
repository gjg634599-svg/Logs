"""v98.09 PATCH-2 — VC LEAVE PRODUCTION FIX regression tests.

PRIMARY USER-REPORTED BUG (2026-09-02, uploaded production artifacts
"mediagrab_bot_v98.09_deployment (1).zip" + bot-diagnostic.log +
bot-diagnostic.log.1, runtime DEPLOYMENT_IDENTITY
voicechat_sha256=8a144c8a3d904d82):

  After deploying v98.09 the userbot is still not reliably leaving
  Voice Chats; a fresh zip extract also crashed at import with:
      voicechat.py, line 5356, in <module>
          _register_v9808_hooks(_vc_rotation_settle_begin,
                                _vc_session_import_notify)
      NameError: name '_vc_rotation_settle_begin' is not defined.

ROOT CAUSES (all RUNTIME/SOURCE-PROVEN — see voicechat.py's
"v98.09 PATCH-2" helper block for the full evidence chain):
  DEFECT-1 (import crash): the v98.08 hook registration at module line
    5356 references functions defined at lines 13772/13788 — import-time
    NameError in EVERY real deployment. The sandbox never saw it because
    `import telegram` fails here first and py_compile only checks
    syntax; the production server ran a hand-patched voicechat.py
    (hash 8a144c8a…, matching NO shipped zip), and the fresh extract of
    the v98.09 zip crashed. The previous session's own final artifact
    (voicechat sha256[:16]=afde1b99) carries the SAME defect.
  DEFECT-2 (wrong-backend leave → FALSE SUCCESS): vc_leave_target()
    selected the GLOBAL backend while Join All rotates joins onto
    PER-ACCOUNT backends. PyTgCalls 2.3.3 keeps call objects in a
    per-instance dict keyed by the MARKED id → leave_call() on the
    global instance is a SILENT NO-OP, and _leave_target's verification
    then checked the GLOBAL container (never had the chat) → "success"
    falsely → registry LEFT + record removed + VC_LEAVE_CONFIRMED
    logged while the account backend still held the LIVE call.
    RUNTIME EVIDENCE: log.1 (09:19→12:37) has ZERO VC_LEAVE_* markers
    (no leave ever reached the backend that owned the calls); the
    12:50:53–58 shutdown "confirmed" leaves for the 8 chats joined via
    acc_919006065076 all ran through the global singleton.
  DEFECT-3 (manual Leave no-op): vc_manual_leave → vc_leave_current →
    `if _vc_state.current_call_id is None: return False` — the tour
    state machine is empty in Join-All mode → "not_in_vc" with ZERO
    leave work performed.
  DEFECT-4 (immediate rejoin): nothing deferred rejoin of an
    explicitly-left target — the next Join-All pass recreated the VC.

FIXES UNDER TEST (voicechat.py, v98.09 PATCH-2):
  FIX-IMPORT: deferred lambda lookup at the SAME line (line-count
    neutral — the pinned FIX-CCC call-site is preserved).

    v98.09-P3 TEST-MECHANISM CORRECTION (documented, precedented by the
    PATCH-2 §11 mechanism corrections): the knowledge-cache/fast-path
    section + worker instrumentation insert ~936 lines BEFORE
    _auto_discovery_run_one_cycle, moving the FIX-CCC call-site from
    20063 → 21006. The pin's INVARIANT is unchanged: exactly ONE
    _vc_discovery_select_queries_bounded call-site inside the cycle,
    at the new pinned line.
  FIX-LEAVE-OWNER: _v9809_leave_owner_backend resolves the OWNER
    backend (ownership map both ID forms → registry account_id →
    global fallback), _v9809_leave_target_verified emits the §10
    marker chain (VC_LEAVE_BEGIN / VC_LEAVE_API_CALL / API_RETURN /
    POST_STATE / FINAL) and performs AGGREGATED cross-backend
    verification (downgrades false successes to "failed"),
    _v9809_leave_owner_release releases ownership + records the §8
    5-minute rejoin cooldown, _v9809_leave_rejoin_deferred gates the
    Join-All target loop.
  FIX-MANUAL-LEAVE: vc_manual_leave falls back to the verified
    Leave-All path when the tour holds no call but tracked
    participations exist.

EVIDENCE CLASSIFICATION:
  * RUNTIME-PROVEN: traced to the uploaded logs with timestamps, chat
    IDs (1922822605; 1393246704 … 2064111110), account ids
    (acc_919006065076, acc_918335829278) and the pasted traceback.
  * SOURCE-PROVEN: verified in the deployed zip's source.
  * TEST-PROVEN: this file + tests/_v9809_leave_driver.py (subprocess:
    imports the REAL voicechat.py with stub dependencies and runs the
    REAL production leave path against a fake PyTgCalls implementing
    the runtime-proven 2.3.3 semantics).

ANTI-CHEATING GUARANTEE: the driver FAILS on the previous session's
shipped artifact (import NameError) and FAILS 9/11 cases on that
artifact with only the import line hand-patched (the user's production
equivalent) — it passes 11/11 on the fixed tree. No assertions were
weakened to achieve this.
"""

from __future__ import annotations

import ast
import builtins
import os
import subprocess
import sys
import unittest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
_VOICECHAT = os.path.join(_ROOT, "mediagrab_bot", "voicechat.py")
_DRIVER = os.path.join(_HERE, "_v9809_leave_driver.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read()


# ---------------------------------------------------------------------------
# §1 — Import-order regression (DEFECT-1): a REAL import-time name
# resolution check. Simulates Python's module-body execution order: every
# top-level statement's LOADed names must already be bound (imports,
# earlier defs/assignments) — function/class/lambda BODIES are deferred
# (resolved at call time), but decorators/defaults execute at def time.
# ---------------------------------------------------------------------------

_IMPLICIT = {
    "__name__", "__file__", "__doc__", "__spec__", "__loader__",
    "__package__", "__path__", "__builtins__", "__all__", "__debug__",
    "__annotations__", "__dict__", "__module__", "__qualname__",
}


class _ImportOrderChecker:
    """AST import-time name-resolution simulator (see §1)."""

    def __init__(self, tree: ast.Module):
        self.violations: list[tuple[int, str]] = []
        self.bound: set[str] = set(dir(builtins)) | _IMPLICIT
        self._walk(tree.body)

    # -- deferred scopes: bodies execute later; decorators/defaults now --
    def _deferred_exprs(self, node):
        out = list(getattr(node, "decorator_list", []))
        args = getattr(node, "args", None)
        if args is not None:
            out += list(args.defaults)
            out += [d for d in args.kw_defaults if d is not None]
            # *args/**kwargs annotations unused; positional defaults matter.
        return out

    def _walk(self, stmts) -> None:
        for st in stmts:
            self._stmt(st)

    def _bind(self, target) -> None:
        if isinstance(target, ast.Name):
            self.bound.add(target.id)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for e in target.elts:
                self._bind(e)
        elif isinstance(target, ast.Starred):
            self._bind(target.value)
        # Subscript/Attribute targets bind nothing.

    def _stmt(self, st) -> None:
        if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for e in self._deferred_exprs(st):
                self._expr(e)
            self.bound.add(st.name)
        elif isinstance(st, ast.ClassDef):
            for e in list(st.decorator_list) + list(st.bases) + [
                    kw.value for kw in st.keywords]:
                self._expr(e)
            self.bound.add(st.name)
            self._walk(st.body)
        elif isinstance(st, (ast.Import, ast.ImportFrom)):
            for a in st.names:
                self.bound.add(a.asname or a.name.split(".")[0])
        elif isinstance(st, ast.Assign):
            self._expr(st.value)
            for t in st.targets:
                self._bind(t)
        elif isinstance(st, ast.AnnAssign):
            if st.value is not None:
                self._expr(st.value)
            if st.target is not None:
                self._bind(st.target)
        elif isinstance(st, ast.AugAssign):
            self._expr(st.value)
            self._expr(st.target)
        elif isinstance(st, ast.Expr):
            self._expr(st.value)
        elif isinstance(st, (ast.If, ast.While)):
            self._expr(st.test)
            self._walk(st.body)
            self._walk(st.orelse)
        elif isinstance(st, (ast.For, ast.AsyncFor)):
            self._expr(st.iter)
            self._bind(st.target)
            self._walk(st.body)
            self._walk(st.orelse)
        elif isinstance(st, (ast.With, ast.AsyncWith)):
            for item in st.items:
                self._expr(item.context_expr)
                if item.optional_vars is not None:
                    self._bind(item.optional_vars)
            self._walk(st.body)
        elif isinstance(st, ast.Try):
            self._walk(st.body)
            for h in st.handlers:
                if h.name:
                    self.bound.add(h.name)
                if h.type is not None:
                    self._expr(h.type)
                self._walk(h.body)
            self._walk(st.orelse)
            self._walk(st.finalbody)
        elif isinstance(st, ast.Assert):
            self._expr(st.test)
            if st.msg is not None:
                self._expr(st.msg)
        elif isinstance(st, ast.Delete):
            for t in st.targets:
                if isinstance(t, ast.Name):
                    self.bound.discard(t.id)
        elif isinstance(st, ast.Global):
            for n in st.names:
                self.bound.add(n)  # declared, not executed — tolerate.
        elif isinstance(st, ast.Pass):
            pass
        # Raise/Return/Import etc. are invalid/irrelevant at module level.

    def _expr(self, node) -> None:
        """Visit an expression subtree WITHOUT descending into deferred
        scopes (function/class/lambda bodies); their decorators and
        default values still execute at the def site."""
        self._visit(node)

    def _visit(self, node) -> None:
        if isinstance(node, ast.Name):
            if isinstance(node.ctx, ast.Load):
                if node.id not in self.bound:
                    self.violations.append((node.lineno, node.id))
            else:
                self.bound.add(node.id)
            return
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef, ast.Lambda)):
            for e in self._deferred_exprs(node):
                self._visit(e)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                 ast.ClassDef)):
                self.bound.add(node.name)
            return  # body is deferred — do NOT descend
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names:
                self.bound.add(a.asname or a.name.split(".")[0])
            return
        if isinstance(node, ast.comprehension):
            self._bind(node.target)  # bound before element exprs
        for child in ast.iter_child_nodes(node):
            self._visit(child)


class TestImportOrderRegression(unittest.TestCase):
    """DEFECT-1 class — any import-time NameError is caught statically."""

    @classmethod
    def setUpClass(cls):
        cls.tree = ast.parse(_read(_VOICECHAT))
        cls.checker = _ImportOrderChecker(cls.tree)
        cls.src = _read(_VOICECHAT)

    def test_no_import_time_unresolved_names(self):
        self.assertEqual(
            self.checker.violations, [],
            "import-time name resolution violations (line, name): "
            f"{self.checker.violations[:10]} — module would crash on "
            "import in production (the v98.09 DEFECT-1 class)")

    def test_v9808_hook_registration_is_deferred(self):
        """The line-5356 registration must not reference late defs directly."""
        lines = self.src.splitlines()
        # v99: window 5975:5990 -> 5120:5145 (the join body moved to
        # vc_pipeline.py — the registration shifted up; contract
        # unchanged: lambda-deferred name resolution).
        # v99.05: window 5090:5115 -> 5115:5145 (the RC-F1 helper
        # insertion above shifted the registration call to 5137;
        # contract unchanged).
        # v99.03: window 5080:5105 -> 5090:5115 (the RC-13 reconcile
        # short-circuit insertion (+14 lines above) shifted the
        # registration call to 5108; contract unchanged).
        # v99.06: window 5115:5145 -> 5445:5485 (the FIX-3a/3b
        # distribution/ownership helper block + the FIX-1
        # effective-scope helpers inserted above shifted the
        # registration call to 5473; contract unchanged).
        # v99.07: window 5445:5485 -> 5605:5655 (the FIX-1/2/3
        # backend-start unification + FIX-4 + FIX-8 insertions above
        # shifted the registration call to 5633; contract unchanged).
        # v99.08: window 5605:5655 -> 5720:5740 (the v99.08 item-8
        # cache-bound helpers + Patch-1/Patch-2 blocks inserted above
        # shifted the registration call to 5722; contract unchanged).
        # v99.09: window 5720:5740 -> 5740:5780 (the FIX-C
        # verify_joined ownership-lookup rewrite in
        # PyTgCallsBackend shifted the registration call to 5761;
        # contract unchanged).
        # v99.10: window 5740:5780 -> 5800:5850 (the FIX-A
        # is_connected delegation guard + the FIX-B stub-mtproto
        # fallback import block at the module head shifted the
        # registration call to 5832; contract unchanged).
        # v99.11: window 5800:5850 -> 5900:5950 (the v99.11 leave-policy
        # + admission/lifecycle blocks above the registration shifted it
        # to 5926; contract unchanged: deferred registration preserved).
        # v99.11.1: window 5900:5950 -> 6020:6070 (the FIX-3 helper at
        # the module head shifted the registration call to 6061;
        # contract unchanged: deferred registration + lambda).
        reg = [ln for ln in lines[6020:6070]
               if ln.strip().startswith("_register_v9808_hooks")]
        self.assertTrue(reg, "registration call not found near line 5356")
        self.assertIn("lambda", reg[0],
                      "registration must defer name resolution (lambda)")

    def test_fixccc_line_contract_still_20063(self):
        """Pinned FIX-CCC call-site contract (shared with the arch +
        termination suites) — preserved by the line-neutral PATCH-2 edits."""
        node = None
        for n in self.tree.body:
            if isinstance(n, ast.AsyncFunctionDef) \
                    and n.name == "_auto_discovery_run_one_cycle":
                node = n
        calls = [n.lineno for n in ast.walk(node)
                 if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Name)
                 and n.func.id == "_vc_discovery_select_queries_bounded"]
        # v98.12-FINAL2: 21478 -> 21944 (documented correction; +466 lines
        # of v98.12-FINAL2 insertions above the anchor — FIX-LC leave/
        # coordinator sync + invariant check in vc_leave_target, FIX-TQ
        # quarantine state/helpers, FIX-SR startup reconcile, FIX-WV
        # owner-account watcher verify, FIX-PM metrics keying; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99: 22911 -> 21827 (documented correction; the v99 pipeline
        # rewrite moved the 850-line join body out of voicechat.py into
        # vc_pipeline.py — net -794 lines above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.05: 21980 -> 22197 (documented correction; the RC-F1
        # peer-matching helper + targeted-query/verification fixes
        # added +217 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.03: 21930 -> 21980 (documented correction; the RC-13
        # discovery/reconcile short-circuit insertions (+50 lines
        # above the anchor) shifted the call-site; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.02: 21827 -> 21930 (documented correction; the FIX-2
        # targeted-no-match absent-streak block + the FIX-5a/5b identity
        # resolution fixes in vc_check_telegram_participation /
        # vc_verify_target added +103 lines above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.06: 22197 -> 22874 (documented correction; the FIX-2
        # parallel per-account discovery pass helpers + the concurrent
        # launch/await blocks inside _auto_discovery_run_one_cycle
        # added +677 lines above the anchor; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.06 (D8 fix correction): 22874 -> 22885 — the FIX-3b
        # registry terminal-state entry-capture fix in
        # vc_registry_register added +11 lines above the anchor;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.07: 22885 -> 23116 (documented correction; the FIX-1/2/3
        # backend-start unification [getter rewrite + _adopt_started_transport
        # method + generation tracking + join-site start gate] + FIX-4
        # shutdown disambiguation + FIX-8 filter-scan counters added +231
        # lines above the anchor; INVARIANT unchanged: ONE call-site,
        # zero while-loops)
        # v99.07 (post-FIX-12 correction): 23116 -> 23129 — the FIX-12
        # worker-heartbeat block at the vc_reconcile_loop head sits ABOVE
        # the discovery cycle and added +13 lines to the anchor shift;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        # v99.08: 23129 -> 23263 (documented correction; the v99.08
        # Patch-1 + item-8 insertions above the anchor; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.09: 23263 -> 23302 (documented correction; the FIX-C
        # verify_joined form-aware ownership lookup + one-hop
        # delegation guard in PyTgCallsBackend (above the discovery
        # cycle) added +39 lines to the anchor shift; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.10: 23302 -> 23776 (documented correction; the FIX-A
        # is_connected delegation guard + FIX-B resource-pressure
        # classifier + FIX-C guard/wait + FIX-E auto-resume + FIX-F
        # register-owner rewrite (all above the discovery cycle)
        # added +474 lines to the anchor shift; INVARIANT unchanged:
        # ONE call-site, zero while-loops)
        # v99.11: 23776 -> 24553 (documented correction; the P0 leave-
        # policy reason-code wiring + the get_contacts ladder + the
        # admission-gate/lifecycle blocks + the P1 verification-state
        # classification/backoff + the crash-loop startup-recovery
        # guard (all above the anchor) added +777 lines; INVARIANT
        # unchanged: ONE call-site, zero while-loops)
        # v99.11 (config-audit correction): 24553 -> 24561 — the
        # VC_JOIN_RETRY_BASE/MAX_SECONDS env wiring at module top
        # added +8 lines above the anchor; INVARIANT unchanged.
        # v99.11.1 (documented correction): 24561 -> 24962 — the FIX-3
        # already-joined classification helper at the module head
        # (+401 lines above the anchor) shifted the call-site;
        # INVARIANT unchanged: ONE call-site, zero while-loops.
        self.assertEqual(calls, [24962])

    def test_cycle_still_has_zero_while_loops(self):
        node = None
        for n in self.tree.body:
            if isinstance(n, ast.AsyncFunctionDef) \
                    and n.name == "_auto_discovery_run_one_cycle":
                node = n
        whiles = [n.lineno for n in ast.walk(node)
                  if isinstance(n, ast.While)]
        self.assertEqual(whiles, [])


# ---------------------------------------------------------------------------
# §2 — Behavioral regression (subprocess): the REAL module + REAL leave
# path vs a fake PyTgCalls with runtime-proven 2.3.3 semantics.
# ---------------------------------------------------------------------------

class TestLeaveBehavioralRegression(unittest.TestCase):
    """§11 Cases A–G (+ D2 cross-backend, G2, H contract, SHUTDOWN path)."""

    @classmethod
    def setUpClass(cls):
        cls.proc = subprocess.run(
            [sys.executable, _DRIVER],
            capture_output=True, text=True, timeout=300, cwd=_ROOT)
        cls.out = cls.proc.stdout
        cls.case_lines = [ln for ln in cls.out.splitlines()
                          if ln.startswith("CASE ") or
                          ln.startswith("IMPORT:")]

    def test_exit_code_zero(self):
        self.assertEqual(self.proc.returncode, 0,
                         f"driver failures:\n{self.out[-4000:]}")

    def test_import_pass_line(self):
        self.assertIn("IMPORT: PASS", self.out,
                      f"import failed:\n{self.proc.stderr[-2000:]}")

    def test_all_cases_present_and_passing(self):
        expected = {"A", "B", "C", "D", "D2", "E", "F", "G", "G2", "H",
                    "SHUTDOWN"}
        seen = set()
        for ln in self.case_lines:
            if ln.startswith("CASE "):
                cid = ln.split()[1].rstrip(":")
                seen.add(cid)
                self.assertIn(": PASS — ", ln,
                              f"case {cid} did not pass: {ln}")
        self.assertTrue(expected <= seen,
                        f"missing cases: {expected - seen}")

    def test_case_a_raw_join_marked_storage(self):
        self.assertIn("CASE A: PASS", self.out)

    def test_case_b_marked_input(self):
        self.assertIn("CASE B: PASS", self.out)

    def test_case_c_owner_backend_not_global(self):
        self.assertIn("CASE C: PASS", self.out)

    def test_case_d_silent_noop_reports_failure(self):
        self.assertIn("CASE D: PASS", self.out)

    def test_case_f_rejoin_deferral(self):
        self.assertIn("CASE F: PASS", self.out)

    def test_case_g_manual_leave_reaches_verified_mechanism(self):
        self.assertIn("CASE G: PASS", self.out)


# ---------------------------------------------------------------------------
# §3 — Static contracts: markers + call-site contents + preserved
# v97.83/v98.04 invariants.
# ---------------------------------------------------------------------------

class TestLeaveStaticContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.src = _read(_VOICECHAT)

    def test_owner_resolution_wired_into_vc_leave_target(self):
        self.assertIn(
            "backend = _v9809_leave_owner_backend(chat_id, rec)",
            self.src)

    def test_verified_wrapper_wired_into_vc_leave_target(self):
        self.assertIn(
            "outcome = await _v9809_leave_target_verified(backend, "
            "chat_id, caller=_caller_func, source=_leave_source)",
            self.src)

    def test_owner_release_replaces_bare_registry_remove(self):
        self.assertIn(
            "await _v9809_leave_owner_release(chat_id)",
            self.src)

    def test_leave_api_instrumentation_on_all_four_apis(self):
        for api in ("leave_group_call", "leave_call",
                    "leave_current_call", "stop_call"):
            self.assertIn(
                f'await _v9809_leave_api(self, "{api}"',
                self.src, f"API {api} not instrumented")

    def test_marker_chain_present(self):
        for marker in ("VC_LEAVE_BEGIN", "VC_LEAVE_API_CALL",
                       "VC_LEAVE_API_RETURN", "VC_LEAVE_POST_STATE",
                       "VC_LEAVE_FINAL", "VC_LEAVE_OWNER_RESOLVED",
                       "VC_LEAVE_OWNER_RELEASED", "VC_REJOIN_DEFERRED"):
            self.assertIn(marker, self.src)

    def test_final_results_vocabulary(self):
        for res in ("CONFIRMED_LEFT", "FAILED", "UNKNOWN",
                    "container_still_present"):
            self.assertIn(res, self.src)

    def test_manual_leave_fallback_present(self):
        self.assertIn(
            "result = await vc_leave_all_tracked(include_intentional=True)",
            self.src)
        self.assertIn("VC_MANUAL_LEAVE_TRACKED", self.src)
        self.assertIn("left_tracked", self.src)

    def test_manual_leave_preserves_not_in_vc_when_nothing_tracked(self):
        self.assertIn('return "not_in_vc"', self.src)

    def test_rejoin_deferral_wired_into_join_all_target_loop(self):
        self.assertIn(
            "if _v9809_leave_rejoin_deferred(gid, run_id=_run_id):",
            self.src)

    def test_v9783_leave_block_contract_preserved(self):
        """The Join-All leave-block invariant (blocked_during_join_all)
        must survive PATCH-2 — Case H proves it behaviorally."""
        self.assertIn("blocked_during_join_all", self.src)
        self.assertIn("_vc_is_leave_blocked_during_join_all", self.src)

    def test_v9804_fixx_both_forms_semantics_preserved(self):
        """The v98.04 FIX-X both-forms leave loop is untouched (PATCH-2
        only instruments the API calls and fixes backend selection)."""
        self.assertIn("_forms = [chat_id, _marked]", self.src)
        self.assertIn("forms_tried=", self.src)

    def test_helpers_defined_once(self):
        for name in ("_v9809_leave_id_forms", "_v9809_leave_owner_backend",
                     "_v9809_leave_api", "_v9809_leave_target_verified",
                     "_v9809_leave_owner_release",
                     "_v9809_leave_rejoin_deferred"):
            count = self.src.count(f"def {name}(")
            self.assertEqual(count, 1, f"{name} defined {count}x")

    def test_helper_block_documented_with_evidence(self):
        self.assertIn("v98.09 PATCH-2 (2026-09-02) — VC LEAVE PRODUCTION FIX",
                      self.src)
        self.assertIn("DEFECT-2 (wrong-backend leave", self.src)
        self.assertIn("DEFECT-3 (manual Leave button no-op", self.src)

    def test_vc_leave_all_tracked_unchanged_contract(self):
        """vc_leave_all_tracked still drives per-target vc_leave_target
        through the 15s bounded wait_for (§13 preserved behavior; the
        per-target leaves become owner-aware via FIX-LEAVE-OWNER)."""
        self.assertIn("asyncio.wait_for(\n                vc_leave_target"
                      "(rec.chat_id), timeout=15,", self.src)


if __name__ == "__main__":
    unittest.main()
