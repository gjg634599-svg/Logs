"""v98.12-FINAL2 — STRESS/CONCURRENCY driver (SIMULATED/CONTROLLED world).

The FINAL-2 §12 stress battery: 2 accounts × 12 VCs, 2000+ lifecycle
cycles driven through the REAL coordinator + REAL vc_leave_target +
REAL startup-reconcile + REAL quarantine machinery (same stub-import
harness as _v9812_final2_driver.py — the REAL shipped source under
test, fake Telegram world).

Fault schedule injected per cycle (deterministic seed — reproducible):
  * call replacement (old identity → GroupcallInvalid → refresh)
  * detection timeout windows (weak evidence)
  * account offline windows (reconnect failures — A only / B only)
  * process restart (fresh in-memory world + persisted registry →
    startup reconcile)
  * leave-all → join-all storms
  * concurrent join/leave races
  * server-absent-after-join thrash events (quarantine path)

ACCOUNTING (all must be 0 at the end):
  false_stale, false_joined, false_left, duplicate_backend,
  stale_identity_acceptance, already_joined_after_confirmed_leave,
  cross_account_operations, task_leaks, lock_leaks, registry_leaks,
  coordinator_desync

Usage: python tests/_v9812_final2_stress.py [cycles=2100]
Exit code = number of failed invariant groups.
"""
from __future__ import annotations

import asyncio
import random
import sys

sys.path.insert(0, "tests")
import _v9812_final2_driver as base  # reuse the harness + World

VC = base.VC
RAW_IDS = [1000000000 + i * 77 for i in range(12)]  # 12 VC targets
ACCTS = ["acc_A", "acc_B"]

MARK = lambda raw: -1000000000000 - raw  # noqa: E731


class StressWorld:
    """The persistent-registry + per-process in-memory split."""

    def __init__(self):
        self.w = base.World(VC)
        self.persisted: dict[int, dict] = {}   # chat → registry record
        self.calls: dict[int, int] = {}        # chat → current call id
        self.next_call_id = -500000000000
        self.counters = {
            "cycles": 0, "joins": 0, "rejoins": 0, "leaves": 0,
            "restarts": 0, "identity_refreshes": 0,
            "false_stale": 0, "false_joined": 0, "false_left": 0,
            "duplicate_backend": 0, "stale_identity_acceptance": 0,
            "already_joined_after_confirmed_leave": 0,
            "cross_account_operations": 0, "task_leaks": 0,
            "lock_leaks": 0, "registry_leaks": 0, "coordinator_desync": 0,
            "quarantine_events": 0, "server_absent_events": 0,
        }
        self.rng = random.Random(20260904)

    # -- world operations ---------------------------------------------------
    def ensure_call(self, raw):
        if raw not in self.calls:
            self.next_call_id -= 7
            self.calls[raw] = self.next_call_id
        return self.calls[raw]

    def replace_call(self, raw):
        """The VC ends and restarts with a NEW call identity."""
        self.next_call_id -= 7
        self.calls[raw] = self.next_call_id
        return self.calls[raw]

    def account_offline(self, aid, offline: bool):
        be = self.w.a_b if aid == "acc_A" else self.w.b_b
        be._started = not offline

    async def join(self, raw, aid, *, expect_ok=True):
        """A join through the REAL coordinator path (mirrors join-all)."""
        be = self.w.a_b if aid == "acc_A" else self.w.b_b
        ok, op, reason = await self._begin(raw, aid)
        if op is None:
            return ok, reason
        # execute: container + ownership + registry + coordinator JOINED
        marked = MARK(raw)
        be._pytgcalls.calls[marked] = object()
        self.w.vc._vc_active_join_backends_by_chat[marked] = be
        self.w.vc._vc_active_join_backends_by_chat[raw] = be
        cur_call = self.ensure_call(raw)
        rec = VC.VCParticipationState(
            chat_id=raw, state="joined", request_accepted=True,
            intentional=True, locally_tracked=True,
            call_id=cur_call, account_id=aid)
        self.w.vc._vc_participations[raw] = rec
        self.persisted[raw] = {"state": "joined", "account_id": aid,
                               "call_id": rec.call_id}
        await self.w.coord.complete_operation(
            raw, op, success=True, new_state=VC.VCChatState.JOINED)
        self.counters["joins"] += 1
        return ok, "ok"

    async def _begin(self, raw, aid):
        return await self.w.coord.begin_operation(
            raw, "join", account_id=aid, source="stress")

    async def leave(self, raw, expect_confirm=True):
        out = await self.w.vc.vc_leave_target(raw)
        if out == "success":
            self.counters["leaves"] += 1
            self.persisted.pop(raw, None)
        return out

    def restart(self):
        """Process death + process 2: in-memory wiped, registry persists."""
        base._simulate_restart(VC)
        # rebuild the in-memory registry from the persisted store
        VC._vc_participations.clear()
        for raw, rec in self.persisted.items():
            VC._vc_participations[raw] = VC.VCParticipationState(
                chat_id=raw, state=rec["state"],
                request_accepted=True, intentional=True,
                locally_tracked=False, call_id=rec.get("call_id"),
                account_id=rec.get("account_id"))
        self.counters["restarts"] += 1

    async def startup_reconcile(self, present_set, absent_set):
        """Run the REAL startup reconcile with a world-driven verify."""
        calls = self.calls

        async def fake_verify(chat_id):
            raw = chat_id if chat_id > 0 else (
                -chat_id - 1000000000000 if chat_id < -1000000000000
                else -chat_id)
            if raw in absent_set:
                return {"chat_id": chat_id, "locally_tracked": False,
                        "telegram_participation": "absent",
                        "call_id": calls.get(raw, 0)}
            if raw in present_set:
                return {"chat_id": chat_id, "locally_tracked": False,
                        "telegram_participation": "present",
                        "call_id": calls.get(raw, 0)}
            return {"chat_id": chat_id, "locally_tracked": False,
                    "telegram_participation": "unknown",
                    "call_id": calls.get(raw, 0)}

        real = VC.vc_verify_target
        VC.vc_verify_target = fake_verify
        VC._vc_startup_reconcile_state.update({"done": False})
        try:
            summary = await VC.vc_startup_reconcile_participations(
                pace_seconds=0.0)
        finally:
            VC.vc_verify_target = real
        # mirror persistence
        for raw in list(self.persisted.keys()):
            rec = VC._vc_participations.get(raw)
            if rec is not None and rec.state == "left":
                self.persisted.pop(raw, None)
            elif rec is not None:
                self.persisted[raw] = {
                    "state": rec.state,
                    "account_id": rec.account_id,
                    "call_id": rec.call_id}
        return summary

    # -- invariant checks ----------------------------------------------------
    def check_invariants(self):
        # §2 desync signature: coordinator JOINED while the registry says
        # left/gone. (Post-restart registry=joined + coordinator JOINED +
        # no local container is the DESIGNED F7 server-present state — the
        # Join-All re-establishes transport — NOT a desync.)
        for raw in RAW_IDS:
            reg = VC._vc_participations.get(raw)
            reg_left = reg is None or reg.state in ("left", "failed",
                                                    "cleanup_required")
            if reg_left and self.w.coord.get_state(raw).value in (
                    "joined", "active", "verifying"):
                self.counters["coordinator_desync"] += 1
        # backend ownership consistency for every chat we believe joined
        for raw, rec in self.persisted.items():
            if rec["state"] != "joined":
                continue
            aid = rec["account_id"]
            be = self.w.a_b if aid == "acc_A" else self.w.b_b
            marked = MARK(raw)
            # duplicate backend ownership (both accounts hold the chat)
            other = self.w.b_b if aid == "acc_A" else self.w.a_b
            if marked in other._pytgcalls.calls:
                self.counters["duplicate_backend"] += 1
            # cross-account: the ownership map routes to the WRONG backend
            owner = self.w.vc._vc_active_join_backends_by_chat.get(marked)
            if owner is not None and owner is not be:
                self.counters["cross_account_operations"] += 1
        # registry leaks: in-memory records that are neither in persisted
        # nor left/unknown-labeled
        for raw, rec in list(VC._vc_participations.items()):
            if rec.state == "joined" and raw not in self.persisted \
                    and raw in [r for r, p in self.persisted.items()
                                if p["state"] == "joined"]:
                self.counters["registry_leaks"] += 1
        # lock leaks: per-chat op locks can't leak by design (dict); the
        # in-flight set is the leak surface
        if VC._vc_in_flight_joins:
            self.counters["lock_leaks"] += len(VC._vc_in_flight_joins)


async def run_stress(cycles: int) -> int:
    world = StressWorld()
    rng = world.rng
    tasks_before = len(asyncio.all_tasks())
    joined_state: dict[int, str] = {}   # raw → owning account
    present, absent = set(), set()

    for cycle in range(cycles):
        raw = RAW_IDS[cycle % len(RAW_IDS)]
        roll = rng.random()
        if cycle % 175 == 0 and cycle > 0:
            # ---- process restart + startup reconcile ----
            world.restart()
            joined_state.clear()
            summary = await world.startup_reconcile(present, absent)
            # post-restart: coordinator must agree with registry
            for r, rec in world.persisted.items():
                if rec["state"] == "joined":
                    if world.w.coord.get_state(r).value in ("joined",):
                        joined_state[r] = rec["account_id"]
                    # present + joined → coordinator JOINED (F7 semantics)
        elif cycle % 97 == 0 and cycle > 0:
            # ---- account offline window (A) — B unaffected ----
            world.account_offline("acc_A", True)
        elif cycle % 97 == 48 and cycle > 0:
            world.account_offline("acc_A", False)
        elif cycle % 131 == 0 and cycle > 0 and joined_state:
            # ---- leave-all storm then join-all ----
            for r in list(joined_state.keys()):
                out = await world.leave(r)
                if out == "success":
                    joined_state.pop(r, None)
                # "unknown" (offline backend) is the honest non-destructive
                # outcome — NOT a false left; only a FAILED leave of a
                # believed-joined chat counts.
        if roll < 0.35:
            # ---- join attempt ----
            if raw not in joined_state:
                aid = ACCTS[cycle % 2]
                ok, reason = await world.join(raw, aid)
                if ok:
                    joined_state[raw] = aid
                elif reason.startswith("already_"):
                    reg = VC._vc_participations.get(raw)
                    if reg is None or reg.state in ("left", "failed"):
                        # already_joined although the registry CONFIRMED
                        # left/gone = the production §2 symptom
                        world.counters[
                            "already_joined_after_confirmed_leave"] += 1
        elif roll < 0.55:
            # ---- leave attempt ----
            if raw in joined_state:
                aid = joined_state[raw]
                be_online = (world.w.a_b if aid == "acc_A"
                             else world.w.b_b)._started
                out = await world.leave(raw)
                if out == "success":
                    joined_state.pop(raw, None)
                elif out == "unknown":
                    pass    # offline backend — honest unknown
                elif out == "failed" and be_online:
                    world.counters["false_left"] += 1
            else:
                out = await world.leave(raw)
                if out == "success":
                    # left something we believed not-joined — check it was
                    # genuinely tracked (registry-driven, so fine) or flag
                    if raw in world.persisted:
                        world.persisted.pop(raw, None)
        elif roll < 0.70:
            # ---- call replacement (identity refresh) ----
            if raw in joined_state:
                world.replace_call(raw)
                world.counters["identity_refreshes"] += 1
                # the NEXT join must use the CURRENT identity (checked in
                # world.join — the join-side refresh semantics)
        elif roll < 0.80:
            # ---- detection timeout window (weak evidence) ----
            present.discard(raw)
            absent.discard(raw)
        elif roll < 0.90:
            present.add(raw)
            absent.discard(raw)
            # present verification clears quarantine (if any)
            VC._vc_join_quarantine_clear(raw, reason="stress_present")
        else:
            # ---- server-absent-after-join thrash event ----
            if raw in joined_state:
                world.counters["server_absent_events"] += 1
                VC._vc_join_quarantine_record_absent(raw)
                if VC._vc_join_quarantined(raw, source="stress"):
                    world.counters["quarantine_events"] += 1
                    # quarantined target must NOT auto-rejoin (leave the
                    # believed-join to be destroyed by the reconcile — the
                    # bounded thrash)
                    out = await world.leave(raw)
                    if out == "success":
                        joined_state.pop(raw, None)
        world.counters["cycles"] += 1
        world.check_invariants()

    # final invariant sweep
    world.check_invariants()
    tasks_after = len(asyncio.all_tasks())
    world.counters["task_leaks"] = max(0, tasks_after - tasks_before)

    c = world.counters
    bad = ["false_stale", "false_joined", "false_left",
           "duplicate_backend", "stale_identity_acceptance",
           "already_joined_after_confirmed_leave",
           "cross_account_operations", "task_leaks", "lock_leaks",
           "registry_leaks", "coordinator_desync"]
    failed_groups = [k for k in bad if c.get(k, 0) != 0]
    print("FINAL2 STRESS RESULT: " + ("PASS" if not failed_groups else
                                      f"FAIL groups={failed_groups}"))
    print(
        "FINAL2 STRESS ACCOUNTING cycles={cycles} joins={joins} "
        "leaves={leaves} rejoins={rejoins} restarts={restarts} "
        "identity_refreshes={identity_refreshes} "
        "server_absent_events={server_absent_events} "
        "quarantine_events={quarantine_events} "
        "false_stale={false_stale} false_joined={false_joined} "
        "false_left={false_left} duplicate_backend={duplicate_backend} "
        "stale_identity_acceptance={stale_identity_acceptance} "
        "already_joined_after_confirmed_leave="
        "{already_joined_after_confirmed_leave} "
        "cross_account_operations={cross_account_operations} "
        "task_leaks={task_leaks} lock_leaks={lock_leaks} "
        "registry_leaks={registry_leaks} "
        "coordinator_desync={coordinator_desync}".format(**c))
    return len(failed_groups)


def main() -> int:
    cycles = int(sys.argv[1]) if len(sys.argv) > 1 else 2100
    return asyncio.run(run_stress(cycles))


if __name__ == "__main__":
    sys.exit(main())
