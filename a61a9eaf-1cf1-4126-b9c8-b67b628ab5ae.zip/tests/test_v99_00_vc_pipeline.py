#!/usr/bin/env python3
"""v99.00/v99.01 — VC PIPELINE regression suite (the 30 required
scenarios + the v99.01 FIX-A sync-bookkeeping regression proofs).

Covers the runtime-proven root causes from upload/bot-diagnostic (1).log
(2026-09-09 07:47–08:2x, running the v98.13 build — deployment hashes
verified against the ZIP):

  RC-A  33/33 transport-accepted joins (status=calls) had ZERO Telegram-
        side participant evidence (complete 84–100-participant scans
        proved absence) → the null-stream play(chat, None) transport
        creates a LOCAL container entry without a server-side
        participant.  The pipeline joins with a REAL silent stream and
        only Telegram evidence confirms.
  RC-B  Verification identity divergence: gate client via the router +
        my_id fallback to the global user id → verification through the
        WRONG account looking for the WRONG user id.
  RC-C  Cross-account entity poisoning → CHANNEL_INVALID ("Invalid
        channel object"); un-scoped flat-cache rewrites (the
        cache_entity_scoped mirror) erased the scope gate.
  RC-D  Phantom joins never repaired (unknown_unverified forever).
  RC-E  Manual /join unverified path destroyed the registry record.
  RC-F  Registry account owner stale after verified re-join.

Method: a full behavioural mock harness (fake voicechat/mtproto/telethon
modules + the REAL vc_pipeline.py loaded against them) so every state
transition, retry, rotation and cleanup is exercised end-to-end, plus
source-contract tests for the discovery wiring (scenarios 24–29).
"""
from __future__ import annotations

import asyncio
import os
import re
import sys
import types
import unittest
from pathlib import Path

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_MT_TEXT = (_SRC / "mtproto.py").read_text(encoding="utf-8")
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
# v99.11: the pipeline now also awaits the leave-policy chokepoint and
# the resource lifecycle (new stdlib-only package modules) — the audit's
# intent (every awaited symbol is 'async def' in a REAL source) requires
# scanning them too.
_V9911_POLICY_TEXT = (_SRC / "vc_leave_policy.py").read_text(encoding="utf-8")
_V9911_RES_TEXT = (_SRC / "vc_resources.py").read_text(encoding="utf-8")
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
_STAMP_TOOL_TEXT = (Path(__file__).resolve().parent.parent /
                    "tools" / "stamp_build.py").read_text(encoding="utf-8")
_REQ_TEXT = (Path(__file__).resolve().parent.parent / "requirements.txt").read_text(encoding="utf-8")


# ===========================================================================
# The behavioural mock harness
# ===========================================================================


class FakeMe:
    def __init__(self, uid: int):
        self.id = uid


class FakeClient:
    """A Telethon-like client for ONE account (user_id)."""

    def __init__(self, uid: int, name: str):
        self.uid = uid
        self.name = name
        self.connected = True
        self.get_entity_calls: list = []

    async def get_me(self):
        return FakeMe(self.uid)

    def is_connected(self):
        return self.connected


class FakeChannelEntity:
    def __init__(self, raw_id: int, access_hash: int):
        self.id = raw_id
        self.access_hash = access_hash


class FakeParticipationError(Exception):
    """ChannelInvalidError-like for mtproto call simulation."""


class FakeTelethonModule(types.ModuleType):
    pass


def _install_fake_telethon():
    """Provide a minimal `telethon` package: tl.types.Channel + errors."""
    if "telethon" in sys.modules and getattr(
            sys.modules["telethon"], "__mg_fake__", False):
        return sys.modules["telethon"]
    telethon = FakeTelethonModule("telethon")
    telethon.__mg_fake__ = True
    tl = types.ModuleType("telethon.tl")
    types_mod = types.ModuleType("telethon.tl.types")
    types_mod.Channel = FakeChannelEntity

    class _Err(Exception):
        pass

    errors_mod = types.ModuleType("telethon.errors")
    errors_mod.FloodWaitError = type("FloodWaitError", (Exception,), {})
    sys.modules["telethon"] = telethon
    sys.modules["telethon.tl"] = tl
    sys.modules["telethon.tl.types"] = types_mod
    sys.modules["telethon.errors"] = errors_mod
    return telethon


class FakeCluster:
    def __init__(self):
        self.accounts: dict = {}
        self.clients: dict = {}

    def add(self, aid, uid, client):
        self.accounts[aid] = {
            "account_id": aid, "user_id": uid, "status": "healthy",
        }
        self.clients[aid] = client

    def get_client(self, aid):
        return self.clients.get(aid)

    def get_account(self, aid):
        return self.accounts.get(aid)

    def get_healthy_accounts(self):
        return [dict(a) for a in self.accounts.values()
                if a.get("status") in ("healthy", "connected")]


class FakeRegistry:
    def __init__(self):
        self.records: dict = {}

    async def register(self, chat_id, *, title=None, call_id=None,
                       access_hash=None, request_accepted=False,
                       state="joining", intentional=False,
                       created_by_tour=False, account_id=None,
                       force_account=False):
        rec = self.records.setdefault(chat_id, {})
        if call_id:
            rec["call_id"] = call_id
        if access_hash:
            rec["access_hash"] = access_hash
        if state:
            rec["state"] = state
        rec["request_accepted"] = request_accepted or rec.get(
            "request_accepted", False)
        if account_id and (force_account or not rec.get("account_id")):
            rec["account_id"] = account_id
        return rec


class Harness:
    """Builds fake `mediagrab_bot.voicechat` + `mediagrab_bot.mtproto`
    modules, then imports the REAL vc_pipeline against them."""

    def __init__(self):
        _install_fake_telethon()
        # --- fake package context -------------------------------------
        self.pkg = types.ModuleType("mediagrab_bot_harness")
        # We import vc_pipeline.py under a unique name with its package
        # relatives pointing at our fakes.  vc_pipeline uses
        # `from .voicechat import ...` and `from .mtproto import ...`,
        # so we create a real package folder structure in sys.modules.
        self.fake_voicechat = types.ModuleType("mediagrab_bot_harness.voicechat")
        self.fake_mtproto = types.ModuleType("mediagrab_bot_harness.mtproto")

        # ---- voicechat symbols --------------------------------------
        class VCTransportError(Exception):
            pass

        class VCJoinUnverifiedError(VCTransportError):
            pass

        vw = self.fake_voicechat
        vw.VCTransportError = VCTransportError
        vw.VCJoinUnverifiedError = VCJoinUnverifiedError
        self.VCTransportError = VCTransportError
        self.VCJoinUnverifiedError = VCJoinUnverifiedError
        vw._vc_active_join_backends_by_chat = {}
        vw._vc_entity_negative_clear_for_chat = lambda gid: None
        vw._vc_evict_poisoned_entity_cache = (
            lambda raw_id, marked_id, consumer_scope: 0)
        vw._vc_join_account_eligible = (
            lambda aid, **kw: (True, "ok"))
        vw._vc_join_account_rank = (
            lambda aid, **kw: (0.0, 0, 0))
        vw._vc_join_account_record_join = lambda aid: None
        vw._vc_join_account_park_floodwait = (
            lambda aid, seconds, **kw: None)
        vw._vc_record_verify_evidence = self._noop_evidence
        vw._vc_classify_join_transport_error = self._classify
        self.registry = FakeRegistry()
        vw.vc_registry_register = self.registry.register
        vw.vc_get_backend = lambda account_id="": None
        vw.vc_detect_active_call = self._detect_active_call
        vw.vc_check_telegram_participation = self._check_participation
        vw._vc_call_gone_evidence_check = self._call_gone

        # ---- mtproto symbols ----------------------------------------
        mt = self.fake_mtproto
        # v99.05 RC-F4: the pipeline's _current_call_identity probe imports
        # resolve_vc_entity + _vc_entity_cache from .voicechat (the REAL
        # module re-exports both from mtproto — see voicechat.py's import
        # block).  Mirror those re-exports here so the probe works in the
        # harness; the cache is SHARED with the fake mtproto module like
        # in the real package.
        _v9905_cache: dict = {}
        vw.resolve_vc_entity = self._resolve_vc_entity
        vw._vc_entity_cache = _v9905_cache
        mt._vc_entity_cache = _v9905_cache
        self.cluster = FakeCluster()
        mt.get_userbot_cluster = lambda: self.cluster
        mt.mtproto_get_client_legacy = lambda: None
        mt.mtproto_get_client = lambda: None
        mt._vc_client_scope = self._client_scope
        mt._v9810_hash_invalid_record = lambda s, c, a: None
        mt.resolve_vc_entity = self._resolve_vc_entity

        # ---- load the REAL pipeline ---------------------------------
        sys.modules["mediagrab_bot_harness"] = self.pkg
        self.pkg.__path__ = []  # mark as package
        sys.modules["mediagrab_bot_harness.voicechat"] = self.fake_voicechat
        sys.modules["mediagrab_bot_harness.mtproto"] = self.fake_mtproto
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "mediagrab_bot_harness.vc_pipeline",
            str(_SRC / "vc_pipeline.py"))
        module = importlib.util.module_from_spec(spec)
        sys.modules["mediagrab_bot_harness.vc_pipeline"] = module
        spec.loader.exec_module(module)
        self.pipeline = module
        self.run_vc_join = module.run_vc_join
        self.vc_pipeline_mod = module

        # ---- scenario knobs -----------------------------------------
        self.verify_sequence: list = []      # verdicts per _verify call
        self.verify_calls: list = []         # (chat, call_id, account, client)
        self.verify_client: Any = None
        self.entity_results: dict = {}       # client -> {ok, entity, source}
        self.entity_calls: list = []         # (client, chat_ref, access_hash)
        self.detect_calls: list = []
        self.detect_result: dict = {}
        self.gone_result = "inconclusive"
        self.gone_calls: list = []
        self.registry_state: dict = {}

        # silence asset: point at a temp file so _make_silent_stream finds
        # something (unless pytgcalls stream types are importable, in which
        # case None) — for determinism the default is the NULL stream path.
        self._asset_bak = os.environ.pop("VC_SILENCE_ASSET", None)
        # v99.02 FIX-1 adaptation (contract-preserving): the pipeline now
        # BLOCKS null-stream dispatches by default (runtime-proven: 168
        # production dispatches → 0 Telegram-side verifications; the churn
        # also correlates with the FD exhaustion). The behavioural
        # scenarios in this suite deliberately exercise the null-stream
        # transport path (verification/backoff/rotation semantics that are
        # INDEPENDENT of the stream type), so the harness opts in via the
        # documented operator escape hatch — the SAME knob a production
        # operator would set. The gate itself is covered by the dedicated
        # TestV9902NullStreamGate suite in test_v99_02_production_stability.py
        # (blocking asserted WITHOUT the env, allowance WITH it).
        self._null_stream_bak = os.environ.pop("VC_ALLOW_NULL_STREAM_JOIN", None)
        os.environ["VC_ALLOW_NULL_STREAM_JOIN"] = "1"

    # ------------------------------------------------------------------
    @staticmethod
    def _noop_evidence(*a, **kw):
        return None

    @staticmethod
    def _classify(exc_text: str) -> str:
        t = (exc_text or "").lower()
        if ("a wait of" in t and "seconds is required" in t) or "floodwait" in t:
            return "floodwait"
        if "interdc" in t or "request was unsuccessful" in t or \
                "timeout" in t or "timed out" in t or "not connected" in t:
            return "transient_dc"
        return "deterministic"

    def _client_scope(self, client) -> str:
        # deterministic scope per client NAME ("global" for the global one)
        name = getattr(client, "name", "")
        if name.startswith("global"):
            return "global"
        if name.startswith("acc_"):
            return name
        return f"client:{id(client)}"

    async def _resolve_vc_entity(self, client, chat_ref, chat_id=0,
                                 access_hash=0):
        self.entity_calls.append((client, chat_ref, access_hash))
        res = self.entity_results.get(getattr(client, "name", ""))
        if res is None:
            # default: fresh-resolve success for any client
            raw = abs(int(chat_id)) % 10**12 if chat_id < 0 else int(chat_id or 123)
            return {"ok": True,
                    "entity": FakeChannelEntity(raw, 555),
                    "source": "fresh"}
        if callable(res):
            return res(client, chat_ref, chat_id, access_hash)
        return dict(res)

    async def _detect_active_call(self, client, entity):
        self.detect_calls.append((client, entity.id if entity else 0))
        # v99.05 RC-F4 harness semantics: detect_result === False models
        # "no active call" (GetFullChannel → full_chat.call is None);
        # a dict models an explicit current identity (stable-call and
        # call-rotation scenarios); None (default) keeps the historical
        # fixed identity for the fresh-detection path.
        if self.detect_result is False:
            return None
        return dict(self.detect_result) if self.detect_result else {
            "call_id": -4599357008817247755, "access_hash": 777, "members": 5,
        }

    async def _check_participation(self, chat_id, call_id=None,
                                   access_hash=None, *, account_id="",
                                   client=None):
        self.verify_calls.append(
            (chat_id, call_id, account_id, getattr(client, "name", None)))
        self.verify_client = client
        if self.verify_sequence:
            return self.verify_sequence.pop(0)
        return "unknown"

    async def _call_gone(self, chat_id, old_call_id, old_access_hash, *,
                         account_id="", timeout=12.0):
        self.gone_calls.append((chat_id, old_call_id, account_id))
        return self.gone_result


class FakeBackend:
    """A PyTgCallsBackend stand-in exercised by the pipeline."""

    backend_name = "pytgcalls"

    def __init__(self, account_id="", client=None):
        self._account_id = account_id
        self._mtproto = client
        self._started = True
        self._compatible = True
        self._join_strategy = "play"
        self.dispatches: list = []
        self.container: set = set()
        self.dispatch_errors: list = []
        self.leave_calls: list = []

    async def _is_target_in_calls_container(self, chat_id):
        return chat_id in self.container

    async def _transport_dispatch(self, chat_id, stream, muted=True):
        self.dispatches.append((chat_id, stream, muted))
        if self.dispatch_errors:
            err = self.dispatch_errors.pop(0)
            if err is not None:
                raise err
        self.container.add(chat_id)

    async def _leave_target(self, chat_id):
        self.leave_calls.append(chat_id)
        self.container.discard(chat_id)
        return "success"

    def start(self):
        self._started = True
        return asyncio.sleep(0)


def _mk_globals_backend(uid=8624009332, name="global"):
    client = FakeClient(uid, name)
    return FakeBackend("", client), client


class PipelineTestBase(unittest.TestCase):
    """Common setUp: fresh harness + env tuning for speed."""

    def setUp(self):
        os.environ["VC_JOIN_PIPELINE_MAX_ATTEMPTS"] = "2"
        os.environ["VC_JOIN_PIPELINE_MAX_ACCOUNTS"] = "2"
        os.environ["VC_JOIN_ENTITY_RETRIES"] = "2"
        os.environ["VC_JOIN_TG_VERIFY_ATTEMPTS"] = "1"
        os.environ["VC_JOIN_TG_VERIFY_BUDGET"] = "2"
        os.environ["VC_JOIN_DC_MAX_RETRIES"] = "1"
        os.environ["VC_JOIN_DC_BACKOFF_BASE"] = "0.01"
        os.environ["VC_JOIN_RECOVERY_BACKOFF_BASE"] = "0.01"
        os.environ["VC_MULTI_JOIN_TIMEOUT"] = "5"
        self.h = Harness()
        self.backend, self.client = _mk_globals_backend()
        # v99.03 RC-12 (contract-preserving harness maintenance): the
        # null-stream suppression windows are MODULE state in the real
        # vc_pipeline — exactly like the env knobs above, they are
        # per-SCENARIO state and must not leak between tests.  Without
        # this reset, the SECOND join for the same chat in a LATER test
        # would short-circuit at pipeline entry (v99.03 RC-12) instead of
        # exercising the code path that test was written to drive.  Every
        # pre-v99.03 test keeps its exact first-block-per-test semantics.
        try:
            self.h.vc_pipeline_mod._null_stream_suppress_reset_for_tests()
        except AttributeError:
            pass
        # v99.03 RC-8: deploy_health must be pristine per test too (the
        # fail-open default is the pre-v99.03 behavior every existing test
        # was written against; v99.03 suites set mismatch states
        # explicitly when they want the disable path).
        try:
            from importlib.util import spec_from_file_location, module_from_spec  # noqa: PLC0415
            _dh = sys.modules.get("mediagrab_bot_harness.deploy_health")
            if _dh is None:
                _spec = spec_from_file_location(
                    "mediagrab_bot_harness.deploy_health",
                    str(_SRC / "deploy_health.py"))
                _dh = module_from_spec(_spec)
                sys.modules["mediagrab_bot_harness.deploy_health"] = _dh
                _spec.loader.exec_module(_dh)
            _dh.reset_for_tests()
            # Expose it on the harness so v99.03 suites can set mismatch
            # states and the pipeline's `from . import deploy_health`
            # resolves to THIS module inside the harness package.
            self.h.deploy_health = _dh
        except Exception:
            pass

    def tearDown(self):
        for k in ("VC_JOIN_PIPELINE_MAX_ATTEMPTS",
                  "VC_JOIN_PIPELINE_MAX_ACCOUNTS", "VC_JOIN_ENTITY_RETRIES",
                  "VC_JOIN_TG_VERIFY_ATTEMPTS", "VC_JOIN_TG_VERIFY_BUDGET",
                  "VC_JOIN_DC_MAX_RETRIES", "VC_JOIN_DC_BACKOFF_BASE",
                  "VC_JOIN_RECOVERY_BACKOFF_BASE", "VC_MULTI_JOIN_TIMEOUT",
                  # v99.02: the harness's null-stream opt-in is scoped to
                  # the harness's own tests (restored here so later suites
                  # in the same process see the production default: gate
                  # ACTIVE).
                  "VC_ALLOW_NULL_STREAM_JOIN"):
            os.environ.pop(k, None)

    async def _join(self, backend=None, chat=-1001234567890, call_id=-42,
                    access_hash=999, **kw):
        backend = backend or self.backend
        return await self.h.run_vc_join(
            backend, chat, call_id=call_id, access_hash=access_hash, **kw)


# ===========================================================================
# Scenarios 1–2: per-account entity resolution
# ===========================================================================


class TestEntityResolution(PipelineTestBase):

    def test_s1_account_a_entity_resolution(self):
        async def run():
            # Account A (acc_A) resolves its own entity.
            self.h.entity_results["acc_A"] = {
                "ok": True, "entity": FakeChannelEntity(123456, 111),
                "source": "acc_A_resolver"}
            self.h.cluster.add("acc_A", 111, FakeClient(111, "acc_A"))
            backend = FakeBackend("acc_A", self.h.cluster.get_client("acc_A"))
            self.h.verify_sequence = ["present"]
            out = await self._join(backend=backend, chat=-1001234567890)
            # the entity came from acc_A's client
            cl, ref, ah = self.h.entity_calls[0]
            self.assertEqual(getattr(cl, "name", ""), "acc_A")
            return out
        out = asyncio.run(run())
        self.assertEqual(out.entity_source, "acc_A_resolver")

    def test_s2_account_b_entity_resolution(self):
        async def run():
            self.h.entity_results["acc_B"] = {
                "ok": True, "entity": FakeChannelEntity(654321, 222),
                "source": "acc_B_resolver"}
            self.h.cluster.add("acc_B", 222, FakeClient(222, "acc_B"))
            backend = FakeBackend("acc_B", self.h.cluster.get_client("acc_B"))
            self.h.verify_sequence = ["present"]
            out = await self._join(backend=backend, chat=-1006543210987)
            cl, ref, ah = self.h.entity_calls[0]
            self.assertEqual(getattr(cl, "name", ""), "acc_B")
            return out
        out = asyncio.run(run())
        self.assertEqual(out.entity_source, "acc_B_resolver")

    def test_s3_cross_account_entity_isolation(self):
        """Account B must NOT consume account A's cached entity/hash."""
        async def run():
            # A resolves and caches (hash 111 under scope acc_A).
            self.h.entity_results["acc_A"] = {
                "ok": True, "entity": FakeChannelEntity(123456, 111),
                "source": "acc_A_resolver"}
            self.h.cluster.add("acc_A", 111, FakeClient(111, "acc_A"))
            backend_a = FakeBackend(
                "acc_A", self.h.cluster.get_client("acc_A"))
            try:
                await self._join(backend=backend_a, chat=-1001234567890)
            except Exception:
                pass
            # B resolves: the pipeline MUST have called B's client, and
            # the flat cache write from A must carry scope=acc_A.
            self.h.entity_results["acc_B"] = {
                "ok": True, "entity": FakeChannelEntity(123456, 222),
                "source": "acc_B_resolver"}
            self.h.cluster.add("acc_B", 222, FakeClient(222, "acc_B"))
            backend_b = FakeBackend(
                "acc_B", self.h.cluster.get_client("acc_B"))
            self.h.verify_sequence = ["present"]
            out = await self._join(backend=backend_b, chat=-1001234567890)
            cache = self.h.fake_mtproto._vc_entity_cache
            # whatever A cached must be scope-annotated acc_A (never
            # consumable by B).
            for k, v in cache.items():
                if isinstance(v, dict) and v.get("access_hash") == 111:
                    self.assertEqual(v.get("scope"), "acc_A")
            # B's verify ran through B's client with B's account id.
            chat, call_id, account, client_name = self.h.verify_calls[-1]
            self.assertEqual(account, "acc_B")
            self.assertEqual(client_name, "acc_B")
            return out
        asyncio.run(run())


# ===========================================================================
# Scenarios 4–6: wrong hash / stale entity / CHANNEL_INVALID recovery
# ===========================================================================


class TestEntityRecovery(PipelineTestBase):

    def test_s4_wrong_access_hash_recovery(self):
        """A foreign hash → CHANNEL_INVALID → evict → fresh resolve →
        retry WITHOUT the hash (§4)."""
        async def run():
            calls = {"n": 0}

            async def resolver(client, chat_ref, chat_id=0, access_hash=0):
                calls["n"] += 1
                if access_hash:
                    # the provided (foreign) hash → ChannelInvalid
                    return {"ok": False, "error":
                            "ChannelInvalidError: Telegram RPC error: "
                            "Invalid channel object."}
                return {"ok": True, "entity": FakeChannelEntity(123456, 77),
                        "source": "fresh_no_hash"}
            self.h.fake_mtproto.resolve_vc_entity = resolver
            self.h.verify_sequence = ["present"]
            out = await self._join(chat=-100123456, access_hash=555)
            # resolver called at least twice: hash attempt then no-hash
            self.assertGreaterEqual(calls["n"], 2)
            self.assertEqual(out.entity_source, "fresh_no_hash")
            self.assertEqual(out.verdict, "joined")
            return out
        asyncio.run(run())

    def test_s5_s6_stale_entity_and_channel_invalid(self):
        """Stale entity → CHANNEL_INVALID → evict + fresh re-resolve on the
        SAME account without the poisoned hash (§4) → bounded retry.

        v99 §18 note: with the caller-provided call identity the FIRST
        attempt no longer runs the detection RPC — the production
        first-attempt CHANNEL_INVALID sources are the ENTITY RESOLVER and
        the transport dispatch; this scenario drives the resolver path
        (the detection-path variant is covered by S21's dispatch error).
        """
        async def run():
            attempts = {"resolve": 0, "detect": 0, "evict": 0}

            async def resolver(client, chat_ref, chat_id=0, access_hash=0):
                attempts["resolve"] += 1
                if attempts["resolve"] == 1:
                    # stale entity: the poisoned cache entry fails with
                    # CHANNEL_INVALID ("Invalid channel object")
                    return {"ok": False,
                            "error": "ChannelInvalidError: Invalid channel object"}
                return {"ok": True,
                        "entity": FakeChannelEntity(123456, 77),
                        "source": "fresh_ladder"}

            async def detect(client, entity):
                attempts["detect"] += 1
                return {"call_id": -42, "access_hash": 999, "members": 3}

            orig_evict = self.h.fake_voicechat._vc_evict_poisoned_entity_cache
            def evict(raw_id, marked_id, scope):
                attempts["evict"] += 1
                return orig_evict(raw_id, marked_id, scope)
            self.h.fake_mtproto.resolve_vc_entity = resolver
            self.h.fake_voicechat.vc_detect_active_call = detect
            self.h.fake_voicechat._vc_evict_poisoned_entity_cache = evict
            self.h.verify_sequence = ["present"]
            # call_id=0 → no caller-provided identity → the authoritative
            # detection runs; the ENTITY retry loop is exercised by the
            # resolver's first CHANNEL_INVALID result.
            out = await self._join(chat=-100123456, call_id=0, access_hash=0)
            self.assertGreaterEqual(attempts["resolve"], 2,
                                    "the poisoned resolve must be retried "
                                    "after eviction")
            self.assertGreaterEqual(attempts["evict"], 1,
                                    "the poisoned entity must be evicted")
            self.assertEqual(out.verdict, "joined")
            return out
        asyncio.run(run())


# ===========================================================================
# Scenario 7–8: verified join; container-only never joins
# ===========================================================================


class TestVerifiedJoin(PipelineTestBase):

    def test_s7_join_with_telegram_participant_confirmation(self):
        async def run():
            self.h.verify_sequence = ["present"]
            out = await self._join()
            self.assertEqual(out.final_state, "JOINED_CONFIRMED")
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(out.verification_result, "present")
            # registry says joined with the account + call identity —
            # v99 §18 fast path: the CALLER-PROVIDED identity (-42/999)
            # is the one verified and recorded (no detection RPC ran).
            rec = self.h.registry.records[-1001234567890]
            self.assertEqual(rec["state"], "joined")
            self.assertEqual(rec["account_id"], "global")
            self.assertEqual(rec["call_id"], -42)
            # the transport dispatched with the silent stream preference
            chat, stream, muted = self.backend.dispatches[0]
            self.assertEqual(chat, -1001234567890)
            # second sub-scenario: NO caller-provided identity (call_id=0)
            # → the authoritative detection runs and ITS identity is
            # verified + recorded (the fresh-detection path).  chat
            # -100123457 resolves through the default resolver → entity
            # 100123457 → marked -1000100123457 (the registry key).
            self.h.verify_sequence = ["present"]
            out2 = await self._join(chat=-100123457, call_id=0, access_hash=0)
            self.assertEqual(out2.verdict, "joined")
            self.assertEqual(out2.call_id, -4599357008817247755)
            rec2 = self.h.registry.records[-1000100123457]
            self.assertEqual(rec2["call_id"], -4599357008817247755)
            return out
        asyncio.run(run())

    def test_s8_container_only_never_joins(self):
        """RC-A: transport accepted + participant ABSENT → NOT joined;
        recovery + honest terminal failure (never success).
        v99.05 RC-F4: a STABLE current identity (the same pair we verified
        against) — the absent verdict stands after hygiene."""
        async def run():
            self.h.verify_sequence = ["absent", "absent"]
            self.h.detect_result = {"call_id": -42, "access_hash": 999,
                                    "members": 5}
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
            # never VC_JOIN_SUCCESS semantics: registry never says joined
            self.assertNotIn("joined",
                             str(self.h.registry.records.get(
                                 -1001234567890, {}).get("state", "")))
            # the phantom local call was CLEANED (leave called)
            self.assertIn(-1001234567890, self.backend.leave_calls)
            self.assertTrue("PROVEN absence" in str(cm.exception)
                            or "absent" in str(cm.exception))
        asyncio.run(run())


# ===========================================================================
# Scenarios 9–11: participant response shapes (identity-correct check)
# ===========================================================================


class TestParticipationShapes(PipelineTestBase):
    """These exercise the fixed vc_check_telegram_participation head —
    identity derivation (client + user_id) per account."""

    def _grab(self):
        m = re.search(
            r"^async def vc_check_telegram_participation\(.*?"
            r"(?=^async def |^def |^class |\Z)",
            _VC_TEXT, re.M | re.S)
        self.assertIsNotNone(m)
        return m.group(0)

    def _exec_check(self):
        ns = {
            "asyncio": asyncio, "logger": types.SimpleNamespace(
                info=lambda *a, **k: None, debug=lambda *a, **k: None,
                warning=lambda *a, **k: None),
            "Optional": Optional, "Any": object,
            "get_userbot_cluster": lambda: self.h.cluster,
            "mtproto_get_client": lambda: self.client,
            "vc_get_backend": lambda: self.backend,
            "vc_registry_get": self._reg_get,
            "_vc_my_user_id": 8624009332,
            "mtproto_get_client_legacy": lambda: self.client,
        }
        code = compile(self._grab(), "<vc-extract>", "exec")
        exec(code, ns)  # noqa: S102
        return ns["vc_check_telegram_participation"]

    async def _reg_get(self, chat_id):
        return None

    def test_s9_empty_participant_response_is_not_present(self):
        """Identity-correct: with the account record MISSING user_id, the
        check derives it via get_me on THE ACCOUNT's client — never the
        global fallback (RC-B)."""
        check = self._exec_check()
        # cluster account without user_id → get_me on ITS client
        self.h.cluster.add("acc_B", None, FakeClient(222, "acc_B"))

        async def run():
            # the function's RPC section is beyond the head — simulate by
            # asserting identity resolution only: call with account_id and
            # a client; expect the check to run get_me on that client
            # (identity: uid 222, not the global 8624009332).
            # We verify the IDENTITY portion by calling with an unusable
            # call id — it returns "unknown" BEFORE any RPC, AFTER the
            # client resolution. To observe the resolved client we patch
            # get_me to record.
            seen = {}

            async def get_me():
                seen["uid"] = self.h.cluster.get_client("acc_B").uid
                return FakeMe(self.h.cluster.get_client("acc_B").uid)
            self.h.cluster.get_client("acc_B").get_me = get_me
            res = await check(-100123, call_id=-42, access_hash=77,
                              account_id="acc_B")
            self.assertEqual(res, "unknown")  # fake telethon: no RPC module
            self.assertEqual(seen.get("uid"), 222)
        asyncio.run(run())

    def test_s10_s11_participation_shapes_source_contract(self):
        src = self._grab()
        # tri-state contract intact
        self.assertIn('"present"', src)
        self.assertIn('"absent"', src)
        self.assertIn('"unknown"', src)
        # pagination + targeted query + completeness guards intact
        self.assertIn("GetGroupParticipantsRequest", src)
        self.assertIn("next_offset", src)
        self.assertIn("MIN_ABSENT_PROOF_PARTICIPANTS", src)
        # RC-B fix markers: no global user-id fallback for accounts
        # (v99.02 FIX-5b evolution: the guard became
        # ``if account_id and account_id != "global":`` — the reserved
        # "global" token is NOT a cluster account, so it takes the
        # global-backend-bound client path and the global _vc_my_user_id
        # cache instead of resolving through the cluster and returning an
        # instant no-client unknown. The RC-B contract — a REAL account
        # never falls back to a foreign user id — is unchanged and
        # strictly stronger.)
        self.assertIn("if account_id and account_id != \"global\":", src)
        self.assertIn("my_id = _vc_my_user_id", src)
        # the client= override parameter exists (pipeline passes it)
        self.assertIn("client: Optional[Any] = None", src)


# ===========================================================================
# Scenario 12: call disappearance
# ===========================================================================


class TestCallDisappearance(PipelineTestBase):

    def test_s12_call_ended_during_join(self):
        async def run():
            self.h.verify_sequence = ["absent"]
            # v99.05 RC-F4: "no active call" is now modeled by the
            # identity probe (detect_result=False → GetFullChannel has no
            # call) instead of the historical gone_result evidence check.
            self.h.detect_result = False
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
            self.assertIn("ENDED", str(cm.exception))
            # local container object cleaned
            self.assertIn(-1001234567890, self.backend.leave_calls)
        asyncio.run(run())


# ===========================================================================
# Scenario 13–15: transport resilience
# ===========================================================================


class TestTransportResilience(PipelineTestBase):

    def test_s13_interdc_retry_then_success(self):
        async def run():
            self.backend.dispatch_errors = [
                RuntimeError("InterdcCallErrorError: communicating with DC 4")]
            self.h.verify_sequence = ["present"]
            out = await self._join()
            # retried after the transient error → joined
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(len(self.backend.dispatches), 2)
            return out
        asyncio.run(run())

    def test_s14_timeout_retry(self):
        async def run():
            self.backend.dispatch_errors = [asyncio.TimeoutError()]
            self.h.verify_sequence = ["present"]
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(len(self.backend.dispatches), 2)
            return out
        asyncio.run(run())

    def test_s15_floodwait_parks_and_never_retries(self):
        async def run():
            parked = {}
            self.h.fake_voicechat._vc_join_account_park_floodwait = (
                lambda aid, seconds, **kw: parked.update({aid: seconds}))
            self.backend.dispatch_errors = [
                RuntimeError("A wait of 127 seconds is required")]
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
            self.assertIn("A wait of 127 seconds", str(cm.exception))
            # the account was PARKED, and the dispatch was NEVER retried
            self.assertEqual(parked.get("global"), 127)
            self.assertEqual(len(self.backend.dispatches), 1)
        asyncio.run(run())


# ===========================================================================
# Scenarios 16–17: account rotation + backend rotation
# ===========================================================================


class TestRotation(PipelineTestBase):

    def test_s16_account_rotation_after_proven_absence(self):
        async def run():
            # global joins → absent; no more attempts; rotation to acc_B
            # whose join VERIFIES present.
            self.h.verify_sequence = ["absent", "absent", "present"]
            # v99.05 RC-F4: a STABLE current identity — the absent verdicts
            # stand after hygiene (no extra sequence consumption).
            self.h.detect_result = {"call_id": -42, "access_hash": 999,
                                    "members": 5}
            self.h.cluster.add("acc_B", 222, FakeClient(222, "acc_B"))

            def get_backend(account_id=""):
                if account_id == "acc_B":
                    if not hasattr(self, "_backend_b"):
                        self._backend_b = FakeBackend(
                            "acc_B", self.h.cluster.get_client("acc_B"))
                    return self._backend_b
                return self.backend
            self.h.fake_voicechat.vc_get_backend = get_backend

            async def resolver(client, chat_ref, chat_id=0, access_hash=0):
                name = getattr(client, "name", "")
                raw = abs(int(chat_id)) % 10**12 if chat_id < 0 else int(chat_id)
                if name == "acc_B":
                    return {"ok": True,
                            "entity": FakeChannelEntity(raw, 88),
                            "source": "fresh"}
                return {"ok": True, "entity": FakeChannelEntity(raw, 77),
                        "source": "fresh"}
            self.h.fake_mtproto.resolve_vc_entity = resolver

            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(out.account, "acc_B")
            # the ROTATED backend actually dispatched the join
            self.assertTrue(any(
                c == -1001234567890 for c, _, _ in self._backend_b.dispatches),
                f"rotated dispatches={self._backend_b.dispatches}")
            # the global backend's phantom was cleaned
            self.assertIn(-1001234567890, self.backend.leave_calls)
            # registry owner switched (force_account on verified join)
            rec = self.h.registry.records[-1001234567890]
            self.assertEqual(rec["account_id"], "acc_B")
            return out
        asyncio.run(run())

    def test_s17_backend_rotation_atomic_identity(self):
        async def run():
            # rotate-to-resolver: entity resolved by acc_B → the identity
            # object swapped BEFORE dispatch (entity/InputPeer/user_id all
            # belong to acc_B).
            self.h.cluster.add("acc_B", 222, FakeClient(222, "acc_B"))

            async def resolver(client, chat_ref, chat_id=0, access_hash=0):
                name = getattr(client, "name", "")
                if name == "global":
                    return {"ok": True,
                            "entity": FakeChannelEntity(123456, 77),
                            "source": "account_rotation:acc_B"}
                return {"ok": True, "entity": FakeChannelEntity(123456, 88),
                        "source": "fresh"}
            self.h.fake_mtproto.resolve_vc_entity = resolver

            def get_backend(account_id=""):
                if account_id == "acc_B":
                    if not hasattr(self, "_backend_b"):
                        self._backend_b = FakeBackend(
                            "acc_B", self.h.cluster.get_client("acc_B"))
                    self._backend_b._started = False  # forces .start()
                    return self._backend_b
                return self.backend
            self.h.fake_voicechat.vc_get_backend = get_backend
            self.h.verify_sequence = ["present"]

            out = await self._join()
            self.assertEqual(out.account, "acc_B")
            self.assertEqual(out.tg_user_id, 222)
            # verify ran through acc_B's client
            chat, call_id, account, client_name = self.h.verify_calls[-1]
            self.assertEqual(account, "acc_B")
            self.assertEqual(client_name, "acc_B")
            return out
        asyncio.run(run())


# ===========================================================================
# Scenario 18–19: dedup + concurrent race
# ===========================================================================


class TestDedup(PipelineTestBase):

    def test_s18_duplicate_join_coalesced(self):
        async def run():
            self.h.verify_sequence = ["present"]
            slow = {"released": False}

            orig_dispatch = self.backend._transport_dispatch

            async def slow_dispatch(chat_id, stream, muted=True):
                await asyncio.sleep(0.05)
                self.backend.container.add(chat_id)
                self.backend.dispatches.append((chat_id, stream, muted))
            self.backend._transport_dispatch = slow_dispatch

            async def one():
                return await self._join()

            a, b = await asyncio.gather(one(), one())
            self.assertEqual(a.verdict, "joined")
            self.assertEqual(b.verdict, "joined")
            # ONE dispatch for the same (account, chat) — never a
            # duplicate JoinGroupCallRequest.
            self.assertEqual(len(self.backend.dispatches), 1)
            _ = slow
        asyncio.run(run())

    def test_s19_concurrent_worker_race_same_outcome(self):
        async def run():
            self.h.verify_sequence = ["present"]

            async def slow_dispatch(chat_id, stream, muted=True):
                await asyncio.sleep(0.03)
                self.backend.container.add(chat_id)
                self.backend.dispatches.append((chat_id, stream, muted))
            self.backend._transport_dispatch = slow_dispatch
            outs = await asyncio.gather(*[self._join() for _ in range(5)])
            self.assertTrue(all(o.verdict == "joined" for o in outs))
            self.assertEqual(len(self.backend.dispatches), 1)
        asyncio.run(run())


# ===========================================================================
# Scenario 20–23: stale backend identity / retry after refresh / cleanup /
# restart recovery
# ===========================================================================


class TestRecovery(PipelineTestBase):

    def test_s20_stale_container_rejoined_not_trusted(self):
        async def run():
            # container already holds the chat (stale phantom) → quick
            # recheck says absent → cleanup → REAL rejoin → verified.
            self.backend.container.add(-1001234567890)
            self.h.verify_sequence = ["absent", "present"]
            # v99.05 RC-F4: stable identity for the quick-recheck absent.
            self.h.detect_result = {"call_id": -42, "access_hash": 999,
                                    "members": 5}
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            # the stale object was cleaned BEFORE the real dispatch
            self.assertIn(-1001234567890, self.backend.leave_calls)
            return out
        asyncio.run(run())

    def test_s21_retry_after_entity_refresh_succeeds(self):
        async def run():
            # attempt 1: dispatch raises CHANNEL_INVALID (entity-level);
            # attempt 2 (entity refreshed, hash dropped) verifies present.
            self.backend.dispatch_errors = [
                RuntimeError("ChannelInvalidError: Invalid channel object")]
            self.h.verify_sequence = ["present"]
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            # 1 failed dispatch + 1 successful dispatch
            self.assertEqual(len(self.backend.dispatches), 2)
            return out
        asyncio.run(run())

    def test_s22_failed_join_cleanup_no_orphans(self):
        async def run():
            self.h.verify_sequence = ["absent", "absent"]
            # v99.05 RC-F4: stable identity — the absent verdict stands
            # (cleanup as a genuinely FAILED join, mission §15).
            self.h.detect_result = {"call_id": -42, "access_hash": 999,
                                    "members": 5}
            with self.assertRaises(self.h.VCTransportError):
                await self._join()
            # no orphaned local call, no stale ownership mapping
            self.assertNotIn(-1001234567890, self.backend.container)
            self.assertNotIn(-1001234567890,
                             self.h.fake_voicechat._vc_active_join_backends_by_chat)
            # registry NOT marked joined
            rec = self.h.registry.records.get(-1001234567890, {})
            self.assertNotEqual(rec.get("state"), "joined")
        asyncio.run(run())

    def test_s23_restart_recovery_idempotent_recheck(self):
        """After a restart (empty in-memory world), a container entry from
        a previous process... in-process: the pipeline re-verifies the
        existing entry; present → idempotent SUCCESS with no re-dispatch."""
        async def run():
            self.backend.container.add(-1001234567890)
            self.h.verify_sequence = ["present"]
            out = await self._join()
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(out.join_result, "already_in_call_verified")
            # NO new dispatch happened
            self.assertEqual(len(self.backend.dispatches), 0)
            return out
        asyncio.run(run())


# ===========================================================================
# Scenario 30 (part): state/DB consistency + observability
# ===========================================================================


class TestStateConsistency(PipelineTestBase):

    def test_s30_registry_joined_only_on_telegram_evidence(self):
        async def run():
            # unknown verdict → registry "unknown", VCJoinUnverifiedError
            self.h.verify_sequence = ["unknown"]
            with self.assertRaises(self.h.VCJoinUnverifiedError):
                await self._join()
            rec = self.h.registry.records[-1001234567890]
            self.assertEqual(rec["state"], "unknown")
            self.assertNotEqual(rec["state"], "joined")
        asyncio.run(run())

    def test_vc_attempt_final_carries_full_fields(self):
        async def run():
            import io
            import logging
            stream = io.StringIO()
            h = logging.StreamHandler(stream)
            h.setLevel(logging.INFO)
            lg = logging.getLogger("mediagrab")
            lg.setLevel(logging.INFO)
            lg.addHandler(h)
            try:
                self.h.verify_sequence = ["present"]
                await self._join()
            finally:
                lg.removeHandler(h)
            text = stream.getvalue()
            self.assertIn("VC_ATTEMPT_FINAL", text)
            self.assertIn("tg_user_id=", text)
            self.assertIn("entity_source=", text)
            self.assertIn("access_hash=fp:", text)
            # NEVER the raw access hash in logs
            self.assertNotIn("999", text.split("access_hash=fp:")[1][:40])
            self.assertIn("final_state=JOINED_CONFIRMED", text)
        asyncio.run(run())

    def test_state_machine_rejects_invalid_transitions(self):
        sm = self.h.vc_pipeline_mod.VCJoinStateMachine(1)
        sm.transition(self.h.vc_pipeline_mod.VCJoinState.RESOLVING)
        with self.assertRaises(RuntimeError):
            sm.transition(self.h.vc_pipeline_mod.VCJoinState.JOINED_CONFIRMED)

    def test_silent_stream_fallback_is_null_stream(self):
        # in the test env pytgcalls stream types don't exist → None
        stream = self.h.vc_pipeline_mod._make_silent_stream()
        self.assertIsNone(stream)


# ===========================================================================
# v99.01 FIX-A — sync bookkeeping contract (the runtime TypeError fix)
# ===========================================================================


class TestV9901SyncBookkeepingFix(PipelineTestBase):
    """v99.01 FIX-A regression proof (runtime-proven defect).

    The v99.00 deployment log (upload/bot-diagnostic.log, 2026-09-09
    15:4x–15:5x, build identity verified via build_stamp) showed 29×
    ``VC_JOIN_UNVERIFIED`` each immediately followed by 29×
    ``VC_PIPELINE_RECORD_UNVERIFIED exc=TypeError: object NoneType
    can't be used in 'await' expression``: ``_record_unverified`` (and
    latently ``_on_verified``) AWAITED the SYNCHRONOUS
    ``_vc_record_verify_evidence`` (voicechat.py v98.12 §35 evidence
    registry — plain ``def``, returns None, called synchronously at all
    six voicechat.py sites).  The old ``except TypeError`` "older
    signature" fallback AWAITED AGAIN and re-raised the same error; the
    outer except-Exception guard then swallowed it — which is exactly
    why the v99.00 suite stayed green (the mock harness's evidence
    function is sync too, so the suite reproduced the production bug
    but never asserted on the swallowed DEBUG log).

    These tests pin the fixed contract:
      * the sync evidence recorder is called synchronously — the
        await-TypeError cannot occur (log-captured at DEBUG level);
      * the UNKNOWN/unverified state is still recorded correctly
        (registry state=unknown + weak/unknown evidence) and the
        failure path NEVER becomes a success path;
      * the verified path records strong evidence AND completes the
        entity-negative hygiene that the old TypeError abort skipped;
      * a durable await-audit: every symbol awaited anywhere in
        vc_pipeline.py must be ``async def`` in the pipeline/voicechat/
        mtproto sources (the generalized "no other sync function is
        awaited" guard).
    """

    def _capture(self):
        import io
        import logging
        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        handler.setLevel(logging.DEBUG)
        lg = logging.getLogger("mediagrab")
        self._lg_level_bak = lg.level
        lg.setLevel(logging.DEBUG)
        lg.addHandler(handler)
        return lg, handler, stream

    def _release(self, lg, handler):
        import logging
        lg.removeHandler(handler)
        lg.setLevel(self._lg_level_bak
                    if self._lg_level_bak != logging.NOTSET
                    else logging.INFO)

    def _install_sync_evidence(self, into):
        """Install a recorder with EXACTLY the production shape: a
        plain ``def`` returning None (synchronous bookkeeping)."""
        calls = []

        def sync_evidence(chat_id, *, outcome, strength, reason,
                          account_id="", call_id=None):
            calls.append({"chat_id": chat_id, "outcome": outcome,
                          "strength": strength, "reason": reason,
                          "account_id": account_id, "call_id": call_id})
            return None
        into._vc_record_verify_evidence = sync_evidence
        return calls

    def test_v9901_record_unverified_sync_evidence_no_typeerror(self):
        """_record_unverified works with the SYNC evidence function:
        no TypeError, UNKNOWN recorded honestly, failure stays
        failure."""
        async def run():
            lg, handler, stream = self._capture()
            evidence = self._install_sync_evidence(self.h.fake_voicechat)
            self.h.verify_sequence = ["unknown"]
            try:
                # the failure path still raises the honest unverified
                # error (NOT swallowed into success)
                with self.assertRaises(self.h.VCJoinUnverifiedError):
                    await self._join()
            finally:
                self._release(lg, handler)
            text = stream.getvalue()
            # (1) the exact production symptom is GONE (29× in the
            # v99.00 deployment log)
            self.assertNotIn("VC_PIPELINE_RECORD_UNVERIFIED", text)
            self.assertNotIn("NoneType can't be used in 'await'", text)
            self.assertNotIn("TypeError", text)
            # (2) the sync recorder ran EXACTLY once with the honest
            # UNKNOWN bookkeeping — the old code recorded it TWICE
            # (try + except-TypeError fallback) and the second await
            # aborted the whole block
            self.assertEqual(len(evidence), 1)
            ev = evidence[0]
            self.assertEqual(ev["chat_id"], -1001234567890)
            self.assertEqual(ev["outcome"], "unknown")
            self.assertEqual(ev["strength"], "weak")
            self.assertEqual(ev["call_id"], -42)
            self.assertTrue(
                ev["reason"].startswith("pipeline:inconclusive:"),
                f"reason={ev['reason']!r}")
            self.assertTrue(ev["account_id"],
                            "evidence must carry the join account id")
            # (3) UNKNOWN stays UNKNOWN — the failure path did NOT
            # accidentally become a success path
            rec = self.h.registry.records[-1001234567890]
            self.assertEqual(rec["state"], "unknown")
            self.assertNotEqual(rec["state"], "joined")
        asyncio.run(run())

    def test_v9901_on_verified_sync_evidence_and_negative_clear(self):
        """The SUCCESS path bookkeeping completes: strong evidence
        recorded once + the entity-negative hygiene the old TypeError
        abort skipped (RC-C)."""
        async def run():
            lg, handler, stream = self._capture()
            evidence = self._install_sync_evidence(self.h.fake_voicechat)
            cleared = []
            self.h.fake_voicechat._vc_entity_negative_clear_for_chat = (
                cleared.append)
            self.h.verify_sequence = ["present"]
            try:
                out = await self._join()
            finally:
                self._release(lg, handler)
            # success semantics preserved: joined ONLY on positive
            # Telegram-side verification (verify_result=present)
            self.assertEqual(out.final_state, "JOINED_CONFIRMED")
            self.assertEqual(out.verdict, "joined")
            self.assertEqual(out.verification_result, "present")
            # strong evidence recorded exactly once, synchronously
            self.assertEqual(len(evidence), 1)
            ev = evidence[0]
            self.assertEqual(ev["outcome"], "joined")
            self.assertEqual(ev["strength"], "strong")
            self.assertEqual(ev["call_id"], -42)
            self.assertTrue(
                ev["reason"].startswith("pipeline:participant_confirmed:"),
                f"reason={ev['reason']!r}")
            # the entity-negative hygiene the old abort skipped: BOTH
            # the raw and the marked id are cleared
            self.assertEqual(
                set(cleared), {1234567890, -1001234567890},
                f"cleared={cleared!r}")
            # no bookkeeping abort logged
            text = stream.getvalue()
            self.assertNotIn(
                "VC_PIPELINE_ON_VERIFIED_BOOKKEEPING exc=TypeError", text)
            self.assertNotIn("NoneType can't be used in 'await'", text)
        asyncio.run(run())

    def test_v9901_source_guard_no_await_on_sync_evidence(self):
        # the regression signature must never come back
        self.assertNotIn("await _vc_record_verify_evidence(", _PIPE_TEXT)
        # the evidence recorder is a plain sync def in voicechat
        self.assertIn("def _vc_record_verify_evidence(", _VC_TEXT)
        self.assertNotIn("async def _vc_record_verify_evidence(", _VC_TEXT)
        # voicechat's own six call sites stay synchronous too
        self.assertNotIn("await _vc_record_verify_evidence(", _VC_TEXT)

    def test_v9901_await_audit_every_awaited_symbol_is_async(self):
        """Durable generalization of the v99.01 await audit: every
        symbol awaited anywhere in vc_pipeline.py must be `async def`
        in the pipeline/voicechat/mtproto sources."""
        awaited = sorted(set(re.findall(
            r"await\s+([A-Za-z_][A-Za-z0-9_.]*)\s*\(", _PIPE_TEXT)))
        self.assertTrue(awaited, "audit found no awaits — regex broken?")
        offenders = []
        for name in awaited:
            if name.startswith("asyncio."):
                continue  # stdlib async primitives (sleep/wait_for/shield)
            attr = name.split(".")[-1]
            needle = f"async def {attr}("
            if needle in _PIPE_TEXT or needle in _VC_TEXT \
                    or needle in _MT_TEXT or needle in _V9911_POLICY_TEXT \
                    or needle in _V9911_RES_TEXT:
                continue
            offenders.append(name)
        self.assertEqual(
            offenders, [],
            "v99.01 FIX-A await audit — awaited symbols that are NOT "
            "'async def' anywhere in vc_pipeline/voicechat/mtproto "
            "(awaiting a sync function raises the runtime TypeError "
            "\"object NoneType can't be used in 'await' expression\"")


# ===========================================================================
# v99.01 FIX-B — build-identity false mismatch (bootstrap runtime hash)
# ===========================================================================


class TestV9901BuildIdentityFix(unittest.TestCase):
    """v99.01 FIX-B regression proof (runtime-proven defect).

    The v99.00 deployment log (upload/bot-diagnostic.log 2026-09-09
    15:39:26) opened with:
        BUILD_IDENTITY_MISMATCH stamp_version=v99.00
        runtime_version=v99.00 detail=[vc_pipeline.py:
        stamp=23104d682dc734f8 actual=?]
    on a CLEAN deployment — v99.00 added vc_pipeline.py to the STAMP
    (tools/stamp_build.py §17) but NOT to bootstrap's
    ``_v9812_runtime_hashes`` map, so the stamp loop read ``actual=?``
    → a FALSE mismatch on every clean v99.00 deployment (the same
    class as the v98.12-FINAL2 FIX-ID ``__init__.py`` incident, whose
    own comment warns it "destroys operator trust in the §21 identity
    system").  The runtime DID load the correct pipeline (the log's
    pipeline line numbers match the v99.00 source byte-exactly) — the
    alarm was false.
    """

    def test_v9901_fix_b_pipeline_hashed_at_startup(self):
        # the canonical pipeline is in the runtime-hash map ...
        self.assertIn('"vc_pipeline.py": "?",', _BOOT_TEXT)
        # ... and actually hashed like every other stamped module
        self.assertIn(
            'with open(os.path.join(_module_dir, "vc_pipeline.py"), "rb")',
            _BOOT_TEXT)
        self.assertIn(
            '_v9812_runtime_hashes["vc_pipeline.py"] = _hashlib.sha256(',
            _BOOT_TEXT)

    def test_v9901_fix_b_identity_line_carries_pipeline_hash(self):
        # the startup identity line now includes the pipeline hash —
        # this deployment's forensics had to INFER it from line numbers
        self.assertIn(
            "vc_pipeline_sha256={_v9812_runtime_hashes.get"
            "('vc_pipeline.py', '?')}",
            _BOOT_TEXT)

    def test_v9901_fix_b_every_stamped_module_has_runtime_hash(self):
        """The generalized guard (no more actual=? false mismatches):
        every module listed in tools/stamp_build.py's _MODULES must be
        hashed by bootstrap's runtime-map block."""
        m = re.search(r"_MODULES = \[(.*?)\]", _STAMP_TOOL_TEXT, re.S)
        self.assertIsNotNone(m, "stamp_build _MODULES list not found")
        stamped = re.findall(r'"([A-Za-z0-9_./]+\.py)"', m.group(1))
        self.assertIn("vc_pipeline.py", stamped)
        self.assertGreaterEqual(len(stamped), 10)
        # the region that populates the runtime hash map: the dict
        # literal + every follow-up file-hash assignment block
        region = re.search(
            r"_v9812_runtime_hashes = \{.*?_v9812_stamp_state",
            _BOOT_TEXT, re.S)
        self.assertIsNotNone(region, "runtime-hash region not found")
        missing = [mod for mod in stamped
                   if f'"{mod}"' not in region.group(0)]
        self.assertEqual(
            missing, [],
            "v99.01 FIX-B — stamped modules with NO bootstrap runtime "
            "hash (stamp loop would read actual=? → false "
            "BUILD_IDENTITY_MISMATCH on every clean deployment)")


# ===========================================================================
# Scenarios 24–29: DISCOVERY wiring (source-contract tests — the
# discovery orchestrations must feed the SAME canonical pipeline)
# ===========================================================================


class TestDiscoveryWiring(unittest.TestCase):

    def setUp(self):
        self.db = (Path(__file__).resolve().parent.parent /
                   "mediagrab_bot" / "db_layer.py").read_text(encoding="utf-8")

    def test_s24_duplicate_filtering_present(self):
        # canonical id + claim registry + DB unique constraints
        self.assertIn("def _vc_canonical_group_id(", _VC_TEXT)
        self.assertIn("_vc_discovery_claim_id", _VC_TEXT)
        self.assertRegex(self.db, r"group_id\s+INTEGER NOT NULL UNIQUE")
        self.assertIn("idx_vc_discovery_provenance_unique", self.db)

    def test_s25_s26_invalid_and_inaccessible_targets(self):
        # classification maps errors to access_status + cooldowns, never
        # permanent exclusion
        self.assertIn("def _vc_discovery_classify(", _VC_TEXT)
        self.assertIn("access_status", _VC_TEXT)
        self.assertIn("_vc_discovery_mark_dead(", _VC_TEXT)

    def test_s27_discovery_feeds_canonical_pipeline(self):
        # every discovery join orchestration calls backend.join() — the
        # method that delegates to run_vc_join.  There must be NO
        # discovery-side direct dispatch (no play()/join_group_call()
        # outside PyTgCallsBackend._transport_dispatch).
        ptc_idx = _VC_TEXT.find("class PyTgCallsBackend")
        self.assertGreater(ptc_idx, 0)
        join_def = re.search(
            r"async def join\(self, chat_ref.*?(?=\n    async def )",
            _VC_TEXT[ptc_idx:], re.S)
        self.assertIsNotNone(join_def)
        self.assertIn("run_vc_join", join_def.group(0),
                      "PyTgCallsBackend.join must delegate to the pipeline")
        # the ONLY strategy dispatch lives in _transport_dispatch —
        # v99.11 documented correction: the strategy block moved verbatim
        # into _v9911_transport_dispatch_inner (extracted so the v99.11
        # admission gate + bounded semaphore + lifecycle can wrap it);
        # the inner method is called ONLY from _transport_dispatch, so
        # the invariant (ONE strategy dispatch path, no discovery-side
        # direct dispatch) is unchanged.
        dispatch_src = _grab_fn(_VC_TEXT, "_transport_dispatch") + \
            _grab_fn(_VC_TEXT, "_v9911_transport_dispatch_inner")
        self.assertIn("_v9911_transport_dispatch_inner(", _grab_fn(
            _VC_TEXT, "_transport_dispatch"))
        for pattern in ("self._pytgcalls.play(",
                        "self._pytgcalls.join_group_call(",
                        "self._pytgcalls.call(",
                        "self._pytgcalls.join_call("):
            self.assertIn(pattern, dispatch_src)
        # discovery orchestrations call backend.join (not raw dispatch)
        cap_src = _grab_fn(_VC_TEXT, "_vc_capacity_aware_join")
        self.assertIn("backend.join(", cap_src)
        # the pipeline module is imported inside join (lazy, no cycle)
        self.assertIn("from .vc_pipeline import run_vc_join", _VC_TEXT)

    def test_s28_discovery_retry_backoff(self):
        self.assertIn("def _retry_backoff", _VC_TEXT)
        self.assertIn("vc_retry_queue_add", _VC_TEXT)
        self.assertIn("_VC_TARGET_COOLDOWN_SECONDS", _VC_TEXT)

    def test_s29_discovery_account_compatibility(self):
        # scope-safe classify + rotation-aware detect client
        self.assertIn("def _vc_detect_active_call_scoped(", _VC_TEXT)
        self.assertIn("account_rotation:", _VC_TEXT)
        # the resolver's foreign-scope hash skip (v99 RC-C)
        self.assertIn("_v99_hash_foreign", _MT_TEXT)
        self.assertIn("ENTITY_RESOLVE_PROVIDED_HASH_FOREIGN_SCOPE", _MT_TEXT)

    def test_requirements_documented(self):
        # pytgcalls pinned + the non-PyPI provenance documented
        self.assertIn("pytgcalls", _REQ_TEXT)


def _grab_fn(src: str, name: str) -> str:
    m = re.search(rf"^[ \t]*(?:async )?def {name}\(.*?(?=^[ \t]*(?:async )?def |^class |\Z)",
                  src, re.M | re.S)
    if m is None:
        raise AssertionError(f"function {name} not found")
    return m.group(0)


from typing import Any, Optional  # noqa: E402  (used by extracts)


if __name__ == "__main__":
    unittest.main()
