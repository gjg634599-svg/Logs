"""
v97.71 regression tests — reconnect drain timeout + reconcile gate before capability evidence.

Root causes fixed:
  1. _telethon_drain_and_reconnect_raw used 30s timeouts for both disconnect() and
     drain (await disconnected). These 30s timeouts blocked the event loop during
     reconnect — the v97.70 runtime log showed 10.55s + 11.67s EVENT_LOOP_LAG_CRITICAL
     with only 28 total tasks. The watchdog at _mtproto_safe_reconnect() held the
     event loop for ~30s waiting for drain.
  2. vc_reconcile_participations called vc_collect_capability_evidence() BEFORE
     checking connectivity. The v97.69 gate was AFTER the capability evidence
     collection, so capability evidence still ran against a disconnected client.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestReconnectDrainTimeoutReduction(unittest.TestCase):
    """P0: reconnect drain timeouts must be bounded to prevent event-loop starvation."""

    def test_disconnect_timeout_reduced(self):
        """client.disconnect() timeout must be 10s (was 30s) in the drain path."""
        with open(_MTPROTO) as f:
            src = f.read()
        # Find the _telethon_drain_and_reconnect_raw function.
        import re
        m = re.search(r'async def _telethon_drain_and_reconnect_raw.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m, "function not found")
        func_body = m.group(0)
        self.assertIn("timeout=10)", func_body,
                      "disconnect + drain timeouts must be 10s in the drain path")
        self.assertNotIn("timeout=30)", func_body,
                         "no 30s timeouts should remain in drain path")

    def test_drain_timeout_reduced(self):
        """await disconnected future timeout must be 10s (was 30s)."""
        with open(_MTPROTO) as f:
            src = f.read()
        # Find the drain timeout — it should be 10s now.
        self.assertIn("timeout=10)", src,
                      "drain timeout must be 10s (v97.71 reduced from 30s)")


class TestReconcileGateBeforeCapabilityEvidence(unittest.TestCase):
    """P0: reconcile must check connectivity BEFORE vc_collect_capability_evidence()."""

    def test_gate_before_capability_evidence(self):
        """The disconnect gate must be BEFORE vc_collect_capability_evidence() call (not in docstring)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the function body (skip the docstring).
        import re
        m = re.search(r'async def vc_reconcile_participations\(.*?"""', src, re.DOTALL)
        self.assertIsNotNone(m, "vc_reconcile_participations not found")
        # Everything AFTER the docstring closing """.
        after_doc = src[m.end():]
        # Find next function to bound the search.
        next_func = re.search(r'\nasync def |\ndef ', after_doc)
        if next_func:
            after_doc = after_doc[:next_func.start()]
        gate_pos = after_doc.find("VC_RECONCILE_DEFERRED_NETWORK")
        # Find the ACTUAL call (not the comment mentioning it).
        evidence_pos = after_doc.find("await vc_collect_capability_evidence()")
        self.assertGreater(gate_pos, 0, "must have disconnect gate")
        self.assertGreater(evidence_pos, 0, "must call vc_collect_capability_evidence")
        self.assertLess(gate_pos, evidence_pos,
                        "disconnect gate must be BEFORE vc_collect_capability_evidence() call")

    def test_no_capability_evidence_when_disconnected(self):
        """When disconnected, vc_collect_capability_evidence must NOT be called."""
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_reconcile_participations\(.*?"""', src, re.DOTALL)
        self.assertIsNotNone(m)
        after_doc = src[m.end():]
        next_func = re.search(r'\nasync def |\ndef ', after_doc)
        if next_func:
            after_doc = after_doc[:next_func.start()]
        return_pos = after_doc.find('return {')
        evidence_pos = after_doc.find("await vc_collect_capability_evidence()")
        self.assertGreater(return_pos, 0)
        self.assertGreater(evidence_pos, 0)
        self.assertLess(return_pos, evidence_pos,
                        "deferred return must be before capability evidence call")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_dispatch_filter_preserved(self):
        """v97.70 func filter must hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_self_destruct_filter", src)
        self.assertIn("func=_self_destruct_filter", src)

    def test_vc_command_filter_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_vc_command_filter", src)
        self.assertIn("func=_vc_command_filter", src)

    def test_disconnect_classification_preserved(self):
        """v97.68 authoritative disconnect classification must hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_is_disconnect_exc", src)
        self.assertIn("classified as disconnect", src)

    def test_reconcile_disconnect_gate_preserved(self):
        """v97.69 reconcile disconnect gate must hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_RECONCILE_DEFERRED_NETWORK", src)

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_no_asyncio_shield_in_stop(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        code_only = re.sub(r'#.*', '', m.group(0))
        self.assertNotIn("asyncio.shield", code_only)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f:
            src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
