"""v98.06 runtime fixes — regression tests for the false-PeerUser blacklist
massacre + reconcile starvation + coverage-manager sync + clock-domain mixup.

CRITICAL USER-REPORTED BUG (bot-diagnostic (18+).log, 2026-08-30
17:32:23→17:55:40, pid=20099, deployed zip SHA256
d86a1c03dba9614cd0f3d208509910f29d0494c1616c7d29c8079f79d56f7eb9):
  Run 1 (17:34:56-17:47:58): 183 known → 47 eligible → 43 joined; 40 of them
    rotated to account=acc_919006065076 (VC_ACTIVE_JOIN_BACKEND_SET 40/40).
  Run 2 (17:50:16-17:54:03): classification loop resolved DB gids via
    BARE-positive-id get_entity → Telethon PeerUser cache-miss errors →
    v98.04 FIX-BB misread as "proven user ID" → vc_mark_peeruser +
    DB delete → 169 VC_PEERUSER_DETECTED, 40 of them REAL JOINED VC
    channels. Run-2 eligible collapsed 47→2 (excluded=173).
  Decisive per-chat proof: 1393246704 — VC_ENTITY_DISCOVERED type=Channel
  17:35:10 → VC_JOIN_SUCCESS 17:37:08 → "proven user ID" 17:50:54 →
  VC_LEAVE_CONFIRMED 17:55:26.

v98.06 FIXES:
  FIX-LL: kill the false-PeerUser blacklist massacre — (1) classification
          resolution NEVER uses the bare id (marked form + resolve_vc_entity
          cache/InputPeer/9-step/multi-account-rotation, the SAME machinery
          the join path used to resolve these exact chats); (2) sound
          user-type probe (PeerUser(gid) explicit construction; a User-TYPE
          resolution is positive type evidence; a cache-miss ERROR proves
          nothing); (3) sound PeerUser verdict requires id match + ZERO
          positive evidence (registry ANY state / container raw|marked /
          session join success) — else log VC_BLACKLIST_DECISION
          peeruser_rejected_evidence + skip gracefully; (4) vc_mark_peeruser
          internal evidence guard (single choke point, defense in depth) +
          reversible tombstone; (5) blacklist sanity sweep at Join-All start.
  FIX-MM: (1) reconcile anti-starvation — after N=2 consecutive
          join_all_running skips, force ONE bounded reconcile slice
          (floodwait/disconnected/backpressure gates still apply);
          (2) VCCoverageManager._reconcile_cycle syncs _active_vcs/
          _joined_vcs from the participation registry + calls container
          (the (18+).log 22 all-zero cycles were decorative).
  FIX-NN: VC_CLASSIFY_FAILURE chat_id err_type err=<full text, 200 chars>
          evidence_guard=<state> on every classification exception outcome
          (the v98.04 PeerUser decision was invisible in the log).
  FIX-OO: BOT_HEARTBEAT uptime clock-domain unification (was
          monotonic()-epoch → uptime=-1787480363s).
  FIX-PP: MTPROTO_GENERATION_STATE total_sessions (a generation count that
          read 0 while connections worked) renamed generation_sessions +
          real live_clients count emitted.

TEST LEVELS (honest):
  * SOURCE-PROVEN: source string/AST assertions on the exact fix shapes.
  * TEST-PROVEN: behavioral tests that AST-extract the ACTUAL shipped
    functions (ast.get_source_segment) and exec them with only I/O
    boundaries mocked (registry dicts, container resolver, logger). These
    test the REAL code, not a re-implementation.
"""

import ast
import asyncio
import os
import sys
import time
import types
import unittest

_PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_PKG_ROOT, "mediagrab_bot", "voicechat.py")
_HANDLERS = os.path.join(_PKG_ROOT, "mediagrab_bot", "handlers.py")
_MTPROTO = os.path.join(_PKG_ROOT, "mediagrab_bot", "mtproto.py")
_INIT = os.path.join(_PKG_ROOT, "mediagrab_bot", "__init__.py")
_BOOTSTRAP = os.path.join(_PKG_ROOT, "mediagrab_bot", "bootstrap.py")

# --- fake mediagrab_bot.db_layer (prevents the REAL aiosqlite import) -----
# The exec'd vc_mark_peeruser does ``from .db_layer import vc_delete_group``.
# Without this stub the relative import machinery falls back to importing
# the REAL db_layer → real aiosqlite connection → a non-daemon worker
# thread → the test process HANGS AT EXIT (the exact "pytest hangs" class
# of failure the v98.06 mandate warns about). The stub RECORDS deletions
# so tests can assert the delete is correctly gated.
_DB_DELETES: list[int] = []


async def _fake_vc_delete_group(group_id: int) -> bool:
    _DB_DELETES.append(group_id)
    return True


def _install_fake_db_layer() -> None:
    if "mediagrab_bot" in sys.modules and getattr(
        sys.modules["mediagrab_bot"], "__is_test_fake__", False
    ):
        return  # already installed
    fake_pkg = types.ModuleType("mediagrab_bot")
    fake_pkg.__path__ = [os.path.join(_PKG_ROOT, "mediagrab_bot")]
    fake_pkg.__is_test_fake__ = True  # type: ignore[attr-defined]
    fake_db = types.ModuleType("mediagrab_bot.db_layer")
    fake_db.vc_delete_group = _fake_vc_delete_group
    sys.modules["mediagrab_bot"] = fake_pkg
    sys.modules["mediagrab_bot.db_layer"] = fake_db


def _remove_fake_db_layer() -> None:
    for key in ("mediagrab_bot", "mediagrab_bot.db_layer"):
        mod = sys.modules.get(key)
        if mod is not None and getattr(mod, "__is_test_fake__", False):
            del sys.modules[key]


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


class _FakeLogger:
    """Captures formatted log records for assertions."""

    def __init__(self) -> None:
        self.records: list[tuple[str, str]] = []

    def _log(self, level: str, msg: str, *args) -> None:
        try:
            self.records.append((level, msg % args if args else msg))
        except Exception:  # noqa: BLE001
            self.records.append((level, msg))

    def info(self, msg, *args):  # noqa: ANN001
        self._log("INFO", msg, *args)

    def warning(self, msg, *args):  # noqa: ANN001
        self._log("WARNING", msg, *args)

    def debug(self, msg, *args):  # noqa: ANN001
        self._log("DEBUG", msg, *args)

    def error(self, msg, *args):  # noqa: ANN001
        self._log("ERROR", msg, *args)

    def text(self) -> str:
        return "\n".join(m for _, m in self.records)


def _extract_toplevel(src: str, name: str) -> str | None:
    """AST-extract the verbatim source of a top-level (async) function."""
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == name:
                return ast.get_source_segment(src, node)
    return None


def _extract_method(src: str, class_name: str, method: str) -> str | None:
    """AST-extract the verbatim source of a class method."""
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for sub in node.body:
                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if sub.name == method:
                        return ast.get_source_segment(src, sub)
    return None


class _Rec:
    """Minimal participation-registry record stand-in."""

    def __init__(self, chat_id: int, state: str):
        self.chat_id = chat_id
        self.state = state
        self.title = ""
        self.call_id = 0
        self.access_hash = 0


def _exec_namespace(logger: _FakeLogger) -> dict:
    """Build an exec namespace with only I/O boundaries mocked.

    The registry dicts / sets are REAL data structures the shipped code
    manipulates; the container resolver + id extractor are the only mocked
    callables (they hit PyTgCalls in production).
    """
    ns: dict = {
        "asyncio": asyncio,
        "time": time,
        "logger": logger,
        "_vc_participations": {},
        "_vc_session_join_success_ids": set(),
        "_vc_known_peeruser_ids": set(),
        "_vc_peeruser_tombstones": {},
    }
    return ns


def _exec_functions(logger: _FakeLogger, container_ids: set[int] | None = None):
    """AST-extract + exec the REAL v98.06 FIX-LL helper functions.

    Returns the namespace containing: _vc_both_id_forms,
    _vc_positive_evidence_sync, _vc_positive_evidence_for_chat,
    _vc_peeruser_blacklist_sweep, vc_mark_peeruser.
    """
    src = _read(_VOICECHAT)
    _install_fake_db_layer()
    ns = _exec_namespace(logger)
    # Relative-import resolution for the exec'd code (``from .db_layer
    # import ...``) → resolves to the TEST FAKE (records deletes, no real
    # aiosqlite → no process-exit hang).
    ns["__name__"] = "mediagrab_bot.voicechat"
    ns["__package__"] = "mediagrab_bot"
    # Mocked I/O boundary: the PyTgCalls container resolver.
    async def _fake_resolve_container(account_id: str = ""):
        return ("__fake_container__",)

    def _fake_extract_ids(raw) -> set[int]:
        return set(container_ids or ())

    ns["vc_resolve_calls_container"] = _fake_resolve_container
    ns["_extract_chat_ids_from_container"] = _fake_extract_ids
    for fname in (
        "_vc_both_id_forms",
        "_vc_positive_evidence_sync",
        "_vc_positive_evidence_for_chat",
        "_vc_evidence_for_chat_safe",
        "_vc_classify_failure_log",
        "_vc_peeruser_blacklist_sweep",
        "vc_mark_peeruser",
        "vc_is_known_peeruser",
    ):
        seg = _extract_toplevel(src, fname)
        assert seg is not None, f"function {fname} not found in voicechat.py"
        exec(compile(seg, f"<voicechat.py::{fname}>", "exec"), ns)  # noqa: S102
    return ns


# =============================================================================
# §1 — FIX-LL behavioral: the evidence guard (T-A, T-B, T-C, T-I)
# =============================================================================

class TestFixLLEvidenceGuardBehavioral(unittest.TestCase):
    """Behavioral tests of the ACTUAL shipped evidence-guard code."""

    def setUp(self):
        self.logger = _FakeLogger()
        _DB_DELETES.clear()
        _install_fake_db_layer()

    def tearDown(self):
        _remove_fake_db_layer()
        _DB_DELETES.clear()

    def test_t_a_registry_joined_chat_is_protected_from_blacklist(self):
        """T-A: registry-joined chat + PeerUser error → NOT blacklisted.

        The (18+).log massacre: 40 chats had VC_PARTICIPATION_REGISTER
        state=joined (raw key form) when the bare-id resolution failed.
        """
        ns = _exec_functions(self.logger)
        massacre_chat = 1393246704
        ns["_vc_participations"][massacre_chat] = _Rec(massacre_chat, "joined")
        # The sound user-type probe SUCCEEDED (id collision) but evidence
        # exists → the decision path must refuse:
        ev_ok, ev_desc = asyncio.run(
            ns["_vc_positive_evidence_for_chat"](massacre_chat)
        )
        self.assertTrue(ev_ok)
        self.assertIn("state=joined", ev_desc)
        # vc_mark_peeruser itself refuses (defense in depth):
        ns["vc_mark_peeruser"](massacre_chat)
        self.assertNotIn(massacre_chat, ns["_vc_known_peeruser_ids"])
        self.assertNotIn(massacre_chat, ns["_vc_peeruser_tombstones"])
        self.assertIn(
            "verdict=peeruser_rejected_evidence", self.logger.text()
        )

    def test_t_a_marked_key_form_is_also_protected(self):
        """T-A variant: registry keyed by the MARKED form is protected too."""
        ns = _exec_functions(self.logger)
        chat_raw = 2054748259
        chat_marked = -1002054748259
        ns["_vc_participations"][chat_marked] = _Rec(chat_marked, "joined")
        ev_ok, _ = asyncio.run(ns["_vc_positive_evidence_for_chat"](chat_raw))
        self.assertTrue(ev_ok)
        ns["vc_mark_peeruser"](chat_raw)
        self.assertNotIn(chat_raw, ns["_vc_known_peeruser_ids"])

    def test_t_a_container_present_is_protected(self):
        """T-A variant: PyTgCalls container presence (raw|marked) protects.

        The container evidence is ASYNC-only, so the protection at the
        choke point runs as the post-mark verification task — the
        production shape (call sites run inside the event loop) is
        simulated: mark INSIDE a loop, then await the verification.
        """
        ns = _exec_functions(self.logger, container_ids={1922822605, -1001922822605})
        # Zero registry + zero session-join evidence; container ONLY:
        ev_ok, ev_desc = asyncio.run(
            ns["_vc_positive_evidence_for_chat"](1922822605)
        )
        self.assertTrue(ev_ok)
        self.assertIn("backend_container", ev_desc)

        async def _scenario():
            # A future code path calls vc_mark_peeruser WITHOUT the async
            # pre-check (inside the loop): the post-mark verification
            # must revert the mark + NOT delete the DB row.
            ns["vc_mark_peeruser"](1922822605)
            self.assertIn(1922822605, ns["_vc_known_peeruser_ids"])
            # Let the bounded verification task run (2.5s bound).
            await asyncio.sleep(0.1)

        asyncio.run(_scenario())
        self.assertNotIn(1922822605, ns["_vc_known_peeruser_ids"])
        self.assertNotIn(1922822605, ns["_vc_peeruser_tombstones"])
        self.assertIn("source=post_mark_verify", self.logger.text())
        # NO DB delete was performed for the evidence-protected chat:
        self.assertNotIn(1922822605, _DB_DELETES)

    def test_t_a_session_join_success_is_protected(self):
        """T-A variant: a successful join() this session protects the chat."""
        ns = _exec_functions(self.logger)
        chat_raw = 2144563093
        ns["_vc_session_join_success_ids"].add(chat_raw)
        ns["_vc_session_join_success_ids"].add(-1002144563093)
        ev_ok, ev_desc = asyncio.run(
            ns["_vc_positive_evidence_for_chat"](chat_raw)
        )
        self.assertTrue(ev_ok)
        self.assertIn("session_join_success", ev_desc)
        ns["vc_mark_peeruser"](chat_raw)
        self.assertNotIn(chat_raw, ns["_vc_known_peeruser_ids"])

    def test_t_b_zero_evidence_genuine_user_is_blacklisted(self):
        """T-B: zero evidence + genuine user id → blacklisted (FIX-BB kept).

        A DB row with a genuine user id (pre-FIX-AA pollution), not in any
        registry/container/join-success → the sound path blacklists it.
        """
        ns = _exec_functions(self.logger)
        genuine_user = 1038774929  # first VC_PEERUSER_DETECTED in (18+).log
        ev_ok, _ = asyncio.run(ns["_vc_positive_evidence_for_chat"](genuine_user))
        self.assertFalse(ev_ok)

        async def _scenario():
            ns["vc_mark_peeruser"](genuine_user)
            await asyncio.sleep(0.1)  # let the verification task confirm

        asyncio.run(_scenario())
        self.assertIn(genuine_user, ns["_vc_known_peeruser_ids"])
        # Tombstone recorded (reversible):
        self.assertIn(genuine_user, ns["_vc_peeruser_tombstones"])
        self.assertIn("VC_PEERUSER_DETECTED", self.logger.text())
        self.assertIn("verdict=peeruser evidence=none", self.logger.text())
        # NOT reverted (no purge log for this chat):
        self.assertNotIn("VC_PEERUSER_BLACKLIST_PURGED", self.logger.text())
        # The DB delete DID proceed (FIX-BB cleanup preserved for genuine
        # user-id rows — gated on the verification finding no evidence):
        self.assertIn(genuine_user, _DB_DELETES)

    def test_t_c_mark_peeruser_refuses_db_delete_when_registry_state_exists(self):
        """T-C: the DB delete is refused when registry state exists (choke point)."""
        ns = _exec_functions(self.logger)
        chat = 1861200510
        ns["_vc_participations"][chat] = _Rec(chat, "left")  # ANY state counts
        ns["vc_mark_peeruser"](chat)
        self.assertNotIn(chat, ns["_vc_known_peeruser_ids"])
        self.assertNotIn(chat, ns["_vc_peeruser_tombstones"])
        self.assertIn("verdict=peeruser_rejected_evidence", self.logger.text())

    def test_t_i_blacklist_sweep_purges_entries_with_evidence(self):
        """T-I: boot-time sweep purges blacklisted ids that gained evidence."""
        ns = _exec_functions(self.logger)
        protected, genuine = 1941982944, 1067163791
        ns["_vc_known_peeruser_ids"].update({protected, genuine})
        ns["_vc_peeruser_tombstones"][protected] = "old"
        ns["_vc_participations"][protected] = _Rec(protected, "joined")
        purged = asyncio.run(
            ns["_vc_peeruser_blacklist_sweep"](source="test_boot")
        )
        self.assertEqual(purged, 1)
        self.assertNotIn(protected, ns["_vc_known_peeruser_ids"])
        self.assertNotIn(protected, ns["_vc_peeruser_tombstones"])
        self.assertIn(genuine, ns["_vc_known_peeruser_ids"])  # kept
        text = self.logger.text()
        self.assertIn("VC_PEERUSER_BLACKLIST_PURGED", text)
        self.assertIn(f"chat_id={protected}", text)
        self.assertIn("evidence=", text)

    def test_id_form_helper_both_directions(self):
        """T-J: _vc_both_id_forms raw↔marked correctness (both directions)."""
        ns = _exec_functions(self.logger)
        both = ns["_vc_both_id_forms"]
        self.assertEqual(both(1393246704), (1393246704, -1001393246704))
        self.assertEqual(both(-1001393246704), (1393246704, -1001393246704))
        self.assertEqual(both(2054748259), (2054748259, -1002054748259))
        self.assertEqual(both(-1002054748259), (2054748259, -1002054748259))


# =============================================================================
# §2 — FIX-LL source-level: the classification loop resolution (T-D, T-E, T-R, T-S)
# =============================================================================

class TestFixLLClassificationResolutionSource(unittest.TestCase):
    """Source-level assertions on the classification-loop resolution shape."""

    def setUp(self):
        self.src = _read(_VOICECHAT)
        # The classification try-block: anchored at the FIX-LL comment.
        idx = self.src.find("BUG-VC-CLASSIFY-BARE-ID-PEERUSER-")
        self.assertGreater(idx, -1, "FIX-LL classification comment must exist")
        # generous window: the whole probe + resolution + handler region
        # (the forensic comment blocks are long — the handler branch sits
        # ~10k chars past the anchor).
        self.window = self.src[idx: idx + 14000]

    def test_t_d_marked_form_resolution_used(self):
        """T-D: resolution uses the marked form, not the bare id."""
        self.assertIn("_v806_marked = -1000000000000 - gid", self.window)
        self.assertIn("resolve_vc_entity", self.window)
        self.assertIn("chat_id=_v806_marked", self.window)
        # The DB row's access_hash is passed through (InputPeerChannel path).
        self.assertIn('int(g.get("access_hash") or 0)', self.window)

    def test_t_d_bare_id_get_entity_is_gone(self):
        """T-R: the v98.04 bare-id resolution ``client.get_entity, gid``
        MUST be gone from the classification path."""
        self.assertNotIn("client.get_entity, gid", self.src,
                         "bare-id resolution must not exist anywhere")

    def test_t_d_bounded_timeout_on_resolution(self):
        """Bounded classification resolution (25s) — FIX-GG pattern."""
        self.assertIn("timeout=25.0", self.window)

    def test_t_s_sound_user_type_probe(self):
        """T-S: explicit PeerUser construction + User-TYPE check + guard."""
        self.assertIn("from telethon.tl.types import PeerUser as _TL_PeerUser",
                      self.window)
        self.assertIn("client.get_entity(_TL_PeerUser(gid))", self.window)
        self.assertIn('"User"', self.window)
        # Probe bounded at 8s.
        self.assertIn("timeout=8.0", self.window)
        # Probe success is STILL evidence-guarded (id-collision protection).
        probe_idx = self.window.find("if _v806_user_proved:")
        self.assertGreater(probe_idx, -1)
        guard_win = self.window[probe_idx: probe_idx + 1200]
        self.assertIn("_vc_evidence_for_chat_safe(gid)", guard_win)
        self.assertIn("verdict=peeruser_rejected_evidence", guard_win)

    def test_t_e_rotation_fallback_via_resolve_vc_entity(self):
        """T-E: resolution failure routes through rotation, never blacklist.

        resolve_vc_entity (mtproto.py) includes resolve_across_accounts
        (multi-account rotation) as step 4 — the same machinery the join
        path used to resolve the 40 massacre chats. The classification
        failure path (LookupError) increments entity-failure (dead-letter)
        — it does NOT call vc_mark_peeruser directly.
        """
        # The classification path calls resolve_vc_entity:
        self.assertIn("from .mtproto import resolve_vc_entity as _v806_resolve",
                      self.window)
        # resolve_vc_entity contains the rotation step (mtproto.py):
        mt = _read(_MTPROTO)
        ridx = mt.find("async def resolve_vc_entity(")
        self.assertGreater(ridx, -1)
        # v98.07 test maintenance: window 8000 → 10000 — the v98.07 FIX-QQ
        # scope-gate (Step 1) + scope-annotated cache writes sit between the
        # function start and Step 4 (resolve_across_accounts); the assertions
        # themselves are UNCHANGED (contract preserved, only the extraction
        # window widened for the inserted guard code).
        # v98.10 test maintenance: window 10000 → 20000 — the v98.10
        # single-flight (§41) + Step-0 scoped routing (§15) + failure
        # classification (§9) sections sit between the function start and
        # Step 4; the ROTATION CONTRACT (asserted below) is unchanged.
        # v98.11 test maintenance: window 20000 → 26000 — the v98.11
        # S4/S5 no-rotation gate (local-miss/temporary + composite
        # Step-2 class) sits between the function start and Step 4; the
        # ROTATION CONTRACT is unchanged.
        rwin = mt[ridx: ridx + 26000]
        # v98.11: the rotation call now also carries the caller-provided
        # access_hash (S6 typed fast-recovery probe) and spans lines —
        # the ROTATION CONTRACT (step 4 of the resolver) is unchanged;
        # the pin tracks the new call form.
        self.assertIn("resolve_across_accounts(", rwin)
        self.assertIn("identity=_ident", rwin)
        self.assertIn("rpc_counter=_rpc_counter", rwin)
        self.assertIn("access_hash=int(access_hash or 0)", rwin)
        self.assertIn("account_rotation", rwin)
        # v98.07 FIX-QQ extension: the resolver is now scope-aware (the F2
        # cross-scope poisoning gate) — assert the NEW contract too.
        self.assertIn("_vc_cache_scope_ok(cached, client)", rwin)
        self.assertIn("VC_HASH_SCOPE_MISMATCH", rwin)
        self.assertIn("\"scope\": _vc_client_scope(client)", rwin)
        # LookupError → entity-failure (dead-letter), not blacklist:
        self.assertIn("isinstance(ent_exc, LookupError)", self.window)
        self.assertIn("vc_record_entity_failure(gid)", self.window)

    def test_peeruser_branch_is_soundly_guarded(self):
        """The PeerUser verdict branch requires id match + zero evidence."""
        self.assertIn('if "peeruser" in _ent_msg_lower:', self.window)
        self.assertIn("str(gid) in _ent_msg_lower and not _v806_ev_ok",
                      self.window)
        self.assertIn("verdict=peeruser_rejected_evidence", self.window)

    def test_evidence_check_runs_before_verdict(self):
        """The FULL evidence check precedes any verdict in the handler."""
        self.assertIn("_v806_ev_ok, _v806_ev = await _vc_evidence_for_chat_safe(gid)",
                      self.window)

    def test_sweep_wired_at_join_all_start(self):
        """T-L: the blacklist sanity sweep runs at Join-All start."""
        idx = self.src.find('_vc_peeruser_blacklist_sweep(source="join_all_start")')
        self.assertGreater(idx, -1, "sweep must be wired at worker start")
        # near vc_reset_target_state in the worker startup region:
        reset_idx = self.src.find("vc_reset_target_state()")
        self.assertGreater(reset_idx, -1)
        self.assertLess(abs(idx - reset_idx), 1500,
                        "sweep must be adjacent to the worker reset block")
        # bounded sweep:
        w = self.src[idx - 200: idx + 300]
        self.assertIn("timeout=10.0", w)

    def test_session_join_success_populated_in_join(self):
        """T-K: join() success records both id forms in the session set."""
        idx = self.src.find("_vc_session_join_success_ids.add(_v806_raw)")
        self.assertGreater(idx, -1)
        # v98.13 test maintenance: 1500 → 4500 back-window — the v98.13
        # §GATE (join-time Telegram verification + evidence recording)
        # sits between the VC_JOIN_SUCCESS log and the session-set add;
        # the CONTRACT (session set populated on join success) is
        # unchanged.
        w = self.src[max(0, idx - 4500): idx + 800]
        self.assertIn("VC_JOIN_SUCCESS", w)
        self.assertIn("_vc_both_id_forms(chat_id)", w)
        self.assertIn("_vc_session_join_success_ids.add(_v806_marked)", w)


# =============================================================================
# §3 — FIX-NN: classification-failure observability
# =============================================================================

class TestFixNNClassifyFailureMarkers(unittest.TestCase):

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_marker_in_exception_branch(self):
        # The marker format exists (first occurrence = the helper def):
        # v98.07 test maintenance: the v98.07 FIX-QQ retry path in
        # _vc_detect_active_call_scoped ALSO emits VC_CLASSIFY_FAILURE — the
        # v98.06 first-occurrence anchor now lands on that NEW (legitimate)
        # emission instead of the helper. Anchor on the HELPER's occurrence
        # (find the def first, then the marker AFTER it). Assertions below
        # are UNCHANGED (contract preserved).
        _hdef = self.src.find("def _vc_classify_failure_log(")
        self.assertGreater(_hdef, -1, "FIX-NN helper must exist")
        idx = self.src.find("VC_CLASSIFY_FAILURE chat_id=%s err_type=%s", _hdef)
        self.assertGreater(idx, -1, "FIX-NN marker must exist")
        w = self.src[max(0, idx - 400): idx + 600]
        # FULL error text truncated to 200 chars (helper param form `exc`):
        self.assertIn("str(exc)[:200]", w)
        self.assertIn("evidence_guard=", w)
        # The classification handler calls the helper with the exception:
        hidx = self.src.find("_vc_classify_failure_log(gid, ent_exc, _v806_ev_ok)")
        self.assertGreater(hidx, -1, "handler must call the FIX-NN helper")

    def test_marker_in_timeout_branch(self):
        self.assertIn(
            "VC_CLASSIFY_FAILURE chat_id=%s err_type=", self.src
        )
        # The timeout branch emits the marker too:
        t_idx = self.src.find("VC_JOIN_ALL_ENTITY_TIMEOUT")
        self.assertGreater(t_idx, -1)
        w = self.src[t_idx: t_idx + 1200]
        self.assertIn("VC_CLASSIFY_FAILURE", w)

    def test_helper_logs_full_text(self):
        """_vc_classify_failure_log behavioral: full text + 200-char truncation."""
        logger = _FakeLogger()
        ns = _exec_namespace(logger)
        src = _read(_VOICECHAT)
        seg = _extract_toplevel(src, "_vc_classify_failure_log")
        assert seg is not None
        exec(compile(seg, "<f>", "exec"), ns)  # noqa: S102
        ns["_vc_classify_failure_log"](
            123, ValueError("x" * 500), False
        )
        text = logger.text()
        self.assertIn("VC_CLASSIFY_FAILURE chat_id=123", text)
        self.assertIn("err_type=ValueError", text)
        self.assertIn("evidence_guard=n/a", text)
        self.assertIn("x" * 200, text)
        self.assertNotIn("x" * 201, text)  # truncated to 200

    def test_blacklist_decision_marker_on_every_outcome(self):
        """FIX-PP: VC_BLACKLIST_DECISION emitted on accepted AND rejected."""
        self.assertIn("VC_BLACKLIST_DECISION", self.src)
        self.assertIn("verdict=peeruser_rejected_evidence", self.src)
        self.assertIn("verdict=peeruser evidence=none", self.src)


# =============================================================================
# §4 — FIX-MM behavioral + source: reconcile anti-starvation (T-F)
# =============================================================================

class TestFixMMReconcileAntiStarvation(unittest.TestCase):

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_t_f_force_after_two_consecutive_skips(self):
        """T-F: after N=2 join_all_running skips, a bounded slice is forced."""
        self.assertIn("_v806_ja_skip_streak >= 2", self.src)
        self.assertIn("VC_MOD_RECONCILE_FORCE_AFTER_STARVATION", self.src)

    def test_t_f_force_branch_falls_through_not_skips(self):
        """The forced branch must NOT continue (it must fall through to the
        remaining gates + the reconcile call)."""
        idx = self.src.find("VC_MOD_RECONCILE_FORCE_AFTER_STARVATION")
        self.assertGreater(idx, -1)
        w = self.src[idx: idx + 2000]
        # The next gate after the force is the MTProto-disconnected check:
        self.assertIn("_vc_mtproto_connected_async()", w)
        # And after the gates, the reconcile runs:
        self.assertIn("await vc_reconcile_participations()", w)

    def test_t_f_skip_branch_still_skips_on_first_streak(self):
        """The first skip (streak=1) still defers (unchanged behavior)."""
        self.assertIn(
            "VC_MOD_RECONCILE_SKIP reason=join_all_running", self.src
        )
        idx = self.src.find('(streak=%d/2)", _v806_ja_skip_streak,')
        self.assertGreater(idx, -1)

    def test_t_f_streak_resets_when_not_running(self):
        """Streak resets when Join-All is NOT running (gaps still reconcile)."""
        self.assertIn("else:\n                _v806_ja_skip_streak = 0", self.src)

    def test_gates_still_apply_after_force(self):
        """FloodWait / disconnected / backpressure gates remain in order
        BEFORE the reconcile call (the force only bypasses join_all)."""
        loop_idx = self.src.find("async def _vc_reconcile_loop(")
        self.assertGreater(loop_idx, -1)
        w = self.src[loop_idx: loop_idx + 9000]
        self.assertIn("vc_is_global_floodwait_active()", w)
        self.assertIn("_vc_join_all_running", w)
        self.assertIn("_vc_mtproto_connected_async()", w)
        self.assertIn("vc_get_backpressure_state()", w)
        self.assertIn("await vc_reconcile_participations()", w)


# =============================================================================
# §5 — FIX-MM behavioral: CoverageManager sync (T-G)
# =============================================================================

class _FakeCoverageSelf:
    """Minimal VCCoverageManager stand-in for the REAL _reconcile_cycle."""

    def __init__(self):
        self._active_vcs = {}
        self._joined_vcs = set()
        self._retry_queue = {}
        self._stop_requested = False

    def get_missing_vcs(self):
        return [c for c in self._active_vcs if c not in self._joined_vcs]

    def get_ready_retries(self):
        return []

    def clear_retry(self, chat_id):
        self._retry_queue.pop(chat_id, None)


class TestFixMMCoverageManagerSync(unittest.TestCase):
    """Behavioral: exec the REAL _reconcile_cycle method with mocks."""

    def _run_cycle(self, registry_recs, container_ids):
        logger = _FakeLogger()
        src = _read(_VOICECHAT)
        seg = _extract_method(src, "VCCoverageManager", "_reconcile_cycle")
        assert seg is not None, "_reconcile_cycle not found"
        fake_self = _FakeCoverageSelf()

        async def _fake_list():
            return registry_recs

        async def _fake_container(account_id: str = ""):
            return ("__fake__",)

        def _fake_extract(raw):
            return set(container_ids)

        def _fake_retry_stats():
            return {"total": 0, "ready": 0}

        # _vc_both_id_forms (real, extracted):
        ns_both: dict = {"asyncio": asyncio, "time": time, "logger": logger}
        seg_both = _extract_toplevel(src, "_vc_both_id_forms")
        assert seg_both is not None
        exec(compile(seg_both, "<f>", "exec"), ns_both)  # noqa: S102

        ns = {
            "asyncio": asyncio, "time": time, "Any": object,
            "logger": logger,
            "vc_registry_list": _fake_list,
            "vc_resolve_calls_container": _fake_container,
            "_extract_chat_ids_from_container": _fake_extract,
            "vc_retry_queue_stats": _fake_retry_stats,
            "_vc_both_id_forms": ns_both["_vc_both_id_forms"],
            "_vc_target_cooldowns": {},
        }
        exec(compile(seg, "<method>", "exec"), ns)  # noqa: S102
        asyncio.run(ns["_reconcile_cycle"](fake_self))
        return fake_self, logger

    def test_t_g_registry_feeds_active_and_joined(self):
        """T-G: registry records populate _active_vcs + _joined_vcs (REAL cycle)."""
        joined_chat = 1393246704          # the (18+).log decisive chat
        unknown_chat = 1879503489
        recs = [_Rec(joined_chat, "joined"), _Rec(unknown_chat, "unknown")]
        fake_self, logger = self._run_cycle(recs, container_ids=set())
        # joined (both id forms) + unknown (both forms) are ACTIVE:
        self.assertIn(joined_chat, fake_self._active_vcs)
        self.assertIn(-1001393246704, fake_self._active_vcs)
        self.assertIn(unknown_chat, fake_self._active_vcs)
        # Only the joined one is in _joined_vcs:
        self.assertIn(joined_chat, fake_self._joined_vcs)
        self.assertNotIn(unknown_chat, fake_self._joined_vcs)
        # The log line now reports REAL counts (not the lying zeros):
        text = logger.text()
        self.assertIn("VC_COVERAGE_RECONCILE_START", text)
        for zero_lie in ("active=0 ", "joined=0 "):
            self.assertNotIn(zero_lie, text.split("VC_COVERAGE_RECONCILE_START")[1][:200])

    def test_t_g_container_only_chats_are_active(self):
        """Container-present chats (no registry record) count as active."""
        container_only = -1003897420686
        fake_self, _ = self._run_cycle([], container_ids={container_only})
        self.assertIn(container_only, fake_self._active_vcs)
        self.assertNotIn(container_only, fake_self._joined_vcs)

    def test_t_g_missing_equals_active_minus_joined(self):
        """missing = active − joined (the actual coverage signal)."""
        joined_chat, unknown_chat = 1393246704, 1879503489
        recs = [_Rec(joined_chat, "joined"), _Rec(unknown_chat, "unknown")]
        fake_self, _ = self._run_cycle(recs, container_ids=set())
        missing = fake_self.get_missing_vcs()
        self.assertIn(unknown_chat, missing)
        self.assertIn(-1001879503489, missing)
        self.assertNotIn(joined_chat, missing)

    def test_t_g_sync_source_wired_in_cycle(self):
        """Source: the sync block exists in _reconcile_cycle."""
        src = _read(_VOICECHAT)
        idx = src.find("async def _reconcile_cycle(")
        # v99.03 test maintenance: window 4000 -> 4800 — the RC-13
        # pipeline-disabled short-circuit sits between the cycle head and
        # the FIX-MM sync block; the CONTRACT (sync from authoritative
        # sources in the cycle) is unchanged.
        w = src[idx: idx + 4800]
        self.assertIn("vc_registry_list()", w)
        self.assertIn("vc_resolve_calls_container()", w)
        self.assertIn("self._active_vcs = _v806_active", w)
        self.assertIn("self._joined_vcs = _v806_joined", w)
        # Bounded container read:
        self.assertIn("timeout=2.5", w)


# =============================================================================
# §6 — FIX-OO: heartbeat uptime clock domain (T-H)
# =============================================================================

class TestFixOOHeartbeatClock(unittest.TestCase):

    def setUp(self):
        self.src = _read(_HANDLERS)

    def test_t_h_epoch_domain_formula(self):
        """T-H: uptime = time.time() - _BOT_START_TIME (single epoch domain)."""
        self.assertIn("_uptime = time.time() - _BOT_START_TIME", self.src)
        # The monotonic-epoch mixup is GONE:
        self.assertNotIn("_now_mono - _BOT_START_TIME", self.src)

    def test_t_h_start_time_is_epoch(self):
        self.assertIn("_BOT_START_TIME = time.time()", self.src)

    def test_t_h_interval_gating_keeps_monotonic(self):
        """The 60s log-interval gate correctly stays monotonic (never wall clock)."""
        self.assertIn("if _now_mono - _last_hb_log >= 60.0:", self.src)

    def test_t_h_formula_sanity(self):
        """Formula sanity: uptime positive and ≈ wall-clock since boot."""
        _BOT_START_TIME = time.time() - 75.0
        uptime = time.time() - _BOT_START_TIME
        self.assertGreater(uptime, 74.0)
        self.assertLess(uptime, 76.0)
        # The v98.05 bug shape (monotonic - epoch) is hugely negative:
        buggy = time.monotonic() - _BOT_START_TIME
        self.assertLess(buggy, -1_000_000_000)

    def test_siblings_are_clean(self):
        """All other _BOT_START_TIME usages are epoch-domain."""
        for line in self.src.splitlines():
            if "_BOT_START_TIME" in line and "monotonic" in line:
                self.fail(f"clock-domain mixup persists: {line.strip()}")

    def test_marker_documents_fix(self):
        self.assertIn("v98.06 FIX-OO", self.src)
        self.assertIn("uptime=-1787480363", self.src)  # runtime evidence cited


# =============================================================================
# §7 — FIX-PP: generation-state counter honesty
# =============================================================================

class TestFixPPGenerationStateCounter(unittest.TestCase):

    def setUp(self):
        self.src = _read(_MTPROTO)

    def test_total_sessions_lie_is_gone(self):
        self.assertNotIn("total_sessions=%d", self.src)

    def test_generation_sessions_and_live_clients(self):
        self.assertIn("generation_sessions=%d live_clients=%d", self.src)
        self.assertIn("_v806_live_clients", self.src)
        # Real sources: healthy cluster accounts + connected global client.
        self.assertIn("get_healthy_accounts()", self.src)
        self.assertIn("_mtproto_client.is_connected()", self.src)

    def test_v97_61_marker_contract_preserved(self):
        self.assertIn("MTPROTO_GENERATION_STATE", self.src)
        # The invariant check is unchanged:
        self.assertIn("MTPROTO_GENERATION_INVARIANT_VIOLATION", self.src)


# =============================================================================
# §8 — Version bump + preserved invariants
# =============================================================================

class TestVersionBump(unittest.TestCase):

    def test_init_version_is_v98_06(self):
        self.assertIn('__bot_version__ = "v99.11.1"', _read(_INIT))

    def test_bootstrap_deployment_identity_is_v98_06(self):
        self.assertIn("DEPLOYMENT_IDENTITY version={_v9812_pkg_version} ", _read(_BOOTSTRAP))  # v99: derivation site


class TestPreservedInvariants(unittest.TestCase):
    """v98.06 must NOT weaken any prior fix (v97.30-v98.05)."""

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_bb_fast_skip_preserved(self):
        """FIX-BB fast-skip (pacing) still present — the PROOF rule was the
        only thing fixed, not the fast-skip value."""
        idx = self.src.find('gid = g["group_id"]')
        self.assertGreater(idx, -1)
        w = self.src[idx: idx + 3000]
        self.assertIn("vc_is_known_peeruser(gid)", w)
        self.assertIn("reason=known_peeruser", w)

    def test_fix_bb_module_set_and_signature_preserved(self):
        self.assertIn("_vc_known_peeruser_ids: set[int] = set()", self.src)
        self.assertIn("def vc_is_known_peeruser(chat_id: int) -> bool:", self.src)
        self.assertIn("def vc_mark_peeruser(chat_id: int) -> None:", self.src)

    def test_fix_bb_346_reference_preserved(self):
        idx = self.src.find("_vc_known_peeruser_ids: set[int] = set()")
        w = self.src[max(0, idx - 2500): idx + 1000]
        self.assertIn("346", w)
        self.assertIn("PeerUser", w)

    def test_fix_x_both_id_forms_leave_preserved(self):
        self.assertIn("async def _leave_target", self.src)
        idx = self.src.find("async def _leave_target")
        w = self.src[idx: idx + 9500]
        self.assertIn("VC_LEAVE_TARGET_NOOP", w)

    def test_fix_y_registry_left_guard_preserved(self):
        self.assertIn("BUG-VC-SNAPSHOT-LEFT-TO-JOINED", self.src)
        self.assertIn('_registry_state_for_skip == "left"', self.src)

    def test_fix_dd_extended_guard_preserved(self):
        self.assertIn("snapshot_stale_container:unknown_registry", self.src)
        self.assertIn("snapshot_stale_container:recovery_pending_registry", self.src)

    def test_fix_cc_recovery_markers_preserved(self):
        for marker in (
            "VC_STALE_CONTAINER_RECOVERY_START",
            "VC_STALE_CONTAINER_REJOIN_ELIGIBLE",
            "VC_STALE_CONTAINER_RECOVERY_PENDING",
        ):
            self.assertIn(marker, self.src)

    def test_fix_gg_bounded_timeouts_preserved(self):
        self.assertIn("timeout=12.0", self.src)  # worker/snapshot recovery

    def test_fix_ff_worker_markers_preserved(self):
        for marker in ("BOT_WORKER_START", "BOT_WORKER_COMPLETE"):
            self.assertIn(marker, _read(_BOOTSTRAP))

    def test_correctly_classified_already_joined_path_untouched(self):
        """Guardrail #4: the 5 correct ALREADY_JOINED (backend_connected on
        registry=JOINED) path is unchanged — backend_connected on a
        non-joined registry still enters ALREADY_JOINED."""
        idx = self.src.find("to=ALREADY_JOINED reason=backend_connected")
        self.assertGreater(idx, -1)


# =============================================================================
# §9 — Runtime-evidence correlation (forensic traceability)
# =============================================================================

class TestRuntimeEvidenceCorrelation(unittest.TestCase):

    def setUp(self):
        self.src = _read(_VOICECHAT)

    def test_fix_ll_cites_massacre_evidence(self):
        """The FIX-LL comment must cite the decisive (18+).log evidence."""
        idx = self.src.find("BUG-VC-CLASSIFY-BARE-ID-PEERUSER-")
        w = self.src[idx: idx + 3000]
        self.assertIn("169", w)               # VC_PEERUSER_DETECTED total
        self.assertIn("1393246704", w)        # decisive chat
        self.assertIn("40/40", w)             # rotation correlation
        self.assertIn("17:50:54", w)          # "proven user ID" timestamp

    def test_fix_mm_cites_starvation_evidence(self):
        idx = self.src.find("BUG-VC-MOD-RECONCILE-STARVED-BY-JOIN-ALL")
        self.assertGreater(idx, -1)
        w = self.src[idx: idx + 1500]
        self.assertIn("17:37:43", w)
        self.assertIn("17:52:44", w)

    def test_fix_mm_cites_decorative_coverage_evidence(self):
        idx = self.src.find("BUG-VC-COVERAGE-DECORATIVE")
        self.assertGreater(idx, -1)
        w = self.src[idx: idx + 1200]
        self.assertIn("active=0 joined=0 missing=0", w)
        self.assertIn("22", w)


# =============================================================================
# §10 — Honest scope
# =============================================================================

class TestHonestScope(unittest.TestCase):
    """Explicitly document what v98.06 does NOT claim."""

    def test_not_yet_proven_documented(self):
        manifest = os.path.join(_PKG_ROOT, "PATCH_MANIFEST_v98.06.txt")
        if not os.path.exists(manifest):
            self.skipTest("manifest not yet built (pre-packaging run)")
        text = _read(manifest)
        self.assertIn("NOT YET PROVEN", text)
        self.assertIn("RUNTIME-PROVEN", text)


if __name__ == "__main__":
    unittest.main()
