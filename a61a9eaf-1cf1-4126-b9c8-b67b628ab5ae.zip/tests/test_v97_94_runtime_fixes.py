"""Regression tests for v97.94 forensic audit fixes.

These tests verify the SOURCE-PROVEN + RUNTIME-PROVEN bugs fixed in v97.94:
  BUG-MAIN-1: voicechat.py:18904 — IndexError on all-slash commands ("/", "//")
  BUG-P6-1: voicechat.py:6816 — inner handler exception logger promoted to WARNING
  BUG-P7-1: mtproto.py — duplicate _progress removed (supervised version is the only one)
  BUG-P13-1: bootstrap.py — TaskSupervisor.cancel_all() runs BEFORE close_db()

Each test is a behavioral regression — it verifies the runtime property
the fix establishes, not just the source-text pattern.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

# Ensure the package is importable
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


# ---------------------------------------------------------------------------
# BUG-MAIN-1: voicechat.py _vc_handle_vc_command must not raise IndexError
#             on all-slash messages ("/", "//", "/ ", "/\n")
# ---------------------------------------------------------------------------
class TestBugMain1IndexErrorGuard:
    """Regression for BUG-MAIN-1 (RUNTIME-PROVEN: 3 IndexError events in
    bot-diagnostic (6).log at 06:59:50, 06:59:57, 07:06:43).

    Root cause: ``text.lstrip("/").lower().split()[0]`` raised IndexError
    when text was all-slashes (lstrip yields "" → "".split() = [] → [0] fails).
    The fix guards with an explicit empty-list check.
    """

    @staticmethod
    def _cmd_extraction_logic(text: str) -> str:
        """Replicate the FIXED cmd-extraction logic from voicechat.py:18904."""
        text = (text or "").strip()
        if not text:
            return ""
        _cmd_parts = text.lstrip("/").lower().split() if text else []
        return _cmd_parts[0] if _cmd_parts else ""

    def test_all_slash_single(self):
        """"/" must NOT raise IndexError — was the root cause of BUG-MAIN-1."""
        assert self._cmd_extraction_logic("/") == ""

    def test_all_slash_double(self):
        assert self._cmd_extraction_logic("//") == ""

    def test_all_slash_triple(self):
        assert self._cmd_extraction_logic("///") == ""

    def test_slash_with_space(self):
        # "/ " → strip() → "/" → lstrip("/") → "" → split() → []
        assert self._cmd_extraction_logic("/ ") == ""

    def test_slash_with_newline(self):
        assert self._cmd_extraction_logic("/\n") == ""

    def test_normal_command_owner(self):
        """Normal commands still work after the fix."""
        assert self._cmd_extraction_logic("/owner") == "owner"

    def test_normal_command_with_bot_mention(self):
        assert self._cmd_extraction_logic("/kill@im_bakabot") == "kill@im_bakabot"

    def test_normal_command_with_args(self):
        assert self._cmd_extraction_logic("/joinall --retry") == "joinall"

    def test_empty_text(self):
        assert self._cmd_extraction_logic("") == ""

    def test_whitespace_only(self):
        assert self._cmd_extraction_logic("   ") == ""


# ---------------------------------------------------------------------------
# BUG-P6-1: voicechat.py:6816 inner handler exception logger must be WARNING
# ---------------------------------------------------------------------------
class TestBugP6_1HandlerExceptionLogLevel:
    """Regression for BUG-P6-1.

    The v97.74 comment claimed the worker exception was promoted to WARNING,
    but that promotion only applied to the OUTER worker exception
    (VC_CALLBACK_WORKER_FATAL). The INNER handler exception
    (VC_CALLBACK_WORKER_ERROR) was left at DEBUG — invisible at INFO+
    production logging. The fix promotes it to WARNING.
    """

    def test_inner_handler_exception_log_is_warning_level(self):
        """The VC_CALLBACK_WORKER_ERROR log call must use logger.warning, not logger.debug.

        This is a source-text test, but it's the ONLY way to verify the log
        level without a full Telethon/PyTgCalls integration environment.
        """
        voicechat_path = ROOT / "mediagrab_bot" / "voicechat.py"
        if not voicechat_path.exists():
            pytest.skip("voicechat.py not found")
        source = voicechat_path.read_text()
        # Find the VC_CALLBACK_WORKER_ERROR line
        assert "VC_CALLBACK_WORKER_ERROR" in source, "marker missing"
        # The line must use logger.warning, NOT logger.debug
        # Find the line and check the log method
        lines = source.splitlines()
        for i, line in enumerate(lines):
            if "VC_CALLBACK_WORKER_ERROR" in line and "logger." in lines[max(0, i - 1)]:
                # The previous line should contain logger.warning
                prev = lines[i - 1]
                assert "logger.warning" in prev, (
                    f"BUG-P6-1 regression: VC_CALLBACK_WORKER_ERROR at line {i+1} "
                    f"uses '{prev.strip()}' — must be logger.warning (was logger.debug)"
                )
                return
        # If the logger call is on the SAME line
        for line in lines:
            if "VC_CALLBACK_WORKER_ERROR" in line and "logger." in line:
                assert "logger.warning" in line, (
                    f"BUG-P6-1 regression: line uses logger.debug instead of logger.warning: {line.strip()}"
                )
                return
        pytest.fail("Could not locate VC_CALLBACK_WORKER_ERROR logger call")


# ---------------------------------------------------------------------------
# BUG-P7-1: mtproto.py must have only ONE _progress definition (the supervised one)
# ---------------------------------------------------------------------------
class TestBugP7_1NoDuplicateProgress:
    """Regression for BUG-P7-1.

    A duplicate ``def _progress`` previously existed at mtproto.py:6335-6343
    that SHADOWED the supervised version at 6282-6293. The orphan version used
    ``asyncio.get_running_loop().create_task(...)`` (fire-and-forget) instead
    of ``supervised_create_task`` — exactly the bug the v97.74 comment claims
    to have fixed. The fix removed the orphan definition.
    """

    def test_no_orphan_progress_definition(self):
        """mtproto.py must have exactly ONE _progress definition per download function,
        and it must use supervised_create_task (not asyncio.get_running_loop().create_task)."""
        mtproto_path = ROOT / "mediagrab_bot" / "mtproto.py"
        if not mtproto_path.exists():
            pytest.skip("mtproto.py not found")
        source = mtproto_path.read_text()
        lines = source.splitlines()

        # Find all "def _progress(" definitions
        progress_defs = [
            i + 1 for i, line in enumerate(lines)
            if "def _progress(" in line
        ]
        assert len(progress_defs) >= 1, "no _progress definition found"

        # For each _progress definition, check the body uses supervised_create_task
        # (NOT asyncio.get_running_loop().create_task)
        for def_line in progress_defs:
            idx = def_line - 1
            # Look at the next ~10 lines for the create_task call
            body = "\n".join(lines[idx: idx + 15])
            if "progress_cb" in body and "create_task" in body:
                # Must use supervised_create_task, NOT asyncio.get_running_loop().create_task
                assert "supervised_create_task" in body or "asyncio.get_running_loop().create_task" not in body, (
                    f"BUG-P7-1 regression: _progress at line {def_line} uses orphan "
                    f"asyncio.get_running_loop().create_task instead of supervised_create_task"
                )

    def test_no_bare_asyncio_get_running_loop_create_task_in_progress(self):
        """The orphan pattern ``asyncio.get_running_loop().create_task(progress_cb(...))``
        must NOT appear inside any _progress function body."""
        mtproto_path = ROOT / "mediagrab_bot" / "mtproto.py"
        if not mtproto_path.exists():
            pytest.skip("mtproto.py not found")
        source = mtproto_path.read_text()
        lines = source.splitlines()

        # Find _progress definitions
        progress_starts = [i for i, line in enumerate(lines) if "def _progress(" in line]
        for start in progress_starts:
            # Scan body until the next def at the same or lower indentation
            body_lines = []
            base_indent = len(lines[start]) - len(lines[start].lstrip())
            for j in range(start + 1, min(start + 20, len(lines))):
                line = lines[j]
                if line.strip() == "":
                    continue
                indent = len(line) - len(line.lstrip())
                if indent <= base_indent and line.strip().startswith(("def ", "async def ", "class ")):
                    break
                body_lines.append(line)
            body = "\n".join(body_lines)
            assert "asyncio.get_running_loop().create_task" not in body, (
                f"BUG-P7-1 regression: orphan create_task pattern found in "
                f"_progress body starting at line {start + 1}"
            )


# ---------------------------------------------------------------------------
# BUG-P13-1: bootstrap.py must cancel TaskSupervisor tasks BEFORE close_db()
# ---------------------------------------------------------------------------
class TestBugP13_1ShutdownOrdering:
    """Regression for BUG-P13-1.

    TaskSupervisor.cancel_all() previously ran AFTER close_db(), so any task
    that touches the DB during cancellation would hit a "DB closed" error.
    The fix reorders: cancel_all FIRST, then close_db.
    """

    def test_cancel_all_before_close_db(self):
        """In _post_stop, TaskSupervisor.cancel_all must appear BEFORE close_db."""
        bootstrap_path = ROOT / "mediagrab_bot" / "bootstrap.py"
        if not bootstrap_path.exists():
            pytest.skip("bootstrap.py not found")
        source = bootstrap_path.read_text()
        lines = source.splitlines()

        # Find _post_stop
        post_stop_start = None
        for i, line in enumerate(lines):
            if "async def _post_stop" in line:
                post_stop_start = i
                break
        if post_stop_start is None:
            pytest.skip("_post_stop not found")

        # Find the next function definition after _post_stop
        post_stop_end = len(lines)
        for i in range(post_stop_start + 1, len(lines)):
            if lines[i].startswith("async def ") or lines[i].startswith("def "):
                post_stop_end = i
                break

        body = "\n".join(lines[post_stop_start:post_stop_end])

        cancel_all_pos = body.find("TaskSupervisor.cancel_all")
        close_db_pos = body.find("close_db()")

        assert cancel_all_pos != -1, "TaskSupervisor.cancel_all not found in _post_stop"
        assert close_db_pos != -1, "close_db() not found in _post_stop"
        assert cancel_all_pos < close_db_pos, (
            "BUG-P13-1 regression: TaskSupervisor.cancel_all (offset "
            f"{cancel_all_pos}) must appear BEFORE close_db() (offset {close_db_pos}) "
            "in _post_stop — inverted order risks DB-after-close errors"
        )


# ---------------------------------------------------------------------------
# BUG-P4-1 instrumentation: MTPROTO_GEN_RETIRING_STUCK marker must exist
# ---------------------------------------------------------------------------
class TestBugP4_1RetiringStuckInstrumentation:
    """Regression for BUG-P4-1 instrumentation.

    retire_generation() is dead code (never called). The instrumentation
    logs MTPROTO_GEN_RETIRING_STUCK when generations are stuck in RETIRING.
    This is observability-only — no behavior change.
    """

    def test_retiring_stuck_marker_exists(self):
        mtproto_path = ROOT / "mediagrab_bot" / "mtproto.py"
        if not mtproto_path.exists():
            pytest.skip("mtproto.py not found")
        source = mtproto_path.read_text()
        assert "MTPROTO_GEN_RETIRING_STUCK" in source, (
            "BUG-P4-1 instrumentation missing: MTPROTO_GEN_RETIRING_STUCK "
            "marker not found — retire_generation dead-code leak has no "
            "observability"
        )


# ---------------------------------------------------------------------------
# BUG-P4-2 instrumentation: MTPROTO_STOP_RECONNECT_IN_FLIGHT marker must exist
# ---------------------------------------------------------------------------
class TestBugP4_2StopReconnectInFlightInstrumentation:
    """Regression for BUG-P4-2 instrumentation.

    mtproto_stop doesn't acquire the RW write lock. The instrumentation
    logs MTPROTO_STOP_RECONNECT_IN_FLIGHT if a reconnect is in-flight at
    shutdown time. Observability-only.
    """

    def test_stop_reconnect_in_flight_marker_exists(self):
        mtproto_path = ROOT / "mediagrab_bot" / "mtproto.py"
        if not mtproto_path.exists():
            pytest.skip("mtproto.py not found")
        source = mtproto_path.read_text()
        assert "MTPROTO_STOP_RECONNECT_IN_FLIGHT" in source, (
            "BUG-P4-2 instrumentation missing: MTPROTO_STOP_RECONNECT_IN_FLIGHT "
            "marker not found — stop/reconnect race has no observability"
        )


# ---------------------------------------------------------------------------
# Version bump verification
# ---------------------------------------------------------------------------
class TestVersionBump:
    """Verify v97.95 version strings are in place."""

    def test_init_bot_version(self):
        init_path = ROOT / "mediagrab_bot" / "__init__.py"
        source = init_path.read_text()
        assert '__bot_version__ = "v99.11.1"' in source, (
            "__bot_version__ not bumped to v97.95"
        )

    def test_bootstrap_deployment_identity(self):
        bootstrap_path = ROOT / "mediagrab_bot" / "bootstrap.py"
        source = bootstrap_path.read_text()
        assert "version={_v9812_pkg_version}" in source, (  # v99: derivation site
            "DEPLOYMENT_IDENTITY version not bumped to v97.95"
        )
