"""
v97.62 regression tests — fixes against the actual v97.61 runtime log.

Runtime log evidence (from note (33).txt):
  - VC_CALLBACK_HANDLER_TIMEOUT: 33 occurrences (30-65s handler block)
  - VC_CALLBACK_HANDLER_SLOW: 93 occurrences (2-65s)
  - EVENT_LOOP_LAG_CRITICAL: 11 occurrences (up to 29.78s)
  - invalid call_id=0: 3 occurrences
  - NO_ACTIVE_CALL: 52 occurrences (verification storm)
  - MTPROTO_RECONNECT_ERROR: 2 (TimeoutError)
  - InterdcCall: 8 occurrences
  - VC_CALLBACK_QUEUE_FULL: 8 occurrences
  - Markdown parse failed: 4
  - TypeError: 0 (v97.61 fix worked)

Root cause of callback block:
  _vc_handle_vc_command did `await event.get_sender()`, `await event.get_chat()`,
  `await mtproto_get_client().get_me()` BEFORE the fast-ack routing. These are
  Telethon RPCs that block on the SQLite session lock during MTProto disconnect.
  The v97.59 fast-ack only routed the EXECUTION, not the ENTITY LOOKUP.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SRC = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestCallbackHandlerNoBlockingRPCs(unittest.TestCase):
    """§2: the callback handler must NOT do ANY Telethon RPC that can block."""

    def test_no_get_sender_in_handler(self):
        """The handler must use event.sender_id (sync), not await event.get_sender()."""
        with open(_SRC) as f:
            src = f.read()
        # Extract the function body (between _vc_handle_vc_command and the next function).
        import re
        m = re.search(
            r'async def _vc_handle_vc_command\(event\).*?(?=\nasync def |\ndef |\nclass )',
            src, re.DOTALL)
        self.assertIsNotNone(m, "function not found")
        func_body = m.group(0)
        # The ONLY await event.get_sender / get_chat should be in the docstring
        # comment or inside _long_op_fn (the scheduler worker). Check the
        # handler body BEFORE _long_op_fn for get_sender/get_chat/get_me.
        # Split at _long_op_fn — everything before it must not have get_sender/get_chat.
        parts = func_body.split("async def _long_op_fn")
        handler_only = parts[0]
        # Remove docstring.
        handler_only_no_doc = re.sub(r'""".*?"""', '', handler_only, flags=re.DOTALL)
        self.assertNotIn("await event.get_sender()", handler_only_no_doc,
                         "handler must not call await event.get_sender() (use event.sender_id)")
        self.assertNotIn("await event.get_chat()", handler_only_no_doc,
                         "handler must not call await event.get_chat() (use event.chat_id)")
        self.assertNotIn("await mtproto_get_client().get_me()", handler_only_no_doc,
                         "handler must not call get_me() (use cached _userbot_id)")

    def test_handler_uses_sync_sender_id(self):
        """The handler must use event.sender_id (sync property)."""
        with open(_SRC) as f:
            src = f.read()
        import re
        m = re.search(
            r'async def _vc_handle_vc_command\(event\).*?(?=\nasync def |\ndef |\nclass )',
            src, re.DOTALL)
        func_body = m.group(0)
        self.assertIn("event.sender_id", func_body,
                      "handler must use event.sender_id (sync)")
        self.assertIn("event.chat_id", func_body,
                      "handler must use event.chat_id (sync)")

    def test_handler_uses_cached_userbot_id(self):
        """For outgoing check, the handler must use _userbot_id not get_me()."""
        with open(_SRC) as f:
            src = f.read()
        import re
        m = re.search(
            r'async def _vc_handle_vc_command\(event\).*?(?=\nasync def |\ndef |\nclass )',
            src, re.DOTALL)
        func_body = m.group(0)
        self.assertIn("_userbot_id", func_body,
                      "handler must use cached _userbot_id for outgoing check")

    def test_dedup_has_timeout(self):
        """The dedup check must have a bounded timeout (not block indefinitely)."""
        with open(_SRC) as f:
            src = f.read()
        import re
        m = re.search(
            r'async def _vc_handle_vc_command\(event\).*?(?=\nasync def |\ndef |\nclass )',
            src, re.DOTALL)
        func_body = m.group(0)
        self.assertIn("asyncio.wait_for", func_body,
                      "dedup check must be wrapped in wait_for with timeout")
        self.assertIn("timeout=2.0", func_body,
                      "dedup timeout must be 2s")


class TestCallIdZeroRejection(unittest.TestCase):
    """§9: call_id=0 must be rejected BEFORE attempting PyTgCalls join."""

    def test_call_id_zero_check_before_join(self):
        """The Join-All worker must check call_id=0 before the join block."""
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_TARGET_SKIP_NO_CALL", src,
                      "call_id=0 check must log VC_JOIN_ALL_TARGET_SKIP_NO_CALL")
        self.assertIn("no_active_call_id_zero", src,
                      "call_id=0 result must set no_active_call_id_zero")


class TestNoActiveCallSuppression(unittest.TestCase):
    """§10: NO_ACTIVE_CALL verification must be suppressed after first occurrence."""

    def test_cooldown_dict_exists(self):
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("_vc_no_active_call_cooldowns", src,
                      "NO_ACTIVE_CALL cooldown dict must exist")
        self.assertIn("_VC_NO_ACTIVE_CALL_COOLDOWN_SECONDS", src,
                      "cooldown constant must exist")

    def test_cooldown_recorded_on_no_active_call(self):
        """When call_info is None, the cooldown must be recorded."""
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("_vc_no_active_call_cooldowns[int(chat_id)] = time.monotonic()", src,
                      "cooldown must be recorded when no_active_call detected")

    def test_cooldown_checked_before_verify(self):
        """verify_vc_participant must check the cooldown before doing RPCs."""
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("no_active_call_suppressed", src,
                      "verify must return no_active_call_suppressed when on cooldown")
        self.assertIn("VC_PARTICIPANT_VERIFY_SKIP", src,
                      "verify must log VC_PARTICIPANT_VERIFY_SKIP when suppressed")


class TestFloodWaitPreserved(unittest.TestCase):
    """§7/§14: FloodWait protection must remain."""

    def test_global_floodwait_still_present(self):
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)
        self.assertIn("JOIN_ALL_BREAKER", src)
        self.assertIn("vc_is_global_floodwait_active", src)


class TestInterdcCallPreserved(unittest.TestCase):
    """§13: InterdcCall classification must be preserved."""

    def test_interdc_still_classified(self):
        with open(_SRC) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)
        self.assertIn("VC_JOIN_ALL_TARGET_INTERDC", src)


class TestNoAwaitOnSyncFunction(unittest.TestCase):
    """§6: the v97.61 TypeError fix must still hold."""

    def test_no_await_on_sync_release(self):
        with open(_SRC) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src,
                         "await _vc_release_target_inflight must be removed")


if __name__ == "__main__":
    unittest.main(verbosity=2)
