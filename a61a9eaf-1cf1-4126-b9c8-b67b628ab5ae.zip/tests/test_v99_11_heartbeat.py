"""v99.11 — HEARTBEAT REGRESSION SUITE (the RC-2 / P0-1 fix).

Production evidence (2026-09-21 bot-diagnostic.log.5/.4/.3/(1).2 —
10:16→12:50, 4×5MB rotated logs): ZERO ``BOT_HEARTBEAT`` lines, ZERO
``MEM_CENSUS`` lines.  Root cause: v99.10 handlers.py:2615-2628 called
``logger.info`` with a format string carrying FIVE ``%`` placeholders
(``%.0f`` uptime, ``%s`` pid, ``%s%s%s`` sections) against only FOUR
arguments.  Python's logging formats lazily AT HANDLER level, so the
record was silently DROPPED ("--- Logging error ---" → stderr only —
not in the diagnostic log), and NO exception escaped into the loop's
``except`` (which would at least have logged "heartbeat loop error").
The bot's single most important observability stream was dead for the
entire OOM approach.

FIX UNDER TEST: the payload is now pre-formatted by the pure, guarded
``_bot_heartbeat_census_line`` helper and emitted via exactly
``logger.info("BOT_HEARTBEAT %s", line)`` — one placeholder, one
argument, structurally impossible to mismatch.  Every metric degrades
individually to ``unknown``; the helper never raises, never returns
empty; telemetry failure can neither kill nor disable the heartbeat.
"""

from __future__ import annotations

import ast
import logging
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import handlers  # noqa: E402
from mediagrab_bot.vc_resources import ResourceSnapshot  # noqa: E402

SRC = (Path(__file__).resolve().parents[1]
       / "mediagrab_bot" / "handlers.py").read_text(encoding="utf-8")


class TestSourceContract(unittest.TestCase):
    """The emission call must be single-%s — structurally mismatch-proof."""

    def test_t1_exactly_one_placeholder_one_argument(self):
        tree = ast.parse(SRC)
        found = 0
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if not (isinstance(func, ast.Attribute)
                    and func.attr == "info"):
                continue
            if not node.args:
                continue
            first = node.args[0]
            if not (isinstance(first, ast.Constant)
                    and isinstance(first.value, str)
                    and first.value.startswith("BOT_HEARTBEAT ")):
                continue
            found += 1
            self.assertEqual(
                first.value, "BOT_HEARTBEAT %s",
                "the BOT_HEARTBEAT format string must be exactly "
                "'BOT_HEARTBEAT %s' (single placeholder)")
            self.assertEqual(
                len(node.args), 2,
                "exactly one message argument after the format string")
            self.assertEqual(
                len(node.keywords), 0, "no keyword args on the emission")
        self.assertEqual(found, 1, "exactly one BOT_HEARTBEAT logger.info")

    def test_t1b_v9910_bug_shape_is_gone(self):
        # The v99.10 call had 'BOT_HEARTBEAT uptime=%.0fs pid=%s ...%s%s%s)'
        for fragment in (
            '"BOT_HEARTBEAT uptime=%.0fs pid=%s',
            ";%s%s%s)",
        ):
            self.assertNotIn(fragment, SRC,
                             f"v99.10 broken fragment still present: {fragment}")

    def test_t1c_census_helper_exists(self):
        self.assertIn("def _bot_heartbeat_census_line(", SRC)
        self.assertIn("def _v9911_hb_field(", SRC)

    def test_t1d_counter_sources_present(self):
        self.assertIn("_vc_active_join_backends_by_chat", SRC)
        self.assertIn("_vc_in_flight_joins", SRC)
        self.assertIn('"progress"', SRC)

    def test_t1e_legacy_contracts_preserved(self):
        # v99.10 FIX-D MEM_CENSUS contract (the v99.10 suite asserts these).
        self.assertIn("MEM_CENSUS rss_mb=%.0f threads=%d", SRC)
        self.assertIn("_vc_resource_pressure_state", SRC)
        self.assertIn("FD_CENSUS total=%d soft=%d", SRC)
        self.assertIn("TASK_POPULATION total=%d", SRC)
        self.assertIn("ACCOUNT_HEALTH", SRC)


class TestCensusLine(unittest.TestCase):
    """The pure helper: required fields, order, degradation."""

    def _snap(self):
        return ResourceSnapshot(
            pid=4242, rss_mb=123.4, threads=17, fd_count=42, fd_limit=1024,
            joined_transports=5, active_joins=1, queued_joins=3,
            available_memory_mb=300.0, memory_limit_mb=512.0,
        )

    def test_t2_all_required_fields_with_values_in_order(self):
        line = handlers._bot_heartbeat_census_line(
            uptime=987.5, snapshot=self._snap(),
            joined_transports=5, active_joins=1, join_queue=3,
            population_txt=" TASK_POPULATION total=99 ",
            fd_txt="FD_CENSUS total=42 soft=1024 sockets=3",
            mem_txt="MEM_CENSUS rss_mb=123 threads=17",
            acct_txt="joins=acc1:J=5/F=0",
        )
        required = [
            "pid=", "uptime=988s", "rss_mb=123", "threads=17", "fd=42/1024",
            "joined_transports=5", "join_queue=3", "active_joins=1",
            "memory_limit_mb=512", "resource_headroom_mb=389",
        ]
        pos = -1
        for frag in required:
            idx = line.find(frag)
            self.assertGreater(
                idx, pos,
                f"field {frag!r} missing or out of order in: {line}")
            pos = idx
        self.assertIn("TASK_POPULATION", line)
        self.assertIn("FD_CENSUS", line)
        self.assertIn("MEM_CENSUS", line)
        self.assertIn("v99.11", line)
        self.assertNotIn("\n", line)

    def test_t3_all_unknown_snapshot_and_broken_sources(self):
        class _Broken:
            @property
            def rss_mb(self):
                raise RuntimeError("boom")

            @property
            def threads(self):
                raise RuntimeError("boom")

            @property
            def fd_count(self):
                raise RuntimeError("boom")

            @property
            def fd_limit(self):
                raise RuntimeError("boom")

            @property
            def memory_limit_mb(self):
                raise RuntimeError("boom")

            @property
            def resource_headroom_mb(self):
                raise RuntimeError("boom")

        class _BrokenSection:
            def __str__(self):
                raise RuntimeError("boom section")

        line = handlers._bot_heartbeat_census_line(
            uptime="not-a-number", snapshot=_Broken(),
            joined_transports=None, active_joins=None, join_queue=None,
            population_txt="", fd_txt=_BrokenSection(),
            mem_txt="MEM_CENSUS rss_mb=%.0f" % (1 / 0 + 1,) if False else "",
            acct_txt="",
        )
        for frag in ("pid=", "uptime=unknown", "rss_mb=unknown",
                     "threads=unknown", "fd=unknown/unknown",
                     "joined_transports=unknown", "join_queue=unknown",
                     "active_joins=unknown", "memory_limit_mb=unknown",
                     "resource_headroom_mb=unknown"):
            self.assertIn(frag, line)

    def test_t3b_none_snapshot_degrades_not_raises(self):
        line = handlers._bot_heartbeat_census_line(
            uptime=5, snapshot=None, joined_transports=2,
            active_joins=0, join_queue=0)
        self.assertIsInstance(line, str)
        self.assertTrue(line)
        self.assertIn("joined_transports=2", line)

    def test_t4_broken_collect_degrades(self):
        import mediagrab_bot.vc_resources as vr
        orig = vr.collect_resource_snapshot
        def _boom(**kwargs):
            raise RuntimeError("telemetry dead")
        vr.collect_resource_snapshot = _boom
        try:
            # snapshot=None triggers the internal fallback collect — which
            # is monkeypatched to raise; the helper must still return a
            # full line with unknowns.
            line = handlers._bot_heartbeat_census_line(
                uptime=1, snapshot=None, joined_transports=1,
                active_joins=0, join_queue=0)
            self.assertIn("rss_mb=unknown", line)
            self.assertIn("joined_transports=1", line)
        finally:
            vr.collect_resource_snapshot = orig


class TestHandlerEmission(unittest.TestCase):
    """Prove the fixed line actually REACHES handlers (the v99.10
    failure mode was: record dropped at handler level)."""

    def test_t5_fixed_emission_reaches_handler(self):
        class _Capture(logging.Handler):
            def __init__(self):
                super().__init__()
                self.records = []

            def emit(self, record):
                try:
                    self.format(record)
                    self.records.append(record)
                except Exception:  # noqa: BLE001
                    self.handleError(record)

        cap = _Capture()
        lg = logging.getLogger("mediagrab.test_v9911_hb")
        lg.setLevel(logging.INFO)
        lg.propagate = False  # keep pytest's capture out of the broken-record test
        lg.addHandler(cap)
        try:
            line = handlers._bot_heartbeat_census_line(
                uptime=42, snapshot=self._snap(), joined_transports=2,
                active_joins=1, join_queue=7)
            lg.info("BOT_HEARTBEAT %s", line)
            self.assertEqual(len(cap.records), 1)
            formatted = cap.records[0].getMessage()
            self.assertTrue(formatted.startswith("BOT_HEARTBEAT "))
            self.assertIn("rss_mb=123", formatted)
        finally:
            lg.removeHandler(cap)

    def test_t5b_v9910_bug_reproduced_and_contrasted(self):
        """The EXACT v99.10 call shape drops the record at handler level
        (no exception escapes) — pinning the failure mechanism so it can
        never silently return."""
        class _Capture(logging.Handler):
            """Mimics StreamHandler: formats INSIDE emit, so a
            format/arg mismatch drops the record via handleError."""

            def __init__(self):
                super().__init__()
                self.records = []
                self.errors = 0

            def emit(self, record):
                try:
                    self.format(record)  # getMessage() — where it breaks
                    self.records.append(record)
                except Exception:  # noqa: BLE001
                    self.handleError(record)

            def handleError(self, record):
                self.errors += 1

        cap = _Capture()
        lg = logging.getLogger("mediagrab.test_v9911_hb2")
        lg.setLevel(logging.INFO)
        lg.propagate = False
        lg.addHandler(cap)
        try:
            # v99.10 shape: 5 placeholders, 4 args.
            lg.info(
                "BOT_HEARTBEAT uptime=%.0fs pid=%s (…;%s%s%s)",
                42.0, 4242, "acct", ("pop" + "fd" + "mem"),
            )
            self.assertEqual(len(cap.records), 0, "v99.10 shape must DROP")
            self.assertEqual(cap.errors, 1)
            # v99.11 shape: single %s — delivered.
            lg.info("BOT_HEARTBEAT %s", "pid=1 uptime=2s")
            self.assertEqual(len(cap.records), 1)
        finally:
            lg.removeHandler(cap)

    @staticmethod
    def _snap():
        return ResourceSnapshot(
            pid=4242, rss_mb=123.4, threads=17, fd_count=42, fd_limit=1024,
            joined_transports=5, active_joins=1, queued_joins=3,
            available_memory_mb=300.0, memory_limit_mb=512.0,
        )


class TestResourceSnapshotFields(unittest.TestCase):
    """The snapshot abstraction powering the head fields."""

    def test_s1_headroom_computed(self):
        snap = ResourceSnapshot(rss_mb=100.0, memory_limit_mb=512.0)
        self.assertAlmostEqual(snap.resource_headroom_mb, 412.0)

    def test_s2_headroom_unknown_when_limit_unknown(self):
        snap = ResourceSnapshot(rss_mb=100.0)
        self.assertIsNone(snap.resource_headroom_mb)
        snap2 = ResourceSnapshot(available_memory_mb=64.0)
        self.assertAlmostEqual(snap2.resource_headroom_mb, 64.0)

    def test_s3_collect_never_raises(self):
        from mediagrab_bot.vc_resources import collect_resource_snapshot
        snap = collect_resource_snapshot(
            joined_transports=1, active_joins=0, queued_joins=0)
        # Duck-type contract: the v99.10 suite's purge-reload loader can
        # create a second module instance, so CLASS IDENTITY is not
        # stable across suites — the field contract is.
        self.assertEqual(type(snap).__name__, "ResourceSnapshot")
        for attr in ("rss_mb", "threads", "fd_count", "fd_limit",
                     "available_memory_mb", "memory_limit_mb",
                     "resource_headroom_mb"):
            self.assertTrue(hasattr(snap, attr), f"missing field {attr}")
        self.assertEqual(snap.joined_transports, 1)
        self.assertGreater(snap.pid, 0)


if __name__ == "__main__":
    unittest.main()
