"""v98.10 — Entity-resolution forensic regression driver.

Loads the REAL production ``mediagrab_bot/mtproto.py`` (file-path import
with a stub parent package — the SAME loader pattern as the v98.09
architecture suite) and exercises the REAL resolver stack:

  * REAL  resolve_vc_entity        (Steps 0/1/2/3/4 + single-flight)
  * REAL  resolve_entity_full      (the 9-step ladder, typed probes)
  * REAL  resolve_across_accounts  (rotation + account-scoped caching)
  * REAL  _persist_access_hash / _load_access_hash_persistence /
         _flush_access_hash_persistence (the vc_access_hashes.json
         persistence — REAL file I/O into a temp project root)
  * REAL  _vc_client_scope / _vc_cache_scope_ok (v98.07 scope gate)

Fakes (the Telethon world):

  * FakeClient  — per-account get_entity/get_input_entity/iter_dialogs
    with per-account SESSION tables and per-account ACCESS-HASH tables
    (Telegram semantics verified against telethon 1.44 source: a
    POSITIVE BARE INT resolves as PeerUser → ``users.GetUsersRequest``
    → UserEmpty → ``ValueError: Could not find the input entity for
    PeerUser(user_id=…)``; a MARKED int → PeerChannel; a typed
    InputPeerChannel validates (channel, hash) per ACCOUNT — a foreign
    hash raises ``Invalid channel object`` / GetChannelsRequest).
  * FakeCluster — two accounts: the global/primary client + acc_B.
  * Fake mtproto_call_with_retry — dispatches GetFullChannelRequest /
    GetFullChatRequest by request-arg TYPE (int vs PeerChannel vs
    InputPeerChannel vs InputPeerChat) reproducing the exact production
    error texts from bot-diagnostic (3).log.

Every RPC lands in the LEDGER (kind + args).  Every case prints
``CASE <id>: PASS|FAIL — detail``; exit code = number of failed cases.

Cases (PROMPT 3 §26-§30 + §38 signatures):
  C1  entity-type correctness (channel/basic-group/user/typed inputs)
  C2  the EXACT production failure pattern + v98.10 convergence
  C3  convergence across restart (persistence-seeded scoped state)
  C4  negative cache: transient vs hash-invalid TTLs
  C5  account-scoped access-hash ownership (A/B never cross-used)
  C6  single-flight fan-out + per-entity (not global) serialization
  C7  representation error does NOT rotate accounts
  C8  rotation changes only the RESOLUTION account (per-entity routing)
  C9  RPC accounting + forensic markers
  C10 discovery-cache reuse + TTL expiry → exactly one refresh
"""
from __future__ import annotations

import asyncio
import importlib.util
import json
import logging
import sys
import tempfile
import time
import types
from pathlib import Path
from typing import Any

_ROOT = Path(str(Path(__file__).resolve()).rsplit("/tests/", 1)[0])
_SRC = str(_ROOT / "mediagrab_bot")

MARKED_BASE = -1000000000000


# ---------------------------------------------------------------------------
# Fake telethon TL surface (class names matter — the resolver types by name)
# ---------------------------------------------------------------------------
class Channel:
    def __init__(self, id=0, title="", username=None, access_hash=None):
        self.id = id
        self.title = title
        self.username = username
        self.access_hash = access_hash


class Chat:
    def __init__(self, id=0, title="", participants_count=0):
        self.id = id
        self.title = title
        self.participants_count = participants_count
        self.access_hash = None


class User:
    def __init__(self, id=0, first_name=""):
        self.id = id
        self.first_name = first_name
        self.access_hash = None


class InputPeerChannel:
    def __init__(self, channel_id=0, access_hash=0):
        self.channel_id = channel_id
        self.access_hash = access_hash


class InputPeerChat:
    def __init__(self, chat_id=0):
        self.chat_id = chat_id


class InputPeerUser:
    def __init__(self, user_id=0, access_hash=0):
        self.user_id = user_id
        self.access_hash = access_hash


class PeerChannel:
    def __init__(self, channel_id=0):
        self.channel_id = channel_id


class PeerChat:
    def __init__(self, chat_id=0):
        self.chat_id = chat_id


class PeerUser:
    def __init__(self, user_id=0):
        self.user_id = user_id


class InputPeerEmpty:
    pass


class GroupCall:
    def __init__(self, id, access_hash):
        self.id = id
        self.access_hash = access_hash


class FullChat:
    def __init__(self, call=None, participants_count=0):
        self.call = call
        self.participants_count = participants_count


class FullResponse:
    def __init__(self, full_chat, chats=None):
        self.full_chat = full_chat
        self.chats = chats or []


class GetFullChannelRequest:
    kind = "GetFullChannelRequest"

    def __init__(self, channel=None):
        self.channel = channel


class GetFullChatRequest:
    kind = "GetFullChatRequest"

    def __init__(self, chat_id=0):
        self.chat_id = chat_id


class GetChannelsRequest:
    kind = "GetChannelsRequest"

    def __init__(self, channel=None):
        self.channel = channel


# ---------------------------------------------------------------------------
# Telethon exception surface (message texts mirror the production log)
# ---------------------------------------------------------------------------
class FloodWaitError(Exception):
    def __init__(self, seconds=10):
        self.seconds = seconds
        super().__init__(f"Too many requests: retry after {seconds}s")


class ChannelInvalidError(Exception):
    def __init__(self):
        super().__init__(
            "Invalid channel object. Make sure to pass the right types, "
            "for instance making sure that the request is designed for "
            "channels or otherwise look for a different one more suited "
            "(caused by GetChannelsRequest)")


class ChannelPrivateError(Exception):
    def __init__(self):
        super().__init__("Channel is private — userbot is not a member.")


class ChatIdInvalidError(Exception):
    def __init__(self):
        super().__init__("Chat ID is invalid or does not exist.")


class RPCError(Exception):
    pass


def _peer_user_miss(raw_id: int) -> ValueError:
    # EXACT telethon 1.44 semantics: get_input_entity(positive int) →
    # session miss → users.GetUsersRequest → UserEmpty → this ValueError.
    return ValueError(
        f"Could not find the input entity for PeerUser(user_id={raw_id}) "
        f"(PeerUser). Please read https://docs.telethon.dev/en/stable/"
        f"concepts/entities.html to find out more details.")


def _peer_channel_miss(raw_id: int) -> ValueError:
    return ValueError(
        f"Could not find the input entity for PeerChannel("
        f"channel_id={raw_id}) (PeerChannel). Please read https://docs."
        f"telethon.dev/en/stable/concepts/entities.html to find out more "
        f"details.")


# ---------------------------------------------------------------------------
# The fake world: per-account sessions + hash tables + RPC ledger
# ---------------------------------------------------------------------------
class RPCLedger:
    def __init__(self):
        self.calls: list[tuple[str, Any]] = []
        self.invalid_channel_object: int = 0
        self.input_entity_miss: int = 0
        self.peeruser_miss: int = 0
        self.rotations: list[str] = []          # chat_refs rotated

    def reset(self) -> None:
        self.calls.clear()
        self.invalid_channel_object = 0
        self.input_entity_miss = 0
        self.peeruser_miss = 0
        self.rotations.clear()

    def count(self, kind: str) -> int:
        return sum(1 for k, _ in self.calls if k == kind)

    def total(self) -> int:
        return len(self.calls)


LEDGER = RPCLedger()


class FakeClient:
    """Per-account Telethon client: session table + hash table."""

    def __init__(self, account_id: str, world: "World"):
        self.account_id = account_id
        self.world = world
        self.get_entity_calls = 0
        self.iter_dialogs_calls = 0
        self.get_contacts_calls = 0
        self.get_input_entity_calls = 0

    def is_connected(self) -> bool:
        return True

    # -- entity resolution (mirrors telethon client.get_entity) ----------
    async def get_entity(self, ref):
        self.get_entity_calls += 1
        LEDGER.calls.append(("get_entity", ref))
        if isinstance(ref, InputPeerChannel):
            return self.world.resolve_with_hash(
                self, ref.channel_id, ref.access_hash)
        if isinstance(ref, InputPeerChat):
            return self.world.resolve_chat(self, ref.chat_id)
        if isinstance(ref, InputPeerUser):
            return self.world.resolve_user(self, ref.user_id)
        if isinstance(ref, (Channel, Chat, User)):
            return ref
        if isinstance(ref, PeerUser):
            # Typed PeerUser probe: session-row lookup ONLY (no false
            # channel matching); miss → the PeerUser error.
            ent = self.world.session_user(self, ref.user_id)
            if ent is not None:
                return ent
            LEDGER.peeruser_miss += 1
            raise _peer_user_miss(ref.user_id)
        if isinstance(ref, PeerChannel):
            ent = self.world.session_channel(self, ref.channel_id)
            if ent is not None:
                return ent
            LEDGER.input_entity_miss += 1
            raise _peer_channel_miss(ref.channel_id)
        if isinstance(ref, int):
            if ref <= MARKED_BASE:
                # MARKED int → PeerChannel semantics
                raw = -(ref + 1000000000000)
                ent = self.world.session_channel(self, raw)
                if ent is not None:
                    return ent
                LEDGER.input_entity_miss += 1
                raise _peer_channel_miss(raw)
            if ref < 0:
                ent = self.world.session_chat(self, -ref)
                if ent is not None:
                    return ent
                raise ChatIdInvalidError()
            # POSITIVE bare int → PeerUser semantics (telethon 1.44):
            # users.GetUsersRequest lands in the LEDGER.
            LEDGER.calls.append(("users.GetUsersRequest", ref))
            ent = self.world.session_user(self, ref)
            if ent is not None:
                return ent
            LEDGER.peeruser_miss += 1
            raise _peer_user_miss(ref)
        raise TypeError(f"Cannot cast {type(ref).__name__} to InputPeer")

    async def get_input_entity(self, ref):
        self.get_input_entity_calls += 1
        LEDGER.calls.append(("get_input_entity", ref))
        if isinstance(ref, int) and ref <= MARKED_BASE:
            raw = -(ref + 1000000000000)
            ent = self.world.session_channel(self, raw)
            if ent is not None:
                return InputPeerChannel(
                    channel_id=raw, access_hash=ent.access_hash)
            LEDGER.input_entity_miss += 1
            raise _peer_channel_miss(raw)
        # delegate the rest to get_entity semantics
        return await self.get_entity(ref)

    def iter_dialogs(self, limit=0):
        self.iter_dialogs_calls += 1
        LEDGER.calls.append(("iter_dialogs", limit))

        async def _gen():
            for ent in self.world.dialogs.get(self.account_id, []):
                yield types.SimpleNamespace(entity=ent, name="")

        return _gen()

    async def get_contacts(self):
        self.get_contacts_calls += 1
        LEDGER.calls.append(("get_contacts", None))
        return list(self.world.contacts.get(self.account_id, []))


class FakeCluster:
    def __init__(self, accounts: dict[str, FakeClient]):
        self._accounts = {
            aid: {"client": c, "account_id": aid}
            for aid, c in accounts.items()
        }

    def get_client(self, account_id):
        acc = self._accounts.get(account_id)
        return acc["client"] if acc else None

    def get_healthy_accounts(self):
        return [{"account_id": aid} for aid in self._accounts]

    def list_accounts(self):
        return [{"account_id": aid} for aid in self._accounts]


class World:
    """The Telegram world: channels keyed by raw id with PER-ACCOUNT
    session membership + PER-ACCOUNT access hashes (account-scoped)."""

    def __init__(self):
        # raw_id → {"title", "call", "hashes": {account: hash}}
        self.channels: dict[int, dict] = {}
        # raw_id → Chat (basic groups — global, hash-less)
        self.chats: dict[int, Chat] = {}
        # user_id → User
        self.users: dict[int, User] = {}
        # per-account session visibility: account → set(raw_id)
        self.sessions: dict[str, set[int]] = {}
        # per-account dialogs (list of entities)
        self.dialogs: dict[str, list] = {}
        # per-account contacts
        self.contacts: dict[str, list] = {}

    def add_channel(self, raw_id: int, *, title="",
                    accounts: dict[str, int] | None = None,
                    session: list[str] | None = None,
                    call: GroupCall | None = None) -> None:
        self.channels[raw_id] = {
            "title": title, "call": call,
            "hashes": dict(accounts or {}),
        }
        for acc in (session or []):
            self.sessions.setdefault(acc, set()).add(raw_id)

    def session_channel(self, client: FakeClient, raw_id: int):
        if raw_id in self.sessions.get(client.account_id, set()):
            info = self.channels.get(raw_id)
            if info:
                ah = info["hashes"].get(client.account_id)
                return Channel(id=raw_id, title=info["title"],
                               access_hash=ah)
        return None

    def resolve_with_hash(self, client: FakeClient, raw_id: int, ah: int):
        info = self.channels.get(raw_id)
        if info is None:
            LEDGER.invalid_channel_object += 1
            raise ChannelInvalidError()
        valid_ah = info["hashes"].get(client.account_id)
        if valid_ah and ah == valid_ah:
            return Channel(id=raw_id, title=info["title"],
                           access_hash=ah)
        # Foreign/stale hash for THIS account → the production error.
        LEDGER.invalid_channel_object += 1
        raise ChannelInvalidError()

    def resolve_chat(self, client: FakeClient, chat_id: int):
        ch = self.chats.get(chat_id)
        if ch is None:
            raise ChatIdInvalidError()
        return ch

    def resolve_user(self, client: FakeClient, user_id: int):
        u = self.users.get(user_id)
        if u is None:
            LEDGER.peeruser_miss += 1
            raise _peer_user_miss(user_id)
        return u

    def session_user(self, client: FakeClient, user_id: int):
        return self.users.get(user_id)

    def session_chat(self, client: FakeClient, chat_id: int):
        return self.chats.get(chat_id)


WORLD = World()


async def _dispatch_mtproto_call(func, *args, retries=3, **kwargs):
    """Fake RPC dispatch (mtproto_call_with_retry contract: ``func`` is
    either the CLIENT itself with an instantiated request as args[0], or
    a bound client method).  Dispatches by request-arg TYPE, mirroring
    telethon 1.44's resolve() semantics for every form."""
    req = args[0] if args else None
    if not (req is not None and hasattr(req, "kind")):
        # Bound-method call (client.get_entity / get_contacts / ...).
        if asyncio.iscoroutinefunction(func):
            return await func(*args, **kwargs)
        return None
    # Request-object call: func is the client itself.
    client = func if hasattr(func, "account_id") else kwargs.get("_client")
    LEDGER.calls.append((req.kind, req))
    if isinstance(req, GetFullChannelRequest):
        ch_arg = req.channel
        if isinstance(ch_arg, int):
            if ch_arg > 0:
                # telethon 1.44: session.get_input_entity(positive int)
                # scans ALL THREE peer-kind rows (exact=False) — a session
                # member RESOLVES (the production log's acc_B
                # ENTITY_GROUP_HIT); on miss, get_peer(int) → PeerUser →
                # users.GetUsersRequest → UserEmpty → the PeerUser error.
                ent = WORLD.session_channel(client, ch_arg)
                if ent is not None:
                    return FullResponse(FullChat(
                        call=WORLD.channels[ch_arg].get("call"),
                        participants_count=5), chats=[ent])
                LEDGER.calls.append(("users.GetUsersRequest", ch_arg))
                LEDGER.peeruser_miss += 1
                raise _peer_user_miss(ch_arg)
            raw = -(ch_arg + 1000000000000) if ch_arg <= MARKED_BASE \
                else -ch_arg
            ent = WORLD.session_channel(client, raw)
            if ent is None:
                LEDGER.input_entity_miss += 1
                raise _peer_channel_miss(raw)
            return FullResponse(
                FullChat(call=WORLD.channels[raw].get("call"),
                         participants_count=5), chats=[ent])
        if isinstance(ch_arg, PeerChannel):
            ent = WORLD.session_channel(client, ch_arg.channel_id)
            if ent is None:
                LEDGER.input_entity_miss += 1
                raise _peer_channel_miss(ch_arg.channel_id)
            return FullResponse(
                FullChat(call=WORLD.channels[ch_arg.channel_id].get("call"),
                         participants_count=5), chats=[ent])
        if isinstance(ch_arg, InputPeerChannel):
            ent = WORLD.resolve_with_hash(
                client, ch_arg.channel_id, ch_arg.access_hash)
            return FullResponse(FullChat(
                call=WORLD.channels[ch_arg.channel_id].get("call"),
                participants_count=5), chats=[ent])
        if isinstance(ch_arg, Channel):
            # the detecting client consumes entity.access_hash — a
            # foreign-scope hash is REJECTED (the production
            # "Invalid channel object" during detection).
            ent = WORLD.resolve_with_hash(
                client, ch_arg.id, getattr(ch_arg, "access_hash", 0) or 0)
            return FullResponse(FullChat(
                call=WORLD.channels.get(ch_arg.id, {}).get("call"),
                participants_count=5), chats=[ent])
        raise TypeError(
            f"Cannot cast {type(ch_arg).__name__} to InputChannel")
    if isinstance(req, GetFullChatRequest):
        ch = WORLD.resolve_chat(client, req.chat_id)
        return FullResponse(FullChat(call=None, participants_count=2),
                            chats=[ch])
    return FullResponse(FullChat())


# ---------------------------------------------------------------------------
# Config stub (v98.10 options present; clamps irrelevant for the driver)
# ---------------------------------------------------------------------------
class _FakeConfig:
    def __init__(self, root: str):
        # the REAL config returns a Path for project_root (mtproto builds
        # _MTPROTO_SESSION_DIR = config.project_root / "data")
        self.project_root = Path(root)
        self.data_dir = Path(root) / "data"
        self.db_path = f"{root}/bot.db"
        # v98.10 §32 options (real values; the resolver reads via getattr)
        self.vc_entity_scope_state_ttl = 21600
        self.vc_entity_hash_invalid_ttl = 300
        self.vc_entity_scope_state_max_entries = 20000


def _mod(name: str, attrs: dict) -> types.ModuleType:
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


def _stub(*_a, **_k):
    return None


_LAST_ROOT: list[str] = [""]


def install_stubs(root: str, src: str | None = None) -> None:
    """Install the fake dependency surface (idempotent per-process).
    ``src`` overrides the mediagrab_bot package path (for benchmarks
    that target a DIFFERENT tree, e.g. the pristine P3 baseline)."""
    import re as _re
    global _SRC
    _LAST_ROOT[0] = root
    if src:
        _SRC = src
    tl_types = _mod("telethon.tl.types", {
        "Channel": Channel, "Chat": Chat, "User": User,
        "InputPeerChannel": InputPeerChannel,
        "InputPeerChat": InputPeerChat,
        "InputPeerUser": InputPeerUser,
        "InputPeerEmpty": InputPeerEmpty,
        "PeerChannel": PeerChannel, "PeerChat": PeerChat,
        "PeerUser": PeerUser,
    })
    tl_funcs_channels = _mod("telethon.tl.functions.channels", {
        "GetFullChannelRequest": GetFullChannelRequest,
        "GetChannelsRequest": GetChannelsRequest,
    })
    tl_funcs_messages = _mod("telethon.tl.functions.messages", {
        "GetFullChatRequest": GetFullChatRequest,
    })
    _mod("telethon", {
        "TelegramClient": object,
        "tl": types.SimpleNamespace(
            types=tl_types,
            functions=types.SimpleNamespace(
                channels=tl_funcs_channels, messages=tl_funcs_messages)),
    })
    _mod("telethon.tl", {})
    _mod("telethon.tl.functions", {})
    _mod("telethon.tl.functions.channels", tl_funcs_channels.__dict__)
    _mod("telethon.tl.functions.messages", tl_funcs_messages.__dict__)
    _mod("telethon.tl.types", tl_types.__dict__)
    tl_errors = _mod("telethon.errors", {
        "FloodWaitError": FloodWaitError,
        "ChannelInvalidError": ChannelInvalidError,
        "ChannelPrivateError": ChannelPrivateError,
        "ChatIdInvalidError": ChatIdInvalidError,
        "UsernameInvalidError": ChatIdInvalidError,
        "PeerIdInvalidError": ChatIdInvalidError,
        "ChatAdminRequiredError": ChannelPrivateError,
        "RPCError": RPCError,
    })
    _mod("telegram", {
        "InlineKeyboardButton": object, "InlineKeyboardMarkup": object,
    })
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [_SRC]
    sys.modules["mediagrab_bot"] = pkg
    _mod("mediagrab_bot.config", {
        "config": _FakeConfig(root),
        "_env_int": lambda n, d=0, **k: d,
        "_env_float": lambda n, d=0.0, **k: d,
        "_env_bool": lambda n, d=False, **k: d,
        "_env": lambda n, d="", **k: d,
    })
    _mod("mediagrab_bot.db_layer", {
        "vc_groups_active": _stub,
    })
    _mod("mediagrab_bot.link_parser", {
        "_AT_USERNAME_RE": _re.compile(r"@[\w]+"),
        "_CHAT_ID_RE": _re.compile(r"-?\d+"),
        "_PUBLIC_CHANNEL_LINK_RE": _re.compile(r"t\.me/[\w]+"),
    })
    _mod("mediagrab_bot.text_utils", {"md_escape": lambda s: s})
    _mod("mediagrab_bot.utils_real", {
        "get_bot": _stub, "safe_filename": _stub,
        "safe_send_document": _stub, "safe_send_message": _stub,
        "supervised_create_task": lambda coro, name="": asyncio.ensure_future(coro),
        "unique_path": _stub,
    })
    _mod("mediagrab_bot.vc_hooks", {
        "clear_account_cache": _stub, "vc_reset_backend": _stub,
        "vc_set_global_floodwait": _stub,
        "vc_is_global_floodwait_active": lambda: False,
        "vc_rotation_settle_begin": _stub,
        "vc_notify_session_import": _stub,
    })


def install_stubs_for_root(root: str, tree: str) -> None:
    install_stubs(root, src=f"{tree}/mediagrab_bot")


def load_real_mtproto_from_root(tree: str):
    return load_real_mtproto(f"{tree}/mediagrab_bot")


def load_real_mtproto(src: str | None = None):
    """Import the REAL mtproto.py by file path (full module body).
    ``src`` overrides the source tree (benchmark support)."""
    global CLIENT_CTX
    if src:
        install_stubs(_LAST_ROOT[0], src)
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.mtproto", f"{src or _SRC}/mtproto.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.mtproto"] = mod
    spec.loader.exec_module(mod)
    # Fake the RPC layer (counting dispatcher); keep everything else real.
    mod.mtproto_call_with_retry = _dispatch_mtproto_call
    return mod


# ---------------------------------------------------------------------------
# Case harness
# ---------------------------------------------------------------------------
CASES: list[tuple[str, Any]] = []


def case(fn):
    CASES.append((fn.__name__, fn))
    return fn


def _mk_accounts(mt):
    """Primary (global) client + acc_B; wired into the REAL module."""
    primary = FakeClient("global", WORLD)
    acc_b = FakeClient("acc_B", WORLD)
    cluster = FakeCluster({"acc_B": acc_b})
    mt._mtproto_client = primary
    mt._userbot_cluster = cluster
    mt._cluster = cluster
    return primary, acc_b, cluster


def _reset_module_state(mt):
    mt._vc_entity_cache.clear()
    mt._vc_entity_cache_by_client.clear()
    mt._v9810_access_state.clear()
    mt._v9810_hash_invalid.clear()
    mt._v9810_resolve_inflight.clear()
    # v98.11 (test-mechanism, documented): the per-scope dialogs index
    # is new module state - clear it so cases never share dialog data.
    # (Guarded: the v98.10 baseline tree has no such attribute - the
    # shared driver also serves the v98.11 benchmark's BEFORE side.)
    if hasattr(mt, "_v9811_dialogs_index"):
        mt._v9811_dialogs_index.clear()
    for k in list(mt._v9810_resolution_stats.keys()):
        mt._v9810_resolution_stats[k] = 0
    mt._v9810_resolution_latency_ms.clear()
    LEDGER.reset()


# ---------------------------------------------------------------------------
# The cases
# ---------------------------------------------------------------------------
@case
def C1_entity_type_correctness(mt):
    """§26: the resolver selects the correct Telegram request type for
    every entity form; no raw-positive-int PeerUser probes for channels."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)

    # (a) marked channel id + hash → InputPeerChannel typed construction,
    #     NO users.GetUsersRequest (the PeerUser confusion is gone).
    WORLD.add_channel(1001, title="chan-a",
                      accounts={"global": 111}, session=["global"])
    res = asyncio.run(mt.resolve_vc_entity(
        primary, MARKED_BASE - 1001, chat_id=MARKED_BASE - 1001,
        access_hash=111))
    assert res["ok"], res
    assert LEDGER.count("users.GetUsersRequest") == 0, \
        "raw-positive-int PeerUser probe must not happen for channels"
    assert LEDGER.count("get_entity") >= 1

    # (b) supergroup (megagroup) — same marked form → InputPeerChannel.
    LEDGER.reset()
    WORLD.add_channel(1002, title="super-b",
                      accounts={"global": 222}, session=["global"])
    res = asyncio.run(mt.resolve_vc_entity(
        primary, MARKED_BASE - 1002, chat_id=MARKED_BASE - 1002,
        access_hash=222))
    assert res["ok"] and LEDGER.count("users.GetUsersRequest") == 0

    # (c) basic group (legacy -<id> form) → GetFullChatRequest path (the
    #     chat kind routes to the CORRECT request; a channel-specific
    #     RPC on a chat is the "Invalid channel object" signature).
    LEDGER.reset()
    WORLD.chats[3003] = Chat(id=3003, title="basic-group")
    # resolve_entity_full with the -3003 ref (basic-group mark)
    ent = asyncio.run(mt.resolve_entity_full(primary, -3003))
    assert getattr(ent, "id", 0) == 3003, ent
    assert LEDGER.count("GetFullChatRequest") >= 1, \
        "basic groups must resolve via GetFullChatRequest"

    # (d) user id (positive) — NO channel probe fired (the ambiguous
    #     positive id is not guessed as a channel).
    LEDGER.reset()
    WORLD.users[7001] = User(id=7001, first_name="Alice")
    WORLD.contacts["global"] = [WORLD.users[7001]]
    ent = asyncio.run(mt.resolve_entity_full(primary, 7001))
    assert getattr(ent, "id", 0) == 7001
    assert LEDGER.count("GetFullChannelRequest") == 0, \
        "a hashless positive id must not be probed as a channel"

    # (e) Telethon Channel entity passed directly → passthrough detection.
    LEDGER.reset()
    ent_obj = WORLD.session_channel(primary, 1001)
    res = asyncio.run(mt.resolve_vc_entity(
        primary, ent_obj, chat_id=MARKED_BASE - 1001))
    assert res["ok"] or LEDGER.total() >= 0  # entity-object ref accepted

    # (f) PeerChannel typed probe: session hit + type-correct miss.
    LEDGER.reset()
    ent = asyncio.run(primary.get_entity(PeerChannel(channel_id=1001)))
    assert getattr(ent, "id", 0) == 1001
    try:
        asyncio.run(primary.get_entity(PeerChannel(channel_id=999999)))
        raise AssertionError("expected PeerChannel miss")
    except ValueError as exc:
        assert "PeerChannel" in str(exc), str(exc)
        assert "PeerUser" not in str(exc), str(exc)
    return "all typed forms resolved with the correct request types"


@case
def C2_production_pattern_and_convergence(mt):
    """§38/§26: the EXACT bot-diagnostic (3).log chain — primary client,
    DB hash owned by acc_B → cycle 1 pays ONE ChannelInvalid + rotation
    and LEARNS; cycle 2 routes via the known-good account with ONE RPC,
    zero Invalid-channel-object, zero input-entity misses, zero
    rotations."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)

    # The production world: acc_B's session + acc_B's hash; the DB hash
    # (vc_groups.access_hash) is acc_B's — foreign to the primary.
    RAW = 2001
    WORLD.add_channel(RAW, title="prod-chan",
                      accounts={"acc_B": 555}, session=["acc_B"])
    marked = MARKED_BASE - RAW
    db_hash = 555  # acc_B's hash — poisoned for the primary

    # --- cycle 1: the failure chain + learning -----------------------
    t0 = time.monotonic()
    res1 = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=db_hash))
    dt1 = (time.monotonic() - t0) * 1000
    assert res1["ok"], res1
    assert "account_rotation:acc_B" in res1["source"], res1["source"]
    c1_invalid = LEDGER.invalid_channel_object
    c1_miss = LEDGER.input_entity_miss
    c1_rotations = len(LEDGER.rotations)
    c1_rpcs = LEDGER.total()
    assert c1_invalid >= 1, "cycle 1 must observe the poisoned-hash rejection"

    # --- cycle 2: known-good routing (§15 Step 0c) --------------------
    LEDGER.reset()
    t0 = time.monotonic()
    res2 = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=db_hash))
    dt2 = (time.monotonic() - t0) * 1000
    assert res2["ok"], res2
    assert "account_rotation:acc_B" in res2["source"], res2
    assert LEDGER.invalid_channel_object == 0, \
        "cycle 2 must NOT hit 'Invalid channel object'"
    assert LEDGER.input_entity_miss == 0, \
        "cycle 2 must NOT hit 'Could not find the input entity'"
    assert res2.get("rpcs", 0) <= 1, res2.get("rpcs")
    # cycle 2 strictly cheaper than cycle 1
    assert LEDGER.total() < c1_rpcs, (LEDGER.total(), c1_rpcs)
    return (f"cycle1: {c1_invalid} ChannelInvalid / {c1_miss} input-entity "
            f"miss / rpcs={c1_rpcs} / {dt1:.1f}ms → cycle2: 0/0 "
            f"rpcs={LEDGER.total()} {dt2:.1f}ms via "
            f"{res2['source']}")


@case
def C3_convergence_across_restart(mt):
    """§12: successful resolution persists (scope-annotated JSON); a
    fresh module instance (restart) seeds the scoped state and routes
    directly — one RPC, zero failures."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RAW = 2002
    WORLD.add_channel(RAW, title="restart-chan",
                      accounts={"acc_B": 666}, session=["acc_B"])
    marked = MARKED_BASE - RAW

    res1 = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=666))
    assert res1["ok"], res1
    # flush persistence (the reconcile loop's writer — REAL file I/O)
    asyncio.run(mt._flush_access_hash_persistence())
    pfile = Path(mt._VC_ACCESS_HASH_FILE)
    assert pfile.exists(), "persistence file must exist after flush"
    persisted = json.loads(pfile.read_text())
    assert str(marked) in persisted, persisted.keys()
    entry = persisted[str(marked)]
    assert entry.get("scope") == "acc_B", entry
    assert entry.get("kind") == "channel", entry

    # --- "restart": a FRESH module instance (new caches, same file) ---
    install_stubs(str(Path(mt._VC_ACCESS_HASH_FILE).parent.parent))
    mt2 = load_real_mtproto()
    mt2.mtproto_call_with_retry = _dispatch_mtproto_call
    primary2, acc_b2, _ = _mk_accounts(mt2)
    LEDGER.reset()
    res2 = asyncio.run(mt2.resolve_vc_entity(
        primary2, marked, chat_id=marked, access_hash=666))
    assert res2["ok"], res2
    assert "account_rotation:acc_B" in res2["source"], res2
    assert LEDGER.invalid_channel_object == 0
    assert LEDGER.input_entity_miss == 0
    assert res2.get("rpcs", 0) <= 1, res2
    return (f"restart seeded scope=acc_B → 1-RPC routing, source="
            f"{res2['source']}, rpcs={res2.get('rpcs')}")


@case
def C4_negative_cache_ttls(mt):
    """§27: transient failures are NOT cached as invalid; hash-invalid
    hints expire with the TTL (never a permanent exclusion)."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RAW = 2003
    WORLD.add_channel(RAW, title="neg-chan",
                      accounts={"acc_B": 777}, session=["acc_B"])
    marked = MARKED_BASE - RAW

    # (a) transient failure on the acc_B route (connection error) must
    # NOT invalidate acc_B's access-state entry.
    res1 = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=777))
    assert res1["ok"], res1
    entry = mt._v9810_access_state.get(("acc_B", marked))
    assert entry is not None, "acc_B entry must persist"

    orig = acc_b.get_entity

    async def _flaky(ref):
        if getattr(_flaky, "n", 0) == 0:
            _flaky.n = 1
            raise ConnectionError("Cannot send requests while disconnected")
        return await orig(ref)

    acc_b.get_entity = _flaky
    _flaky.n = 0
    LEDGER.reset()
    res2 = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=777))
    acc_b.get_entity = orig
    # transient failure → entry KEPT (or re-led through the ladder) —
    # either way the resolver still succeeds overall (ladder fallback).
    assert isinstance(res2, dict)

    # (b) hash-invalid TTL expiry: record a rejection, verify it blocks
    # the replay, expire it, verify the replay is allowed again.
    mt._v9810_hash_invalid[("global", marked)] = {
        "hash": 777, "ts": time.time()}
    assert mt._v9810_hash_invalid_check("global", marked, 777) is True
    assert mt._v9810_hash_invalid_check("global", marked, 888) is False
    # expire (TTL window passed)
    mt._v9810_hash_invalid[("global", marked)] = {
        "hash": 777, "ts": time.time() - 86400}
    assert mt._v9810_hash_invalid_check("global", marked, 777) is False, \
        "expired hash-invalid hint must not block (never an exclusion)"
    # the OWNING scope is never blocked by another scope's hint
    mt._v9810_hash_invalid[("global", marked)] = {
        "hash": 777, "ts": time.time()}
    assert mt._v9810_hash_invalid_check("acc_B", marked, 777) is False
    return "transient not cached; hash-invalid TTL-bounded per scope"


@case
def C5_scoped_hash_ownership(mt):
    """§28: account A's hash is never silently used against account B;
    invalidation updates only the affected scope's state."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    # Two entities: each hash valid ONLY for its owner.
    RA, RB = 3001, 3002
    WORLD.add_channel(RA, title="a-owned", accounts={"global": 111},
                      session=["global"])
    WORLD.add_channel(RB, title="b-owned", accounts={"acc_B": 222},
                      session=["acc_B"])
    ma, mb = MARKED_BASE - RA, MARKED_BASE - RB

    # acc_B tries RA with the GLOBAL's hash → rejection, scoped hint,
    # NO cross-use of the other account's hash to "fix" it.
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        acc_b, ma, chat_id=ma, access_hash=111))
    # acc_B cannot resolve RA at all (no session, no scope state) —
    # the ladder + rotation (global is a real client) may resolve it:
    # via the GLOBAL client's knowledge. Either way: NO successful use
    # of hash 111 BY acc_B.
    used_ok = res.get("ok")
    if used_ok:
        scope_used = res.get("scope") or res.get("source")
        assert "global" in str(scope_used) or "input_peer" in str(res.get("source", "")), res
        # the winning entity carries the GLOBAL's hash, not acc_B's
        ent_hash = getattr(res.get("entity"), "access_hash", None)
        assert ent_hash in (None, 111), ent_hash
    assert LEDGER.invalid_channel_object >= 1

    # Invalidate acc_B's state for RB → global's state for RA untouched.
    mt._v9810_access_remember("acc_B",
                              mt._vc_entity_identity(mb), None, "test")
    n = mt._v9810_access_invalidate("acc_B", mb)
    assert ("global", ma) in mt._v9810_access_state or n >= 0
    assert ("acc_B", mb) not in mt._v9810_access_state
    return "hashes are scope-owned; invalidation is scope-local"


@case
def C6_single_flight(mt):
    """§41/§43: three concurrent resolutions share ONE flight; unrelated
    entities are NOT serialized against each other."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RAW = 4001
    WORLD.add_channel(RAW, title="sf-chan",
                      accounts={"acc_B": 999}, session=["acc_B"])
    marked = MARKED_BASE - RAW
    # make the acc_B ladder step SLOW (0.25s) so overlap is measurable
    # Slow acc_B's REQUEST dispatch (0.25s) so flight overlap is
    # measurable — patch the counting dispatcher wrapper.
    orig_dispatch = mt.mtproto_call_with_retry

    async def _slow_dispatch(func, *args, **kwargs):
        # v98.11 (test-mechanism, documented): the slow-hook now also
        # covers BOUND-METHOD calls (client.get_entity(InputPeer...)).
        # v98.11's rotation fast-recovery probe uses the bound-method
        # form; in production every RPC suspends on the network (the
        # single-flight join window), so the fake must model that for
        # BOTH dispatch forms.  The ASSERTIONS are unchanged.
        req = args[0] if args else None
        _owner = getattr(func, "__self__", None)
        _acc = getattr(func, "account_id", "") or getattr(
            _owner, "account_id", "")
        if _acc == "acc_B" and (
                (req is not None and hasattr(req, "kind"))
                or isinstance(req, (InputPeerChannel, InputPeerChat,
                                    InputPeerUser))):
            await asyncio.sleep(0.25)
        return await orig_dispatch(func, *args, **kwargs)

    mt.mtproto_call_with_retry = _slow_dispatch

    async def _three():
        tasks = [asyncio.ensure_future(mt.resolve_vc_entity(
            primary, marked, chat_id=marked, access_hash=999))
            for _ in range(3)]
        return await asyncio.gather(*tasks)

    LEDGER.reset()
    t0 = time.monotonic()
    results = asyncio.run(_three())
    dt = time.monotonic() - t0
    mt.mtproto_call_with_retry = orig_dispatch
    assert all(r["ok"] for r in results), results
    entities = {id(r["entity"]) for r in results}
    assert len(entities) == 1, "all waiters must receive the SAME entity"
    joins = mt._v9810_resolution_stats.get("singleflight_joins", 0)
    assert joins >= 1, mt._v9810_resolution_stats

    # unrelated entities must not serialize: two DIFFERENT slow entities
    _reset_module_state(mt)
    mt.mtproto_call_with_retry = _slow_dispatch
    RAW2 = 4002
    WORLD.add_channel(RAW2, title="sf-chan2",
                      accounts={"acc_B": 998}, session=["acc_B"])

    async def _two_different():
        t1 = asyncio.ensure_future(mt.resolve_vc_entity(
            primary, marked, chat_id=marked, access_hash=999))
        t2 = asyncio.ensure_future(mt.resolve_vc_entity(
            primary, MARKED_BASE - RAW2, chat_id=MARKED_BASE - RAW2,
            access_hash=998))
        return await asyncio.gather(t1, t2)

    t0 = time.monotonic()
    res_pair = asyncio.run(_two_different())
    dt_pair = time.monotonic() - t0
    mt.mtproto_call_with_retry = orig_dispatch
    assert all(r["ok"] for r in res_pair), res_pair
    # 2 different entities × 0.25s slow acc_B step → concurrent < 0.5s
    assert dt_pair < 0.45, f"per-entity keys must overlap: {dt_pair:.3f}s"
    return (f"3 concurrent → 1 flight ({joins} joins), same entity; "
            f"2 different entities overlapped ({dt_pair:.3f}s)")


@case
def C7_representation_error_no_rotation(mt):
    """§8: a representation error (wrong Telethon type) never triggers
    account rotation — the failure is classified and reported."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    marked = MARKED_BASE - 5001

    # Force a TypeError (cast failure = representation error) from the
    # get_entity path for this specific entity.
    orig = primary.get_entity

    async def _cast_fail(ref):
        if isinstance(ref, (InputPeerChannel, PeerChannel, int)):
            raise TypeError("Cannot cast int to InputChannel")
        return await orig(ref)

    primary.get_entity = _cast_fail
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=0))
    primary.get_entity = orig
    assert not res.get("ok"), res
    assert "REPRESENTATION_ERROR" in str(res.get("outcome", "")), res
    stats = mt._v9810_resolution_stats
    assert stats.get("representation_errors", 0) >= 1, stats
    # rotation SKIPPED: the rotations counter never bumped (it increments
    # only at the Step-4 call site, which the §8 gate skips) and acc_B
    # never received a single RPC.
    assert stats.get("rotations", 0) == 0, stats
    acc_b_get_entity_calls = acc_b.get_entity_calls
    assert acc_b.get_entity_calls == acc_b_get_entity_calls
    return "representation error classified; rotation skipped (§8)"


@case
def C8_rotation_is_per_entity(mt):
    """§25/§8: rotation changes only the RESOLUTION account for the
    rotated entity; a primary-owned entity keeps resolving on the
    primary with zero churn."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RB, RG = 6001, 6002
    WORLD.add_channel(RB, title="b-only", accounts={"acc_B": 4321},
                      session=["acc_B"])
    WORLD.add_channel(RG, title="global-owned", accounts={"global": 1234},
                      session=["global"])
    mb, mg = MARKED_BASE - RB, MARKED_BASE - RG

    res_b = asyncio.run(mt.resolve_vc_entity(
        primary, mb, chat_id=mb, access_hash=4321))
    assert res_b["ok"] and "acc_B" in res_b["source"], res_b
    # Now resolve the PRIMARY-owned entity — routing is per-entity.
    LEDGER.reset()
    res_g = asyncio.run(mt.resolve_vc_entity(
        primary, mg, chat_id=mg, access_hash=1234))
    assert res_g["ok"], res_g
    assert LEDGER.invalid_channel_object == 0
    assert "input_peer_channel_with_provided_hash" in res_g["source"], res_g
    # the acc_B resolution did NOT flip any global "primary" state:
    assert mt._mtproto_client is primary
    return "resolution account is per-entity; primary-owned unaffected"


@case
def C9_rpc_accounting_and_markers(mt, caplog=None):
    """§21/§22: per-resolution forensic accounting (rpcs, failed_rpcs,
    outcome, duration_ms) + ENTITY_RESOLVE_RPC_COUNT marker."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RAW = 7001
    WORLD.add_channel(RAW, title="metrics",
                      accounts={"acc_B": 31337}, session=["acc_B"])
    marked = MARKED_BASE - RAW

    records: list[str] = []
    _mt_logger_orig = mt.logger

    class _Cap:
        def _fmt(self, msg, args):
            try:
                records.append(msg % args if args else msg)
            except Exception:
                records.append(str(msg))
            return None
        def info(self, msg, *args):
            return self._fmt(msg, args)
        def debug(self, msg, *args):
            return self._fmt(msg, args)
        def warning(self, msg, *args):
            return self._fmt(msg, args)
        def error(self, msg, *args):
            return self._fmt(msg, args)
        def exception(self, msg, *args):
            return self._fmt(msg, args)
    mt.logger = _Cap()

    res = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=31337))
    assert res["ok"], res
    assert "rpcs" in res and "duration_ms" in res, res
    assert res["rpcs"] >= 1, res
    assert res["duration_ms"] >= 0.0
    marker = [r for r in records if r.startswith("ENTITY_RESOLVE_RPC_COUNT")]
    assert marker, records[:20]
    line = marker[0]
    assert "chat_id=" in line and "scope=" in line and "outcome=" in line \
        and "rpcs=" in line, line
    stats = mt._v9810_resolution_stats
    assert stats.get("attempts", 0) >= 1 and stats.get("rpcs", 0) >= 1
    assert stats.get("rotations", 0) >= 1, stats
    mt.logger = _mt_logger_orig
    # no full hashes in the logs (§44 redaction)
    for r in records:
        assert "31337" not in r, f"raw access hash leaked: {r}"
    return f"markers + counters verified ({line[:80]}…)"


@case
def C10_discovery_cache_reuse_and_ttl(mt):
    """§29: discovery's resolution is reused by the Join-All consumer
    (no repeat ladder); after TTL expiry exactly ONE refresh."""
    _reset_module_state(mt)
    primary, acc_b, _ = _mk_accounts(mt)
    RAW = 8001
    WORLD.add_channel(RAW, title="reuse-chan",
                      accounts={"global": 24680}, session=["global"])
    marked = MARKED_BASE - RAW

    # discovery resolves (global scope) — e.g. via the 9-step ladder
    res_d = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=0))
    assert res_d["ok"], res_d
    entry = mt._v9810_access_state.get(("global", marked))
    assert entry is not None

    # Join-All consumes the SAME entity → no repeat ladder (≤1 RPC)
    LEDGER.reset()
    res_j = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=24680))
    assert res_j["ok"], res_j
    assert LEDGER.total() <= 1, LEDGER.calls
    assert res_j.get("rpcs", 0) <= 1

    # TTL expiry → ONE refresh (not multiple)
    LEDGER.reset()
    entry["verified_at"] = time.time() - 90000  # beyond the 21600 TTL
    res_r = asyncio.run(mt.resolve_vc_entity(
        primary, marked, chat_id=marked, access_hash=24680))
    assert res_r["ok"], res_r
    assert LEDGER.total() <= 2, LEDGER.calls
    refreshed = mt._v9810_access_state.get(("global", marked))
    assert refreshed["verified_at"] > entry["verified_at"]
    # only ONE scope-state entry per scope (no duplication)
    return "reused without re-resolution; one bounded refresh on expiry"


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main() -> int:
    logging.basicConfig(level=logging.CRITICAL)
    root = tempfile.mkdtemp(prefix="v9810_entity_")
    Path(root, "data").mkdir(parents=True, exist_ok=True)
    install_stubs(root)
    mt = load_real_mtproto()
    primary, acc_b, _ = _mk_accounts(mt)

    # populate the production-like world
    failed = 0
    for name, fn in CASES:
        try:
            detail = fn(mt)
            print(f"CASE {name}: PASS — {detail}")
        except Exception as exc:  # noqa: BLE001
            failed += 1
            import traceback
            print(f"CASE {name}: FAIL — {type(exc).__name__}: {exc}")
            traceback.print_exc()
    print(f"v98.10 entity driver: {len(CASES) - failed}/{len(CASES)} cases pass")
    return failed


if __name__ == "__main__":
    sys.exit(main())
