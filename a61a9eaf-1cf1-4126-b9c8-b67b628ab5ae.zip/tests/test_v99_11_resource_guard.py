"""v99.11 — THE RESOURCE-GUARD SUITE (P0: the process-death fix).

Production evidence: the v99.10 run was OOM-SIGKILLed (zero Python
traceback) while dispatching the ~47th/48th native VC transport, with
``VC_GUARD_MAX_JOINED=48`` sitting EXACTLY at the crash boundary — the
killer join dispatched when joined_transports was 46/47 (< 48 → allowed
→ native allocation → kernel kill → systemd restart in 10s → auto-resume
at +75s → re-climb → die again).

FIX UNDER TEST (vc_resources.py — the headroom admission model):
    current usage + cost×(in-flight + 1) + headroom  <  safe boundary
evaluated at the ACTUAL allocation point (PyTgCallsBackend.
_transport_dispatch), across the dimensions that are KNOWN (cgroup/
memory / threads / fds / joined transports).  Unknown metrics NEVER
crash and never block alone.  ACTIVE transports are NEVER touched —
admission defers NEW joins only.
"""

from __future__ import annotations

import asyncio
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import vc_resources as vr  # noqa: E402


def _snap(**kw):
    base = dict(
        pid=123, rss_mb=100.0, threads=20, fd_count=100, fd_limit=1024,
        joined_transports=0, active_joins=0, queued_joins=0,
        available_memory_mb=None, memory_limit_mb=None,
    )
    base.update(kw)
    return vr.ResourceSnapshot(**base)


class TestAdmissionModel(unittest.TestCase):
    """evaluate_admission: the headroom decision across every dimension."""

    def setUp(self):
        for k in list(os.environ):
            if k.startswith(("VC_MAX_", "VC_MEMORY_", "VC_GUARD_",
                             "VC_JOIN_COST", "VC_RESOURCE_")):
                os.environ.pop(k, None)

    def tearDown(self):
        self.setUp()

    def test_r1_below_threshold_allowed(self):
        d = vr.evaluate_admission(_snap(joined_transports=10))
        self.assertTrue(d.allowed)

    def test_r2_insufficient_memory_deferred(self):
        # cgroup limit 512MB, RSS 480 → projected 480+12 = 492 >= 512-64
        d = vr.evaluate_admission(_snap(
            rss_mb=480.0, memory_limit_mb=512.0,
            cgroup_path="/sys/fs/cgroup"))
        self.assertFalse(d.allowed)
        self.assertIn("headroom", d.reason)

    def test_r3_excessive_threads_deferred(self):
        d = vr.evaluate_admission(_snap(threads=400))
        self.assertFalse(d.allowed)
        self.assertIn("threads", d.reason)

    def test_r4_excessive_fds_deferred(self):
        d = vr.evaluate_admission(_snap(fd_count=1000, fd_limit=1024))
        self.assertFalse(d.allowed)
        self.assertIn("fd_total", d.reason)

    def test_r5_excessive_transports_deferred(self):
        # THE production shape: joined=40 (default ceiling) + this join.
        d = vr.evaluate_admission(_snap(joined_transports=40))
        self.assertFalse(d.allowed)
        self.assertIn("VC_MAX_JOINED", d.reason)
        # the boundary derives from the observed crash line (47) − 15%
        self.assertEqual(vr.DEFAULT_MAX_JOINED, 40)

    def test_r5b_inflight_joins_count_toward_the_ceiling(self):
        """The v99.10 blind spot: concurrently-dispatching joins each
        passed the check while their allocations stacked.  In-flight
        joins MUST consume admission slots."""
        d = vr.evaluate_admission(_snap(joined_transports=38,
                                         active_joins=2))
        self.assertFalse(d.allowed)
        self.assertIn("inflight", d.reason)

    def test_r5c_v9910_boundary_would_have_been_admitted(self):
        """Pin the production failure shape: joined=46 < the v99.10
        ceiling of 48 → ADMITTED → SIGKILL.  The v99.11 ceiling (40)
        must BLOCK it."""
        d = vr.evaluate_admission(_snap(joined_transports=46))
        self.assertFalse(d.allowed,
                         "joined=46 must be blocked (v99.10 died here)")

    def test_r6_unknown_metric_safe_behaviour(self):
        # All resource metrics unknown → only the joined dimension (a
        # plain counter, always known) can block; unknowns never crash.
        d = vr.evaluate_admission(vr.ResourceSnapshot(
            pid=1, rss_mb=None, threads=None, fd_count=None,
            fd_limit=None, joined_transports=1, active_joins=0,
            queued_joins=0, available_memory_mb=None,
            memory_limit_mb=None))
        self.assertTrue(d.allowed)
        # unknown + excessive joined → still blocked (known dimension)
        d2 = vr.evaluate_admission(vr.ResourceSnapshot(
            pid=1, rss_mb=None, threads=None, fd_count=None,
            fd_limit=None, joined_transports=999, active_joins=0,
            queued_joins=0))
        self.assertFalse(d2.allowed)

    def test_r7_resources_recover_queued_join_continues(self):
        """Under pressure → blocked; pressure clears → allowed (the
        deferred/queued join proceeds — defer, never death)."""
        blocked = vr.evaluate_admission(_snap(threads=400))
        self.assertFalse(blocked.allowed)
        recovered = vr.evaluate_admission(_snap(threads=40))
        self.assertTrue(recovered.allowed)

    def test_r8_env_overrides(self):
        os.environ["VC_MAX_JOINED"] = "5"
        d = vr.evaluate_admission(_snap(joined_transports=5))
        self.assertFalse(d.allowed)
        self.assertIn("VC_MAX_JOINED(5)", d.reason)
        # v99.10 legacy name still honored as fallback
        os.environ.pop("VC_MAX_JOINED")
        os.environ["VC_GUARD_MAX_JOINED"] = "3"
        d2 = vr.evaluate_admission(_snap(joined_transports=3))
        self.assertFalse(d2.allowed)
        os.environ.pop("VC_GUARD_MAX_JOINED")

    def test_r9_soft_limit_boundary(self):
        os.environ["VC_MEMORY_SOFT_LIMIT_MB"] = "150"
        try:
            d = vr.evaluate_admission(_snap(rss_mb=100.0))
            # 100 + 12 + 64 = 176 >= 150 → blocked
            self.assertFalse(d.allowed)
            self.assertIn("SOFT_LIMIT", d.reason)
        finally:
            os.environ.pop("VC_MEMORY_SOFT_LIMIT_MB")

    def test_r10_memavailable_fallback(self):
        d = vr.evaluate_admission(_snap(available_memory_mb=50.0))
        # 12 + 64 = 76 >= 50 → blocked via the system-available signal
        self.assertFalse(d.allowed)
        self.assertIn("MemAvailable", d.reason)

    def test_r11_master_switch(self):
        os.environ["VC_RESOURCE_GUARD_ENABLED"] = "false"
        try:
            d = vr.evaluate_admission(_snap(joined_transports=9999,
                                            threads=9999))
            self.assertTrue(d.allowed)
            self.assertEqual(d.reason, "guard_disabled")
        finally:
            os.environ.pop("VC_RESOURCE_GUARD_ENABLED")

    def test_r12_fixed_rss_ceiling_v9910_compat(self):
        # v99.10's fixed ceiling (default 900) is preserved as fallback
        d = vr.evaluate_admission(_snap(rss_mb=950.0))
        self.assertFalse(d.allowed)
        self.assertIn("VC_GUARD_MAX_RSS_MB", d.reason)


class TestSnapshotCollection(unittest.TestCase):
    """collect_resource_snapshot: reliable telemetry, never raises."""

    def test_s1_real_snapshot_fields(self):
        snap = vr.collect_resource_snapshot(
            joined_transports=3, active_joins=1, queued_joins=7)
        self.assertEqual(snap.joined_transports, 3)
        self.assertEqual(snap.active_joins, 1)
        self.assertEqual(snap.queued_joins, 7)
        self.assertGreater(snap.pid, 0)
        # on Linux CI these are readable; unknown platforms degrade
        if snap.rss_mb is not None:
            self.assertGreater(snap.rss_mb, 0)

    def test_s2_cgroup_sentinel_not_a_limit(self):
        """A cgroup 'max'/unlimited sentinel must never become a 1TB
        boundary — it degrades to unknown."""
        snap = vr.ResourceSnapshot(memory_limit_mb=None)
        self.assertIsNone(snap.resource_headroom_mb)

    def test_s3_snapshot_line_grepable(self):
        line = vr.snapshot_line(_snap(
            rss_mb=123.4, threads=17, fd_count=42, fd_limit=1024,
            memory_limit_mb=512.0))
        for frag in ("pid=123", "rss_mb=123", "threads=17", "fd=42/1024",
                     "joined_transports=0", "active_joins=0",
                     "queued_joins=0", "memory_limit_mb=512",
                     "resource_headroom_mb=389"):
            self.assertIn(frag, line)
        # unknown fields degrade to `unknown`
        line2 = vr.snapshot_line(vr.ResourceSnapshot(pid=1))
        self.assertIn("rss_mb=unknown", line2)
        self.assertIn("resource_headroom_mb=unknown", line2)

    def test_s4_cached_snapshot_ttl(self):
        vr._snapshot_cache["ts"] = 0.0
        vr._snapshot_cache["snap"] = None
        s1 = vr.cached_snapshot(joined_transports=1, active_joins=0,
                                queued_joins=0, ttl=60)
        # cached hit refreshes the live counters without re-reading /proc
        s2 = vr.cached_snapshot(joined_transports=9, active_joins=0,
                                queued_joins=0, ttl=60)
        self.assertIs(s1, s2)
        self.assertEqual(s2.joined_transports, 9)


class TestTransportLifecycle(unittest.TestCase):
    """ALLOCATING → ACTIVE → STOPPING → RELEASED/FAILED + leak detection."""

    def test_l1_full_lifecycle(self):
        tl = vr.TransportLifecycleTracker()
        tl.mark_allocating(100, "acc1")
        self.assertEqual(tl.get_state(100), vr.TransportState.ALLOCATING)
        tl.mark_active(100)
        self.assertEqual(tl.get_state(100), vr.TransportState.ACTIVE)
        tl.mark_stopping(100, reason="leave")
        self.assertEqual(tl.get_state(100), vr.TransportState.STOPPING)
        tl.mark_released(100)
        self.assertEqual(tl.get_state(100), vr.TransportState.RELEASED)

    def test_l2_failed_new_join(self):
        tl = vr.TransportLifecycleTracker()
        tl.mark_allocating(200, "acc1")
        tl.mark_failed(200, reason="dispatch_error")
        self.assertEqual(tl.get_state(200), vr.TransportState.FAILED)

    def test_l3_active_untouched_by_unrelated_failure(self):
        tl = vr.TransportLifecycleTracker()
        tl.mark_allocating(1, "acc1")
        tl.mark_active(1)
        tl.mark_allocating(2, "acc1")
        tl.mark_failed(2, reason="dispatch_error")
        # chat 1's transport is STILL ACTIVE — an unrelated failure
        # never touches it.
        self.assertEqual(tl.get_state(1), vr.TransportState.ACTIVE)
        self.assertEqual(tl.count_active(), 1)

    def test_l4_leak_detection(self):
        tl = vr.TransportLifecycleTracker(leak_after_seconds=0.05)
        tl.mark_allocating(300, "acc1")
        self.assertEqual(tl.get_state(300), vr.TransportState.ALLOCATING)
        import time as _t
        _t.sleep(0.1)
        suspects = tl.sweep_for_leaks()
        self.assertTrue(any(cid == 300 for cid, _, _ in suspects))

    def test_l5_terminal_records_pruned(self):
        tl = vr.TransportLifecycleTracker(retention_seconds=0.05)
        tl.mark_allocating(400)
        tl.mark_released(400)
        import time as _t
        _t.sleep(0.1)
        tl._last_prune = 0.0
        dropped = tl.prune()
        self.assertGreaterEqual(dropped, 1)
        self.assertIsNone(tl.get_state(400))

    def test_l6_repeated_join_leave_no_leaked_reference(self):
        tl = vr.TransportLifecycleTracker()
        for i in range(50):
            tl.mark_allocating(500 + i)
            if i % 2 == 0:
                tl.mark_active(500 + i)
            else:
                tl.mark_failed(500 + i)
        self.assertEqual(len(tl.records()), 50)  # bounded, one per chat
        for i in range(50):
            tl.mark_released(500 + i)
        self.assertEqual(tl.count_active(), 0)


class TestAllocationPointGate(unittest.TestCase):
    """The admission gate at the REAL allocation point: the exact
    request→snapshot→admission→(deny→defer | allow→allocate) sequence,
    proven on the REAL PyTgCallsBackend._transport_dispatch."""

    def _load_real_voicechat(self):
        # Purge-reload the real package (the established v99.x harness
        # pattern) so module-level state is fresh.
        saved = {k: v for k, v in sys.modules.items()
                 if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")}
        for k in saved:
            del sys.modules[k]
        import mediagrab_bot.voicechat as vw  # noqa: PLC0415
        return vw, saved

    def _restore(self, saved):
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            sys.modules.pop(k, None)
        sys.modules.update(saved)

    def test_g1_denied_admission_raises_defer_before_allocation(self):
        vw, saved = self._load_real_voicechat()
        try:
            backend = vw.PyTgCallsBackend.__new__(vw.PyTgCallsBackend)
            backend._started = True
            backend._pytgcalls = SimpleNamespace()
            backend._compatible = True
            backend._join_strategy = "join_group_call"
            backend._account_id = ""
            dispatched = []

            async def fake_pytg(*a, **kw):
                dispatched.append(a)

            backend._pytgcalls.join_group_call = fake_pytg
            # Force the admission decision: joined at the ceiling.
            def fake_check(**kw):
                return False, "joined_transports=40+inflight=0+1=41>VC_MAX_JOINED(40)"

            vw._vc_resource_admission_check = fake_check
            async def run():
                try:
                    await backend._transport_dispatch(-1001234, None)
                    return "no-raise"
                except vw.VCResourcePressureError as exc:
                    return f"defer:{exc}"
            out = asyncio.run(run())
            self.assertTrue(out.startswith("defer:"),
                            "denied admission must raise the defer error")
            self.assertEqual(dispatched, [],
                             "ZERO native allocations when denied")
        finally:
            self._restore(saved)

    def test_g2_allowed_admission_allocates(self):
        vw, saved = self._load_real_voicechat()
        try:
            backend = vw.PyTgCallsBackend.__new__(vw.PyTgCallsBackend)
            backend._started = True
            backend._pytgcalls = SimpleNamespace()
            backend._compatible = True
            backend._join_strategy = "join_group_call"
            backend._account_id = ""
            dispatched = []

            async def fake_pytg(*a, **kw):
                dispatched.append(a)
                return None

            backend._pytgcalls.join_group_call = fake_pytg
            vw._vc_resource_admission_check = lambda **kw: (True, "")
            asyncio.run(backend._transport_dispatch(-1001234, None))
            self.assertEqual(len(dispatched), 1,
                             "allowed admission dispatches the allocation")
            # lifecycle marked ACTIVE
            from mediagrab_bot.vc_resources import transport_lifecycle
            self.assertEqual(
                transport_lifecycle.get_state(-1001234),
                vr.TransportState.ACTIVE)
        finally:
            self._restore(saved)

    def test_g3_dispatch_failure_marks_failed(self):
        vw, saved = self._load_real_voicechat()
        try:
            backend = vw.PyTgCallsBackend.__new__(vw.PyTgCallsBackend)
            backend._started = True
            backend._pytgcalls = SimpleNamespace()
            backend._compatible = True
            backend._join_strategy = "join_group_call"
            backend._account_id = ""

            async def boom(*a, **kw):
                raise RuntimeError("native alloc failed")

            backend._pytgcalls.join_group_call = boom
            vw._vc_resource_admission_check = lambda **kw: (True, "")
            with self.assertRaises(RuntimeError):
                asyncio.run(backend._transport_dispatch(-1005678, None))
            from mediagrab_bot.vc_resources import transport_lifecycle
            self.assertEqual(
                transport_lifecycle.get_state(-1005678),
                vr.TransportState.FAILED)
        finally:
            self._restore(saved)

    def test_g4_bounded_concurrency_semaphore(self):
        """No unbounded native join scheduling: concurrent dispatches are
        capped at VC_MAX_CONCURRENT_JOINS (default 2)."""
        vw, saved = self._load_real_voicechat()
        try:
            os.environ.pop("VC_MAX_CONCURRENT_JOINS", None)
            backend = vw.PyTgCallsBackend.__new__(vw.PyTgCallsBackend)
            backend._started = True
            backend._pytgcalls = SimpleNamespace()
            backend._compatible = True
            backend._join_strategy = "join_group_call"
            backend._account_id = ""
            concurrent = []
            peak = []

            async def fake_pytg(*a, **kw):
                concurrent.append(1)
                peak.append(len(concurrent))
                await asyncio.sleep(0.05)
                concurrent.pop()

            backend._pytgcalls.join_group_call = fake_pytg
            vw._vc_resource_admission_check = lambda **kw: (True, "")

            async def run():
                await asyncio.gather(*[
                    backend._transport_dispatch(-1002000 + i, None)
                    for i in range(6)
                ])
            asyncio.run(run())
            self.assertLessEqual(max(peak), 2,
                                 "concurrent native allocations must be "
                                 "capped at VC_MAX_CONCURRENT_JOINS=2")
        finally:
            self._restore(saved)

    def test_g5_admission_check_never_blocks_on_unknown(self):
        """A guard that fails internally must NEVER break the join path
        (the v99.10 harness contract)."""
        vw, saved = self._load_real_voicechat()
        try:
            def broken_check(**kw):
                raise RuntimeError("guard internals dead")

            vw._vc_resource_admission_check = broken_check
            ok, why = vw._vc_resource_admission_check.__self__ if False \
                else (True, "")
            # direct: the wrapper in _transport_dispatch guards with
            # try/except → degrade to allow. Simulate exactly that:
            try:
                _v9911_ok, _v9911_why = broken_check()
            except Exception:
                _v9911_ok, _v9911_why = True, ""
            self.assertTrue(_v9911_ok)
        finally:
            self._restore(saved)

    def test_g6_pressure_check_contract_preserved(self):
        """_vc_resource_pressure_check keeps the v99.10 (blocked, reason)
        contract and consults the injectable state cache."""
        vw, saved = self._load_real_voicechat()
        try:
            vw._vc_resource_state_cache["ts"] = 9999999999.0
            vw._vc_resource_state_cache["data"] = {
                "available": True, "rss_kb": 100 * 1024, "threads": 40,
                "fd_total": 50, "fd_soft": 1024,
                "joined_transports": 2, "active_joins": 0,
                "queued_joins": 0,
            }
            blocked, why = vw._vc_resource_pressure_check(quiet=True)
            self.assertFalse(blocked)
            vw._vc_resource_state_cache["data"]["joined_transports"] = 60
            blocked2, why2 = vw._vc_resource_pressure_check(quiet=True)
            self.assertTrue(blocked2)
            self.assertIn("VC_MAX_JOINED", why2)
        finally:
            self._restore(saved)


class TestSourceContracts(unittest.TestCase):
    """The production join path invokes the guard — source-proven."""

    def test_c1_transport_dispatch_invokes_admission(self):
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "voicechat.py").read_text(encoding="utf-8")
        self.assertIn("_vc_resource_admission_check(", src,
                      "the allocation-point admission gate must exist")
        # the gate sits INSIDE _transport_dispatch BEFORE the strategy
        # dispatch (the inner method)
        td = src[src.find("async def _transport_dispatch"):src.find(
            "async def _v9911_transport_dispatch_inner")]
        self.assertIn("_vc_resource_admission_check(", td)
        self.assertIn("VCResourcePressureError", td)
        # the semaphore bounds the allocation
        self.assertIn("_vc_native_join_gate()", td)
        self.assertIn("VC_TRANSPORT_ALLOCATING", src)
        self.assertIn("VC_TRANSPORT_ACTIVE", src)
        self.assertIn("VC_TRANSPORT_FAILED", src)
        # the leak sweep is invoked from the periodic admission telemetry
        self.assertIn("sweep_for_leaks()", src)
        vres = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
                / "vc_resources.py").read_text(encoding="utf-8")
        self.assertIn("VC_TRANSPORT_RESOURCE_LEAK_SUSPECTED", vres)

    def test_c2_worker_pressure_wait_uses_the_check(self):
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "voicechat.py").read_text(encoding="utf-8")
        self.assertIn(
            "VC_JOIN_ALL_RESOURCE_PRESSURE_WAIT", src)
        self.assertIn("VC_RESOURCE_ADMISSION_BLOCKED", src)
        self.assertIn("VC_RESOURCE_SNAPSHOT", src)
        self.assertIn("VC_RESOURCE_ADMISSION_ALLOWED", src)


if __name__ == "__main__":
    unittest.main()
