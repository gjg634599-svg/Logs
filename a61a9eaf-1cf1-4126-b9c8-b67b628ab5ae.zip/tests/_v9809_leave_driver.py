"""v98.09 PATCH-2 — VC leave regression driver (subprocess-only).

Runs the REAL production leave path (vc_leave_target →
_v9809_leave_target_verified → backend._leave_target → _v9809_leave_api
→ PyTgCalls) with the REAL voicechat module imported via the stub
loader (telegram/telethon/pytgcalls are unavailable in the sandbox —
the exact blind spot that let the v98.09 import crash ship). A fake
PyTgCalls mimics the RUNTIME-PROVEN 2.3.3 semantics:
  * call objects stored under the MARKED id (-100…) in a per-instance
    ``calls`` dict;
  * ``leave_call(id)`` removes the entry ONLY if the id is a key —
    otherwise it is a SILENT NO-OP that still returns successfully
    (the DEFECT-2 / v98.04 FIX-X behavior class).

Cases follow the user's §11 A–G specification. Exit code = number of
failed cases; each case prints ``CASE <id>: PASS|FAIL — detail``.
"""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import sys
import types

_HERE_DIR = __file__
_ROOT = _HERE_DIR.rsplit("/tests/", 1)[0]
_SRC = f"{_ROOT}/mediagrab_bot"


class _Stub:
    """Universal permissive stub (callable/awaitable/attribute-safe)."""
    def __init__(self, *a, **k): pass
    def __call__(self, *a, **k): return _Stub()
    def __await__(self):
        async def _noop(): return _Stub()
        return _noop().__await__()
    def __getattr__(self, name): return _Stub()
    def __iter__(self): return iter(())
    def __bool__(self): return False
    def __or__(self, o): return self
    def __ror__(self, o): return self
    def __fspath__(self): return "/tmp/vcimport"
    def __int__(self): return 0
    def __index__(self): return 0
    def __str__(self): return ""
    def __float__(self): return 0.0
    def __lt__(self, o): return True
    def __le__(self, o): return True
    def __gt__(self, o): return False
    def __ge__(self, o): return False
    def __eq__(self, o): return False
    def __ne__(self, o): return True
    def __hash__(self): return 0
    def __truediv__(self, o): return self
    def __rtruediv__(self, o): return self
    def __add__(self, o): return self
    def __radd__(self, o): return self
    def __mul__(self, o): return self
    def __mod__(self, o): return self
    def __format__(self, spec): return ""


def _mod(name, attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    sys.modules[name] = m
    return m


def _attrs(*names):
    return {n: _Stub() for n in names}


def import_voicechat():
    """Stub-import the REAL voicechat.py (full module body execution)."""
    logging.getLogger("mediagrap").addHandler(logging.NullHandler())
    _mod("httpx", _attrs("AsyncClient", "Client"))
    _mod("telegram", _attrs("Update", "InlineKeyboardButton", "InlineKeyboardMarkup"))
    _mod("telegram.ext", _attrs("ContextTypes", "filters"))
    _mod("telegram.error", _attrs(
        "BadRequest", "Forbidden", "NetworkError", "TimedOut", "RetryAfter"))
    _mod("pytgcalls", _attrs("PyTgCalls"))  # import-success only (lazy import)
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [_SRC]
    sys.modules["mediagrab_bot"] = pkg
    # v98.13: voicechat also imports _env_float (join-time gate env knobs).
    _mod("mediagrab_bot.config", _attrs("_env_int", "_env_float", "config"))
    _mod("mediagrab_bot.text_utils", _attrs("md_escape", "html_escape"))
    _mod("mediagrab_bot.media_processor", _attrs(
        "download_slot", "with_retries", "retrying", "send_file_back",
        "notify", "safe_unlink"))
    _mod("mediagrab_bot.ai_modes", _attrs(
        "ACCEPTS", "MODE_LABELS", "MODE_ORDER", "PROMPTS", "build_prompt",
        "NORMALISERS", "normalise", "accepts", "media_kind_for",
        "render_result"))
    _mod("mediagrab_bot.frame_extractor", _attrs(
        "extract_frames", "FrameExtractionError", "_FFMPEG", "_FFPROBE"))
    _mod("mediagrab_bot.mtproto", _attrs(
        # v98.13: VCTransportError must be a REAL class — voicechat now
        # defines class VCJoinUnverifiedError(VCTransportError) at module
        # import time (the join-time verification gate's typed error).
        "_redact_ah", "_vc_entity_cache",
        "_vc_entity_cache_by_client", "_user_entity_cache",
        "_USER_ENTITY_CACHE_FILE", "_VC_ACCESS_HASH_FILE",
        "resolve_entity_full", "resolve_vc_entity", "_vc_client_scope",
        "resolve_forwarded_sender", "resolve_forwarded_sender_full",
        "resolve_user_id_full", "resolve_across_accounts",
        "profile_count_posts", "profile_download_photo",
        "mtproto_get_client", "mtproto_get_client_for_role",
        "mtproto_call_with_retry", "mtproto_is_available",
        "mtproto_is_started", "get_userbot_cluster", "get_cluster_router",
        "get_routed_client", "get_vc_pool", "VoiceChatAccountPool",
        "UserbotCluster", "UserbotClusterRouter", "profile_resolve_entity",
        "_get_current_vc_account_id", "ROLE_VOICE_CHAT",
        "STATUS_CONNECTED", "STATUS_CONNECTION_FAILED", "STATUS_FLOODWAIT",
        "STATUS_HEALTHY", "STATUS_UNAUTHORIZED",
        "_flush_access_hash_persistence", "_flush_user_entity_persistence"))
    class _VCTransportErrorStub(Exception):
        pass
    sys.modules["mediagrab_bot.mtproto"].VCTransportError = _VCTransportErrorStub
    _mod("mediagrab_bot.talkative_hooks", _attrs(
        "_adaptive_check_stale", "_adaptive_claim_response",
        "_adaptive_release_response", "_adaptive_detect_language",
        "_adaptive_response_length_guidance", "_adaptive_route_model",
        "_talkative_mode_allows_vc", "_adaptive_get_context",
        "_adaptive_engagement_score", "_talkative_build_system_prompt",
        "talkative_generate", "talkative_get_mode"))
    _mod("mediagrab_bot.diag_hooks", _attrs("v85_diag"))
    _mod("mediagrab_bot.db_layer", _attrs(
        "repo", "get_db", "_db", "vc_groups_active", "vc_groups_all",
        "vc_groups_keyset", "vc_groups_keyset_stream", "vc_upsert_group",
        "vc_add_visit", "vc_update_visit", "vc_recent_visits",
        "vc_get_settings", "vc_update_settings", "vc_get_tour_state",
        "vc_save_tour_state", "vc_visit_count", "vc_visited_group_ids_since",
        "vc_group_count", "talkative_add_memory",
        "talkative_effective_provider", "talkative_effective_settings",
        # v98.09-P3 §7/§19: knowledge-cache functions (stub-safe).
        "vc_groups_fresh_active", "vc_groups_stale_active",
        "vc_knowledge_store_active", "vc_knowledge_mark_inactive"))
    _mod("mediagrab_bot.utils_real", _attrs(
        "extension_category", "get_bot", "human_size", "is_available",
        "periodic_cleanup", "register_bot", "remove_path",
        "safe_edit_message_text", "safe_filename", "safe_reply_text",
        "safe_send_document", "safe_send_message", "supervised_create_task",
        "telegram_media_type", "unique_path", "_active_tasks",
        "_redact_secrets", "_ui_check", "_ui_claim", "_ui_invalidate",
        "_ui_release", "_ui_owners", "_userbot_id"))
    _mod("mediagrab_bot.states", _attrs(
        "IDLE", "set_state", "get_state", "reset", "set_tool", "get_tool",
        "set_last_download", "get_last_download", "AWAIT_VC_CHECK_TARGET",
        "AWAIT_VC_COOLDOWN", "AWAIT_VC_JOIN_TARGET", "AWAIT_VC_STAY"))
    _mod("mediagrab_bot.ui_keyboards", _attrs(
        "back_only", "cancel_back", "vc_menu", "vc_manual_menu",
        "vc_settings_menu", "vc_dashboard_menu", "vc_dashboard_back_menu",
        "vc_dashboard_text", "vc_dashboard_errors_menu",
        "vc_dashboard_logs_menu", "vc_stay_presets_menu",
        "vc_cooldown_presets_menu"))
    _mod("mediagrab_bot.ai_analyzer", _attrs(
        "_read_bytes", "_run_in_thread", "_get_client"))
    _mod("mediagrab_bot.join_all_worker", _attrs(
        "CircuitBreaker", "CircuitBreakerState", "CancellationToken",
        "CheckpointManager", "IllegalStateTransitionError",
        "JoinAllWorkerState", "RetryPolicy", "WorkerStateMachine",
        "generate_run_id", "is_backend_wide_error", "is_interdc_error",
        "is_transport_dc_timeout", "parse_floodwait_seconds"))
    _mod("mediagrab_bot.distributed_join", _attrs(
        "distributed_assign_target", "distributed_get_healthy_accounts",
        "distributed_mark_failure", "distributed_mark_success",
        "distributed_plan", "distributed_reset", "distributed_account_loads",
        "vc_assignment_get", "vc_assignment_release",
        "vc_assignment_release_account", "vc_assignment_snapshot"))
    _mod("mediagrab_bot.vc_state_coordinator", _attrs(
        "VCChatCoordinator", "VCChatState", "VCOperation",
        "get_vc_coordinator"))
    _mod("mediagrab_bot.vc_op_scheduler", _attrs(
        "VCOpRequest", "VCOperationScheduler", "OpStatus",
        "get_vc_scheduler"))
    # REAL stdlib-only modules
    for name, fname in (("mediagrab_bot.vc_hooks", "vc_hooks.py"),
                        ("mediagrab_bot.vc_architecture",
                         "vc_architecture.py")):
        spec = importlib.util.spec_from_file_location(name, f"{_SRC}/{fname}")
        m = importlib.util.module_from_spec(spec)
        sys.modules[name] = m
        spec.loader.exec_module(m)
    spec = importlib.util.spec_from_file_location(
        "mediagrab_bot.voicechat", f"{_SRC}/voicechat.py")
    vc = importlib.util.module_from_spec(spec)
    sys.modules["mediagrab_bot.voicechat"] = vc
    spec.loader.exec_module(vc)
    return vc


class FakePyTgCalls:
    """PyTgCalls 2.3.3 semantics: marked-id container + silent no-ops."""

    def __init__(self):
        self.calls: dict[int, object] = {}   # MARKED id -> call object
        self.api_log: list[tuple[str, object]] = []
        self.noop_leave = False              # Case D: success w/o removal

    async def leave_call(self, chat_id):
        self.api_log.append(("leave_call", chat_id))
        if self.noop_leave:
            return  # "success" without removing (RUNTIME-PROVEN defect)
        self.calls.pop(chat_id, None)        # silent no-op if absent

    async def leave_group_call(self, chat_id):
        self.api_log.append(("leave_group_call", chat_id))
        self.calls.pop(chat_id, None)

    async def stop_call(self, chat_id):
        self.api_log.append(("stop_call", chat_id))
        self.calls.pop(chat_id, None)

    async def leave_current_call(self):
        self.api_log.append(("leave_current_call", None))
        if self.calls:
            self.calls.pop(next(iter(self.calls)))


RAW = 1922822605
MARKED = -1001922822605


class World:
    """Fake multi-account world: global + account A + account B backends."""

    def __init__(self, vc):
        self.vc = vc
        self.global_b = vc.PyTgCallsBackend()
        self.global_b._started = True
        self.global_b._leave_strategy = "leave_call"
        self.global_b._pytgcalls = FakePyTgCalls()
        vc._vc_backend = self.global_b
        self.a_b = vc.vc_get_backend(account_id="acc_A")
        self.a_b._started = True
        self.a_b._leave_strategy = "leave_call"
        self.a_b._pytgcalls = FakePyTgCalls()
        self.b_b = vc.vc_get_backend(account_id="acc_B")
        self.b_b._started = True
        self.b_b._leave_strategy = "leave_call"
        self.b_b._pytgcalls = FakePyTgCalls()
        vc._vc_participations.clear()
        vc._vc_active_join_backends_by_chat.clear()
        vc._vc_target_cooldowns.clear()
        vc._vc_join_all_leave_block_active = False

    def join_on(self, backend, raw=RAW):
        """Simulate a Join-All join: call object under the chat's MARKED id
        + ownership + registry record (mirrors join() lines 3621/3637 +
        register)."""
        marked = -1000000000000 - raw if raw > 0 else raw
        backend._pytgcalls.calls[marked] = object()
        self.vc._vc_active_join_backends_by_chat[marked] = backend
        rec = self.vc.VCParticipationState(chat_id=raw, state="joined",
                                           request_accepted=True,
                                           intentional=True,
                                           locally_tracked=True,
                                           account_id=backend._account_id)
        self.vc._vc_participations[raw] = rec
        return rec


async def case_a(vc):
    """Case A — raw ID join / marked ID storage (user §11 A)."""
    w = World(vc)
    w.join_on(w.a_b)
    outcome = await vc.vc_leave_target(RAW)
    ok = (outcome == "success"
          and MARKED not in w.a_b._pytgcalls.calls
          and ("leave_call", RAW) in w.a_b._pytgcalls.api_log
          and ("leave_call", MARKED) in w.a_b._pytgcalls.api_log)
    return ok, f"outcome={outcome} container={sorted(w.a_b._pytgcalls.calls)} api={w.a_b._pytgcalls.api_log}"


async def case_b(vc):
    """Case B — marked ID input (user §11 B)."""
    w = World(vc)
    w.join_on(w.a_b)
    vc._vc_participations.pop(RAW, None)
    vc._vc_participations[MARKED] = vc.VCParticipationState(
        chat_id=MARKED, state="joined", request_accepted=True,
        intentional=True, locally_tracked=True, account_id="acc_A")
    outcome = await vc.vc_leave_target(MARKED)
    ok = (outcome == "success"
          and MARKED not in w.a_b._pytgcalls.calls
          and RAW not in w.a_b._pytgcalls.calls)
    return ok, f"outcome={outcome} container={sorted(w.a_b._pytgcalls.calls)}"


async def case_c(vc):
    """Case C — wrong backend (user §11 C): leave must use OWNER backend A,
    never B nor the global singleton (the DEFECT-2 fix)."""
    w = World(vc)
    w.join_on(w.a_b)                     # call lives in A's container only
    outcome = await vc.vc_leave_target(RAW)
    ok = (outcome == "success"
          and MARKED not in w.a_b._pytgcalls.calls
          and len(w.a_b._pytgcalls.api_log) >= 2     # raw + marked tried on A
          and not w.b_b._pytgcalls.api_log            # B untouched
          and not w.global_b._pytgcalls.api_log       # global untouched
          and not w.b_b._pytgcalls.calls)
    return ok, (f"outcome={outcome} A_api={w.a_b._pytgcalls.api_log} "
                f"B_api={w.b_b._pytgcalls.api_log} "
                f"G_api={w.global_b._pytgcalls.api_log}")


async def case_d(vc):
    """Case D — silent no-op (user §11 D): fake PyTgCalls returns success
    WITHOUT removing the call. The implementation must report failure —
    never false success."""
    w = World(vc)
    w.join_on(w.a_b)
    w.a_b._pytgcalls.noop_leave = True
    outcome = await vc.vc_leave_target(RAW)
    rec = vc._vc_participations.get(RAW)
    ok = (outcome == "failed"
          and MARKED in w.a_b._pytgcalls.calls
          and rec is not None
          and rec.state == "cleanup_required"
          and rec.cleanup_required is True)
    return ok, (f"outcome={outcome} container_has={MARKED in w.a_b._pytgcalls.calls} "
                f"registry_state={rec.state if rec else None}")


async def case_d2(vc):
    """Case D2 — cross-backend residual (aggregated verification): backend
    reports success + its own container is clean, but a DIFFERENT backend
    still holds the call → must downgrade to failed (no false 'left')."""
    w = World(vc)
    w.join_on(w.a_b)
    # Copy the call object into B's container as residual cross-backend state
    w.b_b._pytgcalls.calls[MARKED] = object()
    outcome = await vc.vc_leave_target(RAW)
    ok = outcome == "failed" and MARKED in w.b_b._pytgcalls.calls
    return ok, f"outcome={outcome} B_container_has={MARKED in w.b_b._pytgcalls.calls}"


async def case_e(vc):
    """Case E — post-leave stale registry (user §11 E): after a successful
    leave, no stale local state can flip the target back to JOINED."""
    w = World(vc)
    w.join_on(w.a_b)
    outcome = await vc.vc_leave_target(RAW)
    # No registry record, no container entry under ANY form on ANY backend,
    # ownership released, cooldown recorded (§8).
    containers_clean = all(
        MARKED not in b._pytgcalls.calls and RAW not in b._pytgcalls.calls
        for b in (w.global_b, w.a_b, w.b_b))
    ownership_released = (MARKED not in vc._vc_active_join_backends_by_chat
                          and RAW not in vc._vc_active_join_backends_by_chat)
    cooldown = RAW in vc._vc_target_cooldowns or MARKED in vc._vc_target_cooldowns
    ok = (outcome == "success" and RAW not in vc._vc_participations
          and containers_clean and ownership_released and cooldown)
    return ok, (f"outcome={outcome} registry={RAW in vc._vc_participations} "
                f"containers_clean={containers_clean} "
                f"ownership_released={ownership_released} cooldown={cooldown}")


async def case_f(vc):
    """Case F — immediate rejoin (user §11 F): after a leave, the next
    Join-All pass must DEFER rejoining for the cooldown window, then
    allow it (explicit join policy) after expiry."""
    w = World(vc)
    w.join_on(w.a_b)
    await vc.vc_leave_target(RAW)
    deferred_now = vc._v9809_leave_rejoin_deferred(RAW, run_id="t1")
    # expire the cooldown: bump the recorded timestamps 301s into the past
    for k in list(vc._vc_target_cooldowns):
        vc._vc_target_cooldowns[k] -= 301
    deferred_after = vc._v9809_leave_rejoin_deferred(RAW, run_id="t2")
    ok = deferred_now and not deferred_after
    return ok, f"deferred_now={deferred_now} deferred_after_expiry={deferred_after}"


async def case_g(vc):
    """Case G — manual user leave (user §11 G): the handler chain
    (vc__leave_current → vc_manual_leave) must reach the SAME verified
    leave mechanism and actually disconnect every tracked VC."""
    w = World(vc)
    w.join_on(w.a_b, raw=1393246704)
    w.join_on(w.a_b, raw=1551122433)
    w.join_on(w.b_b, raw=1652225531)
    res = await vc.vc_manual_leave()
    a_clean = not w.a_b._pytgcalls.calls
    b_clean = not w.b_b._pytgcalls.calls
    registry_empty = not vc._vc_participations
    ok = (res.startswith("left_tracked") and a_clean and b_clean
          and registry_empty
          and len(w.a_b._pytgcalls.api_log) >= 4
          and len(w.b_b._pytgcalls.api_log) >= 2)
    return ok, (f"res={res} A_clean={a_clean} B_clean={b_clean} "
                f"registry_empty={registry_empty}")


async def case_g2(vc):
    """Case G2 — manual leave with NOTHING joined → honest 'not_in_vc'
    (legacy semantics preserved)."""
    w = World(vc)
    res = await vc.vc_manual_leave()
    ok = res == "not_in_vc"
    return ok, f"res={res}"


async def case_h(vc):
    """Contract — v97.83 leave-block during Join All still enforced."""
    w = World(vc)
    w.join_on(w.a_b)
    vc._vc_join_all_leave_block_active = True
    try:
        outcome = await vc.vc_leave_target(RAW)
    finally:
        vc._vc_join_all_leave_block_active = False
    ok = (outcome == "blocked_during_join_all"
          and MARKED in w.a_b._pytgcalls.calls
          and not w.a_b._pytgcalls.api_log)
    return ok, f"outcome={outcome} untouched={MARKED in w.a_b._pytgcalls.calls}"


async def case_shutdown_path(vc):
    """Contract — the SHUTDOWN path (vc_leave_all_tracked → wait_for →
    vc_leave_target per record) uses the owner backend per record."""
    w = World(vc)
    w.join_on(w.a_b, raw=1393246704)
    w.join_on(w.b_b, raw=1551122433)
    result = await vc.vc_leave_all_tracked(include_intentional=True)
    ok = (result.get("success") == 2 and result.get("left_count") == 2
          and not w.a_b._pytgcalls.calls and not w.b_b._pytgcalls.calls
          and not w.global_b._pytgcalls.api_log)
    return ok, (f"result={ {k: v for k, v in result.items() if k != 'results'} } "
                f"A_calls={len(w.a_b._pytgcalls.calls)} "
                f"B_calls={len(w.b_b._pytgcalls.calls)}")


CASES = [
    ("A", case_a), ("B", case_b), ("C", case_c), ("D", case_d),
    ("D2", case_d2), ("E", case_e), ("F", case_f), ("G", case_g),
    ("G2", case_g2), ("H", case_h), ("SHUTDOWN", case_shutdown_path),
]


def main() -> int:
    vc = import_voicechat()
    print("IMPORT: PASS — module body executed without NameError")
    failures = 0
    for cid, fn in CASES:
        try:
            ok, detail = asyncio.run(fn(vc))
        except Exception as exc:  # noqa: BLE001
            ok, detail = False, f"EXC {type(exc).__name__}: {exc}"
        status = "PASS" if ok else "FAIL"
        if not ok:
            failures += 1
        print(f"CASE {cid}: {status} — {detail}")
    print(f"SUMMARY: {len(CASES) - failures}/{len(CASES)} cases passed")
    return failures


if __name__ == "__main__":
    sys.exit(main())
