"""
v97.75 RUNTIME-DRIVEN FORENSIC FIX tests.

Root causes fixed in v97.75 (driven by REAL production runtime log — note 45):

  P0  Generation coexistence — _forcibly_cancel_telethon_tasks was only called
      INSIDE `except asyncio.TimeoutError:` (drain timeout path). On the happy
      path (drain succeeded), it was NEVER called → old Telethon background
      tasks survived into the next connect() → 2-3 generations coexisted.
      Runtime proof: task dumps showed Tasks 14-19 (Gen A) + 50-53/60-61 (Gen B)
      + 12958-13000 (Gen C) alive simultaneously, each generation = 6 tasks.
      Fix: make _forcibly_cancel_telethon_tasks UNCONDITIONAL + verify ALL 6
      tasks done() before connect(). If any survive → mark POISONED + abort.

  P0  PyTgCalls _on_frame handler accumulation — handler_method(_on_frame) was
      called on EVERY _vc_audio_capture_loop invocation. PyTgCalls has NO
      remove_handler API → old closures accumulated indefinitely. Each frame
      dispatched to N handlers → multiplied per-update processing cost.
      Runtime proof: 214-task explosion with 200+ pytgcalls
      _handle_mtproto_updates coroutines blocked on _chat_lock.acquire().
      Fix: WeakKeyDictionary idempotency guard — skip re-registration.

  P1  VC_RECONCILE_TIMEOUT cause misclassification — classifier used
      mtproto_get_client() (global primary) but vc_verify_target uses
      per-account client. If account client disconnected while global primary
      connected → mislabelled "rpc_timeout" (real cause: mtproto_disconnected).
      Runtime proof: VC_RECONCILE_TIMEOUT cause=rpc_timeout at log line 209.
      Fix: label honestly as "rpc_timeout_or_account_disconnect".

  P1  Join-all discovery get_entity bypassed mtproto_call_with_retry — bare
      client.get_entity with wait_for(timeout=10) but NO connectivity gate,
      FloodWait gate, or retry logic. Disconnected client could spin retrying.
      Runtime proof: vc_join_all_active appeared in EVERY EVENT_LOOP_LAG_HIGH.
      Fix: route through mtproto_call_with_retry.

  RUNTIME INSTRUMENTATION — TASK_DUMP_CATEGORIES categorizes tasks by type
      (telethon_background, pytgcalls_handle_mtproto_updates, vc_callback_workers,
      etc.) + TELETHON_GENERATION_COEXISTENCE alert when
      telethon_background > 6 + PYTGCALLS_UPDATE_EXPLOSION_DETECTED when
      handle_mtproto_updates > 20.

Tests are BOTH source-verification AND real behavioral asyncio tests.
"""
import asyncio
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")
_BOOTSTRAP = os.path.join(_BASE, "mediagrab_bot", "bootstrap.py")
_INIT = os.path.join(_BASE, "mediagrab_bot", "__init__.py")


# ---------------------------------------------------------------------------
# P0: Generation coexistence fix
# ---------------------------------------------------------------------------

class TestP0ForcedCancelUnconditional(unittest.TestCase):
    """P0: _forcibly_cancel_telethon_tasks must be called UNCONDITIONALLY
    (not just inside `except asyncio.TimeoutError:`)."""

    def test_forced_cancel_called_outside_except_block(self):
        with open(_MTPROTO) as f:
            src = f.read()
        # The forced-cancel call must be at the main function body level,
        # not inside an except block.
        idx = src.find("_client_poisoned = await _forcibly_cancel_telethon_tasks(client, label)")
        self.assertGreater(idx, 0, "unconditional forced-cancel call not found")
        # Verify it's NOT inside an except block by checking the preceding
        # context — it should follow the disconnected-future block, not an except.
        preceding = src[max(0, idx - 200):idx]
        self.assertNotIn("except asyncio.TimeoutError:", preceding.split("\n")[-3:],
                         "forced-cancel is still inside the except block")

    def test_forced_cancel_cancels_all_6_tasks(self):
        """v97.79: forced-cancel now uses CLIENT-SPECIFIC task snapshot
        (the v97.77/v97.78 asyncio.all_tasks approach was GLOBAL — unsafe for
        multi-account bots). This test verifies the v97.79 approach is in place."""
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("async def _forcibly_cancel_telethon_tasks")
        self.assertGreater(idx, 0)
        body = src[idx:idx + 3000]
        # v97.79: must use client-specific snapshot (not global asyncio.all_tasks)
        self.assertIn("_mediagrab_bg_tasks", body)
        self.assertIn("v97.79_client_specific_retirement", body)
        # v97.79: must NOT use asyncio.all_tasks as the PRIMARY mechanism
        self.assertNotIn("asyncio.all_tasks(loop)", body)

    def test_forced_cancel_verifies_all_tasks_done(self):
        """v97.79: after cancellation, tasks are verified via the client-specific snapshot."""
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("VERIFY all snapshotted tasks")
        self.assertGreater(idx, 0, "verification comment not found")
        body = src[idx:idx + 2000]
        self.assertIn("_survivors", body)
        self.assertIn("_poisoned = len(_survivors) > 0", body)
        self.assertIn("return _poisoned", body)

    def test_mtproto_stop_also_calls_forced_cancel(self):
        """v97.75: shutdown path must also force-cancel (not just reconnect path)."""
        with open(_MTPROTO) as f:
            src = f.read()
        # Find mtproto_stop's forced-cancel call
        self.assertIn(
            "await _forcibly_cancel_telethon_tasks(_mtproto_client, \"mtproto_stop\")",
            src,
        )

    def test_poisoned_client_aborts_reconnect(self):
        """v97.75: if forced-cancel reports poisoned, connect() must NOT be called."""
        with open(_MTPROTO) as f:
            src = f.read()
        idx = src.find("MTPROTO_RECONNECT_ABORTED")
        self.assertGreater(idx, 0)
        # The return False must precede the connect() call
        connect_idx = src.find("await asyncio.wait_for(client.connect()", idx)
        self.assertGreater(connect_idx, 0, "connect() call after abort not found")
        abort_block = src[idx:connect_idx]
        self.assertIn("return False", abort_block)


class TestP0ForcedCancelBehavioral(unittest.TestCase):
    """P0 behavioral: prove the forced-cancel pattern actually terminates
    all tasks before proceeding. Uses standalone coroutines (no telethon)."""

    def _run(self, coro):
        return asyncio.new_event_loop().run_until_complete(coro)

    def test_all_tasks_cancelled_and_verified_before_proceed(self):
        """Simulate the v97.75 pattern: 6 background tasks, disconnect,
        forced-cancel ALL 6, verify ALL done, then proceed."""
        tasks_created = []
        survivor_count = {"n": 0}

        async def bg_task(name, stuck=False):
            try:
                if stuck:
                    await asyncio.sleep(100)  # stuck
                else:
                    await asyncio.sleep(0.01)  # finishes quickly
            except asyncio.CancelledError:
                raise

        async def simulate_reconnect_v97_75():
            # Create 6 background tasks (simulating Telethon's 6)
            tasks = []
            for i in range(5):
                t = asyncio.ensure_future(bg_task(f"normal_{i}"))
                tasks.append(t)
            # 6th task is "stuck" (simulates _update_loop_task in get_diff)
            stuck = asyncio.ensure_future(bg_task("stuck", stuck=True))
            tasks.append(stuck)
            await asyncio.sleep(0.02)  # let normal ones finish

            # v97.75 pattern: forced-cancel ALL tasks + verify
            survivors = []
            for t in tasks:
                if not t.done():
                    t.cancel(msg="v97.75")
                    try:
                        await asyncio.wait_for(t, timeout=2.0)
                    except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                        pass
                    if not t.done():
                        survivors.append(t)
            survivor_count["n"] = len(survivors)
            # v97.75: if any survivors → abort (return False)
            if survivors:
                return False
            # Only proceed to "connect" if ALL tasks done
            all_done = all(t.done() for t in tasks)
            return all_done

        result = self._run(simulate_reconnect_v97_75())
        self.assertEqual(survivor_count["n"], 0,
                         "no tasks should survive forced cancel")
        self.assertTrue(result, "reconnect should proceed only after all tasks done")

    def test_stuck_task_triggers_poisoned_abort(self):
        """v97.75 behavioral: if a task survives forced cancel (done() returns
        False after cancel + wait_for), the client must be marked POISONED and
        reconnect aborted. Uses a mock task to simulate a stuck task without
        the event-loop cleanup issues of a truly immortal coroutine."""

        class MockStuckTask:
            """Simulates a Telethon task that's stuck in cancelling state —
            done() returns False even after cancel() + wait_for."""
            def __init__(self):
                self._cancelled = False
            def done(self):
                return False  # always "not done" — simulates stuck task
            def cancel(self, msg=None):
                self._cancelled = True
            def cancelling(self):
                return 1

        async def simulate_poisoned_reconnect():
            t = MockStuckTask()
            # Simulate the v97.75 forced-cancel + verify pattern
            if not t.done():
                t.cancel(msg="v97.75")
                # wait_for would timeout (simulated) — task is still not done
                pass
            poisoned = not t.done()
            return poisoned  # True = poisoned → abort reconnect

        result = asyncio.new_event_loop().run_until_complete(simulate_poisoned_reconnect())
        self.assertTrue(result, "stuck task (done()=False) must trigger POISONED + abort")


# ---------------------------------------------------------------------------
# P0: PyTgCalls handler idempotency guard
# ---------------------------------------------------------------------------

class TestP0PyTgCallsIdempotencyGuard(unittest.TestCase):
    """P0: _on_frame registration must be idempotent (skip re-registration)."""

    def test_weakkeydictionary_declared(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_PYTGCALLS_HANDLER_REGISTERED", src)
        self.assertIn("WeakKeyDictionary", src)

    def test_idempotency_guard_logic_present(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_already_registered = _PYTGCALLS_HANDLER_REGISTERED.get(pytgcalls_obj, False)", src)
        self.assertIn("VC_AUDIO_CAPTURE_SKIP_REREGISTER", src)
        self.assertIn("_PYTGCALLS_HANDLER_REGISTERED[pytgcalls_obj] = True", src)

    def test_behavioral_idempotency_guard(self):
        """Prove the WeakKeyDictionary guard prevents duplicate registration."""
        from weakref import WeakKeyDictionary
        registered = WeakKeyDictionary()
        call_count = {"n": 0}

        class FakePyTgCalls:
            def on_stream_data(self, handler):
                call_count["n"] += 1
                return True

        obj = FakePyTgCalls()
        # First registration
        if not registered.get(obj, False):
            obj.on_stream_data(lambda f: None)
            registered[obj] = True
        # Second registration (should be skipped)
        if not registered.get(obj, False):
            obj.on_stream_data(lambda f: None)
            registered[obj] = True
        # Third registration (should be skipped)
        if not registered.get(obj, False):
            obj.on_stream_data(lambda f: None)
            registered[obj] = True

        self.assertEqual(call_count["n"], 1,
                         "handler must be registered exactly once (got %d)" % call_count["n"])

    def test_weakkeydictionary_gcs_when_object_destroyed(self):
        """When the pytgcalls object is GC'd, the entry is automatically removed."""
        from weakref import WeakKeyDictionary
        import gc
        registered = WeakKeyDictionary()

        class FakePyTgCalls:
            pass

        obj = FakePyTgCalls()
        registered[obj] = True
        self.assertIn(obj, registered)
        del obj
        gc.collect()
        # WeakKeyDictionary should be empty now
        self.assertEqual(len(registered), 0,
                         "entry must be GC'd when pytgcalls object is destroyed")


# ---------------------------------------------------------------------------
# P1: Reconcile cause-classifier fix
# ---------------------------------------------------------------------------

class TestP1ReconcileClassifierFix(unittest.TestCase):
    """P1: classifier must not label as 'rpc_timeout' when the per-account
    client may be disconnected."""

    def test_no_bare_rpc_timeout_label(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        # The old mislabel "rpc_timeout" (when global primary connected) is gone
        idx = src.find("VC_RECONCILE_TIMEOUT chat_id=%s — classified UNKNOWN cause=%s")
        self.assertGreater(idx, 0)
        preceding = src[max(0, idx - 2500):idx]
        self.assertNotIn('_timeout_cls = "rpc_timeout"', preceding)
        self.assertIn("rpc_timeout_or_account_disconnect", preceding)


# ---------------------------------------------------------------------------
# P1: Join-all discovery get_entity routing
# ---------------------------------------------------------------------------

class TestP1JoinAllGetEntityRouted(unittest.TestCase):
    """P1: join-all discovery must route get_entity through mtproto_call_with_retry."""

    def test_get_entity_uses_mtproto_call_with_retry(self):
        """v97.75 contract: classification entity resolution must route
        through ROBUST retry machinery — never a bare, ungated
        ``client.get_entity(gid)``.

        v98.06 note (supersession, EXTENDED not weakened): the v98.06
        mandate (FIX-LL) ordered the classification resolution to route
        through ``resolve_vc_entity`` (cache → InputPeerChannel with the
        DB access_hash → 9-step resolve_entity_full → multi-account
        rotation) — the SAME machinery the join path uses — because the
        v97.75 ``mtproto_call_with_retry(client.get_entity, gid)`` form
        resolved the BARE positive id (Telethon maps bare ints to
        PeerUser → the false-PeerUser blacklist massacre of
        bot-diagnostic (18+).log: 169 VC_PEERUSER_DETECTED, 40 of them
        REAL joined VC channels). The v97.75 INTENT (no bare/ungated
        resolution; connectivity-gated retry machinery) is now satisfied
        by resolve_vc_entity's internal strategy chain + the 25s
        asyncio.wait_for bound (v98.05 FIX-GG pattern).
        """
        with open(_VOICECHAT) as f:
            src = f.read()
        idx = src.find("VC_JOIN_ALL_ENTITY_TIMEOUT")
        self.assertGreater(idx, 0)
        preceding = src[max(0, idx - 4000):idx]
        # v98.06: resolution routes through resolve_vc_entity (robust
        # machinery: cache + InputPeer + 9-step + account rotation).
        self.assertIn("resolve_vc_entity", preceding)
        # The original v97.75 guard is preserved and STRONGER: no bare
        # ungated get_entity anywhere in the classification path.
        self.assertNotIn("client.get_entity(gid), timeout=10.0", preceding)
        self.assertNotIn("client.get_entity, gid, retries=2", preceding)


# ---------------------------------------------------------------------------
# Runtime instrumentation
# ---------------------------------------------------------------------------

class TestRuntimeInstrumentation(unittest.TestCase):
    """v97.75: TASK_DUMP_CATEGORIES must categorize tasks + alert on
    generation coexistence + PyTgCalls explosion."""

    def test_task_dump_categories_present(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("TASK_DUMP_CATEGORIES", src)
        self.assertIn("telethon_background", src)
        self.assertIn("pytgcalls_handle_mtproto_updates", src)
        self.assertIn("vc_callback_workers", src)

    def test_generation_coexistence_alert_present(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("TELETHON_GENERATION_COEXISTENCE", src)
        self.assertIn("telethon_background_tasks=", src)

    def test_pytycalls_explosion_alert_present(self):
        with open(_BOOTSTRAP) as f:
            src = f.read()
        self.assertIn("PYTGCALLS_UPDATE_EXPLOSION_DETECTED", src)
        self.assertIn("handle_mtproto_updates_tasks=", src)


class TestVersionBumped(unittest.TestCase):
    def test_version_is_v97_92(self):
        with open(_INIT) as f:
            src = f.read()
        self.assertIn('__bot_version__ = "v99.11.1"', src)


if __name__ == "__main__":
    unittest.main()
