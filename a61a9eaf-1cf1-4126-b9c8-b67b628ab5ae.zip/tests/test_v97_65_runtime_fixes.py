"""
v97.65 regression tests — fixes against the actual v97.64 production log (note 37).

Runtime log evidence (note 37, 885 lines):
  - VC_CALLBACK_HANDLER_TIMEOUT: 0 (v97.62 fix confirmed)
  - VC_CALLBACK_HANDLER_SLOW: 0 (v97.62 fix confirmed)
  - EVENT_LOOP_LAG_CRITICAL: 1 (10.11s)
  - EVENT_LOOP_LAG_HIGH: 1 (5.78s)
  - VC_ENTITY_DEAD_LETTER: 79 (entity resolution failing for real targets)
  - VC_RECONCILE_TIMEOUT: 2 (classified UNKNOWN — no cause)
  - VC_JOIN_FAILED: 1 (TimeoutError — Telegram internal server issue)
  - InterdcCall: 3 (Telegram-side DC routing)
  - invalid call_id=0: 0 (v97.62 fix confirmed)
  - TypeError: 0 (v97.61 fix confirmed)
  - Cannot send requests while disconnected: 0 (v97.64 fix confirmed)
  - Unhandled exception on on_update: 0 (v97.64 fix confirmed)
  - DISCOVERY_SEARCH_PAGE_FAIL: 0 (v97.64 fix confirmed)

Root causes fixed:
  1. Join-All get_entity at line 7887 was a DIRECT call (no timeout) — blocked 30s+
  2. Distributed join get_entity at line 6992 was also direct (no timeout)
  3. VC_RECONCILE_TIMEOUT had no cause classification (just "UNKNOWN")
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestJoinAllGetEntityTimeout(unittest.TestCase):
    """P0: Join-All get_entity must be bounded with a timeout."""

    def test_join_all_get_entity_has_timeout(self):
        """The Join-All worker's get_entity must be wrapped in wait_for."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_ENTITY_TIMEOUT", src,
                      "Join-All must log VC_JOIN_ALL_ENTITY_TIMEOUT when get_entity times out")
        # The timeout must be 10s.
        self.assertIn("timeout=10.0", src,
                      "get_entity must be bounded with a 10s timeout")

    def test_distributed_join_get_entity_has_timeout(self):
        """The distributed join path's get_entity must also be bounded."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find the distributed join get_entity at line ~6992.
        self.assertIn("re_entity = await asyncio.wait_for", src,
                      "distributed join get_entity must be wrapped in wait_for")


class TestReconcileTimeoutClassification(unittest.TestCase):
    """P1: VC_RECONCILE_TIMEOUT must classify the cause."""

    def test_reconcile_timeout_has_cause(self):
        """The timeout log must include a cause classification."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("classified UNKNOWN cause=", src,
                      "reconcile timeout must include cause classification")
        self.assertIn("mtproto_disconnected", src,
                      "cause must include mtproto_disconnected")
        self.assertIn("rpc_timeout", src,
                      "cause must include rpc_timeout")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)
        self.assertIn("JOIN_ALL_BREAKER", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_callback_handler_sync_properties(self):
        """v97.62 callback handler fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        """v97.61 TypeError fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_entity_dead_letter_network_exclusion(self):
        """v97.64 entity dead-letter network exclusion must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_network_err", src)

    def test_dashboard_single_flight(self):
        """v97.64 dashboard single-flight must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src)

    def test_join_all_shutdown_no_force_clear(self):
        """v97.64 Join-All shutdown log fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("marking ORPHANED (NOT force-clearing state", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
