"""Regression tests for v98.03 forensic upgrade — production hardening
based on bot-diagnostic (16).log runtime evidence.

These tests verify the SOURCE-PROVEN + RUNTIME-CORRELATED defects fixed in
v98.03, addressing the four anomalies revealed by the v98.02 diagnostic log
(bot-diagnostic (16).log, 3373 lines, 591KB, ~3h soak):

  FIX-T (BUG #1 — VC_CORROBORATE_*=0 root cause, RUNTIME-PROVEN):
    bot-diagnostic (16).log showed ALL 70 VC_JOIN_EVIDENCE events logging
    `strength=container_only_no_call_id` — and 0 occurrences of any
    VC_CORROBORATE_FLOODWAIT / VC_CORROBORATE_CALL_GONE / VC_CORROBORATE_FAILED
    event. Root cause: in join() at voicechat.py:3510, v98.02 stored ONLY
    `self._current_access_hash = access_hash` after a successful join.
    `self._current_call_id` was NEVER assigned to a real value — it stayed
    None from __init__ (line 2427) forever. In verify_joined (line 4021),
    `real_call_id = getattr(self, "_current_call_id", None)` returned None
    for ALL post-join corroborations. Combined with the registry being EMPTY
    at the time verify_joined runs (register is called AFTER verify_joined in
    the join-all worker), the elif at line 4130 (`real_call_id and
    real_call_id != 0 and real_access_hash`) NEVER fired → fell to the else
    at line 4184 → logged `strength=container_only_no_call_id` for ALL 70
    joins. FIX-T sets BOTH `_current_call_id` AND `_current_chat_id` right
    after a confirmed join. Behavior is ADDITIVE.

  FIX-U (BUG #4 — VC_PARTICIPATION_REGISTER account_id=None,
  RUNTIME-PROVEN):
    bot-diagnostic (16).log showed ALL 70 VC_PARTICIPATION_REGISTER events
    with `account_id=None`, even when VC_BACKEND_OWNER_SET had just set
    account=acc_919006065076 for the same chat. Root cause: the
    `_vc_join_all_active_worker` call site at voicechat.py:10424 did NOT
    pass `account_id` to vc_registry_register, even though the rotation
    logic in join() (line 3165) had ALREADY set
    `backend._active_join_backend._account_id` to the rotated account.
    This broke per-account ownership tracking — any subsequent cleanup
    logic that looked up the owner by account_id would see None and could
    not distinguish which account's backend owned the join (cross-account
    destructive-operation risk mitigation depends on this field). FIX-U
    reads the rotated backend's account_id from backend._active_join_backend
    and passes it through (at 7 call sites: line 10424 join_all_primary,
    12479 watcher auto-join, 12644 deferred drain, 16054 discovery auto-join,
    25316 two-target probe A, 25347 two-target probe B). The registry stores
    account_id sticky-when-set, so a None call still preserves prior
    behavior.

  FIX-V (BUG #3 — VC_BACKEND_OWNER_SET empty account, RUNTIME-PROVEN):
    bot-diagnostic (16).log showed 26 of 75 VC_BACKEND_OWNER_SET events
    with `account=` (empty). Root cause: line 3171 used
    `getattr(_join_backend, "_account_id", "global")`. When _join_backend
    IS self (the global primary backend), `self._account_id` is "" (empty
    string — the attribute EXISTS with empty value). getattr returns ""
    (the actual value), NOT the "global" fallback — because the attribute
    exists. The "global" fallback was UNREACHABLE for this case. FIX-V uses
    `getattr(_join_backend, "_account_id", "") or "global"` so an
    empty/falsy _account_id falls back to the readable sentinel. Behavior
    for the rotated case (account=acc_919006065076) is unchanged (truthy
    value). Also applied to the parallel sites at VC_LEAVE_DELEGATED
    (line 3600) and VC_VERIFY_DELEGATED (line 4044).

  FIX-W (BUG #2 — VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS still fires,
  RUNTIME-PROVEN + SOURCE-PROVEN via PyTgCalls 2.x wheel):
    bot-diagnostic (16).log showed 4 occurrences of
    VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS, each claiming "v98.01 FIX-G:
    documented limitation". ROOT CAUSE: v98.01/v98.02 FIX-G probed for
    the WRONG callback names (`on_stream_end`, `on_call_end`, `on_killed`,
    `on_connection_state`, `on_connect`, `on_disconnect`) on the WRONG
    object (backend._pytgcalls — the GroupCallFactory). The real
    PyTgCalls 2.x API exposes EXACTLY TWO callback events —
    `on_network_status_changed` and `on_participant_list_updated` — on
    the PER-CALL GroupCall instance (created via
    GroupCallFactory.get_raw_group_call() / get_file_group_call() /
    get_device_group_call()), NOT on the factory itself. FIX-W rewrites
    _vc_register_lifecycle_callbacks to:
      (1) probe for the real `on_network_status_changed` decorator on
          the factory (rare in 2.x but safe);
      (2) probe for `add_handler` with the GroupCallAction.NETWORK_STATUS_CHANGED
          action sentinel;
      (3) register on per-chat GroupCall instances in
          backend._group_calls[chat_id] when the group_call_factory strategy
          is used (the only strategy with per-call instances in PyTgCalls 2.x);
      (4) emit an HONEST warning when NEITHER (1) NOR (2) NOR (3) registered
          any callback, with the actual reason (the strategy name + the
          correct PyTgCalls 2.x limitation), NOT the misleading "none of
          on_stream_end/..." message.
    A new helper `_vc_register_lifecycle_callbacks_for_chat(backend, chat_id)`
    is called from join() right after gc.start(chat_id) succeeds (only for
    the group_call_factory strategy). Limitation HONEST: the bot's production
    deployment uses the `play` strategy (PyTgCalls 0.0.x compatibility shim)
    which has NO per-call GroupCall instance — for this strategy the warning
    will STILL fire but with the correct reason. To enable real
    passive-disconnect callbacks, switch to the group_call_factory strategy
    (PyTgCalls 3.x) — a future migration beyond this fix's scope.

Each test below references the exact runtime evidence from
bot-diagnostic (16).log + the exact source location of the fix.

Honest scope: v98.03 does NOT claim to fix the play-strategy limitation
(operators must migrate to group_call_factory for real per-call callbacks);
v98.03 does NOT claim to make VC_CORROBORATE_* fire for the play strategy
(corroboration still fires correctly when self._current_call_id is set —
FIX-T makes it fire for ALL strategies where the join sets the call_id).
"""

from __future__ import annotations

import os
import unittest

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_BOT_DIR = os.path.join(_REPO_ROOT, "mediagrab_bot")


def _read(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:  # noqa: BLE001
        return ""


def _read_voicechat() -> str:
    return _read(os.path.join(_BOT_DIR, "voicechat.py"))


def _read_pipe() -> str:
    # v99: the canonical VC join pipeline module (source-structure
    # assertions for the join mechanics that moved there).
    return _read(os.path.join(_BOT_DIR, "vc_pipeline.py"))


def _read_init() -> str:
    return _read(os.path.join(_BOT_DIR, "__init__.py"))


def _read_bootstrap() -> str:
    return _read(os.path.join(_BOT_DIR, "bootstrap.py"))


# ============================================================================
# Version + deployment-identity markers
# ============================================================================

class TestVC803VersionBump(unittest.TestCase):
    """v98.03 must bump the version in __init__.py and bootstrap.py."""

    def setUp(self):
        self.init_src = _read_init()
        self.bootstrap_src = _read_bootstrap()

    def test_init_bot_version_is_v98_03(self):
        self.assertIn('__bot_version__ = "v99.11.1"', self.init_src)

    def test_bootstrap_deployment_identity_is_v98_03(self):
        self.assertIn("version={_v9812_pkg_version}", self.bootstrap_src)  # v99: derivation site


# ============================================================================
# FIX-T (BUG #1 — VC_CORROBORATE_*=0 root cause)
# ============================================================================

class TestVC803FixTCurrentCallIdAssignment(unittest.TestCase):
    """FIX-T: join() must set self._current_call_id AND self._current_chat_id
    after a successful join (was only setting _current_access_hash)."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_current_call_id_set_after_join_success(self):
        # The join() success path must assign self._current_call_id.
        # v99: the pipeline outcome carries the verified call identity.
        self.assertIn("v98.03 FIX-T", self.vc)
        self.assertIn("self._current_call_id = outcome.call_id", self.vc)

    def test_current_chat_id_set_after_join_success(self):
        # The join() success path must assign self._current_chat_id (marked).
        self.assertIn("self._current_chat_id = marked", self.vc)

    def test_fix_t_comment_explains_root_cause(self):
        # The comment must explain that v98.02 NEVER set _current_call_id.
        self.assertIn("NEVER assigned to a real value", self.vc)
        self.assertIn("VC_CORROBORATE_*=0", self.vc)

    def test_fix_t_correlates_with_runtime_evidence(self):
        # bot-diagnostic (16).log showed 70 joins with
        # strength=container_only_no_call_id. FIX-T must reference this.
        self.assertIn("container_only_no_call_id", self.vc)

    def test_fix_t_correlates_with_zero_corroboration(self):
        # The comment must mention VC_CORROBORATE_FLOODWAIT/CALL_GONE/FAILED = 0.
        self.assertIn("VC_CORROBORATE_FLOODWAIT/CALL_GONE/FAILED = 0", self.vc)


# ============================================================================
# FIX-U (BUG #4 — VC_PARTICIPATION_REGISTER account_id=None)
# ============================================================================

class TestVC803FixUAccountIdPropagation(unittest.TestCase):
    """FIX-U: vc_registry_register callers must read the rotated backend's
    account_id and pass it through (was None in v98.02)."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_join_all_primary_call_site_passes_account_id(self):
        # The _vc_join_all_active_worker call site at line ~10424 must pass
        # account_id read from backend._active_join_backend.
        self.assertIn("v98.03 FIX-U", self.vc)
        # Must read the rotated backend's account_id.
        # v99.06 FIX-3a test maintenance: the primary-mode join block now
        # dispatches through the round-robin-SELECTED account's backend
        # (_v9906_join_backend) instead of the worker-level global backend
        # — the register reads the account_id of the backend that ACTUALLY
        # did the join (the FIX-U intent, now correct for distributed
        # selection).  Same call shape, same propagation contract.
        # v99.10 FIX-F test maintenance: the scalar-pointer owner read was
        # replaced by the PER-CHAT ownership map (3-form aware) with the
        # scalar as fallback — the production 2026-09-20 11:24:09 register
        # wrote acc_918335829278 (the scalar "last rotated-to" pointer)
        # for a join acc_919006065076 actually owned. The FIX-U intent
        # (propagate the TRUE join owner's account_id) is preserved.
        self.assertIn(
            '_owner_be_for_reg = None\n'
            '                            for _v9910_rk in (_v9910_reg_cid, _v9910_reg_marked, _v9910_reg_raw):',
            self.vc,
        )
        self.assertIn(
            "_vc_active_join_backends_by_chat.get(_v9910_rk)",
            self.vc,
        )
        self.assertIn(
            '_owner_be_for_reg = getattr(\n'
            '                                    _v9906_join_backend, "_active_join_backend", None) \\\n'
            '                                    or _v9906_join_backend',
            self.vc,
        )
        self.assertIn(
            '_owner_aid_for_reg = getattr(_owner_be_for_reg, "_account_id", "") or ""',
            self.vc,
        )
        # v99.10 FIX-F: the register now uses the owner's MARKED form key
        # (no duplicate raw-form record with a potentially wrong owner).
        self.assertIn('await vc_registry_register(\n                                _v9910_reg_key, title=title,', self.vc)
        # Must pass account_id=... or None to vc_registry_register.
        self.assertIn('account_id=(_owner_aid_for_reg or None)', self.vc)

    def test_watcher_auto_join_call_site_passes_account_id(self):
        # The watcher auto-join call site (~line 12479) must pass account_id.
        self.assertIn('_owner_be_w = getattr(backend, "_active_join_backend", None) or backend', self.vc)
        self.assertIn('account_id=(_owner_aid_w or None)', self.vc)

    def test_deferred_drain_call_site_passes_account_id(self):
        # The deferred-drain call site (~line 12644) must pass account_id.
        self.assertIn('_owner_be_d = getattr(backend, "_active_join_backend", None) or backend', self.vc)
        self.assertIn('account_id=(_owner_aid_d or None)', self.vc)

    def test_discovery_auto_join_call_site_passes_account_id(self):
        # The discovery auto-join call site (~line 16054) must pass account_id.
        self.assertIn('_owner_be_disc = getattr(backend, "_active_join_backend", None) or backend', self.vc)
        self.assertIn('account_id=(_owner_aid_disc or None)', self.vc)

    def test_two_target_probe_call_sites_pass_account_id(self):
        # The two-target probe call sites (~25316, ~25347) must pass account_id.
        self.assertIn('_owner_be_probe_a = getattr(backend, "_active_join_backend", None) or backend', self.vc)
        self.assertIn('account_id=(_owner_aid_probe_a or None)', self.vc)
        self.assertIn('_owner_be_probe_b = getattr(backend, "_active_join_backend", None) or backend', self.vc)
        self.assertIn('account_id=(_owner_aid_probe_b or None)', self.vc)

    def test_fix_u_comment_explains_account_id_none_root_cause(self):
        # The comment must explain that v98.02 left account_id=None for ALL
        # 70 register events.
        self.assertIn("ALL 70 VC_PARTICIPATION_REGISTER events", self.vc)
        self.assertIn("account_id=None", self.vc)


# ============================================================================
# FIX-V (BUG #3 — VC_BACKEND_OWNER_SET empty account)
# ============================================================================

class TestVC803FixVEmptyAccountFallback(unittest.TestCase):
    """FIX-V: VC_BACKEND_OWNER_SET (and parallel sites) must use `or "global"`
    so an empty _account_id falls back to the readable sentinel."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_backend_owner_set_uses_or_global_fallback(self):
        # v99: VC_BACKEND_OWNER_SET is emitted by the pipeline with the
        # identity's account — which itself defaults to "global" via the
        # or-global fallback in VCAccountIdentity.resolve (the FIX-V
        # semantics: the owner account is never an empty string).
        pipe = _read_pipe()
        self.assertIn("VC_BACKEND_OWNER_SET chat_id=%s account=%s", pipe)
        self.assertIn('aid = str(account_id or getattr(backend, "_account_id", "") or "global")',
                      pipe, "the identity resolution must default to global")

    def test_active_join_backend_set_uses_or_global(self):
        # v99: the rotation ownership logs live in the canonical pipeline;
        # the or-"global" fallback (v98.03 FIX-V) is the value argument.
        pipe = _read_pipe()
        # the log format string is split across two physical lines —
        # assert both fragments + the or-global value argument.
        self.assertIn('"VC_ACTIVE_JOIN_BACKEND_SET account=%s "', pipe,
                      "VC_ACTIVE_JOIN_BACKEND_SET log line not found in vc_pipeline.py")
        idx = pipe.find('"VC_ACTIVE_JOIN_BACKEND_SET account=%s "')
        context = pipe[idx:idx + 600]
        self.assertIn('"(rotated from %s)', context,
                      "the rotated-from fragment must follow")
        self.assertIn('or "global"', context,
                      "VC_ACTIVE_JOIN_BACKEND_SET must keep the or-global fallback")

    def test_leave_delegated_uses_or_global(self):
        # The VC_LEAVE_DELEGATED log call must use `or "global"`.
        vc_lines = self.vc.split("\n")
        for i, line in enumerate(vc_lines):
            if "VC_LEAVE_DELEGATED to account=%s" in line:
                context = "\n".join(vc_lines[i:i + 3])
                self.assertIn('or "global"', context)
                return
        self.fail("VC_LEAVE_DELEGATED log line not found")

    def test_verify_delegated_uses_or_global(self):
        # The VC_VERIFY_DELEGATED debug log call must use `or "global"`.
        vc_lines = self.vc.split("\n")
        for i, line in enumerate(vc_lines):
            if "VC_VERIFY_DELEGATED chat_id=%s to account=%s" in line:
                context = "\n".join(vc_lines[i:i + 3])
                self.assertIn('or "global"', context)
                return
        self.fail("VC_VERIFY_DELEGATED log line not found")

    def test_fix_v_comment_explains_26_of_75(self):
        # The comment must explain the 26/75 empty-account occurrences.
        self.assertIn("26 of 75", self.vc)
        self.assertIn("VC_BACKEND_OWNER_SET events", self.vc)


# ============================================================================
# FIX-W (BUG #2 — VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS)
# ============================================================================

class TestVC803FixWRealPyTgCalls2xAPI(unittest.TestCase):
    """FIX-W: _vc_register_lifecycle_callbacks must use the real PyTgCalls 2.x
    API (on_network_status_changed / add_handler with NETWORK_STATUS_CHANGED),
    NOT the wrong on_stream_end/on_call_end/etc. names on the wrong object."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_fix_w_marker_present(self):
        self.assertIn("v98.03 FIX-W", self.vc)

    def test_real_pytgcalls_2x_callback_names_probed(self):
        # The function must probe on_network_status_changed (the real
        # PyTgCalls 2.x disconnect callback).
        self.assertIn("on_network_status_changed", self.vc)
        self.assertIn("_REAL_DISCONNECT_ATTRS", self.vc)
        self.assertIn('"on_network_status_changed"', self.vc)

    def test_old_misleading_callbacks_no_longer_in_function_body(self):
        # The function body must NOT contain the old pattern of iterating
        # over ("on_stream_end", "on_call_end", "on_killed") — those names
        # may appear in the docstring as historical explanation, but not
        # in the actual probe loop.
        # Find the function definition start.
        fn_start = self.vc.find("def _vc_register_lifecycle_callbacks(backend")
        self.assertGreater(fn_start, 0, "function not found")
        # Find the function body (up to the next top-level def).
        fn_end_candidates = []
        marker = 0
        while True:
            idx = self.vc.find("\ndef ", marker)
            if idx < 0 or idx > fn_start + 20000:
                break
            if idx > fn_start:
                fn_end_candidates.append(idx)
                if len(fn_end_candidates) > 0:
                    break
            marker = idx + 1
        # Function body ends at the next "def " at column 0 (or next function).
        fn_body = self.vc[fn_start:fn_end_candidates[0]] if fn_end_candidates else self.vc[fn_start:fn_start + 12000]

        # The actual probe loop must NOT iterate over the old names.
        # The old code had: `for _attr in ("on_stream_end", "on_call_end", "on_killed"):`
        # The new code has: `_REAL_DISCONNECT_ATTRS = ("on_network_status_changed",)`
        self.assertNotIn(
            'for _attr in ("on_stream_end", "on_call_end", "on_killed")',
            fn_body,
            "Old misleading callback iteration must be removed from function body",
        )
        self.assertNotIn(
            'for _attr in ("on_connection_state", "on_connect", "on_disconnect")',
            fn_body,
            "Old misleading connection-state callback iteration must be removed",
        )

    def test_per_chat_helper_function_exists(self):
        # The new _vc_register_lifecycle_callbacks_for_chat helper must exist.
        self.assertIn(
            "def _vc_register_lifecycle_callbacks_for_chat(backend: Any, chat_id: int) -> None:",
            self.vc,
        )

    def test_per_chat_helper_called_from_join(self):
        # v99: the join transport dispatch (the pipeline's ONE dispatch
        # point) must call the per-chat helper right after gc.start().
        self.assertIn("gc.start(chat_id)", self.vc)
        self.assertIn("_vc_register_lifecycle_callbacks_for_chat(self, chat_id)", self.vc)

    def test_factory_level_add_handler_probe(self):
        # The function must probe the factory for add_handler with the
        # GroupCallAction.NETWORK_STATUS_CHANGED action sentinel.
        self.assertIn("from pytgcalls.implementation.group_call import GroupCallAction", self.vc)
        self.assertIn("NETWORK_STATUS_CHANGED", self.vc)

    def test_per_chat_group_call_iteration(self):
        # The function must iterate over backend._group_calls to register
        # callbacks on each cached per-call GroupCall instance.
        self.assertIn('_group_calls = getattr(backend, "_group_calls", None)', self.vc)
        self.assertIn("for _gc_cid, _gc_instance in list(_group_calls.items())", self.vc)

    def test_honest_warning_includes_join_strategy(self):
        # The NO_LIFECYCLE_CALLBACKS warning must include the join_strategy
        # so operators can see WHY no callbacks are available.
        # Find the warning emit line.
        idx = self.vc.find("VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS — join_strategy=")
        self.assertGreater(idx, 0, "honest warning not found")
        # The warning must use %s with _join_strategy as the format arg.
        warning_block = self.vc[idx:idx + 800]
        self.assertIn("_join_strategy", warning_block)


# ============================================================================
# RUNTIME EVIDENCE CORRELATION — bot-diagnostic (16).log
# ============================================================================

class TestVC803RuntimeEvidenceCorrelation(unittest.TestCase):
    """v98.03 fixes must correlate with bot-diagnostic (16).log evidence."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_fix_t_correlates_with_70_join_evidence_events(self):
        # bot-diagnostic (16).log showed 70 VC_JOIN_EVIDENCE events with
        # strength=container_only_no_call_id. FIX-T must reference this.
        self.assertIn("70 joins", self.vc)

    def test_fix_u_correlates_with_70_register_events_none(self):
        # bot-diagnostic (16).log showed 70 VC_PARTICIPATION_REGISTER events
        # with account_id=None.
        self.assertIn("ALL 70 VC_PARTICIPATION_REGISTER events", self.vc)

    def test_fix_v_correlates_with_26_empty_account_events(self):
        # bot-diagnostic (16).log showed 26 of 75 VC_BACKEND_OWNER_SET events
        # with account= (empty).
        self.assertIn("26 of 75", self.vc)

    def test_fix_w_correlates_with_4_no_lifecycle_callbacks(self):
        # bot-diagnostic (16).log showed 4 occurrences of
        # VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS.
        # FIX-W must reference the "still fires" claim.
        self.assertIn("VC_PYTGCALLS_NO_LIFECYCLE_CALLBACKS still", self.vc)


# ============================================================================
# PRESERVED INVARIANTS — FIX-T/U/V/W must NOT weaken prior fixes
# ============================================================================

class TestVC803PreservedInvariants(unittest.TestCase):
    """v98.03 fixes are ADDITIVE — must preserve v97.30-v98.02 verbatim."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_fix_e_three_branches_preserved(self):
        # v98.00 FIX-E (Case A/B/C distinction in vc_verify_target) preserved.
        self.assertIn("v98.00 FIX-E Case A", self.vc)
        self.assertIn("v98.00 FIX-E Case B", self.vc)
        self.assertIn("v98.00 FIX-E Case C", self.vc)

    def test_fix_f_gid_assignment_preserved(self):
        # v98.00 FIX-F (gid assigned before FloodWait log) preserved.
        self.assertIn("v98.00 FIX-F", self.vc)

    def test_fix_l_targeted_absent_streak_preserved(self):
        # v98.02 FIX-L (targeted absent streak threshold) preserved.
        self.assertIn("v98.02 FIX-L", self.vc)
        self.assertIn("_VC_TARGETED_ABSENT_THRESHOLD", self.vc)

    def test_fix_m_corroboration_id_form_preserved(self):
        # v98.02 FIX-M (try both raw and marked forms in verify_joined) preserved.
        self.assertIn("v98.02 FIX-M", self.vc)
        self.assertIn("_marked_form", self.vc)
        self.assertIn("_raw_form", self.vc)

    def test_unknown_never_destructive_invariant_preserved(self):
        # The UNKNOWN never destructive invariant from v97.95/v98.00 is
        # still enforced.
        self.assertIn("UNKNOWN", self.vc)
        self.assertIn("never destructive", self.vc)

    def test_fix_w_preserves_unknown_evidence_behavior(self):
        # FIX-W must NOT change the UNKNOWN-evidence behavior for the
        # passive-disconnect path (transport_dead is UNKNOWN, not destructive).
        self.assertIn("UNKNOWN evidence, not destructive", self.vc)


# ============================================================================
# HONEST SCOPE — what v98.03 does NOT claim to fix
# ============================================================================

class TestVC803HonestScopeMarkers(unittest.TestCase):
    """v98.03 must honestly document what it does NOT fix."""

    def setUp(self):
        self.vc = _read_voicechat()

    def test_fix_w_documents_play_strategy_limitation(self):
        # FIX-W must document that the play strategy has NO per-call
        # GroupCall instances (operators must migrate to group_call_factory
        # for real callbacks).
        self.assertIn("play", self.vc)
        # The migration hint must be present.
        self.assertIn("switch to", self.vc)
        self.assertIn("group_call_factory", self.vc)

    def test_fix_t_does_not_break_container_only_path(self):
        # FIX-T must NOT remove the container_only_no_call_id else branch
        # (it's still the fallback when no call_id is available — e.g.,
        # when verify_joined is called for a chat whose join hasn't set
        # _current_call_id, like an old participation record).
        self.assertIn("container_only_no_call_id", self.vc)
        # The else branch must still exist (line 4184-4194 in v98.02 source).
        self.assertIn("No valid call_id to corroborate with", self.vc)

    def test_fix_u_preserves_sticky_when_set_semantics(self):
        # FIX-U must preserve the registry's "sticky-when-set" behavior —
        # a None account_id call must NOT erase a previously recorded owner.
        # The behavior is in vc_registry_register itself (not changed by
        # FIX-U), but the FIX-U comment must mention this.
        self.assertIn("sticky-when-set", self.vc)


# ============================================================================
# SOURCE COMPILE CHECK — voicechat.py must compile cleanly
# ============================================================================

class TestVC803SourceCompiles(unittest.TestCase):
    """voicechat.py + __init__.py + bootstrap.py must compile cleanly."""

    def test_voicechat_compiles(self):
        import py_compile
        py_compile.compile(
            os.path.join(_BOT_DIR, "voicechat.py"),
            doraise=True,
        )

    def test_init_compiles(self):
        import py_compile
        py_compile.compile(
            os.path.join(_BOT_DIR, "__init__.py"),
            doraise=True,
        )

    def test_bootstrap_compiles(self):
        import py_compile
        py_compile.compile(
            os.path.join(_BOT_DIR, "bootstrap.py"),
            doraise=True,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
