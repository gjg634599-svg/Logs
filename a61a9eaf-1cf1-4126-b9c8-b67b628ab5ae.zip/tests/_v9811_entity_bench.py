"""v98.11 §25 — PRODUCTION-LIKE controlled benchmark (MOCK, labeled).

Reproduces the bot-diagnostic (5).log world in the PRODUCTION client
topology (per-call GatedProxy + real-cluster registry — the shape whose
absence let the v98.10 convergence bug escape testing):

  * 46 entities, matching the (5).log count:
      20  foreign-hash   — acc_B owns the hash; the primary is a local
                           cache miss (the exact 9.3s/e entity pattern)
       8  stale-hash     — the primary's DB hash was rotated server-side;
                           the primary IS a dialog member (refresh path)
       6  valid-hash     — the primary's scoped hash is valid but the
                           Telethon local cache lacks the entity (S14)
       5  private        — ChannelPrivate for the primary, B accessible
       4  unresolvable   — nonexistent entities (bounded negative)
       3  b-only-no-hash — B-session members with no hash anywhere
                           (v98.11: honest LOCAL_MISS, no rotation)
    plus secondary-account resolution and already-owned-VC knowledge
    state (cycle-2 Step-0c routing models worker-level ownership).

  * Latency model (CONTROLLED/MOCK — NOT live Telegram):
      RPC round-trip  20 ms per mtproto_call_with_retry call
      dialogs scan   400 ms per iter_dialogs invocation (production
                     measured ~4-5s for a 300-dialog scan; compressed
                     10x for benchmark runtime — the RATIOS hold)

  * Measures per tree/cycle: total duration, avg + p95 resolution
    latency, RPC count, dialogs scans, rotations, resolutions, cache
    hits, failure counters.

  * Compares the v98.10 tree (--baseline PATH) against the v98.11 tree
    (the tree this file lives in).  All numbers are clearly labeled
    controlled/mock; no live-Telegram performance is claimed.

Usage:
    python3 tests/_v9811_entity_bench.py [--baseline <v98.10-tree>]
"""
from __future__ import annotations

import asyncio
import json
import statistics
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _v9810_entity_driver as drv  # noqa: E402
import _v9811_entity_driver as v11  # noqa: E402

MARKED_BASE = -1000000000000

# Controlled/mock latency parameters (S25: clearly labeled).
RPC_RTT_S = 0.020
DIALOGS_SCAN_S = 0.400

N_FOREIGN = 20
N_STALE = 8
N_VALID = 6
N_PRIVATE = 5
N_UNRESOLVABLE = 4
N_B_ONLY = 3
N = N_FOREIGN + N_STALE + N_VALID + N_PRIVATE + N_UNRESOLVABLE + N_B_ONLY

_FOREIGN_BASE = 3000000   # raw ids 3000000..3000019
_STALE_BASE = 3010000     # 3010000..3010007
_VALID_BASE = 3020000     # 3020000..3020005
_PRIVATE_BASE = 3030000   # 3030000..3030004
_UNRES_BASE = 3040000     # 3040000..3040003 (NOT in the world)
_B_ONLY_BASE = 3050000    # 3050000..3050002

_DIALOG_SCANS = [0]


def build_world():
    """The 46-entity production-shaped world (the (5).log mixture)."""
    W = drv.WORLD
    W.channels.clear()
    W.chats.clear()
    W.users.clear()
    W.sessions.clear()
    W.dialogs.clear()
    W.contacts.clear()
    v11.PRIVATE_FOR.clear()
    v11.FLOODWAIT_ON.clear()

    entities = []  # (marked, provided_hash, expected_resolvable)
    for i in range(N_FOREIGN):
        r = _FOREIGN_BASE + i
        W.add_channel(r, title=f"foreign-{i}",
                      accounts={"acc_B": 7000000 + i}, session=["acc_B"])
        entities.append((MARKED_BASE - r, 7000000 + i, True))
    for i in range(N_STALE):
        r = _STALE_BASE + i
        W.add_channel(r, title=f"stale-{i}",
                      accounts={"acc_PRIMARY": 7100000 + i},
                      session=["acc_PRIMARY"])
        # the DB hash is the ROTATED (stale) value:
        entities.append((MARKED_BASE - r, 9900000 + i, True))
    for i in range(N_VALID):
        r = _VALID_BASE + i
        W.add_channel(r, title=f"valid-{i}",
                      accounts={"acc_PRIMARY": 7200000 + i}, session=[])
        entities.append((MARKED_BASE - r, 7200000 + i, True))
    for i in range(N_PRIVATE):
        r = _PRIVATE_BASE + i
        W.add_channel(r, title=f"priv-{i}",
                      accounts={"acc_B": 7300000 + i}, session=["acc_B"])
        v11.PRIVATE_FOR[r] = {"acc_PRIMARY"}
        entities.append((MARKED_BASE - r, 7300000 + i, True))
    for i in range(N_UNRESOLVABLE):
        entities.append((MARKED_BASE - (_UNRES_BASE + i), 9500000 + i, False))
    for i in range(N_B_ONLY):
        r = _B_ONLY_BASE + i
        # hash-less for everyone; B is a session member.
        W.add_channel(r, title=f"bonly-{i}", accounts={}, session=["acc_B"])
        entities.append((MARKED_BASE - r, 0, None))  # v98.11: no rotation

    # The primary's dialogs contain its STALE entities (refresh source).
    W.dialogs["acc_PRIMARY"] = [
        drv.Channel(id=_STALE_BASE + i, title=f"stale-{i}",
                    access_hash=7100000 + i) for i in range(N_STALE)]
    W.dialogs["acc_B"] = [
        drv.Channel(id=_FOREIGN_BASE + i, title=f"foreign-{i}",
                    access_hash=7000000 + i) for i in range(N_FOREIGN)]
    return entities


def _latency_wrap(mt, raw_primary, raw_b):
    """Inject the controlled/mock latency into every RPC + dialogs scan."""
    orig = drv._dispatch_mtproto_call

    async def _slow(func, *args, **kw):
        await asyncio.sleep(RPC_RTT_S)
        return await orig(func, *args, **kw)

    mt.mtproto_call_with_retry = _slow

    for c in (raw_primary, raw_b):
        orig_iter = c.iter_dialogs

        def _slow_iter(limit=0, _oi=orig_iter):
            _DIALOG_SCANS[0] += 1

            async def _gen():
                await asyncio.sleep(DIALOGS_SCAN_S)
                async for d in _oi(limit):
                    yield d
            return _gen()
        c.iter_dialogs = _slow_iter


def _instrument_rotations(mt) -> None:
    orig = mt.resolve_across_accounts
    v11_rot = [0]

    async def _counting(chat_ref, *a, **kw):
        v11_rot[0] += 1
        return await orig(chat_ref, *a, **kw)

    mt.resolve_across_accounts = _counting
    return v11_rot


async def run_cycle(mt, raw_primary, entities, label) -> dict:
    """One classification-style cycle: resolve every entity on the
    primary (per-call proxies) with its DB hash."""
    drv.LEDGER.reset()
    _DIALOG_SCANS[0] = 0
    rot = getattr(mt, "_bench_rot", [0])
    rot[0] = 0
    lats = []
    resolved = 0
    cache_hits = 0
    t0 = time.monotonic()
    for marked, db_hash, _exp in entities:
        t_ent = time.monotonic()
        res = await mt.resolve_vc_entity(
            v11.fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=db_hash)
        lats.append((time.monotonic() - t_ent) * 1000.0)
        if res.get("ok"):
            resolved += 1
            if str(res.get("outcome", "")).startswith("RESOLVED_FROM"):
                cache_hits += 1
    total_ms = (time.monotonic() - t0) * 1000.0
    lats.sort()
    p95 = lats[int(len(lats) * 0.95) - 1 if len(lats) >= 20 else -1] \
        if lats else 0.0
    return {
        "label": label,
        "entities": len(entities),
        "resolved": resolved,
        "rpcs": drv.LEDGER.total(),
        "dialogs_scans": _DIALOG_SCANS[0],
        "rotations": rot[0],
        "cache_hits": cache_hits,
        "invalid_channel_object": drv.LEDGER.invalid_channel_object,
        "input_entity_miss": drv.LEDGER.input_entity_miss,
        "total_ms": round(total_ms, 1),
        "avg_ms": round(statistics.mean(lats), 1) if lats else 0.0,
        "p95_ms": round(p95, 1),
    }


async def run_tree(tree: str, tag: str) -> list[dict]:
    """Full protocol on ONE tree: 3 cycles + restart."""
    tmp = tempfile.mkdtemp(prefix=f"bench_{tag}_")
    Path(tmp, "data").mkdir(parents=True, exist_ok=True)
    drv.install_stubs_for_root(tmp, tree)
    mt = drv.load_real_mtproto_from_root(tree)

    # Production topology (works on BOTH trees; the v98.10 tree simply
    # lacks the proxy/_clients scope identification - the honest
    # reproduction of the production bug).
    raw_primary = drv.FakeClient("acc_PRIMARY", drv.WORLD)
    raw_b = drv.FakeClient("acc_B", drv.WORLD)
    cluster = v11.RealShapeCluster({"acc_PRIMARY": raw_primary, "acc_B": raw_b})
    mt._mtproto_client = None
    mt._userbot_cluster = cluster
    mt._cluster = cluster

    # Reset module state (works on BOTH trees; the v98.11-only
    # structures are guarded).
    if hasattr(drv, "_reset_module_state"):
        drv._reset_module_state(mt)
    mt._vc_entity_cache.clear()
    mt._v9810_access_state.clear()
    mt._v9810_hash_invalid.clear()
    if hasattr(mt, "_v9811_dialogs_index"):
        mt._v9811_dialogs_index.clear()
    for k in list(getattr(mt, "_v9810_resolution_stats", {}).keys()):
        mt._v9810_resolution_stats[k] = 0

    entities = build_world()
    _latency_wrap(mt, raw_primary, raw_b)
    mt._bench_rot = _instrument_rotations(mt)

    out = []
    out.append(await run_cycle(mt, raw_primary, entities, f"{tag}-cycle1"))
    out.append(await run_cycle(mt, raw_primary, entities, f"{tag}-cycle2"))
    out.append(await run_cycle(mt, raw_primary, entities, f"{tag}-cycle3"))

    # restart: flush + fresh module + fresh world
    try:
        await mt._flush_access_hash_persistence()
    except Exception:
        pass
    pfile = Path(getattr(mt, "_VC_ACCESS_HASH_FILE",
                         Path(tmp) / "data" / "vc_access_hashes.json"))
    root2 = str(pfile.parent.parent)
    drv.install_stubs_for_root(root2, tree)
    mt2 = drv.load_real_mtproto_from_root(tree)
    mt2._mtproto_client = None
    cluster2 = v11.RealShapeCluster(
        {"acc_PRIMARY": raw_primary, "acc_B": raw_b})
    mt2._userbot_cluster = cluster2
    mt2._cluster = cluster2
    entities = build_world()
    _latency_wrap(mt2, raw_primary, raw_b)
    mt2._bench_rot = _instrument_rotations(mt2)
    out.append(await run_cycle(mt2, raw_primary, entities,
                               f"{tag}-after-restart"))
    return out


async def main_async() -> int:
    baseline = None
    if "--baseline" in sys.argv:
        baseline = sys.argv[sys.argv.index("--baseline") + 1]

    results = []
    if baseline:
        results.extend(await run_tree(baseline, "v98.10"))
    dev_root = str(Path(__file__).resolve().parents[1])
    results.extend(await run_tree(dev_root, "v98.11"))

    for r in results:
        print(json.dumps(r))
    return 0


if __name__ == "__main__":
    print("CONTROLLED/MOCK benchmark (RPC RTT=20ms, dialogs scan=400ms; "
          "NOT live Telegram)")
    sys.exit(asyncio.run(main_async()))
