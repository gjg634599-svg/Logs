"""v99.10 — THE STABILITY-REPAIR SUITE (2026-09-20 production log).

Production evidence (bot-diagnostic.log 2026-09-20 11:09:41→11:41:52,
v99.09 build — the work tree's 9 module hashes match DEPLOYMENT_IDENTITY
exactly, so every signature below is reproducible in THIS source; THREE
process runs: pid=8 11:09:42→~11:24:16, pid=7 11:24:17→~11:36:46, pid=7
11:36:46→log end):

  RC-1   The process was SIGKILLed TWICE mid-join (11:24:16 after 866s,
         11:36:46 after 741s) with ZERO Python traceback — the kernel OOM
         killer. Every joined VC was lost simultaneously (the user's
         "while running VC, the account automatically leaves the VC").
         41× ``BlockingIOError: [Errno 11] Resource temporarily
         unavailable`` during PyTgCalls joins at ~34-64 concurrent joined
         VCs (FD census plateaued at 409/1024 — NOT fd exhaustion:
         EAGAIN errno 11 is native thread/socket-buffer allocation
         failure under cgroup memory pressure). Each REAL-stream join
         holds a native ntgcalls media pipeline (~4 UDP sockets measured:
         274 sockets / 64 joined ≈ 4.3 per VC + threads + SRTP/jitter
         buffers). The v99.09 classifier folded errno-11 into
         ``transient_dc`` → 3 retries in 6s (all failing — the allocator
         was starved) → TRANSPORT_FAILED + breaker failure records.
  RC-2   45× ``VC_STATUS_TARGET_LOOKUP reader=calls_container
         exc=RecursionError: maximum recursion depth exceeded`` —
         ``is_connected`` still had the single-form ownership lookup +
         UNGUARDED scalar delegation (the exact bug class v99.09 FIX-C
         eliminated in verify_joined): A._active_join_backend=B and
         B._active_join_backend=A → A→B→A→B… mutual recursion.
  RC-3   After each restart the bot sat DEAD IDLE: the interrupted
         Join-All run was marked interrupted but never auto-resumed;
         with auto-discovery admin-disabled (AUTO_DISCOVERY_SKIP
         effective_disabled source=db) coverage stayed active=0 for 5+
         minutes until a human re-triggered Join-All manually.
  RC-4   11:30:26 ``VC_JOIN_ALL_TERMINAL status=cancelled
         cancel_reason=circuit_breaker_floodwait`` — an ADMIN stop
         (CALLBACK vc:join_all_stop → JOIN_ALL_CANCEL_REQUEST
         reason=admin_stop_requested) reported with the STALE breaker
         reason from 11:28:33. The terminal evidence lied about who
         stopped the run.
  RC-5   11:24:08→11:24:09 (chat 3534017859): the pipeline registered
         the MARKED form under the TRUE owner (acc_919006065076), then
         the worker's confirm path re-registered the RAW gid under the
         scalar-pointer account (acc_918335829278) — a DUPLICATE
         registry record with the WRONG owner poisoning later
         owner-account resolution.

FIXES UNDER TEST (v99.10):
  FIX-A  is_connected: form-aware (raw/marked/basic) ownership lookup +
         one-hop delegation guard (``_v9910_delegated``) — mirrors
         v99.09 FIX-C. Recursion structurally dead.
  FIX-B  ``resource_pressure`` transport-error class (checked BEFORE
         transient_dc — "Resource temporarily unavailable" contains
         "temporarily unavailable") + ``VCResourcePressureError`` (a
         VCTransportError subclass) + ``is_resource_pressure_error``.
         Pipeline: NO retry, NO attempt-budget burn, NO breaker record.
  FIX-C  The shared process resource guard
         (``_vc_resource_pressure_state`` cached 10s /proc snapshot +
         ``_vc_resource_pressure_check`` env-tunable thresholds:
         VC_GUARD_MAX_RSS_MB=900, VC_GUARD_MAX_THREADS=350,
         VC_GUARD_MAX_JOINED=48, VC_GUARD_FD_RATIO=0.80). Pipeline
         pre-dispatch gate raises the defer error BEFORE any native
         allocation; the Join-All worker waits (10s poll,
         VC_JOIN_ALL_PRESSURE_MAX_WAIT=600s cap) instead of spawning
         into exhaustion.
  FIX-D  MEM_CENSUS on every logged heartbeat beat (rss_mb / threads /
         fd / joined_transports — thread-offloaded /proc read).
  FIX-E  Startup auto-resume of genuinely-interrupted runs (once per
         boot, 75s delay, admin-stop aware, guard aware,
         VC_JOIN_ALL_AUTO_RESUME=0 kill-switch).
  FIX-F  The worker's registry register resolves the owner from the
         PER-CHAT ownership map (3-form) and registers under the owner's
         MARKED form — exactly ONE record with the TRUE owner.
  FIX-G  The worker's CancelledError branch prefers the cancellation
         TOKEN's reason (admin_stop_requested) over any stale breaker
         reason — the terminal line no longer lies.
"""

import asyncio
import os
import sys
import tempfile
import types
import unittest
import inspect

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
_SRC = os.path.join(_ROOT, "mediagrab_bot")
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Reuse the v99.09 real-module loader (fake telethon stack + REAL
# voicechat/mtproto/config/db_layer sources).
from tests.test_v99_09_verification_repair import (  # noqa: E402
    _load_real, _marked, _ACC_A, _ACC_B)


def _read(path):
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


_VC = os.path.join(_SRC, "voicechat.py")
_PIPELINE = os.path.join(_SRC, "vc_pipeline.py")
_MTPROTO = os.path.join(_SRC, "mtproto.py")
_HANDLERS = os.path.join(_SRC, "handlers.py")
_INIT = os.path.join(_SRC, "__init__.py")


# ===========================================================================
# SECTION A — FIX-A: the is_connected mutual-recursion is structurally dead
# (mission Test C: calls_container resolver recursion — bounded, no false
# leave, no crash)
# ===========================================================================

class _IsConnectedBase(unittest.TestCase):
    """Two REAL PyTgCallsBackend instances exercising the REAL
    is_connected delegation logic (no stubs — the recursion path IS the
    code under test)."""

    def setUp(self):
        self.vw = _load_real()
        self._tmp = tempfile.TemporaryDirectory()
        self._acct_bak = os.environ.get("MG_ACCOUNTS_PATH")
        os.environ["MG_ACCOUNTS_PATH"] = os.path.join(self._tmp.name,
                                                      "accounts.json")
        self.vw._vc_active_join_backends_by_chat.clear()
        self.a = self.vw.PyTgCallsBackend(_ACC_A)
        self.b = self.vw.PyTgCallsBackend(_ACC_B)

    def tearDown(self):
        if self._acct_bak is None:
            os.environ.pop("MG_ACCOUNTS_PATH", None)
        else:
            os.environ["MG_ACCOUNTS_PATH"] = self._acct_bak
        self._tmp.cleanup()
        self.vw._vc_active_join_backends_by_chat.clear()

    def test_a1_production_pingpong_terminated(self):
        """THE production shape (11:15:10, chat 2333937461 raw form):
        mutual scalar pointers, empty per-chat dict. v99.09 recursed to
        the interpreter cap inside verify_joined's calls_container read;
        v99.10 terminates with exactly ONE delegation hop."""
        async def run():
            self.a._active_join_backend = self.b
            self.b._active_join_backend = self.a
            with self.assertLogs("mediagrab", level="DEBUG") as lg:
                res = await self.a.is_connected(2333937461)
            delegated = [l for l in lg.output if "VC_STATUS_DELEGATED" in l]
            self.assertEqual(len(delegated), 1,
                             "exactly one delegation hop — the one-hop "
                             "guard must cap the chain: %r" % (delegated,))
            self.assertIn(_ACC_B, delegated[0])
            # The DELEGATED backend answered LOCALLY (both backends are
            # not-started → False). UNKNOWN/False — never a crash, and
            # verify_joined treats it as UNKNOWN (non-destructive).
            self.assertFalse(res)
        asyncio.run(run())

    def test_a2_deep_mutual_chain_still_bounded(self):
        """A 3-backend ring A→B→C→A (worst-case ownership shape) still
        terminates: the delegated call never delegates again."""
        async def run():
            c = self.vw.PyTgCallsBackend("acc_333333333333")
            self.a._active_join_backend = self.b
            self.b._active_join_backend = c
            c._active_join_backend = self.a
            res = await self.a.is_connected(-1002333937461)
            self.assertFalse(res)
        asyncio.run(run())

    def test_a3_marked_form_dict_hit_delegates_directly(self):
        """Ownership recorded under the MARKED form (the pipeline's JOINING
        bookkeeping), caller passes the RAW Join-All form — the 3-form
        lookup must HIT (v99.09's single-form lookup always missed)."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[_marked(2333937461)] = self.b
            with self.assertLogs("mediagrab", level="DEBUG") as lg:
                res = await self.a.is_connected(2333937461)
            delegated = [l for l in lg.output if "VC_STATUS_DELEGATED" in l]
            self.assertEqual(len(delegated), 1)
            self.assertIn(_ACC_B, delegated[0])
            self.assertFalse(res)
        asyncio.run(run())

    def test_a4_self_owned_no_delegation(self):
        """Dict hit == self → verify locally, ZERO delegation (the local
        path returns False immediately for a not-started backend — no
        log is expected, which is itself the proof nothing delegated)."""
        async def run():
            self.vw._vc_active_join_backends_by_chat[_marked(2333937461)] = self.a
            res = await self.a.is_connected(2333937461)
            self.assertFalse(res)
        asyncio.run(run())

    def test_a5_signature_contract(self):
        """The guard kwarg is keyword-only and defaults False (zero
        call-site churn — every external is_connected(chat_id) caller is
        unchanged)."""
        sig = inspect.signature(self.a.is_connected)
        self.assertIn("_v9910_delegated", sig.parameters)
        self.assertTrue(
            sig.parameters["_v9910_delegated"].default is False)
        self.assertEqual(
            sig.parameters["_v9910_delegated"].kind,
            inspect.Parameter.KEYWORD_ONLY)


# ===========================================================================
# SECTION B — FIX-B: errno-11 is resource_pressure, NOT transient_dc
# (mission Test A: BlockingIOError during PyTgCalls join — account NOT
# punished, target requeued, no retry hammering)
# ===========================================================================

class TestBResourcePressureClassification(unittest.TestCase):

    def setUp(self):
        self.vw = _load_real()

    def test_b1_production_errno11_classified_resource_pressure(self):
        """THE production string (41× in the 2026-09-20 log). v99.09
        classified it transient_dc (retry hammering under a starved
        allocator); v99.10 returns resource_pressure."""
        cls = self.vw._vc_classify_join_transport_error(
            "BlockingIOError: [Errno 11] Resource temporarily unavailable")
        self.assertEqual(cls, "resource_pressure")

    def test_b2_wrapped_transport_message(self):
        cls = self.vw._vc_classify_join_transport_error(
            "VCTransportError: PyTgCalls join failed: "
            "[Errno 11] Resource temporarily unavailable")
        self.assertEqual(cls, "resource_pressure")

    def test_b3_other_native_allocation_failures(self):
        for msg in (
            "OSError: [Errno 12] Cannot allocate memory",
            "OSError: [Errno 23] Too many open files",
            "OSError: [Errno 24] Too many open files in system",
            "RuntimeError: can't start new thread",
            "OSError: [Errno 105] No buffer space available",
        ):
            self.assertEqual(
                self.vw._vc_classify_join_transport_error(msg),
                "resource_pressure", msg)

    def test_b4_server_side_temporarily_unavailable_still_transient(self):
        """A Telegram/server 'Service temporarily unavailable' WITHOUT an
        errno-11 signature stays transient_dc (the v99.09 semantics for
        genuine DC conditions are preserved)."""
        cls = self.vw._vc_classify_join_transport_error(
            "Service temporarily unavailable — please retry")
        self.assertEqual(cls, "transient_dc")

    def test_b5_floodwait_and_interdc_unchanged(self):
        self.assertEqual(self.vw._vc_classify_join_transport_error(
            "FloodWaitError: A wait of 150 seconds is required"),
            "floodwait")
        self.assertEqual(self.vw._vc_classify_join_transport_error(
            "InterdcCallErrorError: Error while communicating with DC 5"),
            "transient_dc")

    def test_b6_is_resource_pressure_error_recogniser(self):
        """The recogniser: type-based (VCResourcePressureError), errno-based
        (real OSError 11), and text-based (the production message)."""
        f = self.vw.is_resource_pressure_error
        self.assertTrue(f(self.vw.VCResourcePressureError("blocked")))
        self.assertTrue(f(BlockingIOError(11, "Resource temporarily "
                                             "unavailable")))
        self.assertTrue(f(Exception(
            "PyTgCalls join failed: [Errno 11] Resource temporarily "
            "unavailable")))
        self.assertFalse(f(Exception("A wait of 150 seconds is required")))
        self.assertFalse(f(Exception("Invalid channel object")))

    def test_b7_exception_hierarchy(self):
        """VCResourcePressureError IS a VCTransportError — every existing
        except-site keeps catching it (zero call-site churn)."""
        self.assertTrue(issubclass(self.vw.VCResourcePressureError,
                                   self.vw.VCTransportError))


# ===========================================================================
# SECTION C — FIX-C: the pipeline pre-dispatch guard + no-retry defer
# (mission §16: "prevents starting another join when the system is near
# exhaustion and instead queues the target")
# ===========================================================================

class TestCPipelineGuard(unittest.TestCase):
    """Harness-level: the REAL vc_pipeline against a fake voicechat whose
    guard is BLOCKED — the join must defer BEFORE any transport dispatch."""

    def setUp(self):
        sys.path.insert(0, os.path.join(_ROOT, "tests"))
        try:
            from tests.test_v99_00_vc_pipeline import (
                Harness, FakeBackend, FakeClient, _install_fake_telethon,
                _mk_globals_backend)
        finally:
            sys.path.pop(0)
        self._install_fake_telethon = _install_fake_telethon
        self.Harness = Harness
        self.FakeBackend = FakeBackend
        self._mk_globals_backend = _mk_globals_backend
        os.environ["VC_JOIN_PIPELINE_MAX_ATTEMPTS"] = "2"
        os.environ["VC_JOIN_PIPELINE_MAX_ACCOUNTS"] = "2"
        os.environ["VC_JOIN_ENTITY_RETRIES"] = "2"
        os.environ["VC_JOIN_TG_VERIFY_ATTEMPTS"] = "1"
        os.environ["VC_JOIN_TG_VERIFY_BUDGET"] = "2"
        os.environ["VC_JOIN_DC_MAX_RETRIES"] = "1"
        os.environ["VC_JOIN_DC_BACKOFF_BASE"] = "0.01"
        os.environ["VC_JOIN_RECOVERY_BACKOFF_BASE"] = "0.01"
        os.environ["VC_MULTI_JOIN_TIMEOUT"] = "5"
        self.h = Harness()
        self.backend, self.client = _mk_globals_backend()
        try:
            self.h.vc_pipeline_mod._null_stream_suppress_reset_for_tests()
        except AttributeError:
            pass
        # keep the guard OUT of the way for tests that don't set it
        self.h.fake_voicechat._vc_resource_pressure_check = (
            lambda **kw: (False, ""))

    def tearDown(self):
        for k in ("VC_JOIN_PIPELINE_MAX_ATTEMPTS", "VC_JOIN_PIPELINE_MAX_ACCOUNTS",
                  "VC_JOIN_ENTITY_RETRIES", "VC_JOIN_TG_VERIFY_ATTEMPTS",
                  "VC_JOIN_TG_VERIFY_BUDGET", "VC_JOIN_DC_MAX_RETRIES",
                  "VC_JOIN_DC_BACKOFF_BASE", "VC_JOIN_RECOVERY_BACKOFF_BASE",
                  "VC_MULTI_JOIN_TIMEOUT"):
            os.environ.pop(k, None)

    def _run_join(self):
        return asyncio.run(self.h.run_vc_join(
            self.backend, 1941982944, call_id=-9150000000000000001,
            access_hash=555, muted=True, account_id=""))

    def test_c1_guard_blocks_before_dispatch(self):
        """Guard blocked → the resource-pressure error is raised BEFORE
        the transport dispatch (ZERO native allocations attempted)."""
        self.h.fake_voicechat._vc_resource_pressure_check = (
            lambda **kw: (True, "rss_mb=999>=VC_GUARD_MAX_RSS_MB(900)"))
        with self.assertLogs("mediagrab", level="WARNING") as lg:
            with self.assertRaises(self.h.vc_pipeline_mod.__dict__.get(
                    "_v9910_make_resource_pressure_error") and Exception) as cm:
                self._run_join()
        self.assertTrue(self.h.vc_pipeline_mod.is_resource_pressure_text(str(cm.exception))
                        if hasattr(self.h.vc_pipeline_mod,
                                   "is_resource_pressure_text") else
                        "resource pressure" in str(cm.exception))
        # ZERO dispatches — the whole point of the pre-dispatch guard.
        self.assertEqual(self.backend.dispatches, [])
        blocked_logs = [l for l in lg.output if "VC_RESOURCE_PRESSURE" in l]
        self.assertTrue(blocked_logs, "the VC_RESOURCE_PRESSURE marker must "
                                      "be emitted with chat context")

    def test_c2_guard_passes_join_proceeds(self):
        """Guard clear → the join proceeds exactly as before (no behavior
        change when resources are healthy)."""
        self.h.verify_sequence = ["present"]
        self._run_join()
        self.assertEqual(len(self.backend.dispatches), 1)

    def test_c3_errno11_inflight_no_retry_hammer(self):
        """THE production scenario (11:34:16→11:34:22): dispatch raises
        BlockingIOError errno-11. v99.09 retried 3× in 6s (all failing);
        v99.10 raises the defer error after the FIRST failure — no retry
        under a starved allocator."""
        self.backend.dispatch_errors = [
            BlockingIOError(11, "Resource temporarily unavailable"),
            BlockingIOError(11, "Resource temporarily unavailable"),
            BlockingIOError(11, "Resource temporarily unavailable"),
        ]
        with self.assertRaises(Exception) as cm:
            self._run_join()
        self.assertIn("resource pressure", str(cm.exception))
        # EXACTLY ONE dispatch attempt (v99.09: three).
        self.assertEqual(len(self.backend.dispatches), 1)

    def test_c4_guard_unavailable_never_blocks(self):
        """A (test/harness) voicechat WITHOUT the guard symbol skips the
        check — the join path must never break on guard infrastructure."""
        del self.h.fake_voicechat._vc_resource_pressure_check
        self.h.verify_sequence = ["present"]
        self._run_join()
        self.assertEqual(len(self.backend.dispatches), 1)


# ===========================================================================
# SECTION D — FIX-C: the guard's threshold evaluation (env-tunable)
# ===========================================================================

class TestDGuardThresholds(unittest.TestCase):

    def setUp(self):
        self.vw = _load_real()

    def _set_state(self, **kw):
        st = {"available": True, "rss_kb": 100 * 1024, "threads": 40,
              "fd_total": 50, "fd_soft": 1024, "joined_transports": 2}
        st.update(kw)
        self.vw._vc_resource_state_cache["ts"] = 9999999999.0
        self.vw._vc_resource_state_cache["data"] = st

    def _clean_env(self):
        for k in ("VC_GUARD_MAX_RSS_MB", "VC_GUARD_MAX_THREADS",
                  "VC_GUARD_MAX_JOINED", "VC_GUARD_FD_RATIO"):
            os.environ.pop(k, None)

    def tearDown(self):
        self._clean_env()

    def test_d1_healthy_state_not_blocked(self):
        self._clean_env()
        self._set_state()
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertFalse(blocked)

    def test_d2_rss_threshold_blocks(self):
        self._clean_env()
        self._set_state(rss_kb=999 * 1024)
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("rss_mb", why)

    def test_d3_threads_threshold_blocks(self):
        self._clean_env()
        self._set_state(threads=400)
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("threads", why)

    def test_d4_joined_transports_threshold_blocks(self):
        """THE production shape: ~60 concurrent joined VCs. Default cap 48
        → blocked (the 2026-09-20 OOM ceiling was ~60)."""
        self._clean_env()
        self._set_state(joined_transports=60)
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("joined_transports", why)

    def test_d5_fd_ratio_blocks(self):
        self._clean_env()
        self._set_state(fd_total=900, fd_soft=1024)
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("fd_total", why)

    def test_d6_env_overrides_respected(self):
        """Operator tuning: VC_GUARD_MAX_JOINED=200 → 60 joined is fine;
        VC_GUARD_MAX_RSS_MB=50 → a 100MB process blocks."""
        os.environ["VC_GUARD_MAX_JOINED"] = "200"
        self._set_state(joined_transports=60)
        blocked, _ = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertFalse(blocked)
        self._clean_env()
        os.environ["VC_GUARD_MAX_RSS_MB"] = "50"
        self._set_state()
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("rss_mb", why)

    def test_d7_state_snapshot_fields(self):
        """The /proc snapshot exposes every metric the mission §16
        observability list requires (fds, threads, joined transports)."""
        st = self.vw._vc_resource_pressure_state(force=True)
        self.assertTrue(st.get("available"))
        self.assertGreater(st.get("rss_kb", 0), 0)
        self.assertGreater(st.get("threads", 0), 0)
        self.assertGreater(st.get("fd_total", 0), 0)
        self.assertIn("joined_transports", st)

    def test_d8_guard_cache_ttl(self):
        """The snapshot is cached (10s) — per-join guard checks add no
        measurable overhead (mission §9: no event-loop lag). Proof: a
        forged UNHEALTHY cache is served verbatim WITHOUT force (no
        /proc re-read — the real /proc values of THIS test process are
        healthy, so a blocked verdict proves the cache was used)."""
        fake = {"available": True, "rss_kb": 999 * 1024, "threads": 7,
                "fd_total": 11, "fd_soft": 1024, "joined_transports": 3}
        self.vw._vc_resource_state_cache["ts"] = 9999999999.0
        self.vw._vc_resource_state_cache["data"] = dict(fake)
        served = self.vw._vc_resource_pressure_state()
        self.assertEqual(served, fake)
        blocked, why = self.vw._vc_resource_pressure_check(quiet=True)
        self.assertTrue(blocked)
        self.assertIn("rss_mb", why)


# ===========================================================================
# SECTION E — FIX-E: startup auto-resume of interrupted runs
# (mission Test D-adjacent: "Recovery must happen automatically without
# requiring a bot restart" + §14 "Only explicit user stop should
# permanently cancel the operation")
# ===========================================================================

class TestEAutoResume(unittest.TestCase):

    def setUp(self):
        self.vw = _load_real()
        self._tmp = tempfile.TemporaryDirectory()
        self._acct_bak = os.environ.get("MG_ACCOUNTS_PATH")
        os.environ["MG_ACCOUNTS_PATH"] = os.path.join(self._tmp.name,
                                                      "accounts.json")
        os.environ.pop("VC_JOIN_ALL_AUTO_RESUME", None)
        self.vw._v9910_auto_resume_done = False
        self.scheduled = []
        self._orig_create = self.vw.supervised_create_task

        def _capture(coro, *, name=""):
            self.scheduled.append((name, coro))
            coro.close()  # do not actually run the 75s sleep
            return None
        self.vw.supervised_create_task = _capture

        class _FakeCkpt:
            def __init__(self, latest):
                self.latest = latest
                self.marked = []
            async def load_latest_incomplete_run(self):
                return self.latest
            async def mark_interrupted(self, run_id, reason="interrupted"):
                self.marked.append((run_id, reason))
        self._FakeCkpt = _FakeCkpt
        self._orig_ckpt = self.vw._vc_join_all_checkpoint

    def tearDown(self):
        self.vw.supervised_create_task = self._orig_create
        self.vw._vc_join_all_checkpoint = self._orig_ckpt
        self.vw._v9910_auto_resume_done = False
        if self._acct_bak is None:
            os.environ.pop("MG_ACCOUNTS_PATH", None)
        else:
            os.environ["MG_ACCOUNTS_PATH"] = self._acct_bak
        os.environ.pop("VC_JOIN_ALL_AUTO_RESUME", None)
        self._tmp.cleanup()

    def test_e1_interrupted_run_schedules_auto_resume(self):
        """THE production shape (11:36:49: run 20260920113035-cb13f13a
        processed=21/57 marked interrupted, then DEAD IDLE): a genuinely
        interrupted run now schedules exactly one auto-resume."""
        ckpt = self._FakeCkpt({
            "run_id": "20260920113035-cb13f13a",
            "terminal_status": "",
            "cancel_reason": "",
            "processed": 21, "total_targets": 57,
        })
        self.vw._vc_join_all_checkpoint = ckpt
        with self.assertLogs("mediagrab", level="INFO") as lg:
            asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(ckpt.marked,
                         [("20260920113035-cb13f13a",
                           "bot_restart_interrupted")])
        self.assertEqual(len(self.scheduled), 1)
        self.assertEqual(self.scheduled[0][0], "vc_join_all_auto_resume")
        self.assertTrue(any("VC_JOIN_ALL_STARTUP_RECOVERY" in l
                            for l in lg.output))

    def test_e2_admin_stopped_never_auto_resumed(self):
        """A run whose pre-mark cancel_reason shows an admin/user stop is
        NEVER auto-resumed (mission §14: explicit user stop is the only
        permanent cancel)."""
        ckpt = self._FakeCkpt({
            "run_id": "r1", "terminal_status": "",
            "cancel_reason": "admin_stop_requested",
            "processed": 3, "total_targets": 10,
        })
        self.vw._vc_join_all_checkpoint = ckpt
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(self.scheduled, [])
        self.assertEqual(ckpt.marked, [("r1", "bot_restart_interrupted")])

    def test_e3_env_kill_switch(self):
        os.environ["VC_JOIN_ALL_AUTO_RESUME"] = "0"
        ckpt = self._FakeCkpt({
            "run_id": "r2", "terminal_status": "", "cancel_reason": "",
            "processed": 3, "total_targets": 10,
        })
        self.vw._vc_join_all_checkpoint = ckpt
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(self.scheduled, [])

    def test_e4_fully_processed_run_not_resumed(self):
        ckpt = self._FakeCkpt({
            "run_id": "r3", "terminal_status": "", "cancel_reason": "",
            "processed": 10, "total_targets": 10,
        })
        self.vw._vc_join_all_checkpoint = ckpt
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(self.scheduled, [])

    def test_e5_once_per_boot(self):
        ckpt = self._FakeCkpt({
            "run_id": "r4", "terminal_status": "", "cancel_reason": "",
            "processed": 1, "total_targets": 10,
        })
        self.vw._vc_join_all_checkpoint = ckpt
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(len(self.scheduled), 1)

    def test_e6_no_incomplete_run_no_schedule(self):
        ckpt = self._FakeCkpt(None)
        self.vw._vc_join_all_checkpoint = ckpt
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertEqual(self.scheduled, [])
        self.assertEqual(ckpt.marked, [])


# ===========================================================================
# SECTION F — FIX-E: the delayed resume coroutine's behavior
# ===========================================================================

class TestFDelayedResumeCoroutine(unittest.TestCase):
    """Exercises the captured auto-resume coroutine end-to-end (with the
    75s sleep stubbed + start/guard captured)."""

    def setUp(self):
        self.vw = _load_real()
        self._tmp = tempfile.TemporaryDirectory()
        self._acct_bak = os.environ.get("MG_ACCOUNTS_PATH")
        os.environ["MG_ACCOUNTS_PATH"] = os.path.join(self._tmp.name,
                                                      "accounts.json")
        os.environ.pop("VC_JOIN_ALL_AUTO_RESUME", None)
        self.vw._v9910_auto_resume_done = False
        self.captured = None
        self._orig_create = self.vw.supervised_create_task

        def _capture(coro, *, name=""):
            self.captured = coro  # keep it runnable
            return None
        self.vw.supervised_create_task = _capture

        class _FakeCkpt:
            async def load_latest_incomplete_run(self):
                return {"run_id": "run-X", "terminal_status": "",
                        "cancel_reason": "", "processed": 1,
                        "total_targets": 5}
            async def mark_interrupted(self, run_id, reason="interrupted"):
                pass
        self.vw._vc_join_all_checkpoint = _FakeCkpt()
        self._orig_ckpt = self.vw._vc_join_all_checkpoint
        # fast sleep + captured start + captured guard
        self._orig_sleep = asyncio.sleep
        self.starts = []
        self._orig_start = self.vw.vc_join_all_active_start

        async def _fake_start(*, resume_run_id=""):
            self.starts.append(resume_run_id)
            return "resumed"
        self.vw.vc_join_all_active_start = _fake_start
        self._orig_guard = self.vw._vc_resource_pressure_check
        self.guard_result = (False, "")

        def _fake_guard(**kw):
            return self.guard_result
        self.vw._vc_resource_pressure_check = _fake_guard
        self._orig_worker = self.vw._vc_join_all_worker
        self.vw._vc_join_all_worker = None

    def tearDown(self):
        self.vw.supervised_create_task = self._orig_create
        self.vw._vc_join_all_checkpoint = self._orig_ckpt
        self.vw.vc_join_all_active_start = self._orig_start
        self.vw._vc_resource_pressure_check = self._orig_guard
        self.vw._vc_join_all_worker = self._orig_worker
        self.vw._v9910_auto_resume_done = False
        if self._acct_bak is None:
            os.environ.pop("MG_ACCOUNTS_PATH", None)
        else:
            os.environ["MG_ACCOUNTS_PATH"] = self._acct_bak
        self._tmp.cleanup()

    def test_f1_resume_fires_after_delay(self):
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.assertIsNotNone(self.captured)

        async def _fast_sleep(seconds, *a, **kw):
            self.assertEqual(seconds, 75.0)
            return None
        asyncio.sleep = _fast_sleep
        try:
            with self.assertLogs("mediagrab", level="INFO") as lg:
                asyncio.run(self.captured)
        finally:
            asyncio.sleep = self._orig_sleep
        self.assertEqual(self.starts, ["run-X"])
        self.assertTrue(any("VC_JOIN_ALL_AUTO_RESUME run_id=run-X" in l
                            for l in lg.output))

    def test_f2_pressure_defers_the_resume(self):
        asyncio.run(self.vw.vc_join_all_startup_recovery())
        self.guard_result = (True, "rss_mb=999>=900")

        async def _fast_sleep(*a, **kw):
            return None
        asyncio.sleep = _fast_sleep
        try:
            with self.assertLogs("mediagrab", level="WARNING") as lg:
                asyncio.run(self.captured)
        finally:
            asyncio.sleep = self._orig_sleep
        self.assertEqual(self.starts, [])
        self.assertTrue(any("VC_JOIN_ALL_AUTO_RESUME_DEFERRED" in l
                            for l in lg.output))


# ===========================================================================
# SECTION G — FIX-F/G + FIX-D: source contracts (the worker register
# owner/form, the terminal cancel-reason override, MEM_CENSUS, the
# worker pressure wait, and every new marker)
# ===========================================================================

class TestGSourceContracts(unittest.TestCase):

    def setUp(self):
        self.vc = _read(_VC)
        self.pipe = _read(_PIPELINE)
        self.handlers = _read(_HANDLERS)

    def test_g1_register_uses_marked_key_and_per_chat_owner(self):
        """FIX-F: the worker's register resolves the owner from the
        per-chat ownership map (3-form) and registers under the MARKED
        form — no duplicate raw-form record with a wrong owner."""
        self.assertIn("_v9910_reg_key = _v9910_reg_marked "
                      "if _v9910_reg_marked else gid", self.vc)
        self.assertIn(
            "for _v9910_rk in (_v9910_reg_cid, _v9910_reg_marked, "
            "_v9910_reg_raw):", self.vc)
        self.assertIn("await vc_registry_register(\n"
                      "                                _v9910_reg_key, "
                      "title=title,", self.vc)

    def test_g2_terminal_prefers_token_reason(self):
        """FIX-G: the CancelledError branch reads _token.reason and it
        OVERRIDES any stale breaker reason (the 11:30:26 mislabel)."""
        self.assertIn('_v9910_tok_reason = str(getattr(_token, "reason", '
                      '"") or "")', self.vc)
        self.assertIn("if _v9910_tok_reason:\n"
                      "            _cancel_reason = _v9910_tok_reason",
                      self.vc)

    def test_g3_worker_pressure_wait_present(self):
        """FIX-C: the worker's target loop has the resource-pressure wait
        (10s poll, env cap, cancellation-safe, checkpoint preserved)."""
        self.assertIn("VC_JOIN_ALL_RESOURCE_PRESSURE_WAIT", self.vc)
        self.assertIn("VC_JOIN_ALL_PRESSURE_MAX_WAIT", self.vc)
        self.assertIn("cooperative_stop_during_pressure_wait", self.vc)
        self.assertIn("VC_JOIN_ALL_RESOURCE_PRESSURE_TIMEOUT", self.vc)

    def test_g4_worker_defer_branch_before_transport_error(self):
        """The dedicated except VCResourcePressureError branch precedes
        except VCTransportError (subclass first) and defers WITHOUT a
        breaker record."""
        defer_idx = self.vc.find("except VCResourcePressureError as exc:")
        transport_idx = self.vc.find("except VCTransportError as exc:")
        self.assertGreater(defer_idx, -1)
        self.assertGreater(transport_idx, -1)
        self.assertLess(defer_idx, transport_idx)
        defer_block = self.vc[defer_idx:defer_idx + 2400]
        self.assertIn("deferred_resource_pressure", defer_block)
        self.assertNotIn("record_failure", defer_block)

    def test_g5_mem_census_on_heartbeat(self):
        """FIX-D: MEM_CENSUS fields on every logged beat, thread-offloaded,
        fresh (force=True)."""
        self.assertIn("MEM_CENSUS rss_mb=%.0f threads=%d", self.handlers)
        self.assertIn("_vc_resource_pressure_state, force=True",
                      self.handlers)
        self.assertIn("asyncio.to_thread(\n"
                      "                        _vc_resource_pressure_state, "
                      "force=True)", self.handlers)

    def test_g6_pipeline_guard_and_defer_markers(self):
        self.assertIn("VC_RESOURCE_PRESSURE chat_id=%s account=%s",
                      self.pipe)
        self.assertIn("resource_pressure_guard", self.pipe)
        self.assertIn("_v9910_make_resource_pressure_error", self.pipe)

    def test_g7_worker_defer_counter(self):
        self.assertIn('elif result_state == "deferred_resource_pressure":',
                      self.vc)
        self.assertIn('prog.get("deferred_resource_pressure", 0) + 1',
                      self.vc)

    def test_g8_mtproto_exception_class(self):
        mt = _read(_MTPROTO)
        self.assertIn("class VCResourcePressureError(VCTransportError):",
                      mt)
        self.assertIn("def is_resource_pressure_error(", mt)

    def test_g9_voicechat_fallback_binding(self):
        """The stub-mtproto fallback keeps every harness/driver working
        when mtproto predates the symbols."""
        self.assertIn(
            "try:\n    from .mtproto import VCResourcePressureError, "
            "is_resource_pressure_error\nexcept ImportError:",
            self.vc)

    def test_g10_version_bumped(self):
        # v99.11 release bump: the version contract tracks CURRENT (the
        # stability-persistence release — admission guard, leave policy,
        # crash-loop guard, heartbeat fix).
        self.assertIn('__bot_version__ = "v99.11.1"', _read(_INIT))


# ===========================================================================
# SECTION H — mission Test G (stability): repeated guarded joins never
# grow tasks, dispatches, or the ownership map
# ===========================================================================

class TestHStabilityUnderPressure(unittest.TestCase):

    def setUp(self):
        sys.path.insert(0, os.path.join(_ROOT, "tests"))
        try:
            from tests.test_v99_00_vc_pipeline import (
                Harness, _mk_globals_backend)
        finally:
            sys.path.pop(0)
        os.environ["VC_JOIN_PIPELINE_MAX_ATTEMPTS"] = "2"
        os.environ["VC_JOIN_PIPELINE_MAX_ACCOUNTS"] = "1"
        os.environ["VC_JOIN_ENTITY_RETRIES"] = "1"
        os.environ["VC_JOIN_TG_VERIFY_ATTEMPTS"] = "1"
        os.environ["VC_JOIN_TG_VERIFY_BUDGET"] = "1"
        os.environ["VC_JOIN_DC_MAX_RETRIES"] = "0"
        os.environ["VC_JOIN_RECOVERY_BACKOFF_BASE"] = "0.01"
        os.environ["VC_MULTI_JOIN_TIMEOUT"] = "5"
        self.h = Harness()
        self.backend, self.client = _mk_globals_backend()
        try:
            self.h.vc_pipeline_mod._null_stream_suppress_reset_for_tests()
        except AttributeError:
            pass
        # guard hard-blocked the whole time (the sustained-pressure world)
        self.h.fake_voicechat._vc_resource_pressure_check = (
            lambda **kw: (True, "joined_transports=60>=48"))

    def tearDown(self):
        for k in ("VC_JOIN_PIPELINE_MAX_ATTEMPTS", "VC_JOIN_PIPELINE_MAX_ACCOUNTS",
                  "VC_JOIN_ENTITY_RETRIES", "VC_JOIN_TG_VERIFY_ATTEMPTS",
                  "VC_JOIN_TG_VERIFY_BUDGET", "VC_JOIN_DC_MAX_RETRIES",
                  "VC_JOIN_RECOVERY_BACKOFF_BASE", "VC_MULTI_JOIN_TIMEOUT"):
            os.environ.pop(k, None)

    def test_h1_fifty_guarded_targets_zero_dispatch_zero_growth(self):
        """50 sequential guard-blocked joins: every one defers cleanly,
        ZERO native dispatches, and the asyncio task population does not
        grow (no per-defer task leak)."""
        async def run():
            task_count_start = len(asyncio.all_tasks())
            deferred = 0
            for i in range(50):
                try:
                    await self.h.run_vc_join(
                        self.backend, 2000000000000 + i,
                        call_id=-9150000000000000001 - i,
                        access_hash=555, muted=True, account_id="")
                except Exception as exc:
                    self.assertIn("resource pressure", str(exc))
                    deferred += 1
            self.assertEqual(deferred, 50)
            self.assertEqual(self.backend.dispatches, [])
            # allow pending callbacks to settle, then compare populations
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            task_count_end = len(asyncio.all_tasks())
            self.assertLessEqual(task_count_end, task_count_start + 2,
                                 "per-defer task leak")
        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
