"""
v97.68 regression tests — authoritative disconnect classification + discovery per-page gate.

Root causes fixed:
  1. mtproto_call_with_retry checked is_connected() AFTER the RPC failed, but
     Telethon's is_connected() can return True when the transport is actually
     half-disconnected. The RPC raising "Cannot send requests while disconnected"
     IS the authoritative signal — must classify it as DISCONNECTED immediately.
  2. Discovery search only checked connectivity at the TOP of the cycle, not
     between pages. The client disconnected mid-cycle, producing 40 page failures.
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestAuthoritativeDisconnectClassification(unittest.TestCase):
    """P0: the retry loop must classify disconnect exceptions by MESSAGE, not is_connected()."""

    def test_disconnect_keywords_checked(self):
        """The handler must check exception message for disconnect keywords."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_is_disconnect_exc", src,
                      "must have _is_disconnect_exc classification")
        self.assertIn("cannot send requests while disconnected", src,
                      "must check for 'cannot send requests while disconnected'")
        self.assertIn("connection reset", src)
        self.assertIn("connection aborted", src)
        self.assertIn("incomplete read", src)

    def test_disconnect_terminates_immediately(self):
        """When the exception is classified as disconnect, must terminate (no retry)."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("classified as disconnect", src,
                      "must log 'classified as disconnect'")
        self.assertIn("terminating retry loop", src,
                      "must terminate retry loop for disconnect exceptions")

    def test_transient_error_still_retries(self):
        """When the exception is NOT a disconnect, must preserve retry behavior."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("transient error", src,
                      "must log 'transient error' for non-disconnect ConnectionError")
        self.assertIn("will retry", src,
                      "must retry genuine transient errors")

    def test_floodwait_preserved(self):
        """FloodWait handling must be preserved."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("FloodWaitError", src)
        self.assertIn("vc_set_global_floodwait", src)


class TestDiscoveryPerPageGate(unittest.TestCase):
    """P0: discovery must check connectivity before each page, not just at cycle start."""

    def test_per_page_connectivity_check(self):
        """Discovery search must check client.is_connected() before each page."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("DISCOVERY_DEFERRED_NETWORK", src,
                      "discovery must log DISCOVERY_DEFERRED_NETWORK when disconnected mid-cycle")
        self.assertIn("client disconnected mid-cycle", src,
                      "discovery must detect mid-cycle disconnect")


class TestPreservedBehavior(unittest.TestCase):
    """Verify all previous fixes are still present."""

    def test_callback_handler_sync_properties(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_entity_dead_letter_network_exclusion(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_network_err", src)

    def test_dashboard_single_flight(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src)

    def test_join_all_get_entity_timeout(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_JOIN_ALL_ENTITY_TIMEOUT", src)

    def test_reconcile_timeout_cause(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("classified UNKNOWN cause=", src)

    def test_no_asyncio_shield_in_stop(self):
        """v97.67 Join-All shutdown fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        import re
        m = re.search(r'async def vc_join_all_active_stop.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m)
        code_only = re.sub(r'#.*', '', m.group(0))
        self.assertNotIn("asyncio.shield", code_only)

    def test_event_loop_lag_instrumentation(self):
        with open(os.path.join(_BASE, "mediagrab_bot/bootstrap.py")) as f:
            src = f.read()
        self.assertIn("_capture_blocking_task_stack", src)
        self.assertIn("EVENT_LOOP_LAG_APP_TASKS", src)

    def test_dashboard_single_to_thread(self):
        with open(os.path.join(_BASE, "mediagrab_bot/handlers.py")) as f:
            src = f.read()
        self.assertIn("_snapshot_and_triggers", src)

    def test_get_entity_wrapper(self):
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_wrap_get_entity_disconnect_safe", src)

    def test_floodwait_breaker_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)
        self.assertIn("JOIN_ALL_BREAKER", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
