"""
v97.64 regression tests — fixes against the actual v97.63 production logs.

Runtime log evidence (note 35 + note 36):
  Log 1 (note 35):
    - MTProto connection error (attempt 1/2, 2/2): 54 (retry storm STILL EXISTS)
    - EVENT_LOOP_LAG_HIGH: 1 (6.24s)
    - VC_JOIN_ALL_SHUTDOWN_TIMEOUT + force-clearing: 1
    - vc_dashboard_auto_refresh: 14 task-dump entries (duplicates)
  Log 2 (note 36):
    - DISCOVERY_SEARCH_PAGE_FAIL: 35 (discovery flooding disconnected MTProto)
    - Unhandled exception on on_update (PyTgCalls): 13
    - VC_ENTITY_DEAD_LETTER: 22 (during network outage)
    - vc_dashboard_auto_refresh: 47 task-dump entries (4 simultaneous workers)
    - get_entity: 27 (Join-All + discovery still calling during disconnect)

Root causes fixed:
  1. mtproto_call_with_retry disconnect gate checked WRONG client (global not bound)
  2. discovery search didn't check connectivity before issuing queries
  3. PyTgCalls on_update get_entity raised ConnectionResetError (unhandled)
  4. Join-All get_entity during disconnect (vc_watcher was fixed, Join-All wasn't)
  5. Entity dead-letter counter incremented during network outage
  6. Dashboard duplicate workers (4 simultaneous for same admin+chat)
  7. Join-All shutdown log said "force-clearing" but code marked orphaned
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestAuthoritativeNetworkGate(unittest.TestCase):
    """P0 #1: the disconnect gate must check the ACTUAL client, not the global."""

    def test_gate_extracts_client_from_bound_method(self):
        """The gate must extract the client from func.__self__ (bound method)."""
        with open(_MTPROTO) as f:
            src = f.read()
        # v97.67: the extraction uses getattr(func, "__self__", None)
        self.assertIn("__self__", src,
                      "gate must extract client from __self__ (bound method)")
        self.assertIn("_gate_client", src,
                      "gate must use _gate_client variable")
        self.assertIn("MTPROTO_RPC_DEFERRED_DISCONNECTED", src,
                      "gate must log MTPROTO_RPC_DEFERRED_DISCONNECTED")

    def test_gate_checks_actual_client_not_global(self):
        """The gate must NOT check _mtproto_client (the global) when func is bound."""
        with open(_MTPROTO) as f:
            src = f.read()
        # The v97.63 bug was: _client_for_check = _mtproto_client
        # The v97.64 fix uses: _gate_client extracted from func.__self__
        self.assertNotIn("_client_for_check = _mtproto_client", src,
                         "gate must NOT use the global client when func is bound")


class TestDiscoveryDisconnectGate(unittest.TestCase):
    """P0 #2: discovery must not issue queries when MTProto is disconnected."""

    def test_discovery_returns_deferred_when_disconnected(self):
        """vc_discovery_run_cycle must return DEFERRED_NETWORK when disconnected."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_DISCOVERY_DEFERRED_NETWORK", src,
                      "discovery must log VC_DISCOVERY_DEFERRED_NETWORK")
        self.assertIn("deferred_network_disconnected", src,
                      "discovery must return deferred_network_disconnected")

    def test_discovery_checks_connectivity_before_queries(self):
        """The connectivity check must be BEFORE the query loop."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # Find vc_discovery_run_cycle
        import re
        m = re.search(r'async def vc_discovery_run_cycle.*?(?=\nasync def |\ndef )', src, re.DOTALL)
        self.assertIsNotNone(m, "vc_discovery_run_cycle not found")
        func_body = m.group(0)
        # The connectivity check must be BEFORE "merged = await vc_discovery_get_merged_queries"
        check_pos = func_body.find("VC_DISCOVERY_DEFERRED_NETWORK")
        query_pos = func_body.find("vc_discovery_get_merged_queries")
        self.assertGreater(check_pos, 0, "connectivity check must exist")
        self.assertGreater(query_pos, 0, "query loop must exist")
        self.assertLess(check_pos, query_pos,
                        "connectivity check must be BEFORE the query loop")


class TestPyTgCallsGetEntityWrapper(unittest.TestCase):
    """P0 #3: PyTgCalls on_update get_entity must not raise during disconnect."""

    def test_wrapper_exists(self):
        """_wrap_get_entity_disconnect_safe must exist + be called."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("def _wrap_get_entity_disconnect_safe", src,
                      "wrapper function must exist")
        self.assertIn("_wrap_get_entity_disconnect_safe(_mtproto_client)", src,
                      "wrapper must be called in _mtproto_register_handlers")

    def test_wrapper_returns_none_on_disconnect(self):
        """The wrapper must return None (not raise) when disconnected."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("return None", src,
                      "wrapper must return None on disconnect")
        self.assertIn("ConnectionResetError", src,
                      "wrapper must catch ConnectionResetError")

    def test_wrapper_is_idempotent(self):
        """The wrapper must not double-wrap the same client."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("_mtproto_wrapped_clients", src,
                      "wrapper must track wrapped clients to avoid double-wrapping")


class TestEntityDeadLetterNetworkExclusion(unittest.TestCase):
    """P0 #5: network errors must NOT increment the entity-failure counter."""

    def test_network_errors_excluded_from_dead_letter(self):
        """vc_record_entity_failure must NOT be called for network errors."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_is_network_err", src,
                      "entity failure check must classify network errors")
        self.assertIn("not _is_network_err", src,
                      "network errors must NOT increment entity-failure counter")

    def test_network_error_keywords_checked(self):
        """The check must look for disconnected/connection-reset keywords."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("cannot send requests", src)
        self.assertIn("connection reset", src)
        self.assertIn("network is unreachable", src)


class TestDashboardSingleFlightPerChat(unittest.TestCase):
    """P0 #6: at most ONE dashboard refresh worker per (admin_id, chat_id)."""

    def test_start_cancels_all_workers_for_same_admin_chat(self):
        """_vc_dashboard_auto_refresh_start must cancel ALL workers for (admin, chat)."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("_old_keys_to_cancel", src,
                      "start must find all old keys to cancel")
        self.assertIn("k[0] == _ac and k[1] == _cc", src,
                      "start must match on (admin_id, chat_id) regardless of message_id")
        self.assertIn("VC_DASHBOARD_REFRESH_CANCELLED", src,
                      "start must log when cancelling old workers")


class TestJoinAllShutdownNoForceClear(unittest.TestCase):
    """P0 #7: Join-All shutdown must NOT force-clear state."""

    def test_shutdown_logs_orphaned_not_force_clear(self):
        """The log must say ORPHANED, not 'force-clearing state'."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("marking ORPHANED (NOT force-clearing state", src,
                      "shutdown must log ORPHANED not force-clear")
        self.assertNotIn('force-clearing state")', src,
                         "force-clearing state must be removed from the log")


class TestPreservedBehavior(unittest.TestCase):
    """§10: FloodWait + InterdcCall + previous fixes must be preserved."""

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)
        self.assertIn("JOIN_ALL_BREAKER", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_callback_handler_no_blocking_rpcs(self):
        """v97.62 callback handler fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("event.sender_id", src)

    def test_no_await_on_sync_release(self):
        """v97.61 TypeError fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_mtproto_capture_ingress_filter(self):
        """v97.63 capture filter must still hold."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("not getattr(message, \"media\", None)", src)

    def test_watcher_disconnect_safe(self):
        """v97.63 watcher disconnect-safe must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_WATCHER_SKIP_DISCONNECTED", src)

    def test_parked_expiry(self):
        """v97.63 parked expiry must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_CALLBACK_PARKED_EXPIRED", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
