"""Regression tests for v97.96 forensic audit — secondary-account sqlite_locked cascade.

These tests verify the RUNTIME-PROVEN + SOURCE-PROVEN bugs fixed in v97.96:

  BUG-1 (CRITICAL, RUNTIME-PROVEN + SOURCE-PROVEN):
    When `_cluster_reconnect_loop` (bootstrap.py:903) retries an account in
    STATUS_CONNECTION_FAILED, `connect_account` (mtproto.py:999) finds the
    existing client in `self._clients` but `is_connected()` returns False. The
    "else: client exists but not connected" branch (mtproto.py:1094-1122 in
    v97.95) only called `_release_client_session` + `self._clients.pop`, but
    did NOT call `existing_client.disconnect()` and did NOT
    `_forcibly_cancel_telethon_tasks`. The existing client's 6 Telethon
    background tasks (update_loop, keepalive_loop, mtprotosender_send/recv_loop,
    connection_send/recv_loop) survived, holding the SQLite write lock. Every
    subsequent `connect_account` created a NEW TelegramClient that failed with
    `OperationalError: database is locked — another process holds the write
    lock`.

    Runtime evidence (bot-diagnostic (8).log + bot (9).log, v97.95):
      14:38:46 ACCOUNT_CONNECT_SUCCESS strategy=new_client client_identity=103877824
      14:57:20 MTPROTO_CLUSTER_DISCONNECT_DETECTED for acc_919006065076
      14:57:50 ACCOUNT_RECONNECT_START → release 103877824 → acquire 105996704
      14:58:03 ACCOUNT_CONNECT_FAILED sqlite_locked (13s after release)
      14:59:04 acquire 489760883760 → 14:59:17 sqlite_locked (1m13s after first release)
      ... continues every ~74s for over 1 hour ...

  BUG-2 (MEDIUM, RUNTIME-PROVEN + SOURCE-PROVEN, amplifier):
    `_classify_connect_exception` (mtproto.py:1411) called
    `update_status(STATUS_CONNECTION_FAILED)` on the sqlite_locked /
    connection_failed / generic paths, but NEVER incremented `fail_count`.
    `_cluster_reconnect_loop` (bootstrap.py:927) reads `fail_count` to
    determine backoff (60→300→900s). With fail_count stuck at 0, the loop
    retried every 60s forever, amplifying BUG-1's leaked-tasks cascade.

  BUG-3 (LOW, SOURCE-PROVEN, latent): `disconnect_account` (mtproto.py:1530)
    awaited the `disconnected` drain future but did NOT
    `_forcibly_cancel_telethon_tasks`. If the drain timed out, the bg tasks
    survived.

  BUG-4 (defensive, SOURCE-PROVEN): no per-account asyncio.Lock for
    `connect_account` — a manual /reconnect command could race with
    `_cluster_reconnect_loop`, creating 2 TelegramClients on the same session
    file simultaneously.

Fix (v97.96):
  - FIX-1: add `_forcibly_cancel_telethon_tasks` to all 4 paths in
    `connect_account` (3 existing-client paths + new-client failure path).
  - FIX-2: increment `fail_count` in `_classify_connect_exception` on the 3
    STATUS_CONNECTION_FAILED paths; reset `fail_count=0` on the 4 connect
    success paths; add `ACCOUNT_SQLITE_LOCKED_BACKOFF` log marker.
  - FIX-3: add `_forcibly_cancel_telethon_tasks` to `disconnect_account`.
  - FIX-4: per-account `asyncio.Lock` single-flight for `connect_account`.

These tests verify behavior via source-text assertions (because Telethon
cannot be loaded in the validation env) PLUS pure-Python behavioral tests
for the fail_count escalation logic.
"""
from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_MTPROTO_PATH = ROOT / "mediagrab_bot" / "mtproto.py"
_VOICECHAT_PATH = ROOT / "mediagrab_bot" / "voicechat.py"
_INIT_PATH = ROOT / "mediagrab_bot" / "__init__.py"
_BOOTSTRAP_PATH = ROOT / "mediagrab_bot" / "bootstrap.py"


def _read_source(path: Path) -> str:
    if not path.exists():
        raise unittest.SkipTest(f"{path.name} not found")
    return path.read_text(encoding="utf-8")


# ===========================================================================
# SECTION A — BUG-1: forcibly_cancel_telethon_tasks in connect_account
#
# Verify all 4 paths in connect_account call _forcibly_cancel_telethon_tasks
# BEFORE _release_client_session / disconnect. This is the core fix.
# ===========================================================================
class TestBUG1ForciblyCancelInConnectAccount(unittest.TestCase):
    """v97.96 BUG-1: connect_account must forcibly-cancel old client bg tasks."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_get_me_failed_path_cancels_bg_tasks(self):
        """The get_me-failed path (existing client connected but get_me raised)
        must call _forcibly_cancel_telethon_tasks BEFORE disconnect+release."""
        # Find the get_me-failed else branch.
        idx = self.src.find("ACCOUNT_CONNECT_GLOBAL_CLIENT_GETME_FAIL")
        self.assertGreater(idx, -1, "get_me-fail log marker must exist")
        # Window after the global-client-skip block — the else branch.
        # Find the next _forcibly_cancel after this marker.
        cancel_idx = self.src.find("_forcibly_cancel_telethon_tasks", idx)
        self.assertGreater(cancel_idx, -1,
                           "BUG-1: get_me-failed path must call "
                           "_forcibly_cancel_telethon_tasks")
        # The cancel must come BEFORE the disconnect + _release_client_session
        # in the same branch. Verify by checking the window (extend to include
        # the label which is on the line after the call).
        window = self.src[idx:cancel_idx + 250]
        self.assertIn("cluster_reconnect_getme_fail", window,
                      "label must be cluster_reconnect_getme_fail")

    def test_not_connected_else_branch_cancels_bg_tasks(self):
        """The 'client exists but not connected' else branch must call
        _forcibly_cancel_telethon_tasks BEFORE release+pop. This is THE core
        fix — this branch is what _cluster_reconnect_loop triggers."""
        # Find the else branch with the comment "Client exists but not connected"
        idx = self.src.find("Client exists but not connected")
        self.assertGreater(idx, -1, "else-branch comment must exist")
        # Window after this comment — must contain _forcibly_cancel.
        window = self.src[idx:idx + 2500]
        self.assertIn("_forcibly_cancel_telethon_tasks", window,
                      "BUG-1: else-branch must call _forcibly_cancel_telethon_tasks")
        self.assertIn("cluster_reconnect_stale", window,
                      "label must be cluster_reconnect_stale")
        # The _release_client_session must ALSO be present (existing behavior preserved).
        self.assertIn("_release_client_session", window,
                      "else-branch must still call _release_client_session")

    def test_outer_except_path_cancels_bg_tasks(self):
        """The outer except (is_connected()/disconnect() raised mid-op)
        must call _forcibly_cancel_telethon_tasks."""
        # Find "same forcibly-cancel pattern on the" — the comment added by FIX-1.
        idx = self.src.find("same forcibly-cancel pattern on the")
        self.assertGreater(idx, -1, "outer-except comment must exist")
        window = self.src[idx:idx + 1200]
        self.assertIn("_forcibly_cancel_telethon_tasks", window,
                      "BUG-1: outer-except must call _forcibly_cancel_telethon_tasks")
        self.assertIn("cluster_reconnect_except", window,
                      "label must be cluster_reconnect_except")

    def test_new_client_failure_path_cancels_bg_tasks(self):
        """On the new-client failure path (connect() raised, e.g.
        sqlite_locked), the NEW client's bg tasks must be forcibly cancelled
        BEFORE disconnect + release. This prevents the new client's leaked
        SQLiteSession from holding the write lock on the next iteration."""
        # Find the except block of the new-client try (label=cluster_connect_failed).
        idx = self.src.find("cluster_connect_failed")
        self.assertGreater(idx, -1,
                           "BUG-1: new-client failure path must exist with "
                           "cluster_connect_failed label")
        # Walk backwards to confirm it's in the except block.
        window_before = self.src[max(0, idx - 800):idx + 50]
        self.assertIn("except Exception as exc", window_before,
                      "must be in the new-client except block")
        # The _forcibly_cancel must come BEFORE client.disconnect() in this path.
        # Find the _forcibly_cancel_telethon_tasks call nearest to idx (search backwards).
        fc_idx = self.src.rfind("_forcibly_cancel_telethon_tasks", 0, idx + 50)
        self.assertGreater(fc_idx, -1, "must find _forcibly_cancel call")
        disc_idx = self.src.find("await client.disconnect()", fc_idx)
        self.assertGreater(disc_idx, -1, "client.disconnect() must follow")
        self.assertLess(disc_idx, idx + 200,
                        "disconnect must be within the same path")


# ===========================================================================
# SECTION B — BUG-2: fail_count increment in _classify_connect_exception
# + reset on connect success paths.
# ===========================================================================
class TestBUG2FailCountEscalation(unittest.TestCase):
    """v97.96 BUG-2: _classify_connect_exception must increment fail_count
    on the 3 STATUS_CONNECTION_FAILED paths so the exponential backoff
    (60→300→900s) actually escalates. Connect success paths must reset
    fail_count=0."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_sqlite_locked_increments_fail_count(self):
        """The sqlite_locked path must set acc['fail_count'] = old + 1."""
        # Search for the actual sqlite_locked branch (the comment, not the
        # docstring mention of 'database is locked').
        idx = self.src.find("# SQLite database locked.")
        self.assertGreater(idx, -1, "sqlite_locked branch comment must exist")
        window = self.src[idx:idx + 3000]
        self.assertIn('acc["fail_count"]', window,
                      "BUG-2: sqlite_locked path must increment fail_count")

    def test_sqlite_locked_logs_backoff_marker(self):
        """The sqlite_locked path must log ACCOUNT_SQLITE_LOCKED_BACKOFF so
        operators can see the next retry delay without re-deriving it."""
        idx = self.src.find("ACCOUNT_SQLITE_LOCKED_BACKOFF")
        self.assertGreater(idx, -1,
                           "BUG-2: must log ACCOUNT_SQLITE_LOCKED_BACKOFF marker")
        window = self.src[idx:idx + 400]
        self.assertIn("next_backoff", window,
                      "marker must include next_backoff field")
        self.assertIn("fail_count", window,
                      "marker must include fail_count field")

    def test_connection_failed_increments_fail_count(self):
        """The connection_failed path must increment fail_count."""
        idx = self.src.find("Network / connection errors")
        self.assertGreater(idx, -1, "connection_failed branch must exist")
        window = self.src[idx:idx + 1500]
        self.assertIn('acc["fail_count"]', window,
                      "BUG-2: connection_failed path must increment fail_count")

    def test_generic_fallback_increments_fail_count(self):
        """The generic fallback path must increment fail_count."""
        idx = self.src.find("Generic fallback")
        self.assertGreater(idx, -1, "generic fallback branch must exist")
        window = self.src[idx:idx + 800]
        self.assertIn('acc["fail_count"]', window,
                      "BUG-2: generic path must increment fail_count")

    def test_floodwait_does_not_increment_fail_count(self):
        """FloodWait has its own backoff via floodwait_until — the loop does
        NOT retry floodwait accounts (status=STATUS_FLOODWAIT), so fail_count
        must NOT be incremented on floodwait (it would incorrectly elevate
        the next connection_failed backoff)."""
        idx = self.src.find("FloodWait — extract the wait time")
        self.assertGreater(idx, -1, "floodwait branch must exist")
        # Window until the next branch (session revoked).
        end = self.src.find("Session revoked", idx)
        window = self.src[idx:end]
        self.assertNotIn('acc["fail_count"]', window,
                         "BUG-2: floodwait path must NOT increment fail_count "
                         "(it has its own backoff via floodwait_until)")

    def test_connect_success_resets_fail_count(self):
        """All 4 connect success paths (existing-connected-reuse,
        legacy_reuse, registry_reuse, new_client) must reset fail_count=0."""
        # Find all strategy= markers and verify each is preceded (within 600 chars)
        # by a fail_count=0 reset. The window must be wide enough to reach back
        # past the update_status + _snapshot_telethon_bg_tasks + logger.info
        # prologue to the reset line.
        for marker in ("strategy=legacy_reuse",
                       "strategy=registry_reuse",
                       "strategy=new_client"):
            idx = self.src.find(marker)
            self.assertGreater(idx, -1, f"{marker} success log must exist")
            # Look in the 600-char window BEFORE the log marker for the reset.
            window = self.src[max(0, idx - 600):idx]
            self.assertIn('acc["fail_count"] = 0', window,
                          f"BUG-2: {marker} success path must reset fail_count=0")
        # Also the existing-connected-reuse path (no strategy= marker).
        idx = self.src.find("ACCOUNT_CONNECT_REUSING_EXISTING")
        self.assertGreater(idx, -1, "reuse-existing log marker must exist")
        window = self.src[idx:idx + 800]
        self.assertIn('acc["fail_count"] = 0', window,
                      "BUG-2: reuse-existing success path must reset fail_count=0")


# ===========================================================================
# SECTION C — BUG-3: disconnect_account calls _forcibly_cancel
# ===========================================================================
class TestBUG3DisconnectAccountCancelsBgTasks(unittest.TestCase):
    """v97.96 BUG-3: disconnect_account must call _forcibly_cancel_telethon_tasks
    BEFORE client.disconnect() so leaked bg tasks don't survive a drain timeout."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_disconnect_account_cancels_bg_tasks(self):
        """disconnect_account's else branch (not the global _mtproto_client)
        must call _forcibly_cancel_telethon_tasks before client.disconnect()."""
        idx = self.src.find("async def disconnect_account")
        self.assertGreater(idx, -1, "disconnect_account must exist")
        # Find the cluster_disconnect label (added by FIX-3).
        label_idx = self.src.find("cluster_disconnect", idx)
        self.assertGreater(label_idx, -1,
                           "BUG-3: disconnect_account must have cluster_disconnect label")
        # The _forcibly_cancel must come BEFORE client.disconnect() in this path.
        fc_idx = self.src.rfind("_forcibly_cancel_telethon_tasks",
                                idx, label_idx + 50)
        self.assertGreater(fc_idx, -1,
                           "must find _forcibly_cancel call in disconnect_account")
        disc_idx = self.src.find("await client.disconnect()", fc_idx)
        self.assertGreater(disc_idx, -1, "client.disconnect() must follow")
        self.assertLess(disc_idx, label_idx + 400,
                        "disconnect must be within the same path")


# ===========================================================================
# SECTION D — BUG-4: per-account asyncio.Lock single-flight
# ===========================================================================
class TestBUG4ConnectAccountSingleFlight(unittest.TestCase):
    """v97.96 BUG-4: connect_account must hold a per-account asyncio.Lock so
    concurrent callers (manual /reconnect + _cluster_reconnect_loop) cannot
    create 2 TelegramClients on the same session file simultaneously."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_MTPROTO_PATH)

    def test_account_connect_locks_dict_initialized(self):
        """UserbotCluster.__init__ must initialize _account_connect_locks."""
        idx = self.src.find("class UserbotCluster")
        self.assertGreater(idx, -1, "UserbotCluster class must exist")
        # Find __init__ and the lock dict init within 2000 chars.
        init_idx = self.src.find("def __init__", idx)
        self.assertGreater(init_idx, -1, "UserbotCluster.__init__ must exist")
        window = self.src[init_idx:init_idx + 2000]
        self.assertIn("_account_connect_locks", window,
                      "BUG-4: UserbotCluster.__init__ must init _account_connect_locks")
        self.assertIn("asyncio.Lock", window,
                      "BUG-4: must use asyncio.Lock type annotation")

    def test_connect_account_acquires_lock_before_inner(self):
        """connect_account must acquire the per-account lock then dispatch
        to _connect_account_inner. This is the single-flight pattern."""
        idx = self.src.find("async def connect_account")
        self.assertGreater(idx, -1, "connect_account must exist")
        # The body must reference _account_connect_locks + async with + _connect_account_inner.
        body_end = self.src.find("async def _connect_account_inner", idx)
        self.assertGreater(body_end, -1,
                           "BUG-4: _connect_account_inner must exist (refactored body)")
        body = self.src[idx:body_end]
        self.assertIn("_account_connect_locks", body,
                      "BUG-4: connect_account must reference _account_connect_locks")
        self.assertIn("asyncio.Lock()", body,
                      "BUG-4: connect_account must construct asyncio.Lock lazily")
        self.assertIn("async with _lk", body,
                      "BUG-4: connect_account must acquire the lock with async with")
        self.assertIn("_connect_account_inner", body,
                      "BUG-4: connect_account must dispatch to _connect_account_inner")


# ===========================================================================
# SECTION E — Behavioral: fail_count escalation produces 60→300→900s backoff
# ===========================================================================
class TestFailCountBackoffEscalation(unittest.TestCase):
    """v97.96: pure-Python simulation of the _cluster_reconnect_loop backoff
    logic to prove that with fail_count incrementing (BUG-2 fix), the backoff
    escalates 60s → 300s → 900s, instead of staying at 60s forever (the v97.95
    bug)."""

    def test_backoff_escalates_with_fail_count(self):
        """Simulate _cluster_reconnect_loop's backoff selection with the
        _CLUSTER_RECONNECT_BACKOFF = [60, 300, 900] list and verify escalation.

        The loop reads fail_count BEFORE the connect attempt:
          failure #1: fail_count=0 (read) → backoff_idx=0 → 60s. After failure,
                     _classify_connect_exception increments to 1.
          failure #2: fail_count=1 (read) → backoff_idx=1 → 300s. Increments to 2.
          failure #3: fail_count=2 (read) → backoff_idx=2 → 900s. Increments to 3.
          failure #4+: capped at idx=2 → 900s.
        """
        _BACKOFF = [60, 300, 900]
        # Before BUG-2 fix: fail_count never incremented → always 0 → always 60s.
        old_fail_count = 0  # v97.95 bug: stuck at 0
        old_backoff_idx = min(old_fail_count, len(_BACKOFF) - 1)
        old_wait = _BACKOFF[old_backoff_idx]
        self.assertEqual(old_wait, 60, "v97.95 bug: backoff stuck at 60s")
        # After BUG-2 fix: fail_count increments on each sqlite_locked.
        for fc, expected_wait in [(0, 60), (1, 300), (2, 900), (3, 900), (10, 900)]:
            backoff_idx = min(fc, len(_BACKOFF) - 1)
            wait = _BACKOFF[backoff_idx]
            self.assertEqual(wait, expected_wait,
                             f"BUG-2: fail_count={fc} must give backoff={expected_wait}s, "
                             f"got {wait}s")

    def test_fail_count_reset_on_success_resets_backoff(self):
        """When connect succeeds, fail_count resets to 0, so the NEXT failure
        starts backoff from 60s (not the previously-elevated step). This
        prevents a transient failure from permanently elevating backoff."""
        _BACKOFF = [60, 300, 900]
        # Simulate: 3 failures (fail_count=3, backoff=900s) → success (reset to 0).
        fail_count = 3
        backoff_idx = min(fail_count, len(_BACKOFF) - 1)
        self.assertEqual(_BACKOFF[backoff_idx], 900,
                         "after 3 failures, backoff is 900s")
        # Success path resets fail_count=0 (BUG-2 fix).
        fail_count = 0  # reset on success
        backoff_idx = min(fail_count, len(_BACKOFF) - 1)
        self.assertEqual(_BACKOFF[backoff_idx], 60,
                         "after success+reset, next failure starts at 60s")


# ===========================================================================
# SECTION F — v97.95 VC fix regression check (must still be intact)
# ===========================================================================
class TestV9795VCFixStillIntact(unittest.TestCase):
    """v97.96 must NOT weaken the v97.95 VC stale-coordinator fix. Verify the
    3 detection sites in voicechat.py still call record_evidence_absent /
    mark_unknown."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_positive_absence_site_calls_record_evidence_absent(self):
        """Site 1 (reconcile POSITIVE-ABSENCE) must call
        coord.record_evidence_absent — this is what clears JOINED → LEFT."""
        # Find the VC_STALE_STATE_DETECTED near "participation_reconcile:telegram_absent".
        idx = self.src.find("participation_reconcile:telegram_absent")
        self.assertGreater(idx, -1,
                           "v97.95 Site 1 evidence string must exist")
        window = self.src[max(0, idx - 600):idx + 200]
        self.assertIn("record_evidence_absent", window,
                      "v97.95 Site 1 must call record_evidence_absent (REGRESSION)")

    def test_stale_joined_record_site_calls_mark_unknown(self):
        """Site 2 (v97.85 stale-joined-record repair) must call
        coord.mark_unknown — this clears JOINED → UNKNOWN when backend
        disconnects but registry still says joined."""
        idx = self.src.find("stale_joined_record:backend_disconnected")
        self.assertGreater(idx, -1,
                           "v97.95 Site 2 evidence string must exist")
        window = self.src[max(0, idx - 600):idx + 200]
        self.assertIn("mark_unknown", window,
                      "v97.95 Site 2 must call mark_unknown (REGRESSION)")

    def test_reconcile_timeout_site_calls_mark_unknown(self):
        """Site 3 (reconcile TIMEOUT) must call coord.mark_unknown — this
        clears JOINED → UNKNOWN when reconcile times out."""
        idx = self.src.find("reconcile_timeout:")
        self.assertGreater(idx, -1,
                           "v97.95 Site 3 evidence string must exist")
        window = self.src[max(0, idx - 600):idx + 200]
        self.assertIn("mark_unknown", window,
                      "v97.95 Site 3 must call mark_unknown (REGRESSION)")


# ===========================================================================
# SECTION G — Logging markers (Phase 8)
# ===========================================================================
class TestLoggingMarkers(unittest.TestCase):
    """v97.96: structured logging markers for the account-session lifecycle."""

    @classmethod
    def setUpClass(cls):
        cls.mt = _read_source(_MTPROTO_PATH)
        cls.vc = _read_source(_VOICECHAT_PATH)

    def test_account_sqlite_locked_backoff_marker(self):
        """ACCOUNT_SQLITE_LOCKED_BACKOFF must be logged on sqlite_locked."""
        self.assertIn("ACCOUNT_SQLITE_LOCKED_BACKOFF", self.mt,
                      "must log ACCOUNT_SQLITE_LOCKED_BACKOFF")

    def test_account_forced_cancel_error_marker(self):
        """ACCOUNT_FORCED_CANCEL_ERROR must be logged when forcibly-cancel
        raises (defensive — should never fire but logs if it does)."""
        self.assertIn("ACCOUNT_FORCED_CANCEL_ERROR", self.mt,
                      "must log ACCOUNT_FORCED_CANCEL_ERROR")

    def test_v97_95_leave_cleanup_markers_preserved(self):
        """v97.95 added VC_LEAVE_CLEANUP_START + VC_LEAVE_CLEANUP_COMPLETE —
        these must NOT be removed."""
        self.assertIn("VC_LEAVE_CLEANUP_START", self.vc,
                      "v97.95 VC_LEAVE_CLEANUP_START must be preserved")
        self.assertIn("VC_LEAVE_CLEANUP_COMPLETE", self.vc,
                      "v97.95 VC_LEAVE_CLEANUP_COMPLETE must be preserved")

    def test_v97_95_stale_state_marker_preserved(self):
        """v97.95 added VC_STALE_STATE_DETECTED — must be preserved."""
        self.assertIn("VC_STALE_STATE_DETECTED", self.vc,
                      "v97.95 VC_STALE_STATE_DETECTED must be preserved")


# ===========================================================================
# SECTION H — Version bump
# ===========================================================================
class TestVersionBump(unittest.TestCase):
    """v97.96 must bump the version string consistently."""

    @classmethod
    def setUpClass(cls):
        cls._init_src = _read_source(_INIT_PATH)
        cls._bootstrap_src = _read_source(_BOOTSTRAP_PATH)

    def test_init_version_is_v97_97(self):
        # v99: the version string tracks the CURRENT artifact (v99.03).
        self.assertIn("v99.11", self._init_src,
                      "__init__.py must declare the current version")

    def test_bootstrap_version_is_v97_97(self):
        self.assertIn("version={_v9812_pkg_version}", self._bootstrap_src,  # v99: derivation site
                      "bootstrap.py DEPLOYMENT_IDENTITY must declare v97.97")

    def test_no_v97_96_version_strings_remain(self):
        """The VERSION STRINGS (not descriptive comments) must not still
        reference v97.96 (the previous version) in __init__.py / bootstrap.py."""
        self.assertNotIn('__bot_version__ = "v97.97"', self._init_src,
                          "__init__.py must not still declare v97.96")
        self.assertNotIn("version=v97.97", self._bootstrap_src,
                          "bootstrap.py must not still declare v97.96")


if __name__ == "__main__":
    unittest.main()
