#!/usr/bin/env python3
"""v99.03 — DEPLOYMENT HYGIENE regression suite (RC-8 .. RC-13).

Every test in this file targets a gap that was RUNTIME-PROVEN by the
2026-09-11 02:45:10 → 03:20:39 v99.02 production diagnostic log
(upload/bot-diagnostic.log, 3,292 lines, 1,086s uptime) — a run in which
EVERY v99.02 code fix fired correctly (asset-identity mismatch detected
at line 2; 40 join attempts honestly blocked; FD_CENSUS stable 18–20;
zero reconnects; zero Errno 24) yet the operator still reported "still
facing issues + there are two accounts but showing one":

  RC-8  The bot KNEW the deployment was broken (BUILD_IDENTITY_MISMATCH
        at boot) and kept running joins for 36 minutes — 40 attempts ×
        ~8 entity-resolution RPCs ≈ 320 wasted RPCs. v99.03: the VC
        pipeline refuses entry when the boot identity check failed
        (fail-open for dev/test trees; VC_ALLOW_PIPELINE_ON_IDENTITY_
        MISMATCH=1 override), discovery + reconcile cycles short-circuit
        (RC-13), and the Bot API surface stays available for diagnosis.
  RC-9  The 226,371-byte silence asset shipped IN the v99.02 ZIP but the
        operator extracted only the .py files. v99.03: on an asset
        identity mismatch the bot self-extracts the stamped asset from
        the on-disk deployment ZIP (sha256-verified, atomic write) and
        re-verifies the identity.
  RC-10 ACCOUNT_STARTUP_REPORT total=1 counts CLUSTER accounts only —
        the operator could not see that of their 3 .session files one is
        DEAD (cluster_916397080450, SESSION_UNAUTHORIZED line 131), one
        is the PRIMARY GLOBAL session (@Gradieer), and one is the only
        cluster account (@Official_Ishitaa). v99.03: ACCOUNT_SESSION_
        HEALTH (one entry per .session file) at import end, ACCOUNT_
        HEALTH every 300s in the heartbeat, /v85accounts command.
  RC-11 SESSION_UNAUTHORIZED carried no repair instructions. v99.03:
        every SESSION_UNAUTHORIZED is followed by a SESSION_REMEDIATION
        runbook line with the EXACT re-login command (phone derived from
        the file stem), and tools/login.py implements that command.
  RC-12 40 blocked-join WARNINGs in 36 min across 31 chats (9 repeats)
        — each repeat re-paid the full pre-gate cost. v99.03: repeats
        for a (chat, reason) pair inside 300s short-circuit at pipeline
        ENTRY (zero RPCs) and collapse to DEBUG + one SUPPRESSED summary
        per expired window.
  RC-13 Discovery + reconcile cycles ran while every join was doomed.
        v99.03: one DEBUG line per skipped cycle while the pipeline is
        disabled.

Method: behavioural tests against the REAL modules (the pipeline through
the v99.00 mock harness; mtproto through the v99.02 real-module fake
stack; the RC-9 heal functions exec-extracted from bootstrap.py so the
SHIPPED bytes are what runs), source contracts where behaviour is not
offline-reproducible, and explicit EFFICACY FAIL-ON-REVERT tests for
RC-8/RC-9/RC-10 (the fix surgically removed from a scratch copy → the
guarded contract observably breaks).
"""
from __future__ import annotations

import ast
import asyncio
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile
import types
import unittest
import zipfile
from pathlib import Path

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")
_BOOT_TEXT = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
_MT_TEXT = (_SRC / "mtproto.py").read_text(encoding="utf-8")
_HANDLERS_TEXT = (_SRC / "handlers.py").read_text(encoding="utf-8")
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_INIT_TEXT = (_SRC / "__init__.py").read_text(encoding="utf-8")
_DH_TEXT = (_SRC / "deploy_health.py").read_text(encoding="utf-8")
_LOGIN_TEXT = (_SRC / "tools" / "login.py").read_text(encoding="utf-8")
_SERVICE_TEXT = (Path(__file__).resolve().parent.parent /
                 "deploy" / "mediagrab.service").read_text(encoding="utf-8")

# Reuse the v99.00 behavioural harness (fake voicechat/mtproto + the REAL
# vc_pipeline.py) and the v99.02 real-module fake stack (REAL mtproto).
sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_v99_00_vc_pipeline as T  # noqa: E402
import test_v99_02_production_stability as T2  # noqa: E402


def _env_cleanup(*keys: str):
    """Decorator-ish helper: run fn with env keys removed afterwards."""
    def _wrap(fn):
        def _inner(self):
            try:
                return fn(self)
            finally:
                for k in keys:
                    os.environ.pop(k, None)
        return _inner
    return _wrap


# ===========================================================================
# deploy_health — the shared-state semantics (RC-8 carrier)
# ===========================================================================

class TestDeployHealthSemantics(unittest.TestCase):
    """The RC-8 state carrier: fail-open by default, mismatch only when
    checked AND failed, env override respected."""

    def setUp(self):
        self.dh = self._load()
        self.dh.reset_for_tests()

    @staticmethod
    def _load():
        spec = importlib.util.spec_from_file_location(
            "v9903_dh_semantics", str(_SRC / "deploy_health.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def tearDown(self):
        self.dh.reset_for_tests()
        os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)

    def test_default_state_is_unknown_and_not_disabled(self):
        # Fail-open: a fresh import (dev/test tree, boot check not run)
        # must NEVER disable the pipeline — that would trade an
        # availability regression for a hygiene win.
        snap = self.dh.build_identity_state()
        self.assertEqual(snap["state"], "unknown")
        self.assertFalse(snap["checked"])
        self.assertIsNone(self.dh.vc_pipeline_disabled_reason())

    def test_mismatch_enables_refusal_and_states_carry_detail(self):
        self.dh.set_build_identity(
            "MISMATCH", "assets/vc_silence_600s.opus: "
            "stamp=e6ad24a0ecd48db2 actual=missing",
            stamp_version="v99.03", runtime_version="v99.03")
        self.assertTrue(self.dh.build_identity_mismatch())
        self.assertEqual(self.dh.vc_pipeline_disabled_reason(),
                         "build_identity_mismatch")
        snap = self.dh.build_identity_state()
        self.assertIn("actual=missing", snap["detail"])
        self.assertEqual(snap["stamp_version"], "v99.03")

    def test_env_override_disables_the_refusal(self):
        self.dh.set_build_identity("MISMATCH", "assets/x actual=missing")
        os.environ["VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH"] = "1"
        self.assertIsNone(self.dh.vc_pipeline_disabled_reason())

    def test_missing_or_unreadable_stamp_never_disables(self):
        # The dev-tree states: boot ran but there is no stamp to compare.
        for state in ("missing", "unreadable", "verified"):
            self.dh.reset_for_tests()
            self.dh.set_build_identity(state, "…")
            self.assertIsNone(self.dh.vc_pipeline_disabled_reason(),
                               f"state={state} must be fail-open")

    def test_self_heal_report_roundtrip(self):
        self.assertIsNone(self.dh.self_heal_report())
        self.dh.mark_self_heal(
            True, ["assets/vc_silence_600s.opus"], "/tmp/x.zip",
            {"assets/vc_silence_600s.opus": "e6ad24a0ecd48db2"})
        rep = self.dh.self_heal_report()
        self.assertTrue(rep["ok"])
        self.assertEqual(rep["source"], "/tmp/x.zip")


# ===========================================================================
# RC-8 — fail-fast: run_vc_join refuses entry BEFORE identity resolution
# ===========================================================================

class TestV9903RC8PipelineRefusal(T.PipelineTestBase):
    """The zero-RPC fast refusal — the production evidence: 40 join
    attempts AFTER the boot check had already declared the tree broken."""

    def tearDown(self):
        super().tearDown()
        os.environ.pop("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH", None)
        try:
            self.h.deploy_health.reset_for_tests()
        except Exception:
            pass

    def _set_mismatch(self):
        self.h.deploy_health.set_build_identity(
            "MISMATCH", "assets/vc_silence_600s.opus: "
            "stamp=e6ad24a0ecd48db2 actual=missing")

    def test_refusal_raises_before_identity_resolution(self):
        self._set_mismatch()
        asyncio.run(self._refusal_body())

    async def _refusal_body(self):
        resolve_before = len(self.h.entity_calls)
        with self.assertLogs("mediagrab", level="ERROR") as logs:
            with self.assertRaises(self.h.VCTransportError) as cm:
                await self._join()
        # ZERO-RPC proof: no entity resolution happened for the refusal.
        self.assertEqual(len(self.h.entity_calls), resolve_before)
        self.assertEqual(len(self.backend.dispatches), 0)
        self.assertEqual(len(self.h.verify_calls), 0)
        # The refusal names the reason + the operator runbook.
        self.assertIn("build_identity_mismatch", str(cm.exception))
        self.assertIn("FULL", str(cm.exception))
        # The one-time operator-facing ERROR marker.
        disable = [l for l in logs.output if "VC_PIPELINE_DISABLE" in l]
        self.assertEqual(len(disable), 1)
        self.assertIn("reason=build_identity_mismatch", disable[0])
        self.assertIn("/deploy_check", disable[0])

    def test_disable_marker_logged_exactly_once_across_many_joins(self):
        self._set_mismatch()

        async def run():
            for _ in range(5):
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()
        with self.assertLogs("mediagrab", level="DEBUG") as logs:
            asyncio.run(run())
        disable = [l for l in logs.output if "VC_PIPELINE_DISABLE" in l]
        self.assertEqual(len(disable), 1,
                         "the operator-facing marker is once-per-process")
        refused = [l for l in logs.output
                   if "VC_JOIN_REFUSED_PIPELINE_DISABLED" in l]
        self.assertEqual(len(refused), 5, "each refusal is DEBUG-traceable")

    def test_env_override_lets_the_join_proceed(self):
        self._set_mismatch()
        os.environ["VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH"] = "1"

        async def run():
            # The overridden pipeline runs the NORMAL path — with the
            # harness's null-stream opt-in that means a real dispatch +
            # the honest unverified raise (NOT the RC-8 refusal).
            with self.assertRaises(self.h.VCJoinUnverifiedError):
                await self._join()
            self.assertGreaterEqual(len(self.backend.dispatches), 1)
        asyncio.run(run())

    def test_fail_open_when_identity_not_checked(self):
        # deploy_health pristine (setUp reset) — the join must run the
        # normal pipeline (the pre-v99.03 behavior every existing test
        # was written against).
        async def run():
            with self.assertRaises(self.h.VCJoinUnverifiedError):
                await self._join()
        asyncio.run(run())


class TestV9903RC8SourceContracts(unittest.TestCase):
    """RC-8/RC-13 wiring: bootstrap publishes the verdict; the loops
    short-circuit; the Bot API commands are registered."""

    def test_bootstrap_publishes_identity_to_deploy_health(self):
        self.assertIn("from . import deploy_health as _v9903_dh", _BOOT_TEXT)
        self.assertIn("_v9903_dh.set_build_identity(", _BOOT_TEXT)
        # The startup operator line (single, ERROR level).
        self.assertIn('"VC_PIPELINE_DISABLE reason=build_identity_mismatch',
                      _BOOT_TEXT)

    def test_pipeline_entry_gate_sits_before_identity_resolution(self):
        # The gate must run BEFORE VCAccountIdentity.resolve (zero RPCs).
        gate_idx = _PIPE_TEXT.find("_vc_pipeline_disable_refusal(chat_ref")
        resolve_idx = _PIPE_TEXT.find(
            "identity = await VCAccountIdentity.resolve(backend, account_id)")
        self.assertGreater(gate_idx, -1)
        self.assertGreater(resolve_idx, -1)
        self.assertLess(gate_idx, resolve_idx)

    def test_discovery_loop_short_circuits_when_disabled(self):
        self.assertIn("AUTO_DISCOVERY_SKIP reason=vc_pipeline_disabled",
                      _VC_TEXT)
        self.assertIn('status"] = "pipeline_disabled"', _VC_TEXT)

    def test_both_reconcile_loops_short_circuit_when_disabled(self):
        self.assertIn("VC_MOD_RECONCILE_SKIP reason=vc_pipeline_disabled",
                      _VC_TEXT)
        self.assertIn(
            "VC_COVERAGE_RECONCILE_SKIP reason=vc_pipeline_disabled",
            _VC_TEXT)

    def test_deploy_check_and_v85accounts_commands_registered(self):
        self.assertIn('CommandHandler(\n            "deploy_check",'
                      ' v99_03_deploy_check_command)', _BOOT_TEXT)
        self.assertIn('CommandHandler(\n            "v85accounts",'
                      ' v99_03_accounts_command)', _BOOT_TEXT)

    def test_deploy_check_reports_identity_and_selfheal(self):
        self.assertIn("build_identity_state()", _BOOT_TEXT)
        self.assertIn("vc_pipeline_disabled_reason()", _BOOT_TEXT)
        self.assertIn("self_heal_report()", _BOOT_TEXT)
        self.assertIn("silence asset", _BOOT_TEXT)

    def test_v85accounts_reports_session_health(self):
        self.assertIn("account_session_health()", _BOOT_TEXT)
        self.assertIn("delete_and_relogin", _BOOT_TEXT)
        self.assertIn("SESSION_REMEDIATION", _BOOT_TEXT)


# ===========================================================================
# RC-9 — self-heal: re-extract the stamped asset from the on-disk ZIP
# ===========================================================================

def _exec_self_heal_functions(source_text: str) -> dict:
    """Exec-extract the RC-9 functions from the REAL bootstrap source so
    the SHIPPED bytes (not a copy) are what the tests run."""
    wanted = {"_v9903_self_heal_disabled", "_v9903_self_heal_zip_candidates",
              "_v9903_self_heal_assets"}
    import logging as _logging
    ns: dict = {"os": os, "hashlib": hashlib,
                "logger": _logging.getLogger("mediagrab"),
                "__name__": "v9903_boot_extract"}
    tree = ast.parse(source_text)
    found = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name in wanted:
            seg = ast.get_source_segment(source_text, node)
            assert seg is not None
            exec(compile(seg, "<bootstrap.py:v99.03-RC-9>", "exec"), ns)
            found.add(node.name)
    missing = wanted - found
    assert not missing, f"functions missing from bootstrap source: {missing}"
    return ns


class TestV9903RC9SelfHeal(unittest.TestCase):
    """The RC-9 mechanics against the REAL shipped function bodies."""

    def setUp(self):
        self.fns = _exec_self_heal_functions(_BOOT_TEXT)
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)

    def tearDown(self):
        os.environ.pop("VC_DISABLE_DEPLOY_SELF_HEAL", None)

    def _scenario(self, asset_bytes: bytes, td: Path):
        module_dir = td / "mediagrab_bot"
        (module_dir / "assets").mkdir(parents=True, exist_ok=True)
        expected = hashlib.sha256(asset_bytes).hexdigest()[:16]
        zip_path = td / "mediagrab_bot_v99.03_deployment.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("mediagrab_bot/assets/vc_silence_600s.opus",
                        asset_bytes)
        stamp = {"assets/vc_silence_600s.opus": expected}
        runtime = {"assets/vc_silence_600s.opus": "missing"}
        return module_dir, stamp, runtime, zip_path

    def test_heal_extracts_the_asset_from_the_zip(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            asset = b"\x11\x22" * 113_000  # 226,000 bytes ≈ the real asset
            module_dir, stamp, runtime, _ = self._scenario(asset, td)
            oldcwd = os.getcwd()
            os.chdir(td)  # the ZIP sits beside the extracted tree
            try:
                with self.assertLogs("mediagrab", level="INFO") as logs:
                    res = self.fns["_v9903_self_heal_assets"](
                        stamp, runtime, str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertTrue(res["ok"], res)
            healed = module_dir / "assets" / "vc_silence_600s.opus"
            self.assertTrue(healed.is_file())
            self.assertEqual(healed.read_bytes(), asset)
            self.assertEqual(
                hashlib.sha256(healed.read_bytes()).hexdigest()[:16],
                stamp["assets/vc_silence_600s.opus"])
            # The mission's exact log line format.
            heal_lines = [l for l in logs.output if "DEPLOY_SELF_HEAL " in l]
            self.assertEqual(len(heal_lines), 1)
            self.assertIn("asset=vc_silence_600s.opus", heal_lines[0])
            self.assertIn(f"sha256={stamp['assets/vc_silence_600s.opus']}",
                          heal_lines[0])
            self.assertIn("source=", heal_lines[0])

    def test_wrong_content_zip_is_refused(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir, stamp, runtime, _ = self._scenario(
                b"RIGHT-CONTENT" * 100, td)
            # Corrupt the ZIP's member AFTER computing the stamp: rebuild
            # the zip with different bytes.
            for z in td.glob("*.zip"):
                z.unlink()
            with zipfile.ZipFile(td / "mediagrab_bot_v99.03_deployment.zip",
                                 "w") as zf:
                zf.writestr("mediagrab_bot/assets/vc_silence_600s.opus",
                            b"WRONG-CONTENT" * 100)
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    stamp, runtime, str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(res["ok"])
            self.assertIn("sha256_mismatch", str(res.get("reason", "")))
            # Unknown bytes were NEVER installed.
            self.assertFalse(
                (module_dir / "assets" / "vc_silence_600s.opus").exists())

    def test_no_zip_on_disk_falls_through_to_fail_fast(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            module_dir = td / "mediagrab_bot"
            (module_dir / "assets").mkdir(parents=True)
            stamp = {"assets/vc_silence_600s.opus": "e6ad24a0ecd48db2"}
            oldcwd = os.getcwd()
            os.chdir(td)  # an empty dir: no deployment ZIP anywhere
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    stamp, {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(res["ok"])
            self.assertEqual(res.get("reason"), "no_deployment_zip_found")

    def test_env_kill_switch_disables_the_heal(self):
        os.environ["VC_DISABLE_DEPLOY_SELF_HEAL"] = "1"
        res = self.fns["_v9903_self_heal_assets"](
            {"assets/vc_silence_600s.opus": "x"},
            {"assets/vc_silence_600s.opus": "missing"}, "/nonexistent")
        self.assertFalse(res["ok"])
        self.assertEqual(res.get("reason"), "disabled_by_env")

    def test_path_traversal_asset_names_are_rejected(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            evil = b"EVIL" * 10
            with zipfile.ZipFile(td / "mediagrab_bot_v99.03_deployment.zip",
                                 "w") as zf:
                zf.writestr("mediagrab_bot/assets/../../../evil.opus", evil)
            stamp = {"assets/../../../evil.opus":
                     hashlib.sha256(evil).hexdigest()[:16]}
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                res = self.fns["_v9903_self_heal_assets"](
                    stamp, {"assets/../../../evil.opus": "missing"},
                    str(td / "tree" / "mediagrab_bot"))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(res["ok"])
            # Nothing escaped the tree.
            self.assertFalse((td / "evil.opus").exists())
            self.assertFalse((td / "tree" / "evil.opus").exists())

    def test_zip_candidates_search_cwd_and_package_roots(self):
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            (td / "pkg" / "mediagrab_bot").mkdir(parents=True)
            (td / "pkg" / "mediagrab_bot_v99.03_deployment.zip").write_bytes(
                b"PK-fake")
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                cands = self.fns["_v9903_self_heal_zip_candidates"](
                    str(td / "pkg" / "mediagrab_bot"))
            finally:
                os.chdir(oldcwd)
            self.assertEqual(
                cands, [str(td / "pkg" / "mediagrab_bot_v99.03_deployment.zip")])

    def test_atomic_write_contract(self):
        # tmp + os.replace — a crash mid-heal can never leave a torn file.
        self.assertIn("mkstemp", _BOOT_TEXT)
        self.assertIn("os.replace(_tmp, _dest)", _BOOT_TEXT)
        self.assertIn('prefix=".v9903_heal_"', _BOOT_TEXT)

    def test_size_bound_contract(self):
        # The 8 MB member bound (the shipped asset is 226 KB).
        self.assertIn("8 * 1024 * 1024", _BOOT_TEXT)


class TestV9903RC9BootIntegration(unittest.TestCase):
    """The identity block wiring: mismatch → heal → re-verify → publish."""

    def test_identity_block_attempts_heal_on_asset_mismatch(self):
        self.assertIn("_v9903_self_heal_assets(", _BOOT_TEXT)
        self.assertIn('_v9903_asset_mismatch_present = any(', _BOOT_TEXT)
        # Only ASSET mismatches trigger the heal (module-only mismatches
        # cannot be healed by re-extracting an asset).
        self.assertIn('str(_m).startswith("assets/")', _BOOT_TEXT)

    def test_successful_heal_reverifies_the_full_identity(self):
        self.assertIn('"BUILD_IDENTITY_VERIFIED stamp_version=%s modules=%d "',
                      _BOOT_TEXT)
        self.assertIn("self_healed=1", _BOOT_TEXT)
        self.assertIn("mark_self_heal(", _BOOT_TEXT)

    def test_failed_heal_logs_the_runbook_and_falls_through(self):
        self.assertIn("DEPLOY_SELF_HEAL_FAILED reason=%s", _BOOT_TEXT)
        self.assertIn("VC_ALLOW_PIPELINE_ON_IDENTITY_MISMATCH=1", _BOOT_TEXT)

    def test_stamp_version_preinitialized_for_every_path(self):
        # The deploy_health publication must never NameError on the
        # missing-stamp (dev tree) paths.
        self.assertIn('_v9812_expected_version = ""', _BOOT_TEXT)


# ===========================================================================
# RC-10 — account session health: "two accounts but showing one"
# ===========================================================================

class TestV9903RC10AccountHealth(unittest.TestCase):
    """Behavioural tests against the REAL mtproto (v99.02 fake stack)."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = T2._load_real_voicechat()

    def setUp(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self._active_bak = self.mt._MTPROTO_ACTIVE_SESSION_PATH
        self._find_bak = self.mt._find_all_session_files
        self._cluster_bak = self.mt.get_userbot_cluster

    def tearDown(self):
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = self._active_bak
        self.mt._find_all_session_files = self._find_bak
        self.mt.get_userbot_cluster = self._cluster_bak

    def _install_production_scenario(self):
        """The EXACT 2026-09-11 production layout: 3 .session files —
        one dead, one primary global, one cluster account."""
        self.mt._find_all_session_files = lambda: [
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_916397080450.session"),
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_918335829278.session"),
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_919006065076.session"),
        ]
        self.mt._register_session_status(
            "cluster_916397080450.session", "unauthorized")
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = (
            "/home/container/mediagrab_bot/data/sessions/"
            "cluster_918335829278.session")

        class _FakeCluster:
            _accounts = {
                "acc_919006065076": {
                    "session_file": "/home/container/mediagrab_bot/data/"
                                    "sessions/cluster_919006065076.session"},
            }
        self.mt.get_userbot_cluster = lambda: _FakeCluster()

    def test_production_three_file_scenario(self):
        self._install_production_scenario()
        h = self.mt.account_session_health()
        # The mission's exact numbers: total_files=3 live=2 dead=1
        # unregistered=0 expected_cluster=1.
        self.assertEqual(h["total_files"], 3)
        self.assertEqual(h["live"], 2)
        self.assertEqual(h["dead"], 1)
        self.assertEqual(h["unregistered"], 0)
        self.assertEqual(h["expected_cluster"], 1)
        self.assertEqual(h["cluster_accounts"], 1)
        by_file = {d["file"]: d for d in h["details"]}
        self.assertEqual(
            by_file["cluster_916397080450.session"]["status"],
            "unauthorized")
        self.assertEqual(
            by_file["cluster_916397080450.session"]["action"],
            "delete_and_relogin")
        self.assertEqual(
            by_file["cluster_918335829278.session"]["status"],
            "primary_global")
        self.assertEqual(
            by_file["cluster_919006065076.session"]["status"],
            "cluster_account_id=acc_919006065076")

    def test_account_session_health_emits_the_summary_line(self):
        self._install_production_scenario()
        with self.assertLogs("mediagrab", level="INFO") as logs:
            self.mt._emit_account_session_health()
        line = [l for l in logs.output
                if "ACCOUNT_SESSION_HEALTH" in l]
        self.assertEqual(len(line), 1)
        self.assertIn("total_files=3", line[0])
        self.assertIn("live=2", line[0])
        self.assertIn("dead=1", line[0])
        self.assertIn("unregistered=0", line[0])
        self.assertIn("expected_cluster=1", line[0])
        self.assertIn("file:cluster_916397080450.session, "
                      "status:unauthorized", line[0])
        self.assertIn("action:delete_and_relogin", line[0])

    def test_registry_survives_file_deletion_honestly(self):
        # The operator deletes the dead file BEFORE re-login: the health
        # view keeps the honest history entry (status recorded) but the
        # on-disk scan no longer sees it — total_files reflects history.
        self._install_production_scenario()
        self.mt._find_all_session_files = lambda: [
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_918335829278.session"),
            Path("/home/container/mediagrab_bot/data/sessions/"
                 "cluster_919006065076.session"),
        ]
        h = self.mt.account_session_health()
        self.assertEqual(h["dead"], 1, "the dead entry is still reported")

    def test_unregistered_file_is_visible_as_such(self):
        self.mt._find_all_session_files = lambda: [
            Path("/x/cluster_911100000011.session")]
        self.mt.get_userbot_cluster = lambda: None
        h = self.mt.account_session_health()
        self.assertEqual(h["total_files"], 1)
        self.assertEqual(h["unregistered"], 1)
        self.assertEqual(h["details"][0]["status"], "unregistered")

    def test_rc10_efficacy_fail_on_revert_no_registry(self):
        """EFFICACY: with the registry REMOVED (the pre-v99.03 world),
        the dead session becomes indistinguishable from an unregistered
        one — proving the registry is what carries the signal."""
        self._install_production_scenario()
        with_registry = self.mt.account_session_health()
        self.assertEqual(with_registry["dead"], 1)
        # REVERT: wipe the registry (what v99.02 effectively had).
        self.mt._SESSION_HEALTH_REGISTRY.clear()
        without = self.mt.account_session_health()
        self.assertEqual(without["dead"], 0)
        self.assertEqual(without["details"][0]["status"], "unregistered")
        # ...i.e. the production test above (dead == 1) FAILS in the
        # reverted state — fail-on-revert proven by contrast.


class TestV9903RC10SourceContracts(unittest.TestCase):
    """The emission wiring: import end + heartbeat + command surface."""

    def test_import_end_emits_session_health(self):
        self.assertIn("_emit_account_session_health()", _MT_TEXT)

    def test_both_unauthorized_sites_register_and_remediate(self):
        # The temp-client site (the exact production line-131 site)…
        self.assertIn(
            'logger.warning("SESSION_UNAUTHORIZED file=%s "\n'
            '                                       "reason=not_authorized", '
            'sf.name)',
            _MT_TEXT)
        # …and the legacy-reuse site, both followed by the RC-11 pair.
        self.assertIn(
            'logger.warning("SESSION_UNAUTHORIZED file=%s "\n'
            '                                       "reason=legacy_not_authorized", '
            'sf.name)',
            _MT_TEXT)
        # 3 CALL SITES + the definition itself.
        self.assertEqual(_MT_TEXT.count("_emit_session_remediation("), 4,
                         "def + temp-client + legacy + mtproto_start")
        self.assertEqual(
            _MT_TEXT.count("_register_session_status("), 8,
            "def + 7 call sites (v99.03's 6 + v99.05 RC-16 "
            "login_live_owner_reuse registration)")

    def test_heartbeat_carries_account_health_every_300s(self):
        self.assertIn("if _v808_hb_count % 5 == 0:", _HANDLERS_TEXT)
        self.assertIn("ACCOUNT_HEALTH live_clients=%d ", _HANDLERS_TEXT)
        self.assertIn("cluster_accounts=%d dead_sessions=%d",
                      _HANDLERS_TEXT)
        self.assertIn("expected_cluster=%d", _HANDLERS_TEXT)

    def test_heartbeat_flushes_suppression_windows(self):
        self.assertIn("_null_stream_suppress_flush()", _HANDLERS_TEXT)

    def test_mtproto_start_records_the_active_session(self):
        self.assertIn("_MTPROTO_ACTIVE_SESSION_PATH = ", _MT_TEXT)
        self.assertIn('"primary_global"', _MT_TEXT)

    def test_startup_report_semantics_documented(self):
        # ACCOUNT_STARTUP_REPORT counts CLUSTER accounts only — the
        # RC-10 block comment documents why the operator saw "one".
        self.assertIn("counts REGISTERED CLUSTER accounts", _MT_TEXT)


# ===========================================================================
# RC-11 — dead-session remediation runbook + the login helper
# ===========================================================================

class TestV9903RC11Remediation(unittest.TestCase):
    """Behavioural: the remediation line with the EXACT command."""

    @classmethod
    def setUpClass(cls):
        cls.vw, cls.mt = T2._load_real_voicechat()

    def test_remediation_line_after_unauthorized_carries_exact_command(self):
        with self.assertLogs("mediagrab", level="WARNING") as logs:
            self.mt._emit_session_remediation(
                "cluster_916397080450.session")
        rem = [l for l in logs.output if "SESSION_REMEDIATION" in l]
        self.assertEqual(len(rem), 1)
        # The phone is derived from the stem — the EXACT command for THIS
        # file (the importer derives missing phones the same way).
        self.assertIn(
            "python -m mediagrab_bot.tools.login --phone +916397080450",
            rem[0])
        # The runbook steps are concrete.
        self.assertIn("Delete the .session file", rem[0])
        self.assertIn("Stop the bot", rem[0])
        self.assertIn("v99.03 RC-11", rem[0])

    def test_non_numeric_stem_degrades_to_placeholder(self):
        with self.assertLogs("mediagrab", level="WARNING") as logs:
            self.mt._emit_session_remediation("cluster_unknown.session")
        rem = [l for l in logs.output if "SESSION_REMEDIATION" in l]
        self.assertEqual(len(rem), 1)
        self.assertIn("--phone <phone>", rem[0])

    def test_unauthorized_is_immediately_followed_by_remediation(self):
        # Source contract: the remediation call sits DIRECTLY after each
        # SESSION_UNAUTHORIZED warning (same block, next statements).
        for site in ('"reason=not_authorized", sf.name)',
                     '"reason=legacy_not_authorized", sf.name)'):
            idx = _MT_TEXT.find(site)
            self.assertGreater(idx, -1, site)
            window = _MT_TEXT[idx: idx + 600]
            self.assertIn("_register_session_status(sf.name, \"unauthorized\")",
                          window)
            self.assertIn("_emit_session_remediation(sf.name)", window)

    def test_login_helper_exists_and_is_offline_runnable(self):
        self.assertTrue((_SRC / "tools" / "__init__.py").is_file())
        self.assertTrue((_SRC / "tools" / "login.py").is_file())
        # --help works with NO network, NO telegram import (argparse
        # exits before the config/telethon imports).
        proc = subprocess.run(
            [sys.executable, str(_SRC / "tools" / "login.py"), "--help"],
            capture_output=True, text=True, timeout=60)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("--phone", proc.stdout)

    def test_login_helper_rejects_bad_phone_offline(self):
        proc = subprocess.run(
            [sys.executable, str(_SRC / "tools" / "login.py"),
             "--phone", "abc"],
            capture_output=True, text=True, timeout=60)
        self.assertEqual(proc.returncode, 2)
        self.assertIn("ERROR", proc.stderr)

    def test_login_helper_guards_against_running_bot(self):
        self.assertIn("def _bot_running(", _LOGIN_TEXT)
        self.assertIn(".v85_instance.pid", _LOGIN_TEXT)

    def test_login_helper_writes_cluster_named_session(self):
        self.assertIn('f"cluster_{digits}"', _LOGIN_TEXT)


# ===========================================================================
# RC-12 — blocked-join suppression: one WARNING + SUPPRESSED summaries
# ===========================================================================

class TestV9903RC12Suppression(T.PipelineTestBase):
    """The production noise: 40 blocked joins / 31 chats / 36 min, each
    repeat re-paying the full pre-gate cost (~8 entity RPCs)."""

    def setUp(self):
        super().setUp()
        # Gate ACTIVE (production default) — the v99.00 harness opt-in
        # is removed for this suite.
        os.environ.pop("VC_ALLOW_NULL_STREAM_JOIN", None)
        os.environ.pop("VC_JOIN_PREFER_REAL_STREAM", None)
        os.environ.pop("VC_SILENCE_ASSET", None)
        self.pm = self.h.vc_pipeline_mod

    def tearDown(self):
        super().tearDown()
        os.environ.pop("VC_JOIN_PREFER_REAL_STREAM", None)
        self.pm._null_stream_suppress_reset_for_tests()

    def test_first_block_warns_repeats_short_circuit_at_entry(self):
        async def run():
            # Join #1: the FULL pipeline runs (entity resolution happens),
            # the gate blocks, ONE WARNING.
            with self.assertLogs("mediagrab", level="WARNING") as w1:
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()
            warned = [l for l in w1.output
                      if "VC_JOIN_BLOCKED_NULL_STREAM" in l
                      and "WARNING" in l]
            self.assertEqual(len(warned), 1)
            entity_after_first = len(self.h.entity_calls)
            self.assertGreaterEqual(entity_after_first, 1,
                                    "the first block pays the real cost")
            # Joins #2..#5: refused at ENTRY — zero additional entity
            # resolution, and the repeats log at DEBUG only.
            with self.assertLogs("mediagrab", level="DEBUG") as d1:
                for _ in range(4):
                    with self.assertRaises(self.h.VCTransportError) as cm:
                        await self._join()
                    self.assertIn("suppression window", str(cm.exception))
            self.assertEqual(len(self.h.entity_calls), entity_after_first,
                             "repeats must not re-resolve the entity")
            debug_repeats = [l for l in d1.output
                             if "VC_JOIN_BLOCKED_NULL_STREAM" in l]
            self.assertEqual(len(debug_repeats), 4)
        asyncio.run(run())

    def test_suppressed_summary_on_window_expiry(self):
        async def run():
            with self.assertRaises(self.h.VCTransportError):
                await self._join()   # opens the window
            for _ in range(3):
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()   # suppressed repeats
        asyncio.run(run())
        # Expire the window (the heartbeat flush path does this every
        # 300s in production).
        key = list(self.pm._NULL_STREAM_SUPPRESS.keys())[0]
        rec = self.pm._NULL_STREAM_SUPPRESS[key]
        self.assertEqual(rec["suppressed"], 3)
        rec["window_start"] -= 301.0  # simulate window expiry
        with self.assertLogs("mediagrab", level="WARNING") as logs:
            flushed = self.pm._null_stream_suppress_flush()
        self.assertGreaterEqual(flushed, 1)
        summary = [l for l in logs.output
                   if "VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED" in l]
        self.assertEqual(len(summary), 1)
        self.assertIn("count=3", summary[0])
        self.assertIn("reason=", summary[0])
        # The window is gone: the NEXT join pays the full cost again and
        # logs a fresh WARNING (one WARNING per window — the mission's
        # collapse contract).
        async def run2():
            with self.assertLogs("mediagrab", level="WARNING") as w2:
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()
            warned = [l for l in w2.output
                      if "VC_JOIN_BLOCKED_NULL_STREAM" in l
                      and "WARNING" in l]
            self.assertEqual(len(warned), 1)
        asyncio.run(run2())

    def test_entity_resolution_rpc_reduction_at_least_80_percent(self):
        """Acceptance #4: in the repeated-block condition the entity
        resolution count must drop by ≥80% (10 joins → 1 resolution)."""

        async def run():
            for _ in range(10):
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()
        asyncio.run(run())
        with_suppression = len(self.h.entity_calls)
        self.assertEqual(with_suppression, 1,
                         "only the FIRST join resolves the entity")
        # The reverted (v99.02) behavior for comparison: every join
        # resolves.  (10 resolutions vs 1 → 90% reduction ≥ 80%.)
        self.pm._null_stream_suppress_reset_for_tests()
        self.pm._NULL_STREAM_SUPPRESS.clear()
        # Neutralize the entry check by removing the windows' effect is
        # not possible without the gate firing first — emulate the
        # pre-RC-12 world by re-joining with a FRESH window each time.
        async def run_pre_v9903():
            for _ in range(10):
                self.pm._NULL_STREAM_SUPPRESS.clear()  # pre-RC-12: no memory
                with self.assertRaises(self.h.VCTransportError):
                    await self._join()
        asyncio.run(run_pre_v9903())
        without_suppression = len(self.h.entity_calls) - with_suppression
        self.assertEqual(without_suppression, 10)
        reduction = 1.0 - (with_suppression / (
            with_suppression + without_suppression))
        self.assertGreaterEqual(reduction, 0.80)

    def test_operator_opt_in_is_never_suppressed(self):
        os.environ["VC_ALLOW_NULL_STREAM_JOIN"] = "1"

        async def run():
            # Two dispatches, zero refusals: the opt-in disables BOTH the
            # v99.02 gate and the v99.03 entry short-circuit.
            for _ in range(2):
                with self.assertRaises(self.h.VCJoinUnverifiedError):
                    await self._join()
            self.assertEqual(len(self.backend.dispatches), 2)
        asyncio.run(run())

    def test_distinct_chats_have_independent_windows(self):
        async def run():
            for chat in (-1001111111111, -1002222222222):
                with self.assertRaises(self.h.VCTransportError):
                    await self._join(chat=chat)
            self.assertEqual(len(self.pm._NULL_STREAM_SUPPRESS), 2)
        asyncio.run(run())


# ===========================================================================
# RC-8 efficacy — fail-on-revert (the gate surgically removed)
# ===========================================================================

class TestV9903EfficacyFailOnRevert(unittest.TestCase):
    """EFFICACY PROOFS: with each fix surgically REMOVED from a scratch
    copy of the source, the guarded contract observably breaks.  (The
    v99.02 convention: a regression test is only trusted if its target
    fix, when reverted, actually fails it.)"""

    def _load_pipeline_from_source(self, source: str, tag: str):
        """Load a (possibly reverted) vc_pipeline source into a fresh
        harness package context and run one join with a mismatched
        deploy_health state; returns (raised_exception, entity_calls,
        exc_type_name, module)."""
        import logging
        T._install_fake_telethon()
        # spec_from_file_location needs a REAL file: materialise the
        # (possibly reverted) source into a temp module file.
        tmpdir = tempfile.mkdtemp(prefix=f"v9903_eff_{tag}_")
        src_path = Path(tmpdir) / "vc_pipeline.py"
        src_path.write_text(source, encoding="utf-8")

        async def _drive():
            pkg = types.ModuleType(f"mg_eff_{tag}")
            pkg.__path__ = []
            sys.modules[f"mg_eff_{tag}"] = pkg
            vw = types.ModuleType(f"mg_eff_{tag}.voicechat")

            class VCTransportError(Exception):
                pass

            class VCJoinUnverifiedError(VCTransportError):
                pass

            vw.VCTransportError = VCTransportError
            vw.VCJoinUnverifiedError = VCJoinUnverifiedError
            vw._vc_active_join_backends_by_chat = {}
            vw._vc_entity_negative_clear_for_chat = lambda gid: None
            vw._vc_evict_poisoned_entity_cache = (
                lambda raw_id, marked_id, scope: 0)
            vw._vc_join_account_eligible = lambda aid, **kw: (True, "ok")
            vw._vc_join_account_rank = lambda aid, **kw: (0.0, 0, 0)
            vw._vc_join_account_record_join = lambda aid: None
            vw._vc_join_account_park_floodwait = lambda a, s, **kw: None
            vw._vc_record_verify_evidence = lambda *a, **k: None
            vw._vc_classify_join_transport_error = lambda t: "deterministic"
            vw.vc_registry_register = AsyncNoop()
            vw.vc_registry_get = AsyncNone()
            vw.vc_get_backend = lambda account_id="": None
            vw.vc_detect_active_call = AsyncDict({"call_id": 5,
                                                  "access_hash": 7})
            vw.vc_check_telegram_participation = AsyncStr("unknown")
            vw._vc_call_gone_evidence_check = AsyncStr("inconclusive")
            mt = types.ModuleType(f"mg_eff_{tag}.mtproto")

            entity_calls = []

            async def _resolve(client, chat_ref, **kw):
                entity_calls.append((chat_ref, kw.get("access_hash")))
                class _Ent:
                    id = 1234567890
                return {"ok": True, "entity": _Ent(), "source": "cache"}

            mt.resolve_vc_entity = _resolve
            mt.get_userbot_cluster = lambda: None
            mt.mtproto_get_client_legacy = lambda: None
            mt.mtproto_get_client = lambda: None
            mt._vc_client_scope = lambda client: "global"
            mt._vc_entity_cache = {}
            mt._v9810_hash_invalid_record = lambda s, c, a: None
            sys.modules[f"mg_eff_{tag}.voicechat"] = vw
            sys.modules[f"mg_eff_{tag}.mtproto"] = mt
            # deploy_health with a mismatch (the RC-8 trigger).
            spec = importlib.util.spec_from_file_location(
                f"mg_eff_{tag}.deploy_health", str(_SRC / "deploy_health.py"))
            dh = importlib.util.module_from_spec(spec)
            sys.modules[f"mg_eff_{tag}.deploy_health"] = dh
            spec.loader.exec_module(dh)
            dh.set_build_identity(
                "MISMATCH", "assets/vc_silence_600s.opus actual=missing")
            spec = importlib.util.spec_from_file_location(
                f"mg_eff_{tag}.vc_pipeline", str(src_path))
            mod = importlib.util.module_from_spec(spec)
            sys.modules[f"mg_eff_{tag}.vc_pipeline"] = mod
            try:
                spec.loader.exec_module(mod)
            except Exception as exc:
                raise AssertionError(f"reverted source must still load: {exc}")

            class _B:
                backend_name = "eff"

                async def _is_target_in_calls_container(self, chat):
                    return False

                async def _leave_target(self, chat):
                    return None
            raised = None
            try:
                await mod.run_vc_join(_B(), -1001234567890,
                                      call_id=42, access_hash=999)
            except Exception as exc:  # noqa: BLE001
                raised = exc
            return raised, entity_calls, str(type(raised)), mod

        result = {}

        async def _capture():
            result["out"] = await _drive()
        asyncio.run(_capture())
        return result["out"]

    def test_rc8_revert_lets_joins_pay_the_entity_cost_again(self):
        """Surgically REMOVE the RC-8 entry gate from a scratch copy →
        the join NO LONGER refuses at entry (entity resolution runs) —
        exactly the v99.02 production waste the fix eliminates.  This
        proves the RC-8 behavioural test fails when the fix is reverted."""
        self.assertIn(
            "        _v9903_disable = _v9903_dh.vc_pipeline_disabled_reason()",
            _PIPE_TEXT, "RC-8 gate present in shipped source")
        # Build the reverted source: neutralize the deploy_health import
        # so the gate reads nothing (the pre-v99.03 pipeline had NO
        # deploy_health dependency at all).
        gate_block = (
            "    try:\n"
            "        from . import deploy_health as _v9903_dh\n"
            "        _v9903_disable = _v9903_dh.vc_pipeline_disabled_reason()\n"
            "    except Exception:  # noqa: BLE001\n"
            "        _v9903_disable = None\n"
            "    if _v9903_disable is not None:\n"
            "        raise _vc_pipeline_disable_refusal(chat_ref, account_id,\n"
            "                                           _v9903_disable)\n")
        self.assertIn(gate_block, _PIPE_TEXT,
                      "revert surgery anchor must match the shipped source")
        reverted = _PIPE_TEXT.replace(gate_block, "    _v9903_disable = None\n", 1)
        self.assertNotIn("from . import deploy_health as _v9903_dh", reverted,
                         "revert surgery must remove the gate")
        raised, entity_calls, exc_name, _ = self._load_pipeline_from_source(
            reverted, "rc8rev")
        # REVERTED behavior: the join PROCEEDS past entry (pays entity
        # resolution) — i.e. the RC-8 test's assertions (raise +
        # zero entity calls) would FAIL on this source.  Efficacy proven.
        self.assertGreaterEqual(
            len(entity_calls), 1,
            "reverted gate lets the join pay entity-resolution RPCs")
        # The SHIPPED source, same scenario: refusal with ZERO calls.
        raised2, entity_calls2, exc_name2, _ = self._load_pipeline_from_source(
            _PIPE_TEXT, "rc8fix")
        self.assertIsNotNone(raised2)
        self.assertIn("build_identity_mismatch", str(raised2))
        self.assertEqual(entity_calls2, [])

    def test_rc9_revert_cannot_heal(self):
        """Neutralise the extraction read (the RC-9 core) in a scratch
        copy → the heal can no longer repair the asset → the RC-9
        success test would fail.  Efficacy proven by contrast."""
        # The shipped function heals:
        fns = _exec_self_heal_functions(_BOOT_TEXT)
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            asset = b"A" * 4096
            module_dir = td / "mediagrab_bot"
            (module_dir / "assets").mkdir(parents=True)
            expected = hashlib.sha256(asset).hexdigest()[:16]
            with zipfile.ZipFile(td / "mediagrab_bot_v99.03_deployment.zip",
                                 "w") as zf:
                zf.writestr("mediagrab_bot/assets/vc_silence_600s.opus", asset)
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                ok_case = fns["_v9903_self_heal_assets"](
                    {"assets/vc_silence_600s.opus": expected},
                    {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertTrue(ok_case["ok"])
        # REVERT: the read of the ZIP member returns wrong bytes — the
        # sha256 verification then refuses to install anything and the
        # heal fails (the pre-v99.03 world: no repair at all).
        anchor = "                        _data = _zf.read(_member)\n"
        self.assertIn(anchor, _BOOT_TEXT,
                      "revert surgery anchor must match the shipped source")
        reverted_src = _BOOT_TEXT.replace(
            anchor, "                        _data = b'REVERTED-NO-EXTRACTION'\n", 1)
        fns_rev = _exec_self_heal_functions(reverted_src)
        with tempfile.TemporaryDirectory() as td_s:
            td = Path(td_s)
            asset = b"A" * 4096
            module_dir = td / "mediagrab_bot"
            (module_dir / "assets").mkdir(parents=True)
            expected = hashlib.sha256(asset).hexdigest()[:16]
            with zipfile.ZipFile(td / "mediagrab_bot_v99.03_deployment.zip",
                                 "w") as zf:
                zf.writestr("mediagrab_bot/assets/vc_silence_600s.opus", asset)
            oldcwd = os.getcwd()
            os.chdir(td)
            try:
                rev_case = fns_rev["_v9903_self_heal_assets"](
                    {"assets/vc_silence_600s.opus": expected},
                    {"assets/vc_silence_600s.opus": "missing"},
                    str(module_dir))
            finally:
                os.chdir(oldcwd)
            self.assertFalse(rev_case["ok"], "reverted heal cannot repair")
            self.assertIn("sha256_mismatch", str(rev_case.get("reason", "")))
            self.assertFalse(
                (module_dir / "assets" / "vc_silence_600s.opus").exists())

    def test_rc10_revert_loses_the_dead_session_signal(self):
        """Covered behaviourally in TestV9903RC10AccountHealth
        (test_rc10_efficacy_fail_on_revert_no_registry): wiping the
        registry (the pre-v99.03 state) turns dead=1 into dead=0.  This
        placeholder asserts the companion test exists in this suite."""
        self.assertTrue(hasattr(TestV9903RC10AccountHealth,
                                "test_rc10_efficacy_fail_on_revert_no_registry"))


# Async helper shims used by the efficacy loader ---------------------------

class AsyncNoop:
    def __init__(self, ret=None):
        self.ret = ret

    async def __call__(self, *a, **kw):
        return self.ret


class AsyncNone(AsyncNoop):
    pass


class AsyncDict(AsyncNoop):
    pass


class AsyncStr(AsyncNoop):
    pass


# ===========================================================================
# Version + packaging contracts (§21)
# ===========================================================================

class TestV9903VersionStamp(unittest.TestCase):
    def test_init_version(self):
        self.assertIn('__bot_version__ = "v99.11.1"', _INIT_TEXT)

    def test_service_version(self):
        self.assertIn("(24/7 supervised, v99.11)", _SERVICE_TEXT)  # v99.11 release bump: tracks CURRENT

    def test_stamp_version_tracks_the_artifact(self):
        stamp_path = _SRC / "build_stamp.json"
        if not stamp_path.exists():
            self.skipTest("dev tree without a stamp")
        with open(stamp_path, encoding="utf-8") as f:
            stamp = json.load(f)
        # v99.11 release bump: stamp version tracks CURRENT.
        self.assertEqual(stamp.get("version"), "v99.11.1")

    def test_new_modules_ship(self):
        self.assertTrue((_SRC / "deploy_health.py").is_file())
        self.assertTrue((_SRC / "tools" / "login.py").is_file())
        self.assertTrue((_SRC / "tools" / "__init__.py").is_file())

    def test_rc_markers_reference_v9903(self):
        for marker in ("VC_PIPELINE_DISABLE", "DEPLOY_SELF_HEAL ",
                       "ACCOUNT_SESSION_HEALTH", "SESSION_REMEDIATION",
                       "VC_JOIN_BLOCKED_NULL_STREAM_SUPPRESSED",
                       "AUTO_DISCOVERY_SKIP reason=vc_pipeline_disabled"):
            self.assertIn(marker, _PIPE_TEXT + _BOOT_TEXT + _MT_TEXT
                          + _HANDLERS_TEXT + _VC_TEXT,
                          f"marker missing: {marker}")


if __name__ == "__main__":
    unittest.main()
