"""v98.12 §31 — LONG-RUN STRESS DRIVER (deterministic simulated world).

Runs the REAL extracted v98.12 functions (``_vc_telegram_call_still_valid``,
``_vc_call_gone_evidence_check``, ``_vc_record_verify_evidence``) + the REAL
``mtproto_generation.ReconnectCoordinator`` through a LONG-RUNNING simulated
24/7 workload:

  * 2 accounts (acc_A global-primary + acc_B) × 12 VCs
  * repeated join/verify cycles (default 400 cycles ≈ simulated hours)
  * every cycle: some calls are REPLACED (new call_id — the (6).log
    false-CALL-GONE race), some GENUINELY end, some detects time out,
    occasional FloodWait, account B disconnect/reconnect windows,
    duplicate concurrent verify requests (single-flight stress), and
    reconnect-generation churn via the REAL coordinator.

Reports (§31's required accounting):
    tasks_created / completed / failed / cancelled / active_tasks
    clients_created / retired (generation manager)
    generations_created / retired
    joins / rejoins / false_stale / real_stale
    RPCs (GetGroupCall + GetFullChannel) / dialog_scans (n/a — resolver
    world not engaged; recorded as 0 by design)
    registry / evidence / corroboration dict bounds (unbounded-growth check)

PASS criteria:
    * false_stale == 0        (every stale-identity GroupcallInvalid →
                               refreshed/preserved — the v98.12 §5 contract)
    * real_stale recovered   (genuine disappearances detected + left)
    * no task leak           (active_tasks returns to baseline)
    * no unbounded growth    (all bookkeeping dicts bounded by world size)
    * no deadlock            (every cycle completes within its budget)
"""
from __future__ import annotations

import asyncio
import logging
import random
import sys
import time
import types
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _v9812_driver as base  # noqa: E402  (reuses the exec'd real functions)

NS = base.NS
W = base.W
GEN = base.GEN

logging.basicConfig(level=logging.WARNING, stream=sys.stdout)
log = logging.getLogger("v9812.longrun")

# ---------------------------------------------------------------------------
# Accounting
# ---------------------------------------------------------------------------
STATS = {
    "tasks_created": 0, "tasks_completed": 0, "tasks_failed": 0,
    "tasks_cancelled": 0, "generations_created": 0, "generations_retired": 0,
    "joins": 0, "rejoins": 0, "false_stale": 0, "real_stale": 0,
    "preserved_unverified": 0, "identity_refreshes": 0,
    "rpc_getgroupcall": 0, "rpc_getfullchannel": 0,
    "floodwait": 0, "detect_timeouts": 0,
    "account_reconnect_attempts": 0, "reconnect_successes": 0,
}


class _TaskAccountingWrap:
    """Wraps task creation to count created/completed/failed/cancelled."""

    def __init__(self):
        self._orig_create = asyncio.tasks.Task
        self.active: set[int] = set()

    def patch(self):
        orig = asyncio.ensure_future

        def tracked(coro, **kw):
            STATS["tasks_created"] += 1
            t = orig(coro, **kw)

            def _done(task):
                STATS["tasks_completed"] += 1
                if task.cancelled():
                    STATS["tasks_cancelled"] += 1
                elif task.exception() is not None:
                    STATS["tasks_failed"] += 1

            t.add_done_callback(_done)
            return t

        asyncio.ensure_future = tracked
        return orig

    def unpatch(self, orig):
        asyncio.ensure_future = orig


# ---------------------------------------------------------------------------
# The simulated 24/7 world
# ---------------------------------------------------------------------------
class StressWorld:
    def __init__(self, chats: int = 12):
        self.n = chats
        self.raw_ids = [100000 + i for i in range(chats)]
        # chat state: owner account, current call identity, joined flag
        self.chats: dict[int, dict[str, Any]] = {}
        for i, raw in enumerate(self.raw_ids):
            self.chats[raw] = {
                "owner": "acc_A" if i % 2 == 0 else "acc_B",
                "call_id": -(1000 + i),
                "access_hash": 5000 + i,
                "joined": True,
                "container_present": True,
            }
            W.calls[raw] = {"call_id": -(1000 + i), "access_hash": 5000 + i}

    def evolve(self, cycle: int, rng: random.Random) -> list[str]:
        """Advance the world one step; returns the events applied.

        CRITICAL (the (6).log race semantics): a REPLACED call updates ONLY
        the Telegram-side world (W.calls) — the chat's RECORDED identity
        (st["call_id"], what the code carries after a failed recheck) stays
        at the OLD value → the next corroboration asks about the OBSOLETE
        identity → GroupcallInvalid → the v98.12 evidence gate decides.
        An ENDED call keeps the chat 'joined' with a stale container object
        (exactly the v98.05 silent-death shape) → the verify must prove it
        GONE with strong evidence.
        """
        events = []
        for i, raw in enumerate(self.raw_ids):
            st = self.chats[raw]
            if not st["joined"] or not W.calls.get(raw):
                continue
            roll = rng.random()
            if roll < 0.08:
                # call REPLACED server-side (recorded identity goes stale)
                new_id = -(1_000_000 + cycle * 100 + i)
                W.calls[raw] = {"call_id": new_id, "access_hash": 7_000_000 + cycle * 100 + i}
                events.append(f"replaced:{raw}")
            elif roll < 0.12:
                # call GENUINELY ended — chat still 'joined' w/ stale container
                W.calls.pop(raw, None)
                events.append(f"ended:{raw}")
            elif roll < 0.15:
                # detect transiently times out (weak-evidence path)
                W.detect_error[(st["owner"], raw)] = TimeoutError("simulated")
                events.append(f"detect_timeout:{raw}")
            elif roll < 0.18 and cycle > 3:
                # FloodWait-equivalent: GroupcallInvalid for the owner on the
                # CURRENT identity (server-side rejection of the pair)
                W.groupcall_invalid[(st["owner"], st["call_id"])] = True
                events.append(f"groupcall_invalid:{raw}")
        # account B has a bad network window every ~40 cycles
        if cycle % 40 == 7:
            W.accounts["acc_B"].connected = False
            events.append("acc_B_disconnected")
        elif cycle % 40 == 13:
            W.accounts["acc_B"].connected = True
            events.append("acc_B_reconnected")
        return events

    def cleanup_errors(self):
        W.detect_error.clear()
        W.groupcall_invalid.clear()


# ---------------------------------------------------------------------------
# One verify cycle (the REAL functions under stress)
# ---------------------------------------------------------------------------
async def verify_one(sw: StressWorld, raw: int, recorded_call_id: int,
                     recorded_ah: int) -> str:
    """Mirror of the shipped verify path using the REAL functions:
    corroborate (owner account) → on False → evidence check → gate.
    Records evidence + corroboration-throttle entries EXACTLY like the
    shipped verify_joined (bounded-growth accounting)."""
    st = sw.chats[raw]
    owner = st["owner"]
    corr = await NS["_vc_telegram_call_still_valid"](
        raw, recorded_call_id, recorded_ah, account_id=owner)
    STATS["rpc_getgroupcall"] += 1
    if corr is True:
        NS["_vc_corroboration_cache"][raw] = time.monotonic()
        NS["_vc_record_verify_evidence"](
            raw, outcome="joined", strength="strong", reason="corroborated",
            account_id=owner, call_id=recorded_call_id)
        return "joined"
    if corr is None:
        STATS["floodwait"] += 1
        NS["_vc_record_verify_evidence"](
            raw, outcome="unknown", strength="weak", reason="corroboration_failed",
            account_id=owner, call_id=recorded_call_id)
        STATS["preserved_unverified"] += 1
        return "preserve"        # FloodWait / timeout → preserve (§5)
    # corr is False (GroupcallInvalid) → evidence check (REAL function)
    ev = await NS["_vc_call_gone_evidence_check"](
        raw, recorded_call_id, recorded_ah, account_id=owner)
    STATS["rpc_getfullchannel"] += 1
    if ev == "refreshed":
        STATS["identity_refreshes"] += 1
        NS["_vc_record_verify_evidence"](
            raw, outcome="joined", strength="strong", reason="identity_refreshed",
            account_id=owner, call_id=recorded_call_id)
        return "joined"          # identity refreshed; join preserved
    if ev == "strong_negative":
        NS["_vc_record_verify_evidence"](
            raw, outcome="unknown", strength="strong_negative",
            reason="call_gone_confirmed", account_id=owner,
            call_id=recorded_call_id)
        STATS["real_stale"] += 1
        st["joined"] = False
        st["container_present"] = False
        return "left"
    if ev == "inconclusive":
        STATS["detect_timeouts"] += 1
        STATS["preserved_unverified"] += 1
        NS["_vc_record_verify_evidence"](
            raw, outcome="unknown", strength="weak", reason="recheck_inconclusive",
            account_id=owner, call_id=recorded_call_id)
        return "preserve"            # weak → preserve
    raise AssertionError(f"unexpected evidence outcome: {ev}")


async def run_cycle(sw: StressWorld, cycle: int, rng: random.Random) -> None:
    events = sw.evolve(cycle, rng)
    # occasionally duplicate-verify concurrently (single-flight stress)
    concurrent = cycle % 10 == 0
    for raw in sw.raw_ids:
        st = sw.chats[raw]
        if not st["joined"]:
            # simulate a rejoin attempt next cycle for ended chats
            if rng.random() < 0.5:
                W.calls[raw] = {"call_id": -(2_000_000 + cycle), "access_hash": 9}
                st.update({"call_id": -(2_000_000 + cycle), "access_hash": 9,
                           "joined": True, "container_present": True})
                STATS["rejoins"] += 1
            continue
        # the recorded identity is the chat's LAST-KNOWN identity (possibly
        # obsolete — exactly the (6).log condition after a failed recheck)
        recorded_call_id, recorded_ah = st["call_id"], st["access_hash"]
        if concurrent:
            # duplicate concurrent verifies (single-flight stress) — created
            # via ensure_future so the task accounting wrapper counts them.
            t1 = asyncio.ensure_future(
                verify_one(sw, raw, recorded_call_id, recorded_ah))
            t2 = asyncio.ensure_future(
                verify_one(sw, raw, recorded_call_id, recorded_ah))
            results = await asyncio.gather(t1, t2, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    STATS["tasks_failed"] += 1
        else:
            await verify_one(sw, raw, recorded_call_id, recorded_ah)
        STATS["joins"] += 1
        # refresh the recorded identity from the world (the join-registry
        # update the real worker performs)
        cur = W.calls.get(raw)
        if cur is not None:
            st["call_id"], st["access_hash"] = cur["call_id"], cur["access_hash"]
    sw.cleanup_errors()
    # every ~25 cycles: reconnect churn via the REAL coordinator
    if cycle % 25 == 3:
        STATS["account_reconnect_attempts"] += 1
        coord = GEN.ReconnectCoordinator()

        async def reconnect_fn(gen):
            STATS["generations_created"] += 1
            await asyncio.sleep(0.01)
            if W.accounts["acc_B"].connected:
                STATS["generations_retired"] += 1
                STATS["reconnect_successes"] += 1
                return True
            raise asyncio.TimeoutError()

        try:
            await coord.request_reconnect(
                session_path="/tmp/stress.session", account_id="primary",
                reconnect_fn=reconnect_fn)
        except Exception:  # noqa: BLE001
            pass
    _ = events  # (logged at debug only — deterministic world, no flakiness)


async def main(cycles: int = 400) -> int:
    rng = random.Random(20260903)      # deterministic
    sw = StressWorld()
    wrap = _TaskAccountingWrap()
    orig = wrap.patch()
    t0 = time.monotonic()
    baseline_tasks = len(asyncio.all_tasks())
    try:
        for cycle in range(cycles):
            await asyncio.wait_for(run_cycle(sw, cycle, rng), timeout=30.0)
    finally:
        wrap.unpatch(orig)
    dt = time.monotonic() - t0
    final_tasks = len(asyncio.all_tasks())

    # ---- verdicts --------------------------------------------------------
    checks = {
        "false_stale==0": STATS["false_stale"] == 0,
        "real_stale_detected": STATS["real_stale"] >= 1,
        "identity_refreshes>0": STATS["identity_refreshes"] > 0,
        "preserved_weak>0": STATS["preserved_unverified"] > 0,
        "no_task_leak": final_tasks <= baseline_tasks + 1,
        "evidence_bounded": len(NS["_vc_last_verify_evidence"]) <= sw.n,
        "corroboration_bounded": len(NS["_vc_corroboration_cache"]) <= sw.n,
        "reconnects_bounded": STATS["account_reconnect_attempts"] <= cycles // 25 + 2,
        "reconnect_recovered": STATS["reconnect_successes"] >= 1,
        "joins_rejoined": STATS["joins"] > cycles and STATS["rejoins"] > 0,
    }
    print("=== v98.12 LONG-RUN STRESS REPORT (SIMULATED/CONTROLLED) ===")
    print(f"cycles={cycles} duration={dt:.1f}s chats={sw.n} accounts=2")
    for k in ("tasks_created", "tasks_completed", "tasks_failed",
              "tasks_cancelled", "generations_created", "generations_retired",
              "joins", "rejoins", "false_stale", "real_stale",
              "identity_refreshes", "preserved_unverified",
              "rpc_getgroupcall", "rpc_getfullchannel", "floodwait",
              "account_reconnect_attempts", "reconnect_successes"):
        print(f"  {k}={STATS[k]}")
    print(f"  active_tasks_baseline={baseline_tasks} final={final_tasks}")
    print(f"  evidence_registry_size={len(NS['_vc_last_verify_evidence'])} "
          f"corroboration_cache_size={len(NS['_vc_corroboration_cache'])}")
    failed = [k for k, v in checks.items() if not v]
    for k, v in checks.items():
        print(f"  CHECK {k}: {'PASS' if v else 'FAIL'}")
    print(f"LONGRUN RESULT: {'PASS' if not failed else 'FAIL'} ({len(checks) - len(failed)}/{len(checks)} checks; failures: {failed})")
    return 1 if failed else 0


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    raise SystemExit(asyncio.run(main(n)))
