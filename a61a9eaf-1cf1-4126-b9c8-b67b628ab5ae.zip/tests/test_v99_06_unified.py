"""v99.06 — THE UNIFIED THREE-FIX SUITE (spec: tests/test_v99_06_unified.py).

The four parts ship together and the composition tests are the strongest
evidence, so this is ONE file:

  SECTION A — Scope binding (FIX-1)
      The chameleon "global" token is eliminated: every cache key / scope
      token / ownership comparison binds to the CURRENT primary's REAL
      account id.  Rotation purges the old owner's entries (production
      2026-09-09: ENTITY_CACHE_CLEARED entries_removed=0 — the purge never
      reached anything; 388x CHANNEL_INVALID from cross-account hash
      consumption).

  SECTION B — Parallel per-account discovery (FIX-2)
      Every eligible cluster account runs its OWN discovery budget in one
      cycle (was: one shared 90s wall cap consumed by the primary → every
      additional account ran ZERO queries — production 19:05:13
      VC_DISCOVERY_MULTI_ACCOUNT_CAPPED queries_done=0).

  SECTION C — Distributed join-all (FIX-3a)
      Join-All spreads targets round-robin across eligible accounts (was:
      every target pinned to the first healthy account / the global
      backend — production 44x VC_JOIN_ALL_HEALTH_CHECK account=<same>,
      VC_JOIN_DISTRIBUTION acc_A:confirmed=23 acc_B:confirmed=0).

  SECTION D — One-group-one-account invariant (FIX-3b, HARD GATE)
      A second account can never even dispatch a JoinGroupCallRequest for
      a group owned by a different account.  The gate lives in
      run_vc_join (the single writer) — every entry point is covered.

  SECTION E — Composition + regression contracts
      FIX-1 + FIX-3a + FIX-3b round-trip through a REAL primary rotation.

Method notes (the spec's v99.05 blind-spot warning):
  * Rotations call set_primary_id() FOR REAL on a REAL UserbotCluster —
    never stubbed.
  * The pipeline gate tests run the REAL vc_pipeline.py (via the proven
    v99.00 harness) with the REAL voicechat ownership functions wired in.
  * The behavioural discovery tests run the REAL
    _auto_discovery_run_one_cycle / _vc_discovery_account_pass against a
    fake RPC layer (real code, fake Telegram).
"""

from __future__ import annotations

import asyncio
import importlib.util
import os
import re
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path
from typing import Any

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"
_VC_TEXT = (_SRC / "voicechat.py").read_text(encoding="utf-8")
_MT_TEXT = (_SRC / "mtproto.py").read_text(encoding="utf-8")
_PIPE_TEXT = (_SRC / "vc_pipeline.py").read_text(encoding="utf-8")

# The proven v99.00 behavioural harness (fake voicechat/mtproto + the REAL
# vc_pipeline) for SECTION D.
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(_SRC))
import test_v99_00_vc_pipeline as T  # noqa: E402

# ---------------------------------------------------------------------------
# Real-module loader (the proven v99.02 mechanism: purge mediagrab_bot*,
# install the fake telethon/pytgcalls stack, import config → db_layer →
# mtproto → voicechat as the REAL package name so voicechat's absolute
# `from mediagrab_bot.vc_hooks import ...` lines resolve).
# ---------------------------------------------------------------------------

_MODS: dict = {}


def _load_real():
    """Import the REAL voicechat.py + mtproto.py against a fake telethon
    stack.  Returns (voicechat_module, mtproto_module).  Cached; the
    sys.modules purge/restore lifecycle is handled by tearDownModule."""
    if "vw" in _MODS:
        return _MODS["vw"], _MODS["mt"]

    # --- fake telethon (v99.00 base + the phone/contacts/types surface) --
    telethon = T._install_fake_telethon()

    class _FakeReq:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = type("GetGroupCallRequest", (_FakeReq,), {})
    phone_mod.GetGroupParticipantsRequest = type(
        "GetGroupParticipantsRequest", (_FakeReq,), {})
    contacts_mod = types.ModuleType("telethon.tl.functions.contacts")
    contacts_mod.SearchRequest = type("SearchRequest", (_FakeReq,), {})
    sys.modules.setdefault("telethon.tl.functions",
                           types.ModuleType("telethon.tl.functions"))
    sys.modules["telethon.tl.functions.phone"] = phone_mod
    sys.modules["telethon.tl.functions.contacts"] = contacts_mod

    types_mod = sys.modules["telethon.tl.types"]
    types_mod.InputGroupCall = type("InputGroupCall", (_FakeReq,), {})
    types_mod.InputPeerChannel = type("InputPeerChannel", (_FakeReq,), {})
    types_mod.InputPeerChat = type("InputPeerChat", (_FakeReq,), {})
    types_mod.InputPeerUser = type("InputPeerUser", (_FakeReq,), {})
    types_mod.Channel = getattr(types_mod, "Channel",
                                type("Channel", (_FakeReq,), {}))

    # --- fake pytgcalls ---------------------------------------------------
    ptg = types.ModuleType("pytgcalls")
    ptg.__version__ = "2.3.3-fake"
    sys.modules.setdefault("pytgcalls", ptg)
    for sub in ("pytgcalls.types", "pytgcalls.types.input_stream",
                "pytgcalls.mtypes", "pytgcalls.helpers"):
        sys.modules.setdefault(sub, types.ModuleType(sub))

    # --- real package import ----------------------------------------------
    _MODS["purged"] = {
        k: v for k, v in sys.modules.items()
        if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")
    }
    for k in list(_MODS["purged"]):
        del sys.modules[k]
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [str(_SRC)]
    sys.modules["mediagrab_bot"] = pkg
    for name in ("config", "db_layer", "mtproto", "voicechat"):
        spec = importlib.util.spec_from_file_location(
            f"mediagrab_bot.{name}", str(_SRC / f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"mediagrab_bot.{name}"] = mod
        spec.loader.exec_module(mod)
    _MODS["vw"] = sys.modules["mediagrab_bot.voicechat"]
    _MODS["mt"] = sys.modules["mediagrab_bot.mtproto"]
    return _MODS["vw"], _MODS["mt"]


def tearDownModule():
    """Restore any mediagrab_bot* modules this suite displaced, so a later
    suite in the same process sees the environment it expects."""
    purged = _MODS.pop("purged", None)
    _MODS.pop("vw", None)
    _MODS.pop("mt", None)
    if purged:
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            if k not in purged:
                del sys.modules[k]
        sys.modules.update(purged)


# ---------------------------------------------------------------------------
# Shared fakes
# ---------------------------------------------------------------------------

_V9906_ENV_KEYS = (
    "VC_DISCOVERY_PARALLEL_ACCOUNTS", "VC_DISCOVERY_PER_ACCOUNT_CAP",
    "VC_JOIN_DISTRIBUTION", "VC_JOIN_ONE_GROUP_ONE_ACCOUNT",
)


class _FakeChat:
    def __init__(self, cid: int):
        self.id = cid


class _FakeSearchResult:
    def __init__(self, chats):
        self.chats = list(chats)


class _DiscoveryClient:
    """A callable Telethon-client stand-in: records SearchRequest calls."""

    def __init__(self, name: str, chats=None, per_query_delay: float = 0.0):
        self.name = name
        self.searches: list[str] = []
        self._chats = list(chats or [])
        self._delay = float(per_query_delay)

    def is_connected(self) -> bool:
        return True

    async def __call__(self, request):
        if self._delay:
            await asyncio.sleep(self._delay)
        self.searches.append(str(getattr(request, "q", "?")))
        return _FakeSearchResult(self._chats)


class _ScopeClient:
    """A client stand-in for scope-routing tests (async get_entity)."""

    def __init__(self, name: str, entity=None):
        self.name = name
        self.entity = entity
        self.get_entity_calls: list = []

    async def get_entity(self, inp):
        self.get_entity_calls.append(inp)
        return self.entity


class _FakeEntity:
    def __init__(self, eid: int, access_hash: int = 555):
        self.id = eid
        self.access_hash = access_hash


class _FakeDb:
    def __init__(self):
        self.commits = 0

    async def commit(self):
        self.commits += 1


def _run(coro):
    return asyncio.run(coro)


# ===========================================================================
# SECTION A — Scope binding (FIX-1)
# ===========================================================================

class TestSectionAScopeBinding(unittest.TestCase):
    """A1-A8: the chameleon "global" is bound to the real primary id at
    every cache/scope/ownership boundary."""

    def setUp(self):
        for k in _V9906_ENV_KEYS:
            self.saved_env = getattr(self, "saved_env", {})
            self.saved_env[k] = os.environ.pop(k, None)
        self.vw, self.mt = _load_real()
        # reset every cache the scope binding touches
        self.vw._vc_entity_cache_scoped.clear()
        self.mt._vc_entity_cache.clear()
        self.mt._v9810_access_state.clear()
        self.vw._vc_participations.clear()
        self.vw._vc_active_join_backends_by_chat.clear()
        self.vw._vc_account_join_stats.clear()
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = ""
        # cluster on a temp accounts file (no work-tree leakage)
        self._tmp = tempfile.mkdtemp(prefix="v9906_secA_")
        self._file_bak = self.mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR
        self.mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        self.mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"
        self._cluster_bak = self.mt._userbot_cluster
        self._guc_bak = self.vw.get_userbot_cluster

    def tearDown(self):
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._userbot_cluster = self._cluster_bak
        self.vw.get_userbot_cluster = self._guc_bak
        import shutil
        shutil.rmtree(self._tmp, ignore_errors=True)

    # -- helpers ----------------------------------------------------------

    def _make_cluster(self, aids: list[str]):
        cluster = self.mt.UserbotCluster()
        cluster._accounts = {}
        for i, aid in enumerate(aids):
            cluster._accounts[aid] = {
                "phone": f"+900000{i}",
                "session_file": f"/tmp/{aid}.session",
                "status": "healthy",
                "role": "primary" if i == 0 else "voice_chat",
                "created_at": float(i + 1),
            }
        cluster._clients = {}
        return cluster

    def _wire(self, cluster):
        self.mt._userbot_cluster = cluster
        self.vw.get_userbot_cluster = lambda: cluster

    # -- A1-A3: effective_scope -------------------------------------------

    def test_a1_effective_scope_binds_primary(self):
        self._wire(self._make_cluster(["acc_A", "acc_B"]))
        # primary not set yet → unidentifiable → literal fallback
        self.assertEqual(self.vw.effective_scope("global"), "global")
        cluster = self.mt._userbot_cluster
        self.assertTrue(cluster.set_primary_id("acc_A"))
        self.assertEqual(self.vw.effective_scope("global"), "acc_A")

    def test_a2_effective_scope_passthrough(self):
        self.assertEqual(self.vw.effective_scope("acc_A"), "acc_A")
        self.assertEqual(self.vw.effective_scope("acc_ZZZ"), "acc_ZZZ")

    def test_a3_effective_scope_empty_like_global(self):
        self._wire(self._make_cluster(["acc_A"]))
        self.mt._userbot_cluster.set_primary_id("acc_A")
        self.assertEqual(self.vw.effective_scope(""),
                         self.vw.effective_scope("global"))
        self.assertEqual(self.vw.effective_scope(""), "acc_A")

    # -- A4: the production cache round-trip with REAL rotation -----------

    def test_a4_cache_round_trip_with_real_rotation(self):
        cluster = self._make_cluster(["acc_A", "acc_B"])
        client_a = _ScopeClient("acc_A")
        client_b = _ScopeClient("acc_B")
        cluster._clients = {"acc_A": client_a, "acc_B": client_b}
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        vw, mt = self.vw, self.mt
        X = 4711

        # 1-3) write under the chameleon token "" — physical key MUST be
        #      the real primary's id, NOT ("_global", X).
        vw.cache_entity_scoped("", X, _FakeEntity(X, 111))
        self.assertIn(("acc_A", X), vw._vc_entity_cache_scoped)
        self.assertNotIn(("_global", X), vw._vc_entity_cache_scoped)
        self.assertEqual(mt._vc_entity_cache[X]["scope"], "acc_A")

        # 4-5) REAL rotation A→B: the pre-swap purge fires for acc_A and
        #      the entry is GONE (production reproducer: entries_removed=0
        #      in v99.05 — the purge must now REACH the physical key).
        with self.assertLogs("mediagrab", level="INFO") as cm:
            self.assertTrue(cluster.set_primary_id("acc_B"))
        self.assertNotIn(("acc_A", X), vw._vc_entity_cache_scoped)
        self.assertIsNone(vw.get_cached_entity_scoped("", X))
        self.assertTrue(any("ENTITY_CACHE_CLEARED" in ln and "account=acc_A" in ln
                            for ln in cm.output),
                        "rotation must emit ENTITY_CACHE_CLEARED for acc_A")
        # the surviving flat mirror (if any) is structurally unshareable:
        flat = mt._vc_entity_cache.get(X)
        if isinstance(flat, dict):
            self.assertFalse(mt._vc_cache_scope_ok(flat, client_b),
                             "old primary's flat entry must NOT be "
                             "consumable by the new primary")

        # 6-9) re-cache under the new primary — scope bound to acc_B, the
        #      scope gate separates the two clients.
        vw.cache_entity_scoped("", X, _FakeEntity(X, 222))
        self.assertIn(("acc_B", X), vw._vc_entity_cache_scoped)
        self.assertEqual(mt._vc_entity_cache[X]["scope"], "acc_B")
        self.assertTrue(mt._vc_cache_scope_ok(mt._vc_entity_cache[X], client_b))
        self.assertFalse(mt._vc_cache_scope_ok(mt._vc_entity_cache[X], client_a))

    # -- A5: Step 0c never routes a rotated-away "global" ------------------

    def test_a5_step0c_never_routes_rotated_away_global(self):
        cluster = self._make_cluster(["acc_A", "acc_B", "acc_C"])
        client_a = _ScopeClient("acc_A")
        client_b = _ScopeClient("acc_B")
        client_c = _ScopeClient("acc_C")
        cluster._clients = {"acc_A": client_a, "acc_B": client_b,
                            "acc_C": client_c}
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        mt = self.mt
        MARKED = -100471124836
        # A PRE-v99.06 chameleon entry: earned by the OLD primary (acc_A)
        # under the literal "global" scope token.
        mt._v9810_access_state[("global", MARKED)] = {
            "entity": _FakeEntity(471124836, 111), "access_hash": 111,
            "scope": "global", "verified_at": time.time(),
            "kind": "channel",
        }
        ident = {"marked_id": MARKED, "raw_id": 471124836, "kind": "channel"}
        # REAL rotation to acc_B.
        self.assertTrue(cluster.set_primary_id("acc_B"))

        async def scenario():
            result: dict = {}
            counter: dict = {}
            # consumer = the NEW primary's client (scope acc_B): the OLD
            # primary's "global" entry must NOT be consumed — no stale
            # cross-scope cache hit, no CHANNEL_INVALID replay.
            ok = await mt._v9810_scope_route(client_b, ident, "acc_B",
                                             counter, result)
            return ok, result

        ok, result = _run(scenario())
        self.assertFalse(ok, "the rotated-away chameleon entry must not "
                             "produce a hit for the new primary")
        self.assertNotIn("entity", result)

    # -- A6: clear_account_cache reaches >= 30 entries ---------------------

    def test_a6_clear_account_cache_reaches_entries(self):
        cluster = self._make_cluster(["acc_A"])
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        vw = self.vw
        for i in range(35):
            vw.cache_entity_scoped("acc_A", 900000 + i, _FakeEntity(900000 + i))
        self.assertEqual(len([k for k in vw._vc_entity_cache_scoped
                               if k[0] == "acc_A"]), 35)
        with self.assertLogs("mediagrab", level="INFO") as cm:
            vw.clear_account_cache("acc_A")
        self.assertEqual(len([k for k in vw._vc_entity_cache_scoped
                               if k[0] == "acc_A"]), 0)
        cleared_lines = [ln for ln in cm.output
                         if "ENTITY_CACHE_CLEARED" in ln
                         and "account=acc_A" in ln]
        self.assertTrue(cleared_lines)
        m = re.search(r"entries_removed=(\d+)", cleared_lines[0])
        self.assertIsNotNone(m)
        self.assertGreaterEqual(int(m.group(1)), 30,
                                "the purge must reach the entries "
                                "(production: entries_removed=0)")

    # -- A7: legacy migration purges pre-v99.06 chameleon shapes -----------

    def test_a7_legacy_migration_purges_chameleon_shapes(self):
        cluster = self._make_cluster(["acc_A"])
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        vw = self.vw
        # inject the PRE-v99.06 physical shapes
        vw._vc_entity_cache_scoped[("_global", 800001)] = {"entity": object()}
        vw._vc_entity_cache_scoped[("global", 800002)] = {"entity": object()}
        self.mt._vc_entity_cache[800003] = {
            "entity": object(), "scope": "global"}
        with self.assertLogs("mediagrab", level="INFO") as cm:
            vw.clear_account_cache("acc_A")
        self.assertNotIn(("_global", 800001), vw._vc_entity_cache_scoped)
        self.assertNotIn(("global", 800002), vw._vc_entity_cache_scoped)
        self.assertNotIn(800003, self.mt._vc_entity_cache)
        mig = [ln for ln in cm.output if "VC_SCOPE_ALIAS_MIGRATION" in ln]
        self.assertTrue(mig, "the migration marker must fire")
        m = re.search(r"removed_scoped=(\d+) removed_flat=(\d+)", mig[0])
        self.assertIsNotNone(m)
        self.assertGreater(int(m.group(1)), 0)
        self.assertGreater(int(m.group(2)), 0)

    # -- A8: grep guard — no literal "global" scope writes -----------------

    def test_a8_no_literal_global_scope_writes(self):
        for name, text in (("voicechat.py", _VC_TEXT), ("mtproto.py", _MT_TEXT),
                           ("vc_pipeline.py", _PIPE_TEXT)):
            for pat in ('scope="global"', '"scope": "global"',
                        "scope='global'"):
                self.assertNotIn(pat, text,
                                 f"{name} writes the literal chameleon "
                                 f"token into a scope field: {pat!r}")


# ===========================================================================
# SECTION B — Parallel per-account discovery (FIX-2)
# ===========================================================================

class TestSectionBParallelDiscovery(unittest.TestCase):
    """B1-B6: every eligible account runs its OWN discovery budget."""

    def setUp(self):
        self.saved_env = {k: os.environ.pop(k, None) for k in _V9906_ENV_KEYS}
        self.vw, self.mt = _load_real()
        vw = self.vw
        # --- config knobs (fast cycles) ---------------------------------
        # Config is a FROZEN dataclass: patch via object.__setattr__ with
        # an instance-__dict__ backup (the import-time values are restored
        # in tearDown — no leakage into later suites; the module set is
        # per-suite anyway).
        self._cfg_bak = {}
        for attr, val in (
                ("vc_discovery_search_delay", 0.5),
                ("vc_discovery_max_queries_per_cycle", 10),
                ("vc_discovery_cycle_wall_cap", 60),
                ("vc_discovery_expand", False)):
            self._cfg_bak[attr] = vw.config.__dict__.get(attr)
            object.__setattr__(vw.config, attr, val)
        # --- discovery state reset --------------------------------------
        vw._vc_discovery_claimed.clear()
        vw._vc_discovery_cycle_seen.clear()
        vw._vc_discovery_batch_seen.clear()
        vw._auto_discovery_stop.clear()
        vw._auto_discovery_pause.set()
        vw._auto_discovery_state.update({
            "cycle": 1, "current_phase": "searching", "queries_executed": 0,
            "raw_results": 0, "unique_groups": 0, "duplicates_skipped": 0,
            "active_vcs": 0, "joined_vcs": 0, "deferred": 0, "failed": 0,
            "zero_result_searches": 0, "search_failures": 0, "floodwaits": 0,
            "last_search_at": 0.0, "current_query": "", "current_source": "",
        })
        vw._vc_account_join_stats.clear()
        vw._vc_known_call_ids.clear()
        # --- cluster on a temp accounts file ----------------------------
        self._tmp = tempfile.mkdtemp(prefix="v9906_secB_")
        self._file_bak = self.mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR
        self.mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        self.mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"
        self._cluster_bak = self.mt._userbot_cluster
        self._guc_bak = vw.get_userbot_cluster
        # --- RPC-layer stubs (real code, fake Telegram) ------------------
        self.merged = [{"query": f"v9906q{i}", "source": "builtin"}
                       for i in range(2)]
        self.upserts: list = []
        self.store_results: list = []
        self.knowledge: list = []
        self.searches_via_primary: list = []
        self._stubs: list = []

        def _stub(name, fn):
            self._stubs.append((name, getattr(vw, name)))
            setattr(vw, name, fn)

        async def _merged():
            return list(self.merged)

        async def _v851(query, **kw):
            self.searches_via_primary.append(query)
            return {"entities": []}

        async def _cool(query):
            return (False, 0)

        async def _tcool(gid):
            return (False, 0)

        async def _classify(client, ent, prefetched=None, **kw):
            return {"access_status": "accessible", "access_hash": 7,
                    "title": f"T{getattr(ent, 'id', 0)}", "username": "",
                    "public_link": "", "active_vc": False, "vc_info": None}

        async def _knowledge(gid, info, source="", commit=False):
            self.knowledge.append(gid)

        async def _upsert(**kw):
            self.upserts.append(kw)

        async def _store(**kw):
            self.store_results.append(kw)

        self._fake_db = _FakeDb()

        async def _get_db():
            return self._fake_db

        _stub("vc_discovery_get_merged_queries", _merged)
        _stub("v851_discovery_search", _v851)
        _stub("_vc_discovery_is_query_on_cooldown", _cool)
        _stub("_vc_discovery_is_target_on_cooldown", _tcool)
        _stub("_vc_arch_classify_guarded", _classify)
        _stub("vc_knowledge_store_verified", _knowledge)
        _stub("vc_upsert_group", _upsert)
        _stub("vc_discovery_store_result", _store)
        _stub("get_db", _get_db)

    def tearDown(self):
        vw = self.vw
        for name, orig in self._stubs:
            setattr(vw, name, orig)
        for attr, val in self._cfg_bak.items():
            object.__setattr__(vw.config, attr, val)
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._userbot_cluster = self._cluster_bak
        vw.get_userbot_cluster = self._guc_bak
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        import shutil
        shutil.rmtree(self._tmp, ignore_errors=True)

    def _make_cluster(self, clients: dict[str, _DiscoveryClient]):
        cluster = self.mt.UserbotCluster()
        cluster._accounts = {}
        for i, (aid, _c) in enumerate(clients.items()):
            cluster._accounts[aid] = {
                "phone": f"+900100{i}", "session_file": f"/tmp/{aid}.session",
                "status": "healthy", "role": "voice_chat",
                "created_at": float(i + 1),
            }
        cluster._clients = dict(clients)
        self.mt._userbot_cluster = cluster
        vw = self.vw
        vw.get_userbot_cluster = lambda: cluster
        return cluster

    def _run_cycle(self):
        with self.assertLogs("mediagrab", level="INFO") as cm:
            _run(self.vw._auto_discovery_run_one_cycle())
        return cm.output

    # -- B1/B2: both accounts run queries in ONE cycle ---------------------

    def test_b1_b2_both_accounts_run_queries(self):
        client_p = _DiscoveryClient("acc_P")
        client_a = _DiscoveryClient("acc_A")
        self._make_cluster({"acc_P": client_p, "acc_A": client_a})
        out = self._run_cycle()
        # the PRIMARY loop executed its queries (via the v851 layer)
        self.assertEqual(len(self.searches_via_primary), 2)
        # the ADDITIONAL account executed REAL SearchRequests
        self.assertEqual(len(client_a.searches), 2,
                         f"additional account queries: {client_a.searches}")
        # B2: VC_DISCOVERY_ACCOUNT_DONE with queries_done > 0
        done = [ln for ln in out if "VC_DISCOVERY_ACCOUNT_DONE" in ln
                and "account=acc_A" in ln]
        self.assertTrue(done, "VC_DISCOVERY_ACCOUNT_DONE must fire for acc_A")
        m = re.search(r"queries_done=(\d+)", done[0])
        self.assertIsNotNone(m)
        self.assertGreater(int(m.group(1)), 0)
        self.assertTrue(any("VC_DISCOVERY_PARALLEL_LAUNCHED" in ln for ln in out))

    def test_b1_single_account_invariant_unchanged(self):
        """One eligible account → no parallel launch, cycle unchanged."""
        client_p = _DiscoveryClient("acc_P")
        self._make_cluster({"acc_P": client_p})
        out = self._run_cycle()
        self.assertEqual(len(self.searches_via_primary), 2)
        self.assertFalse([ln for ln in out
                          if "VC_DISCOVERY_PARALLEL_LAUNCHED" in ln])
        self.assertFalse([ln for ln in out
                          if "VC_DISCOVERY_ACCOUNT_START" in ln])

    # -- B3: per-account caps are independent ------------------------------

    def test_b3_per_account_caps_independent(self):
        os.environ["VC_DISCOVERY_PER_ACCOUNT_CAP"] = "0.3"
        # acc_A's queries each take 0.2s → its OWN cap (0.3s) hits after
        # ~1 query; acc_B is instant and completes all queries.
        client_p = _DiscoveryClient("acc_P")
        client_a = _DiscoveryClient("acc_A", per_query_delay=0.2)
        client_b = _DiscoveryClient("acc_B")
        self._make_cluster({"acc_P": client_p, "acc_A": client_a,
                            "acc_B": client_b})
        out = self._run_cycle()
        done_a = [ln for ln in out if "VC_DISCOVERY_ACCOUNT_DONE" in ln
                  and "account=acc_A" in ln]
        done_b = [ln for ln in out if "VC_DISCOVERY_ACCOUNT_DONE" in ln
                  and "account=acc_B" in ln]
        self.assertTrue(done_a and done_b)
        qa = int(re.search(r"queries_done=(\d+)", done_a[0]).group(1))
        qb = int(re.search(r"queries_done=(\d+)", done_b[0]).group(1))
        self.assertLessEqual(qa, 1, "acc_A's own cap must bound it")
        self.assertGreater(qb, 0, "acc_B's budget is INDEPENDENT of "
                                  "acc_A's cap (v99.05: queries_done=0)")
        self.assertTrue(any("VC_DISCOVERY_MULTI_ACCOUNT_CAPPED" in ln
                            and "account=acc_A" in ln for ln in out))

    # -- B4: global dedup via the claim registry ---------------------------

    def test_b4_dedup_one_claim_per_group(self):
        shared = [_FakeChat(2001), _FakeChat(2002)]
        client_p = _DiscoveryClient("acc_P")
        client_a = _DiscoveryClient("acc_A", chats=shared)
        client_b = _DiscoveryClient("acc_B", chats=shared)
        self._make_cluster({"acc_P": client_p, "acc_A": client_a,
                            "acc_B": client_b})
        self._run_cycle()
        # BOTH accounts ran their queries…
        self.assertGreater(len(client_a.searches), 0)
        self.assertGreater(len(client_b.searches), 0)
        # …but each shared group was processed EXACTLY ONCE.
        for gid in (self.vw._vc_canonical_group_id(2001),
                    self.vw._vc_canonical_group_id(2002)):
            n = sum(1 for u in self.upserts if u.get("group_id") == gid)
            self.assertEqual(n, 1,
                             f"group {gid} upserted {n}x — dedup broken")

    # -- B5: cycle duration ≈ max(per-account), not the sum ----------------

    def test_b5_parallel_duration_is_max_not_sum(self):
        # THREE accounts: the two additional ones each take ~1.2s of
        # per-query work (0.1s work + 0.5s stagger x2).  Sequential would
        # be >= 2.4s of additional-account work alone; parallel ~= 1.2s.
        client_p = _DiscoveryClient("acc_P")
        client_a = _DiscoveryClient("acc_A", per_query_delay=0.1)
        client_b = _DiscoveryClient("acc_B", per_query_delay=0.1)
        self._make_cluster({"acc_P": client_p, "acc_A": client_a,
                            "acc_B": client_b})
        t0 = time.monotonic()
        out = self._run_cycle()
        duration = time.monotonic() - t0
        par = [ln for ln in out if "VC_DISCOVERY_PARALLEL_CYCLE" in ln]
        self.assertTrue(par)
        m = re.search(r"duration_s=([\d.]+)", par[0])
        self.assertIsNotNone(m)
        logged = float(m.group(1))
        self.assertLess(logged, 2.0,
                        f"parallel cycle took {logged}s — sequential sum "
                        f"behavior (each account ~1.2s => >= 2.4s)")
        self.assertGreater(logged, 0.5)
        self.assertLess(duration, 3.0)

    # -- B6: FloodWait-parked account skipped, others continue -------------

    def test_b6_floodwait_account_skipped(self):
        client_p = _DiscoveryClient("acc_P")
        client_a = _DiscoveryClient("acc_A")
        client_b = _DiscoveryClient("acc_B")
        self._make_cluster({"acc_P": client_p, "acc_A": client_a,
                            "acc_B": client_b})
        # park acc_A in FloodWait for 300s
        self.vw._vc_join_account_park_floodwait("acc_A", 300.0,
                                                source="test_b6")
        out = self._run_cycle()
        skipped = [ln for ln in out if "VC_DISCOVERY_ACCOUNT_SKIPPED" in ln
                   and "account=acc_A" in ln and "reason=floodwait" in ln]
        self.assertTrue(skipped,
                        "VC_DISCOVERY_ACCOUNT_SKIPPED reason=floodwait "
                        "must fire for the parked account")
        self.assertEqual(client_a.searches, [],
                         "the parked account must run ZERO queries")
        self.assertGreater(len(client_b.searches), 0,
                           "the remaining account still runs its budget")


# ===========================================================================
# SECTION C — Distributed join-all (FIX-3a)
# ===========================================================================

class TestSectionCDistribution(unittest.TestCase):
    """C1-C7: round-robin distribution across eligible accounts."""

    def setUp(self):
        self.saved_env = {k: os.environ.pop(k, None) for k in _V9906_ENV_KEYS}
        self.vw, self.mt = _load_real()
        self.vw._vc_account_join_stats.clear()
        self.vw._vc_participations.clear()
        self.vw._vc_active_join_backends_by_chat.clear()
        self.vw._vc_join_all_distribution_cursor = 0
        self._guc_bak = self.vw.get_userbot_cluster
        self._started_bak = self.mt.mtproto_is_started
        # C7 constructs a REAL UserbotCluster and calls set_primary_id —
        # redirect persistence to a temp dir so _save() never writes
        # accounts.json into the work tree (the v99.05 leakage guard).
        self._tmp = tempfile.mkdtemp(prefix="v9906_secC_")
        self._file_bak = self.mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR
        self.mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        self.mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"
        self._cluster_singleton_bak = self.mt._userbot_cluster
        self.mt._userbot_cluster = None

    def tearDown(self):
        self.vw.get_userbot_cluster = self._guc_bak
        self.mt.mtproto_is_started = self._started_bak
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._userbot_cluster = self._cluster_singleton_bak
        import shutil
        shutil.rmtree(self._tmp, ignore_errors=True)
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v

    def _targets(self, n: int):
        return [-1009000000000 - i for i in range(n)]

    # -- C1/C3/C4: round-robin fairness over a burst ------------------------

    def test_c1_c3_c4_round_robin_fairness(self):
        eligible = ["acc_A", "acc_B", "acc_C"]
        vw = self.vw
        targets = self._targets(9)
        picks = [vw._vc_select_account_for_join(g, eligible, set())
                 for g in targets]
        # C1: every target got an account
        self.assertTrue(all(picks))
        # C4: the cursor advanced — NOT the same account every time
        self.assertGreater(len(set(picks)), 1,
                           f"selector degenerated to one account: {picks}")
        # C3: no account exceeds targets/accounts + 1
        from collections import Counter
        counts = Counter(picks)
        for acc, n in counts.items():
            self.assertLessEqual(n, 9 // 3 + 1,
                                 f"{acc} got {n}/9 targets — unfair")

    def test_c4_cursor_value_advances(self):
        vw = self.vw
        self.assertEqual(vw._vc_join_all_distribution_cursor, 0)
        vw._vc_select_account_for_join(-1009100000001, ["acc_A", "acc_B"], set())
        self.assertEqual(vw._vc_join_all_distribution_cursor, 1)
        vw._vc_select_account_for_join(-1009100000002, ["acc_A", "acc_B"], set())
        self.assertEqual(vw._vc_join_all_distribution_cursor, 2)

    # -- C5: the selection marker + source contract -------------------------

    def test_c5_selection_marker_source_contract(self):
        for marker in ("VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED",
                       "VC_JOIN_ALL_TARGET_DEFERRED",
                       "VC_JOIN_ALL_DISTRIBUTION_ENABLED",
                       "VC_JOIN_ALL_ACCOUNTS_PARKED"):
            self.assertIn(marker, _VC_TEXT)
        # the caller dispatches through the SELECTED account's backend
        self.assertIn("_vc_select_account_for_join(", _VC_TEXT)
        self.assertIn("vc_get_backend(", _VC_TEXT)

    # -- C6: FloodWait-parked accounts are skipped / targets deferred -------

    def test_c6_floodwait_parked_accounts_skipped(self):
        vw = self.vw
        eligible = ["acc_A", "acc_B", "acc_C"]
        # park acc_B
        vw._vc_join_account_park_floodwait("acc_B", 300.0, source="test_c6")
        picks = [vw._vc_select_account_for_join(g, eligible, set())
                 for g in self._targets(6)]
        self.assertTrue(all(picks))
        self.assertNotIn("acc_B", picks,
                         "a FloodWait-parked account must never be picked")
        # ALL parked → defer ("" + the parked marker)
        vw._vc_join_account_park_floodwait("acc_A", 300.0, source="test_c6")
        vw._vc_join_account_park_floodwait("acc_C", 300.0, source="test_c6")
        with self.assertLogs("mediagrab", level="INFO") as cm:
            pick = vw._vc_select_account_for_join(-1009200000001, eligible, set())
        self.assertEqual(pick, "")
        self.assertTrue(any("VC_JOIN_ALL_ACCOUNTS_PARKED" in ln
                            for ln in cm.output))

    # -- C7: single-account fallback ----------------------------------------

    def test_c7_single_account_fallback(self):
        vw = self.vw
        # eligible = the global backend only → every target takes it
        for g in self._targets(4):
            self.assertEqual(
                vw._vc_select_account_for_join(g, ["global"], set()), "global")
        # eligible-accounts enumeration with NO cluster + started primary
        self.vw.get_userbot_cluster = lambda: None
        self.mt.mtproto_is_started = lambda: True
        self.assertEqual(vw._vc_join_all_eligible_accounts(), ["global"])
        # with a bound primary + a one-account cluster → that account leads
        cluster = self.mt.UserbotCluster()
        cluster._accounts = {
            "acc_P": {"phone": "+1", "session_file": "/x/p.session",
                      "status": "healthy", "role": "primary",
                      "created_at": 1.0},
        }
        cluster._clients = {"acc_P": _ScopeClient("acc_P")}
        cluster.set_primary_id("acc_P")
        self.mt._userbot_cluster = cluster
        self.vw.get_userbot_cluster = lambda: cluster
        self.mt.mtproto_is_started = lambda: True
        self.assertEqual(vw._vc_join_all_eligible_accounts(), ["acc_P"])

    def test_c7_primary_only_mode_restores_v9905(self):
        os.environ["VC_JOIN_DISTRIBUTION"] = "primary_only"
        vw = self.vw
        eligible = ["acc_A", "acc_B", "acc_C"]
        picks = [vw._vc_select_account_for_join(g, eligible, set())
                 for g in self._targets(5)]
        self.assertEqual(picks, ["acc_A"] * 5,
                         "primary_only must pin every target to the first "
                         "eligible account (the v99.05 behavior)")


# ===========================================================================
# SECTION D — One-group-one-account invariant (FIX-3b, HARD GATE)
# ===========================================================================

class TestSectionDOwnerGate(T.PipelineTestBase):
    """D1-D6: the pipeline-level hard gate (zero RPCs before refusal)."""

    def setUp(self):
        super().setUp()
        self.vw, self.mt = _load_real()
        vw = self.vw
        vw._vc_participations.clear()
        vw._vc_active_join_backends_by_chat.clear()
        vw._vc_entity_cache_scoped.clear()
        self.mt._v9810_access_state.clear()
        # wire the REAL ownership functions into the harness's fake
        # voicechat — run_vc_join imports them lazily at call time.
        fvw = self.h.fake_voicechat
        fvw._vc_group_owner = vw._vc_group_owner
        fvw._vc_effective_account_id = vw._vc_effective_account_id
        fvw._vc_one_group_one_account_enabled = vw._vc_one_group_one_account_enabled

    def _own(self, chat: int, account_id: str, state: str = "joined"):
        rec = self.vw.VCParticipationState(chat_id=chat)
        rec.account_id = account_id
        rec.state = state
        rec.request_accepted = True
        self.vw._vc_participations[chat] = rec
        return rec

    def test_d1_to_d5_second_account_refused_with_zero_rpcs(self):
        CHAT = -1007700000001
        # D1: account A owns CHAT (registry source).
        self._own(CHAT, "acc_A", "joined")
        # D2: account B attempts the join through the REAL pipeline.
        backend_b = T.FakeBackend("acc_B", T.FakeClient(222, "acc_B"))
        with self.assertLogs("mediagrab", level="WARNING") as cm:
            with self.assertRaises(self.h.VCTransportError) as exc:
                async def run():
                    await self._join(backend=backend_b, chat=CHAT,
                                     account_id="acc_B")
                _run(run())
        # D3: the marker fires with owner=acc_A requester=acc_B.
        skip = [ln for ln in cm.output
                if "VC_JOIN_SKIPPED_ALREADY_OWNED" in ln]
        self.assertTrue(skip, "VC_JOIN_SKIPPED_ALREADY_OWNED must fire")
        self.assertIn("owner=acc_A", skip[0])
        self.assertIn("requester=acc_B", skip[0])
        # D4: the exact invariant phrase.
        self.assertIn("one-group-one-account invariant", str(exc.exception))
        # D5: ZERO Telegram RPCs (the gate is before entity resolution).
        self.assertEqual(self.h.entity_calls, [],
                         "the gate must fire BEFORE any entity-resolution RPC")
        self.assertEqual(self.h.detect_calls, [])
        self.assertEqual(backend_b.dispatches, [],
                         "no JoinGroupCallRequest may be dispatched")

    def test_d6_idempotent_reentry_same_account_not_blocked(self):
        CHAT = -1007700000002
        self._own(CHAT, "acc_A", "joined")
        backend_a = T.FakeBackend("acc_A", T.FakeClient(111, "acc_A"))
        self.h.verify_sequence = ["present"]

        async def run():
            return await self._join(backend=backend_a, chat=CHAT,
                                    account_id="acc_A")

        out = _run(run())
        self.assertEqual(out.final_state, "JOINED_CONFIRMED",
                         "owner == requester is the idempotent fast path")
        self.assertEqual(len(backend_a.dispatches), 1)

    def test_d_gate_disabled_by_operator_optout(self):
        os.environ["VC_JOIN_ONE_GROUP_ONE_ACCOUNT"] = "false"
        try:
            CHAT = -1007700000003
            self._own(CHAT, "acc_A", "joined")
            backend_b = T.FakeBackend("acc_B", T.FakeClient(222, "acc_B"))
            self.h.verify_sequence = ["present"]

            async def run():
                return await self._join(backend=backend_b, chat=CHAT,
                                        account_id="acc_B")

            out = _run(run())
            self.assertEqual(out.final_state, "JOINED_CONFIRMED",
                             "the documented operator kill-switch")
        finally:
            os.environ.pop("VC_JOIN_ONE_GROUP_ONE_ACCOUNT", None)

    def test_d_backend_map_source_resolves_owner(self):
        CHAT = -1007700000004
        # ownership via the LIVE BACKEND map (source 1)
        fake_backend = T.FakeBackend("acc_Z", T.FakeClient(999, "acc_Z"))
        self.vw._vc_active_join_backends_by_chat[CHAT] = fake_backend
        with self.assertLogs("mediagrab", level="INFO") as cm:
            owner = self.vw._vc_group_owner(CHAT)
        self.assertEqual(owner, "acc_Z")
        self.assertTrue(any("VC_GROUP_OWNER_RESOLVED" in ln
                            and "source=active_backend" in ln
                            for ln in cm.output))


class TestSectionDRegistry(unittest.TestCase):
    """D7/D8: vc_registry_register force_account ownership transfers."""

    def setUp(self):
        for k in _V9906_ENV_KEYS:
            os.environ.pop(k, None)
        self.vw, self.mt = _load_real()
        self.vw._vc_participations.clear()
        # persistence is best-effort — stub it (registry semantics only)
        self._persist_bak = self.vw._vc_persist_participation

        async def _noop(rec):
            return None

        self.vw._vc_persist_participation = _noop

    def tearDown(self):
        self.vw._vc_persist_participation = self._persist_bak

    def test_d7_force_account_from_different_owner_refused(self):
        vw = self.vw
        CHAT = -1008800000001

        async def run():
            r1 = await vw.vc_registry_register(
                CHAT, state="joined", request_accepted=True,
                account_id="acc_A", force_account=True)
            self.assertEqual(r1.account_id, "acc_A")
            with self.assertLogs("mediagrab", level="WARNING") as cm:
                r2 = await vw.vc_registry_register(
                    CHAT, state="joined", request_accepted=True,
                    account_id="acc_B", force_account=True)
            return r2, cm.output

        r2, out = _run(run())
        self.assertEqual(r2.account_id, "acc_A",
                         "the record must be returned UNCHANGED")
        self.assertTrue(any("VC_REGISTRY_OWNER_REFUSED" in ln
                            and "current=acc_A" in ln
                            and "attempted=acc_B" in ln for ln in out))

    def test_d8_force_account_accepted_after_terminal_state(self):
        vw = self.vw
        CHAT = -1008800000002

        async def run():
            await vw.vc_registry_register(
                CHAT, state="joined", request_accepted=True,
                account_id="acc_A", force_account=True)
            # the owner leaves (terminal non-joined state)
            await vw.vc_registry_update(CHAT, state="left")
            with self.assertLogs("mediagrab", level="INFO"):
                r3 = await vw.vc_registry_register(
                    CHAT, state="joined", request_accepted=True,
                    account_id="acc_B", force_account=True)
            return r3

        r3 = _run(run())
        self.assertEqual(r3.account_id, "acc_B",
                         "ownership transfers only from a terminal state")


# ===========================================================================
# SECTION E — Composition + regression contracts
# ===========================================================================

class TestSectionEComposition(unittest.TestCase):
    """E1: FIX-1 + FIX-3a + FIX-3b compose through a REAL rotation."""

    def setUp(self):
        self.saved_env = {k: os.environ.pop(k, None) for k in _V9906_ENV_KEYS}
        self.vw, self.mt = _load_real()
        vw, mt = self.vw, self.mt
        vw._vc_entity_cache_scoped.clear()
        mt._vc_entity_cache.clear()
        mt._v9810_access_state.clear()
        vw._vc_participations.clear()
        vw._vc_active_join_backends_by_chat.clear()
        vw._vc_account_join_stats.clear()
        vw._vc_join_all_distribution_cursor = 0
        self._tmp = tempfile.mkdtemp(prefix="v9906_secE_")
        self._file_bak = mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = mt._CLUSTER_ACCOUNTS_DIR
        mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"
        self._cluster_bak = mt._userbot_cluster
        self._guc_bak = vw.get_userbot_cluster
        self._persist_bak = vw._vc_persist_participation

        async def _noop(rec):
            return None

        vw._vc_persist_participation = _noop

    def tearDown(self):
        self.vw._vc_persist_participation = self._persist_bak
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._userbot_cluster = self._cluster_bak
        self.vw.get_userbot_cluster = self._guc_bak
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        import shutil
        shutil.rmtree(self._tmp, ignore_errors=True)

    def test_e1_composition_through_real_rotation(self):
        vw, mt = self.vw, self.mt
        cluster = mt.UserbotCluster()
        cluster._accounts = {
            "acc_A": {"phone": "+1", "session_file": "/x/a.session",
                      "status": "healthy", "role": "primary",
                      "created_at": 1.0},
            "acc_B": {"phone": "+2", "session_file": "/x/b.session",
                      "status": "healthy", "role": "voice_chat",
                      "created_at": 2.0},
        }
        ca, cb = _ScopeClient("acc_A"), _ScopeClient("acc_B")
        cluster._clients = {"acc_A": ca, "acc_B": cb}
        mt._userbot_cluster = cluster
        vw.get_userbot_cluster = lambda: cluster
        self.assertTrue(cluster.set_primary_id("acc_A"))

        # PART 1: the cache key is the RESOLVED account id (not "global").
        X = 6001
        vw.cache_entity_scoped("", X, _FakeEntity(X, 111))
        self.assertIn(("acc_A", X), vw._vc_entity_cache_scoped)

        # PART 3: distribution picks by REAL account id.
        eligible = vw._vc_join_all_eligible_accounts()
        self.assertEqual(eligible, ["acc_A", "acc_B"])
        new_chat = -1009900000001
        pick1 = vw._vc_select_account_for_join(new_chat, eligible, set())
        self.assertIn(pick1, ("acc_A", "acc_B"))

        # PART 4: ownership keyed by (real account id, chat).
        async def own():
            return await vw.vc_registry_register(
                X_MARKED := -1009900000002, state="joined",
                request_accepted=True, account_id="acc_A",
                force_account=True)
        _run(own())
        self.assertEqual(vw._vc_group_owner(-1009900000002), "acc_A")
        # the owner is EXCLUDED from selection for that chat
        pick2 = vw._vc_select_account_for_join(-1009900000002, eligible, set())
        self.assertNotEqual(pick2, "acc_A",
                            "the owner must not be re-picked for its own "
                            "group when another account is eligible")

        # REAL rotation A→B — everything stays coherent.
        with self.assertLogs("mediagrab", level="INFO"):
            self.assertTrue(cluster.set_primary_id("acc_B"))
        # cache writes now bind to acc_B
        Y = 6002
        vw.cache_entity_scoped("", Y, _FakeEntity(Y, 222))
        self.assertIn(("acc_B", Y), vw._vc_entity_cache_scoped)
        self.assertEqual(mt._vc_entity_cache[Y]["scope"], "acc_B")
        # the OLD owner's entries are gone / unshareable
        self.assertNotIn(("acc_A", X), vw._vc_entity_cache_scoped)
        # ownership survived the rotation (registry is account-keyed)
        self.assertEqual(vw._vc_group_owner(-1009900000002), "acc_A")
        # the gate condition: a DIFFERENT account is refused, the owner
        # is not
        self.assertNotEqual(
            vw._vc_effective_account_id("acc_B"),
            vw._vc_group_owner(-1009900000002))
        self.assertEqual(
            vw._vc_effective_account_id("acc_A"),
            vw._vc_group_owner(-1009900000002))

    def test_e_version_and_marker_inventory(self):
        """The v99.06 artifact contract: version + every new marker."""
        self.assertIn('__bot_version__ = "v99.11.1"',
                      (_SRC / "__init__.py").read_text(encoding="utf-8"))
        markers = (
            # FIX-1
            "VC_SCOPE_ALIAS_MIGRATION",
            # FIX-2
            "VC_DISCOVERY_ACCOUNT_START", "VC_DISCOVERY_ACCOUNT_DONE",
            "VC_DISCOVERY_PARALLEL_CYCLE", "VC_DISCOVERY_ACCOUNT_SKIPPED",
            "VC_DISCOVERY_CYCLE_CAPPED", "VC_DISCOVERY_PARALLEL_LAUNCHED",
            # FIX-3a
            "VC_JOIN_ALL_TARGET_ACCOUNT_SELECTED",
            "VC_JOIN_ALL_TARGET_DEFERRED",
            # FIX-3b
            "VC_GROUP_OWNER_RESOLVED", "VC_JOIN_SKIPPED_ALREADY_OWNED",
            "VC_REGISTRY_OWNER_REFUSED",
            # config
            "VC_INVARIANT_DISABLED",
        )
        body = _VC_TEXT + _MT_TEXT + _PIPE_TEXT + (
            _SRC / "bootstrap.py").read_text(encoding="utf-8")
        for m in markers:
            self.assertIn(m, body, f"missing v99.06 marker {m}")
        # the new env knobs exist
        for knob in ("VC_DISCOVERY_PARALLEL_ACCOUNTS",
                     "VC_DISCOVERY_PER_ACCOUNT_CAP",
                     "VC_JOIN_DISTRIBUTION",
                     "VC_JOIN_ONE_GROUP_ONE_ACCOUNT"):
            self.assertIn(knob, _VC_TEXT + (_SRC / "bootstrap.py").read_text(
                encoding="utf-8"))

    def test_e_no_existing_marker_renamed(self):
        """The spec constraint: existing markers are preserved verbatim."""
        preserved = (
            "AUTO_DISCOVERY_CYCLE_STARTED", "AUTO_DISCOVERY_CYCLE_CAPPED",
            "AUTO_DISCOVERY_CYCLE_COMPLETED", "VC_DISCOVERY_CYCLE_METRICS",
            "AUTO_DISCOVERY_MULTI_ACCOUNT_START",
            "AUTO_DISCOVERY_MULTI_ACCOUNT_DONE",
            "VC_DISCOVERY_MULTI_ACCOUNT_CAPPED",
            "VC_JOIN_ALL_START", "VC_JOIN_ALL_SNAPSHOT", "VC_JOIN_ALL_MODE",
            "VC_JOIN_ALL_TARGET_START", "VC_JOIN_ALL_HEALTH_CHECK",
            "VC_JOIN_ALL_HEALTH_OK", "VC_JOIN_ALL_TRANSPORT_ACCEPTED",
            "VC_JOIN_ALL_TARGET_CONFIRMED", "VC_JOIN_ALL_TARGET_FAILURE",
            "VC_JOIN_ALL_TARGET_UNKNOWN", "VC_JOIN_ALL_TARGET_VERIFY_DEFERRED",
            "VC_JOIN_ALL_PROGRESS", "VC_JOIN_DISTRIBUTION",
            "VC_JOIN_ALL_COMPLETE", "VC_JOIN_ALL_TERMINAL",
            "VC_JOIN_ALL_METRICS", "ENTITY_CACHE_CLEARED",
            "VC_JOIN_SUCCESS",
        )
        for m in preserved:
            self.assertIn(m, _VC_TEXT, f"existing marker renamed: {m}")


if __name__ == "__main__":
    unittest.main()
