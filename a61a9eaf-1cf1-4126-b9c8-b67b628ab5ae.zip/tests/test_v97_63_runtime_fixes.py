"""
v97.63 regression tests — fixes against the actual v97.62 production log.

Runtime log evidence (from note (34).txt):
  - VC_CALLBACK_QUEUE_FULL label=mtproto_capture: 8 (parked reached 214)
  - EVENT_LOOP_LAG_HIGH: 3 (9.39s, 9.10s, 5.09s)
  - Cannot send requests while disconnected: 69 (retry storm)
  - Unhandled exception on on_update (PyTgCalls): 2 (ConnectionResetError)
  - MTProto client disconnected: 1
  - VC_RECONCILE_TIMEOUT UNKNOWN: 1
  - invalid call_id=0: 0 (v97.62 fix worked)
  - VC_CALLBACK_HANDLER_TIMEOUT: 0 (v97.62 fix worked)
  - TypeError: 0 (v97.61 fix worked)

Root causes fixed:
  1. mtproto_capture enqueued EVERY incoming message → queue saturation
  2. vc_watcher `await client.get_entity(gid)` blocked 9s during disconnect
  3. mtproto_call_with_retry retried 3x against a disconnected client (69 errors)
  4. Parked callback events grew unbounded (reached 214)
"""
import os
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_MTPROTO = os.path.join(_BASE, "mediagrab_bot", "mtproto.py")
_VOICECHAT = os.path.join(_BASE, "mediagrab_bot", "voicechat.py")


class TestMtprotoCaptureIngressFilter(unittest.TestCase):
    """§1/§11: mtproto_capture must filter at ingress — only self-destruct media."""

    def test_capture_filters_non_media_messages(self):
        """_on_new_message must skip messages with no media (via func filter or handler body)."""
        with open(_MTPROTO) as f:
            src = f.read()
        # v97.70: the filter is now in the func parameter (runs BEFORE task creation).
        self.assertIn("_self_destruct_filter", src,
                      "capture must use _self_destruct_filter func to filter before task creation")
        self.assertIn("_mtproto_is_self_destruct", src,
                      "capture must check _mtproto_is_self_destruct")
        self.assertIn("func=_self_destruct_filter", src,
                      "event registration must use func filter")


class TestWatcherDisconnectSafe(unittest.TestCase):
    """§2: vc_watcher must not block on get_entity during disconnect."""

    def test_watcher_skips_when_disconnected(self):
        """vc_watcher must check MTProto connectivity before probing."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_WATCHER_SKIP_DISCONNECTED", src,
                      "watcher must log skip when disconnected")
        self.assertIn("_vc_mtproto_ok_safe()", src,
                      "watcher must check _vc_mtproto_ok_safe before probing")

    def test_watcher_get_entity_has_timeout(self):
        """get_entity must be bounded with a timeout.
        (v98.07 SUPERSESSION: the watcher's raw
        ``wait_for(client.get_entity(gid), timeout=10)`` was replaced by the
        FIX-QQ sanctioned scoped resolver —
        ``wait_for(_vc_get_entity_for_detect(client, gid, purpose="watcher"),
        timeout=25)`` — eliminating the bare-int get_entity (the PeerUser
        side-effect class). The CONTRACT (bounded watcher entity fetch)
        is PRESERVED and strengthened: 10s → 25s bound around a resolution
        chain that is itself internally bounded at 25s.)"""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn(
            'asyncio.wait_for(\n'
            '                                _vc_get_entity_for_detect(\n'
            '                                    client, gid, purpose="watcher"),\n'
            '                                timeout=25.0,',
            src,
            "watcher entity fetch must be bounded (v98.07 FIX-QQ scoped "
            "resolver, 25s wait_for)")


class TestMtprotoCallDisconnectGate(unittest.TestCase):
    """§5/§6: mtproto_call_with_retry must not retry against a dead client."""

    def test_disconnect_gate_before_retry_loop(self):
        """The function must check is_connected() BEFORE the retry loop."""
        with open(_MTPROTO) as f:
            src = f.read()
        self.assertIn("Cannot send requests while disconnected", src,
                      "disconnect gate must raise ConnectionError")
        self.assertIn("deferring", src,
                      "disconnect gate must mention deferring")
        self.assertIn("watchdog handles reconnect", src,
                      "disconnect gate must mention watchdog")


class TestParkedExpiry(unittest.TestCase):
    """§1: parked callback events must expire (not grow unbounded)."""

    def test_parked_expiry_exists(self):
        """The worker must expire stale parked events."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_CALLBACK_PARKED_EXPIRED", src,
                      "worker must log VC_CALLBACK_PARKED_EXPIRED")
        self.assertIn("expired", src,
                      "worker must track expired count")
        # Expiry must remove events older than 60s.
        self.assertIn("> 60.0", src,
                      "expiry threshold must be 60s")


class TestPreservedBehavior(unittest.TestCase):
    """§10/§13: FloodWait + InterdcCall must be preserved."""

    def test_floodwait_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("VC_GLOBAL_FLOODWAIT_SET", src)
        self.assertIn("JOIN_ALL_BREAKER", src)

    def test_interdc_preserved(self):
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)

    def test_no_await_on_sync_release(self):
        """v97.61 TypeError fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        self.assertNotIn("await _vc_release_target_inflight", src)

    def test_callback_handler_no_blocking_rpcs(self):
        """v97.62 callback handler fix must still hold."""
        with open(_VOICECHAT) as f:
            src = f.read()
        # The handler must use sync sender_id.
        self.assertIn("event.sender_id", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
