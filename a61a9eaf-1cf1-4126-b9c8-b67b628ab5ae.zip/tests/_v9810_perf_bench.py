#!/usr/bin/env python3
"""v98.09-P3 §24 — Join-All performance benchmark (BEFORE vs AFTER).

Runs the REAL ``_vc_join_all_active_worker`` against a deterministic fake
Telegram world (N dialog groups, K active VCs, simulated 20ms RPC latency)
and MEASURES:

  * first_join_latency_s — worker start → first join API call
  * total_worker_time_s  — worker start → terminal state
  * iter_dialogs_calls   — blocking dialog-discovery invocations
  * get_full_channel_calls — classification + recheck metadata RPCs
  * search_global_calls  — SearchGlobalRequest RPCs
  * joins_attempted      — join_group_call API invocations

Usage:
    python3 tests/_v9810_perf_bench.py [target_root]

    target_root defaults to this tree; pass the baseline extraction root
    to measure the BEFORE numbers (the baseline module has no fast-path
    code — it runs the full discovery → classification → join pipeline).
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time

_HERE = os.path.abspath(__file__)
_DEFAULT_ROOT = _HERE.rsplit("/tests/", 1)[0]
TARGET_ROOT = sys.argv[1] if len(sys.argv) > 1 else _DEFAULT_ROOT

# Import the driver machinery from THIS tree, then point its source root at
# the measurement target.
sys.path.insert(0, os.path.join(_DEFAULT_ROOT, "tests"))
import _v9810_fastpath_driver as d  # noqa: E402

d._ROOT = TARGET_ROOT
d._SRC = os.path.join(TARGET_ROOT, "mediagrab_bot")

N_GROUPS = int(os.environ.get("V9810_BENCH_GROUPS", "40"))  # dialog groups
N_ACTIVE = 3       # groups with a live VC
RPC_LATENCY = 0.02  # simulated per-RPC latency (seconds)
DIALOG_COST = 0.002  # simulated per-dialog iteration cost (seconds)


async def main() -> int:
    vc = d.import_voicechat()

    # --- deterministic world -------------------------------------------
    w = await d.reset_world(vc)
    d._FakeConfig.vc_multi_stagger_seconds = 0.05

    active_gids = []
    for i in range(N_GROUPS):
        gid = 4000 + i
        if i < N_ACTIVE:
            active_gids.append(gid)
            d.seed_group(gid, title=f"G{i}", call_id=-(90000 + i),
                         call_ah=7000 + i)
        else:
            d.seed_group(gid, title=f"G{i}", call_id=None)
        d.SCENARIO.dialogs.append(d.FakeDialog(d.SCENARIO.entities[gid]))

    # --- simulated RPC + dialog latency ---------------------------------
    orig_call = d.fake_mtproto_call_with_retry

    async def slow_call(client, request, retries=3, **kw):
        await asyncio.sleep(RPC_LATENCY)
        return await orig_call(client, request, retries)

    sys.modules["mediagrab_bot.mtproto"].mtproto_call_with_retry = slow_call

    # Dialog iteration cost (the baseline's blocking iter_dialogs path).
    class _SlowDialogs(list):
        pass

    _orig_iter = d.FakeClient.iter_dialogs

    def slow_iter(self, limit=0):
        self.iter_dialogs_calls += 1
        d.LEDGER.calls.append(("iter_dialogs", limit))

        async def _gen():
            if d.SCENARIO.dialogs_error is not None:
                raise d.SCENARIO.dialogs_error
            for dg in d.SCENARIO.dialogs:
                await asyncio.sleep(DIALOG_COST)
                yield dg

        return _gen()

    d.FakeClient.iter_dialogs = slow_iter

    # Timestamp every join API call.
    join_times: list[float] = []
    orig_join = d.FakePyTgCalls.join_group_call

    async def timed_join(self, chat_id, stream, muted=True):
        join_times.append(time.monotonic())
        return await orig_join(self, chat_id, stream, muted)

    d.FakePyTgCalls.join_group_call = timed_join

    vc._vc_join_all_state["run_id"] = "bench"
    t0 = time.monotonic()
    terminal = await d.run_worker(vc)
    total = time.monotonic() - t0

    result = {
        "target_root": os.path.basename(TARGET_ROOT.rstrip("/")),
        "first_join_latency_s": round(
            join_times[0] - t0, 3) if join_times else None,
        "total_worker_time_s": round(total, 3),
        "iter_dialogs_calls": d.LEDGER.count("iter_dialogs"),
        "get_full_channel_calls": d.LEDGER.count("GetFullChannelRequest"),
        "get_full_chat_calls": d.LEDGER.count("GetFullChatRequest"),
        "search_global_calls": d.LEDGER.count("SearchGlobalRequest"),
        "joins_attempted": len(join_times),
        "joins_in_container": len(w.global_b._pytgcalls.calls),
        "terminal": terminal,
        "active_groups": N_ACTIVE,
        "world_groups": N_GROUPS,
        "rpc_latency_ms": int(RPC_LATENCY * 1000),
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
