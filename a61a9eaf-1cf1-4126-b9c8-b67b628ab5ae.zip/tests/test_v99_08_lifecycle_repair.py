"""v99.08 — THE LIFECYCLE-REPAIR SUITE (spec: 2026-09-19 GLM 5.3 mission).

Production root cause (bot-diagnostic (2).log, v99.07 build,
2026-09-19 12:29:29-12:36:29):

    PRIMARY_ROTATED old=acc_918335829278 new=acc_919006065076
    ENTITY_CACHE_CLEARED account=acc_918335829278 entries_removed=27
        scope_aware=True                     <- scoped dict ONLY; 0 flat
    ... 27x VC_HASH_SCOPE_MISMATCH (false: the OLD primary's live client
        was misattributed to the NEW primary id — set_primary_id swaps
        the id, NOT the client object)
    ... reconcile re-annotated acc_918's entities under scope=acc_919
        (THE POISON — vc_detect_active_call caches by caller scope)
    ... join-all classify consumed the poison through the scope gate
        (scope matched, hash foreign) -> "Invalid channel object"
    ... VC_CLASSIFY_FAILURE + 60s negative backoff, TTL expiry, repeat
    eligible=0 excluded=27 channel_invalid=25 (12:36:29, 12:39, 12:50)

The three v99.08 repairs this suite pins:

  Patch-1  clear_account_cache flat-scope comparison (the flat purge now
           matches the real-account-id scope values cache_entity_scoped
           writes; ENTITY_CACHE_CLEARED reports flat_removed).
  Patch-7  resolve_entity_full Step-1 flat read is scope-gated.
  Patch-8  _v9810_scope_route results carry account_id.
  Patch-9  _vc_client_scope rotation-window guard: the cluster identity
           wins when the primary-id binding would MISattribute the
           client (id swapped, client object preserved).

Tests A-J per the mission spec, plus a K section pinning the v99.08
sustainability additions (cache bounds, worker heartbeats).

Method notes (the v99.06 suite's proven mechanisms):
  * REAL voicechat.py + mtproto.py against the fake telethon stack.
  * REAL set_primary_id rotations on a REAL UserbotCluster (temp
    accounts.json redirect — never the work tree).
  * The REAL vc_pipeline.py harness (test_v99_00_vc_pipeline) for the
    hard-gate tests (E/F/G).
"""

from __future__ import annotations

import asyncio
import importlib.util
import os
import re
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path
from typing import Any

_SRC = Path(__file__).resolve().parent.parent / "mediagrab_bot"

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(_SRC))
import test_v99_00_vc_pipeline as T  # noqa: E402

# ---------------------------------------------------------------------------
# Real-module loader (the proven v99.06 mechanism)
# ---------------------------------------------------------------------------

_MODS: dict = {}


def _load_real():
    """Import the REAL voicechat.py + mtproto.py against a fake telethon
    stack.  Cached; sys.modules purge/restore handled by tearDownModule."""
    if "vw" in _MODS:
        return _MODS["vw"], _MODS["mt"]

    telethon = T._install_fake_telethon()

    class _FakeReq:
        def __init__(self, **kw):
            self.__dict__.update(kw)

    phone_mod = types.ModuleType("telethon.tl.functions.phone")
    phone_mod.GetGroupCallRequest = type("GetGroupCallRequest", (_FakeReq,), {})
    phone_mod.GetGroupParticipantsRequest = type(
        "GetGroupParticipantsRequest", (_FakeReq,), {})
    contacts_mod = types.ModuleType("telethon.tl.functions.contacts")
    contacts_mod.SearchRequest = type("SearchRequest", (_FakeReq,), {})
    channels_mod = types.ModuleType("telethon.tl.functions.channels")
    channels_mod.GetFullChannelRequest = type(
        "GetFullChannelRequest", (_FakeReq,), {})
    messages_mod = types.ModuleType("telethon.tl.functions.messages")
    messages_mod.GetFullChatRequest = type(
        "GetFullChatRequest", (_FakeReq,), {})
    sys.modules.setdefault("telethon.tl.functions",
                           types.ModuleType("telethon.tl.functions"))
    sys.modules["telethon.tl.functions.phone"] = phone_mod
    sys.modules["telethon.tl.functions.contacts"] = contacts_mod
    sys.modules["telethon.tl.functions.channels"] = channels_mod
    sys.modules["telethon.tl.functions.messages"] = messages_mod

    types_mod = sys.modules["telethon.tl.types"]
    types_mod.InputGroupCall = type("InputGroupCall", (_FakeReq,), {})
    types_mod.InputPeerChannel = type("InputPeerChannel", (_FakeReq,), {})
    types_mod.InputPeerChat = type("InputPeerChat", (_FakeReq,), {})
    types_mod.InputPeerUser = type("InputPeerUser", (_FakeReq,), {})
    types_mod.Channel = getattr(types_mod, "Channel",
                                type("Channel", (_FakeReq,), {}))

    # the errors surface resolve_entity_full's Step-4 probe needs
    errors_mod = sys.modules["telethon.errors"]
    for _ename in ("ChannelInvalidError", "ChannelPrivateError",
                   "ChatAdminRequiredError", "ChatIdInvalidError",
                   "UsernameInvalidError", "PeerIdInvalidError",
                   "RPCError"):
        if not hasattr(errors_mod, _ename):
            setattr(errors_mod, _ename,
                    type(_ename, (Exception,), {}))

    ptg = types.ModuleType("pytgcalls")
    ptg.__version__ = "2.3.3-fake"
    sys.modules.setdefault("pytgcalls", ptg)
    for sub in ("pytgcalls.types", "pytgcalls.types.input_stream",
                "pytgcalls.mtypes", "pytgcalls.helpers"):
        sys.modules.setdefault(sub, types.ModuleType(sub))

    _MODS["purged"] = {
        k: v for k, v in sys.modules.items()
        if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")
    }
    for k in list(_MODS["purged"]):
        del sys.modules[k]
    pkg = types.ModuleType("mediagrab_bot")
    pkg.__path__ = [str(_SRC)]
    sys.modules["mediagrab_bot"] = pkg
    for name in ("config", "db_layer", "mtproto", "voicechat"):
        spec = importlib.util.spec_from_file_location(
            f"mediagrab_bot.{name}", str(_SRC / f"{name}.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[f"mediagrab_bot.{name}"] = mod
        spec.loader.exec_module(mod)
    _MODS["vw"] = sys.modules["mediagrab_bot.voicechat"]
    _MODS["mt"] = sys.modules["mediagrab_bot.mtproto"]
    return _MODS["vw"], _MODS["mt"]


def tearDownModule():
    purged = _MODS.pop("purged", None)
    _MODS.pop("vw", None)
    _MODS.pop("mt", None)
    if purged:
        for k in [k for k in sys.modules
                  if k == "mediagrab_bot" or k.startswith("mediagrab_bot.")]:
            if k not in purged:
                del sys.modules[k]
        sys.modules.update(purged)


# ---------------------------------------------------------------------------
# Shared fakes
# ---------------------------------------------------------------------------

_V9908_ENV_KEYS = ("VC_ENTITY_CACHE_MAX_ENTRIES",)


class _FakeEntity:
    def __init__(self, eid: int, access_hash: int = 555):
        self.id = eid
        self.access_hash = access_hash


class _ScopeClient:
    """A client stand-in whose scope resolves via the cluster registry."""

    def __init__(self, name: str):
        self.name = name
        self.get_entity_calls: list = []

    def is_connected(self) -> bool:
        return True

    async def get_entity(self, ref):
        self.get_entity_calls.append(ref)
        raise LookupError(f"no entity for {ref!r} (scope {self.name})")


class _OfflineClient(_ScopeClient):
    """The owner-offline shape: is_connected() -> False."""

    def is_connected(self) -> bool:
        return False


def _run(coro):
    return asyncio.run(coro)


def _marked(raw: int) -> int:
    return -1000000000000 - raw


# ===========================================================================
# SECTIONS A-D — cache lifecycle (real modules, no pipeline)
# ===========================================================================

class _CacheTestBase(unittest.TestCase):
    """Shared setUp: real modules + temp accounts redirect + clean caches."""

    def setUp(self):
        for k in _V9908_ENV_KEYS:
            self.saved_env = getattr(self, "saved_env", {})
            self.saved_env[k] = os.environ.pop(k, None)
        self.vw, self.mt = _load_real()
        self.vw._vc_entity_cache_scoped.clear()
        self.mt._vc_entity_cache.clear()
        self.mt._v9810_access_state.clear()
        self.mt._v9810_hash_invalid.clear()
        self.mt._vc_entity_cache_by_client.clear()
        self.vw._vc_participations.clear()
        self.vw._vc_active_join_backends_by_chat.clear()
        self.vw._VC_ENTITY_NEGATIVE_CACHE.clear()
        self.mt._MTPROTO_ACTIVE_SESSION_PATH = ""
        self._tmp = tempfile.mkdtemp(prefix="v9908_")
        self._file_bak = self.mt._CLUSTER_ACCOUNTS_FILE
        self._dir_bak = self.mt._CLUSTER_ACCOUNTS_DIR
        self.mt._CLUSTER_ACCOUNTS_FILE = Path(self._tmp) / "accounts.json"
        self.mt._CLUSTER_ACCOUNTS_DIR = Path(self._tmp) / "sessions"
        self._cluster_bak = self.mt._userbot_cluster
        self._guc_bak = self.vw.get_userbot_cluster

    def tearDown(self):
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        self.mt._CLUSTER_ACCOUNTS_FILE = self._file_bak
        self.mt._CLUSTER_ACCOUNTS_DIR = self._dir_bak
        self.mt._userbot_cluster = self._cluster_bak
        self.vw.get_userbot_cluster = self._guc_bak

    def _make_cluster(self, aids: list[str]):
        cluster = self.mt.UserbotCluster()
        cluster._accounts = {}
        for i, aid in enumerate(aids):
            cluster._accounts[aid] = {
                "phone": f"+910000{i}",
                "session_file": f"/tmp/{aid}.session",
                "status": "healthy",
                "role": "primary" if i == 0 else "voice_chat",
                "created_at": float(i + 1),
            }
        cluster._clients = {}
        return cluster

    def _wire(self, cluster):
        self.mt._userbot_cluster = cluster
        self.vw.get_userbot_cluster = lambda: cluster


class TestFlatCacheScopeRejection(_CacheTestBase):
    """Test A — flat-cache scope rejection on read.

    A writes a flat entry with scope="acc_A".  B calls
    resolve_vc_entity AND resolve_entity_full.  B must not receive A's
    entity; VC_HASH_SCOPE_MISMATCH must fire for both readers."""

    def test_a_flat_entry_rejected_for_foreign_consumer(self):
        cluster = self._make_cluster(["acc_A", "acc_B"])
        client_a = _ScopeClient("acc_A")
        client_b = _ScopeClient("acc_B")
        cluster._clients = {"acc_A": client_a, "acc_B": client_b}
        self._wire(cluster)
        # No primary set: raw cluster clients scope-resolve via the
        # registry (the v98.11 S9 path).
        RAW = 61000001
        ent_a = _FakeEntity(RAW, 777)
        self.vw.cache_entity_scoped("acc_A", RAW, ent_a)
        self.assertEqual(self.mt._vc_entity_cache[RAW]["scope"], "acc_A")
        # the production flat-mirror shape: vc_detect_active_call also
        # mirrors the MARKED key (the classify path reads the marked
        # form — see the production VC_HASH_SCOPE_MISMATCH lines).
        self.mt._vc_entity_cache[_marked(RAW)] = \
            self.mt._vc_entity_cache[RAW]

        # --- resolve_vc_entity (the v98.07 FIX-QQ gated reader) --------
        res = _run(self.mt.resolve_vc_entity(
            client_b, _marked(RAW), chat_id=_marked(RAW), access_hash=0))
        self.assertFalse(res.get("ok"),
                         "B must not resolve via A's flat entry")
        self.assertIsNone(res.get("entity"))

        # --- resolve_entity_full (the v99.08 Patch-7 gated reader) -----
        # all 9 ladder steps fail on the stub client -> VCTransportError
        # (the important part: B never RECEIVED A's cached entity).
        with self.assertLogs("mediagrab", level="WARNING") as cm:
            with self.assertRaises(self.mt.VCTransportError):
                _run(self.mt.resolve_entity_full(client_b, _marked(RAW)))
        mism = [ln for ln in cm.output if "VC_HASH_SCOPE_MISMATCH" in ln]
        self.assertTrue(
            mism,
            "the scope-mismatch warning must fire for the foreign read")
        self.assertTrue(any("entry_scope=acc_A" in ln
                            and "consumer_scope=acc_B" in ln
                            for ln in mism), mism)
        # A's own read still hits its entry (no false rejection).
        res3 = _run(self.mt.resolve_vc_entity(
            client_a, _marked(RAW), chat_id=_marked(RAW), access_hash=0))
        self.assertTrue(res3.get("ok"))
        self.assertIs(res3.get("entity"), ent_a)


class TestScopedCacheCoexistence(_CacheTestBase):
    """Test B — scoped cache coexistence: (acc_A, chat) and (acc_B, chat)
    both present; neither is removed by the other's writes."""

    def test_b_both_scopes_coexist(self):
        RAW = 61000002
        ent_a = _FakeEntity(RAW, 111)
        ent_b = _FakeEntity(RAW, 222)
        self.vw.cache_entity_scoped("acc_A", RAW, ent_a)
        self.vw.cache_entity_scoped("acc_B", RAW, ent_b)
        # both scoped entries present
        self.assertIn(("acc_A", RAW), self.vw._vc_entity_cache_scoped)
        self.assertIn(("acc_B", RAW), self.vw._vc_entity_cache_scoped)
        # each account reads its OWN entity
        self.assertIs(
            self.vw.get_cached_entity_scoped("acc_A", RAW), ent_a)
        self.assertIs(
            self.vw.get_cached_entity_scoped("acc_B", RAW), ent_b)
        # a fresh write for a THIRD account does not evict either
        self.vw.cache_entity_scoped("acc_C", RAW, _FakeEntity(RAW, 333))
        self.assertIn(("acc_A", RAW), self.vw._vc_entity_cache_scoped)
        self.assertIn(("acc_B", RAW), self.vw._vc_entity_cache_scoped)


class TestRotationClearsFlatCache(_CacheTestBase):
    """Test C — primary rotation clears the flat cache for the rotated-out
    account; the OTHER account's entries survive; flat_removed logged."""

    def test_c_clear_account_cache_purges_flat(self):
        cluster = self._make_cluster(["acc_A", "acc_B"])
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        vw = self.vw
        for i in range(5):
            vw.cache_entity_scoped("acc_A", 62000000 + i,
                                   _FakeEntity(62000000 + i))
        for i in range(3):
            vw.cache_entity_scoped("acc_B", 63000000 + i,
                                   _FakeEntity(63000000 + i))
        flat_a = [k for k, v in self.mt._vc_entity_cache.items()
                  if isinstance(v, dict) and v.get("scope") == "acc_A"]
        flat_b = [k for k, v in self.mt._vc_entity_cache.items()
                  if isinstance(v, dict) and v.get("scope") == "acc_B"]
        self.assertEqual(len(flat_a), 5)
        self.assertEqual(len(flat_b), 3)

        with self.assertLogs("mediagrab", level="INFO") as cm:
            vw.clear_account_cache("acc_A")

        # the 5 are gone (scoped AND flat), the 3 remain
        for k in flat_a:
            self.assertNotIn(k, self.mt._vc_entity_cache,
                             f"flat entry {k} must be purged (v99.08 FIX-1)")
        self.assertEqual(
            len([k for k in vw._vc_entity_cache_scoped if k[0] == "acc_A"]),
            0)
        for k in flat_b:
            self.assertIn(k, self.mt._vc_entity_cache,
                          f"acc_B's flat entry {k} must survive")
        self.assertEqual(
            len([k for k in vw._vc_entity_cache_scoped if k[0] == "acc_B"]),
            3)
        # the log carries the new fields
        cleared = [ln for ln in cm.output if "ENTITY_CACHE_CLEARED" in ln
                   and "account=acc_A" in ln]
        self.assertTrue(cleared)
        m = re.search(r"flat_removed=(\d+)", cleared[0])
        self.assertIsNotNone(m, cleared[0])
        self.assertEqual(int(m.group(1)), 5,
                         "flat_removed=5 — the production flat purge")
        m2 = re.search(r"scoped_removed=(\d+)", cleared[0])
        self.assertIsNotNone(m2)
        self.assertEqual(int(m2.group(1)), 5)
        m3 = re.search(r"entries_removed=(\d+)", cleared[0])
        self.assertEqual(int(m3.group(1)), 10)


class TestRotationPreservesAccessState(_CacheTestBase):
    """Test D — primary rotation preserves _v9810_access_state (the
    Step-0c other-scope route; NOT cleared by rotation)."""

    def test_d_access_state_survives_rotation(self):
        cluster = self._make_cluster(["acc_A", "acc_B"])
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        now = time.time()
        for aid, raw in (("acc_A", 64000001), ("acc_B", 64000002)):
            self.mt._v9810_access_state[(aid, _marked(raw))] = {
                "entity": _FakeEntity(raw, 999),
                "access_hash": 999,
                "kind": "channel",
                "scope": aid,
                "verified_at": now,
                "source": "test",
            }
        self.vw.cache_entity_scoped("acc_A", 64000001, _FakeEntity(64000001))
        vw = self.vw
        vw.clear_account_cache("acc_A")
        # BOTH accounts' access-state entries survive
        self.assertIn(("acc_A", _marked(64000001)),
                      self.mt._v9810_access_state)
        self.assertIn(("acc_B", _marked(64000002)),
                      self.mt._v9810_access_state)
        # ...while the entity caches WERE purged for acc_A
        self.assertNotIn(("acc_A", 64000001), vw._vc_entity_cache_scoped)


# ===========================================================================
# SECTIONS E-G — ownership lifecycle (REAL pipeline hard gate)
# ===========================================================================

class TestOwnershipLifecycle(T.PipelineTestBase, _CacheTestBase):
    """Tests E/F/G — owner offline defer, terminal-owner unowned path,
    no duplicate join.  REAL vc_pipeline gate + REAL ownership functions."""

    def setUp(self):
        T.PipelineTestBase.setUp(self)
        _CacheTestBase.setUp(self)
        vw = self.vw
        # wire the REAL ownership functions into the harness's fake
        # voicechat — run_vc_join imports them lazily at call time.
        fvw = self.h.fake_voicechat
        fvw._vc_group_owner = vw._vc_group_owner
        fvw._vc_effective_account_id = vw._vc_effective_account_id
        fvw._vc_one_group_one_account_enabled = \
            vw._vc_one_group_one_account_enabled

    def tearDown(self):
        _CacheTestBase.tearDown(self)
        T.PipelineTestBase.tearDown(self)

    def _own(self, chat: int, account_id: str, state: str = "joined"):
        rec = self.vw.VCParticipationState(chat_id=chat)
        rec.account_id = account_id
        rec.state = state
        rec.request_accepted = True
        self.vw._vc_participations[chat] = rec
        return rec

    def _fake_container_union(self, ids, owners):
        async def _union():
            return set(ids), dict(owners)
        self.vw._vc_calls_container_union = _union

    # -- Test E: owner offline -> defer, never acc_B, registry intact ----

    def test_e_owner_offline_defer(self):
        CHAT = -1007700000011
        RAW = abs(CHAT) % 1000000000000
        # owned by acc_A (registry, non-terminal), acc_A's backend
        # container holds the call object, acc_A's CLIENT is offline.
        rec = self._own(CHAT, "acc_A", "joined")
        self._fake_container_union(
            [RAW], {RAW: "acc_A"})
        offline_client = _OfflineClient("acc_A")
        cluster = self._make_cluster(["acc_A", "acc_B"])
        cluster._clients = {"acc_A": offline_client,
                            "acc_B": _ScopeClient("acc_B")}
        self._wire(cluster)
        self.assertFalse(offline_client.is_connected())

        # (1) the worker's owned-path decision: container + registry →
        #     already-owned for acc_A (deferred from the join loop).
        connected, owner, ids = _run(self.vw._vc_target_connected_any_backend(RAW))
        self.assertTrue(connected)
        self.assertEqual(owner, "acc_A")

        # (2) even if the target reached the join loop, the selector
        #     excludes the owner and the HARD GATE refuses acc_B with
        #     ZERO Telegram RPCs (acc_B never attempts the join).
        backend_b = T.FakeBackend("acc_B", T.FakeClient(222, "acc_B"))
        with self.assertLogs("mediagrab", level="WARNING") as cm:
            with self.assertRaises(self.h.VCTransportError):
                async def run():
                    await self._join(backend=backend_b, chat=CHAT,
                                     account_id="acc_B")
                _run(run())
        self.assertTrue(any("VC_JOIN_SKIPPED_ALREADY_OWNED" in ln
                            for ln in cm.output))
        self.assertEqual(self.h.entity_calls, [])
        self.assertEqual(self.h.detect_calls, [])
        self.assertEqual(backend_b.dispatches, [],
                         "acc_B never attempts the join")

        # (3) the registry is not rewritten.
        self.assertEqual(self.vw._vc_participations[CHAT].account_id,
                         "acc_A")
        self.assertEqual(self.vw._vc_participations[CHAT].state, "joined")
        self.assertEqual(self.vw._vc_group_owner(CHAT), "acc_A")

    # -- Test F: terminal owner (state=left) -> unowned path --------------

    def test_f_terminal_owner_unowned(self):
        CHAT = -1007700000012
        self._own(CHAT, "acc_A", "left")   # terminal
        self._fake_container_union([], {})
        # terminal registry record → NO owner (the unowned path)
        self.assertEqual(self.vw._vc_group_owner(CHAT), "")
        # acc_B can join (the gate lets an UNOWNED target through)
        backend_b = T.FakeBackend("acc_B", T.FakeClient(222, "acc_B"))
        self.h.verify_sequence = ["present"]
        async def run():
            return await self._join(backend=backend_b, chat=CHAT,
                                    account_id="acc_B")
        out = _run(run())
        self.assertEqual(out.final_state, "JOINED_CONFIRMED")
        # and the register (pipeline, force_account from the TERMINAL
        # previous state) legitimately takes ownership — Patch 5.
        _run(self.vw.vc_registry_register(
            CHAT, state="joined", request_accepted=True,
            account_id="acc_B", force_account=True))
        self.assertEqual(self.vw._vc_participations[CHAT].account_id,
                         "acc_B")
        self.assertEqual(self.vw._vc_group_owner(CHAT), "acc_B")

    # -- Test G: no duplicate join for an owned VC -------------------------

    def test_g_no_duplicate_join(self):
        CHAT = -1007700000013
        RAW = abs(CHAT) % 1000000000000
        self._own(CHAT, "acc_A", "joined")
        self._fake_container_union([RAW], {RAW: "acc_A"})
        cluster = self._make_cluster(["acc_A", "acc_B"])
        cluster._clients = {"acc_A": _ScopeClient("acc_A"),
                            "acc_B": _ScopeClient("acc_B")}
        self._wire(cluster)

        # owned → the worker's already_joined shape
        connected, owner, _ids = _run(
            self.vw._vc_target_connected_any_backend(RAW))
        self.assertTrue(connected)

        # acc_B (primary) attempt → skipped_already_owned, ZERO dispatches
        backend_b = T.FakeBackend("acc_B", T.FakeClient(222, "acc_B"))
        with self.assertLogs("mediagrab", level="WARNING") as cm:
            with self.assertRaises(self.h.VCTransportError) as exc:
                async def run():
                    await self._join(backend=backend_b, chat=CHAT,
                                     account_id="acc_B")
                _run(run())
        self.assertTrue(any("VC_JOIN_SKIPPED_ALREADY_OWNED" in ln
                            for ln in cm.output))
        self.assertEqual(backend_b.dispatches, [],
                         "no backend.join call for the owned chat")
        self.assertIn("one-group-one-account invariant", str(exc.exception))

        # acc_A itself: idempotent re-entry (already_joined fast path)
        backend_a = T.FakeBackend("acc_A", T.FakeClient(111, "acc_A"))
        self.h.verify_sequence = ["present"]
        async def run_a():
            return await self._join(backend=backend_a, chat=CHAT,
                                    account_id="acc_A")
        out_a = _run(run_a())
        self.assertEqual(out_a.final_state, "JOINED_CONFIRMED")
        self.assertEqual(len(backend_a.dispatches), 1,
                         "the owner's own re-entry is the fast path, "
                         "not a duplicate")


# ===========================================================================
# SECTION H — the production reproduction (27 owned VCs + REAL rotation)
# ===========================================================================

class TestProductionReproduction(_CacheTestBase):
    """Test H — seed 27 owned VCs under acc_A, rotate primary to acc_B,
    run the classification resolution for every target under BOTH the
    new primary's client and the (still-live) old primary's client.

    The production kill chain must be inverted:
      * flat purge reaches the flat mirrors (flat_removed=27);
      * NO misattribution (the old primary's client scopes to acc_A);
      * NO poisoned entries (scope=acc_B + acc_A's hash);
      * every target resolves OK via the Step-0c account_rotation route
        (the resolution whose CHANNEL_INVALID failure zeroed eligible);
      * no VC_HASH_SCOPE_MISMATCH / VC_CLASSIFY_FAILURE chain.
    """

    N = 27

    def test_h_production_shape_inverted(self):
        cluster = self._make_cluster(["acc_A", "acc_B"])
        client_a = _ScopeClient("acc_A")
        client_b = _ScopeClient("acc_B")
        cluster._clients = {"acc_A": client_a, "acc_B": client_b}
        self._wire(cluster)
        self.assertTrue(cluster.set_primary_id("acc_A"))
        # the production identity shape: the PRIMARY client object IS
        # the cluster's acc_A client (id(primary) == id(cluster client)).
        self.mt._mtproto_client = client_a

        vw, mt = self.vw, self.mt
        now = time.time()
        chats = [65000000 + i for i in range(self.N)]
        for raw in chats:
            ent = _FakeEntity(raw, 1000 + (raw % 97))
            # the join-era knowledge: scoped + flat caches + access_state
            # (exactly what the 12:21-12:26 join run produced).
            vw.cache_entity_scoped("acc_A", raw, ent)
            mt._v9810_access_state[("acc_A", _marked(raw))] = {
                "entity": ent,
                "access_hash": ent.access_hash,
                "kind": "channel",
                "scope": "acc_A",
                "verified_at": now,
                "source": "provided_hash",
            }

        # sanity: 27 flat entries with scope=acc_A
        self.assertEqual(
            len([1 for v in mt._vc_entity_cache.values()
                 if isinstance(v, dict) and v.get("scope") == "acc_A"]),
            self.N)

        # --- the REAL rotation (pre-swap purge included) ----------------
        with self.assertLogs("mediagrab", level="INFO") as cm:
            self.assertTrue(cluster.set_primary_id("acc_B"))

        # (1) the flat purge reached the mirrors (the v99.07 bug: 0).
        cleared = [ln for ln in cm.output if "ENTITY_CACHE_CLEARED" in ln
                   and "account=acc_A" in ln]
        self.assertTrue(cleared, "rotation must emit ENTITY_CACHE_CLEARED")
        m = re.search(r"flat_removed=(\d+)", cleared[0])
        self.assertIsNotNone(m)
        self.assertEqual(int(m.group(1)), self.N)
        self.assertEqual(
            len([1 for v in mt._vc_entity_cache.values()
                 if isinstance(v, dict) and v.get("scope") == "acc_A"]),
            0, "zero stale acc_A-tagged flat entries survive")

        # (2) NO misattribution: the old primary's LIVE client (still
        #     _mtproto_client — set_primary_id does not swap the object)
        #     scopes to its TRUE owner acc_A, not the new primary acc_B
        #     (the Patch-9 rotation-window guard; v99.07 returned acc_B
        #     here — the poison injector).
        self.assertIs(mt._mtproto_client, client_a)
        self.assertEqual(mt._vc_client_scope(client_a), "acc_A")
        # the new primary's client scopes to acc_B
        self.assertEqual(mt._vc_client_scope(client_b), "acc_B")

        # (3) NO poisoned entries: nothing carries acc_A's entities
        #     under scope=acc_B.
        ent_ids = {raw for raw in chats}
        for k, v in mt._vc_entity_cache.items():
            if isinstance(v, dict) and v.get("scope") == "acc_B":
                ent = v.get("entity")
                self.assertNotIn(getattr(ent, "id", None), ent_ids,
                                 f"poisoned flat entry {k}: acc_B scope "
                                 f"holding acc_A's entity")

        # (4) the classification resolution under the NEW primary's
        #     client: every target resolves OK via account_rotation:acc_A
        #     (the Step-0c route over the SURVIVING access_state) — the
        #     resolution whose "Invalid channel object" failure collapsed
        #     eligible 27 -> 0 in production.
        ok_count = 0
        for raw in chats:
            res = _run(mt.resolve_vc_entity(
                client_b, _marked(raw), chat_id=_marked(raw), access_hash=0))
            self.assertTrue(res.get("ok"),
                            f"target {raw} must resolve post-rotation: "
                            f"{res.get('error')}")
            self.assertEqual(res.get("source"), f"account_rotation:acc_A")
            self.assertEqual(res.get("account_id"), "acc_A",
                             "Patch-8: account_id alias on the route")
            ok_count += 1
        self.assertEqual(ok_count, self.N)

        # (5) the old primary's own client ALSO resolves cleanly (no
        #     false mismatch — the access_state survived per Test D).
        res_a = _run(mt.resolve_vc_entity(
            client_a, _marked(chats[0]), chat_id=_marked(chats[0]),
            access_hash=0))
        self.assertTrue(res_a.get("ok"))
        self.assertEqual(res_a.get("source"), "scope_state")

        # (6) the kill chain never fired: no classify failures, no
        #     negative-cache records, no channel_invalid exclusions.
        self.assertEqual(len(vw._VC_ENTITY_NEGATIVE_CACHE), 0)
        # eligible > 0 in the production sense: every one of the 27
        # targets is resolvable + classifiable under the new primary —
        # the run cannot terminate with eligible=0 channel_invalid=25.
        self.assertGreater(ok_count, 0)


# ===========================================================================
# SECTIONS I-J — _vc_group_owner contracts
# ===========================================================================

class TestGroupOwnerContracts(_CacheTestBase):
    """Test I — callable without entity resolution (zero RPCs).
    Test J — precedence: backend map > registry (non-terminal) >
    join-path cache scope; discovery sources never create ownership."""

    def test_i_no_entity_resolution(self):
        from unittest import mock
        CHAT = -1007700000021
        rec = self.vw.VCParticipationState(chat_id=CHAT)
        rec.account_id = "acc_A"
        rec.state = "joined"
        rec.request_accepted = True
        self.vw._vc_participations[CHAT] = rec
        with mock.patch.object(
                self.mt, "resolve_vc_entity",
                side_effect=AssertionError("RPC attempted")) as m_res, \
             mock.patch.object(
                self.vw, "resolve_vc_entity",
                side_effect=AssertionError("RPC attempted")) as m_vres:
            owner = self.vw._vc_group_owner(CHAT)
        self.assertEqual(owner, "acc_A")
        m_res.assert_not_called()
        m_vres.assert_not_called()

    def test_j_precedence(self):
        RAW = 66000001
        MARKED = _marked(RAW)
        # (1) backend map wins
        fake_backend = types.SimpleNamespace(_account_id="acc_Z")
        self.vw._vc_active_join_backends_by_chat[MARKED] = fake_backend
        self.assertEqual(self.vw._vc_group_owner(RAW), "acc_Z")
        self.vw._vc_active_join_backends_by_chat.clear()

        # (2) registry (non-terminal) when the map is empty
        rec = self.vw.VCParticipationState(chat_id=MARKED)
        rec.account_id = "acc_A"
        rec.state = "joined"
        rec.request_accepted = True
        self.vw._vc_participations[MARKED] = rec
        self.assertEqual(self.vw._vc_group_owner(RAW), "acc_A")
        # terminal registry record -> NO owner
        rec.state = "left"
        self.assertEqual(self.vw._vc_group_owner(RAW), "")
        self.vw._vc_participations.clear()

        # (3) join-path cache source creates ownership; discovery does NOT
        self.mt._vc_entity_cache[RAW] = {
            "entity": _FakeEntity(RAW), "access_hash": 1,
            "source": "join_dispatch", "scope": "acc_J"}
        self.assertEqual(self.vw._vc_group_owner(RAW), "acc_J")
        self.mt._vc_entity_cache[RAW] = {
            "entity": _FakeEntity(RAW), "access_hash": 1,
            "source": "vc_discovery", "scope": "acc_D"}
        self.assertEqual(self.vw._vc_group_owner(RAW), "",
                         "discovery-source cache entries must NOT create "
                         "ownership (invariant 11)")


# ===========================================================================
# SECTION K — v99.08 sustainability pins (additive, beyond the A-J spec)
# ===========================================================================

class TestV9908SustainabilityPins(unittest.TestCase):
    """Source-contract pins for the v99.08 sustainability additions."""

    def test_k1_clear_account_cache_flat_comparison(self):
        src = (_SRC / "voicechat.py").read_text(encoding="utf-8")
        i = src.find("def clear_account_cache")
        seg = src[i:i + 7000]
        self.assertIn('str(v.get("scope", "")) == account_id', seg,
                      "the direct flat-scope comparison (Patch 1)")
        self.assertIn("_vc_client_scope_account_map()", seg,
                      "the identity map stays available for legacy tokens")
        self.assertIn("flat_removed=%d scoped_removed=%d", seg,
                      "the new log fields")

    def test_k2_resolve_entity_full_gate(self):
        src = (_SRC / "mtproto.py").read_text(encoding="utf-8")
        i = src.find("async def resolve_entity_full")
        seg = src[i:i + 9000]
        self.assertIn("_vc_cache_scope_ok(cached, client)", seg,
                      "the Patch-7 gate on the Step-1 flat read")

    def test_k3_scope_route_account_id(self):
        src = (_SRC / "mtproto.py").read_text(encoding="utf-8")
        i = src.find("async def _v9810_scope_route")
        seg = src[i:i + 9000]
        self.assertIn('result["account_id"]', seg,
                      "Patch-8: the account_id alias")

    def test_k4_rotation_window_guard(self):
        src = (_SRC / "mtproto.py").read_text(encoding="utf-8")
        self.assertIn("def _v9908_rotation_scope_conflict(", src)
        self.assertIn("def _v9908_cluster_identity(", src)
        i = src.find("def _vc_client_scope(")
        seg = src[i:i + 6600]
        self.assertIn("_v9908_rotation_scope_conflict", seg)

    def test_k5_cache_bounds(self):
        vc = (_SRC / "voicechat.py").read_text(encoding="utf-8")
        mt = (_SRC / "mtproto.py").read_text(encoding="utf-8")
        self.assertIn("VC_ENTITY_CACHE_MAX_ENTRIES", vc)
        self.assertIn("_vc_entity_cache_evict_oldest", vc)
        self.assertIn("VC_ENTITY_CACHE_MAX_ENTRIES", mt)
        self.assertIn("_v9908_bound_by_client_cache", mt)
        # negative cache honors the arch budget
        self.assertIn("negcache_max_entries", vc)

    def test_k6_worker_heartbeats(self):
        mt = (_SRC / "mtproto.py").read_text(encoding="utf-8")
        vc = (_SRC / "voicechat.py").read_text(encoding="utf-8")
        bp = (_SRC / "bootstrap.py").read_text(encoding="utf-8")
        hd = (_SRC / "handlers.py").read_text(encoding="utf-8")

        def _loop_has_hb(src, anchor, name):
            i = src.find(anchor)
            self.assertGreater(i, 0, anchor)
            # find the while loop after the anchor, then the heartbeat
            # call within the following 300 lines
            win = src[i:i + 14000]
            self.assertIn("bot_worker_heartbeat", win,
                          f"{name} must heartbeat")

        _loop_has_hb(mt, "async def _vc_session_hot_reload_loop",
                     "session hot-reload")
        _loop_has_hb(vc, "async def _auto_discovery_loop",
                     "auto discovery")
        _loop_has_hb(vc, "async def _reconcile_loop(self)",
                     "coverage reconciler")
        _loop_has_hb(bp, "async def _cluster_reconnect_loop",
                     "cluster reconnect")
        _loop_has_hb(hd, "async def _bot_history_loop",
                     "bot history")

    def test_k7_negative_cache_size_bound_enforced(self):
        vw, mt = _load_real()
        vw._VC_ENTITY_NEGATIVE_CACHE.clear()
        # the arch budget spec clamps negcache to >=100 — the smallest
        # testable bound.  The config dataclass is frozen (FIX-29/30);
        # object.__setattr__ is the documented test-only escape hatch.
        orig = vw.config.vc_arch_negcache_max_entries
        try:
            object.__setattr__(vw.config, "vc_arch_negcache_max_entries",
                               100)
            for i in range(140):
                vw._vc_entity_negative_record(
                    67000000 + i, "acc_X", "VCTransportError",
                    now=float(i))
            self.assertLessEqual(len(vw._VC_ENTITY_NEGATIVE_CACHE), 100,
                                 "the negcache budget must be enforced")
        finally:
            object.__setattr__(vw.config, "vc_arch_negcache_max_entries",
                               orig)
            vw._VC_ENTITY_NEGATIVE_CACHE.clear()

    def test_k8_entity_cache_size_bound_enforced(self):
        vw, mt = _load_real()
        vw._vc_entity_cache_scoped.clear()
        mt._vc_entity_cache.clear()
        # the clamp floor is 100 — use 150 as the testable bound.
        os.environ["VC_ENTITY_CACHE_MAX_ENTRIES"] = "150"
        try:
            for i in range(260):
                vw.cache_entity_scoped("acc_B", 68000000 + i,
                                       _FakeEntity(68000000 + i))
            self.assertLessEqual(len(vw._vc_entity_cache_scoped), 150)
            self.assertLessEqual(len(mt._vc_entity_cache), 150)
        finally:
            os.environ.pop("VC_ENTITY_CACHE_MAX_ENTRIES", None)
            vw._vc_entity_cache_scoped.clear()
            mt._vc_entity_cache.clear()


if __name__ == "__main__":
    unittest.main()
