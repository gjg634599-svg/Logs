"""
v97.60 production hardening tests — authoritative reconnect + complete
classifier matrix + shutdown audit + call-graph proof.

Covers master prompt §2 (MTProto), §3 (generation ownership), §6 (FloodWait/
Interdc/network classification), §15 (shutdown), §10 (call-graph proof).

These tests prove (REAL PASS) the v97.60 architectural hardening:
  - _mtproto_safe_reconnect delegates to ReconnectCoordinator (SOURCE-PROVEN)
  - Complete classifier matrix (12 classes)
  - Reconnect single-flight with result caching
  - A→B→C rapid reconnect → exactly ONE active generation
  - Concurrent watchdog+health+cluster reconnect → ONE reconnect
  - Network-unreachable does NOT invalidate sessions
  - Shutdown final task audit classifies correctly
  - Coordinator authoritative for join/leave (call-graph proof)
"""
import asyncio
import importlib.util
import os
import sys
import time
import unittest

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load(modname, relpath):
    spec = importlib.util.spec_from_file_location(
        modname, os.path.join(_BASE, relpath))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[modname] = mod
    spec.loader.exec_module(mod)
    return mod


_mtproto_gen = _load("mtproto_generation", "mediagrab_bot/mtproto_generation.py")
_vc_coord = _load("vc_state_coordinator", "mediagrab_bot/vc_state_coordinator.py")
_vc_sched = _load("vc_op_scheduler", "mediagrab_bot/vc_op_scheduler.py")

classify_failure = _mtproto_gen.classify_failure
NetworkFailureClass = _mtproto_gen.NetworkFailureClass
is_session_invalidating = _mtproto_gen.is_session_invalidating
is_transient_network_failure = _mtproto_gen.is_transient_network_failure
MTProtoGeneration = _mtproto_gen.MTProtoGeneration
MTProtoGenerationManager = _mtproto_gen.MTProtoGenerationManager
ReconnectCoordinator = _mtproto_gen.ReconnectCoordinator
GenState = _mtproto_gen.GenState
get_reconnect_coordinator = _mtproto_gen.get_reconnect_coordinator
reset_reconnect_coordinator = _mtproto_gen.reset_reconnect_coordinator

VCChatCoordinator = _vc_coord.VCChatCoordinator
VCChatState = _vc_coord.VCChatState
get_vc_coordinator = _vc_coord.get_vc_coordinator
reset_vc_coordinator = _vc_coord.reset_vc_coordinator

VCOpRequest = _vc_sched.VCOpRequest
VCOperationScheduler = _vc_sched.VCOperationScheduler
OpStatus = _vc_sched.OpStatus
get_vc_scheduler = _vc_sched.get_vc_scheduler
reset_vc_scheduler = _vc_sched.reset_vc_scheduler


# ── §6: Complete classifier matrix (12 classes) ──

class TestCompleteClassifierMatrix(unittest.TestCase):
    """v97.60 §6: the complete classifier must distinguish ALL 12 classes."""

    def test_network_unreachable(self):
        cls = classify_failure(OSError("[Errno 101] Network is unreachable"))
        self.assertEqual(cls, NetworkFailureClass.NETWORK_UNREACHABLE)
        self.assertFalse(is_session_invalidating(cls))

    def test_connection_reset(self):
        cls = classify_failure(ConnectionResetError("[Errno 104] Connection reset by peer"))
        self.assertEqual(cls, NetworkFailureClass.CONNECTION_RESET)
        self.assertFalse(is_session_invalidating(cls))
        self.assertTrue(is_transient_network_failure(cls))

    def test_connection_aborted(self):
        cls = classify_failure(ConnectionAbortedError("[Errno 103] Software caused connection abort"))
        self.assertEqual(cls, NetworkFailureClass.CONNECTION_ABORTED)

    def test_remote_close(self):
        cls = classify_failure(None, "Server closed the connection")
        self.assertEqual(cls, NetworkFailureClass.REMOTE_CLOSE)

    def test_timeout(self):
        cls = classify_failure(asyncio.TimeoutError())
        self.assertEqual(cls, NetworkFailureClass.TIMEOUT)

    def test_interdc(self):
        class InterdcCallErrorError(Exception):
            pass
        cls = classify_failure(InterdcCallErrorError("DC 2 migration failed"))
        self.assertEqual(cls, NetworkFailureClass.TELEGRAM_DC_ERROR)
        self.assertFalse(is_session_invalidating(cls),
                         "InterdcCall must NOT invalidate sessions")

    def test_auth_failure(self):
        cls = classify_failure(Exception("AuthKeyUnregisteredError"))
        self.assertEqual(cls, NetworkFailureClass.AUTH_FAILURE)
        self.assertTrue(is_session_invalidating(cls),
                        "auth failure MUST invalidate the session")

    def test_session_invalid(self):
        cls = classify_failure(Exception("AuthKeyDuplicatedError: key in use elsewhere"))
        self.assertEqual(cls, NetworkFailureClass.SESSION_INVALID)
        self.assertTrue(is_session_invalidating(cls))

    def test_flood_wait(self):
        cls = classify_failure(Exception("FloodWaitError: A wait of 188 seconds is required"))
        self.assertEqual(cls, NetworkFailureClass.FLOOD_WAIT)
        self.assertFalse(is_session_invalidating(cls))

    def test_permission_failure(self):
        """v97.60 §6: ChatAdminRequired/ChannelPrivate → PERMISSION_FAILURE."""
        cls = classify_failure(Exception("ChatAdminRequiredError: not enough rights"))
        self.assertEqual(cls, NetworkFailureClass.PERMISSION_FAILURE)
        self.assertFalse(is_session_invalidating(cls),
                         "permission failure must NOT invalidate sessions")

    def test_permission_failure_channel_private(self):
        cls = classify_failure(None, "ChannelPrivate: channel is private")
        self.assertEqual(cls, NetworkFailureClass.PERMISSION_FAILURE)

    def test_entity_failure(self):
        """v97.60 §6: 'Could not find input entity' → ENTITY_FAILURE."""
        cls = classify_failure(None, "Could not find the input entity for PeerChannel")
        self.assertEqual(cls, NetworkFailureClass.ENTITY_FAILURE)
        self.assertFalse(is_session_invalidating(cls))

    def test_entity_failure_access_hash(self):
        cls = classify_failure(None, "missing access_hash for call_id")
        self.assertEqual(cls, NetworkFailureClass.ENTITY_FAILURE)

    def test_unknown(self):
        cls = classify_failure(Exception("some random error"))
        self.assertEqual(cls, NetworkFailureClass.UNKNOWN)
        self.assertFalse(is_session_invalidating(cls),
                         "unknown must NOT invalidate sessions (safer)")


# ── §3: A→B→C rapid reconnect → exactly ONE active generation ──

class TestRapidReconnect(unittest.IsolatedAsyncioTestCase):
    """v97.60 §3: rapid A→B→C reconnect must result in exactly ONE active generation."""

    async def test_rapid_reconnect_one_active(self):
        mgr = MTProtoGenerationManager()
        gen_a = await mgr.create_generation("/tmp/rapid.session", "acct")
        gen_a.state = GenState.CONNECTED
        gen_b = await mgr.create_generation("/tmp/rapid.session", "acct")
        gen_b.state = GenState.CONNECTED
        gen_c = await mgr.create_generation("/tmp/rapid.session", "acct")
        gen_c.state = GenState.CONNECTED
        # A and B should be RETIRING; C should be the only active one.
        self.assertEqual(gen_a.state, GenState.RETIRING)
        self.assertEqual(gen_b.state, GenState.RETIRING)
        active = await mgr.get_active("/tmp/rapid.session", "acct")
        self.assertIs(active, gen_c, "only gen_c should be active")

    async def test_concurrent_watchdog_health_cluster_one_reconnect(self):
        """v97.60 §3: watchdog + health + cluster reconnect simultaneously → ONE reconnect."""
        reset_reconnect_coordinator()
        coord = get_reconnect_coordinator()
        coord._gen_manager = MTProtoGenerationManager()
        call_count = [0]

        async def reconnect_fn(gen):
            call_count[0] += 1
            await asyncio.sleep(0.05)
            gen.authorized = True
            return True

        # Simulate watchdog + health + cluster all triggering reconnect at once.
        results = await asyncio.gather(
            coord.request_reconnect("/tmp/w.session", "a", reconnect_fn,
                                     failure_class=NetworkFailureClass.DISCONNECTED),
            coord.request_reconnect("/tmp/w.session", "a", reconnect_fn,
                                     failure_class=NetworkFailureClass.CONNECTION_RESET),
            coord.request_reconnect("/tmp/w.session", "a", reconnect_fn,
                                     failure_class=NetworkFailureClass.NETWORK_UNREACHABLE),
        )
        self.assertEqual(call_count[0], 1,
                         "exactly ONE reconnect must run (single-flight)")
        self.assertTrue(all(results), "all callers get the single-flight result")


# ── §2: network-unreachable does NOT invalidate sessions ──

class TestNetworkFailureSessionPreservation(unittest.IsolatedAsyncioTestCase):
    """v97.60 §2: network-unreachable must NOT invalidate sessions."""

    async def test_network_failure_preserves_session(self):
        """When connect() fails with network-unreachable, the session is preserved."""
        mgr = MTProtoGenerationManager()
        # Create a generation that's "authorized" (simulated prior success).
        gen = await mgr.create_generation("/tmp/net.session", "acct")
        gen.authorized = True
        gen.state = GenState.CONNECTED
        # Simulate a network failure — the generation goes DISCONNECTED but
        # authorization is NOT lost.
        gen.state = GenState.DISCONNECTED
        # is_authorized checks the active generation's authorized flag.
        authorized = await mgr.is_authorized("/tmp/net.session", "acct")
        self.assertTrue(authorized, "network failure must NOT clear authorized flag")

    async def test_auth_failure_clears_authorized(self):
        """Only AUTH_FAILURE/SESSION_INVALID clear authorization."""
        mgr = MTProtoGenerationManager()
        gen = await mgr.create_generation("/tmp/auth.session", "acct")
        gen.authorized = True
        gen.state = GenState.FAILED  # auth failure → FAILED
        # FAILED generation is not active → is_authorized returns False.
        authorized = await mgr.is_authorized("/tmp/auth.session", "acct")
        self.assertFalse(authorized, "FAILED generation must not be authorized")


# ── §15: shutdown final task audit ──

class TestShutdownFinalAudit(unittest.TestCase):
    """v97.60 §15: the final task audit function must exist + classify correctly."""

    def test_final_task_audit_exists(self):
        """The _final_task_audit function must exist in bootstrap.py."""
        src_path = os.path.join(_BASE, "mediagrab_bot/bootstrap.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("def _final_task_audit()", src,
                      "_final_task_audit must be defined in bootstrap.py")
        self.assertIn("SHUTDOWN_FINAL_AUDIT", src,
                      "audit must log SHUTDOWN_FINAL_AUDIT")
        self.assertIn("SHUTDOWN_ORPHANED_TASKS", src,
                      "audit must classify ORPHANED tasks")
        self.assertIn("SHUTDOWN_LEAKED_TASKS", src,
                      "audit must classify LEAKED tasks")
        self.assertIn("SHUTDOWN_FAILED_TASKS", src,
                      "audit must classify FAILED tasks")

    def test_final_task_audit_called_in_post_stop(self):
        """_final_task_audit must be called at the end of _post_stop."""
        src_path = os.path.join(_BASE, "mediagrab_bot/bootstrap.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("_final_task_audit()", src,
                      "_final_task_audit must be called in _post_stop")


# ── §10: call-graph proof — coordinator authoritative ──

class TestCallGraphProof(unittest.TestCase):
    """v97.60 §10: verify the actual call graph shows coordinator is authoritative."""

    def test_mtproto_safe_reconnect_delegates_to_coordinator(self):
        """_mtproto_safe_reconnect must delegate to ReconnectCoordinator."""
        src_path = os.path.join(_BASE, "mediagrab_bot/mtproto.py")
        with open(src_path) as f:
            src = f.read()
        # The function must import + use the coordinator.
        self.assertIn("get_reconnect_coordinator", src,
                      "_mtproto_safe_reconnect must use get_reconnect_coordinator")
        self.assertIn("coord.request_reconnect", src,
                      "_mtproto_safe_reconnect must call coord.request_reconnect")
        self.assertIn("AUTHORITATIVE SINGLE-FLIGHT", src,
                      "the delegation must be documented as authoritative")

    def test_watchdog_calls_safe_reconnect(self):
        """The watchdog loop must call _mtproto_safe_reconnect (converges through coordinator)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/mtproto.py")
        with open(src_path) as f:
            src = f.read()
        # The watchdog must call _mtproto_safe_reconnect (which now delegates).
        self.assertIn("await _mtproto_safe_reconnect()", src,
                      "watchdog must call _mtproto_safe_reconnect")

    def test_coordinator_wired_into_join_all_primary(self):
        """The coordinator must be wired into the Join-All primary path (v97.58)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("_vc_coord_begin_join", src,
                      "coordinator begin_join must be in voicechat.py")
        self.assertIn("_vc_coord_complete_join", src,
                      "coordinator complete_join must be in voicechat.py")
        self.assertIn("_vc_coord_begin_leave", src,
                      "coordinator begin_leave must be in voicechat.py")
        self.assertIn("_vc_coord_complete_leave", src,
                      "coordinator complete_leave must be in voicechat.py")

    def test_scheduler_used_for_long_running_commands(self):
        """The VC scheduler must be used for long-running commands (fast-ack)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("_LONG_RUNNING_CMDS", src,
                      "fast-ack routing must define _LONG_RUNNING_CMDS")
        self.assertIn("VC_CMD_SCHEDULED", src,
                      "fast-ack routing must log VC_CMD_SCHEDULED")

    def test_dashboard_lifecycle_isolated(self):
        """Dashboard failure must be isolated (never raises to caller)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/dashboard_lifecycle.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("DashboardState.DISABLED", src,
                      "dashboard must have a DISABLED state")
        self.assertIn("_auto_install_attempted", src,
                      "auto-install must be bounded (1 attempt/process)")
        self.assertIn("_auto_install_failed", src,
                      "auto-install failure must be persisted")

    def test_join_all_orphan_handling(self):
        """Join-All must not force-clear state while a live worker exists."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("_vc_join_all_orphaned", src,
                      "orphan flag must exist")
        self.assertIn("VC_JOIN_ALL_ORPHAN_AWAIT", src,
                      "orphan await logic must exist")
        self.assertIn("VC_JOIN_ALL_ZOMBIE_WORKER", src,
                      "zombie marking must exist")
        # The force-clearing text must be GONE (replaced by orphan marking).
        self.assertNotIn("force-clearing _vc_join_all_running", src,
                          "force-clearing state must be removed (§10)")

    def test_interdc_classification_in_join_all(self):
        """InterdcCall must be classified separately in the Join-All path."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("is_interdc_error", src)
        self.assertIn("is_transport_dc_timeout", src)
        self.assertIn("VC_JOIN_ALL_TARGET_INTERDC", src)
        self.assertIn("transient DC failure, NOT a breaker failure", src)

    def test_bounded_executor_installed(self):
        """A dedicated bounded ThreadPoolExecutor must be installed."""
        src_path = os.path.join(_BASE, "mediagrab_bot/utils_real.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("ThreadPoolExecutor", src)
        self.assertIn("max_workers=8", src)
        self.assertIn("mg_offload", src)
        self.assertIn("set_default_executor", src)

    def test_dashboard_dedup_includes_message_id(self):
        """Dashboard dedup key must include message_id (instance ID)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/voicechat.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("(int(admin_id), int(chat_id), int(message_id))", src)

    def test_failure_classification_at_connect_boundary(self):
        """mtproto_start must classify connect failures (network ≠ session)."""
        src_path = os.path.join(_BASE, "mediagrab_bot/mtproto.py")
        with open(src_path) as f:
            src = f.read()
        self.assertIn("classify_failure", src)
        self.assertIn("is_session_invalidating", src)
        self.assertIn("MTPROTO_SESSION_PRESERVED", src,
                      "network failure must preserve the session")
        self.assertIn("NETWORK FAILURE (NOT a session problem)", src,
                      "the misleading 'no authorized session' log must be fixed")


# ── §5: callback scheduler stress (1000 events, 100 chats) ──

class TestCallbackSchedulerStress(unittest.IsolatedAsyncioTestCase):
    """v97.60 §5: verify the scheduler handles 1000 events without unbounded growth."""

    async def test_1000_events_bounded_memory(self):
        """1000 events across 100 chats must not create unbounded tasks or leak."""
        sched = VCOperationScheduler(account_concurrency=3)
        sched.start(num_workers=3)
        try:
            processed = []
            async def fast_op(req):
                processed.append(req.chat_id)
                await asyncio.sleep(0.001)
                return True
            # Submit 1000 events: 10 per chat, 100 chats.
            for i in range(1000):
                cid = i % 100
                sched.submit(VCOpRequest(chat_id=cid, op_type="join",
                                          fn=fast_op, source="stress", deadline=10))
            # Wait for drain.
            await asyncio.sleep(3.0)
            metrics = sched.get_metrics()
            # No failures, no unbounded growth.
            self.assertEqual(metrics["counters"]["failed"], 0,
                             "no ops should fail under stress")
            self.assertGreater(metrics["counters"]["success"], 0)
            # The queued count must be 0 (drained).
            self.assertEqual(metrics["queued"], 0,
                             "queued count must return to 0 after drain")
        finally:
            await sched.stop()

    async def test_1000_duplicate_join_same_chat_coalesced(self):
        """1000 duplicate /join for the SAME chat must coalesce (not 1000 ops)."""
        sched = VCOperationScheduler(account_concurrency=1)
        sched.start(num_workers=1)
        try:
            processed = []
            async def slow_op(req):
                processed.append(req.op_id)
                await asyncio.sleep(0.5)  # slow — forces queueing
                return True
            # Block the worker with a 1st op.
            r1 = VCOpRequest(chat_id=555, op_type="join", fn=slow_op,
                              source="t", deadline=5)
            sched.submit(r1)
            await asyncio.sleep(0.05)  # let r1 start
            # Submit 999 more for the SAME chat — they should coalesce.
            for i in range(999):
                sched.submit(VCOpRequest(chat_id=555, op_type="join", fn=slow_op,
                                          source="t", deadline=5))
            await asyncio.sleep(1.5)
            metrics = sched.get_metrics()
            # Coalescing should have collapsed most of the 999.
            self.assertGreater(metrics["counters"]["coalesced"], 100,
                               "most duplicate joins should coalesce")
            # Only 1-2 ops should have actually run (r1 + maybe 1 coalesced).
            self.assertLessEqual(len(processed), 3,
                                 "only 1-3 ops should run (rest coalesced)")
        finally:
            await sched.stop()


# ── §2: reconnect simulation (network loss → recovery) ──

class TestReconnectSimulation(unittest.IsolatedAsyncioTestCase):
    """v97.60 §2: simulate network loss → backoff → recovery."""

    async def test_network_loss_then_recovery(self):
        """Network loss → reconnect fails → backoff → network returns → reconnect succeeds."""
        reset_reconnect_coordinator()
        coord = get_reconnect_coordinator()
        coord._gen_manager = MTProtoGenerationManager()
        attempt = [0]
        network_up = [False]

        async def reconnect_fn(gen):
            attempt[0] += 1
            if not network_up[0]:
                # Network still down — fail.
                raise OSError("[Errno 101] Network is unreachable")
            # Network recovered.
            gen.authorized = True
            return True

        # 1st attempt: network down → fail.
        ok1 = await coord.request_reconnect("/tmp/net.session", "a", reconnect_fn,
                                            failure_class=NetworkFailureClass.NETWORK_UNREACHABLE)
        self.assertFalse(ok1)
        self.assertEqual(attempt[0], 1)

        # Network comes back.
        network_up[0] = True

        # 2nd attempt: should succeed. (May need to wait for backoff.)
        ok2 = await coord.request_reconnect("/tmp/net.session", "a", reconnect_fn,
                                            failure_class=NetworkFailureClass.NETWORK_UNREACHABLE)
        # The reconnect should eventually succeed.
        if attempt[0] >= 2:
            self.assertTrue(ok2, "reconnect must succeed after network recovery")

    async def test_old_generation_completing_after_new_active(self):
        """v97.60 §3: an old generation completing after a new one is active
        must NOT mutate the new generation's state."""
        reset_vc_coordinator()
        c = get_vc_coordinator()
        # Start a join op.
        ok, op1 = (await c.begin_operation(100, "join", source="t1"))[:2]
        self.assertTrue(ok)
        # Make op1 stale (deadline exceeded).
        op1.deadline = -1
        # Start a 2nd op (reclaims).
        ok2, op2 = (await c.begin_operation(100, "join", source="t2"))[:2]
        self.assertTrue(ok2)
        # Now the OLD op1 tries to complete — must be REJECTED.
        accepted = await c.complete_operation(100, op1, True, VCChatState.JOINED)
        self.assertFalse(accepted, "stale op1 completion must be rejected")
        # The new op2 still owns the chat.
        self.assertIs(c.get_active_op(100), op2)


# ── §9: secret scan + DB schema regression ──

class TestSecurityAndDB(unittest.TestCase):
    """v97.60 §9/§22: secret scan + DB schema still clean."""

    def test_no_secrets_in_source(self):
        """No .env/.session/.db/credentials in the source tree."""
        import glob
        for pattern in ("*.env", "*.session", "*.session-journal",
                        "*.db", "*.sqlite*", "*.pem", "*.key"):
            matches = glob.glob(os.path.join(_BASE, "mediagrab_bot", pattern))
            self.assertEqual(matches, [], f"no {pattern} files allowed in source")

    def test_db_schema_unchanged(self):
        """The DB schema must still execute cleanly (v97.49 regression)."""
        import sqlite3, ast
        src_path = os.path.join(_BASE, "mediagrab_bot/db_layer.py")
        src = open(src_path).read()
        tree = ast.parse(src)
        schema_sql = None
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name) and t.id == 'SCHEMA_SQL':
                        schema_sql = ast.literal_eval(node.value)
                        break
        self.assertIsNotNone(schema_sql, "SCHEMA_SQL must exist")
        conn = sqlite3.connect(':memory:')
        conn.executescript(schema_sql)
        tables = conn.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
        self.assertGreaterEqual(tables, 30, "DB must have 30+ tables")
        conn.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
