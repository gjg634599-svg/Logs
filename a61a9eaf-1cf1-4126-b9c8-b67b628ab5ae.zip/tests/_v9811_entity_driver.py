"""v98.11 — Entity-resolution CONVERGENCE forensic regression driver.

Loads the REAL production ``mediagrab_bot/mtproto.py`` (file-path import
with a stub parent package — the SAME loader pattern as the v98.09/v98.10
suites) and exercises the REAL resolver stack against a fake Telethon
world that reproduces the PRODUCTION client topology of
bot-diagnostic (5).log:

  * ``GatedProxy``     — the ``_GatedClientProxy`` shape that
                         ``mtproto_get_client()`` constructs PER CALL
                         (client_id="global" / "cluster:<aid>"): the
                         v98.10 scope identification bug lived here.
  * ``RealShapeCluster`` — the REAL cluster registry shape: live clients
                         in ``_clients`` (NOT nested in ``_accounts``).
  * per-account session tables + per-account access-hash tables
    (Telegram semantics verified against telethon 1.44 source — the
    v98.10 driver's world, reused via import).

Every RPC lands in the shared LEDGER.  Every case prints
``CASE <id>: PASS|FAIL — detail``; exit code = number of failed cases.

PROMPT 4 (v98.11) §30 matrix coverage at the resolver level:
  V1  valid scoped hash + local cache miss (S14)      -> 1 RPC, no rotation
  V2  stale scoped hash (S15)                          -> scope-local refresh
  V3  valid cache object (S30-3)                       -> 0 RPCs
  V4  representation error (S30-4)                     -> no rotation
  V5  basic group (S30-5)                              -> GetFullChatRequest
  V6  user entity (S30-6)                              -> no channel probe
  V7  private channel (S30-7/S16)                      -> PRIVATE + fallback
  V8  nonexistent entity (S30-8/S17)                   -> bounded negative
  V9  temporary RPC failure (S30-9/S18)                -> TEMPORARY, no rot
  V10 FloodWait during rotation (S30-10/S19)           -> account cooling
  V11 the EXACT (5).log production chain               -> markers + cost
  V12 convergence: cycle2 0-RPC + restart 1-RPC (S9)   -> durable knowledge
  V13 single-flight + waiter cancel safety (S30-14/15)
  V14 no raw-positive-int probe regression (S30-22)
  V15 dialogs index: 1 scan per (scope, TTL) (S24)
  V16 scope stability across proxy recreation (S9)
  V17 local-miss-only entity (no hash anywhere) (S5)   -> NO rotation
"""
from __future__ import annotations

import asyncio
import importlib.util
import logging
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _v9810_entity_driver as drv  # noqa: E402  (shared fake world)

MARKED_BASE = -1000000000000
WORLD = drv.WORLD
LEDGER = drv.LEDGER


# ---------------------------------------------------------------------------
# Production-topology shims (the shapes v98.10's tests were missing)
# ---------------------------------------------------------------------------
class RealShapeCluster:
    """The REAL cluster registry shape: clients in ``_clients``.

    ``UserbotCluster._accounts`` holds account METADATA only (no client
    objects) — v98.10's scope reverse-lookup only scanned ``_accounts``,
    so every real client fell through to the unstable ``client:<id>``
    scope.  This shape reproduces that faithfully.
    """

    def __init__(self, accounts: dict[str, Any]):
        self._clients = dict(accounts)
        self._accounts = {aid: {"account_id": aid} for aid in accounts}

    def get_client(self, account_id: str):
        return self._clients.get(account_id)

    def get_healthy_accounts(self):
        return [{"account_id": aid} for aid in self._clients]

    def list_accounts(self):
        return [{"account_id": aid} for aid in self._clients]

    def update_status(self, account_id: str, status: str, **kw):
        self._accounts.setdefault(account_id, {}).update(
            {"status": status, **kw})


class GatedProxy:
    """The ``_GatedClientProxy`` shape: a per-call wrapper carrying its
    stable identity (``_client_id`` = "global" | "cluster:<aid>").

    ``mtproto_get_client()`` constructs a NEW proxy on EVERY call, so a
    scope derived from ``id(proxy)`` is unstable — the v98.11 S9 root
    cause.  This shim reproduces both the shape and the per-call
    recreation (``fresh_proxy()``).
    """

    def __init__(self, client: Any, client_id: str):
        object.__setattr__(self, "_real_client", client)
        object.__setattr__(self, "_client_id", client_id)

    def __getattr__(self, name: str):
        return getattr(object.__getattribute__(self, "_real_client"), name)


class ChannelPrivateError(Exception):
    """Telethon ChannelPrivateError shape (matched by class NAME)."""


class FloodWaitError(Exception):
    """Telethon FloodWaitError shape (seconds attr)."""

    def __init__(self, seconds: int = 30):
        super().__init__(f"Too many requests (retry after {seconds}s)")
        self.seconds = seconds


# ---------------------------------------------------------------------------
# World extensions: private channels + floodwait
# ---------------------------------------------------------------------------
PRIVATE_FOR: dict[int, set[str]] = {}      # raw_id -> {account scopes}
FLOODWAIT_ON: set[str] = set()             # account ids that FloodWait

_orig_resolve_with_hash = WORLD.resolve_with_hash


def _resolve_with_hash(client, raw_id: int, ah: int):
    _acc = getattr(client, "account_id", "")
    if raw_id in PRIVATE_FOR and _acc in PRIVATE_FOR[raw_id]:
        # The stub telethon's ChannelPrivateError takes no message arg.
        raise ChannelPrivateError()
    if _acc in FLOODWAIT_ON:
        raise FloodWaitError(seconds=17)
    return _orig_resolve_with_hash(client, raw_id, ah)


WORLD.resolve_with_hash = _resolve_with_hash


# ---------------------------------------------------------------------------
# Case harness
# ---------------------------------------------------------------------------
CASES: list[tuple[str, Any]] = []


def case(fn):
    CASES.append((fn.__name__, fn))
    return fn


def load_real_mtproto(src: str | None = None):
    return drv.load_real_mtproto(src)


def _make_production_world(mt):
    """acc_PRIMARY (raw+proxy) + acc_B (raw) in the REAL registry shape."""
    raw_primary = drv.FakeClient("acc_PRIMARY", WORLD)
    raw_b = drv.FakeClient("acc_B", WORLD)
    cluster = RealShapeCluster(
        {"acc_PRIMARY": raw_primary, "acc_B": raw_b})
    mt._mtproto_client = None          # the production global is routed away
    mt._userbot_cluster = cluster
    mt._cluster = cluster
    return raw_primary, raw_b, cluster


def fresh_proxy(raw_primary):
    """A NEW proxy per call — exactly mtproto_get_client() semantics."""
    return GatedProxy(raw_primary, "cluster:acc_PRIMARY")


def _reset(mt):
    drv._reset_module_state(mt)
    WORLD.channels.clear()
    WORLD.chats.clear()
    WORLD.users.clear()
    WORLD.sessions.clear()
    WORLD.dialogs.clear()
    WORLD.contacts.clear()
    PRIVATE_FOR.clear()
    FLOODWAIT_ON.clear()
    LEDGER.reset()


def _scope_of(entry) -> str:
    if isinstance(entry, dict):
        return str(entry.get("scope") or "")
    return ""


# ---------------------------------------------------------------------------
# The cases
# ---------------------------------------------------------------------------
@case
def V1_valid_scoped_hash_local_cache_miss(mt):
    """S14/S30-1: DB knows the entity + type + a scope-VALID hash, but
    Telethon's local entity cache does NOT contain the channel.  The
    smallest safe recovery: Step 0b typed InputPeerChannel probe -> ONE
    RPC.  NO account rotation.  NO 9-step cascade.  State persisted."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11001
    WORLD.add_channel(RAW, title="v1-chan",
                      accounts={"acc_PRIMARY": 4242}, session=["acc_B"])
    marked = MARKED_BASE - RAW
    # Prime the scoped state for the PRIMARY (its OWN verified hash).
    mt._v9810_access_remember(
        "acc_PRIMARY", mt._vc_entity_identity(marked), None, "test")
    mt._v9810_access_state[("acc_PRIMARY", marked)]["access_hash"] = 4242

    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=4242))
    assert res["ok"], res
    assert res.get("outcome") == "RESOLVED_FROM_SCOPE_STATE", res
    assert mt._v9810_resolution_stats.get("rotations", 0) == 0, \
        "valid scoped hash + local miss must NOT rotate (S5)"
    assert LEDGER.input_entity_miss == 0, \
        "the typed InputPeer path must not consult the local cache"
    assert LEDGER.count("iter_dialogs") == 0, \
        "no dialogs scan for a known typed entity (S6)"
    assert LEDGER.total() <= 1, LEDGER.calls
    return "valid scoped hash + local cache miss -> 1 typed RPC, 0 rotations"


@case
def V2_stale_scoped_hash_refresh(mt):
    """S15/S30-2: the DB hash for THIS scope is stale.  Expected:
    typed request -> hash rejection -> invalidate ONLY this account's
    hash -> refresh (dialogs index — the account IS a member) -> new
    hash -> success -> persist new scoped hash.  Other accounts'
    hashes UNTOUCHED."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11002
    WORLD.add_channel(RAW, title="v2-chan",
                      accounts={"acc_PRIMARY": 777, "acc_B": 888},
                      session=["acc_PRIMARY", "acc_B"])
    marked = MARKED_BASE - RAW
    # Prime ONLY the OWNER's scoped entry (stale hash — the server
    # rotated it).  acc_B has NO scoped knowledge yet, so the Step-0c
    # route cannot short-circuit the deterministic owner refresh (the
    # 0c-route variant is covered separately by V12).
    ident = mt._vc_entity_identity(marked)
    mt._v9810_access_remember("acc_PRIMARY", ident, None, "test")
    mt._v9810_access_state[("acc_PRIMARY", marked)]["access_hash"] = 12345
    # The primary IS a dialog member (the refresh source).
    WORLD.dialogs["acc_PRIMARY"] = [
        drv.Channel(id=RAW, title="v2-chan", access_hash=777)]

    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=12345))
    assert res["ok"], res
    # ONE deterministic refresh path — not a fallback cascade:
    # probe(1 rejected) + dialogs-index lookup (1 scan, member hit).
    assert mt._v9810_resolution_stats.get("rotations", 0) == 0, \
        "stale hash is refreshed in place; rotation NOT justified (S6)"
    assert LEDGER.invalid_channel_object >= 1, \
        "the stale hash must be observed rejected"
    # The NEW hash is persisted for THIS scope only.
    _pri = mt._v9810_access_state.get(("acc_PRIMARY", marked), {})
    assert int(_pri.get("access_hash") or 0) == 777, _pri
    # No OTHER-scope entry was created (no global poisoning, S10) — the
    # world hash 888 belongs to acc_B but nobody consumed it.
    assert ("acc_B", marked) not in mt._v9810_access_state, \
        "the refresh must not fabricate other-scope knowledge"
    # The stale-hash hint is recorded for the primary scope only.
    assert mt._v9810_hash_invalid_check("acc_PRIMARY", marked, 12345)
    assert not mt._v9810_hash_invalid_check("acc_B", marked, 12345)
    return ("stale hash -> scope-local invalidation + dialogs refresh -> "
            "new hash persisted; no other-scope poisoning")


@case
def V3_valid_cache_object(mt):
    """S30-3: a scope-VALID flat-cache entity object resolves with ZERO
    RPCs (Step 1)."""
    _reset(mt)
    raw_primary, _, _ = _make_production_world(mt)
    RAW = 11003
    marked = MARKED_BASE - RAW
    ent = drv.Channel(id=RAW, title="v3", access_hash=31)
    mt._vc_entity_cache[marked] = {
        "entity": ent, "access_hash": 31, "source": "test",
        "scope": "acc_PRIMARY"}
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked))
    assert res["ok"] and res["source"] == "cache", res
    assert LEDGER.total() == 0, LEDGER.calls
    return "valid cached object -> 0 RPCs"


@case
def V4_representation_error_no_rotation(mt):
    """S30-4: a deterministic representation error (wrong Telethon type)
    is classified and never rotates (v98.10 C7 semantics preserved)."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    marked = MARKED_BASE - 11004
    orig = raw_primary.get_entity

    async def _cast_fail(ref):
        if isinstance(ref, (drv.InputPeerChannel, drv.PeerChannel, int)):
            raise TypeError("Cannot cast int to InputChannel")
        return await orig(ref)

    raw_primary.get_entity = _cast_fail
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=0))
    raw_primary.get_entity = orig
    assert not res.get("ok"), res
    assert "REPRESENTATION_ERROR" in str(res.get("outcome", "")), res
    assert mt._v9810_resolution_stats.get("rotations", 0) == 0
    assert raw_b.get_entity_calls == 0, \
        "acc_B must receive ZERO RPCs for a representation error"
    return "representation error classified; zero rotation, zero B RPCs"


@case
def V5_basic_group_typed(mt):
    """S30-5: a basic group resolves via GetFullChatRequest (the CORRECT
    request; a channel RPC on a chat is the S13 signature)."""
    _reset(mt)
    raw_primary, _, _ = _make_production_world(mt)
    WORLD.chats[11005] = drv.Chat(id=11005, title="basic-group")
    LEDGER.reset()
    ent = asyncio.run(mt.resolve_entity_full(
        fresh_proxy(raw_primary), -11005))
    assert getattr(ent, "id", 0) == 11005, ent
    assert LEDGER.count("GetFullChatRequest") >= 1
    assert LEDGER.count("GetFullChannelRequest") == 0
    return "basic group -> GetFullChatRequest only"


@case
def V6_user_entity_no_channel_probe(mt):
    """S30-6: a USER id never reaches a channel-specific RPC."""
    _reset(mt)
    raw_primary, _, _ = _make_production_world(mt)
    WORLD.users[11006] = drv.User(id=11006, first_name="Alice")
    WORLD.contacts["acc_PRIMARY"] = [WORLD.users[11006]]
    LEDGER.reset()
    ent = asyncio.run(mt.resolve_entity_full(
        fresh_proxy(raw_primary), 11006))
    assert getattr(ent, "id", 0) == 11006, ent
    assert LEDGER.count("GetFullChannelRequest") == 0, \
        "user ids must not be probed as channels"
    return "user entity -> contacts path, zero channel RPCs"


@case
def V7_private_channel_fallback(mt):
    """S30-7/S16: a channel that is PRIVATE for the primary but accessible
    to acc_B.  Expected: confirmed PRIVATE classification on the primary
    (server-verified, not a cache miss) + JUSTIFIED rotation to acc_B."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11007
    WORLD.add_channel(RAW, title="priv",
                      accounts={"acc_B": 551}, session=["acc_B"])
    PRIVATE_FOR[RAW] = {"acc_PRIMARY"}
    marked = MARKED_BASE - RAW

    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=551))
    assert res["ok"], res
    # Rotation happened ONLY because the composite class elevated the
    # Step-2 probe's server-verified PRIVATE observation over the
    # ladder's LOCAL_MISS noise (the v98.11 S4 composite - a pure
    # LOCAL_MISS would have been gated by V17's no-rotation rule).
    assert "account_rotation:acc_B" in res["source"], res
    assert mt._v9810_resolution_stats.get("rotations", 0) == 1, \
        mt._v9810_resolution_stats
    assert mt._v9810_resolution_stats.get(
        "local_miss_no_rotation", 0) == 0, \
        "PRIVATE evidence must not be gated as a local miss"
    return ("private-for-primary -> composite PRIVATE class + justified "
            "acc_B fallback (rotation=1, gated-local-miss=0)")


@case
def V8_nonexistent_entity_bounded(mt):
    """S30-8/S17: a genuinely nonexistent entity fails with a bounded
    negative result — the rejected-hash hint suppresses hash replay
    within the TTL (no repeated full cascade)."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    marked = MARKED_BASE - 11008   # NOT in the world at all
    LEDGER.reset()
    res1 = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=987654))
    assert not res1["ok"], res1
    # The rejection evidence was recorded for the primary scope.
    assert mt._v9810_hash_invalid_check("acc_PRIMARY", marked, 987654)
    # Second attempt within the TTL: the rejected hash is NOT replayed.
    LEDGER.reset()
    res2 = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=987654))
    assert not res2["ok"], res2
    assert LEDGER.invalid_channel_object == 0, \
        "the TTL-bounded hint must suppress the rejected-hash replay"
    return "nonexistent entity -> bounded negative (hint suppresses replay)"


@case
def V9_temporary_failure_no_rotation(mt):
    """S30-9/S18: a TRANSIENT RPC failure (connection drop) is classified
    TEMPORARY_RPC_FAILURE — the scoped entry is KEPT and account rotation
    is NOT triggered (a network blip is not account-scoped evidence)."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11009
    WORLD.add_channel(RAW, title="tmp",
                      accounts={"acc_PRIMARY": 91, "acc_B": 92},
                      session=["acc_B"])
    marked = MARKED_BASE - RAW
    ident = mt._vc_entity_identity(marked)
    mt._v9810_access_remember("acc_PRIMARY", ident, None, "test")
    mt._v9810_access_state[("acc_PRIMARY", marked)]["access_hash"] = 91
    WORLD.dialogs["acc_PRIMARY"] = []

    # Fail EVERY RPC form for acc_PRIMARY at the DISPATCH level (both
    # bound-method get_entity and request-object calls go through
    # mtproto_call_with_retry) — and keep the primary OUT of the session
    # so no local path can succeed either.
    WORLD.sessions.setdefault("acc_PRIMARY", set()).discard(RAW)
    orig_dispatch = mt.mtproto_call_with_retry

    async def _conn_fail(func, *args, **kw):
        _owner = getattr(func, "__self__", None)
        _acc = getattr(func, "account_id", "") or getattr(
            _owner, "account_id", "")
        if _acc == "acc_PRIMARY":
            raise ConnectionError(
                "Cannot send requests while disconnected")
        return await orig_dispatch(func, *args, **kw)

    mt.mtproto_call_with_retry = _conn_fail
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked,
        access_hash=91))
    mt.mtproto_call_with_retry = orig_dispatch
    assert not res["ok"], res
    assert "TEMPORARY_RPC_FAILURE" in str(res.get("outcome", "")), res
    assert mt._v9810_resolution_stats.get("rotations", 0) == 0, \
        "transient failures must not rotate (S5/S18)"
    # The scoped entry is KEPT (not invalidated by a transient failure).
    ent = mt._v9810_access_state.get(("acc_PRIMARY", marked))
    assert ent is not None and int(ent.get("access_hash") or 0) == 91, ent
    return "transient failure -> TEMPORARY class, entry kept, no rotation"


@case
def V10_floodwait_account_cooling(mt):
    """S30-10/S19: FloodWait during rotation marks the account COOLING
    (ERR-E-002 semantics preserved in v98.11)."""
    _reset(mt)
    raw_primary, raw_b, cluster = _make_production_world(mt)
    RAW = 11010
    WORLD.add_channel(RAW, title="fw",
                      accounts={"acc_B": 93}, session=["acc_B"])
    marked = MARKED_BASE - RAW
    FLOODWAIT_ON.add("acc_B")
    try:
        LEDGER.reset()
        res = asyncio.run(mt.resolve_vc_entity(
            fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=93))
        # acc_B FloodWaits; acc_PRIMARY cannot resolve (local miss + no
        # more accounts) -> overall failure, and the cooling marker set.
        acc = cluster._accounts.get("acc_B", {})
        assert acc.get("status") == "floodwait" or acc.get(
            "floodwait_until", 0) > 0, acc
        assert not res["ok"], res
    finally:
        FLOODWAIT_ON.clear()
    return "FloodWait during rotation -> account cooling (ERR-E-002 kept)"


@case
def V11_production_chain_and_cost(mt):
    """S25 signature: the EXACT (5).log chain — fresh proxy per call, DB
    hash foreign (acc_B's), primary local cache miss.  v98.11: rotation
    IS justified (server-verified hash rejection) but pays ONE typed
    probe on the winning account instead of the full ladder."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11011
    WORLD.add_channel(RAW, title="prod",
                      accounts={"acc_B": 94}, session=["acc_B"])
    marked = MARKED_BASE - RAW

    LEDGER.reset()
    t0 = time.monotonic()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=94))
    dt = (time.monotonic() - t0) * 1000
    assert res["ok"], res
    assert "account_rotation:acc_B" in res["source"], res
    # The B-side cost: ONE typed probe (no dialogs scan for B — hmm, the
    # B ladder only runs if the probe fails; here the probe WINS).
    b_entity_rpcs = raw_b.get_entity_calls
    assert b_entity_rpcs >= 1
    assert LEDGER.count("iter_dialogs") <= 2, \
        "dialogs scans are index-bounded: at most one per account (S24)"
    # v98.10's production chain burned 5 RPCs + 2 full dialogs scans
    # (~9.3s live); v98.11's chain is RPC-counted and scan-bounded.
    assert LEDGER.total() <= 12, LEDGER.calls
    return (f"production chain: {LEDGER.total()} RPCs, "
            f"{LEDGER.count('iter_dialogs')} dialogs scans, "
            f"rotations=1 (justified: hash rejection), {dt:.1f}ms mock")


@case
def V12_convergence_durable_knowledge(mt):
    """S9/S30-12/13: success becomes DURABLE knowledge — cycle 2 resolves
    with ZERO RPCs (Step 0c known-good routing through the PRODUCTION
    proxy topology); after restart, ONE typed RPC per entity."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    N = 6
    for i in range(N):
        r = 12000 + i
        WORLD.add_channel(r, title=f"conv-{i}",
                          accounts={"acc_B": 2000 + i}, session=["acc_B"])

    async def cycle():
        ok = 0
        for i in range(N):
            marked = MARKED_BASE - (12000 + i)
            res = await mt.resolve_vc_entity(
                fresh_proxy(raw_primary), marked, chat_id=marked,
                access_hash=2000 + i)
            ok += 1 if res.get("ok") else 0
        return ok

    LEDGER.reset()
    ok1 = asyncio.run(cycle())
    rpcs1 = LEDGER.total()
    inv1 = LEDGER.invalid_channel_object
    assert ok1 == N, (ok1, N)

    LEDGER.reset()
    ok2 = asyncio.run(cycle())
    assert ok2 == N, (ok2, N)
    assert LEDGER.total() == 0, \
        f"cycle 2 must resolve with ZERO RPCs (S9), got {LEDGER.calls}"
    assert LEDGER.invalid_channel_object == 0

    # --- restart: flush + fresh module + fresh proxies ---
    asyncio.run(mt._flush_access_hash_persistence())
    pfile = Path(mt._VC_ACCESS_HASH_FILE)
    assert pfile.exists()
    drv.install_stubs(str(pfile.parent.parent))
    mt2 = load_real_mtproto()
    mt2._mtproto_client = None
    _rp2, _rb2, _ = _make_production_world(mt2)
    LEDGER.reset()
    ok3 = 0
    for i in range(N):
        marked = MARKED_BASE - (12000 + i)
        res = asyncio.run(mt2.resolve_vc_entity(
            GatedProxy(_rp2, "cluster:acc_PRIMARY"), marked,
            chat_id=marked, access_hash=2000 + i))
        ok3 += 1 if res.get("ok") else 0
    assert ok3 == N, (ok3, N)
    assert LEDGER.total() <= N, \
        f"restart routing: <=1 RPC per entity, got {LEDGER.total()}"
    return (f"learning cycle: {rpcs1} RPCs / {inv1} rejections -> "
            f"cycle2: 0 RPCs -> restart: {LEDGER.total()} RPCs "
            f"(durable scoped knowledge)")


@case
def V13_single_flight_waiter_cancel(mt):
    """S30-14/15: concurrent requests share ONE flight; a waiter's
    cancellation does NOT cancel the shared leader flight (mirror-future
    contract, v97.73-compliant)."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11013
    WORLD.add_channel(RAW, title="sf",
                      accounts={"acc_B": 96}, session=["acc_B"])
    marked = MARKED_BASE - RAW

    # Slow the acc_B typed probe so the leader stays in flight.
    orig = drv._dispatch_mtproto_call

    async def _slow(func, *args, **kw):
        _owner = getattr(func, "__self__", None)
        _acc = getattr(func, "account_id", "") or getattr(
            _owner, "account_id", "")
        req = args[0] if args else None
        if _acc == "acc_B" and (
                (req is not None and hasattr(req, "kind"))
                or isinstance(req, (drv.InputPeerChannel, drv.InputPeerChat,
                                    drv.InputPeerUser))):
            await asyncio.sleep(0.25)
        return await orig(func, *args, **kw)

    mt.mtproto_call_with_retry = _slow

    async def scenario():
        leader = asyncio.ensure_future(mt.resolve_vc_entity(
            fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=96))
        await asyncio.sleep(0.05)     # leader is mid-flight
        waiter = asyncio.ensure_future(mt.resolve_vc_entity(
            fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=96))
        waiter2 = asyncio.ensure_future(mt.resolve_vc_entity(
            fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=96))
        await asyncio.sleep(0.05)
        waiter.cancel()               # the waiter dies; the leader must not
        try:
            await waiter
        except asyncio.CancelledError:
            pass
        res_leader = await leader
        res_w2 = await waiter2
        return res_leader, res_w2

    res_leader, res_w2 = asyncio.run(scenario())
    mt.mtproto_call_with_retry = drv._dispatch_mtproto_call
    assert res_leader["ok"], res_leader
    assert res_w2["ok"], res_w2
    assert res_leader["entity"] is res_w2["entity"] or \
        getattr(res_leader["entity"], "id", 0) == \
        getattr(res_w2["entity"], "id", 0)
    joins = mt._v9810_resolution_stats.get("singleflight_joins", 0)
    assert joins >= 1, mt._v9810_resolution_stats
    return (f"waiter cancel survived: leader ok, second waiter ok, "
            f"{joins} singleflight joins")


@case
def V14_no_raw_positive_int_probe(mt):
    """S30-22: no raw positive integer ever reaches a channel RPC as a
    user representation (the v98.09 PeerUser regression guard)."""
    _reset(mt)
    raw_primary, _, _ = _make_production_world(mt)
    WORLD.add_channel(11014, title="pos",
                      accounts={"acc_PRIMARY": 97}, session=["acc_PRIMARY"])
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), MARKED_BASE - 11014,
        chat_id=MARKED_BASE - 11014, access_hash=97))
    assert res["ok"], res
    assert LEDGER.count("users.GetUsersRequest") == 0, \
        "raw-positive-int PeerUser probes must not happen"
    return "zero users.GetUsersRequest probes (typed forms only)"


@case
def V15_dialogs_index_one_scan_per_ttl(mt):
    """S24: the dialogs step scans ONCE per (scope, TTL); a second
    resolution inside the TTL serves from the index; TTL expiry
    re-scans exactly once."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11015
    WORLD.add_channel(RAW, title="idx",
                      accounts={"acc_B": 98}, session=["acc_B"])
    WORLD.dialogs["acc_PRIMARY"] = []
    marked = MARKED_BASE - RAW

    # Two full (failing) resolutions on the primary: the dialogs step
    # runs twice but scans ONCE.
    for _ in range(2):
        asyncio.run(mt.resolve_vc_entity(
            fresh_proxy(raw_primary), marked, chat_id=marked,
            access_hash=0))
    assert raw_primary.iter_dialogs_calls == 1, \
        raw_primary.iter_dialogs_calls
    # TTL expiry -> exactly one more scan.
    _key = "acc_PRIMARY"
    _ts, _idx = mt._v9811_dialogs_index[_key]
    mt._v9811_dialogs_index[_key] = (
        _ts - (mt._v9811_dialogs_index_ttl() + 1), _idx)
    asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=0))
    assert raw_primary.iter_dialogs_calls == 2, \
        raw_primary.iter_dialogs_calls
    return "dialogs index: 2 resolutions -> 1 scan; TTL expiry -> 1 more"


@case
def V16_scope_stability_across_proxies(mt):
    """S9: proxy recreation does NOT change the scope; the persisted
    scopes are STABLE tokens ("global"/"acc_*") — the v98.10 proxy-scope
    root cause."""
    _reset(mt)
    raw_primary, _, cluster = _make_production_world(mt)
    p1 = fresh_proxy(raw_primary)
    p2 = fresh_proxy(raw_primary)
    assert p1 is not p2, "proxies are per-call objects"
    s1 = mt._vc_client_scope(p1)
    s2 = mt._vc_client_scope(p2)
    assert s1 == s2 == "acc_PRIMARY", (s1, s2)
    # Raw clients in the REAL registry shape also resolve stably.
    assert mt._vc_client_scope(raw_primary) == "acc_PRIMARY"
    assert mt._vc_client_scope(raw_primary) != f"client:{id(raw_primary)}"
    # A global-proxy shape maps to "global".
    gp = GatedProxy(raw_primary, "global")
    assert mt._vc_client_scope(gp) == "global"
    # Flat-cache entries written through proxies carry stable scopes.
    WORLD.add_channel(11016, title="stab",
                      accounts={"acc_B": 99}, session=["acc_B"])
    marked = MARKED_BASE - 11016
    asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=99))
    scopes = {_scope_of(v) for v in mt._vc_entity_cache.values()
              if isinstance(v, dict)}
    assert scopes <= {"acc_B", ""}, scopes
    return "proxy recreation: stable acc_ scopes everywhere"


@case
def V17_local_miss_only_no_rotation(mt):
    """S5 core rule: a LOCAL session-cache miss with NO hash-rejection
    evidence does NOT rotate — PEER_NOT_FOUND_LOCALLY != NOT_ACCESSIBLE."""
    _reset(mt)
    raw_primary, raw_b, _ = _make_production_world(mt)
    RAW = 11017
    # The REQUESTER passes NO hash (access_hash=0): the primary's ladder
    # fails with PURE local misses and NO hash-rejection evidence exists.
    # acc_B is a session member (its hash is 555 — nobody asked for it).
    WORLD.add_channel(RAW, title="lmo",
                      accounts={"acc_B": 555}, session=["acc_B"])
    marked = MARKED_BASE - RAW
    LEDGER.reset()
    res = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=0))
    assert not res["ok"], res
    assert res.get("outcome") == "LOCAL_MISS", res
    assert mt._v9810_resolution_stats.get("rotations", 0) == 0, \
        "local-miss-only must NOT rotate (S5)"
    assert mt._v9810_resolution_stats.get(
        "local_miss_no_rotation", 0) >= 1
    assert raw_b.get_entity_calls == 0, \
        "acc_B must receive ZERO RPCs without rejection evidence"
    # The entity stays ELIGIBLE (no permanent exclusion): a scoped
    # known-good entry (acc_B) makes the NEXT request route directly
    # through KNOWLEDGE (Step 0c targeted routing - not a blind retry).
    mt._v9810_access_remember(
        "acc_B", mt._vc_entity_identity(marked),
        drv.Channel(id=RAW, title="lmo", access_hash=555), "test")
    res2 = asyncio.run(mt.resolve_vc_entity(
        fresh_proxy(raw_primary), marked, chat_id=marked, access_hash=0))
    assert res2["ok"], res2
    assert "account_rotation:acc_B" in res2["source"], res2
    return ("local-miss-only -> LOCAL_MISS class, zero rotation, zero "
            "B-side RPCs; knowledge still routes once learned")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
def main() -> int:
    logging.disable(logging.CRITICAL)
    tmp = tempfile.mkdtemp(prefix="v9811_drv_")
    Path(tmp, "data").mkdir(parents=True, exist_ok=True)
    drv.install_stubs(tmp)
    # v98.11 (test-mechanism): bind to the STUB telethon's exception
    # classes so ``except FloodWaitError`` in the REAL mtproto matches
    # by TYPE (the module-level shims are name-compatible placeholders).
    global FloodWaitError, ChannelPrivateError
    from telethon.errors import FloodWaitError as _stub_fwe  # noqa: E402
    from telethon.errors import (  # noqa: E402
        ChannelPrivateError as _stub_cpe,
    )
    FloodWaitError = _stub_fwe
    ChannelPrivateError = _stub_cpe
    mt = load_real_mtproto()
    failures = 0
    for name, fn in CASES:
        try:
            detail = fn(mt)
            print(f"CASE {name}: PASS - {detail}")
        except AssertionError as exc:
            failures += 1
            print(f"CASE {name}: FAIL - {type(exc).__name__}: {exc}")
        except Exception as exc:  # noqa: BLE001
            failures += 1
            print(f"CASE {name}: FAIL - {type(exc).__name__}: {exc}")
    print(f"v98.11 entity driver: "
          f"{len(CASES) - failures}/{len(CASES)} cases pass")
    return failures


if __name__ == "__main__":
    sys.exit(main())
