"""v98.09-P3 — Join-All fast-path / discovery knowledge-cache regression.

Covers the v98.09-P3 §28 test matrix (Tests 1-17 + the §29 dedicated
account-rotation scenario) with two complementary layers:

  §A — SOURCE CONTRACTS (AST-level, mirroring the v98.09 leave/architecture
        suites): the fast-path ordering, tiered verification, adaptive
        pacing/expansion/pagination, cross-backend ownership, and the §17
        stop/cancellation wiring are pinned to the REAL source.

  §B — BEHAVIORAL REGRESSION (subprocess): tests/_v9810_fastpath_driver.py
        stub-imports the REAL voicechat module (telegram/telethon/pytgcalls
        unavailable in the sandbox — the same blind-spot class the P2 leave
        driver closed) with a fake Telethon RPC surface whose EVERY RPC is
        counted, a dict-backed knowledge-cache db_layer implementing the
        REAL function contracts, and the REAL stdlib-only worker
        infrastructure (state machine, circuit breaker, cancellation token,
        coordinator).  The REAL ``_vc_join_all_active_worker`` runs end to
        end against that world.

Baseline reference (this suite must stay green through the §27 mandatory
run): python -m pytest -q tests/test_v98_09_leave_regression.py → 27 passed.
"""
from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
import unittest

_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_SRC = os.path.join(_ROOT, "mediagrab_bot")
_VC = os.path.join(_SRC, "voicechat.py")
_DRIVER = os.path.join(_ROOT, "tests", "_v9810_fastpath_driver.py")


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _tree(path: str) -> ast.Module:
    return ast.parse(_read(path))


def _fn(tree: ast.Module, name: str):
    for node in ast.walk(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) \
                and node.name == name:
            return node
    return None


def _contains_call(node, func_name: str) -> bool:
    for n in ast.walk(node):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) \
                and n.func.id == func_name:
            return True
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) \
                and n.func.attr == func_name:
            return True
    return False


# ---------------------------------------------------------------------------
# §A — Source contracts (the §28 matrix, pinned to the real source)
# ---------------------------------------------------------------------------

class TestFastPathSourceContracts(unittest.TestCase):
    """Tests 1/2/15/16 + §4 ordering — the fast path precedes discovery."""

    @classmethod
    def setUpClass(cls):
        cls.tree = _tree(_VC)
        cls.worker = _fn(cls.tree, "_vc_join_all_active_worker")
        cls.src = _read(_VC)

    def test_worker_calls_knowledge_snapshot_before_discover_groups(self):
        """Test 1 — the knowledge snapshot is consulted BEFORE the
        dialog discovery (cache-first ordering pinned by line number)."""
        self.assertIsNotNone(self.worker)
        snap = [n.lineno for n in ast.walk(self.worker)
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                and n.func.id == "vc_knowledge_snapshot"]
        disc = [n.lineno for n in ast.walk(self.worker)
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                and n.func.id == "vc_discover_groups"]
        self.assertEqual(len(snap), 1, "exactly one knowledge snapshot")
        self.assertTrue(snap[0] < disc[0],
                        f"snapshot({snap[0]}) must precede "
                        f"vc_discover_groups({disc[0]})")

    def test_discover_groups_call_is_conditional_on_fast_path(self):
        """Test 1 — the dialog scan only runs when the fast path declined
        (``if _fast_candidates is None:`` guards the blocking discovery)."""
        self.assertIn("if _fast_candidates is None:", self.src)
        # The worker's guarded discovery call directly follows the guard.
        guard_idx = self.src.index("if _fast_candidates is None:")
        window = self.src[guard_idx:guard_idx + 400]
        self.assertIn("await vc_discover_groups()", window,
                      "the blocking discovery call must sit inside the "
                      "fast-path-declined guard")

    def test_bg_refresh_started_before_blocking_fallback(self):
        """§4 — the decoupled background refresh is launched (not awaited
        on the critical path) when the fast path engages."""
        self.assertIn("VC_JOIN_ALL_BG_REFRESH_START", self.src)
        self.assertIn("_vc_join_all_bg_refresh_start()", self.src)
        # The worker starts it inside the fast-path branch.
        starts = [n.lineno for n in ast.walk(self.worker)
                  if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                  and n.func.id == "_vc_join_all_bg_refresh_start"]
        self.assertEqual(len(starts), 1)

    def test_fresh_verified_recheck_skip_contract(self):
        """Test 16 — the Phase-4 authoritative recheck is guarded by
        ``not target.get("fresh_verified")`` so fresh discovery data is
        never re-detected (the duplicate VC-detection RPC removal)."""
        guard = ('if result_state not in ("skipped_breaker",) '
                 'and not target.get("fresh_verified")')
        self.assertIn(guard, self.src)
        self.assertIn("VC_JOIN_ALL_RECHECK_SKIPPED", self.src)

    def test_adaptive_pacing_sleep_contract(self):
        """§14 — the fixed 0.5s per-candidate sleep became adaptive
        (``0.5 if _candidate_rpc_performed else 0``): retained pacing
        after real RPCs, event-loop yield for cache/no-RPC candidates."""
        self.assertIn("0.5 if _candidate_rpc_performed else 0", self.src)
        self.assertIn("_candidate_rpc_performed = True", self.src)

    def test_fast_path_gate_exists_and_config_backed(self):
        """§25 — the fast path is operator-switchable (config
        vc_join_all_fast_path, env VC_JOIN_ALL_FAST_PATH)."""
        self.assertIn("vc_join_all_fast_path", _read(
            os.path.join(_SRC, "config.py")))
        self.assertIn("_vc_join_all_fast_path_enabled", self.src)


class TestKnowledgeCacheContracts(unittest.TestCase):
    """§7/§19/§20 — cache-first discovery handoff, TTLs, writers."""

    @classmethod
    def setUpClass(cls):
        cls.tree = _tree(_VC)
        cls.src = _read(_VC)
        cls.db = _read(os.path.join(_SRC, "db_layer.py"))

    def test_knowledge_ttl_short_and_config_backed(self):
        """§20 — the active-VC TTL is SHORT (active state changes quickly),
        config-driven with a sane default (300s), and clamped."""
        cfg = _read(os.path.join(_SRC, "config.py"))
        self.assertIn("vc_knowledge_active_ttl", cfg)
        self.assertIn("VC_KNOWLEDGE_ACTIVE_TTL", cfg)
        self.assertIn("_clamp_int(\"vc_knowledge_active_ttl\"", cfg)

    def test_idempotent_schema_migration(self):
        """§7/§25 — the knowledge columns are additive ALTERs through the
        existing idempotent _run_migrations path (old installs upgrade
        transparently; no data destruction)."""
        self.assertIn("ALTER TABLE vc_groups ADD COLUMN last_active_vc_at",
                      self.db)
        self.assertIn("ALTER TABLE vc_groups ADD COLUMN call_id", self.db)
        self.assertIn("ALTER TABLE vc_groups ADD COLUMN call_access_hash",
                      self.db)
        self.assertIn("vc_groups_fresh_active", self.db)
        self.assertIn("vc_knowledge_store_active", self.db)
        self.assertIn("vc_knowledge_mark_inactive", self.db)

    def test_knowledge_writers_cover_all_classification_paths(self):
        """§19 — every path that verifies an active VC persists the
        knowledge (worker Phase-2, auto-cycle, multi-account pass,
        run_cycle, watcher, revalidate, manual search)."""
        handlers_src = _read(os.path.join(_SRC, "handlers.py"))
        sources = {
            'source="join_all_phase2"': self.src,
            'source="auto_cycle"': self.src,
            'source="auto_multi_account"': self.src,
            'source="run_cycle"': self.src,
            'source="watcher"': self.src,
            'source="revalidate"': self.src,
            'source="manual_search"': handlers_src,
        }
        for marker, target in sources.items():
            self.assertIn(marker, target,
                          f"knowledge writer missing: {marker}")

    def test_stale_refresh_bounded(self):
        """§4 — the stale Tier-2 refresh quota is bounded (config
        vc_knowledge_stale_refresh_limit, default 40; clamped)."""
        cfg = _read(os.path.join(_SRC, "config.py"))
        self.assertIn("vc_knowledge_stale_refresh_limit", cfg)
        self.assertIn("vc_knowledge_snapshot_stale", self.src)

    def test_fresh_active_snapshot_ordering(self):
        """§4/§7 — the snapshot orders by most-recent verification and
        limits results (never a hidden full-scan)."""
        db_src = self.db
        self.assertIn("ORDER BY last_active_vc_at DESC LIMIT", db_src)
        self.assertIn("WHERE active_vc=1 AND last_active_vc_at IS NOT NULL",
                      db_src)


class TestAccountAwareContracts(unittest.TestCase):
    """§12/§13/§1 — cross-backend ownership + rotation invariant."""

    @classmethod
    def setUpClass(cls):
        cls.tree = _tree(_VC)
        cls.src = _read(_VC)

    def test_container_union_covers_all_backends(self):
        """§13 — _vc_calls_container_union iterates the GLOBAL backend AND
        every per-account backend (both ID forms) so per-account joins are
        visible to Join-All's already-joined detection."""
        union = _fn(self.tree, "_vc_calls_container_union")
        self.assertIsNotNone(union)
        self.assertIn("_account_backends", self.src)

    def test_snapshot_uses_union_not_global_only(self):
        """§13 — the worker Phase-2 snapshot consults the cross-backend
        helper (NOT the old global-only vc_resolve_calls_container call)."""
        worker = _fn(self.tree, "_vc_join_all_active_worker")
        self.assertIsNotNone(worker)
        union_calls = [n.lineno for n in ast.walk(worker)
                       if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                       and n.func.id == "_vc_target_connected_any_backend"]
        global_only = [n.lineno for n in ast.walk(worker)
                       if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                       and n.func.id == "vc_resolve_calls_container"]
        self.assertTrue(union_calls,
                        "worker must use the cross-backend union check")
        self.assertEqual(global_only, [],
                         "worker must not call the global-only container "
                         "resolver directly (§13)")

    def test_stop_cancels_bg_refresh(self):
        """§17 — vc_join_all_active_stop cancels the decoupled background
        discovery refresh (pending discovery work stops with the run)."""
        stop = _fn(self.tree, "vc_join_all_active_stop")
        self.assertIsNotNone(stop)
        self.assertTrue(_contains_call(stop, "_vc_join_all_bg_refresh_cancel"))
        # The worker's finally cancels it too (terminal paths).
        worker = _fn(self.tree, "_vc_join_all_active_worker")
        self.assertTrue(_contains_call(worker, "_vc_join_all_bg_refresh_cancel"))

    def test_rotation_backend_preservation_unchanged(self):
        """§1 — the v97.86 preserve-connections semantics survive the P3
        edits (rotation must never tear down an owner backend)."""
        self.assertIn("VC_BACKEND_PRESERVED", self.src)
        self.assertIn("preserve_connections: bool = True", self.src)


class TestDiscoveryDedupContracts(unittest.TestCase):
    """§6/§9/§10/§11 — single canonical search, metadata reuse, adaptive
    expansion + pagination."""

    @classmethod
    def setUpClass(cls):
        cls.tree = _tree(_VC)
        cls.src = _read(_VC)

    def test_public_search_legacy_loop_is_fallback_only(self):
        """§6 — _vc_discovery_public_search returns pipeline results when
        present; the legacy SearchGlobal loop only fires on zero yield."""
        self.assertIn("DISCOVERY_LEGACY_LOOP_SKIPPED", self.src)
        self.assertIn("pipeline_yield_nonzero", self.src)

    def test_classify_accepts_prefetched_metadata(self):
        """§9 — _vc_discovery_classify accepts Stage-10 prefetched
        metadata (the duplicate GetFullChannel probe is skipped)."""
        classify = _fn(self.tree, "_vc_discovery_classify")
        self.assertIsNotNone(classify)
        kw = [a.arg for a in classify.args.kwonlyargs]
        self.assertIn("prefetched", kw)
        guarded = _fn(self.tree, "_vc_arch_classify_guarded")
        self.assertIsNotNone(guarded)
        guarded_kw = [a.arg for a in guarded.args.kwonlyargs]
        self.assertIn("prefetched", guarded_kw)

    def test_stage10_map_flows_to_cycles(self):
        """§9 — the Stage-10 metadata map is exported by the v851 wrapper
        and consumed by the auto-cycle + run-cycle classification."""
        self.assertIn("_stage10_by_id", self.src)
        self.assertIn("prefetched=_stage10_map.get(int(raw_gid))", self.src)
        self.assertIn("prefetched=_stage10_map_run.get(int(raw_gid))", self.src)

    def test_adaptive_expansion_gates(self):
        """§10 — expansion/fuzzy skip on sufficient yield; zero-yield
        queries keep full variant coverage; config-gated."""
        self.assertIn("sufficient_exact_yield", self.src)
        self.assertIn("nonzero_yield_after_expansion", self.src)
        self.assertIn("vc_discovery_adaptive_expansion", self.src)

    def test_adaptive_pagination_early_stop(self):
        """§11 — zero-new-unique page stops pagination; offset_rate flows
        to page 2+ (the write-only next_rate bug fixed); hard cap kept."""
        self.assertIn("DISCOVERY_PAGINATION_EARLY_STOP", self.src)
        self.assertIn("zero_new_unique", self.src)
        self.assertIn("offset_rate=offset_rate", self.src)
        builder = _fn(self.tree, "_build_search_global_request")
        self.assertIsNotNone(builder)
        params = [a.arg for a in builder.args.args]
        self.assertIn("offset_rate", params)

    def test_run_cycle_batch_commit(self):
        """§22 — run_cycle no longer commits per row; ONE batch commit per
        query-entity gather (upsert/store_result pass commit=False)."""
        run_cycle = _fn(self.tree, "vc_discovery_run_cycle")
        self.assertIsNotNone(run_cycle)
        self.assertIn("v98.09-P3 §22: batched commit", self.src)
        self.assertIn("commit=False,  # v98.09-P3 §22: batched commit",
                      self.src)

    def test_metrics_observability_present(self):
        """§23 — the Join-All + cycle metric dicts, the terminal
        VC_JOIN_ALL_METRICS line, and the VC_DISCOVERY_CYCLE_METRICS line
        exist (performance regressions diagnosable from measurements)."""
        self.assertIn("_v9810_join_metrics", self.src)
        self.assertIn("VC_JOIN_ALL_METRICS", self.src)
        self.assertIn("VC_DISCOVERY_CYCLE_METRICS", self.src)
        self.assertIn("v9810_metrics_snapshot", self.src)

    def test_db_layer_knowledge_functions_imported(self):
        """§7 — voicechat imports the knowledge-cache functions from
        db_layer (compile-time contract for the stub-import driver)."""
        self.assertIn("vc_groups_fresh_active, vc_groups_stale_active",
                      self.src)
        self.assertIn("vc_knowledge_store_active, vc_knowledge_mark_inactive",
                      self.src)


# ---------------------------------------------------------------------------
# §B — Behavioral regression (subprocess): the REAL module + REAL worker
# ---------------------------------------------------------------------------

class TestFastPathBehavioralRegression(unittest.TestCase):
    """§28 matrix — runs tests/_v9810_fastpath_driver.py (16 cases)."""

    @classmethod
    def setUpClass(cls):
        cls.proc = subprocess.run(
            [sys.executable, _DRIVER],
            capture_output=True, text=True, timeout=600, cwd=_ROOT)
        cls.out = cls.proc.stdout
        cls.case_lines = [ln for ln in cls.out.splitlines()
                          if ln.startswith("CASE ")]

    def test_exit_code_zero(self):
        self.assertEqual(self.proc.returncode, 0,
                         f"driver failures:\n{self.out[-4000:]}")

    def test_all_cases_present_and_passing(self):
        expected = {
            "KB-FASTPATH", "KB-ALREADY-JOINED", "KB-OWNER-ACCOUNT",
            "ROTATION-INVARIANT", "STOP-PRESERVES", "STALE-REFRESH",
            "DUP-RESULTS", "ADAPTIVE-PAGINATION", "METADATA-REUSE",
            "FLOODWAIT-NO-DUP", "SEARCH-NO-DUP-PIPELINES",
            "ADAPTIVE-EXPANSION", "CANCELS-PENDING", "NO-CACHE-LEGACY",
            "LEAVE-OWNER-BACKEND", "MANUAL-LEAVE-JOINALL",
        }
        seen = set()
        for ln in self.case_lines:
            cid = ln.split()[1].rstrip(":")
            seen.add(cid)
            self.assertIn(": PASS — ", ln, f"case {cid} failed: {ln}")
        self.assertTrue(expected <= seen, f"missing: {expected - seen}")

    def test_t1_no_full_discovery_before_cache(self):
        self.assertIn("CASE KB-FASTPATH: PASS", self.out)

    def test_t2_fresh_active_handed_directly(self):
        self.assertIn("CASE KB-FASTPATH: PASS", self.out)
        self.assertIn("'rechecks_skipped_fresh': 1", self.out)

    def test_t3_already_joined_skipped(self):
        self.assertIn("CASE KB-ALREADY-JOINED: PASS", self.out)

    def test_t4_secondary_account_owner_detected(self):
        self.assertIn("CASE KB-OWNER-ACCOUNT: PASS", self.out)

    def test_t5_rotation_never_leaves_old_account(self):
        self.assertIn("CASE ROTATION-INVARIANT: PASS", self.out)

    def test_t6_manual_leave_joinall_call(self):
        self.assertIn("CASE MANUAL-LEAVE-JOINALL: PASS", self.out)

    def test_t7_leave_uses_owner_backend(self):
        self.assertIn("CASE LEAVE-OWNER-BACKEND: PASS", self.out)

    def test_t8_stop_preserves_joined(self):
        self.assertIn("CASE STOP-PRESERVES: PASS", self.out)

    def test_t9_duplicate_results_one_candidate(self):
        self.assertIn("CASE DUP-RESULTS: PASS", self.out)

    def test_t10_metadata_reused(self):
        self.assertIn("CASE METADATA-REUSE: PASS", self.out)

    def test_t11_adaptive_pagination_stops(self):
        self.assertIn("CASE ADAPTIVE-PAGINATION: PASS", self.out)

    def test_t12_floodwait_no_duplicate_work(self):
        self.assertIn("CASE FLOODWAIT-NO-DUP: PASS", self.out)

    def test_t13_cancellation_stops_pending(self):
        self.assertIn("CASE CANCELS-PENDING: PASS", self.out)

    def test_t14_stale_cache_triggers_refresh(self):
        self.assertIn("CASE STALE-REFRESH: PASS", self.out)

    def test_t15_fresh_cache_avoids_rpc(self):
        self.assertIn("CASE KB-FASTPATH: PASS", self.out)

    def test_t16_no_duplicate_detection_fresh_data(self):
        self.assertIn("CASE KB-FASTPATH: PASS", self.out)

    def test_legacy_path_preserved_without_cache(self):
        self.assertIn("CASE NO-CACHE-LEGACY: PASS", self.out)


# ---------------------------------------------------------------------------
# Test 17 — fresh-process import / initialization safety
# ---------------------------------------------------------------------------

class TestFreshProcessImport(unittest.TestCase):
    """Test 17 — the module imports cleanly in a fresh process (the
    v98.09 DEFECT-1 class guard, extended to the P3 additions)."""

    def test_driver_imports_real_module_fresh(self):
        proc = subprocess.run(
            [sys.executable, _DRIVER],
            capture_output=True, text=True, timeout=600, cwd=_ROOT)
        self.assertEqual(proc.returncode, 0)
        # The driver imports the REAL module body in its own process.
        self.assertIn("SUMMARY: 16/16 cases passed", proc.stdout)

    def test_ast_import_order_no_late_refs(self):
        """The v9808 hook registration at the module head still defers
        name resolution (lambda) — no import-time NameError (P2 guard)."""
        src = _read(_VC)
        lines = src.splitlines()
        # v99: window 5975:5990 -> 5120:5145 (the v99 pipeline rewrite
        # moved the join body into vc_pipeline.py — the registration
        # shifted up; contract unchanged).
        # v99.05: window 5090:5115 -> 5115:5145 (the RC-F1 helper
        # insertion above shifted the registration call to 5137;
        # contract unchanged).
        # v99.03: window 5080:5105 -> 5090:5115 (the RC-13 reconcile
        # short-circuit insertion (+14 lines above) shifted the
        # registration call to 5108; contract unchanged).
        # v99.06: window 5115:5145 -> 5445:5485 (the FIX-3a/3b
        # distribution/ownership helper block + the FIX-1
        # effective-scope helpers inserted above shifted the
        # registration call to 5473; contract unchanged).
        # v99.07: window 5445:5485 -> 5605:5655 (the FIX-1/2/3 backend-start
        # unification + FIX-4 + FIX-8 insertions above shifted the
        # registration call to 5633; contract unchanged).
        # v99.08: window 5605:5655 -> 5720:5740 (the v99.08 item-8
        # cache-bound helpers + Patch-1/Patch-2 blocks inserted above
        # shifted the registration call to 5722; contract unchanged).
        # v99.09: window 5720:5740 -> 5740:5780 (the FIX-C
        # verify_joined ownership-lookup rewrite in
        # PyTgCallsBackend shifted the registration call to 5761;
        # contract unchanged).
        # v99.10: window 5740:5780 -> 5800:5850 (the FIX-A
        # is_connected delegation guard + the FIX-B stub-mtproto
        # fallback import block at the module head shifted the
        # registration call to 5832; contract unchanged).
        # v99.11: window 5800:5850 -> 5900:5950 (the v99.11 leave-policy
        # + admission/lifecycle blocks above the registration shifted it
        # to 5926; contract unchanged: deferred registration preserved).
        # v99.11.1: window 5900:5950 -> 6020:6070 (the FIX-3
        # already-joined classification helper inserted at the module
        # head shifted the registration call to 6061; contract
        # unchanged: deferred registration + lambda preserved).
        reg = [ln for ln in lines[6020:6070]
               if ln.strip().startswith("_register_v9808_hooks")]
        self.assertTrue(reg)
        self.assertIn("lambda", reg[0])

    def test_compile_all_modules(self):
        for fname in ("voicechat.py", "db_layer.py", "config.py",
                      "handlers.py", "join_all_worker.py",
                      "vc_state_coordinator.py", "vc_architecture.py"):
            path = os.path.join(_SRC, fname)
            compile(_read(path), path, "exec")
        # tools + tests too.
        compile(_read(os.path.join(_ROOT, "tools", "vc_static_audit.py")),
                "vc_static_audit.py", "exec")


if __name__ == "__main__":
    unittest.main()
