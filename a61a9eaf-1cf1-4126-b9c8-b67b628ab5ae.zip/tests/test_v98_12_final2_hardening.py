"""v98.12-FINAL2 — SECOND-LAST-CHANCE regression suite (pytest).

Layers:
  §A  behavioral — the FINAL-2 driver (tests/_v9812_final2_driver.py,
      14 cases) and the FINAL-2 stress battery
      (tests/_v9812_final2_stress.py, 2100+ cycles, 2 accounts × 12 VCs).
  §B  source contracts — the five FINAL-2 root-cause fixes pinned at
      source level (FIX-LC leave/coordinator, FIX-ID build identity,
      FIX-WV owner-account watcher verify, FIX-TQ thrash quarantine,
      FIX-SR startup reconcile, FIX-PM metrics).
  §C  §13 live-log instrumentation markers.
  §D  §12-12 single-instance ownership contract.

FINAL-2 §12 matrix mapping (user numbering → tests):
  1  leave → coordinator sync (A/B)          → driver F1/F2 + §B FIX-LC
  2  leave → rejoin                           → driver F3/F4/F5
  3  second Join-All                          → driver F5/F6
  4  concurrent Join-All                      → driver F6 + stress
  5  second process/startup                   → driver F7/F8/F9/F14 + §B FIX-SR
  6  restart while already joined             → driver F7
  7  fresh call identity after restart        → driver F9 + stress identity
  8  two-account isolation                    → driver F10 + stress
  9  reconnect + Join race                    → driver F11
  10 leave + Join race                        → driver F12
  11 stale identity + second startup          → driver F9 + stress
  12 single-instance ownership                → §D
"""
from __future__ import annotations

import subprocess
import sys
import unittest
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_SRC = _ROOT / "mediagrab_bot"
_TESTS = _ROOT / "tests"


def _read(path: str) -> str:
    with open(path, encoding="utf-8") as f:
        return f.read()


_VC = _read(str(_SRC / "voicechat.py"))
_BOOT = _read(str(_SRC / "bootstrap.py"))
_COORD = _read(str(_SRC / "vc_state_coordinator.py"))


# ---------------------------------------------------------------------------
# §A — behavioral: FINAL-2 driver + stress battery
# ---------------------------------------------------------------------------
class TestFinal2Driver(unittest.TestCase):
    """§A: the FINAL-2 driver must pass 22/22 (exit 0) — the 14 FINAL-2
    cases + the 8 FINAL2-2 second-round cases (G/H/I)."""

    def test_driver_all_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, str(_TESTS / "_v9812_final2_driver.py")],
            capture_output=True, text=True, timeout=240, cwd=str(_ROOT))
        self.assertEqual(proc.returncode, 0,
                         f"driver failures:\n{proc.stdout[-2500:]}")
        self.assertIn("22/22 cases pass", proc.stdout)

    def test_driver_runs_without_asyncio_hygiene_warnings(self):
        """FINAL2-2 §8: 0 RuntimeWarning / never-awaited coroutine /
        destroyed-pending-task / unclosed-resource messages on stderr."""
        proc = subprocess.run(
            [sys.executable, str(_TESTS / "_v9812_final2_driver.py")],
            capture_output=True, text=True, timeout=240, cwd=str(_ROOT))
        for bad in ("RuntimeWarning", "never awaited",
                    "Task was destroyed", "unclosed",
                    "coroutine .* was never"):
            self.assertNotIn(bad, proc.stderr,
                             f"driver emitted hygiene warning {bad!r}:")

    def test_driver_covers_the_final2_matrix(self):
        src = _read(str(_TESTS / "_v9812_final2_driver.py"))
        for marker in (
            "F1_leave_coordinator_sync_account_A",       # §12-1
            "F2_leave_coordinator_sync_account_B",       # §12-1'
            "F3_leave_then_rejoin_cycle",                # §12-2
            "F6_concurrent_join_single_flight",          # §12-3/4
            "F7_restart_present_no_join_rpcs",           # §12-5/6
            "F8_restart_absent_precleaned_left",         # §12-6'
            "F9_restart_unknown_preserved",              # §12-7/11
            "F10_two_account_isolation",                 # §12-8
            "F11_reconnect_join_race_stale_reclaim",     # §12-9
            "F12_leave_join_race_serialized",            # §12-10
            "F14_startup_reconcile_single_flight",       # §12-5''
            # FINAL2-2 second-round matrix (user §3-§7)
            "G1_sequences_account_A",                     # §5 five sequences A
            "G2_sequences_account_B",                     # §5 five sequences B
            "G3_second_process_rejected_during_ops",      # §3 scenario B
            "H1_A_leaves_VC1_B_untouched_in_VC2",         # §7 isolation A→B
            "H2_B_leaves_VC2_A_untouched_in_VC1",         # §7 isolation B→A
            "H3_A_backend_outage_B_unaffected",           # §7 outage isolation
            "I1_stale_identity_restart_current_wins",     # §6 stale + restart
            "I2_stale_identity_recheck_fails_join_all",   # §6 stale + join-all
        ):
            self.assertIn(marker, src)


class TestFinal2Stress(unittest.TestCase):
    """§A: §12 stress battery — 2100 cycles, every invariant group zero."""

    def test_stress_2100_cycles_all_invariants_zero(self):
        proc = subprocess.run(
            [sys.executable, str(_TESTS / "_v9812_final2_stress.py"), "2100"],
            capture_output=True, text=True, timeout=600, cwd=str(_ROOT))
        self.assertEqual(proc.returncode, 0,
                         f"stress failures:\n{proc.stdout[-2500:]}")
        self.assertIn("FINAL2 STRESS RESULT: PASS", proc.stdout)
        self.assertIn("cycles=2100", proc.stdout)
        # §12 expected-zero accounting
        for field in ("false_stale", "false_joined", "false_left",
                      "duplicate_backend", "stale_identity_acceptance",
                      "already_joined_after_confirmed_leave",
                      "cross_account_operations", "task_leaks",
                      "lock_leaks", "registry_leaks",
                      "coordinator_desync"):
            self.assertIn(f"{field}=0", proc.stdout)


# ---------------------------------------------------------------------------
# §B — source contracts: the FINAL-2 root-cause fixes
# ---------------------------------------------------------------------------
class TestFixLCLeaveCoordinatorSync(unittest.TestCase):
    """FIX-LC: the §2 leave/coordinator desync fix."""

    def test_owner_release_transitions_coordinator(self):
        self.assertIn("async def _v9809_leave_owner_release(", _VC)
        # the JOINED→LEFT transition with the confirmed-leave evidence
        self.assertIn(
            'await _coord.record_evidence_absent(', _VC)
        self.assertIn(
            'evidence="leave_target_confirmed:container_absent_both_forms"',
            _VC)
        # BOTH id forms (raw + marked — the coordinator may be keyed by
        # either depending on the join path)
        self.assertIn(
            'for _key in (chat_id, _marked, _raw):', _VC)

    def test_leave_target_invariant_check_present(self):
        self.assertIn("VC_LEAVE_INVARIANT_OK", _VC)
        self.assertIn("VC_LEAVE_INVARIANT_VIOLATION", _VC)
        # the invariant runs in vc_leave_target's success branch
        idx = _VC.find("async def vc_leave_target(")
        end = _VC.find("async def ", idx + 60)
        body = _VC[idx:end]
        self.assertIn("_v9809_leave_owner_release(chat_id)", body)
        self.assertIn("VC_LEAVE_INVARIANT_OK", body)

    def test_coordinator_absent_transition_semantics(self):
        # §19 semantics preserved: only positive evidence may JOINED→LEFT
        self.assertIn("NEVER transitions JOINED→LEFT", _COORD)
        self.assertIn("async def record_evidence_absent", _COORD)
        # and the already_joined skip still consults _JOINED_STATES only
        self.assertIn('f"already_{cur_state.value}"', _COORD)

    def test_rejoin_ready_marker_after_leave(self):
        self.assertIn("VC_LEAVE_REJOIN_READY", _VC)


class TestFixIDBuildIdentity(unittest.TestCase):
    """FIX-ID: the __init__.py runtime hash (false mismatch)."""

    def test_init_hash_computed_and_in_runtime_map(self):
        self.assertIn('_init_path = os.path.join(_module_dir, "__init__.py")',
                      _BOOT)
        self.assertIn("_init_sha = _hashlib.sha256", _BOOT)
        self.assertIn('"__init__.py": _init_sha', _BOOT)

    def test_stamp_loop_covers_every_stamped_module(self):
        # the stamp verification loop must find a runtime hash for every
        # module in the stamp (no more actual=? false mismatches)
        self.assertIn('_v9812_actual = _v9812_runtime_hashes.get(_v9812_mod, "?")',
                      _BOOT)


class TestFixWVOwnerAccountWatcherVerify(unittest.TestCase):
    """FIX-WV: the watcher post-join verify uses the OWNER account."""

    def test_watcher_resolves_owner_client(self):
        self.assertIn("_wv_owner_be = getattr(", _VC)
        self.assertIn('backend, "_active_join_backend", None) or backend',
                      _VC)
        self.assertIn(
            "verify_client = get_userbot_cluster().get_client(", _VC)
        self.assertIn("VC_PARTICIPANT_VERIFY_ACCOUNT", _VC)

    def test_primary_fallback_is_explicit_and_logged(self):
        # the global-join fallback remains, explicitly labeled
        self.assertIn('_wv_source = "primary_fallback_global_owner"', _VC)

    def test_verify_failure_logs_account(self):
        self.assertIn(
            '"chat_id=%s reason=%s account=%s", gid, verify_reason[:100],',
            _VC)


class TestFixTQThrashQuarantine(unittest.TestCase):
    """FIX-TQ: the bounded join↔destroy cycle."""

    def test_quarantine_state_and_constants(self):
        self.assertIn("_vc_server_absent_after_join: dict[int, dict[str, Any]] = {}",
                      _VC)
        self.assertIn("_vc_join_quarantine_until: dict[int, float] = {}",
                      _VC)
        self.assertIn("_VC_JOIN_QUARANTINE_CYCLES = 2", _VC)
        self.assertIn("_VC_JOIN_QUARANTINE_SECONDS = 1800", _VC)

    def test_record_site_in_reconcile_absent(self):
        idx = _VC.find("VC_PARTICIPATION_CONFIRMED_ABSENT chat_id=%s")
        self.assertGreater(idx, 0)
        # the record site is in the LEFT handling branch AFTER the marker
        window = _VC[idx: idx + 3500]
        self.assertIn("_vc_join_quarantine_record_absent(rec.chat_id)",
                      window)

    def test_consult_sites(self):
        # join-all target loop
        idx = _VC.find("VC_JOIN_QUARANTINED chat_id=%s ")
        self.assertGreater(idx, 0)
        self.assertIn(
            'if _vc_join_quarantined(gid, run_id=_run_id, source="join_all"):',
            _VC)
        # watcher
        self.assertIn('if _vc_join_quarantined(gid, source="watcher"):',
                      _VC)
        # capacity join
        self.assertIn(
            'if _vc_join_quarantined(gid, source="capacity_aware_join"):',
            _VC)
        self.assertIn('return "quarantined_server_absent"', _VC)

    def test_clear_sites(self):
        # targeted-present clears
        self.assertIn('reason="targeted_query_present"', _VC)
        # explicit user join clears
        self.assertIn('reason="explicit_user_join"', _VC)
        # leave-all reset clears
        self.assertIn("_vc_join_quarantine_until.clear()", _VC)
        # prune keeps the map bounded
        self.assertIn("VC_CACHE_PRUNE join_quarantine", _VC)

    def test_manual_join_not_blocked_by_quarantine(self):
        idx = _VC.find("async def vc_manual_join(")
        end = _VC.find("\nasync def ", idx + 60)
        body = _VC[idx:end]
        self.assertIn("_vc_join_quarantine_clear", body)


class TestFixSRStartupReconcile(unittest.TestCase):
    """FIX-SR: the second-run startup reconcile."""

    def test_function_and_single_flight(self):
        self.assertIn("async def vc_startup_reconcile_participations(",
                      _VC)
        self.assertIn("_vc_startup_reconcile_lock", _VC)
        self.assertIn("async with _vc_startup_reconcile_lock:", _VC)

    def test_bootstrap_schedules_after_cluster(self):
        # scheduled INSIDE _cluster_startup_validate_bg (after validation)
        idx = _BOOT.find("async def _cluster_startup_validate_bg(")
        end = _BOOT.find("\nasync def ", idx + 60)
        body = _BOOT[idx:end]
        self.assertIn("vc_startup_reconcile_participations", body)
        self.assertIn("VC_STARTUP_RECONCILE_SCHEDULED", body)

    def test_present_absent_unknown_semantics(self):
        idx = _VC.find(
            "async def vc_startup_reconcile_participations(")
        end = _VC.find("\nasync def ", idx + 60)
        body = _VC[idx:end]
        # present → coordinator JOINED (no join RPC)
        self.assertIn('await get_vc_coordinator().mark_joined(', body)
        # absent → registry LEFT + coordinator LEFT
        self.assertIn('await vc_registry_update(_cid, state="left")', body)
        self.assertIn('evidence="startup_reconcile:telegram_absent"', body)
        # unknown → preserved (no destructive action)
        self.assertIn("# Preserved joined (weak evidence)", body)

    def test_idempotent_flag(self):
        self.assertIn("def vc_startup_reconcile_done(", _VC)


class TestFixPMMetricsAttribution(unittest.TestCase):
    """FIX-PM: per-account join metrics use the REAL owner account."""

    def test_no_hardcoded_primary_key(self):
        self.assertNotIn('_pa["(primary)"] = _pa.get("(primary)", 0) + 1',
                         _VC)
        self.assertIn('_pm_owner_be = getattr(', _VC)
        self.assertIn('_pa[_pm_key] = _pa.get(_pm_key, 0) + 1', _VC)


# ---------------------------------------------------------------------------
# §C — §13 live-log instrumentation markers
# ---------------------------------------------------------------------------
class TestSection13Markers(unittest.TestCase):
    """§13: the required production-log markers exist at real call sites."""

    def test_startup_reconcile_markers(self):
        for m in ("VC_STARTUP_RECONCILE_BEGIN",
                  "VC_STARTUP_RECONCILE_ACCOUNT",
                  "VC_STARTUP_RECONCILE_CALL",
                  "VC_STARTUP_RECONCILE_COMPLETE"):
            self.assertIn(m, _VC)

    def test_join_markers(self):
        for m in ("VC_JOIN_DUPLICATE_SUPPRESSED",
                  "VC_JOIN_SECOND_ATTEMPT",
                  "VC_JOIN_IDENTITY_REFRESHED"):
            self.assertIn(m, _VC)

    def test_leave_markers(self):
        for m in ("VC_LEAVE_COORDINATOR_SYNC",
                  "VC_LEAVE_REJOIN_READY"):
            self.assertIn(m, _VC)

    def test_process_ownership_markers(self):
        for m in ("VC_PROCESS_OWNERSHIP_ACQUIRED",
                  "VC_PROCESS_OWNERSHIP_REJECTED"):
            self.assertIn(m, _BOOT)
        # the rejected path hard-exits (exactly one live owner)
        idx = _BOOT.find("VC_PROCESS_OWNERSHIP_REJECTED")
        window = _BOOT[idx: idx + 1200]
        self.assertIn("sys.exit(2)", window)

    def test_quarantine_markers(self):
        for m in ("VC_JOIN_QUARANTINE_SET", "VC_JOIN_QUARANTINED ",
                  "VC_JOIN_QUARANTINE_CLEARED"):
            self.assertIn(m, _VC)

    def test_no_secret_logging_of_full_hashes(self):
        # the reconcile verify uses _redact_ah for access hashes
        self.assertIn("_redact_ah(rec.access_hash)", _VC)


# ---------------------------------------------------------------------------
# §D — §12-12: single-instance ownership
# ---------------------------------------------------------------------------
class TestSingleInstanceOwnership(unittest.TestCase):
    """§12-12: the second LIVE process is rejected; the stale lock is
    reclaimed with an explicit marker."""

    def test_pid_guard_rejects_live_owner(self):
        self.assertIn("INSTANCE_ALREADY_RUNNING", _BOOT)
        idx = _BOOT.find("if alive:")
        window = _BOOT[idx: idx + 2000]
        self.assertIn("sys.exit(2)", window)
        self.assertIn("VC_PROCESS_OWNERSHIP_REJECTED", window)

    def test_stale_pid_reclaim_marker(self):
        self.assertIn("Stale PID file found", _BOOT)
        idx = _BOOT.find("Stale PID file found")
        window = _BOOT[idx: idx + 800]
        self.assertIn("VC_PROCESS_OWNERSHIP_ACQUIRED", window)

    def test_pid_reuse_detection(self):
        # PID recycled by an unrelated process → treated as stale
        self.assertIn("V85_PID_REUSE_DETECTED", _BOOT)

    def test_atomic_pid_write(self):
        # two processes starting near-simultaneously can't both win
        self.assertIn("os.replace(_tmp_path, _V85_PID_FILE)", _BOOT)

    def test_pid_guard_precedes_vc_startup(self):
        """FINAL2-2 §3: the cross-process PID guard (main() → sys.exit(2))
        executes BEFORE app.run_polling() — the call that triggers
        _post_init (cluster connect + ALL VC/Telegram init). A second
        process therefore exits before creating any VC/Telegram state,
        which is what makes 'P2 starts while P1 is mid-Join-All /
        mid-reconnect' safe regardless of P1's internal state."""
        idx_guard = _BOOT.find("_V85_PID_FILE = Path(")
        idx_rejected = _BOOT.find("VC_PROCESS_OWNERSHIP_REJECTED")
        idx_run = _BOOT.find("app.run_polling(")
        self.assertGreater(idx_guard, 0)
        self.assertGreater(idx_rejected, idx_guard)
        self.assertGreater(idx_run, 0)
        self.assertGreater(idx_run, idx_rejected,
                           "PID guard must precede app.run_polling (VC init)")
        # the rejection exits the process (no partial startup state)
        # v99.07 (documented correction): window 3000 -> 4200 — the FIX-22
        # canary-marker consumption block + FIX-21 reclaim-noise demotion
        # inside the guard region enlarged it past the old fixed window.
        window = _BOOT[idx_guard: idx_guard + 4600]
        self.assertIn("sys.exit(2)", window)


if __name__ == "__main__":
    unittest.main()
