"""Regression tests for v97.98 forensic upgrade — 24/7 VC reliability.

These tests verify the RUNTIME-PROVEN + SOURCE-PROVEN defect fixed in v97.98:

  BUG-VC-CONTAINER-STALE (HIGH severity, RUNTIME-PROVEN + SOURCE-PROVEN):
    The v97.95 ``record_evidence_absent`` wiring repaired the VCChatCoordinator
    (JOINED→LEFT) on passive-leave detection, but did NOT remove the stale
    call object from the PyTgCalls ``calls`` container. PyTgCalls 2.3.3 fires
    no reliable stream-end / closed-voice-chat callback on passive removal
    (bot kicked / network drop / VC ended), so the stale object (with the OLD
    call_id) persists indefinitely. The next join()'s container pre-check
    (voicechat.py:2996) finds it and emits VC_JOIN_SKIP_ALREADY_CONNECTED,
    skipping the real ``PyTgCalls.join()`` and re-registering the STALE
    call_id — flipping the coordinator LEFT→JOINED again with the bot NOT
    actually in the VC. This defeats the v97.95 fix.

    Runtime evidence (bot-diagnostic (12).log, v97.97, chat 1922822605):
      00:19:14 VC_JOIN_SUCCESS call_id=-8258460204417634036 (→JOINED)
      00:26:41 VC_PARTICIPATION_VERIFY result=absent inspected=90 complete=yes
              → record_evidence_absent → LEFT (container NOT cleaned)
      00:35:54 VC_JOIN_SKIP_ALREADY_CONNECTED — found in calls container
              → VC_PARTICIPATION_REGISTER call_id=-8258460204417634036 (STALE)
              → coordinator LEFT→JOINED again (bot NOT in VC)
      00:42:48 VC_PARTICIPATION_VERIFY result=absent inspected=78 complete=yes
              → VC_STALE_STATE_DETECTED stale_state=joined (proves flip-back)
      [16-minute window where the bot was NOT in the VC but coordinator=JOINED]

    Root cause (SOURCE-PROVEN): the v97.95 detection site updated the
    coordinator + participation registry but NOT the PyTgCalls calls
    container. The container pre-check at join() (voicechat.py:2991-3003)
    trusted the local container object as proof of Telegram participation.

    v97.98 FIX (minimal, targeted, deterministic — two layers):
      FIX-A (PRIMARY): new helper ``_vc_cleanup_stale_backend_call`` removes
        the stale call object from the container at the passive-absence
        detection site (vc_reconcile_participations cls=="LEFT" block), so
        the next join() does not trip on it. Mirrors vc_leave_target's
        backend._leave_target call pattern (voicechat.py:5911).
      FIX-B (SAFETY NET): the join() container pre-check now consults the
        participation registry BEFORE skipping. If registry state=="left"
        (proven absent), the container object is stale → clean it + proceed
        with the real join (do NOT skip). Only a registry state that has
        NOT been proven absent (e.g. "joined"/"unknown") may justify a skip.

    Invariant (v97.98): LOCAL OBJECT EXISTS is NEVER treated as equivalent
    to TELEGRAM PARTICIPATION CONFIRMED. Only POSITIVE_PRESENT evidence (or
    a registry state that has NOT been proven absent) may justify an
    already-connected skip.

These tests use source-text assertions (Telethon/PyTgCalls cannot be loaded
in the validation env) matching the established v97.60-v97.97 test pattern.
"""
from __future__ import annotations

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_MTPROTO_PATH = ROOT / "mediagrab_bot" / "mtproto.py"
_VOICECHAT_PATH = ROOT / "mediagrab_bot" / "voicechat.py"
_PIPELINE_PATH = ROOT / "mediagrab_bot" / "vc_pipeline.py"
_INIT_PATH = ROOT / "mediagrab_bot" / "__init__.py"
_BOOTSTRAP_PATH = ROOT / "mediagrab_bot" / "bootstrap.py"


def _read_source(path: Path) -> str:
    if not path.exists():
        raise unittest.SkipTest(f"{path.name} not found")
    return path.read_text(encoding="utf-8")


# ===========================================================================
# SECTION A — _vc_cleanup_stale_backend_call helper exists + structure
# ===========================================================================
class TestVC98CleanupHelper(unittest.TestCase):
    """v97.98 FIX-A: the _vc_cleanup_stale_backend_call helper must exist
    and mirror vc_leave_target's backend._leave_target call pattern."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_helper_exists(self):
        """_vc_cleanup_stale_backend_call must be defined as an async function."""
        # v99.11 documented correction: the signature gained the
        # reason_code/evidence keyword params (the leave-policy P0 fix);
        # the tracked contract (async helper with chat_id + reason) is
        # unchanged.
        self.assertIn(
            "async def _vc_cleanup_stale_backend_call(chat_id: int, *, reason: str",
            self.src,
            "v97.98 FIX-A: _vc_cleanup_stale_backend_call helper must exist",
        )

    def test_helper_calls_backend_leave_target(self):
        """The helper must call backend._leave_target (mirrors vc_leave_target)."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1, "helper must exist")
        # Window after the def — must contain backend._leave_target call.
        # (helper has a long forensic docstring; use a generous window.)
        # v99.11: 9500 -> 13000 — the v99.11 leave-policy chokepoint
        # docstring + reason-code forwarding grew the helper; contract
        # unchanged (backend._leave_target still the destructive call,
        # now inside the policy factory).
        window = self.src[idx:idx + 13000]  # v99: 6500 -> 9500; v99.11: -> 13000
        self.assertIn("backend._leave_target(chat_id)", window,
                      "v97.98 FIX-A: helper must call backend._leave_target(chat_id)")

    def test_helper_logs_cleanup_markers(self):
        """The helper must log VC_BACKEND_STALE_CALL_CLEANUP_START / CLEANED."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1, "helper must exist")
        # v99.11: 9500 -> 13000 — the v99.11 leave-policy chokepoint
        # docstring + reason-code forwarding grew the helper; contract
        # unchanged (backend._leave_target still the destructive call,
        # now inside the policy factory).
        window = self.src[idx:idx + 13000]  # v99: 6500 -> 9500; v99.11: -> 13000
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_START", window,
                      "v97.98 FIX-A: helper must log CLEANUP_START marker")
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANED", window,
                      "v97.98 FIX-A: helper must log CLEANED marker")
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_FAILED", window,
                      "v97.98 FIX-A: helper must log CLEANUP_FAILED marker")

    def test_helper_checks_container_before_cleanup(self):
        """The helper must check if the chat is in the container before cleaning
        (avoid unnecessary leave_call on an already-absent chat)."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1, "helper must exist")
        # v99.11: 9500 -> 13000 — the v99.11 leave-policy chokepoint
        # docstring + reason-code forwarding grew the helper; contract
        # unchanged (backend._leave_target still the destructive call,
        # now inside the policy factory).
        window = self.src[idx:idx + 13000]  # v99: 6500 -> 9500; v99.11: -> 13000
        self.assertIn("_extract_chat_ids_from_container", window,
                      "v97.98 FIX-A: helper must use _extract_chat_ids_from_container")
        self.assertIn("Already absent from container", window,
                      "v97.98 FIX-A: helper must short-circuit when chat not in container")

    def test_helper_handles_marked_and_raw_ids(self):
        """The helper must check both marked (-100...) and raw (positive) forms."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1, "helper must exist")
        window = self.src[idx:idx + 9500]  # v99: 3500 -> 9500 (FIX-J/FIX-HH blocks grew; contract unchanged)
        self.assertIn("_marked", window, "v97.98 FIX-A: helper must compute marked form")
        self.assertIn("_raw", window, "v97.98 FIX-A: helper must compute raw form")

    def test_helper_is_best_effort(self):
        """The helper must swallow exceptions (best-effort) and return bool."""
        idx = self.src.find("async def _vc_cleanup_stale_backend_call")
        self.assertGreater(idx, -1, "helper must exist")
        # v99.11: 9500 -> 13000 — the v99.11 leave-policy chokepoint
        # docstring + reason-code forwarding grew the helper; contract
        # unchanged (backend._leave_target still the destructive call,
        # now inside the policy factory).
        window = self.src[idx:idx + 13000]  # v99: 6500 -> 9500; v99.11: -> 13000
        # v99.11: 200 -> 260 — the signature spans three lines with the
        # reason_code/evidence params; contract unchanged.
        self.assertIn("-> bool:", self.src[idx:idx + 260],
                      "v97.98 FIX-A: helper must return bool")
        self.assertIn("return False", window,
                      "v97.98 FIX-A: helper must return False on failure")
        self.assertIn("return True", window,
                      "v97.98 FIX-A: helper must return True on success")


# ===========================================================================
# SECTION B — FIX-A: reconcile cls=="LEFT" calls the cleanup helper
# ===========================================================================
class TestVC98FixAReconcileCleanup(unittest.TestCase):
    """v97.98 FIX-A: the passive-absence detection site (cls=="LEFT") must
    call _vc_cleanup_stale_backend_call after record_evidence_absent."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_reconcile_left_calls_cleanup_helper(self):
        """The cls=="LEFT" block must call _vc_cleanup_stale_backend_call."""
        # Find the record_evidence_absent call in vc_reconcile_participations.
        idx = self.src.find("await get_vc_coordinator().record_evidence_absent(")
        self.assertGreater(idx, -1, "v97.95 record_evidence_absent must exist (regression)")
        # Window after the record_evidence_absent — must contain the cleanup call.
        # (the v97.98 FIX-A comment block is ~16 lines before the actual call)
        window = self.src[idx:idx + 2800]
        self.assertIn("_vc_cleanup_stale_backend_call", window,
                      "v97.98 FIX-A: cls==LEFT block must call _vc_cleanup_stale_backend_call")
        self.assertIn('reason="participation_reconcile_absent"', window,
                      "v97.98 FIX-A: cleanup call must use reason=participation_reconcile_absent")

    def test_reconcile_left_cleanup_after_coordinator_update(self):
        """The cleanup must come AFTER the coordinator record_evidence_absent
        (coordinator→LEFT first, then container cleanup)."""
        idx_coord = self.src.find("await get_vc_coordinator().record_evidence_absent(")
        self.assertGreater(idx_coord, -1, "record_evidence_absent must exist")
        idx_cleanup = self.src.find("_vc_cleanup_stale_backend_call", idx_coord)
        self.assertGreater(idx_cleanup, -1, "cleanup must exist after record_evidence_absent")
        # Cleanup index must be AFTER coordinator index.
        self.assertGreater(idx_cleanup, idx_coord,
                          "v97.98 FIX-A: cleanup must come after coordinator record_evidence_absent")

    def test_reconcile_left_cleanup_is_best_effort(self):
        """The cleanup call must be wrapped in try/except (best-effort)."""
        idx_coord = self.src.find("await get_vc_coordinator().record_evidence_absent(")
        self.assertGreater(idx_coord, -1, "record_evidence_absent must exist")
        window = self.src[idx_coord:idx_coord + 2800]
        self.assertIn("try:", window,
                      "v97.98 FIX-A: cleanup call must be in a try block")
        self.assertIn("VC_BACKEND_STALE_CALL_CLEANUP_ERROR", window,
                      "v97.98 FIX-A: cleanup error path must log CLEANUP_ERROR")


# ===========================================================================
# SECTION C — FIX-B: join() container check consults registry before skip
# ===========================================================================
class TestVC98FixBJoinContainerCheck(unittest.TestCase):
    """v97.98 FIX-B: the join() container pre-check must NOT blindly skip
    when the container has an object — it must consult the participation
    registry, and if state=="left" (proven absent), clean + proceed with
    the real join instead of skipping."""

    @classmethod
    def setUpClass(cls):
        cls.src = _read_source(_VOICECHAT_PATH)

    def test_join_container_check_consults_registry(self):
        """v99 §7 (STRENGTHENED FIX-B): the container skip consults the
        TELEGRAM-SIDE participant state (quick recheck) before skipping —
        the registry's state (incl. "left") was only a heuristic proxy;
        the pipeline's recheck is the authoritative consult."""
        pipe = _read_source(_PIPELINE_PATH)
        idx = pipe.find("container_holds_target")
        self.assertGreater(idx, -1, "container re-entry path must exist")
        window = pipe[max(0, idx - 1200):idx + 1800]
        self.assertIn("_verify_participation(", window,
                      "v99: the container skip must run the Telegram-side recheck")
        self.assertIn("idempotent_recheck", window,
                      "v99: the recheck is the idempotent participant verification")

    def test_join_container_stale_detected_marker(self):
        """v99: VC_PIPELINE_STALE_CONTAINER fires when the container holds
        the chat but the Telegram-side recheck does NOT confirm presence
        (STRICTLY stronger than the registry-left heuristic)."""
        pipe = _read_source(_PIPELINE_PATH)
        self.assertIn(
            "VC_PIPELINE_STALE_CONTAINER",
            pipe,
            "v99 §7: VC_PIPELINE_STALE_DETECTED-equivalent marker must exist",
        )

    def test_join_skip_is_conditional_on_registry_state(self):
        """v99 §7: the skip must be gated by the recheck verdict, NOT an
        unconditional return (the container object alone is never proof)."""
        pipe = _read_source(_PIPELINE_PATH)
        idx = pipe.find("if quick == \"present\":")
        self.assertGreater(idx, -1, "the conditional skip must exist")
        # The skip is gated by `if quick == "present":` (the verdict).
        window = pipe[max(0, idx - 500):idx + 300]
        self.assertIn("quick", window,
                      "v99: skip must be gated by the quick-recheck verdict")
        self.assertIn("if quick == \"present\":", window,
                      "v99: skip must be conditional (if quick == present)")

    def test_join_falls_through_when_stale(self):
        """v99 §7: when the container object is stale (recheck not
        present), the pipeline must NOT short-circuit — it cleans the
        local call and falls through to the REAL join."""
        pipe = _read_source(_PIPELINE_PATH)
        idx = pipe.find("VC_PIPELINE_STALE_CONTAINER")
        self.assertGreater(idx, -1, "stale-detection marker must exist")
        # Window after the stale-detection — must contain cleanup + the
        # re-entry into JOINING (fall-through to the real dispatch).
        window = pipe[idx:idx + 1400]
        self.assertIn("_cleanup_local_call(", window,
                      "v99 §7: stale-detection path must clean the local call")
        self.assertIn('sm.transition(VCJoinState.JOINING, "stale_container_cleanup")',
                      window,
                      "v99 §7: stale path must fall through to the real join "
                      "(re-enter JOINING — NOT return True)")

    def test_join_skip_allowed_for_non_left_states(self):
        """v99 §7: the idempotent skip is allowed only on a PRESENT
        Telegram-side recheck (the authoritative non-stale state); the
        'left' registry heuristic is superseded by the recheck verdict."""
        pipe = _read_source(_PIPELINE_PATH)
        idx = pipe.find("if quick == \"present\":")
        self.assertGreater(idx, -1, "the conditional skip must exist")
        # Only the PRESENT branch returns the verified success; every
        # other verdict falls through (stale cleanup + real join).
        window = pipe[idx:idx + 900]
        self.assertIn("idempotent_recheck_present", window,
                      "v99: the skip is the idempotent VERIFIED re-join")


# ===========================================================================
# SECTION D — v97.95/v97.96/v97.97 regression (prior fixes preserved)
# ===========================================================================
class TestVC98RegressionPriorFixes(unittest.TestCase):
    """v97.98 must NOT regress the v97.95 (coordinator), v97.96 (SQLite cascade),
    or v97.97 (lifecycle cleanup) fixes."""

    @classmethod
    def setUpClass(cls):
        cls.vc_src = _read_source(_VOICECHAT_PATH)
        cls.mt_src = _read_source(_MTPROTO_PATH)

    def test_v97_95_record_evidence_absent_preserved(self):
        """v97.95: record_evidence_absent must still be wired at the cls==LEFT site."""
        self.assertIn(
            "await get_vc_coordinator().record_evidence_absent(",
            self.vc_src,
            "v97.95 regression: record_evidence_absent wiring must be preserved",
        )
        self.assertIn(
            "v97.95 BUG-VC-REJOIN-SKIP",
            self.vc_src,
            "v97.95 regression: BUG-VC-REJOIN-SKIP comment must be preserved",
        )

    def test_v97_95_stale_state_detected_marker_preserved(self):
        """v97.95: VC_STALE_STATE_DETECTED marker must still fire at the cls==LEFT site."""
        self.assertIn("VC_STALE_STATE_DETECTED", self.vc_src,
                      "v97.95 regression: VC_STALE_STATE_DETECTED marker must be preserved")

    def test_v97_96_forcibly_cancel_preserved(self):
        """v97.96: _forcibly_cancel_telethon_tasks must still be in mtproto.py."""
        self.assertIn("_forcibly_cancel_telethon_tasks", self.mt_src,
                      "v97.96 regression: _forcibly_cancel_telethon_tasks must be preserved")
        self.assertIn("ACCOUNT_SQLITE_LOCKED_BACKOFF", self.mt_src,
                      "v97.96 regression: ACCOUNT_SQLITE_LOCKED_BACKOFF marker must be preserved")

    def test_v97_97_cleanup_client_async_preserved(self):
        """v97.97: _cleanup_client_async helper must still be in mtproto.py."""
        self.assertIn("_cleanup_client_async", self.mt_src,
                      "v97.97 regression: _cleanup_client_async helper must be preserved")

    def test_v97_95_join_skip_marker_preserved(self):
        """v99: the idempotent re-join skip path is preserved by the
        canonical pipeline's VERIFIED container re-entry (only a PRESENT
        Telegram-side recheck short-circuits — the stronger form of the
        legitimate idempotent guard)."""
        pipe = _read_source(_PIPELINE_PATH)
        self.assertIn("idempotent_recheck", pipe,
                      "v99 must preserve the legitimate verified idempotent "
                      "re-join path")


# ===========================================================================
# SECTION E — version bump
# ===========================================================================
class TestVC98VersionBump(unittest.TestCase):
    """v97.98: version strings must be bumped in __init__.py and bootstrap.py."""

    @classmethod
    def setUpClass(cls):
        cls.init_src = _read_source(_INIT_PATH)
        cls.boot_src = _read_source(_BOOTSTRAP_PATH)

    def test_init_version_is_v97_98(self):
        self.assertIn('__bot_version__ = "v99.11.1"', self.init_src,
                      "v97.98: __init__.py __bot_version__ must be v97.98")

    def test_bootstrap_version_is_v97_98(self):
        self.assertIn("DEPLOYMENT_IDENTITY version={_v9812_pkg_version}", self.boot_src,  # v99: derivation site (v98.12 correction)
                      "v97.98: bootstrap.py DEPLOYMENT_IDENTITY must be v97.98")

    def test_no_v97_97_version_strings_remain(self):
        """The v97.97 version string must NOT remain in the version-declaration
        sites (descriptive comments referencing the v97.97 audit are OK)."""
        # __init__.py must not declare v97.97.
        self.assertNotIn('__bot_version__ = "v97.97"', self.init_src,
                          "v97.98: __init__.py must not declare v97.97")
        # bootstrap.py DEPLOYMENT_IDENTITY must not say v97.97.
        self.assertNotIn("DEPLOYMENT_IDENTITY version=v97.97", self.boot_src,
                          "v97.98: bootstrap.py must not declare v97.97 in DEPLOYMENT_IDENTITY")


if __name__ == "__main__":
    unittest.main()
