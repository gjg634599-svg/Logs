"""v99.11 — THE CRASH-LOOP PROTECTION + DURABLE CHECKPOINT SUITE (P1).

Production pattern (2026-09-21): the process was OOM-SIGKILLed near the
47th transport → systemd Restart=always in 10s → startup auto-resume at
+75s → the run re-climbed to the SAME resource boundary → died again.
v99.10 had NO restart counting; and its terminal_status='stopped' +
COALESCE guard meant a run auto-resumed EXACTLY ONCE EVER (the second
crash left the bot dead-idle — the RC-3 symptom FIX-E was meant to cure).

FIX UNDER TEST:
  * the startup recovery accepts BOTH crash signatures (fresh '' row +
    the durable 'stopped'/bot_restart_interrupted row);
  * backoff: 75s × 2^resume_attempts (capped 900s);
  * admission reduction: VC_MAX_JOINED ceiling × 0.75^attempts
    (floor 0.25) — deliberate, logged, never a leave;
  * tripwire: ≥ VC_CRASH_LOOP_MAX_FAILURES interrupted runs in the
    window → NO auto-resume this boot (high-severity
    VC_JOIN_ALL_CRASH_GUARD; manual /joinallresume stays available);
  * durable checkpoints: pid + resource snapshot + last successful /
    failed target + resume_attempts, serialized under the manager lock.
"""

from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mediagrab_bot import join_all_worker as jaw  # noqa: E402
from mediagrab_bot.join_all_worker import (  # noqa: E402
    CheckpointManager, JoinAllWorkerState, _now_iso,
)

_SRC_VC = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
           / "voicechat.py").read_text(encoding="utf-8")


class _FakeDbLayer:
    def __init__(self, db):
        self._db = db

    async def get_db(self):
        return self._db


class CheckpointHarness(unittest.TestCase):
    """Real SQLite-backed CheckpointManager (aiosqlite, temp DB)."""

    def setUp(self):
        import aiosqlite
        from mediagrab_bot.db_layer import SCHEMA_SQL, _run_migrations
        self._dir = tempfile.mkdtemp(prefix="v9911_ckpt_")
        self._path = os.path.join(self._dir, "ck.db")
        self._sqlite = sqlite3.connect(self._path)
        self._sqlite.executescript(SCHEMA_SQL)
        self._sqlite.commit()
        self._sqlite.close()
        self._loop = asyncio.new_event_loop()
        self.db = self._loop.run_until_complete(aiosqlite.connect(self._path))
        self.db.row_factory = aiosqlite.Row  # same as init_db()
        self._loop.run_until_complete(_run_migrations(self.db))
        self._loop.run_until_complete(self.db.commit())
        self._orig_get = jaw._get_db_layer
        jaw._get_db_layer = lambda: _FakeDbLayer(self.db)
        self.cm = CheckpointManager()

    def tearDown(self):
        jaw._get_db_layer = self._orig_get
        self._loop.run_until_complete(self.db.close())
        self._loop.close()

    def _run(self, coro):
        return self._loop.run_until_complete(coro)


class TestDurableCheckpoint(CheckpointHarness):
    """The checkpoint row carries the v99.11 durability fields."""

    def test_d1_schema_fields_present(self):
        async def cols_async():
            rows = await (await self.db.execute(
                "PRAGMA table_info(vc_join_all_runs)")).fetchall()
            return {r[1] for r in rows}
        cols = self._run(cols_async())
        for c in ("pid", "resume_attempts", "resource_json",
                  "last_successful_target", "last_failed_target",
                  # the mission-required minimum set:
                  "run_id", "total_targets", "processed", "current_index",
                  "state", "started_at", "updated_at"):
            self.assertIn(c, cols, f"checkpoint column {c} missing")

    def test_d2_create_save_load_roundtrip(self):
        run_id = "20990921000000-abcd1234"

        async def run():
            await self.cm.create_run(
                run_id, [{"group_id": 1, "title": "a"},
                         {"group_id": 2, "title": "b"},
                         {"group_id": 3, "title": "c"}])
            await self.cm.save_checkpoint(
                run_id, state=JoinAllWorkerState.JOINING,
                progress={"processed": 2, "joined_confirmed": 1,
                          "failed": 1},
                current_index=2,
                results={1: {"state": "joined_confirmed"},
                         2: {"state": "failed"}},
                resource_snapshot={"rss_mb": 400.0,
                                   "joined_transports": 12},
                last_successful_target="1",
                last_failed_target="2",
            )
            return await self.cm.load_run(run_id)
        row = self._run(run())
        self.assertIsNotNone(row)
        self.assertEqual(row["processed"], 2)
        self.assertEqual(row["current_index"], 2)
        self.assertEqual(row["last_successful_target"], "1")
        self.assertEqual(row["last_failed_target"], "2")
        self.assertGreater(int(row["pid"]), 0)
        res = json.loads(row["resource_json"])
        self.assertEqual(res["rss_mb"], 400.0)
        self.assertEqual(res["joined_transports"], 12)
        self.assertEqual(row["total_targets"], 3)

    def test_d3_coalesce_guards_terminal_and_forensics(self):
        """A mid-run save (terminal='') cannot clobber a terminal status
        (v97.5) — NOR erase the last-successful/failed forensics (v99.11)."""
        run_id = "20990921000001-ffff0000"

        async def run():
            await self.cm.create_run(run_id, [{"group_id": 9}])
            # terminal save with forensics
            await self.cm.save_checkpoint(
                run_id, state=JoinAllWorkerState.COMPLETED,
                terminal_status="completed",
                progress={"processed": 1, "joined_confirmed": 1},
                last_successful_target="9")
            # a LATE mid-run save (the fire-and-forget race shape)
            await self.cm.save_checkpoint(
                run_id, state=JoinAllWorkerState.JOINING,
                terminal_status="", last_successful_target="",
                last_failed_target="")
            return await self.cm.load_run(run_id)
        row = self._run(run())
        self.assertEqual(row["terminal_status"], "completed")
        self.assertEqual(row["last_successful_target"], "9")

    def test_d4_resume_attempts_and_crash_count(self):
        run_id = "20990921000002-crash0001"

        async def run():
            await self.cm.create_run(run_id, [{"group_id": 5}] * 10)
            # the run crashes mid-flight; the next boot marks it
            await self.cm.mark_interrupted(run_id,
                                           reason="bot_restart_interrupted")
            n1 = await self.cm.record_resume_attempt(run_id)
            n2 = await self.cm.record_resume_attempt(run_id)
            recent = await self.cm.count_recent_crash_loops(
                window_seconds=3600)
            # second-granularity timestamps: a ~0s window may or may not
            # include a row written in the same second — tolerate both.
            old = await self.cm.count_recent_crash_loops(
                window_seconds=0.001)
            assert old in (0, 1)
            # backdate the row beyond any window
            await self.db.execute(
                "UPDATE vc_join_all_runs SET updated_at = "
                "datetime('now','-2 hours') WHERE run_id = ?", (run_id,))
            await self.db.commit()
            old2 = await self.cm.count_recent_crash_loops(
                window_seconds=3600)
            return n1, n2, recent, old, old2
        n1, n2, recent, old, old2 = self._run(run())
        self.assertEqual(n1, 1)
        self.assertEqual(n2, 2)
        self.assertEqual(recent, 1)
        self.assertIn(old, (0, 1))
        self.assertEqual(old2, 0,
                         "a backdated crash row falls out of the window")

    def test_d5_concurrent_saves_serialize(self):
        """Two concurrent save_checkpoint coroutines cannot interleave
        their UPDATE/commit pairs (the manager lock)."""
        run_id = "20990921000003-race0000"
        events = []

        async def save(i):
            await self.cm.save_checkpoint(
                run_id, state=JoinAllWorkerState.JOINING,
                progress={"processed": i},
                current_index=i)
            events.append(f"done{i}")

        async def run():
            await self.cm.create_run(run_id, [{"group_id": 1}])
            await asyncio.gather(save(1), save(2), save(3))
            return await self.cm.load_run(run_id)
        row = self._run(run())
        self.assertEqual(len(events), 3)
        self.assertIn(row["processed"], (1, 2, 3))


class TestStartupRecoveryContract(unittest.TestCase):
    """The crash-loop guard logic — source + unit contracts."""

    def test_c1_both_crash_signatures_accepted(self):
        self.assertIn('"bot_restart_interrupted" in _v9911_cr', _SRC_VC)
        self.assertIn("_v9911_is_crash_row", _SRC_VC)

    def test_c2_crash_guard_markers_present(self):
        self.assertIn("VC_JOIN_ALL_CRASH_GUARD", _SRC_VC)
        self.assertIn("CRASH LOOP DETECTED", _SRC_VC)

    def test_c3_backoff_and_admission_reduction(self):
        self.assertIn("_v9911_delay = min(75.0 * (2 ** _v9911_attempts), 900.0)",
                      _SRC_VC)
        self.assertIn("_v9911_factor = max(0.25, 0.75 ** _v9911_attempts)",
                      _SRC_VC)
        self.assertIn("_vc_crash_loop_admission_factor = _v9911_factor",
                      _SRC_VC)

    def test_c4_env_controls(self):
        self.assertIn("VC_CRASH_LOOP_WINDOW_SECONDS", _SRC_VC)
        self.assertIn("VC_CRASH_LOOP_MAX_FAILURES", _SRC_VC)
        # not permanently disabled: manual resume stays available
        self.assertIn("/joinallresume", _SRC_VC)

    def test_c5_tripwire_requires_multiple_failures(self):
        """One crash never disables auto-resume (the default tripwire is
        3 within 1h)."""
        self.assertIn('"VC_CRASH_LOOP_MAX_FAILURES", 3', _SRC_VC)
        self.assertIn('"VC_CRASH_LOOP_WINDOW_SECONDS", 3600', _SRC_VC)

    def test_c6_admission_factor_blocks_above_reduced_ceiling(self):
        """The reduced ceiling actually blocks admission (the factor is
        consulted by the admission check)."""
        import mediagrab_bot.voicechat as vw
        prev = vw._vc_crash_loop_admission_factor
        try:
            vw._vc_crash_loop_admission_factor = 0.5  # ceiling 40 → 20
            vw._vc_resource_state_cache["ts"] = 9999999999.0
            vw._vc_resource_state_cache["data"] = {
                "available": True, "rss_kb": 100 * 1024, "threads": 40,
                "fd_total": 50, "fd_soft": 1024,
                "joined_transports": 20, "active_joins": 0,
                "queued_joins": 0,
            }
            blocked, why = vw._vc_resource_pressure_check(quiet=True)
            self.assertTrue(blocked)
            self.assertIn("crash-loop-reduced", why)
            # below the reduced ceiling → allowed
            vw._vc_resource_state_cache["data"]["joined_transports"] = 5
            ok2, _ = vw._vc_resource_pressure_check(quiet=True)
            self.assertFalse(ok2)
        finally:
            vw._vc_crash_loop_admission_factor = prev
            vw._vc_resource_state_cache["ts"] = 0.0

    def test_c7_resume_preserves_successful_targets(self):
        """The resume path never re-joins successful targets (no
        duplication) and never skips targets (current_index cursor) —
        the checkpoint resume contract."""
        self.assertIn("resume_run_id", _SRC_VC)
        self.assertIn("_is_resumed", _SRC_VC)
        self.assertIn("already_joined", _SRC_VC)


class TestRestartResumeSemantics(unittest.TestCase):
    """process dies → startup recovery → checkpoint loaded → successful
    targets not duplicated → Join-All continues from the cursor."""

    def test_r1_mark_interrupted_only_touches_incomplete_rows(self):
        """mark_interrupted's WHERE guard keeps admin-stopped rows
        intact (their cancel_reason must survive for the next boot's
        user-stop detection)."""
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "join_all_worker.py").read_text(encoding="utf-8")
        self.assertIn(
            "WHERE run_id = ? AND (terminal_status = '' OR terminal_status IS NULL)",
            src)

    def test_r2_load_latest_incomplete_includes_stopped(self):
        """The recovery loader sees crash-marked 'stopped' rows (the
        v99.11 second-crash case) — they are resume candidates."""
        src = (Path(__file__).resolve().parents[1] / "mediagrab_bot"
               / "join_all_worker.py").read_text(encoding="utf-8")
        self.assertIn("OR terminal_status = 'stopped'", src)

    def test_r3_user_stop_never_auto_resumed(self):
        self.assertIn('"admin", "user", "cooperative_stop"', _SRC_VC)


if __name__ == "__main__":
    unittest.main()
