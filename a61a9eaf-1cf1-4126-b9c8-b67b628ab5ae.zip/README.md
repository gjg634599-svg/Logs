# MediaGrab AI Bot

A production-grade, modular Telegram bot with AI-powered media analysis, MTProto userbot capabilities, voice chat integration, and an adaptive conversational AI engine.

## Quick Start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env with your bot token, API keys, and admin IDs

# 3. Run
python -m mediagrab_bot
# OR
python mediagrab_bot/_bot_core.py
```

## Architecture

The project uses an **incremental physical extraction** strategy. Business logic is progressively moved from `_bot_core.py` into dedicated modules. Each extraction moves the actual implementation (not wrappers), updates imports, and preserves 100% behavior.

### Current Module Structure (22 modules)

```
mediagrab_bot/
├── __init__.py          # Package entry — re-exports public API
├── __main__.py          # python -m mediagrab_bot entry point
├── _bot_core.py         # Core implementation (52,241 lines — shrinking)
├── config.py            # Configuration facade
├── database.py          # Database layer facade
├── mtproto.py           # MTProto/Telethon facade
├── voicechat.py         # Voice Chat subsystem facade
├── talkative.py         # Talkative AI facade
├── multimodal.py        # Multimodal AI facade
├── handlers.py          # PTB handler facade
├── ui.py                # UI facade
├── utils.py             # Utility functions facade
├── runtime.py           # Runtime infrastructure facade
│
├── # Physically extracted modules (real implementation):
├── states.py            # User state machine (216 lines)
├── text_utils.py        # md_escape, html_escape (40 lines)
├── ui_keyboards.py      # 68 keyboard builders (1,381 lines)
├── ui_messages.py       # 31 text functions + 46 constants (733 lines)
├── i18n.py              # 7-language UI translations (99 lines)
├── qr_generator.py      # QR code generation with DI (53 lines)
├── backup.py            # Backup export/import with DI (108 lines)
├── link_parser.py       # Telegram link parsing (257 lines)
└── ai_modes.py          # 5 AI analysis modes (279 lines)
```

### Extraction Progress

| Phase | Module | Lines | Status |
|-------|--------|-------|--------|
| 3a | `text_utils.py` | 40 | ✅ Extracted |
| 3b | `states.py` | 216 | ✅ Extracted |
| 3c | `ui_keyboards.py` | 1,381 | ✅ Extracted |
| 3d | `ui_messages.py` | 733 | ✅ Extracted |
| 4a | `i18n.py` | 99 | ✅ Extracted |
| 4b | `qr_generator.py` | 53 | ✅ Extracted |
| 4c | `backup.py` | 108 | ✅ Extracted |
| 4d | `link_parser.py` | 257 | ✅ Extracted |
| 4e | `ai_modes.py` | 279 | ✅ Extracted |
| **Total extracted** | | **4,117** | |

### Dependency Injection

Newly extracted modules use dependency injection for circular-dependency avoidance:

- `qr_generator.py`: receives `unique_path` function via `_set_unique_path()`
- `backup.py`: receives `repo`, `safe_filename`, `config` via `_set_dependencies()`

## Key Features

- **Telegram Bot API** — Full inline UI, commands, callbacks, inline mode
- **MTProto/Telethon** — Userbot for restricted content, self-destruct capture, multi-account cluster
- **Voice Chat** — PyTgCalls integration, VC tour, join-all, watcher, reconcile
- **Talkative AI** — Adaptive conversational engine with provider fallback
- **Multimodal AI** — Voice (Wit.ai STT), vision (Gemini), OCR, video summarization
- **Discovery** — Autonomous group discovery with query learning
- **Runtime Monitoring** — Event-loop lag detection, task dump diagnostics

## Requirements

- Python 3.10+
- ffmpeg (for media processing)
- See `requirements.txt` for Python dependencies
