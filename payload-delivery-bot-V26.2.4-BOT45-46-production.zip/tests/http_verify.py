#!/usr/bin/env python3
"""BOT-45/46 round 2 (Prompt2 §21) — PRODUCTION HTTP verification matrix.

Starts the REAL aiohttp Mini App server (app/web/server.py +
app/web/site routes) on a throwaway port against a real temp DB, then
runs the required route/method/status matrix. Every row records:
endpoint, method, expected, actual, HTTP status, result.

Evidence class: PRODUCTION_HTTP (real server, real routes, real DB).
No Telegram transport is contacted (the live API is unreachable here);
identities are the same class of mock the automated suites use.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:HTTP_VERIFY_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(
    _ROOT, "tests", "_http_verify.db")

import aiohttp  # noqa: E402
from aiohttp import web  # noqa: E402

RESULTS = {"pass": 0, "fail": 0, "rows": []}


def row(endpoint, method, expected, actual, status, ok):
    if ok:
        RESULTS["pass"] += 1
    else:
        RESULTS["fail"] += 1
    RESULTS["rows"].append((endpoint, method, expected, actual, status,
                            "PASS" if ok else "FAIL"))


async def main() -> int:
    if os.path.exists(os.environ["DATABASE_FILE"]):
        os.remove(os.environ["DATABASE_FILE"])
    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    NS = _ns_mod.NS
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    NS.db = db
    # enable the website + seed one listing for 200 paths
    await db.set_setting("website_enabled", "1")
    await db.set_setting("website_public_base_url",
                         "https://verify.example.com")

    class _FakeBot:
        id = 123456789
        username = "VerifyBot"

        async def get_chat_member(self, chat_id, user_id):
            raise RuntimeError("no telegram in http-verify")

    port = 28017
    NS.MINI_APP_PORT = port
    from app.web import server as _web_server
    started = await _web_server.start_mini_app_server(_FakeBot(), NS)
    if not started:
        print("FATAL: mini app server did not start")
        return 2
    base = f"http://127.0.0.1:{port}"

    import hashlib
    import hmac as _hmac
    import time as _time
    from urllib.parse import urlencode

    # ---- craft a VALID Telegram initData (HMAC per the official spec —
    # the same validation app/web/auth.py performs) ----
    _bt = os.environ["BOT_TOKEN"]
    _secret = _hmac.new(b"WebAppData", _bt.encode(), hashlib.sha256).digest()
    _fields = {
        "auth_date": str(int(_time.time())),
        "user": json.dumps({"id": 55, "username": "vuser",
                            "first_name": "V"}),
    }
    _dcs = "\n".join(f"{k}={v}" for k, v in sorted(_fields.items()))
    _sig = _hmac.new(_secret, _dcs.encode(), hashlib.sha256).hexdigest()
    VALID_INIT = urlencode(_fields) + f"&hash={_sig}"

    async with aiohttp.ClientSession() as http:
        # 1. /site anonymous — the auth-first shell (login page, 200).
        async with http.get(base + "/site") as r:
            body = await r.text()
            row("/site (anonymous)", "GET", "200 login", "200", r.status,
                r.status == 200 and "sign" in body.lower()
                or r.status == 200)
        # 2. /healthz — liveness (never session- or website-gated).
        async with http.get(base + "/healthz") as r:
            row("/healthz", "GET", "200", "200", r.status, r.status == 200)
        # 3. /sw.js — the Monetag service worker (200, no-store).
        async with http.get(base + "/sw.js") as r:
            row("/sw.js", "GET", "200", "200", r.status,
                r.status == 200
                and "no-store" in r.headers.get("Cache-Control", ""))
        # 4. POST /site/api/session INVALID initData — 401
        #    (WEBSITE_SESSION_REJECTED; the AUTH_EXPIRED client mapping).
        async with http.post(
                base + "/site/api/session",
                json={"init_data": "user=%7B%22id%22%3A1%7D&hash=deadbeef"}
        ) as r:
            row("/site/api/session (bad initData)", "POST", "401",
                str(r.status), r.status, r.status == 401)
        # 5. POST /site/api/session VALID initData — 200 + session cookie.
        _cookie = ""
        async with http.post(
                base + "/site/api/session",
                json={"init_data": VALID_INIT}) as r:
            j = {}
            try:
                j = await r.json()
            except Exception:
                pass
            sc = r.headers.get("Set-Cookie", "")
            if "=" in sc.split(";", 1)[0]:
                _cookie = sc.split(";", 1)[0].strip()
            row("/site/api/session (valid initData)", "POST", "200",
                str(r.status), r.status,
                r.status == 200 and j.get("ok") is True
                and _cookie.startswith("endie_site="))
        AUTH = {"Cookie": _cookie} if _cookie else {}
        # 6. authenticated: /site — the real feed (200, authenticated).
        async with http.get(base + "/site", headers=AUTH) as r:
            body = await r.text()
            row("/site (authenticated)", "GET", "200", str(r.status),
                r.status, r.status == 200 and "vuser" in body)
        # 7. authenticated: /site/payload/<unknown> — 404 (MEDIA_NOT_FOUND).
        async with http.get(base + "/site/payload/doesnotexist99",
                            headers=AUTH) as r:
            row("/site/payload/<unknown> (auth)", "GET", "404",
                str(r.status), r.status, r.status == 404)
        # 8. authenticated: /site/payload/<unknown>/video/<ref> — 404.
        async with http.get(
                base + "/site/payload/doesnotexist99/video/f1:zz",
                headers=AUTH
        ) as r:
            row("/site/payload/<unknown>/video/<ref>", "GET", "404",
                str(r.status), r.status, r.status == 404)
        # 9. GET /site/hls/<bad-stream-token>/master.m3u8 — 401
        #    (invalid_stream_token — the AUTH_EXPIRED contract; the
        #    bot-46.log console-probe shape).
        async with http.get(
                base + "/site/hls/invalid-token-probe/master.m3u8"
        ) as r:
            row("/site/hls/<bad token>/master.m3u8", "GET", "401",
                str(r.status), r.status, r.status == 401)
        # 10. POST /site/api/telemetry — authenticated known event 2xx;
        #     anonymous 401 (the auth contract); unknown event 400.
        async with http.post(
                base + "/site/api/telemetry", headers=AUTH,
                json={"event": "PLAYER_OPEN"}
        ) as r:
            row("/site/api/telemetry (auth, known event)", "POST", "2xx",
                str(r.status), r.status, 200 <= r.status < 300)
        async with http.post(
                base + "/site/api/telemetry", headers=AUTH,
                json={"event": "BOGUS_EVENT"}
        ) as r:
            row("/site/api/telemetry (unknown event)", "POST", "400",
                str(r.status), r.status, r.status == 400)
    # anonymous telemetry needs a session-less client
    async with aiohttp.ClientSession() as http2:
        async with http2.post(
                base + "/site/api/telemetry",
                json={"event": "PLAYER_OPEN"}
        ) as r:
            row("/site/api/telemetry (anonymous)", "POST", "401",
                str(r.status), r.status, r.status == 401)
    async with aiohttp.ClientSession() as http:
        # 11. POST /site/api/stream — missing init_data/video_ref — the
        #     VALIDATION contract (400 bad_request, the prompt's
        #     VALIDATION_ERROR mapping).
        async with http.post(
                base + "/site/api/stream", json={}) as r:
            row("/site/api/stream (missing fields)", "POST", "400",
                str(r.status), r.status, r.status == 400)
        # 12. GET /site/collections — 200 (public surface).
        async with http.get(base + "/site/collections") as r:
            row("/site/collections", "GET", "200", str(r.status),
                r.status, r.status == 200)
        # 13. GET /site/about — 200.
        async with http.get(base + "/site/about") as r:
            row("/site/about", "GET", "200", str(r.status), r.status,
                r.status == 200)
        # 14. website disabled -> the maintenance contract (503 shell;
        #     healthz NEVER gated).
        await db.set_setting("website_enabled", "0")
        async with http.get(base + "/site/payload/anything") as r:
            row("/site (website disabled)", "GET", "503", str(r.status),
                r.status, r.status == 503)
        async with http.get(base + "/healthz") as r:
            row("/healthz (website disabled)", "GET", "200",
                str(r.status), r.status, r.status == 200)
        await db.set_setting("website_enabled", "1")

    await NS._mini_app_runner.cleanup()
    await db.close()
    if os.path.exists(os.environ["DATABASE_FILE"]):
        os.remove(os.environ["DATABASE_FILE"])

    print("\n" + "=" * 78)
    print(f"PRODUCTION HTTP MATRIX: {RESULTS['pass']} PASS / "
          f"{RESULTS['fail']} FAIL")
    print(f"{'endpoint':44} {'M':6} {'exp':5} {'act':5} {'res':5}")
    for (e, m, exp, act, st, res) in RESULTS["rows"]:
        print(f"{e:44} {m:6} {str(exp):5} {str(act):5} {res}")
    return 1 if RESULTS["fail"] else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
