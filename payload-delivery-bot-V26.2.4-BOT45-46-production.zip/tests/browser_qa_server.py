#!/usr/bin/env python3
"""BOT-45/46 round 2 (Prompt2 §22) — BROWSER QA server.

Starts the REAL website server (aiohttp + app/web/site routes) with a
seeded DB (2 published listings, one with FJ-gated policy), stays UP so
agent-browser can drive it, and prints the signed session cookie for the
authenticated flows. Evidence class: BROWSER_DEMO.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _ROOT)

os.environ.setdefault("BOT_TOKEN", "123456:BROWSER_QA_TOKEN")
os.environ.setdefault("ADMIN_IDS", "8370454312")
os.environ["DATABASE_FILE"] = os.path.join(_ROOT, "tests",
                                           "_browser_qa.db")

STAMP = "2026-09-20T00:00:00+00:00"


async def main() -> int:
    if os.path.exists(os.environ["DATABASE_FILE"]):
        os.remove(os.environ["DATABASE_FILE"])
    from app.presentation.telegram import namespace as _ns_mod
    from app.storage.schema import Database
    NS = _ns_mod.NS
    db = Database(os.environ["DATABASE_FILE"])
    await db.connect()
    await db.init_schema()
    NS.db = db
    await db.set_setting("website_enabled", "1")
    await db.set_setting("website_public_base_url",
                         "http://127.0.0.1:28019")

    CH = -100990011
    # category
    await db.conn.execute(
        "INSERT INTO website_categories(slug, name, sort_order, "
        "age_restricted, created_at, updated_at) VALUES ('bqa', 'BQA', "
        "0, 0, ?, ?)", (STAMP, STAMP))
    # listing 1: OPEN policy, 2 video files
    for n, (mid, opaque, title) in enumerate(
            [(9001, "bqaopen", "Browser QA Open"),
             (9005, "bqafj", "Browser QA FJ")], start=1):
        await db.conn.execute(
            "INSERT INTO indexed_files(channel_id, message_id, file_id, "
            "file_unique_id, media_type, file_name, file_size, "
            "mime_type, upload_date) VALUES (?,?,?,?, 'video', ?, 1000, "
            "'video/mp4', ?)",
            (CH, mid, f"FID{mid}", f"UID{mid}", f"qa{n}.mp4", STAMP))
        cur = await db.conn.execute(
            "SELECT id FROM indexed_files WHERE channel_id=? AND "
            "message_id=?", (CH, mid))
        idx = int((await cur.fetchone())[0])
        policy = "OPEN" if n == 1 else "FORCE_JOIN"
        await db.conn.execute(
            "INSERT INTO payloads(payload, index_id, status, "
            "access_policy, display_name, created_at, updated_at) VALUES "
            "(?,?,'active',?,?,?,?)",
            (f"qa{n}", idx, policy, title, STAMP, STAMP))
        cur = await db.conn.execute(
            "SELECT id FROM payloads WHERE payload=?", (f"qa{n}",))
        pid = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT INTO website_payloads(opaque_id, payload_id, title, "
            "description, tags, position, published, created_at, "
            "updated_at) VALUES (?,?,?,?,?,0,1,?,?)",
            (opaque, pid, title, "browser qa seed", "qa", STAMP, STAMP))
        cur = await db.conn.execute(
            "SELECT id FROM website_payloads WHERE opaque_id=?",
            (opaque,))
        lid = int((await cur.fetchone())[0])
        cur = await db.conn.execute(
            "SELECT id FROM website_categories WHERE slug='bqa'")
        cid = int((await cur.fetchone())[0])
        await db.conn.execute(
            "INSERT INTO website_payload_categories(listing_id, "
            "category_id, position, created_at) VALUES (?,?,0,?)",
            (lid, cid, STAMP))
        # a second file part for listing 1 (Part 2 — Next Part surface)
        if n == 1:
            await db.conn.execute(
                "INSERT INTO indexed_files(channel_id, message_id, "
                "file_id, file_unique_id, media_type, file_name, "
                "file_size, mime_type, upload_date) VALUES (?,?,?,?, "
                "'video', ?, 1000, 'video/mp4', ?)",
                (CH, mid + 1, f"FID{mid + 1}", f"UID{mid + 1}",
                 f"qa{n}part2.mp4", STAMP))
            cur = await db.conn.execute(
                "SELECT id FROM indexed_files WHERE channel_id=? AND "
                "message_id=?", (CH, mid + 1))
            idx2 = int((await cur.fetchone())[0])
            await db.conn.execute(
                "UPDATE payloads SET index_id=? WHERE id=?", (idx2, pid))
            await db.conn.execute(
                "INSERT INTO collections(collection_id, channel_id, "
                "file_count, created_at, created_by) VALUES ('qa1coll', "
                "?, 2, ?, 5500)", (CH, STAMP))
            await db.conn.execute(
                "INSERT INTO collection_items(collection_id, channel_id, "
                "message_id, position) VALUES ('qa1coll', ?, ?, 0), "
                "('qa1coll', ?, ?, 1)",
                (CH, mid, CH, mid + 1))
    # FJ channel for listing 2's gate
    await db.add_force_channel(-100990099, "bqagate")
    await db.set_setting("force_join_enabled", "1")
    await db.set_setting("fj_mode", "fixed_order")
    await db.set_setting("fj_batch_size", "1")
    await db.conn.commit()

    class _FakeBot:
        id = 123456789
        username = "BqaBot"

        async def get_chat_member(self, chat_id, user_id):
            class _M:
                status = "member"
            return _M()

    port = 28019
    NS.MINI_APP_PORT = port
    from app.web import server as _web_server
    started = await _web_server.start_mini_app_server(_FakeBot(), NS)
    if not started:
        print("FATAL: server did not start")
        return 2

    # craft the signed session cookie for the authenticated browser flow
    from app.web.site import pages as _pages
    deps = NS._website_deps_factory()
    codec = _pages._session_codec(deps)
    token = codec.issue_session(5500, username="bqauser",
                                first_name="B")
    print("SESSION_COOKIE_JSON=" + json.dumps({
        "name": "endie_site", "value": token,
        "url": f"http://127.0.0.1:{port}/site"}))
    print("SERVER_UP port=%d" % port, flush=True)
    # keep serving until killed
    while True:
        await asyncio.sleep(3600)


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
