"""B23 / P0-1 — WEBSITE PLAYBACK AUTHORIZATION (the one-rule module).

The authoritative separation the operator decided after bot-23.log:

    Telegram:  Force Join → Telegram Watch Ad → Telegram delivery
    Website:   Force Join → age/access/security → website pre-roll → PLAY

The Telegram payload Watch-Ad gate (reason="watch_ad_required" from the
EXISTING Access Engine — ``app/presentation/telegram/access.py``) is a
TELEGRAM-side delivery requirement. It is NOT a website playback
requirement: the website runs its own INDEPENDENT ad system
(``preroll.py`` / ``video_ads.py`` — /site/api/ads/decision +
/site/api/ads/event), which fires according to its own configuration.

``authorize_website_playback()`` runs the SAME Access Engine verdict every
other surface uses (never a second engine) and then applies the
website-specific interpretation:

  * every denial reason stays ENFORCED — force_join_required,
    referral_required, points_locked, payload_missing, policy_unknown …
  * EXCEPT "watch_ad_required", which is WAIVED for website playback
    (bot-23.log 01:11:15/01:11:26: a real user with Force Join satisfied
    was still denied website streams by the Telegram ad gate). The
    Telegram delivery path continues to enforce it via ``enforce_access``
    — the two systems remain independent.

The waiver is SAFE with respect to Force Join: the engine only ever
produces watch_ad_required AFTER the base policy (including Force Join)
authorized (``_apply_watch_ad_gate`` returns earlier reasons untouched),
so a waived verdict never skips a Force-Join denial.

Every verdict is structured so log lines are unambiguous: the engine
reason is preserved verbatim (``engine_reason``) and the website-level
reason (``reason``) records the waiver explicitly.

V26.2-bot42 (TASK A2): engine EXCEPTIONS are never silently swallowed —
``log_website_engine_failure`` emits an ERROR-level telemetry line with
ONLY safe fields (the exact production 500 was a NameError masked at
DEBUG level, invisible in the bot-42 log). Never logged: BOT_TOKEN,
Telegram authorization headers, initData, stream tokens, session tokens,
cookies, HMAC secrets.

V26.2.3-bot45/46 (TASK A / master prompt §3 — FORCE JOIN, fix repeated
Telegram checks): the FJ AUTH SESSION CACHE. After a live FJ-complete
pass (the six-channel Telegram membership sweep) this chokepoint mints a
SHORT-LIVED authorized playback session (FJ_AUTH_SESSION_TTL=120s,
identity-keyed, fail-closed) and validates it on the following HLS
master/variant/segment requests — instead of re-running the sweep on
every request. See ``FjAuthSessionCache`` below.
"""
from __future__ import annotations

import hashlib
import inspect
import logging
import re
import time
import traceback
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger("payload-bot")

# The ONE engine reason the website playback path waives (constants stay
# owned by app/core/constants.py — duplicated here only as the literal the
# website layer gates on, so this module has zero import cycles).
_WATCH_AD_REQUIRED = "watch_ad_required"

# Safe-field sanitisation for engine-failure telemetry: redact anything
# shaped like a bot token, a long base64/hex blob, or an Authorization
# header value. Engine exceptions are internal programming errors, but
# the discipline is defense-in-depth (nothing secret ever reaches a log).
_SECRET_SHAPES = re.compile(
    r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b"          # <bot_id>:<token>
    r"|[A-Za-z0-9+/_-]{120,}"                    # long opaque blobs
    r"|\b(?:Bearer|Basic)\s+\S+",                # authorization headers
    re.IGNORECASE)


def _sanitize_exc_text(text: str, limit: int = 180) -> str:
    """Redact secret-shaped substrings + bound the length (safe to log)."""
    try:
        out = _SECRET_SHAPES.sub("<redacted>", str(text or ""))
    except Exception:  # noqa: BLE001 — never fail the log line
        out = ""
    return out[:limit]


def _classify_engine_failure(exc: BaseException) -> str:
    """Map the exception's traceback to the DEPENDENCY STAGE that raised.

    Walks the frames (innermost last → outermost) and returns the FIRST
    matching stage from the inside out — the true origin of the failure:
      access_engine / force_join_service / membership_verification /
      policy_lookup / watch_ads_gate / points_gate / db_layer /
      namespace_resolution / another_dependency
    """
    try:
        frames = traceback.extract_tb(exc.__traceback__)
    except Exception:  # noqa: BLE001
        return "another_dependency"
    for fs in reversed(frames):
        f = str(fs.filename or "").replace("\\", "/")
        if f.endswith("app/presentation/telegram/access.py"):
            fn = str(fs.name or "")
            if fn in ("_fj_slice_for", "_fj_verifier_bot"):
                return "force_join_slice"
            if fn == "_apply_watch_ad_gate":
                return "watch_ads_gate"
            return "access_engine"
        if f.endswith("app/core/force_join/service.py"):
            fn = str(fs.name or "")
            if fn in ("check_membership", "is_member"):
                return "membership_verification"
            if fn in ("fj_gate_view", "fj_gate_unjoined"):
                return "fj_gate_unjoined"
            return "force_join_service"
        if f.endswith("app/core/watch_ads/service.py"):
            return "watch_ads_gate"
        if f.endswith("app/core/access/engine.py"):
            return "points_gate"
        if f.endswith("app/presentation/telegram/namespace.py"):
            return "namespace_resolution"
        if "/app/storage/" in f or f.endswith("dbutil.py"):
            return "db_layer"
        if f.endswith("app/web/site/authz.py"):
            return "authz_wrapper"
    return "another_dependency"


def _safe_gate_key(gate_key: Optional[str]) -> str:
    """Safe gate-key telemetry: the prefix + a short digest (the website
    key's listing/file_pk components are public URL parts; the bot-side
    link_arg is a public deep-link argument — but the digest keeps the
    line uniformly bounded regardless of shape)."""
    gk = str(gate_key or "")
    if not gk:
        return "-"
    digest = hashlib.sha256(gk.encode("utf-8")).hexdigest()[:8]
    return f"{gk[:24]}~{digest}"


def log_website_engine_failure(stage: str, exc: BaseException, *,
                               user_id: int = 0, payload_id: Any = None,
                               file_pk: Any = None,
                               gate_key: Optional[str] = None) -> None:
    """TASK A2 — SAFE ERROR-level telemetry for an engine exception.

    ``stage`` is the WEBSITE call surface (stream_issuance / hls_reverify /
    access_api / pack_issue / download_gate). The dependency stage where
    the exception originated is classified from the traceback. Fields:
    user_id, payload_id, file_pk, safe gate-key, exception class, the
    classified failure stage, a sanitized message head. NEVER: tokens,
    initData, session/Authorization material (see _sanitize_exc_text).
    The full traceback stays at DEBUG (local diagnosis; the ERROR line is
    the production signal).
    """
    try:
        logger.error(
            "WEBSITE_ACCESS_ENGINE_ERROR surface=%s failure_stage=%s "
            "user_id=%s payload_id=%s file_pk=%s gate_key=%s "
            "exception=%s detail=%s",
            str(stage or "-")[:32],
            _classify_engine_failure(exc),
            int(user_id or 0),
            (int(payload_id) if payload_id is not None else "-"),
            (int(file_pk) if file_pk is not None else "-"),
            _safe_gate_key(gate_key),
            type(exc).__name__,
            _sanitize_exc_text(exc))
        logger.debug("website engine failure traceback", exc_info=exc)
    except Exception:  # noqa: BLE001 — telemetry must never raise
        pass

# Bounded once-per-(user,payload) waiver log memo: the gateway re-verifies
# EVERY media/segment request, so a waived playback would otherwise emit
# one waiver line per range/segment (log spam). The FIRST waiver for a
# (user, payload) is logged at INFO; repeats within the process are
# silent (bounded FIFO — never a leak).
_WAIVER_LOGGED: dict = {}
_WAIVER_LOG_MAX = 512


def _waiver_log_key(user_id: int, payload_id) -> tuple:
    return (int(user_id or 0), int(payload_id or 0))


def _should_log_waiver(user_id: int, payload_id) -> bool:
    key = _waiver_log_key(user_id, payload_id)
    if key in _WAIVER_LOGGED:
        return False
    _WAIVER_LOGGED[key] = True
    if len(_WAIVER_LOGGED) > _WAIVER_LOG_MAX:
        # FIFO evict the oldest inserts (dicts preserve insertion order).
        for k in list(_WAIVER_LOGGED)[:-_WAIVER_LOG_MAX]:
            _WAIVER_LOGGED.pop(k, None)
    return True


# ---------------------------------------------------------------------------
# BOT-45/46 (master prompt §3 — FORCE JOIN: fix repeated Telegram checks):
# the FJ AUTH SESSION CACHE — the short-lived authorized playback session.
#
# Root cause (bot-44.log): EVERY website HLS request (master / variant /
# segment) ran authorize_website_playback → Access Engine → fj_gate_view's
# complete fast-path → SIX live get_chat_member Telegram calls — repeated
# for EVERY segment of EVERY playback. The correct §3 flow is: PLAY →
# FJ_PLAY_GATE → membership verification → FJ_COMPLETE → SHORT-LIVED
# AUTHORIZED PLAYBACK SESSION → HLS authorization (master → variant →
# segments) VALIDATES that session instead of re-sweeping the six
# channels per request.
#
# The cache lives HERE — the one chokepoint every website surface (stream
# issuance, HLS master/variant/segment, the access API, pack issue, the
# download gate) already flows through — so no caller changes:
#
#   * IDENTITY-KEYED sessions: key = (user_id, scope, requirement
#     identity). The scope embeds the canonical payload_id AND the
#     per-gate website key ("w|{listing}|{file_pk}" / "w|{listing}"), so
#     the V26.2 per-gate progressive-batching semantics stay exact: a
#     pass for gate A NEVER authorizes gate B (different key → live
#     re-check of B's pinned batch), and session ownership is bound to
#     the user_id. The requirement identity is the canonical FJ service
#     fingerprint (mode|batch_size|sorted channel ids → 12 hex) — ANY
#     Force-Join configuration change re-keys every session.
#   * Expiry is enforced on the monotonic clock (FJ_AUTH_SESSION_TTL,
#     master prompt "short-lived"); the store is bounded (FIFO,
#     FJ_AUTH_SESSION_MAX_ENTRIES — the _WAIVER_LOGGED discipline).
#   * ONLY the FJ PASS fast-path is cached: authorized verdicts on
#     Force-Join-gated payloads while Force Join is active (that is the
#     case whose engine call performed the 6-channel sweep). DENIED
#     verdicts are NEVER cached (a user who joins the channels gets an
#     immediate live re-check), and nothing is cached while Force Join
#     is globally inactive (no sweep to avoid — a later enable applies
#     on the very next request). A HIT therefore replays ONLY a
#     verdict the live engine ALREADY produced for the exact (user,
#     payload/gate, requirement-identity) tuple ≤120s ago — never a
#     denial, never an unverified user/payload combination.
#   * FAIL-CLOSED (never fail-open): any identity/cache issue emits
#     FJ_AUTH_SESSION_ISSUE and BYPASSES the cache — the LIVE Access
#     Engine verdict (the sole authorization authority, unchanged in
#     authorize_website_playback below) then decides. A cache error can
#     never manufacture a pass; a failed INVALIDATION clears the WHOLE
#     cache (everyone re-verifies). Anti-Leech, token/session validity,
#     expiry, file/media identity, age rules and the wrong-user guards
#     stay in the callers, untouched.
#   * Invalidation hooks are exported (``fj_auth_session_cache`` /
#     ``invalidate_fj_auth_sessions``) so the FJ verify endpoint
#     (pages.py) can drop sessions the moment a live re-check runs or
#     membership changes.
# ---------------------------------------------------------------------------
FJ_AUTH_SESSION_TTL = 120            # seconds — "short-lived" by contract
FJ_AUTH_SESSION_MAX_ENTRIES = 1024   # bounded store (FIFO eviction)

# Invalidation memory: REVALIDATE attribution ONLY (bounded, TTL'd —
# remembers which (user, scope) recently had a session dropped so the
# next live re-check logs FJ_AUTH_REVALIDATE cause=invalidated).
_FJ_TOMBSTONE_MAX = 256
_FJ_TOMBSTONE_TTL = 60.0

# The service's canonical identity inputs, duplicated as literals exactly
# the way _WATCH_AD_REQUIRED is above (constants stay owned by
# app/core/constants.py / app/core/force_join/service.py — zero import
# cycles for this module).
_FJ_MODES = ("progressive_random", "fixed_order", "show_all")
_FJ_MODE_DEFAULT = "show_all"
_FJ_BATCH_SIZE_DEFAULT = 2
_FJ_SETTING_ENABLED = "force_join_enabled"
_FJ_SETTING_MODE = "fj_mode"
_FJ_SETTING_BATCH = "fj_batch_size"
# Engine policy literals (app/core/constants.py): the OPEN policy never
# runs the Force-Join slice (and admin_exempt short-circuits before
# payload resolution) — neither is cached.
_FJ_POLICY_OPEN = "OPEN"


def _fj_gate_parts(gate_key: Optional[str]) -> tuple:
    """(listing, file_pk) parsed from a WEBSITE gate key — SAFE telemetry
    fields only: the listing opaque + file_pk are public URL parts, and
    the key is derived SERVER-side from the signed stream token /
    listing resolution, never from client input."""
    gk = str(gate_key or "")
    if not gk:
        return ("-", 0)
    parts = gk.split("|")
    listing = (parts[1] if len(parts) > 1 else "") or "-"
    file_pk = 0
    if len(parts) > 2:
        try:
            file_pk = int(parts[2])
        except (TypeError, ValueError):
            file_pk = 0
    return (str(listing)[:24], file_pk)


def _log_fj_session_issue(op: str, exc: BaseException, *,
                          user_id: Any = 0, payload_id: Any = None,
                          gate_key: Optional[str] = None) -> None:
    """FJ_AUTH_SESSION_ISSUE — an internal cache/identity issue (safe
    fields only, see _sanitize_exc_text). The failure MODE is always
    fail-closed: the cache is bypassed and the live engine decides —
    this line follows the module's A2 ERROR-level discipline for
    internal anomalies (an issue at INFO would be lost in production
    exactly the way the bot-42 NameError was)."""
    try:
        listing, file_pk = _fj_gate_parts(gate_key)
        logger.error(
            "FJ_AUTH_SESSION_ISSUE op=%s user_id=%s payload_id=%s "
            "listing=%s file_pk=%s exception=%s detail=%s "
            "(cache bypassed — the live Access Engine verdict decides; "
            "fail-closed, never fail-open)",
            str(op or "-")[:32], int(user_id or 0),
            (int(payload_id) if payload_id is not None else "-"),
            listing, (int(file_pk) if file_pk else "-"),
            type(exc).__name__, _sanitize_exc_text(exc))
    except Exception:  # noqa: BLE001 — telemetry must never raise
        pass


@dataclass
class _FjAuthSessionEntry:
    """One short-lived authorized playback session (in-memory only)."""
    user_id: int
    payload_id: Optional[int]
    gate_key: str
    scope: str
    requirement_identity: str
    reason: str
    engine_reason: str
    waived_reason: Optional[str]
    result: Any
    created_monotonic: float
    expires_monotonic: float


class FjAuthSessionCache:
    """BOT-45 §3: the short-lived, identity-keyed FJ authorization session
    cache (module singleton ``fj_auth_session_cache`` below).

    Fail-closed by construction: a lookup never fabricates a verdict —
    a HIT only replays a verdict the live Access Engine ALREADY produced
    for the exact (user_id, payload/gate scope, requirement-identity)
    tuple within the TTL window; every other outcome falls back to the
    live engine. Methods never raise (internal errors are logged as
    FJ_AUTH_SESSION_ISSUE and degrade to a miss).
    """

    def __init__(self, *, ttl: float = FJ_AUTH_SESSION_TTL,
                 max_entries: int = FJ_AUTH_SESSION_MAX_ENTRIES) -> None:
        self._ttl = float(ttl)
        self._max_entries = max(int(max_entries), 1)
        self._entries: dict = {}      # key → _FjAuthSessionEntry (FIFO)
        self._tombstones: dict = {}   # (user_id, scope) → (ts, cause)
        self._issues = 0

    @property
    def ttl(self) -> float:
        return self._ttl

    # ---- key derivation ---------------------------------------------
    @staticmethod
    def scope_for(payload_id: Any, gate_key: Optional[str]) -> str:
        """The payload/listing scope component of the key. Embeds BOTH the
        canonical payload_id AND the website gate key: the V26.2 per-gate
        progressive-batching contract (bot-41 §16-§24) means gate A's
        pinned batch ≠ gate B's — a session for one gate must never
        authorize another (per-gate semantics preserved exactly)."""
        try:
            pid = int(payload_id) if payload_id is not None else None
        except (TypeError, ValueError):
            pid = None
        scope = "p|%s" % (pid if pid is not None else "-")
        gk = str(gate_key or "")
        if gk:
            scope += "|g|%s" % gk[:96]
        return scope

    @staticmethod
    def key_for(user_id: Any, scope: str,
                requirement_identity: str) -> tuple:
        return (int(user_id or 0), str(scope),
                str(requirement_identity))

    # ---- lookup -------------------------------------------------------
    def lookup(self, user_id: Any, scope: str,
               requirement_identity: str) -> tuple:
        """-> (entry, prior_state, prior_age_s).

        prior_state: "active" (a valid session — entry returned),
        "expired" (a session existed and its TTL elapsed → the caller
        performs a live re-check), "invalidated" (a session was dropped
        by an explicit invalidation → live re-check), "none" (first
        check) or "issue" (internal error — fail-closed: never a pass).
        Never raises."""
        try:
            key = self.key_for(user_id, scope, requirement_identity)
            now = time.monotonic()
            entry = self._entries.get(key)
            if entry is not None:
                age = max(0.0, now - entry.created_monotonic)
                if now < entry.expires_monotonic:
                    return entry, "active", age
                self._entries.pop(key, None)   # expired → live re-check
                return None, "expired", age
            ts_key = (int(user_id or 0), str(scope))
            tomb = self._tombstones.get(ts_key)
            if tomb is not None:
                self._tombstones.pop(ts_key, None)
                ts, _cause = tomb
                if (now - ts) <= _FJ_TOMBSTONE_TTL:
                    return None, "invalidated", max(0.0, now - ts)
            return None, "none", None
        except Exception as exc:  # noqa: BLE001 — fail-closed, never raise
            self._issues += 1
            try:
                _log_fj_session_issue("lookup", exc, user_id=user_id)
            except Exception:  # noqa: BLE001
                pass
            return None, "issue", None

    # ---- store ----------------------------------------------------------
    def store(self, *, user_id: Any, payload_id: Any = None,
              gate_key: Optional[str] = None, scope: str = "",
              requirement_identity: str = "",
              reason: str = "", engine_reason: str = "",
              waived_reason: Optional[str] = None,
              result: Any = None) -> Optional[_FjAuthSessionEntry]:
        """Store ONE authorized session. Only ever called for AUTHORIZED
        verdicts (the FJ pass fast-path) — denials are never stored."""
        try:
            _scope = str(scope) if scope else \
                self.scope_for(payload_id, gate_key)
            try:
                pid = int(payload_id) if payload_id is not None else None
            except (TypeError, ValueError):
                pid = None
            now = time.monotonic()
            entry = _FjAuthSessionEntry(
                user_id=int(user_id or 0), payload_id=pid,
                gate_key=str(gate_key or "")[:96], scope=_scope,
                requirement_identity=str(requirement_identity),
                reason=str(reason or ""),
                engine_reason=str(engine_reason or ""),
                waived_reason=waived_reason, result=result,
                created_monotonic=now,
                expires_monotonic=now + self._ttl)
            key = self.key_for(user_id, _scope, requirement_identity)
            self._entries.pop(key, None)
            self._entries[key] = entry
            while len(self._entries) > self._max_entries:
                # FIFO evict the oldest inserts (dicts preserve order).
                oldest = next(iter(self._entries))
                self._entries.pop(oldest, None)
            return entry
        except Exception as exc:  # noqa: BLE001 — fail-closed, never raise
            self._issues += 1
            try:
                _log_fj_session_issue("store", exc, user_id=user_id,
                                      payload_id=payload_id,
                                      gate_key=gate_key)
            except Exception:  # noqa: BLE001
                pass
            return None

    # ---- invalidation ---------------------------------------------------
    def invalidate(self, user_id: Any = None, payload_id: Any = None,
                   gate_key: Optional[str] = None,
                   cause: str = "explicit") -> int:
        """Drop the sessions matching the filters (all params None → all
        sessions). Emits FJ_AUTH_INVALIDATE and plants short-lived
        tombstones so the next lookup for a dropped (user, scope) logs
        FJ_AUTH_REVALIDATE cause=invalidated. FAIL-CLOSED: on an internal
        error the WHOLE cache is cleared (a stale pass must never survive
        a failed invalidation). Returns the removal count."""
        try:
            try:
                uid = int(user_id) if user_id is not None else None
            except (TypeError, ValueError):
                uid = None
            try:
                pid = int(payload_id) if payload_id is not None else None
            except (TypeError, ValueError):
                pid = None
            gk = str(gate_key or "")[:96] or None
            now = time.monotonic()
            removed = 0
            for key in list(self._entries.keys()):
                entry = self._entries[key]
                if uid is not None and entry.user_id != uid:
                    continue
                if pid is not None and entry.payload_id != pid:
                    continue
                if gk is not None and entry.gate_key != gk:
                    continue
                self._entries.pop(key, None)
                self._plant_tombstone(entry.user_id, entry.scope, now)
                removed += 1
            if uid is None and pid is None and gk is None:
                self._tombstones.clear()
            logger.info(
                "FJ_AUTH_INVALIDATE user_id=%s payload_id=%s gate_key=%s "
                "removed=%s cause=%s entries=%s (authorized playback "
                "sessions dropped — the next request live re-verifies)",
                (uid if uid is not None else "-"),
                (pid if pid is not None else "-"),
                (gk or "-"), removed, str(cause or "-")[:32],
                len(self._entries))
            return removed
        except Exception as exc:  # noqa: BLE001 — fail-CLOSED on purpose
            self._issues += 1
            try:
                _log_fj_session_issue("invalidate", exc, user_id=user_id,
                                      payload_id=payload_id,
                                      gate_key=gate_key)
                # Never leave possibly-stale sessions behind a failed
                # invalidation: clear everything (everyone re-verifies).
                self._entries.clear()
                self._tombstones.clear()
            except Exception:  # noqa: BLE001
                pass
            return 0

    def clear(self, cause: str = "explicit") -> int:
        """Drop EVERY session (fail-closed reset)."""
        try:
            count = len(self._entries)
            self._entries.clear()
            self._tombstones.clear()
            logger.info(
                "FJ_AUTH_INVALIDATE user_id=- payload_id=- gate_key=- "
                "removed=%s cause=%s entries=0", count,
                str(cause or "-")[:32])
            return count
        except Exception as exc:  # noqa: BLE001 — never raise
            self._issues += 1
            _log_fj_session_issue("clear", exc)
            return 0

    def _plant_tombstone(self, user_id: int, scope: str,
                         now: float) -> None:
        try:
            self._tombstones[(int(user_id), str(scope))] = \
                (now, "invalidated")
            while len(self._tombstones) > _FJ_TOMBSTONE_MAX:
                oldest = next(iter(self._tombstones))
                self._tombstones.pop(oldest, None)
        except Exception:  # noqa: BLE001
            pass

    def stats(self) -> dict:
        """Safe diagnostics (no keys, no verdict data, no secrets)."""
        try:
            now = time.monotonic()
            live = sum(1 for e in self._entries.values()
                       if now < e.expires_monotonic)
            return {"entries": len(self._entries), "live": live,
                    "ttl_s": self._ttl, "max_entries": self._max_entries,
                    "tombstones": len(self._tombstones),
                    "issues": self._issues}
        except Exception:  # noqa: BLE001 — never raise
            return {"entries": 0, "live": 0, "ttl_s": self._ttl,
                    "max_entries": self._max_entries, "tombstones": 0,
                    "issues": self._issues + 1}


# The module-level singleton every website surface shares — and the one
# the FJ verify endpoint (pages.py) invalidates on a live re-check.
fj_auth_session_cache = FjAuthSessionCache()


def invalidate_fj_auth_sessions(user_id: Any = None, payload_id: Any = None,
                                gate_key: Optional[str] = None,
                                *, cause: str = "explicit") -> int:
    """BOT-45 §3 — the module-level invalidation hook. Drop the
    short-lived authorized playback sessions matching the filters (all
    None → clear all). Call this whenever a live membership re-check runs
    or FJ membership/configuration state changes, so the NEXT HLS request
    re-verifies instead of replaying a stale session. Returns the
    removal count. Fail-closed: an internal error clears the cache."""
    return fj_auth_session_cache.invalidate(
        user_id=user_id, payload_id=payload_id, gate_key=gate_key,
        cause=cause)


# Short alias for external callers that followed the §3 example name
# (``fj_auth_cache_invalidate(user_id=..., payload_id=...)``).
fj_auth_cache_invalidate = invalidate_fj_auth_sessions


async def _fj_auth_cache_context(deps: Any, *, user_id: Any = 0,
                                 payload_id: Any = None,
                                 gate_key: Optional[str] = None) -> Optional[tuple]:
    """(requirement_identity, fj_active) for THIS request — or None on ANY
    issue (the cache is then BYPASSED and the live engine decides:
    fail-closed, never fail-open).

    The identity is the canonical FJ service fingerprint
    (mode|batch_size|sorted channel ids → 12 hex — the SAME value
    fj_gate_view / FJ_COMPLETE log, so the cache telemetry correlates
    with the FJ service lines). It is recomputed LIVE per request (a few
    local SQLite reads — negligible next to the six get_chat_member
    Telegram API calls they replace) so ANY FJ configuration change
    re-keys every session IMMEDIATELY. ``deps.fj_identity`` (when a
    deployment wires one) is preferred; the self-contained db fallback
    keeps this module dependency-free.
    """
    db = getattr(deps, "db", None)
    identity: Optional[str] = None
    # Optional explicit provider (e.g. a deps snapshot that wires
    # fj_identity) — accepted sync OR async, never trusted past shape.
    identity_fn = getattr(deps, "fj_identity", None)
    if callable(identity_fn):
        try:
            out = identity_fn()
            if inspect.isawaitable(out):
                out = await out
            if out:
                identity = str(out)[:64]
        except Exception as exc:  # noqa: BLE001
            _log_fj_session_issue("identity_provider", exc,
                                  user_id=user_id, payload_id=payload_id,
                                  gate_key=gate_key)
            identity = None
    try:
        # Force Join globally active? (deps.fj_active when wired — the
        # SAME setting the engine itself reads; db fallback otherwise.)
        fj_active = False
        active_fn = getattr(deps, "fj_active", None)
        if callable(active_fn):
            out = active_fn()
            if inspect.isawaitable(out):
                out = await out
            fj_active = bool(out)
        elif db is not None:
            fj_active = bool(await db.get_setting_bool(
                _FJ_SETTING_ENABLED, True))
        if identity is not None:
            return (identity, fj_active)
        if db is None:
            # A deps snapshot with no db and no identity provider: the
            # cache is simply unavailable (bypassed — engine decides).
            return None
        mode = await db.get_setting(_FJ_SETTING_MODE, _FJ_MODE_DEFAULT)
        if mode not in _FJ_MODES:
            mode = _FJ_MODE_DEFAULT
        batch_size = int(await db.get_setting_int(
            _FJ_SETTING_BATCH, _FJ_BATCH_SIZE_DEFAULT) or 0)
        if batch_size <= 0:
            batch_size = _FJ_BATCH_SIZE_DEFAULT
        rows = await db.list_force_channels()
        # EXACTLY the service formula (sorted ids, no dedup) so the
        # fingerprint matches force_join_requirement_identity() byte for
        # byte; a malformed row raises → caught below → cache bypassed.
        chan_ids = sorted(int(r["channel_id"]) for r in (rows or []))
        raw = "%s|%d|%s" % (mode, batch_size,
                            ",".join(str(i) for i in chan_ids))
        identity = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]
        return (identity, fj_active)
    except Exception as exc:  # noqa: BLE001 — fail-closed: bypass cache
        _log_fj_session_issue("context", exc, user_id=user_id,
                              payload_id=payload_id, gate_key=gate_key)
        return None


def _fj_store_authorized_session(*, user_id: Any, payload_id: Any,
                                 gate_key: Optional[str], scope: str,
                                 requirement_identity: Optional[str],
                                 fj_active: bool, verifier_present: bool,
                                 reason: str, engine_reason: str,
                                 waived_reason: Optional[str],
                                 result: Any) -> None:
    """Mint the short-lived authorized playback session for a PASS
    verdict — ONLY when the FJ dimension actually gated this request
    (Force Join active + a Force-Join engine policy + the live verifier
    bot present for the engine call: the pass then proves the 6-channel
    live membership sweep ran and PASSED). DENIED verdicts are never
    stored (a user who joins the channels gets an immediate live
    re-check); OPEN-policy / admin passes are not stored (no membership
    sweep happened — nothing to short-circuit, and an FJ enable must
    apply on the very next request); a pass minted without the verifier
    is never stored (the cache must NEVER hold a session for a
    user/payload combination that was not live-verified). Storing is
    best-effort: a failed store only costs the NEXT request a live
    re-check — never a security change."""
    try:
        if requirement_identity is None or not fj_active:
            return
        if not verifier_present:
            return  # never session-cache an un-verifiable pass
        policy = str(getattr(result, "policy", "") or "")
        if policy == _FJ_POLICY_OPEN:
            return
        fj_auth_session_cache.store(
            user_id=user_id, payload_id=payload_id, gate_key=gate_key,
            scope=scope, requirement_identity=requirement_identity,
            reason=reason, engine_reason=engine_reason,
            waived_reason=waived_reason, result=result)
    except Exception as exc:  # noqa: BLE001 — fail-closed (see docstring)
        _log_fj_session_issue("store_wrapper", exc, user_id=user_id,
                              payload_id=payload_id, gate_key=gate_key)


@dataclass
class WebsitePlaybackVerdict:
    """Structured outcome of a website-playback authorization.

    Attributes:
        authorized:   the WEBSITE-level decision (True = may play/stream).
        reason:       the effective website reason. For an engine denial
                      this is the engine reason verbatim; for the waived
                      watch-ad case it is "watch_ad_waived_for_website"
                      (an authorized verdict).
        engine_reason: the RAW Access Engine reason — never rewritten, so
                      operators can always see what the engine itself said.
        waived_reason: the engine reason that was waived for website
                      playback (only ever "watch_ad_required"), or None.
        result:       the original AccessResult (not_joined channel views,
                      referral context, points context … are read from it
                      by the callers — the engine object is authoritative).
    """
    authorized: bool
    reason: str
    engine_reason: str
    waived_reason: Optional[str] = None
    result: Any = None

    @property
    def engine_result(self) -> Any:
        return self.result


async def authorize_website_playback(deps: Any, bot: Any, user_id: int,
                                     *, payload_id: Optional[int] = None,
                                     gate_key: Optional[str] = None
                                     ) -> WebsitePlaybackVerdict:
    """The website playback authorization chokepoint (spec §1.2).

    Accepts the SAME inputs the stream/access/pack/HLS handlers used to
    pass to ``deps.access_engine`` and returns a structured verdict:

      * engine authorized                  → authorized verdict (engine
        reason preserved — e.g. "watch_ad_unlocked" stays informative);
      * engine denied, reason == watch_ad_required → AUTHORIZED for the
        website with waived_reason="watch_ad_required" (the Telegram
        delivery path still enforces the gate — never weakened here);
      * engine denied, any other reason    → denied verdict (reason kept).

    V26.2 (bot-41 §16-§24): ``gate_key`` threads the PER-GATE progressive
    Force-Join batching context into the engine (website keys: the
    canonical (listing, file_pk) pair — or the listing for pack-level
    authorization). With a gate key the engine's Force-Join slice is THIS
    gate's pinned batch (satisfied = the pinned batch is live-verified
    joined — the progressive unlock); without one the legacy
    full-requirement verdict applies unchanged. The gate key is derived
    SERVER-side from the signed stream token / listing resolution — never
    from client input.

    V26.2.3-bot45/46 (master prompt §3): BEFORE the engine runs, the FJ
    AUTH SESSION CACHE is consulted — a live FJ-complete pass (the
    six-channel Telegram membership sweep) mints a short-lived
    authorized playback session (FJ_AUTH_SESSION_TTL, identity-keyed,
    fail-closed; see ``FjAuthSessionCache``) that this chokepoint then
    validates for the following HLS master/variant/segment requests, so
    playback no longer re-sweeps Telegram per segment. ONLY the PASS
    fast-path is cached (denials never are — a user who joins the
    channels gets an immediate live re-check), and any cache issue
    bypasses to the live engine below (never fail-open).

    Engine exceptions propagate to the caller (the handlers map them to
    honest 5xx responses — through ``log_website_engine_failure`` the
    actual exception is now VISIBLE at ERROR level with safe fields).
    """
    # ---- BOT-45/46 (master prompt §3) — FJ AUTH SESSION CACHE: the
    #      short-lived authorized playback session ------------------
    # Checked BEFORE the engine call so ONE live FJ-complete pass (the
    # 6-channel get_chat_member sweep) authorizes the whole playback
    # session: PLAY → FJ_PLAY_GATE → membership verification →
    # FJ_COMPLETE → session minted below → the following HLS master /
    # variant / segment requests VALIDATE the session instead of
    # re-sweeping Telegram. FAIL-CLOSED: any identity/cache issue
    # bypasses the cache and the engine below decides — the cache can
    # never manufacture a pass. The lookup additionally requires the
    # live verifier (bot) to be present: without it the engine's
    # existing fail-closed path runs completely unchanged.
    _fj_identity: Optional[str] = None
    _fj_active = False
    _fj_scope = FjAuthSessionCache.scope_for(payload_id, gate_key)
    try:
        _fj_ctx = await _fj_auth_cache_context(
            deps, user_id=user_id, payload_id=payload_id, gate_key=gate_key)
        if _fj_ctx is not None:
            _fj_identity, _fj_active = _fj_ctx
    except Exception as _fj_exc:  # noqa: BLE001 — the cache NEVER breaks authz
        _log_fj_session_issue("context", _fj_exc, user_id=user_id,
                              payload_id=payload_id, gate_key=gate_key)
        _fj_identity, _fj_active = None, False
    if _fj_identity is not None and bot is not None:
        _fj_listing, _fj_file_pk = _fj_gate_parts(gate_key)
        try:
            _fj_entry, _fj_prior, _fj_age = fj_auth_session_cache.lookup(
                user_id, _fj_scope, _fj_identity)
        except Exception as _fj_exc:  # noqa: BLE001 — fail-closed bypass
            _log_fj_session_issue("lookup", _fj_exc, user_id=user_id,
                                  payload_id=payload_id, gate_key=gate_key)
            _fj_entry, _fj_prior, _fj_age = None, "issue", None
        if _fj_entry is not None:
            # Session ownership (user_id in the key), expiry (monotonic
            # TTL), payload/gate scope and requirement identity were ALL
            # validated by the lookup — replay the live engine's own PASS
            # verdict for exactly this tuple (no Telegram sweep).
            logger.info(
                "FJ_AUTH_CACHE_HIT user_id=%s payload_id=%s listing=%s "
                "file_pk=%s fj_identity=%s session_state=active age_s=%s "
                "ttl_s=%s (authorized playback session validated — no "
                "Telegram membership sweep this request)",
                int(user_id or 0),
                (int(payload_id) if payload_id is not None else "-"),
                _fj_listing, (_fj_file_pk if _fj_file_pk else "-"),
                _fj_identity, int(_fj_age or 0),
                int(fj_auth_session_cache.ttl))
            return WebsitePlaybackVerdict(
                authorized=True, reason=_fj_entry.reason,
                engine_reason=_fj_entry.engine_reason,
                waived_reason=_fj_entry.waived_reason,
                result=_fj_entry.result)
        if _fj_prior == "expired":
            logger.info(
                "FJ_AUTH_REVALIDATE user_id=%s payload_id=%s listing=%s "
                "file_pk=%s fj_identity=%s cause=expired age_s=%s "
                "(session expired — live re-check runs now)",
                int(user_id or 0),
                (int(payload_id) if payload_id is not None else "-"),
                _fj_listing, (_fj_file_pk if _fj_file_pk else "-"),
                _fj_identity, int(_fj_age or 0))
        elif _fj_prior == "invalidated":
            logger.info(
                "FJ_AUTH_REVALIDATE user_id=%s payload_id=%s listing=%s "
                "file_pk=%s fj_identity=%s cause=invalidated age_s=%s "
                "(session invalidated — live re-check runs now)",
                int(user_id or 0),
                (int(payload_id) if payload_id is not None else "-"),
                _fj_listing, (_fj_file_pk if _fj_file_pk else "-"),
                _fj_identity, int(_fj_age or 0))
        else:
            logger.info(
                "FJ_AUTH_CACHE_MISS user_id=%s payload_id=%s listing=%s "
                "file_pk=%s fj_identity=%s reason=%s",
                int(user_id or 0),
                (int(payload_id) if payload_id is not None else "-"),
                _fj_listing, (_fj_file_pk if _fj_file_pk else "-"),
                _fj_identity,
                ("cache_issue" if _fj_prior == "issue"
                 else "no_session"))

    # V26.2-bot42: the legacy ``except TypeError: retry without gate_key``
    # shape is replaced by an explicit signature probe — a GENUINE
    # TypeError raised inside the engine body (e.g. int(None)) used to be
    # retried once and then surface as an opaque engine_error; the probe
    # cannot misclassify, and a real engine TypeError now propagates
    # directly (and is classified by the telemetry).
    engine = getattr(deps, "access_engine", None)
    _accepts_gate_key = False
    try:
        _params = inspect.signature(engine).parameters
        _accepts_gate_key = "gate_key" in _params \
            or any(p.kind == inspect.Parameter.VAR_KEYWORD
                   for p in _params.values())
    except (TypeError, ValueError):
        _accepts_gate_key = False
    try:
        if _accepts_gate_key:
            res = await engine(bot, user_id, payload_id=payload_id,
                               gate_key=gate_key)
        else:
            # A deps snapshot wired to a legacy engine signature (no
            # gate_key) — call unchanged (legacy full-requirement verdict).
            res = await engine(bot, user_id, payload_id=payload_id)
    except TypeError as exc:
        # Signature mismatch on a NON-probed callable (e.g. a bound
        # partial without inspectable params): retry the legacy shape —
        # but only when the TypeError clearly originates from the CALL
        # binding, never for an engine-body TypeError (which propagates).
        if _accepts_gate_key and "gate_key" not in str(exc):
            raise
        try:
            res = await engine(bot, user_id, payload_id=payload_id)
        except TypeError:
            raise
    engine_reason = str(getattr(res, "reason", "denied") or "denied")
    if bool(getattr(res, "authorized", False)):
        # BOT-45/46 §3: the live engine PASSED — mint the short-lived
        # authorized playback session (only when the FJ dimension
        # actually gated this request; denials are NEVER cached).
        _fj_store_authorized_session(
            user_id=user_id, payload_id=payload_id, gate_key=gate_key,
            scope=_fj_scope, requirement_identity=_fj_identity,
            fj_active=_fj_active, verifier_present=bot is not None,
            reason=engine_reason,
            engine_reason=engine_reason, waived_reason=None, result=res)
        return WebsitePlaybackVerdict(
            authorized=True, reason=engine_reason,
            engine_reason=engine_reason, waived_reason=None, result=res)
    if engine_reason == _WATCH_AD_REQUIRED:
        # THE website rule: the Telegram payload Watch-Ad requirement does
        # not gate website playback. Waived honestly + loudly (once per
        # (user, payload) per process — the media gateway re-verifies on
        # EVERY range/segment request and must not spam the log) — the log
        # line is unambiguous about WHICH system decided what.
        if _should_log_waiver(user_id, payload_id):
            logger.info(
                "WEBSITE_PLAYBACK_WATCH_AD_WAIVED user_id=%s payload_id=%s "
                "engine_reason=%s (the Telegram payload Watch-Ad requirement "
                "does not gate website playback — the website pre-roll ad "
                "system fires independently per its own configuration)",
                user_id, payload_id or 0, engine_reason)
        # BOT-45/46 §3: the waiver rides on a BASE-policy PASS (the FJ
        # slice passed BEFORE watch-ads is even evaluated) — mint the
        # authorized playback session for it as well.
        _fj_store_authorized_session(
            user_id=user_id, payload_id=payload_id, gate_key=gate_key,
            scope=_fj_scope, requirement_identity=_fj_identity,
            fj_active=_fj_active, verifier_present=bot is not None,
            reason="watch_ad_waived_for_website",
            engine_reason=engine_reason,
            waived_reason=_WATCH_AD_REQUIRED, result=res)
        return WebsitePlaybackVerdict(
            authorized=True, reason="watch_ad_waived_for_website",
            engine_reason=engine_reason,
            waived_reason=_WATCH_AD_REQUIRED, result=res)
    # BOT-45/46 §3: DENIED verdicts are NEVER cached — a user who joins
    # the channels gets an immediate live re-check on the next request
    # (fail-closed: authorization state incomplete → deny).
    return WebsitePlaybackVerdict(
        authorized=False, reason=engine_reason,
        engine_reason=engine_reason, waived_reason=None, result=res)
