"""Delivery-infrastructure repositories (FILE DELIVERY BOT v34).

Owns the durable state of the trusted relay delivery architecture:

* ``network_delivery_groups`` — the ONE private Delivery Group per Network
  Bot (spec §39-§43): the association + verification state machine
  (DELIVERY_SETUP_REQUIRED → DELIVERY_VERIFYING → DELIVERY_READY →
  DELIVERY_DEGRADED / DELIVERY_UNAVAILABLE).
* ``delivery_jobs`` — durable delivery jobs (spec §53): the
  CREATED → RELAY_CREATING → RELAYED → DELIVERING → DELIVERED →
  DELETE_PENDING → DELETED (+ FAILED / EXPIRED) lifecycle with attempts,
  retry scheduling and reconciliation data.
* ``file_delivery_bot`` — the singleton platform-owned File Delivery Bot
  configuration: identity, ENCRYPTED credential (vault blob — never
  plaintext), health/storage-access state (spec §24-§26).
* ``control_audit_events`` — safe structured audit trail for the Control
  Bot (spec §36): event names + actor ids, NEVER secrets.

Naming note (B23-3 §5.13): this module is DELIVERY INFRASTRUCTURE —
the trusted-relay tables the DeliveryJobEngine / network layer drive.
Do not confuse it with the sibling ``deliveries.py``
(``DeliveriesRepoMixin``), which owns the PAYLOAD-FACING analytics:
view counters, retrieval stats, per-payload delivery records and the
pending-deletion queues. No renames — both keep their historical module
names; this docstring is the disambiguator.

All access is parameterised. No token material is ever stored or logged
in plaintext here (the vault owns encryption; this repo stores the blob).
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Delivery Group statuses (spec §43)
# ---------------------------------------------------------------------------
DG_SETUP_REQUIRED = "DELIVERY_SETUP_REQUIRED"
DG_VERIFYING = "DELIVERY_VERIFYING"
DG_READY = "DELIVERY_READY"
DG_DEGRADED = "DELIVERY_DEGRADED"
DG_UNAVAILABLE = "DELIVERY_UNAVAILABLE"

# ---------------------------------------------------------------------------
# Delivery job states (spec §53)
# ---------------------------------------------------------------------------
JOB_CREATED = "CREATED"
JOB_RELAY_CREATING = "RELAY_CREATING"
JOB_RELAYED = "RELAYED"
JOB_DELIVERING = "DELIVERING"
JOB_DELIVERED = "DELIVERED"
JOB_DELETE_PENDING = "DELETE_PENDING"
JOB_DELETED = "DELETED"
JOB_FAILED = "FAILED"
JOB_EXPIRED = "EXPIRED"
# B17 — direct-delivery handoff: the user has not started the File
# Delivery Bot yet; a deep-link button (t.me/<fdb>?start=dl<token>) was
# sent and the job waits for the user to tap it. NOT delivered, NOT
# failed — an honest intermediate state with its own TTL.
JOB_HANDOFF_PENDING = "HANDOFF_PENDING"

# Terminal-ish states that still need the background sweeper's attention.
JOB_RETRYABLE = (JOB_CREATED, JOB_RELAY_CREATING, JOB_RELAYED,
                 JOB_DELIVERING, JOB_DELETE_PENDING)
# States where a relay message may exist on Telegram but is not yet deleted.
# BOT-45/46 (Task B): a row whose deleted_at is set is SETTLED — its
# deletion is no longer owed. The listing filter (list_delivery_jobs
# relay_open=True) additionally excludes settled rows, so the TTL pass
# only ever sees jobs whose relay deletion is genuinely outstanding
# (the production.log root cause: 2 settled-but-still-listed DELIVERED
# zombie rows were re-deleted idempotently on 170/171 sweeps).
JOB_RELAY_OPEN = (JOB_RELAY_CREATING, JOB_RELAYED, JOB_DELIVERING,
                  JOB_DELIVERED, JOB_DELETE_PENDING)
# B17: delivery modes (delivery_jobs.delivery_mode) — audit trail for HOW
# the file actually reached the user (bot-18.log: the relay copy never
# reached anyone; the mode must be recorded honestly).
DM_NETWORK_RELAY = "network_relay"   # network-bot-owned relay (network bot
                                       # authored BOTH the relay and the user copy)
DM_FDB_DIRECT = "fdb_direct"          # shared File Delivery Bot performed the
                                       # final user-facing send (storage -> user)
DM_HANDOFF = "handoff"                # deep-link start handoff -> then fdb_direct
# V25 FINAL (bot-35.log): the two-stage DELIVERY CHANNEL architecture —
# Stage A: the FDB copies Storage -> Delivery Channel; Stage B: the
# Network Bot copies Delivery Channel -> User. This is the ONLY
# production routing mode; fdb_direct/network_relay/handoff survive as
# legacy audit values on historical rows (never newly selected).
DM_DELIVERY_CHANNEL = "delivery_channel"

# ---------------------------------------------------------------------------
# B17 FINAL VERIFICATION — the canonical Telegram delivery-failure
# taxonomy (the NETWORK_DELIVERY_GROUP_ACCESS_CHECK classifications).
# EVERY Telegram exception on a delivery hop is classified into EXACTLY
# one of these; the classification is recorded with real probe evidence
# (see DeliveryJobEngine.network_delivery_group_access_check).
# ---------------------------------------------------------------------------
DC_RELAY_DELETED = "RELAY_DELETED"
# The message to copy is not accessible to the network bot and deletion
# has NOT been proven — the bot-18.log root cause class (one bot can
# never copy a message authored by a different bot).
DC_RELAY_INACCESSIBLE_TO_NETWORK_BOT = "RELAY_INACCESSIBLE_TO_NETWORK_BOT"
DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT = "GROUP_INACCESSIBLE_TO_NETWORK_BOT"
# B18 (bot-19.log): Mode A's relay-create copyMessage reads FROM the
# Storage master. "Chat not found" on that hop means the NETWORK BOT
# cannot see the STORAGE channel (bot-19.log 03:18:30: group_reachable=
# True + bot_membership=administrator while the copy failed "Chat not
# found" — the group was healthy; the STORAGE chat was the invisible
# one). The old blanket GROUP_INACCESSIBLE classification marked a
# healthy delivery group LOST (DELIVERY_GROUP_CAPABILITY_LOST) and hid
# the real remediation (add the network bot to the Storage channel).
DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT = \
    "STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT"
DC_MESSAGE_ID_INVALID = "MESSAGE_ID_INVALID"
DC_MESSAGE_NOT_COPYABLE = "MESSAGE_NOT_COPYABLE"
DC_BOT_IDENTITY_MISMATCH = "BOT_IDENTITY_MISMATCH"
DC_TELEGRAM_API_RESTRICTION = "TELEGRAM_API_RESTRICTION"
DC_PERMISSION_FAILURE = "PERMISSION_FAILURE"
DC_THREAD_TOPIC_MISMATCH = "THREAD_TOPIC_MISMATCH"
DC_UNKNOWN_TELEGRAM_FAILURE = "UNKNOWN_TELEGRAM_FAILURE"
DELIVERY_FAILURE_CLASSIFICATIONS = (
    DC_RELAY_DELETED,
    DC_RELAY_INACCESSIBLE_TO_NETWORK_BOT,
    DC_GROUP_INACCESSIBLE_TO_NETWORK_BOT,
    DC_STORAGE_MASTER_INACCESSIBLE_TO_NETWORK_BOT,
    DC_MESSAGE_ID_INVALID,
    DC_MESSAGE_NOT_COPYABLE,
    DC_BOT_IDENTITY_MISMATCH,
    DC_TELEGRAM_API_RESTRICTION,
    DC_PERMISSION_FAILURE,
    DC_THREAD_TOPIC_MISMATCH,
    DC_UNKNOWN_TELEGRAM_FAILURE,
)

# ---------------------------------------------------------------------------
# File Delivery Bot singleton states
# ---------------------------------------------------------------------------
FDB_UNCONFIGURED = "UNCONFIGURED"
FDB_READY = "READY"
FDB_DEGRADED = "DEGRADED"
FDB_DISABLED = "DISABLED"
FDB_TOKEN_INVALID = "TOKEN_INVALID"

FDB_WORKER_STOPPED = "stopped"
FDB_WORKER_RUNNING = "running"

# ---------------------------------------------------------------------------
# Network bot management modes (spec §27-§32)
# ---------------------------------------------------------------------------
MGMT_USER_OWNED = "USER_OWNED"
MGMT_PLATFORM_MANAGED = "PLATFORM_MANAGED"
CRED_CONTROL_OWNER = "OWNER"
CRED_CONTROL_PLATFORM = "PLATFORM"


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class DeliveryRepoMixin:
    """Delivery Groups + delivery jobs + File Delivery Bot + audit events."""

    # ==================================================================
    # network_delivery_groups
    # ==================================================================
    async def get_delivery_group_for_bot(self, network_bot_id: int
                                         ) -> Optional[Dict[str, Any]]:
        row = await self.conn.execute_fetchall(
            "SELECT * FROM network_delivery_groups WHERE network_bot_id = ?",
            (int(network_bot_id),))
        return dict(row[0]) if row else None

    async def get_delivery_group_by_chat(self, chat_id: int
                                         ) -> Optional[Dict[str, Any]]:
        row = await self.conn.execute_fetchall(
            "SELECT * FROM network_delivery_groups WHERE "
            "delivery_group_chat_id = ?", (int(chat_id),))
        return dict(row[0]) if row else None

    async def list_delivery_groups(self,
                                   only_ready: bool = False
                                   ) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM network_delivery_groups"
        if only_ready:
            sql += " WHERE status = ?"
            rows = await self.conn.execute_fetchall(sql, (DG_READY,))
        else:
            rows = await self.conn.execute_fetchall(sql)
        return [dict(r) for r in rows]

    async def upsert_delivery_group(self, network_bot_id: int,
                                    owner_user_id: int,
                                    chat_id: int, *,
                                    title: str = "",
                                    status: str = DG_VERIFYING,
                                    checks: Optional[Dict] = None,
                                    last_error: Optional[str] = None,
                                    verified: bool = False) -> Dict[str, Any]:
        """Insert-or-update the delivery group association for ONE bot.

        Exactly ONE group per bot (UNIQUE(network_bot_id)) — replacing a
        group means re-associating the bot (spec §39). The chat must not be
        claimed by a different bot (UNIQUE(delivery_group_chat_id)).
        """
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute("BEGIN IMMEDIATE")
            try:
                existing = await self.conn.execute_fetchall(
                    "SELECT id, network_bot_id FROM network_delivery_groups "
                    "WHERE network_bot_id = ?", (int(network_bot_id),))
                clash = await self.conn.execute_fetchall(
                    "SELECT id, network_bot_id FROM network_delivery_groups "
                    "WHERE delivery_group_chat_id = ? AND network_bot_id != ?",
                    (int(chat_id), int(network_bot_id)))
                if clash:
                    await self.conn.execute("ROLLBACK")
                    return {"ok": False,
                            "reason": "group_already_used",
                            "other_network_bot_id": int(clash[0][1])}
                checks_json = json.dumps(checks) if checks is not None else None
                if existing:
                    await self.conn.execute(
                        "UPDATE network_delivery_groups SET "
                        "owner_user_id = ?, delivery_group_chat_id = ?, "
                        "title = ?, status = ?, checks = ?, last_error = ?, "
                        "verified_at = CASE WHEN ? THEN ? ELSE verified_at END, "
                        "last_checked_at = ?, updated_at = ? WHERE "
                        "network_bot_id = ?",
                        (int(owner_user_id), int(chat_id), title, status,
                         checks_json, last_error,
                         1 if verified else 0, now, now, now,
                         int(network_bot_id)))
                else:
                    await self.conn.execute(
                        "INSERT INTO network_delivery_groups ("
                        "network_bot_id, owner_user_id, "
                        "delivery_group_chat_id, title, status, checks, "
                        "verified_at, last_checked_at, last_error, "
                        "created_at, updated_at) VALUES "
                        "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (int(network_bot_id), int(owner_user_id), int(chat_id),
                         title, status, checks_json,
                         now if verified else None, now, last_error,
                         now, now))
                await self.conn.commit()
            except Exception:
                await self.conn.execute("ROLLBACK")
                raise
        row = await self.get_delivery_group_for_bot(int(network_bot_id))
        out = dict(row or {})
        out["ok"] = True
        return out

    async def update_delivery_group_status(self, network_bot_id: int,
                                           status: str, *,
                                           last_error: Optional[str] = None,
                                           checks: Optional[Dict] = None,
                                           verified: Optional[bool] = None
                                           ) -> None:
        now = _now_iso()
        sets = ["status = ?", "last_checked_at = ?", "updated_at = ?"]
        args: list = [status, now, now]
        if last_error is not None:
            sets.append("last_error = ?")
            args.append(last_error)
        if checks is not None:
            sets.append("checks = ?")
            args.append(json.dumps(checks))
        if verified is True:
            sets.append("verified_at = ?")
            args.append(now)
        args.append(int(network_bot_id))
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE network_delivery_groups SET {', '.join(sets)} "
                "WHERE network_bot_id = ?", tuple(args))
            await self.conn.commit()

    async def delete_delivery_group(self, network_bot_id: int) -> None:
        async with self.write_lock:
            await self.conn.execute(
                "DELETE FROM network_delivery_groups WHERE network_bot_id = ?",
                (int(network_bot_id),))
            await self.conn.commit()

    async def count_delivery_groups(self, ready_only: bool = False) -> int:
        if ready_only:
            rows = await self.conn.execute_fetchall(
                "SELECT COUNT(*) FROM network_delivery_groups "
                "WHERE status = ?", (DG_READY,))
        else:
            rows = await self.conn.execute_fetchall(
                "SELECT COUNT(*) FROM network_delivery_groups")
        return int(rows[0][0]) if rows else 0

    # ==================================================================
    # network_dg_pending_setup — b10 §2/§3 (B10-B2)
    # ------------------------------------------------------------------
    # The DURABLE, DB-backed pending Delivery-Group setup intent (per
    # network_bot_id, visible to BOTH the main app and the worker apps,
    # survives restarts). The wizard arms it; the worker detection hook
    # and /setup read it; the last detected candidate chat_id is kept so
    # Check Again (dg:verify) can re-run the REAL verification BEFORE an
    # association row exists. Rows EXPIRE (older than 24h are pruned on
    # read) and are cleared at DELIVERY_READY.
    # ==================================================================
    DG_PENDING_TTL_HOURS = 24

    async def upsert_pending_delivery_group(self, network_bot_id: int,
                                            owner_user_id: int, *,
                                            chat_id: Optional[int] = None
                                            ) -> None:
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute(
                "INSERT INTO network_dg_pending_setup (network_bot_id, "
                "owner_user_id, chat_id, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(network_bot_id) DO UPDATE SET "
                "owner_user_id = excluded.owner_user_id, "
                "updated_at = excluded.updated_at",
                (int(network_bot_id), int(owner_user_id), chat_id, now, now))
            await self.conn.commit()

    async def get_pending_delivery_group(self, network_bot_id: int
                                         ) -> Optional[Dict[str, Any]]:
        row = await self.conn.execute_fetchall(
            "SELECT * FROM network_dg_pending_setup WHERE network_bot_id = ?",
            (int(network_bot_id),))
        if not row:
            return None
        out = dict(row[0])
        # Expiry: a pending setup older than the TTL is dead — prune it
        # and answer None (the intent never outlives a day).
        try:
            from datetime import datetime, timedelta, timezone
            created = datetime.fromisoformat(str(out.get("created_at")))
            if datetime.now(timezone.utc) - created > timedelta(
                    hours=self.DG_PENDING_TTL_HOURS):
                await self.clear_pending_delivery_group(int(network_bot_id))
                return None
        except Exception:  # noqa: BLE001 — unparsable stamps stay valid
            pass
        return out

    async def update_pending_delivery_group_chat(self, network_bot_id: int,
                                                 chat_id: int) -> None:
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute(
                "UPDATE network_dg_pending_setup SET chat_id = ?, "
                "updated_at = ? WHERE network_bot_id = ?",
                (int(chat_id), now, int(network_bot_id)))
            await self.conn.commit()

    async def clear_pending_delivery_group(self, network_bot_id: int) -> None:
        async with self.write_lock:
            await self.conn.execute(
                "DELETE FROM network_dg_pending_setup "
                "WHERE network_bot_id = ?", (int(network_bot_id),))
            await self.conn.commit()

    # ==================================================================
    # delivery_jobs
    # ==================================================================
    async def insert_delivery_job(self, *, user_id: int, network_bot_id: int,
                                  payload_id: Optional[int],
                                  payload_code: Optional[str],
                                  file_pk: Optional[int],
                                  storage_chat_id: Optional[int],
                                  storage_message_id: Optional[int],
                                  delivery_group_chat_id: Optional[int],
                                  max_attempts: int = 5,
                                  delivery_mode: Optional[str] = None) -> int:
        """B17: ``delivery_mode`` records HOW the file is being routed
        (network_relay / fdb_direct / handoff) — the honest audit trail
        bot-18.log demanded (the relay chain never reached a user, yet
        jobs were marked DELIVERED). Optional for compatibility: legacy
        callers keep the old signature; the mode is also settable later
        via ``update_delivery_job``."""
        now = _now_iso()
        cur = await self.conn.execute(
            "INSERT INTO delivery_jobs (user_id, network_bot_id, payload_id, "
            "payload_code, file_pk, storage_chat_id, storage_message_id, "
            "delivery_group_chat_id, status, attempts, max_attempts, "
            "delivery_mode, created_at, updated_at) VALUES "
            "(?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)",
            (int(user_id), int(network_bot_id), payload_id, payload_code,
             file_pk, storage_chat_id, storage_message_id,
             delivery_group_chat_id, JOB_CREATED, int(max_attempts),
             delivery_mode, now, now))
        await self.conn.commit()
        return int(cur.lastrowid)

    async def get_delivery_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        rows = await self.conn.execute_fetchall(
            "SELECT * FROM delivery_jobs WHERE id = ?", (int(job_id),))
        return dict(rows[0]) if rows else None

    async def get_delivery_job_by_handoff_token(
            self, token: str) -> Optional[Dict[str, Any]]:
        """B17: resolve a pending delivery by its one-time deep-link token.

        Only non-terminal, un-expired HANDOFF_PENDING rows resolve — a used
        or expired token is dead (single-use semantics).
        """
        tok = str(token or "").strip()
        if not tok:
            return None
        rows = await self.conn.execute_fetchall(
            "SELECT * FROM delivery_jobs WHERE handoff_token = ? "
            "AND status = ? ORDER BY id DESC LIMIT 1",
            (tok, JOB_HANDOFF_PENDING))
        return dict(rows[0]) if rows else None

    async def claim_handoff_job(self, job_id: int) -> bool:
        """B17: atomically claim a HANDOFF_PENDING job for completion.

        Single-use enforcement at the DB level: the status transition
        HANDOFF_PENDING → DELIVERING happens under the write lock with a
        conditional UPDATE, so a double-tap (two /start dl<token> updates
        racing) can only ever claim ONCE — the loser sees False and gets
        the honest "link no longer valid" answer.
        """
        async with self.write_lock:
            cur = await self.conn.execute(
                "UPDATE delivery_jobs SET status = ?, updated_at = ? "
                "WHERE id = ? AND status = ?",
                (JOB_DELIVERING, _now_iso(), int(job_id),
                 JOB_HANDOFF_PENDING))
            await self.conn.commit()
            return bool(cur.rowcount)

    async def update_delivery_job(self, job_id: int, **fields: Any) -> None:
        """Update arbitrary job fields (status/relay_message_id/...)."""
        if not fields:
            return
        fields = dict(fields)
        fields["updated_at"] = _now_iso()
        sets = ", ".join(f"{k} = ?" for k in fields)
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE delivery_jobs SET {sets} WHERE id = ?",
                (*fields.values(), int(job_id)))
            await self.conn.commit()

    async def list_delivery_jobs(self, *, status: Optional[str] = None,
                                 due_for_retry: bool = False,
                                 relay_open: bool = False,
                                 channel_cleanup_pending: bool = False,
                                 limit: int = 200
                                 ) -> List[Dict[str, Any]]:
        """List jobs filtered for the background sweeper.

        due_for_retry: retryable states whose next_retry_at has passed
        (or is NULL).
        relay_open: states where a relay message may still exist on
        Telegram (for TTL cleanup + reconciliation, spec §55/§57)
        EXCLUDING rows already settled (deleted_at IS NOT NULL) — a
        DELIVERED row whose deletion is confirmed stays DELIVERED but is
        no longer relay-open, so the TTL pass never re-deletes settled
        messages (BOT-45/46 Task B: the idempotent zombie re-deletes).
        channel_cleanup_pending (V26.x Phase 3): rows whose Delivery
        Channel SOURCE message still exists (the durable cleanup marker
        — typically DELIVERED rows awaiting the FDB source delete, e.g.
        after a crash between the confirmed user delivery and the
        deletion).
        """
        now = _now_iso()
        sql = "SELECT * FROM delivery_jobs"
        conds: List[str] = []
        args: List[Any] = []
        if status is not None:
            conds.append("status = ?")
            args.append(status)
        if due_for_retry:
            ph = ", ".join("?" for _ in JOB_RETRYABLE)
            conds.append(f"status IN ({ph})")
            args.extend(JOB_RETRYABLE)
            conds.append("(next_retry_at IS NULL OR next_retry_at <= ?)")
            args.append(now)
        if relay_open:
            ph = ", ".join("?" for _ in JOB_RELAY_OPEN)
            conds.append(f"status IN ({ph})")
            args.extend(JOB_RELAY_OPEN)
            # BOT-45/46 (Task B): settled rows (deleted_at recorded) are
            # NOT relay-open — only rows whose deletion is still genuinely
            # owed. Without this, a settled DELIVERED row keeps matching
            # the status filter and the sweeper re-deletes it idempotently
            # on EVERY pass (production.log ttl_deleted=2 with zero
            # RELAY_MESSAGE_DELETED lines — "message to delete not found"
            # idempotent re-deletes, 170/171 sweeps).
            conds.append("deleted_at IS NULL")
        if channel_cleanup_pending:
            conds.append("channel_cleanup_pending = 1")
            conds.append("delivery_message_id IS NOT NULL")
        if conds:
            sql += " WHERE " + " AND ".join(conds)
        sql += " ORDER BY id LIMIT ?"
        args.append(int(limit))
        rows = await self.conn.execute_fetchall(sql, tuple(args))
        return [dict(r) for r in rows]

    async def count_delivery_jobs(self, status: Optional[str] = None) -> int:
        if status is not None:
            rows = await self.conn.execute_fetchall(
                "SELECT COUNT(*) FROM delivery_jobs WHERE status = ?",
                (status,))
        else:
            rows = await self.conn.execute_fetchall(
                "SELECT COUNT(*) FROM delivery_jobs")
        return int(rows[0][0]) if rows else 0

    # ==================================================================
    # file_delivery_bot (singleton row id=1)
    # ==================================================================
    async def get_file_delivery_bot(self) -> Optional[Dict[str, Any]]:
        rows = await self.conn.execute_fetchall(
            "SELECT * FROM file_delivery_bot WHERE id = 1")
        return dict(rows[0]) if rows else None

    async def get_file_delivery_bot_credential(self) -> Optional[Dict[str, Any]]:
        rows = await self.conn.execute_fetchall(
            "SELECT encrypted_token, key_version FROM file_delivery_bot "
            "WHERE id = 1")
        return dict(rows[0]) if rows else None

    async def upsert_file_delivery_bot(self, *, username: Optional[str],
                                       telegram_bot_id: Optional[int],
                                       encrypted_token: Optional[str],
                                       key_version: int, status: str,
                                       storage_access: str = "unknown",
                                       worker_state: str = FDB_WORKER_STOPPED,
                                       last_error: Optional[str] = None
                                       ) -> None:
        now = _now_iso()
        async with self.write_lock:
            await self.conn.execute("BEGIN IMMEDIATE")
            try:
                existing = await self.conn.execute_fetchall(
                    "SELECT id FROM file_delivery_bot WHERE id = 1")
                if existing:
                    await self.conn.execute(
                        "UPDATE file_delivery_bot SET username = ?, "
                        "telegram_bot_id = ?, encrypted_token = ?, "
                        "key_version = ?, status = ?, storage_access = ?, "
                        "worker_state = ?, last_error = ?, updated_at = ? "
                        "WHERE id = 1",
                        (username, telegram_bot_id, encrypted_token,
                         int(key_version), status, storage_access,
                         worker_state, last_error, now))
                else:
                    await self.conn.execute(
                        "INSERT INTO file_delivery_bot (id, username, "
                        "telegram_bot_id, encrypted_token, key_version, "
                        "status, storage_access, worker_state, last_error, "
                        "created_at, updated_at) VALUES "
                        "(1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (username, telegram_bot_id, encrypted_token,
                         int(key_version), status, storage_access,
                         worker_state, last_error, now, now))
                await self.conn.commit()
            except Exception:
                await self.conn.execute("ROLLBACK")
                raise

    async def update_file_delivery_bot(self, **fields: Any) -> None:
        if not fields:
            return
        fields = dict(fields)
        fields["updated_at"] = _now_iso()
        sets = ", ".join(f"{k} = ?" for k in fields)
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE file_delivery_bot SET {sets} WHERE id = 1",
                tuple(fields.values()))
            await self.conn.commit()

    # ==================================================================
    # control_audit_events (spec §36 — safe, no secrets)
    # ==================================================================
    async def insert_control_audit_event(self, event: str, *,
                                         actor_user_id: Optional[int] = None,
                                         network_bot_id: Optional[int] = None,
                                         detail: Optional[str] = None) -> None:
        await self.conn.execute(
            "INSERT INTO control_audit_events (event, actor_user_id, "
            "network_bot_id, detail, created_at) VALUES (?, ?, ?, ?, ?)",
            (str(event), actor_user_id, network_bot_id, detail, _now_iso()))
        await self.conn.commit()

    async def list_control_audit_events(self, limit: int = 40
                                        ) -> List[Dict[str, Any]]:
        rows = await self.conn.execute_fetchall(
            "SELECT * FROM control_audit_events ORDER BY id DESC LIMIT ?",
            (int(limit),))
        return [dict(r) for r in rows]
