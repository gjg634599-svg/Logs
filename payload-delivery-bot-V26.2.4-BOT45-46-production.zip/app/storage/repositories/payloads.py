"""payloads, collections and aliases — payloads repository (ARCHITECTURE PHASE).

Verbatim method bodies extracted from the legacy ``Database`` class in
bot.py; SQL, transactions, locking and concurrency behavior unchanged.
Composed into ``app.storage.database.DatabaseBase``.
"""
from __future__ import annotations

import aiosqlite
import logging
import re
from typing import Any, List, Optional, Tuple
from app.core.constants import (
    ACCESS_POLICIES_ALL,
    ACCESS_POLICIES_IMPLEMENTED,
    ACCESS_POLICY_DEFAULT,
    ACCESS_POLICY_FORCE_JOIN,
)
from app.storage.dbutil import now_iso as _now_iso
from app.core.payload.service import sanitize_slug as _sanitize_slug

logger = logging.getLogger("payload-bot")

# BOT-45/46 (Task D, schema v47): the display-name PROVENANCE values.
#   'source'         — derived from the CURRENT Telegram Storage source
#                      filename (NULL is treated identically: legacy rows
#                      keep their current value until an explicit refresh
#                      event — the documented v47 semantics).
#   'admin_override' — explicitly admin-set; PRESERVED verbatim, never
#                      overwritten by a source refresh.
DISPLAY_NAME_ORIGIN_SOURCE = "source"
DISPLAY_NAME_ORIGIN_ADMIN_OVERRIDE = "admin_override"
_DISPLAY_NAME_ORIGINS = frozenset({
    DISPLAY_NAME_ORIGIN_SOURCE, DISPLAY_NAME_ORIGIN_ADMIN_OVERRIDE})


def normalize_display_name_origin(origin: Optional[str]) -> Optional[str]:
    """Normalize a provenance value to the v47 vocabulary.

    Only 'source' and 'admin_override' are stored; anything else (empty,
    unknown, legacy) becomes NULL — which the v47 contract reads as
    'source with the CURRENT value preserved until an explicit refresh'.
    """
    if not origin:
        return None
    val = str(origin).strip().lower()
    return val if val in _DISPLAY_NAME_ORIGINS else None


class PayloadsRepoMixin:
    """payloads, collections and aliases."""

    async def create_payload(
        self,
        payload: str,
        index_id: int,
        status: str = "active",
        password: Optional[str] = None,
        expires_at: Optional[str] = None,
        max_clicks: int = 0,
        delete_after: Optional[int] = None,
        one_time: int = 0,
        access_policy: str = ACCESS_POLICY_DEFAULT,
        display_name: Optional[str] = None,
        display_name_origin: Optional[str] = None,
    ) -> int:
        """Create a payload row.

        Access Engine V1: `access_policy` defaults to FORCE_JOIN (the legacy
        behaviour). The Payload Creation Wizard passes the admin-chosen policy
        here so the payload is production-ready the moment it is created.

        BOTV13: `display_name` is the editable human-readable title. If None,
        it defaults to the slug (so legacy callers behave exactly as before).
        The `payload` column is the IMMUTABLE routing slug.

        BOT-45/46 (Task D, schema v47): `display_name_origin` records the
        PROVENANCE of the display name — 'source' when it was derived from
        the Telegram Storage source filename (auto-payload / wizard
        auto-name), 'admin_override' when an admin explicitly set it, NULL
        for legacy callers (treated as 'source' with the current value
        preserved). The origin gates every later source-derived refresh:
        'admin_override' rows are NEVER overwritten.
        """
        now = _now_iso()
        if not access_policy or access_policy not in ACCESS_POLICIES_ALL:
            access_policy = ACCESS_POLICY_DEFAULT
        elif access_policy not in ACCESS_POLICIES_IMPLEMENTED:
            # Future policy requested but not enforced yet -> safe fallback.
            access_policy = ACCESS_POLICY_FORCE_JOIN
        # BOTV13: display_name defaults to the slug for backward compat.
        display_name_val = display_name if display_name else payload
        # BOT-45/46: provenance is normalized to the v47 vocabulary (unknown
        # values store NULL — never a free-form string).
        origin_val = normalize_display_name_origin(display_name_origin)
        cur = await self.conn.execute(
            """
            INSERT INTO payloads
                (payload, display_name, index_id, status, delete_after, one_time, password,
                 expires_at, max_clicks, current_clicks, access_policy,
                 display_name_origin, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)
            """,
            (payload, display_name_val, index_id, status, delete_after, one_time,
             password, expires_at, max_clicks, access_policy, origin_val, now, now),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def get_payload(self, payload: str) -> Optional[aiosqlite.Row]:
        """Resolve a payload string by its own name OR any of its aliases."""
        payload = payload.lower()
        cur = await self.conn.execute(
            """
            SELECT p.* FROM payloads p
            WHERE p.payload = ?
            UNION ALL
            SELECT p.* FROM payloads p
            JOIN payload_aliases a ON a.payload_id = p.id
            WHERE a.alias = ?
            LIMIT 1
            """,
            (payload, payload),
        )
        return await cur.fetchone()
    async def get_payload_by_id(self, payload_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute("SELECT * FROM payloads WHERE id = ?", (payload_id,))
        return await cur.fetchone()
    async def list_payloads(self, limit: int = 50, offset: int = 0) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM payloads ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)
        )
        return await cur.fetchall()
    async def search_payloads(self, query: str, limit: int = 20) -> List[aiosqlite.Row]:
        """Search payloads by routing slug OR display_name (BOTV13 Phase 1).
        PHASE 5: user input is LIKE-ESCAPED — a literal % or _ in an admin
        search can no longer widen into a full-table match."""
        like = f"%{self._search_escape_like(query.lower())}%"
        cur = await self.conn.execute(
            """SELECT * FROM payloads
               WHERE LOWER(payload) LIKE ? ESCAPE '\\'
                  OR LOWER(COALESCE(display_name, '')) LIKE ? ESCAPE '\\'
               ORDER BY id DESC LIMIT ?""",
            (like, like, limit),
        )
        return await cur.fetchall()
    @staticmethod
    def _search_escape_like(term: str) -> str:
        """Escape SQL LIKE metacharacters so user input can never widen the
        pattern ('100%' must not match everything). Parameterized SQL + ESCAPE.
        """
        return (term or "").replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    @staticmethod
    def _search_tokens(text: str) -> List[str]:
        """Normalized token list for fuzzy matching.

        Case-insensitive (unicode .lower()), whitespace/punctuation tolerant
        (every non-word run becomes a separator), hashtag-aware ('#movie'
        yields the token 'movie' — '#' is a non-word char). Underscores split
        too so 'sonali_bhabhi_0e155111' matches the token 'sonali'.
        """
        s = (text or "").lower()
        s = re.sub(r"[\W_]+", " ", s, flags=re.UNICODE)
        return [t for t in s.split() if t]
    @classmethod
    def _search_norm(cls, text: str) -> str:
        return " ".join(cls._search_tokens(text))
    @classmethod
    def _search_rank(cls, row: aiosqlite.Row, query_norm: str,
                     query_tokens: List[str]) -> int:
        """Rank a candidate row against the normalized query. Higher = better.

        100 exact normalized equality of the combined name fields
         80 exact equality of one field / prefix match of the combined field
         60 raw substring (normalized) of the combined field
         50 ALL query tokens appear somewhere (order-free token match)
         30 at least one token appears
          0 no match (excluded)
        Exact matches therefore always rank above partial/fuzzy matches.
        """
        try:
            payload = row["payload"] or ""
        except (IndexError, KeyError):
            payload = ""
        try:
            dn = row["display_name"] if "display_name" in row.keys() else None
        except (IndexError, KeyError):
            dn = None
        dn = dn or ""
        combined = f"{payload} {dn}".strip().lower()
        combined_norm = cls._search_norm(combined)
        field_norms = (cls._search_norm(payload), cls._search_norm(dn))
        if query_norm and (combined_norm == query_norm
                           or query_norm in field_norms):
            return 100
        if query_norm and (combined_norm.startswith(query_norm)
                           or any(fn.startswith(query_norm) for fn in field_norms
                                  if fn)):
            return 80
        if query_norm and query_norm in combined_norm:
            return 60
        if query_tokens:
            hit = sum(1 for t in query_tokens if t in combined_norm)
            if hit == len(query_tokens):
                return 50
            if hit > 0:
                return 30
        return 0
    async def search_payloads_fuzzy(self, query: str, limit: int = 10,
                                    offset: int = 0
                                    ) -> Tuple[List[aiosqlite.Row], int]:
        """PHASE 7 (Task 3): real fuzzy database search over payload fields.

        Matching strategy (all against the EXISTING payloads table fields —
        `payload` routing slug and `display_name`):
          1. Parameterized SQL LIKE prefilter on the RAW fields (case-folded):
             a token matches when it appears as a substring of either field.
             Multi-token queries require EVERY token to match somewhere
             (AND semantics) so 'movie hindi' finds 'hindi_movie_x' but not
             'movie' alone.
          2. Python-side normalized ranking (see _search_rank): exact first,
             then prefix, then substring, then all-token, then any-token.

        Safety: parameterized SQL only; LIKE metacharacters in user input are
        escaped; empty/whitespace/punctuation-only queries return no results;
        queries are truncated to 120 chars. `offset`/`limit` paginate the
        RANKED result list (deterministic order: rank DESC, then id DESC).

        Returns (rows, total_matches).
        """
        query = (query or "").strip()[:120]
        tokens = self._search_tokens(query)
        if not tokens:
            return [], 0
        if len(tokens) == 1:
            tok = tokens[0]
            pat = f"%{self._search_escape_like(tok)}%"
            sql = (
                "SELECT * FROM payloads WHERE (LOWER(payload) LIKE ? ESCAPE '\\' "
                "OR LOWER(COALESCE(display_name, '')) LIKE ? ESCAPE '\\') "
                "ORDER BY id DESC"
            )
            params: List[Any] = [pat, pat]
        else:
            conds: List[str] = []
            params = []
            for tok in tokens:
                pat = f"%{self._search_escape_like(tok)}%"
                conds.append(
                    "(LOWER(payload) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(display_name, '')) LIKE ? ESCAPE '\\')")
                params.extend([pat, pat])
            sql = ("SELECT * FROM payloads WHERE ("
                   + " AND ".join(conds) + ") ORDER BY id DESC")
        try:
            cur = await self.conn.execute(sql, params)
            rows = await cur.fetchall()
        except Exception as e:  # noqa: BLE001
            logger.error("PAYLOAD_SEARCH_DB_ERROR query_len=%s tokens=%s exc=%s",
                         len(query), len(tokens), e)
            return [], 0
        # Rank the candidates (deterministic).
        query_norm = self._search_norm(query)
        ranked: List[Tuple[int, aiosqlite.Row]] = []
        for r in rows:
            score = self._search_rank(r, query_norm, tokens)
            if score > 0:
                ranked.append((score, r))
        ranked.sort(key=lambda pair: (-pair[0], -int(pair[1]["id"])))
        total = len(ranked)
        offset = max(0, int(offset or 0))
        limit = max(1, int(limit or 10))
        return [r for _s, r in ranked[offset:offset + limit]], total
    async def search_payloads_paged(self, query: str, page: int = 1,
                                    page_size: int = 20
                                    ) -> Tuple[List[aiosqlite.Row], int]:
        """WEBSITE PHASE 2: DB-side paginated payload search for the website
        feed/search — ONE search system beside ``search_payloads_fuzzy``
        (SAME tokenization + escaped-LIKE prefilter helpers; no second
        engine, no second tokenization).

        Deliberate differences vs ``search_payloads_fuzzy`` (documented):
          * pagination + counting happen IN SQL (LIMIT/OFFSET + COUNT) — no
            full-catalog memory loading (the fuzzy method materializes every
            prefiltered row to rank it in Python, which is fine for the
            Telegram search UI but not for a website feed over a large
            catalog);
          * deterministic ordering ``id DESC`` (recency) — identical to the
            fuzzy method's candidate order and to ``list_payloads``;
          * the Telegram search path (``search_payloads_fuzzy`` + its
            Python ranking tiers) is UNCHANGED and stays authoritative for
            the bot's search UX.

        Same safety as the fuzzy method: parameterized SQL only, LIKE
        metacharacters escaped, empty/whitespace/punctuation-only queries
        return no results, query truncated to 120 chars, AND semantics for
        multi-token queries. Page size is BOUNDED (1..100); page >= 1.

        Returns (rows, total_matches).
        """
        page = max(1, int(page or 1))
        page_size = max(1, min(100, int(page_size or 20)))
        offset = (page - 1) * page_size
        query = (query or "").strip()[:120]
        tokens = self._search_tokens(query)
        if not tokens:
            return [], 0
        if len(tokens) == 1:
            pat = f"%{self._search_escape_like(tokens[0])}%"
            cond = ("(LOWER(payload) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(display_name, '')) LIKE ? ESCAPE '\\')")
            params: List[Any] = [pat, pat]
        else:
            conds: List[str] = []
            params = []
            for tok in tokens:
                pat = f"%{self._search_escape_like(tok)}%"
                conds.append(
                    "(LOWER(payload) LIKE ? ESCAPE '\\' "
                    "OR LOWER(COALESCE(display_name, '')) LIKE ? ESCAPE '\\')")
                params.extend([pat, pat])
            cond = "(" + " AND ".join(conds) + ")"
        try:
            cur = await self.conn.execute(
                f"SELECT * FROM payloads WHERE {cond} ORDER BY id DESC "
                "LIMIT ? OFFSET ?",
                [*params, page_size, offset],
            )
            rows = await cur.fetchall()
            cur2 = await self.conn.execute(
                f"SELECT COUNT(*) AS c FROM payloads WHERE {cond}", params)
            row2 = await cur2.fetchone()
            total = int(row2["c"]) if row2 else 0
            return rows, total
        except Exception as e:  # noqa: BLE001
            logger.error("PAYLOAD_SEARCH_DB_ERROR query_len=%s tokens=%s "
                         "kind=paged exc=%s", len(query), len(tokens), e)
            return [], 0
    async def get_payload_file_overview(self,
                                        payload_ids: List[int]
                                        ) -> List[aiosqlite.Row]:
        """WEBSITE PHASE 2: file metadata for a BATCH of single-file payload
        ids in ONE query — avoids the N+1 of per-payload file lookups when
        rendering feed/search cards.

        Returns one row per payload id that references a live indexed file,
        carrying exactly the card/player fields (identity, name, type, size,
        mime, dimensions, thumbnail references). The delivery-grade
        ``file_id`` is deliberately NOT projected: transport references are
        resolved later by the media stack (Phase 1) keyed on
        ``file_unique_id`` — web-layer code never handles a main-file
        ``file_id``. Payloads whose indexed file no longer exists are absent
        from the result (the caller renders the honest 'file unavailable'
        state, never a fabricated card).

        A.6.6 (bot-25): ``channel_id``/``message_id`` of the canonical
        indexed file are now projected TOO (the durable source reference —
        the pack row view and any handle consumer needs the REAL chat, not
        a fabricated 0). Additive projection: existing callers ignore the
        extra columns.
        """
        ids = [int(pid) for pid in (payload_ids or []) if pid is not None]
        if not ids:
            return []
        placeholders = ", ".join("?" for _ in ids)
        cur = await self.conn.execute(
            f"""
            SELECT p.id AS payload_id, i.id AS file_pk,
                   i.file_unique_id, i.file_name, i.media_type, i.file_size,
                   i.mime_type, i.width, i.height,
                   i.thumb_file_id, i.thumb_file_unique_id,
                   i.channel_id, i.message_id
            FROM payloads p
            JOIN indexed_files i ON i.id = p.index_id
            WHERE p.id IN ({placeholders})
            """,
            ids,
        )
        return await cur.fetchall()
    async def list_collections_paged(self, page: int = 1, page_size: int = 20
                                     ) -> Tuple[List[aiosqlite.Row], int]:
        """WEBSITE PHASE 2: DB-side paginated multi-file payload (collection)
        listing for the website feed — deterministic order (created_at DESC,
        id DESC tie-break), BOUNDED page size (1..100), LIMIT/OFFSET + COUNT
        in SQL (no full-catalog memory loading)."""
        page = max(1, int(page or 1))
        page_size = max(1, min(100, int(page_size or 20)))
        offset = (page - 1) * page_size
        cur = await self.conn.execute(
            "SELECT * FROM collections ORDER BY created_at DESC, id DESC "
            "LIMIT ? OFFSET ?",
            (page_size, offset),
        )
        rows = await cur.fetchall()
        cur2 = await self.conn.execute("SELECT COUNT(*) AS c FROM collections")
        row2 = await cur2.fetchone()
        total = int(row2["c"]) if row2 else 0
        return rows, total
    async def count_payloads(self) -> int:
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM payloads")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    # PHASE 5 SQL hardening (defense in depth): every current caller
    # passes a literal constant field name, but the interpolation itself
    # is now guarded by an exhaustive whitelist derived from those call
    # sites — a future caller passing anything else fails loudly instead
    # of silently building unsafe SQL.
    _UPDATABLE_PAYLOAD_FIELDS = frozenset({
        "status", "password", "expires_at", "max_clicks", "delete_after",
        "one_time", "display_name", "forward_blocking", "access_policy",
        "watch_ads_enabled", "watch_ads_ad_mode_override",
        # BOT-13 §46/§48: per-payload website delivery controls.
        "show_get_file", "video_ad_destination",
        # BOT-45/46 (Task D, schema v47): display-name provenance — an admin
        # rename sets 'admin_override' so later source refreshes preserve it.
        "display_name_origin",
    })

    async def get_payload_display_name_origin(
            self, payload_id: int) -> Optional[str]:
        """BOT-45/46 (Task D): read a payload's display-name provenance.

        Returns 'source', 'admin_override' or None (NULL — legacy rows,
        treated as 'source' with the current value preserved).
        """
        try:
            cur = await self.conn.execute(
                "SELECT display_name_origin FROM payloads WHERE id = ?",
                (int(payload_id),))
            row = await cur.fetchone()
            if row is None:
                return None
            val = row["display_name_origin"] if "display_name_origin" in row.keys() \
                else row[0]
            return str(val) if val else None
        except Exception:  # noqa: BLE001 — best-effort read
            logger.debug("get_payload_display_name_origin failed",
                         exc_info=True)
            return None

    async def set_payload_display_name_origin(
            self, payload_id: int, origin: Optional[str]) -> bool:
        """BOT-45/46 (Task D): set a payload's display-name provenance.

        ``origin`` is normalized to the v47 vocabulary ('source' /
        'admin_override'); anything else stores NULL. Returns True when a
        row was updated.
        """
        origin_val = normalize_display_name_origin(origin)
        async with self.write_lock:
            cur = await self.conn.execute(
                "UPDATE payloads SET display_name_origin = ?, updated_at = ? "
                "WHERE id = ?",
                (origin_val, _now_iso(), int(payload_id)),
            )
            await self.conn.commit()
        return bool(cur.rowcount)

    async def refresh_source_derived_display_name(
            self, index_pk: int, new_name: Any, old_name: Any = None
    ) -> Dict[str, List[int]]:
        """BOT-45/46 (Task D): ORIGIN-AWARE propagation of the CURRENT
        Telegram source filename into the derived display layers.

        Called by the payload-creation wizard's live source re-resolve
        (``_live_refresh_source_identity``) after the CURRENT source
        filename was (re)derived. Two layers, ONE transaction:

        1. ``payloads.display_name`` — only payloads pointing at this
           ``index_id`` whose provenance allows a refresh
           (``display_name_origin`` IS NULL or 'source') AND whose current
           value is still a source-derived default (NULL/empty, or equal
           to ``sanitize_slug(old_name)`` / the RAW ``old_name``).
           'admin_override' rows are PRESERVED verbatim — never touched.
           Refreshed rows are stamped ``display_name_origin='source'``.
        2. ``website_payloads.title`` — single-payload listings
           (``payload_id`` set, ``collection_id`` NULL) whose payload is
           origin-eligible (same gate) and whose title still matches the
           OLD file-name-derived default: RAW old filename -> RAW new
           filename, slug old -> ``sanitize_slug(new_name)``. Collection /
           package listings are NEVER touched (admin-curated package
           title). Mirrors the value-guarded propagation semantics of
           ``propagate_renamed_file_defaults`` (media repo) with the
           additional v47 origin gate.

        Returns ``{"payload_ids": [...], "listing_ids": [...]}`` (rows
        actually updated; empty lists = nothing was a source-derived
        default — the admin override everywhere).
        """
        _new = str(new_name or "").strip()
        _old = str(old_name or "").strip()
        if not _new:
            return {"payload_ids": [], "listing_ids": []}
        new_slug = _sanitize_slug(_new)
        old_slug = _sanitize_slug(_old) if _old else None
        now = _now_iso()
        payload_ids: List[int] = []
        listing_ids: List[int] = []
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning(
                        "refresh_source_derived_display_name: "
                        "in_transaction on entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                # 1) payloads.display_name — origin-gated, value-guarded.
                cur = await self.conn.execute(
                    "SELECT id, display_name, display_name_origin FROM "
                    "payloads WHERE index_id = ? ORDER BY id ASC",
                    (int(index_pk),))
                rows = await cur.fetchall()
                dn_updates: List[Tuple[str, int]] = []
                for r in rows:
                    origin = r["display_name_origin"] \
                        if "display_name_origin" in r.keys() else None
                    if origin and str(origin).strip().lower() \
                            != DISPLAY_NAME_ORIGIN_SOURCE:
                        # 'admin_override' (or any future explicit value):
                        # PRESERVED verbatim.
                        continue
                    dn = r["display_name"]
                    is_default = (
                        dn is None or str(dn).strip() == ""
                        or (_old and str(dn) == _old)
                        or (old_slug is not None and str(dn) == old_slug))
                    if not is_default:
                        continue  # a non-default source value — keep verbatim
                    dn_updates.append((new_slug or _new, int(r["id"])))
                payload_ids = [pid for (_, pid) in dn_updates]
                if dn_updates:
                    await self.conn.executemany(
                        "UPDATE payloads SET display_name = ?, "
                        "display_name_origin = ?, updated_at = ? WHERE id = ?",
                        [(dn, DISPLAY_NAME_ORIGIN_SOURCE, now, pid)
                         for (dn, pid) in dn_updates])
                    # BOT-45/46 (master prompt §5 telemetry): the resolved
                    # display name + its provenance (safe fields only).
                    for dn, pid in dn_updates:
                        logger.info(
                            "PAYLOAD_DISPLAY_NAME_RESOLVE file_pk=%s "
                            "payload_id=%s display_name=%r "
                            "display_name_origin=%s (source-derived "
                            "refresh)",
                            int(index_pk), pid, dn,
                            DISPLAY_NAME_ORIGIN_SOURCE)
                # 2) website_payloads.title — single-payload listings whose
                #    payload is origin-eligible (JOIN gate) + value-guarded.
                cur = await self.conn.execute(
                    "SELECT w.id AS wid, w.title AS title, "
                    "p.display_name_origin AS origin FROM website_payloads w "
                    "JOIN payloads p ON p.id = w.payload_id "
                    "WHERE p.index_id = ? AND w.collection_id IS NULL "
                    "ORDER BY w.id ASC",
                    (int(index_pk),))
                rows = await cur.fetchall()
                title_updates: List[Tuple[str, int]] = []
                for r in rows:
                    origin = r["origin"]
                    if origin and str(origin).strip().lower() \
                            != DISPLAY_NAME_ORIGIN_SOURCE:
                        continue  # admin-curated listing title
                    title = r["title"]
                    if title is None or str(title).strip() == "":
                        if new_slug:
                            title_updates.append((new_slug, int(r["wid"])))
                    elif _old and str(title) == _old:
                        title_updates.append((_new, int(r["wid"])))
                    elif old_slug is not None and str(title) == old_slug:
                        if new_slug:
                            title_updates.append((new_slug, int(r["wid"])))
                    # any OTHER value = admin-curated — NEVER touched
                listing_ids = [wid for (_, wid) in title_updates]
                if title_updates:
                    await self.conn.executemany(
                        "UPDATE website_payloads SET title = ?, updated_at = ? "
                        "WHERE id = ?",
                        [(t, now, wid) for (t, wid) in title_updates])
                await self.conn.commit()
            except Exception as e:  # noqa: BLE001 — propagation is best-effort
                try:
                    await self.conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    pass
                logger.error("refresh_source_derived_display_name(%s) "
                             "failed: %s", int(index_pk), e)
                return {"payload_ids": [], "listing_ids": []}
        return {"payload_ids": payload_ids, "listing_ids": listing_ids}

    async def update_payload_field(self, payload_id: int, field: str, value: Any) -> None:
        # field is validated by callers, never user-supplied raw — AND
        # whitelisted here (PHASE 5: never interpolatable regardless of
        # caller).
        # WATCH_AD V5 (concurrency fix): serialized under write_lock — an
        # admin payload change during an in-flight reward transaction can
        # no longer interleave with (or early-commit) it.
        if field not in self._UPDATABLE_PAYLOAD_FIELDS:
            raise ValueError(
                f"update_payload_field: field {field!r} is not whitelisted")
        async with self.write_lock:
            await self.conn.execute(
                f"UPDATE payloads SET {field} = ?, updated_at = ? WHERE id = ?",
                (value, _now_iso(), payload_id),
            )
            await self.conn.commit()
    async def delete_payload(self, payload_id: int) -> None:
        await self.conn.execute("DELETE FROM payloads WHERE id = ?", (payload_id,))
        await self.conn.commit()
    async def increment_clicks(self, payload_id: int) -> None:
        await self.conn.execute(
            "UPDATE payloads SET current_clicks = current_clicks + 1, updated_at = ? WHERE id = ?",
            (_now_iso(), payload_id),
        )
        await self.conn.commit()
    async def create_collection(self, collection_id: str, channel_id: int,
                                 message_ids: List[int], created_by: Optional[int] = None) -> bool:
        """Create a collection with EXPLICIT message_ids stored in order.

        Never infers from a range. Every message_id is stored explicitly in
        collection_items with a position index so delivery is always exact.
        Returns True on success, False if the collection_id already exists.
        """
        now = _now_iso()
        # BOTV13 fix: serialise under the write lock to prevent nested transactions.
        # B23-3 (5.1): the shared DatabaseBase.write_lock property — one
        # consistent lock name across every repository mixin.
        async with self.write_lock:
            try:
                if self.conn.in_transaction:
                    logger.warning("create_collection: in_transaction on entry — safety ROLLBACK.")
                    await self.conn.execute("ROLLBACK")
            except Exception:  # noqa: BLE001
                pass
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                await self.conn.execute(
                    "INSERT INTO collections (collection_id, channel_id, file_count, created_at, created_by) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (collection_id, channel_id, len(message_ids), now, created_by),
                )
                rows = [
                    (collection_id, channel_id, int(msg_id), pos)
                    for pos, msg_id in enumerate(message_ids)
                ]
                await self.conn.executemany(
                    "INSERT INTO collection_items (collection_id, channel_id, message_id, position) "
                    "VALUES (?, ?, ?, ?)",
                    rows,
                )
                await self.conn.commit()
                return True
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("create_collection(%s) failed: %s", collection_id, e)
                return False
    async def get_collection(self, collection_id: str) -> Optional[aiosqlite.Row]:
        """Fetch a collection header by its short link code."""
        cur = await self.conn.execute(
            "SELECT * FROM collections WHERE collection_id = ?", (collection_id,)
        )
        return await cur.fetchone()

    async def collection_add_item(self, collection_id: str, channel_id: int,
                                  message_id: int) -> str:
        """V25 FINAL §15 (Manage Files — Add): append ONE exact
        (channel_id, message_id) member at the END of the collection
        order. Returns 'added' | 'duplicate' | 'error'. The file_count
        header stays in sync; the website cache must be revalidated by
        the caller."""
        async with self.write_lock:
            try:
                cur = await self.conn.execute(
                    "SELECT 1 FROM collection_items WHERE collection_id = ? "
                    "AND channel_id = ? AND message_id = ?",
                    (collection_id, int(channel_id), int(message_id)))
                if await cur.fetchone():
                    return "duplicate"
                cur = await self.conn.execute(
                    "SELECT COALESCE(MAX(position), -1) AS mp FROM "
                    "collection_items WHERE collection_id = ?",
                    (collection_id,))
                row = await cur.fetchone()
                pos = int(row["mp"]) + 1 if row else 0
                await self.conn.execute(
                    "INSERT INTO collection_items (collection_id, "
                    "channel_id, message_id, position) VALUES (?, ?, ?, ?)",
                    (collection_id, int(channel_id), int(message_id), pos))
                await self.conn.execute(
                    "UPDATE collections SET file_count = (SELECT COUNT(*) "
                    "FROM collection_items WHERE collection_id = ?), "
                    "created_at = created_at WHERE collection_id = ?",
                    (collection_id, collection_id))
                await self.conn.commit()
                return "added"
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("collection_add_item(%s) failed: %s",
                             collection_id, e)
                return "error"

    async def collection_remove_item(self, collection_id: str,
                                     position: int) -> bool:
        """V25 FINAL §15 (Manage Files — Remove): remove the member at
        ``position`` and renumber the remaining order 0..n-1 (the
        collection order stays dense and deterministic)."""
        async with self.write_lock:
            try:
                cur = await self.conn.execute(
                    "DELETE FROM collection_items WHERE collection_id = ? "
                    "AND position = ?",
                    (collection_id, int(position)))
                removed = bool(cur.rowcount)
                if removed:
                    # Renumber deterministically by the OLD order.
                    cur2 = await self.conn.execute(
                        "SELECT id FROM collection_items WHERE "
                        "collection_id = ? ORDER BY position ASC",
                        (collection_id,))
                    # NOTE: collection_items.id IS the INTEGER PRIMARY KEY
                    # (rowid alias) — SQLite labels the result column 'id',
                    # so the OLD rowid-label access raised IndexError and
                    # rolled the whole removal back (the §11 defect: remove
                    # always failed on non-empty collections).
                    rowids = [r["id"] for r in await cur2.fetchall()]
                    for new_pos, rid in enumerate(rowids):
                        await self.conn.execute(
                            "UPDATE collection_items SET position = ? "
                            "WHERE id = ?", (new_pos, rid))
                    await self.conn.execute(
                        "UPDATE collections SET file_count = (SELECT "
                        "COUNT(*) FROM collection_items WHERE "
                        "collection_id = ?) WHERE collection_id = ?",
                        (collection_id, collection_id))
                await self.conn.commit()
                return removed
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("collection_remove_item(%s) failed: %s",
                             collection_id, e)
                return False

    async def collection_move_item(self, collection_id: str, position: int,
                                   direction: str) -> bool:
        """V25 FINAL §15 (Manage Files — Reorder): swap the member at
        ``position`` with its neighbor ('up' | 'down'). Returns True when
        the order actually changed."""
        delta = -1 if str(direction) == "up" else 1
        other = int(position) + delta
        async with self.write_lock:
            try:
                cur = await self.conn.execute(
                    "SELECT id, position FROM collection_items WHERE "
                    "collection_id = ? AND position IN (?, ?)",
                    (collection_id, int(position), other))
                rows = await cur.fetchall()
                if len(rows) != 2:
                    return False  # at the boundary or missing — no-op
                # ID-SCOPED swap: a position-keyed pair of UPDATEs would
                # transiently duplicate a position and the second UPDATE
                # would then match BOTH rows (the §11 defect: [0,1,2]
                # became [0,0,2] while answering success). Swapping by the
                # stable primary key is atomic-order-safe.
                by_pos = {int(r["position"]): int(r["id"]) for r in rows}
                if len(by_pos) != 2:
                    return False  # corrupted source order — honest no-op
                await self.conn.execute(
                    "UPDATE collection_items SET position = ? WHERE id = ?",
                    (other, by_pos[int(position)]))
                await self.conn.execute(
                    "UPDATE collection_items SET position = ? WHERE id = ?",
                    (int(position), by_pos[other]))
                await self.conn.commit()
                return True
            except Exception as e:  # noqa: BLE001
                try:
                    await self.conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
                logger.error("collection_move_item(%s) failed: %s",
                             collection_id, e)
                return False
    async def find_collection_by_message_ids(self, channel_id: int,
                                               message_ids: List[int]) -> Optional[aiosqlite.Row]:
        """BOT6 P10/P12: find a collection that contains ALL the given message_ids
        on the given channel. Returns the collections row if found, None otherwise.
        Used for semantic duplicate detection: when the admin forwards files that
        already belong to an existing collection, show the existing payload instead
        of silently skipping or creating a duplicate."""
        if not message_ids:
            return None
        # Find collection_ids that contain the FIRST message_id.
        first_mid = message_ids[0]
        cur = await self.conn.execute(
            "SELECT DISTINCT collection_id FROM collection_items "
            "WHERE channel_id = ? AND message_id = ?",
            (channel_id, first_mid),
        )
        candidate_rows = await cur.fetchall()
        for row in candidate_rows:
            coll_id = row["collection_id"]
            # Verify ALL message_ids are in this collection.
            cur2 = await self.conn.execute(
                "SELECT message_id FROM collection_items "
                "WHERE collection_id = ? AND channel_id = ?",
                (coll_id, channel_id),
            )
            existing_ids = {r["message_id"] for r in await cur2.fetchall()}
            if set(message_ids).issubset(existing_ids):
                # Found a collection containing all message_ids.
                cur3 = await self.conn.execute(
                    "SELECT * FROM collections WHERE collection_id = ?",
                    (coll_id,),
                )
                return await cur3.fetchone()
        return None
    async def get_collection_items(self, collection_id: str) -> List[aiosqlite.Row]:
        """Return the ordered list of (channel_id, message_id) for a collection.

        Joined with indexed_files so the caller gets the full file rows needed
        for delivery. Files that were deleted from the storage channel (no
        longer indexed) are excluded — the caller sees only deliverable files.
        """
        cur = await self.conn.execute(
            "SELECT ci.position, ci.channel_id, ci.message_id, i.* "
            "FROM collection_items ci "
            "LEFT JOIN indexed_files i ON i.channel_id = ci.channel_id "
            "  AND i.message_id = ci.message_id "
            "WHERE ci.collection_id = ? "
            "ORDER BY ci.position ASC",
            (collection_id,),
        )
        return await cur.fetchall()
    async def find_collection_id_for_index_id(self, index_id: int) -> Optional[str]:
        """Return the collection_id containing the indexed file, if any.

        A.4 (bot-25): the website payload resolver uses this to expand a
        payload whose canonical indexed file belongs to a collection into
        the collection's FULL ordered file list (the multi-file payload
        contract — one part per member, prev/next navigation across all
        parts). Deterministic: the lexicographically smallest collection_id
        wins when a file somehow belongs to more than one.
        """
        cur = await self.conn.execute(
            """
            SELECT ci.collection_id
            FROM collection_items ci
            JOIN indexed_files i
              ON i.channel_id = ci.channel_id
             AND i.message_id = ci.message_id
            WHERE i.id = ?
            ORDER BY ci.collection_id ASC
            LIMIT 1
            """,
            (int(index_id),),
        )
        row = await cur.fetchone()
        return str(row["collection_id"]) if row else None
    async def find_single_payload_by_channel_message(
            self, channel_id: int, message_id: int) -> Optional[aiosqlite.Row]:
        """V26 (bot-37.log message-872 identity fix): find the SINGLE-file
        payload whose canonical indexed file is the exact
        (channel_id, message_id) pair — the forward-detection identity.

        Production evidence: message 872 (channel -1004460709020,
        file_pk 1174) was payload 787's file, yet re-forwarding it ALWAYS
        produced decision=create_wizard (the duplicate detection was
        COLLECTION-only) — the admin could silently mint duplicate
        payloads of the same file. This returns the payloads row (with
        display_name + index_id) for the exact identity, or None.

        Deterministic: the LOWEST payload id wins when several rows
        somehow reference the same indexed file (the first-created
        payload is the canonical one)."""
        try:
            cur = await self.conn.execute(
                """
                SELECT p.*
                FROM payloads p
                JOIN indexed_files i ON i.id = p.index_id
                WHERE i.channel_id = ? AND i.message_id = ?
                ORDER BY p.id ASC
                LIMIT 1
                """,
                (int(channel_id), int(message_id)),
            )
            return await cur.fetchone()
        except Exception:  # noqa: BLE001 — detection is best-effort
            logger.debug("find_single_payload_by_channel_message failed",
                         exc_info=True)
            return None
    async def count_collection_items(self, collection_id: str) -> int:
        """Total items stored in a collection (including deleted files)."""
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM collection_items WHERE collection_id = ?",
            (collection_id,),
        )
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def delete_collection(self, collection_id: str) -> bool:
        """Delete a collection and all its items (CASCADE)."""
        cur = await self.conn.execute(
            "DELETE FROM collections WHERE collection_id = ?", (collection_id,)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def collection_exists(self, collection_id: str) -> bool:
        cur = await self.conn.execute(
            "SELECT 1 FROM collections WHERE collection_id = ?", (collection_id,)
        )
        return await cur.fetchone() is not None
    async def add_alias(self, payload_id: int, alias: str) -> bool:
        try:
            await self.conn.execute(
                "INSERT INTO payload_aliases (payload_id, alias) VALUES (?, ?)",
                (payload_id, alias.lower()),
            )
            await self.conn.commit()
            return True
        except aiosqlite.IntegrityError:
            return False
    async def remove_alias(self, alias: str) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM payload_aliases WHERE alias = ?", (alias.lower(),)
        )
        await self.conn.commit()
        return cur.rowcount > 0
    async def list_aliases(self, payload_id: int) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT alias FROM payload_aliases WHERE payload_id = ? ORDER BY id",
            (payload_id,),
        )
        return await cur.fetchall()
    async def alias_owner(self, alias: str) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM payload_aliases WHERE alias = ?", (alias.lower(),)
        )
        return await cur.fetchone()
