"""pending deletions, delivery records, retrieval analytics, views/stats — deliveries repository (ARCHITECTURE PHASE).

Payload-FACING delivery analytics + housekeeping, extracted verbatim from
the legacy ``bot.py`` ``Database`` class; composed into ``app.storage.
database.DatabaseBase`` as ``DeliveriesRepoMixin``. Scope:

* ``payload_views`` — per-(payload, user) view rows + the total/unique/
  daily/weekly/monthly rollups (``record_view`` / ``*_view_stats`` /
  ``top_payloads`` / ``top_downloads``), gated by ENABLE_ANALYTICS.
* ``delivery_records`` — the per-user retrieval ledger for named payloads
  and collections (``create_delivery_record`` / retrieve counters /
  ``most_retrieved_*`` analytics / recovery-message bookkeeping).
* ``pending_deletions`` + ``broadcast_deletions`` — the durable
  self-destruct queues for sent messages (save/defer/due/expired + the
  batch variants).
* ``stat:*`` counters — ``increment_stat`` / ``get_stat`` (backed by
  the shared ``bot_settings`` table).

Naming note (B23-3 §5.13): NOT the trusted-relay delivery architecture —
that is the SIBLING ``delivery.py`` (``DeliveryRepoMixin``:
network_delivery_groups / delivery_jobs / file_delivery_bot /
control_audit_events). This module never touches those tables. No
renames — both keep their historical module names; this docstring is the
disambiguator.
"""
from __future__ import annotations

import aiosqlite
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple
from app.core.constants import (
    ENABLE_ANALYTICS,
)
from app.storage.dbutil import now_iso as _now_iso

class DeliveriesRepoMixin:
    """pending deletions, delivery records, retrieval analytics, views/stats."""

    async def record_view(self, payload_id: int, user_id: int) -> None:
        if not ENABLE_ANALYTICS:
            return
        await self.conn.execute(
            "INSERT INTO payload_views (payload_id, user_id, timestamp) VALUES (?, ?, ?)",
            (payload_id, user_id, _now_iso()),
        )
        await self.conn.commit()
    async def payload_view_stats(self, payload_id: int) -> Dict[str, int]:
        now = datetime.now(timezone.utc)
        day_ago = (now - timedelta(days=1)).isoformat()
        week_ago = (now - timedelta(days=7)).isoformat()
        month_ago = (now - timedelta(days=30)).isoformat()
        stats = {"total": 0, "unique": 0, "daily": 0, "weekly": 0, "monthly": 0}
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c FROM payload_views WHERE payload_id = ?", (payload_id,)
        )
        r = await cur.fetchone()
        stats["total"] = int(r["c"]) if r else 0

        cur = await self.conn.execute(
            "SELECT COUNT(DISTINCT user_id) AS c FROM payload_views WHERE payload_id = ?",
            (payload_id,),
        )
        r = await cur.fetchone()
        stats["unique"] = int(r["c"]) if r else 0

        for key, since in (("daily", day_ago), ("weekly", week_ago), ("monthly", month_ago)):
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM payload_views WHERE payload_id = ? AND timestamp >= ?",
                (payload_id, since),
            )
            r = await cur.fetchone()
            stats[key] = int(r["c"]) if r else 0
        return stats
    async def global_view_stats(self) -> Dict[str, int]:
        now = datetime.now(timezone.utc)
        day_ago = (now - timedelta(days=1)).isoformat()
        week_ago = (now - timedelta(days=7)).isoformat()
        month_ago = (now - timedelta(days=30)).isoformat()
        stats = {"total": 0, "unique": 0, "daily": 0, "weekly": 0, "monthly": 0}

        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM payload_views")
        r = await cur.fetchone()
        stats["total"] = int(r["c"]) if r else 0

        cur = await self.conn.execute("SELECT COUNT(DISTINCT user_id) AS c FROM payload_views")
        r = await cur.fetchone()
        stats["unique"] = int(r["c"]) if r else 0

        for key, since in (("daily", day_ago), ("weekly", week_ago), ("monthly", month_ago)):
            cur = await self.conn.execute(
                "SELECT COUNT(*) AS c FROM payload_views WHERE timestamp >= ?", (since,)
            )
            r = await cur.fetchone()
            stats[key] = int(r["c"]) if r else 0
        return stats
    async def top_payloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            """
            SELECT p.payload, p.current_clicks,
                   (SELECT COUNT(*) FROM payload_views v WHERE v.payload_id = p.id) AS views
            FROM payloads p
            ORDER BY p.current_clicks DESC
            LIMIT ?
            """,
            (limit,),
        )
        return await cur.fetchall()
    async def top_downloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM indexed_files ORDER BY downloads DESC LIMIT ?", (limit,)
        )
        return await cur.fetchall()
    async def increment_stat(self, key: str, by: int = 1) -> None:
        cur_val = await self.get_setting_int(f"stat:{key}", 0)
        await self.set_setting(f"stat:{key}", str(cur_val + by))
    async def get_stat(self, key: str, default: int = 0) -> int:
        return await self.get_setting_int(f"stat:{key}", default)
    async def save_pending_deletion(self, chat_id: int, message_id: int, delete_at: str) -> None:
        await self.conn.execute(
            "INSERT OR REPLACE INTO broadcast_deletions (chat_id, message_id, delete_at) "
            "VALUES (?, ?, ?)", (chat_id, message_id, delete_at)
        )
        await self.conn.commit()
    async def bulk_save_pending_deletions(self, rows: List[Tuple[int, int, str]]) -> None:
        await self.conn.executemany(
            "INSERT OR REPLACE INTO broadcast_deletions (chat_id, message_id, delete_at) "
            "VALUES (?, ?, ?)", rows
        )
        await self.conn.commit()
    async def remove_pending_deletion(self, chat_id: int, message_id: int) -> None:
        await self.conn.execute(
            "DELETE FROM broadcast_deletions WHERE chat_id = ? AND message_id = ?",
            (chat_id, message_id)
        )
        await self.conn.commit()
    async def defer_pending_deletion(self, chat_id: int, message_id: int, delete_at: str) -> None:
        await self.conn.execute(
            "UPDATE broadcast_deletions SET delete_at = ? WHERE chat_id = ? AND message_id = ?",
            (delete_at, chat_id, message_id)
        )
        await self.conn.commit()
    async def expired_pending_deletions(self, now_str: str) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT chat_id, message_id FROM broadcast_deletions WHERE delete_at <= ?",
            (now_str,)
        )
        return await cur.fetchall()
    async def add_pending_deletion(self, chat_id: int, message_id: int,
                                    delete_at: int, deletion_type: str,
                                    network_bot_id: Optional[int] = None
                                    ) -> int:
        """Persist a scheduled message deletion so it survives bot restart.

        Returns the row id. delete_at is a unix epoch timestamp (seconds).
        deletion_type is one of: delivery, browse, admin_preview, status.

        BOT-45/46 round 2 (Prompt2 §C/§D/§H):
          * network_bot_id — the durable NETWORK BOT identity that
            DELIVERED the user-facing message (NULL/0 = the main bot).
            Recorded at schedule time; the startup recovery / sweeper
            resolve the CORRECT bot client at delete time (the main bot
            can never delete a Network Bot's message in a user chat).
          * IDEMPOTENT per (chat_id, message_id): a second schedule for
            the same pair never creates a duplicate deletion job — the
            existing open row's due time is refreshed instead (Prompt2
            §D: "Duplicate scheduling must not create duplicate deletion
            jobs"). Rows are never duplicated, so the recovery/sweeper
            can never double-fire the same target.
        """
        try:
            nid_val = int(network_bot_id) if network_bot_id else None
        except (TypeError, ValueError):
            nid_val = None
        cur = await self.conn.execute(
            "SELECT id FROM pending_deletions "
            "WHERE chat_id = ? AND message_id = ? LIMIT 1",
            (int(chat_id), int(message_id)))
        existing = await cur.fetchone()
        if existing is not None:
            row_id = int(existing["id"])
            # COALESCE preserves an already-recorded Network Bot identity
            # when a later schedule arrives without one (e.g. the engine
            # hook recorded nid=4, then the presentation re-schedules the
            # same pair with nid=NULL — the identity must NEVER be
            # downgraded, or restart recovery would delete with the wrong
            # bot).
            await self.conn.execute(
                "UPDATE pending_deletions SET delete_at = ?, "
                "deletion_type = ?, "
                "network_bot_id = COALESCE(?, network_bot_id) "
                "WHERE id = ?",
                (int(delete_at), deletion_type, nid_val, row_id))
            await self.conn.commit()
            return row_id
        cur = await self.conn.execute(
            "INSERT INTO pending_deletions (chat_id, message_id, "
            "delete_at, deletion_type, network_bot_id) "
            "VALUES (?, ?, ?, ?, ?)",
            (int(chat_id), int(message_id), int(delete_at), deletion_type,
             nid_val),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def add_pending_deletions_batch(self, rows: List[Tuple[int, int, int, str]]) -> None:
        """Bulk insert pending deletions. Each row is (chat_id, message_id, delete_at, type)."""
        if not rows:
            return
        await self.conn.executemany(
            "INSERT INTO pending_deletions (chat_id, message_id, delete_at, deletion_type) "
            "VALUES (?, ?, ?, ?)",
            rows,
        )
        await self.conn.commit()
    async def due_pending_deletions(self, now_ts: int) -> List[aiosqlite.Row]:
        """Return all pending deletions whose delete_at <= now (should be deleted immediately).

        BOT-45/46 (v47): also selects attempts + last_error so the
        classified retry path (deletion section) can account bounded
        give-ups without a second read.
        BOT-45/46 round 2 (v48): also selects network_bot_id so the
        caller resolves the CORRECT bot client for each row (the main
        bot can never delete a Network Bot's user-facing message).
        """
        cur = await self.conn.execute(
            "SELECT id, chat_id, message_id, deletion_type, attempts, "
            "last_error, network_bot_id FROM pending_deletions "
            "WHERE delete_at <= ? ORDER BY delete_at ASC",
            (int(now_ts),),
        )
        return await cur.fetchall()
    async def upcoming_pending_deletions(self, now_ts: int) -> List[aiosqlite.Row]:
        """Return all pending deletions whose delete_at > now (need re-scheduling)."""
        cur = await self.conn.execute(
            "SELECT id, chat_id, message_id, delete_at, deletion_type, network_bot_id FROM pending_deletions "
            "WHERE delete_at > ? ORDER BY delete_at ASC",
            (int(now_ts),),
        )
        return await cur.fetchall()
    async def remove_pending_deletion_by_id(self, row_id: int) -> None:
        """Issue 34/C1 Fix: Remove a pending_deletions record by row id.

        Renamed from remove_pending_deletion to avoid collision with the
        broadcast_deletions method of the same name (which takes
        chat_id+message_id). The old name caused a TypeError crash in
        cleanup_loop because Python silently overrode the first definition.
        """
        await self.conn.execute(
            "DELETE FROM pending_deletions WHERE id = ?", (row_id,)
        )
        await self.conn.commit()
    async def remove_pending_deletion_by_msg(self, chat_id: int, message_id: int) -> None:
        """Remove a pending deletion record by (chat_id, message_id)."""
        await self.conn.execute(
            "DELETE FROM pending_deletions WHERE chat_id = ? AND message_id = ?",
            (chat_id, message_id),
        )
        await self.conn.commit()
    async def count_pending_deletions(self) -> int:
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM pending_deletions")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def retry_pending_deletion(self, row_id: int, *, error: str,
                                     base_delay: int = 60,
                                     max_delay: int = 3600,
                                     max_attempts: int = 5
                                     ) -> Dict[str, object]:
        """BOT-45/46 (v47): record a failed delete attempt + schedule the
        BOUNDED retry — or give up.

        A failed Telegram delete is no longer settled silently: attempts
        is incremented, the CLASSIFIED reason token is stored in
        last_error (never a raw exception / never a secret) and delete_at
        is deferred by the bounded exponential backoff
        (base_delay * 2^(attempts-1), capped at max_delay). At
        max_attempts failed attempts the row is REMOVED (bounded
        give-up) so a dead target can never spin forever — the caller
        emits the AUTO_DELETE_GAVE_UP telemetry for that verdict.

        Returns a safe-fields dict:
          ok       — the row was found and the decision applied;
          gave_up  — True when the bounded give-up fired (row removed);
          attempts — the failed-attempt count AFTER this failure;
          retry_at — the new delete_at epoch (0 when gave up);
          delay    — the applied backoff seconds (0 when gave up);
          reason   — the classified reason token (truncated, safe).
        """
        cur = await self.conn.execute(
            "SELECT attempts FROM pending_deletions WHERE id = ?", (int(row_id),)
        )
        row = await cur.fetchone()
        if row is None:
            return {"ok": False, "gave_up": False, "attempts": 0,
                    "retry_at": 0, "delay": 0, "reason": "row_missing"}
        reason = str(error or "")[:200]
        attempts = int(row["attempts"] or 0) + 1
        if attempts >= int(max_attempts):
            await self.conn.execute(
                "DELETE FROM pending_deletions WHERE id = ?", (int(row_id),)
            )
            await self.conn.commit()
            return {"ok": True, "gave_up": True, "attempts": attempts,
                    "retry_at": 0, "delay": 0, "reason": reason}
        delay = min(int(base_delay) * (2 ** (attempts - 1)), int(max_delay))
        retry_at = int(datetime.now(timezone.utc).timestamp()) + delay
        await self.conn.execute(
            "UPDATE pending_deletions SET attempts = ?, last_error = ?, "
            "delete_at = ? WHERE id = ?",
            (attempts, reason, retry_at, int(row_id)),
        )
        await self.conn.commit()
        return {"ok": True, "gave_up": False, "attempts": attempts,
                "retry_at": retry_at, "delay": delay, "reason": reason}
    async def pending_deletion_stats(self, *, now_ts: Optional[int] = None,
                                     max_attempts: int = 5) -> Dict[str, int]:
        """BOT-45/46 (v47): aggregate pending-deletion retry health.

        Safe diagnostic counters only (no error text, no chat/message
        ids — safe for admin panels and logs):
          total             — rows currently pending;
          due               — rows whose delete_at has passed;
          upcoming          — rows still waiting on their timer;
          failed            — rows with at least one recorded failed attempt;
          exhausted         — rows at/over max_attempts (give-up imminent);
          max_attempts_seen — the highest attempts value currently pending.
        """
        if now_ts is None:
            now_ts = int(datetime.now(timezone.utc).timestamp())
        cur = await self.conn.execute(
            "SELECT COUNT(*) AS c, "
            "SUM(CASE WHEN delete_at <= ? THEN 1 ELSE 0 END) AS due, "
            "SUM(CASE WHEN delete_at > ? THEN 1 ELSE 0 END) AS upcoming, "
            "SUM(CASE WHEN attempts > 0 THEN 1 ELSE 0 END) AS failed, "
            "SUM(CASE WHEN attempts >= ? THEN 1 ELSE 0 END) AS exhausted, "
            "COALESCE(MAX(attempts), 0) AS max_seen "
            "FROM pending_deletions",
            (int(now_ts), int(now_ts), int(max_attempts)),
        )
        row = await cur.fetchone()
        if row is None:
            return {"total": 0, "due": 0, "upcoming": 0, "failed": 0,
                    "exhausted": 0, "max_attempts_seen": 0}
        return {
            "total": int(row["c"] or 0),
            "due": int(row["due"] or 0),
            "upcoming": int(row["upcoming"] or 0),
            "failed": int(row["failed"] or 0),
            "exhausted": int(row["exhausted"] or 0),
            "max_attempts_seen": int(row["max_seen"] or 0),
        }
    async def create_delivery_record(self, payload_code: str, user_id: int,
                                      delivery_type: str, chat_id: int,
                                      collection_code: Optional[str] = None,
                                      max_retrieves: int = 0,
                                      retrieve_window_hours: int = 0) -> int:
        """Store a delivery record so it can be retrieved after auto-delete."""
        cur = await self.conn.execute(
            """INSERT INTO delivery_records
               (payload_code, collection_code, user_id, delivery_type, delivered_at,
                retrieve_count, max_retrieves, retrieve_window_hours, chat_id)
               VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)""",
            (payload_code, collection_code, user_id, delivery_type, _now_iso(),
             max_retrieves, retrieve_window_hours, chat_id),
        )
        await self.conn.commit()
        return int(cur.lastrowid)
    async def get_delivery_record(self, record_id: int) -> Optional[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM delivery_records WHERE id = ?", (record_id,)
        )
        return await cur.fetchone()
    async def get_recent_delivery_records(self, user_id: int, limit: int = 5) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM delivery_records WHERE user_id = ? ORDER BY id DESC LIMIT ?",
            (user_id, limit),
        )
        return await cur.fetchall()
    async def get_recent_payload_deliveries_24h(self, user_id: int,
                                                  limit: int = 4) -> List[aiosqlite.Row]:
        """BOT5 /recent: deduped by payload_code, 24h window, max 4."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        cur = await self.conn.execute(
            "SELECT MAX(id) AS max_id FROM delivery_records "
            "WHERE user_id = ? AND delivered_at >= ? "
            "GROUP BY payload_code ORDER BY max_id DESC LIMIT ?",
            (user_id, cutoff, limit),
        )
        id_rows = await cur.fetchall()
        if not id_rows:
            return []
        ids = [int(r["max_id"]) for r in id_rows]
        placeholders = ",".join("?" * len(ids))
        cur = await self.conn.execute(
            f"SELECT * FROM delivery_records WHERE id IN ({placeholders}) ORDER BY id DESC",
            ids,
        )
        return await cur.fetchall()
    async def increment_retrieve_count(self, record_id: int) -> None:
        await self.conn.execute(
            "UPDATE delivery_records SET retrieve_count = retrieve_count + 1 WHERE id = ?",
            (record_id,),
        )
        await self.conn.commit()
    async def delete_delivery_record(self, record_id: int) -> None:
        await self.conn.execute("DELETE FROM delivery_records WHERE id = ?", (record_id,))
        await self.conn.commit()
    async def update_recovery_message_id(self, record_id: int, message_id: int) -> None:
        """Issue #81: store the Telegram message_id of the recovery card."""
        await self.conn.execute(
            "UPDATE delivery_records SET recovery_message_id = ? WHERE id = ?",
            (message_id, record_id),
        )
        await self.conn.commit()
    async def count_delivery_records(self) -> int:
        """Total deliveries that left a recovery card (retrieve-eligible)."""
        cur = await self.conn.execute("SELECT COUNT(*) AS c FROM delivery_records")
        row = await cur.fetchone()
        return int(row["c"]) if row else 0
    async def count_total_retrieves(self) -> int:
        """Sum of retrieve_count across all delivery records."""
        cur = await self.conn.execute(
            "SELECT COALESCE(SUM(retrieve_count), 0) AS s FROM delivery_records"
        )
        row = await cur.fetchone()
        return int(row["s"]) if row else 0
    async def most_retrieved_payloads(self, limit: int = 10) -> List[aiosqlite.Row]:
        """Issue #55: top single-file payloads by retrieve_count."""
        cur = await self.conn.execute(
            """SELECT payload_code, SUM(retrieve_count) AS total
               FROM delivery_records
               WHERE delivery_type = 'single'
               GROUP BY payload_code
               ORDER BY total DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
    async def most_retrieved_collections(self, limit: int = 10) -> List[aiosqlite.Row]:
        """Issue #55: top collections by retrieve_count."""
        cur = await self.conn.execute(
            """SELECT collection_code, SUM(retrieve_count) AS total
               FROM delivery_records
               WHERE delivery_type = 'collection' AND collection_code IS NOT NULL
               GROUP BY collection_code
               ORDER BY total DESC LIMIT ?""",
            (limit,),
        )
        return await cur.fetchall()
