"""SQLite connection core + repository composition (ARCHITECTURE PHASE).

``DatabaseBase`` owns the connection lifecycle, the write lock, the
migration primitives delegation and the critical-schema verification; the
domain methods come from the repository mixins. The legacy
``bot.py:Database`` subclasses this base and keeps ONLY the source-pinned
frozen core (the v1→v29 migration chain and the Watch Ads
session/reward transaction methods) — see docs/BOT_COMPATIBILITY.md.
"""
from __future__ import annotations

import asyncio
import logging
from typing import List, Optional, Tuple

import aiosqlite

from app.storage.migrations import (
    add_column_if_missing as _mig_add_column,
    column_exists as _mig_column_exists,
    table_exists as _mig_table_exists,
)
from app.storage.repositories.users import UsersRepoMixin
from app.storage.repositories.media import MediaRepoMixin
from app.storage.repositories.payloads import PayloadsRepoMixin
from app.storage.repositories.force_join import ForceJoinRepoMixin
from app.storage.repositories.referrals import ReferralsRepoMixin
from app.storage.repositories.watch_ads import WatchAdsRepoMixin
from app.storage.repositories.network import NetworkRepoMixin
from app.storage.repositories.broadcasts import BroadcastsRepoMixin
from app.storage.repositories.deliveries import DeliveriesRepoMixin
from app.storage.repositories.settings import SettingsRepoMixin
from app.storage.repositories.website import WebsiteRepoMixin
from app.storage.repositories.categories import WebsiteCategoriesRepoMixin
from app.storage.repositories.ads import AdsRepoMixin
from app.storage.repositories.verification import VerificationRepoMixin
from app.storage.repositories.delivery import DeliveryRepoMixin
from app.storage.repositories.media_stats import MediaStatsRepoMixin

logger = logging.getLogger("payload-bot")


class DatabaseBase(
    UsersRepoMixin,
    MediaRepoMixin,
    PayloadsRepoMixin,
    ForceJoinRepoMixin,
    ReferralsRepoMixin,
    WatchAdsRepoMixin,
    NetworkRepoMixin,
    BroadcastsRepoMixin,
    DeliveriesRepoMixin,
    SettingsRepoMixin,
    WebsiteRepoMixin,
    WebsiteCategoriesRepoMixin,
    AdsRepoMixin,
    VerificationRepoMixin,
    DeliveryRepoMixin,
    MediaStatsRepoMixin,
):
    """Composition of every domain repository + the connection core."""
    async def connect(self) -> None:
        self._db = await aiosqlite.connect(self.db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL;")
        await self._db.execute("PRAGMA foreign_keys=ON;")
        await self._db.commit()
        logger.info("Connected to database: %s", self.db_path)

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None
            logger.info("Database connection closed.")

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("Database not connected.")
        return self._db

    @property
    def write_lock(self) -> asyncio.Lock:
        """Expose the write lock so callers that issue explicit BEGIN IMMEDIATE
        can serialise their transaction windows. Implicit-transaction helpers
        (single INSERT/UPDATE + commit) are safe enough on WAL but should also
        be wrapped when they participate in a larger atomic operation."""
        return self._write_lock

    async def _column_exists(self, table: str, column: str) -> bool:
        return await _mig_column_exists(self.conn, table, column)

    async def _add_column_if_missing(self, table: str, column: str,
                                     definition: str) -> None:
        await _mig_add_column(self.conn, table, column, definition)

    async def _verify_critical_schema(self) -> None:
        """Verify every CRITICAL_COLUMN actually exists. Repair if missing
        (idempotent). Verify again. FAIL LOUDLY if still missing.

        This is the defense-in-depth that catches the production failure mode
        where schema_meta.version=23 but the v23 columns are absent (partial
        migration, different DB file, swallowed exception, stale container,
        CWD mismatch). Without this, the bot would start "successfully" and
        later surface `sqlite3.OperationalError: no such column: active_batch`
        mid-delivery — which is exactly the reported production defect.
        """
        # First pass: detect + attempt idempotent repair.
        missing_after_repair: List[Tuple[str, str]] = []
        repair_log: List[str] = []
        for table, column, definition in self.CRITICAL_COLUMNS:
            if await self._column_exists(table, column):
                continue
            logger.warning("Schema verify: %s.%s MISSING — attempting idempotent repair.",
                           table, column)
            try:
                await self._add_column_if_missing(table, column, definition)
                repair_log.append(f"{table}.{column}")
            except Exception as e:  # noqa: BLE001
                logger.error("Schema verify: REPAIR FAILED for %s.%s: %s",
                             table, column, e, exc_info=True)
                missing_after_repair.append((table, column))
        # If we repaired anything, verify again.
        if repair_log:
            logger.info("Schema verify: repaired columns: %s", ", ".join(repair_log))
            for table, column, _ in self.CRITICAL_COLUMNS:
                if (table, column) in missing_after_repair:
                    continue  # already known-failed
                if not await self._column_exists(table, column):
                    missing_after_repair.append((table, column))
        # Final pass: build a PASS/FAIL report.
        report: List[str] = []
        all_ok = True
        for table, column, _ in self.CRITICAL_COLUMNS:
            ok = await self._column_exists(table, column)
            report.append(f"{table}.{column}={'PASS' if ok else 'FAIL'}")
            if not ok:
                all_ok = False
        logger.info("Schema verify report: %s", " | ".join(report))
        if not all_ok:
            missing_str = ", ".join(f"{t}.{c}" for t, c in missing_after_repair)
            # Raise so post_init() fails loudly — the bot MUST NOT start with
            # an incompatible schema. Better to fail at startup than to serve
            # "Could not deliver this payload right now" to every user.
            raise RuntimeError(
                f"FATAL: database schema is missing critical columns even after "
                f"idempotent repair: {missing_str}. DATABASE_FILE={self.db_path}. "
                f"This usually means the running bot is using a different database "
                f"file than the one that was migrated, OR a prior migration set "
                f"schema_meta.version without actually applying the ALTERs. "
                f"Stop the bot, resolve the database path mismatch or restore "
                f"from a known-good backup, then restart."
            )

    async def _table_exists(self, table: str) -> bool:
        return await _mig_table_exists(self.conn, table)

    CRITICAL_COLUMNS: List[Tuple[str, str, str]] = [
        # v23 — Force Join STABLE ACTIVE BATCH state machine.
        ("fj_progress", "active_batch", "TEXT"),
        ("fj_progress", "completed_batches", "TEXT DEFAULT '[]'"),
        ("fj_progress", "batch_cursor", "INTEGER DEFAULT 0"),
        ("fj_progress", "unlocked_payload_ids", "TEXT DEFAULT '[]'"),
        # v22 — Entity preservation (text_link, bold, italic, etc.).
        ("start_message", "entities", "TEXT"),
        ("force_join_channels", "join_text_entities", "TEXT"),
        # v25 — WATCH_AD: payloads.watch_ads_enabled MUST exist (the Access
        # Engine reads it on every named-payload resolution).
        ("payloads", "watch_ads_enabled", "INTEGER NOT NULL DEFAULT 0"),
        # v26 — WATCH_AD V2: the multi-ad session columns MUST exist, otherwise
        # create_watch_ad_session()'s INSERT fails on EVERY attempt — which
        # silently degrades every Watch Ads screen to "temporarily
        # unavailable" (the exact reported production defect: a partially
        # migrated / stamped-but-altered-missed DB). Verified + repaired here
        # regardless of what schema_meta claims.
        ("watch_ad_sessions", "ad_control_mode", "TEXT NOT NULL DEFAULT 'short'"),
        ("watch_ad_sessions", "required_ads", "INTEGER NOT NULL DEFAULT 1"),
        ("watch_ad_sessions", "completed_ads", "INTEGER NOT NULL DEFAULT 0"),
        # v26 PRODUCTION FIX (bot.log evidence: "no such column:
        # last_reward_at" inside process_watch_ad_reward): the live DB was
        # stamped schema_meta_version=26 while last_reward_at was absent —
        # the version-gated migration never re-runs, and this list was the
        # ONLY startup defense. It was incomplete. reward_count is in the
        # v25 base table but is verified too (defense-in-depth for
        # restored/stale DBs): process_watch_ad_reward writes BOTH columns.
        ("watch_ad_sessions", "last_reward_at", "TEXT"),
        ("watch_ad_sessions", "reward_count", "INTEGER NOT NULL DEFAULT 0"),
        # v27 — WATCH_AD V4: the per-payload ad-mode override read by
        # create_watch_ad_session on EVERY new session (INSERT path is safe
        # with NULL, but the SELECT in mode resolution needs the column).
        ("payloads", "watch_ads_ad_mode_override", "TEXT"),
        # v36 — BOT-13: per-payload website delivery controls. The website
        # Get File endpoint and the payload-detail/player render read
        # show_get_file on every request. video_ad_destination is INERT at
        # runtime since B17 (surface-based preroll policy only — legacy
        # rows preserved for backward compat); it stays verified for
        # schema-completeness, but nothing routes on it anymore.
        ("payloads", "show_get_file", "INTEGER NOT NULL DEFAULT 1"),
        ("payloads", "video_ad_destination", "TEXT NOT NULL DEFAULT 'BOT'"),
        # v38 — B17: direct-delivery columns. The DeliveryJobEngine reads
        # delivery_mode on every retry dispatch and the handoff poller
        # resolves jobs BY handoff_token on every /start dl<token> — a
        # stamped-but-missed v38 DB would break the Mode B/C retry plane
        # and the poller completion mid-flight. Verified + repaired here
        # regardless of what schema_meta claims (the same defense-in-depth
        # the Watch Ads columns get).
        ("delivery_jobs", "delivery_mode", "TEXT"),
        ("delivery_jobs", "handoff_token", "TEXT"),
        ("delivery_jobs", "handoff_sent_at", "TEXT"),
        # v39 — B18: truthful Mode-A metrics (bot-19.log: jobs 34/35 fell
        # back to fdb_direct with no durable record Mode A ever failed).
        # The DeliveryJobEngine writes mode_a_failure on EVERY Mode-A
        # skip/fallback and the control-UI metrics read it — a
        # stamped-but-missed v39 DB would silently lose the Mode-A vs
        # fallback distinction again.
        ("delivery_jobs", "mode_a_failure", "TEXT"),
        ("delivery_jobs", "mode_a_failure_at", "TEXT"),
        # v39 — B18: force-join link provenance. Link health reads it on
        # every verification (bot_created = provably valid until our own
        # rotate; custom = trusted — the Bot API has NO getChatInviteLink
        # to introspect invite hashes).
        ("force_join_channels", "link_provenance", "TEXT"),
        # v37 — B17: network bot removal audit trail (REMOVED rows carry
        # removed_at; the registry's unfiltered reads and the archived
        # admin views rely on it).
        ("network_bots", "removed_at", "TEXT"),
        # v47 — BOT-45/46 (bot-46.log production evidence: 3,790×
        # "cleanup: pending_deletions sweep error: no such column:
        # last_error" + "Startup: pending_deletions recovery failed" +
        # "Wizard: ... table payloads has no column named
        # display_name_origin"). The live production DB was stamped
        # schema_meta_version=47 while the physical v47 columns were
        # absent — the version-gated migration (``if current < 47``)
        # never re-runs, and the v47 columns were missing from THIS
        # list, so the bot started with an incomplete schema and the
        # Auto Delete durable plane + the wizard create path + the
        # display-name propagation all failed at runtime for 10+ hours.
        # Verified + repaired HERE regardless of what schema_meta
        # claims (the same defense-in-depth the Watch Ads columns get):
        #   payloads.display_name_origin — provenance read/written by
        #     set/get_payload_display_name_origin + the wizard INSERT +
        #     refresh_source_derived_display_name;
        #   pending_deletions.attempts / .last_error — read by
        #     due_pending_deletions on EVERY 10s sweep and written by
        #     the classified retry path (retry_pending_deletion).
        ("payloads", "display_name_origin", "TEXT"),
        ("pending_deletions", "attempts", "INTEGER NOT NULL DEFAULT 0"),
        ("pending_deletions", "last_error", "TEXT"),
        # v48 — BOT-45/46 round 2 (Prompt2 §C/§H): the durable Network
        # Bot identity for a scheduled user-message deletion — recorded
        # at schedule time, resolved at delete time so a restart (or the
        # 10s sweeper) deletes with the CORRECT bot client (the main
        # bot can never delete a Network Bot's user-facing message).
        ("pending_deletions", "network_bot_id", "INTEGER"),
    ]

