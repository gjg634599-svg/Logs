"""PHASE 8 (§3-§5, §7, §28): real index verification + reconciliation.

STANDALONE MODULE — never imports the bot monolith. bot.py wires it with a
Deps container (db, transport callbacks, logger, epoch info) at call time.

Why this exists (production evidence):
  * The Storage Center reported files=1077 while a manual re-index found
    only 9 live messages — nothing in the system could say WHICH of the
    1077 DB records still had a live source message.
  * The old "Verify Index Integrity" compared two COUNTs (channel media
    found vs indexed) — it could not detect orphaned DB records, broken
    payload relationships, stale file_ids, duplicate identities, or
    cross-channel orphans, and stopped after 50 consecutive missing
    messages near the START of history.

Verification strategy (efficient + complete):
  Phase A — live-source discovery walk (read-only): from latest DOWNWARD to
  1 via the injected transport, stopping only at a large consecutive-missing
  gap. Builds the live map {message_id: media_info} and counts
  scanned/media/missing/no_media honestly (a Telegram error is an ERROR,
  never a 'missing').
  Phase B — targeted orphan probes: every DB message_id NOT seen live is
  probed INDIVIDUALLY (bounded by DB size, immune to history gaps). Each
  orphan gets an honest verdict: source missing / source hosts a DIFFERENT
  file (identity discipline — never overwrite the canonical row) / unknown
  (transient — not concluded).
  Phase C — database cross-matrix: duplicate identities, NULL-identity
  duplicates, broken payload references, payloads on unavailable files,
  cross-channel orphans, missing file_id, invalid media types, file_id
  staleness (stored vs freshly-fetched live id — exact, not heuristic),
  bot-token epoch staleness.
  Phase D — optional reconciliation (ALL actions guarded and logged,
    NOTHING is ever deleted, payload relationships are NEVER modified):
      source exists, DB missing            -> index the record
      DB exists, source exists, fid stale  -> atomic in-place file_id repair
      DB exists, source permanently gone   -> mark source_status='unavailable'
      DB 'unavailable', source back live   -> mark 'available' (+ fid repair)
      same (channel_id, message_id) now hosts NEW media (BOT-45 §7) ->
          guarded IN-PLACE source media replacement: file_pk, payload
          FKs, website + package associations preserved (UPDATE in
          place, never a second canonical source), INDEX_REPLACE_
          SOURCE_MEDIA_* telemetry + §5 display-name/website-label
          propagation — ONLY from the authoritative fetch this engine
          performed (identity is never fabricated)
      same identity, edited source metadata (BOT-45 §8) -> mutable
          metadata refresh in place + INDEX_REINDEX_METADATA_CHANGED /
          _UNCHANGED (same file_pk, same payload)
      identity mismatch without usable evidence -> report only (canonical preserved)
      broken payload refs                  -> report only (never touched)
  Phase C also emits per-record PAYLOAD_ON_UNAVAILABLE diagnostics
  (payload_id, file_pk, channel_id, message_id, short identity hash,
  availability, exact reason) — the count keeps its exact semantics.

The final report carries the exact counter vocabulary of the unified spec
(§28) and is persisted (KV index_verify:<channel_id>) for the Storage
Center. 'SUCCESS' is reported ONLY when the scan coverage was full.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
from typing import Any, Awaitable, Callable, Dict, List, Optional, Set, Tuple

# Verification walk tuning (independent from reindex tuning — this walk is
# read-only and must cover the whole history; only a huge gap stops it).
VERIFY_MAX_CONSEC_MISSING = 500
VERIFY_RUNAWAY_GUARD = 2_000_000
VERIFY_PROGRESS_EVERY = 25

KNOWN_MEDIA_TYPES = {
    "video", "document", "audio", "photo", "voice", "animation",
    "video_note", "sticker",
}

# BOT-45 §8: the mutable-metadata comparison vocabulary (mirrors the
# storage-layer refresh contract — identity-immutable columns are never
# part of a metadata comparison).
_MUTABLE_META_COLUMNS = (
    "file_name", "caption", "file_size", "duration", "mime_type",
    "width", "height", "thumb_file_id", "thumb_file_unique_id",
)

# Bounded diagnostics caps (report detail lists stay finite).
PAYLOAD_ON_UNAVAILABLE_DETAIL_CAP = 20

# Terminal statuses for the verification job itself.
VERIFY_STATUS_COMPLETE = "VERIFICATION_COMPLETE"
VERIFY_STATUS_PARTIAL = "VERIFICATION_PARTIAL"
VERIFY_STATUS_FAILED = "VERIFICATION_FAILED"
VERIFY_STATUS_RUNNING = "VERIFICATION_RUNNING"


def _now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


class Deps:
    """Dependency container wired by bot.py (keeps this module standalone)."""

    def __init__(self, *, db: Any, logger: Any,
                 fetch_channel_media: Callable[..., Awaitable],
                 index_one_message: Callable[..., Awaitable],
                 probe_message_exists: Callable[..., Awaitable],
                 determine_latest: Callable[..., Awaitable],
                 current_bot_id: Optional[int] = None,
                 file_id_owner_bot_id: Optional[int] = None) -> None:
        self.db = db
        self.logger = logger
        self.fetch_channel_media = fetch_channel_media
        self.index_one_message = index_one_message
        self.probe_message_exists = probe_message_exists
        self.determine_latest = determine_latest
        self.current_bot_id = current_bot_id
        self.file_id_owner_bot_id = file_id_owner_bot_id


def _new_report(channel_id: int) -> Dict[str, Any]:
    return {
        "channel_id": int(channel_id),
        "status": VERIFY_STATUS_RUNNING,
        "started_at": _now_iso(),
        "finished_at": None,
        "coverage": "full",
        "coverage_note": "",
        "messages_scanned": 0,
        "media_messages": 0,
        "no_media": 0,
        "missing": 0,                # source message ids confirmed absent
        "errors": 0,
        "stopped": False,
        # Cross-matrix findings (counts + capped detail lists)
        "db_total": 0,
        "db_available": 0,
        "db_unavailable": 0,
        "source_missing_from_db": 0,
        "source_missing_from_db_detail": [],
        "orphaned_records": 0,
        "orphaned_records_detail": [],
        "source_changed_identity": 0,
        "source_changed_identity_detail": [],
        "stale_file_ids": 0,
        "invalid_file_ids": 0,
        "null_identities": 0,
        "duplicate_identities": 0,
        "null_identity_duplicates": 0,
        "broken_payload_refs": 0,
        "broken_payload_refs_detail": [],
        "payloads_on_unavailable": 0,
        "payloads_on_unavailable_detail": [],
        "cross_channel_orphans": 0,
        "invalid_media_types": 0,
        "epoch_stale": False,
        # Reconciliation outcome
        "reconciled_indexed": 0,
        "reconciled_repaired": 0,
        "reconciled_marked_unavailable": 0,
        "reconciled_recovered": 0,
        "reconcile_failed": 0,
        # BOT-45 §7/§8 (Task E): in-place source media replacement +
        # reindex metadata comparison outcome.
        "source_replaced": 0,
        "source_replaced_detail": [],
        "reindex_metadata_changed": 0,
        "reindex_metadata_unchanged": 0,
    }


def _rows_to_dicts(rows: List[Any]) -> List[Dict[str, Any]]:
    """Repository rows (aiosqlite.Row) → plain dicts (RULE E: the engine
    reads ONLY through the storage verification repository)."""
    return [dict(r) for r in rows]


def _cap(detail: List[str], item: str, limit: int = 12) -> None:
    if len(detail) < limit:
        detail.append(item)


def _uid_hash(value: Any) -> str:
    """BOT-45 (§7/§8): short stable digest of a raw Telegram
    file_unique_id for SAFE telemetry (sha256 hex[:16] — the same
    convention as the storage layer; raw identity values are NEVER
    logged)."""
    try:
        return hashlib.sha256(
            str(value or "").encode("utf-8", "replace")).hexdigest()[:16]
    except Exception:  # noqa: BLE001 — hashing must never break the caller
        return "-"


def _source_display_slug(file_name: Any) -> str:
    """The source-DERIVED payload display name (the auto-payload creation
    convention: sanitize_slug(file_name)). The import is LAZY so this
    standalone engine stays loadable without the payload service; on any
    import failure the bounded raw filename is used — a display string
    only, NEVER a fabricated media identity."""
    raw = str(file_name or "").strip()
    if not raw:
        return ""
    try:
        from app.core.payload.service import sanitize_slug  # noqa: PLC0415
        return str(sanitize_slug(raw))
    except Exception:  # noqa: BLE001 — display string only, best-effort
        return raw[:64]


def _meta_field_differs(cur: Any, fresh: Any) -> bool:
    """Numeric-tolerant metadata comparison (mirrors the storage-layer
    semantics: int 1000 == str '1000' — no phantom 'changed' verdicts)."""
    if cur is None or fresh is None:
        return True
    try:
        if isinstance(cur, (int, float)) or isinstance(fresh, (int, float)):
            return float(cur) != float(fresh)
    except (TypeError, ValueError):
        pass
    return str(cur) != str(fresh)


async def _payloads_for_index(deps: Deps, file_pk: int,
                              *, walk_cap: int = 5000
                              ) -> List[Dict[str, Any]]:
    """All payload rows bound to one canonical indexed row (RULE E: read
    ONLY through the repository surface — a bounded page walk over
    ``list_payloads`` filtered by index_id; the exact-identity single
    lookup covers only the lowest payload id)."""
    out: List[Dict[str, Any]] = []
    lister = getattr(deps.db, "list_payloads", None)
    if lister is None:
        return out
    try:
        offset = 0
        page = 200
        while len(out) < walk_cap:
            rows = await lister(page, offset)
            if not rows:
                break
            for r in rows:
                d = dict(r) if not isinstance(r, dict) else r
                try:
                    if d.get("index_id") is not None and \
                            int(d["index_id"]) == int(file_pk):
                        out.append(d)
                except (TypeError, ValueError):
                    continue
            offset += len(rows)
            if len(rows) < page:
                break
    except Exception:  # noqa: BLE001 — enumeration is best-effort
        return out
    return out


async def _refresh_source_derived_display_names(
        deps: Deps, log: Any, *, file_pk: int, new_name: Any,
        already_updated: List[int]) -> List[int]:
    """BOT-45 §5/§7 (schema v47): refresh ``payloads.display_name`` from
    the CURRENT source filename for payloads whose
    ``display_name_origin`` is NULL or 'source'. ``admin_override``
    payloads are preserved VERBATIM (never written here). Repository
    surface only — ``update_payload_field`` is whitelisted for
    'display_name'."""
    updated = list(already_updated or [])
    slug = _source_display_slug(new_name)
    if not slug:
        return updated
    updater = getattr(deps.db, "update_payload_field", None)
    if updater is None:
        return updated
    for p in await _payloads_for_index(deps, file_pk):
        pid = p.get("id")
        if pid is None:
            continue
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            continue
        origin = p.get("display_name_origin")
        if origin is not None and str(origin) != "source":
            continue  # admin_override (any curated origin) — verbatim
        if str(p.get("display_name") or "") == slug or pid in updated:
            continue
        try:
            await updater(pid, "display_name", slug)
            updated.append(pid)
            log.info(
                "PAYLOAD_DISPLAY_NAME_SOURCE_REFRESH payload_id=%s "
                "file_pk=%s origin=%s display_name_hash=%s (source-derived "
                "display name refreshed in place)", pid, int(file_pk),
                str(origin or "null"), _uid_hash(slug))
        except Exception as e:  # noqa: BLE001 — propagation is best-effort
            log.warning("INDEX_REPLACE_SOURCE_MEDIA_PROPAGATE_ERROR "
                        "payload_id=%s file_pk=%s exc=%s", pid,
                        int(file_pk), type(e).__name__)
    return updated


async def _propagate_source_rename(
        deps: Deps, log: Any, *, channel_id: int, msg: int, file_pk: int,
        old_name: Any, new_name: Any) -> Tuple[List[int], List[int]]:
    """BOT-45 §5 propagation: (1) the EXISTING guarded repo path
    (propagate_renamed_file_defaults — payload display defaults +
    website listing labels, admin-curated values never touched — no
    duplicated logic in the engine) and (2) the schema-v47 origin-aware
    refresh (origin NULL/'source' only; admin_override verbatim).
    Returns (payload_ids, listing_ids) actually updated."""
    payload_ids: List[int] = []
    listing_ids: List[int] = []
    prop = getattr(deps.db, "propagate_renamed_file_defaults", None)
    if prop is not None and str(old_name or "").strip() and \
            str(new_name or "").strip() and str(old_name) != str(new_name):
        try:
            res = dict(await prop(file_pk, old_name, new_name) or {})
            payload_ids = [int(x) for x in (res.get("payload_ids") or [])]
            listing_ids = [int(x) for x in (res.get("listing_ids") or [])]
        except Exception as e:  # noqa: BLE001 — propagation is best-effort
            log.warning("INDEX_REPLACE_SOURCE_MEDIA_PROPAGATE_ERROR "
                        "file_pk=%s exc=%s", file_pk, type(e).__name__)
    payload_ids = await _refresh_source_derived_display_names(
        deps, log, file_pk=file_pk, new_name=new_name,
        already_updated=payload_ids)
    if payload_ids or listing_ids:
        log.info(
            "INDEX_RENAME_PROPAGATED file_pk=%s channel_id=%s message_id=%s "
            "payload_ids=%s listing_ids=%s old_filename=%r new_filename=%r "
            "(source-derived display names + website labels follow the "
            "current source; admin overrides preserved)",
            file_pk, channel_id, msg,
            ",".join(str(i) for i in payload_ids[:10]) or "-",
            ",".join(str(i) for i in listing_ids[:10]) or "-",
            old_name, new_name)
    return payload_ids, listing_ids


async def _diagnose_payloads_on_unavailable(
        deps: Deps, log: Any, report: Dict[str, Any], channel_id: int,
        db_rows: List[Dict[str, Any]], orphan_reasons: Dict[int, str],
        recovered_keys: Set[int], source_changed_keys: Set[int]) -> None:
    """BOT-45 §8 (Task E): PER-RECORD diagnostics for payloads bound to
    indexed rows whose source is unavailable. The count
    (verification_payloads_on_unavailable) keeps its exact global
    semantics; this adds one diagnostic line per record in THIS
    channel's verification scope — payload_id, file_pk, channel_id,
    message_id, a SHORT file_unique_id hash (raw identity values are
    never logged), the stored availability and the exact reason derived
    from THIS pass's live evidence (§8 steps 1-5: does the Telegram
    source exist, is the indexed identity valid, is the payload FK
    valid, did file_unique_id change, is the source genuinely gone)."""
    finder = getattr(deps.db, "find_single_payload_by_channel_message", None)
    if finder is None:
        return
    for row in db_rows:
        if str(row.get("source_status") or "") != "unavailable":
            continue
        try:
            msg = int(row["message_id"])
            file_pk = int(row["id"])
        except (TypeError, ValueError, KeyError):
            continue
        if file_pk in orphan_reasons:
            reason = (f"source message confirmed "
                      f"{orphan_reasons[file_pk]} by this pass")
        elif file_pk in recovered_keys:
            reason = ("source message is LIVE again this pass (recovery "
                      "pending — run Reconcile)")
        elif file_pk in source_changed_keys:
            reason = ("source message now hosts DIFFERENT media (identity "
                      "change) — in-place replacement available on "
                      "Reconcile")
        else:
            reason = ("indexed source_status=unavailable from a prior "
                      "verification pass (not re-verified by this pass)")
        try:
            payload = await finder(channel_id, msg)
        except Exception as e:  # noqa: BLE001 — diagnostics never break the run
            log.warning("PAYLOAD_ON_UNAVAILABLE_DIAG_ERROR channel_id=%s "
                        "message_id=%s exc=%s", channel_id, msg,
                        type(e).__name__)
            continue
        if payload is None:
            continue  # unavailable row with NO payload — not in the count
        p = dict(payload) if not isinstance(payload, dict) else payload
        payload_id = p.get("id")
        payload_name = p.get("payload")
        availability = str(row.get("source_status") or "unavailable")
        log.info(
            "PAYLOAD_ON_UNAVAILABLE payload_id=%s payload=%s file_pk=%s "
            "channel_id=%s message_id=%s file_unique_id_hash=%s "
            "availability=%s reason=%s",
            payload_id, payload_name, file_pk, int(channel_id), msg,
            _uid_hash(row.get("file_unique_id")), availability, reason)
        _cap(report["payloads_on_unavailable_detail"],
             f"payload {payload_id} ('{payload_name}') -> file_pk "
             f"{file_pk} msg {msg} [{availability}]: {reason}",
             limit=PAYLOAD_ON_UNAVAILABLE_DETAIL_CAP)


async def _replace_source_media_in_place(
        deps: Deps, log: Any, *, channel_id: int, row: Dict[str, Any],
        info: Dict[str, Any], report: Dict[str, Any]) -> str:
    """BOT-45 §7 (Phase D step 5): IN-PLACE SOURCE MEDIA REPLACEMENT.

    When verification itself fetched the (channel_id, message_id) and the
    message now carries NEW media (new file_unique_id — previously only
    counted as source_changed_identity), the canonical indexed row is
    UPDATED IN PLACE through the guarded storage method
    (replace_indexed_source_media): file_pk, upload_date, stats, source
    re-point history, payload foreign keys, website associations and
    package/collection associations ALL survive — no second canonical
    source is ever created and nothing is deleted.

    SECURITY: the ONLY accepted evidence is the authoritative Telegram
    fetch this engine performed (the ``info`` dict from
    fetch_channel_media); identity is NEVER fabricated — a missing
    fresh identity is rejected, not defaulted. The new identity must
    not be owned by another row (UNIQUE(file_unique_id) preserved).

    Returns "replaced" | "skipped" (identity discipline — report only)
    | "failed" (INDEX_REPLACE_SOURCE_MEDIA_FAILED emitted)."""
    file_pk = int(row["id"])
    msg = int(row["message_id"])
    old_uid = str(row.get("file_unique_id") or "").strip()
    new_uid = str(info.get("file_unique_id") or "").strip()
    new_fid = str(info.get("file_id") or "").strip()
    new_mtype = str(info.get("media_type") or "").strip()

    def _skip(reason: str) -> str:
        log.info("INDEX_REPLACE_SOURCE_MEDIA_SKIPPED channel_id=%s "
                 "message_id=%s file_pk=%s reason=%s (canonical row "
                 "preserved — report only)", channel_id, msg, file_pk,
                 reason)
        return "skipped"

    def _fail(reason: str) -> str:
        log.info("INDEX_REPLACE_SOURCE_MEDIA_FAILED channel_id=%s "
                 "message_id=%s file_pk=%s reason=%s (canonical row "
                 "preserved — report only)", channel_id, msg, file_pk,
                 reason)
        return "failed"

    if not old_uid:
        return _skip("no_stored_identity (NULL identities belong to the "
                     "identity-repair path, never replacement)")
    if new_uid == old_uid:
        return _skip("same_identity (media-type-only change stays "
                     "report-only)")
    if not new_uid:
        return _fail("missing_fresh_identity (never fabricated)")
    if not new_mtype or new_mtype not in KNOWN_MEDIA_TYPES:
        return _fail("missing_or_invalid_media_type")
    if not new_fid:
        return _fail("missing_fresh_file_id")
    # The NEW identity must not be owned by ANOTHER canonical row.
    owner_check = getattr(deps.db, "get_indexed_file_by_unique_id", None)
    if owner_check is not None:
        try:
            owner = await owner_check(new_uid)
        except Exception as e:  # noqa: BLE001 — guard failure is safe-stop
            return _fail(f"identity_conflict_check_error_{type(e).__name__}")
        if owner is not None:
            try:
                owner_pk = int(owner["id"])
            except (TypeError, ValueError, KeyError, IndexError):
                owner_pk = -1
            if owner_pk != file_pk:
                return _fail(
                    f"identity_conflict (the new file_unique_id is already "
                    f"owned by file_pk={owner_pk})")
    log.info(
        "INDEX_REPLACE_SOURCE_MEDIA_START channel_id=%s message_id=%s "
        "file_pk=%s old_file_unique_id_hash=%s new_file_unique_id_hash=%s",
        channel_id, msg, file_pk, _uid_hash(old_uid), _uid_hash(new_uid))
    swap = getattr(deps.db, "replace_indexed_source_media", None)
    if swap is None:
        return _fail("repo_method_unavailable")
    try:
        replaced = bool(await swap(file_pk, info))
    except Exception as e:  # noqa: BLE001 — replacement never breaks the pass
        return _fail(f"repo_error_{type(e).__name__}")
    if not replaced:
        return _fail("no_row_change (concurrent writer? canonical state "
                     "wins)")
    # The source message clearly EXISTS now — a row that was previously
    # marked unavailable is honestly recovered by the replacement itself
    # (existing repo method, non-destructive).
    if str(row.get("source_status") or "") == "unavailable":
        try:
            await deps.db.mark_indexed_file_source_status(
                file_pk, "available",
                note=f"source media replaced @ {_now_iso()}")
        except Exception as e:  # noqa: BLE001 — best-effort status flip
            log.warning("INDEX_REPLACE_SOURCE_MEDIA_STATUS_ERROR "
                        "file_pk=%s exc=%s", file_pk, type(e).__name__)
    # §5 propagation: payload display_name (origin-aware) + the EXISTING
    # website-label propagation path — one guarded repo call, no
    # duplicated logic in the engine.
    payload_ids, listing_ids = await _propagate_source_rename(
        deps, log, channel_id=channel_id, msg=msg, file_pk=file_pk,
        old_name=row.get("file_name"), new_name=info.get("file_name"))
    log.info(
        "INDEX_REPLACE_SOURCE_MEDIA_COMPLETE channel_id=%s message_id=%s "
        "file_pk=%s old_file_unique_id_hash=%s new_file_unique_id_hash=%s "
        "propagated_payloads=%s propagated_listings=%s result=ok (the "
        "canonical row was updated IN PLACE — file_pk, payload FKs, "
        "website + package associations preserved; no second canonical "
        "source created)",
        channel_id, msg, file_pk, _uid_hash(old_uid), _uid_hash(new_uid),
        len(payload_ids), len(listing_ids))
    _cap(report["source_replaced_detail"],
         f"pk {file_pk} msg {msg} (identity "
         f"{_uid_hash(old_uid)[:8]}->{_uid_hash(new_uid)[:8]})", limit=12)
    return "replaced"


async def _refresh_and_report_source_metadata(
        deps: Deps, log: Any, *, channel_id: int, row: Dict[str, Any],
        info: Dict[str, Any], report: Dict[str, Any], reconcile: bool
        ) -> None:
    """BOT-45 §8 (EDITED FILENAME TEST): compare the CURRENT Telegram
    source metadata against the indexed row and emit
    INDEX_REINDEX_METADATA_CHANGED (the fields that changed) /
    INDEX_REINDEX_METADATA_UNCHANGED (the pin: same file_pk, same
    payload — metadata verified current / refreshed).

    reconcile=True  -> the existing guarded storage refresh
    (refresh_indexed_file_mutable_metadata — identity-immutable columns
    never touched) applies the change in place and the EDITED FILENAME
    is propagated through the existing path (propagate_renamed_
    file_defaults + the origin-aware display refresh).
    reconcile=False -> read-only comparison on the columns this pass's
    row snapshot carries (no writes, same telemetry names, honest
    fields_checked)."""
    file_pk = int(row["id"])
    msg = int(row["message_id"])
    if reconcile:
        refresher = getattr(deps.db, "refresh_indexed_file_mutable_metadata",
                            None)
        if refresher is None:
            return
        try:
            changes = dict(await refresher(file_pk, info) or {})
        except Exception as e:  # noqa: BLE001 — refresh never breaks the pass
            log.warning("INDEX_REINDEX_METADATA_REFRESH_ERROR "
                        "channel_id=%s message_id=%s file_pk=%s exc=%s",
                        channel_id, msg, file_pk, type(e).__name__)
            return
        if not changes:
            report["reindex_metadata_unchanged"] += 1
            log.info(
                "INDEX_REINDEX_METADATA_UNCHANGED channel_id=%s "
                "message_id=%s file_pk=%s fields_checked=%s "
                "file_pk_preserved=1 payload_preserved=1 (source metadata "
                "already current)", channel_id, msg, file_pk,
                ",".join(_MUTABLE_META_COLUMNS))
            return
        report["reindex_metadata_changed"] += 1
        log.info(
            "INDEX_REINDEX_METADATA_CHANGED channel_id=%s message_id=%s "
            "file_pk=%s fields=%s file_pk_preserved=1 payload_preserved=1 "
            "(metadata refreshed in place from the current source)",
            channel_id, msg, file_pk, ",".join(sorted(changes.keys())))
        if "file_name" in changes:
            old_name, new_name = changes["file_name"]
            await _propagate_source_rename(
                deps, log, channel_id=channel_id, msg=msg, file_pk=file_pk,
                old_name=old_name, new_name=new_name)
        return
    # Read-only pass: compare ONLY what the row snapshot carries; a
    # field the fresh fetch did not provide is NOT compared (never a
    # phantom 'changed' verdict), and nothing is written.
    changed: List[str] = []
    for field in ("file_name", "file_size"):
        fresh = info.get(field)
        if fresh is None:
            continue
        if _meta_field_differs(row.get(field), fresh):
            changed.append(field)
    if not changed:
        report["reindex_metadata_unchanged"] += 1
        log.info(
            "INDEX_REINDEX_METADATA_UNCHANGED channel_id=%s message_id=%s "
            "file_pk=%s fields_checked=file_name,file_size "
            "file_pk_preserved=1 payload_preserved=1 (read-only pass — "
            "source metadata matches)", channel_id, msg, file_pk)
    else:
        report["reindex_metadata_changed"] += 1
        log.info(
            "INDEX_REINDEX_METADATA_CHANGED channel_id=%s message_id=%s "
            "file_pk=%s fields=%s (read-only pass — run Reconcile to "
            "refresh in place)", channel_id, msg, file_pk,
            ",".join(changed))


async def run_verification(deps: Deps, bot: Any, admin_id: int,
                           channel_id: int, *,
                           reconcile: bool = False,
                           status_cb: Optional[Callable[[str], Awaitable[None]]] = None
                           ) -> Dict[str, Any]:
    """Execute the full verification (+ optional reconciliation) for one
    storage channel. Returns the report dict (also persisted by caller)."""
    log = deps.logger
    report = _new_report(channel_id)
    ch = await deps.db.get_storage_channel(channel_id)
    title = (ch["title"] if ch else None) or f"Channel {channel_id}"
    log.info("INDEX_VERIFY_START channel_id=%s reconcile=%s", channel_id,
             1 if reconcile else 0)

    async def _progress(text: str) -> None:
        if status_cb is not None:
            try:
                await status_cb(text)
            except Exception:  # noqa: BLE001 — progress is best-effort
                pass

    # ------------------------------------------------------------------
    # Phase A — live-source discovery walk (latest -> 1, read-only).
    # ------------------------------------------------------------------
    await _progress(
        f"\U0001F50D Verifying Index — {title}\n\n"
        f"Phase 1/3: determining channel boundaries…")
    latest = await deps.determine_latest(bot, admin_id, channel_id)
    if latest is None:
        report["status"] = VERIFY_STATUS_FAILED
        report["coverage"] = "none"
        report["coverage_note"] = ("could not determine the latest message "
                                   "(channel empty or inaccessible)")
        report["finished_at"] = _now_iso()
        log.warning("INDEX_VERIFY_FAILED channel_id=%s reason=latest_unknown",
                    channel_id)
        return report
    report["latest_message_id"] = int(latest)
    # V25 §5: the walk must start at/above the DB's own highest indexed
    # message id — anything less *may* be a truncated walk
    # (gap-truncation class). The seeded determine_latest guarantees this
    # when the seed probe works. The VERDICT is deferred to the Phase-B
    # targeted probes: a DB record above the walk range that is CONFIRMED
    # missing is a dead orphan (everything live was still walked —
    # coverage stays honest/full; the row is never deleted, so a
    # numeric-only rule would report partial forever on a reconciled
    # channel); one found LIVE above the range PROVES the walk was
    # truncated; an unverifiable one keeps the report conservative.
    try:
        _db_max = int(await deps.db.max_message_id_for_channel(channel_id) or 0)
    except Exception:  # noqa: BLE001 — repository read is best-effort
        _db_max = 0
    _above_latest_suspected = _db_max > int(latest)
    _above_latest_live = 0
    _above_latest_dead = 0
    _above_latest_unknown = 0

    live: Dict[int, Dict[str, Any]] = {}
    live_by_uid: Dict[str, int] = {}
    consec_missing = 0
    msg_id = int(latest)
    scanned = 0
    gap_stop = None
    while msg_id >= 1 and scanned < VERIFY_RUNAWAY_GUARD:
        if consec_missing >= VERIFY_MAX_CONSEC_MISSING:
            gap_stop = msg_id
            break
        try:
            info, fwd_mid = await deps.fetch_channel_media(
                bot, admin_id, channel_id, msg_id)
            if fwd_mid:
                try:
                    await bot.delete_message(admin_id, fwd_mid)
                except Exception:  # noqa: BLE001 — cleanup is best-effort
                    pass
            if info is None and fwd_mid is None:
                report["missing"] += 1
                consec_missing += 1
            else:
                consec_missing = 0
                if info:
                    report["media_messages"] += 1
                    live[msg_id] = info
                    uid = info.get("file_unique_id")
                    if uid:
                        live_by_uid[str(uid)] = msg_id
                else:
                    report["no_media"] += 1
        except Exception as e:  # noqa: BLE001 — classified, never fatal here
            # A Telegram error is an ERROR — never a 'missing' verdict.
            report["errors"] += 1
            consec_missing = 0
            log.warning("INDEX_VERIFY_WALK_ERROR channel_id=%s message_id=%s "
                        "exc=%s", channel_id, msg_id, type(e).__name__)
        scanned += 1
        report["messages_scanned"] = scanned
        if scanned % VERIFY_PROGRESS_EVERY == 0:
            await _progress(
                f"\U0001F50D Verifying Index — {title}\n\n"
                f"Phase 1/3: walking source history…\n"
                f"Scanned: {scanned} / {latest} messages\n"
                f"Live media found: {report['media_messages']}")
        msg_id -= 1
    if gap_stop is not None:
        report["coverage"] = "partial"
        report["coverage_note"] = (
            f"history gap: {VERIFY_MAX_CONSEC_MISSING} consecutive missing "
            f"messages at/above id {gap_stop} — messages below the gap were "
            f"NOT walk-verified (targeted probes still ran for DB records)")
        log.info("INDEX_VERIFY_PARTIAL_WALK channel_id=%s gap_stop=%s",
                 channel_id, gap_stop)
    # V25 §5 walk-truncation suspicion is recorded ABOVE (pre-walk) and its
    # VERDICT is deferred to the post-probe block — a numeric-only
    # `_db_max > latest` downgrade here would permanently misreport a
    # reconciled channel (confirmed-dead orphans are never deleted).

    # ------------------------------------------------------------------
    # Phase B — DB snapshot + targeted orphan probes.
    # ------------------------------------------------------------------
    await _progress(
        f"\U0001F50D Verifying Index — {title}\n\n"
        f"Phase 2/3: cross-checking {report['media_messages']} live media "
        f"vs database…")
    db_rows = _rows_to_dicts(
        await deps.db.verification_channel_rows(channel_id))
    report["db_total"] = len(db_rows)
    by_msg: Dict[int, Dict[str, Any]] = {int(r["message_id"]): r for r in db_rows}

    for msg, info in live.items():
        row = by_msg.get(msg)
        uid = str(info.get("file_unique_id") or "")
        if row is None and uid and uid not in {
                str(r.get("file_unique_id") or "") for r in db_rows}:
            # Live media with no DB record at this message AND no record
            # carrying the same identity elsewhere.
            report["source_missing_from_db"] += 1
            _cap(report["source_missing_from_db_detail"],
                 f"msg {msg} ({info.get('media_type')})")

    orphans: List[Tuple[Dict[str, Any], str]] = []
    source_changed: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    stale_fid_rows: List[Tuple[Dict[str, Any], str]] = []
    recovered_candidates: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    # BOT-45 §8: same-identity (row, live_info) pairs — the reindex
    # metadata comparison set for Phase D step 6.
    metadata_rows: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    for row in db_rows:
        msg = int(row["message_id"])
        status = row.get("source_status")
        if status == "unavailable":
            report["db_unavailable"] += 1
        else:
            report["db_available"] += 1
        live_info = live.get(msg)
        if live_info is not None:
            # Source exists at the recorded message.
            uid_live = str(live_info.get("file_unique_id") or "")
            uid_db = str(row.get("file_unique_id") or "")
            type_live = live_info.get("media_type")
            type_db = row.get("media_type")
            if uid_db and uid_live and uid_db != uid_live:
                # The source message now hosts a DIFFERENT file. Identity
                # discipline: NEVER touch the canonical row automatically.
                report["source_changed_identity"] += 1
                _cap(report["source_changed_identity_detail"],
                     f"pk {row['id']} msg {msg}")
                source_changed.append((row, live_info))
            elif type_db != type_live:
                report["source_changed_identity"] += 1
                _cap(report["source_changed_identity_detail"],
                     f"pk {row['id']} msg {msg} (type {type_db}->{type_live})")
                source_changed.append((row, live_info))
            else:
                metadata_rows.append((row, live_info))
                fid_live = live_info.get("file_id")
                fid_db = row.get("file_id")
                if fid_live and fid_db and fid_live != fid_db:
                    stale_fid_rows.append((row, str(fid_live)))
                if status == "unavailable":
                    recovered_candidates.append((row, live_info))
            continue
        # Not seen live (below a gap, or genuinely gone): probe individually.
        _above_walk_range = _above_latest_suspected and msg > int(latest)
        try:
            verdict = await deps.probe_message_exists(
                bot, admin_id, channel_id, msg)
        except Exception as e:  # noqa: BLE001
            log.warning("INDEX_VERIFY_PROBE_ERROR channel_id=%s message_id=%s "
                        "exc=%s", channel_id, msg, type(e).__name__)
            report["errors"] += 1
            if _above_walk_range:
                _above_latest_unknown += 1
            continue
        if verdict is None:
            report["errors"] += 1   # transient — NOT concluded missing
            if _above_walk_range:
                _above_latest_unknown += 1
            continue
        if verdict is False:
            report["orphaned_records"] += 1
            _cap(report["orphaned_records_detail"], f"pk {row['id']} msg {msg}")
            orphans.append((row, "missing"))
            if _above_walk_range:
                _above_latest_dead += 1
        else:
            # Message exists but the walk did not see it (below a gap, or
            # no-media/protected outcome). Fetch its real content once so
            # the verdict is precise.
            if _above_walk_range:
                _above_latest_live += 1
            try:
                info2, fwd2 = await deps.fetch_channel_media(
                    bot, admin_id, channel_id, msg)
                if fwd2:
                    try:
                        await bot.delete_message(admin_id, fwd2)
                    except Exception:  # noqa: BLE001
                        pass
                if info2:
                    uid_live = str(info2.get("file_unique_id") or "")
                    uid_db = str(row.get("file_unique_id") or "")
                    if uid_db and uid_live and uid_db != uid_live:
                        report["source_changed_identity"] += 1
                        _cap(report["source_changed_identity_detail"],
                             f"pk {row['id']} msg {msg}")
                        source_changed.append((row, info2))
                    else:
                        metadata_rows.append((row, info2))
                        fid_live = info2.get("file_id")
                        if fid_live and row.get("file_id") and \
                                fid_live != row.get("file_id"):
                            stale_fid_rows.append((row, str(fid_live)))
                        if status == "unavailable":
                            recovered_candidates.append((row, info2))
                else:
                    # Message exists but has no media anymore.
                    report["orphaned_records"] += 1
                    _cap(report["orphaned_records_detail"],
                         f"pk {row['id']} msg {msg} (no media)")
                    orphans.append((row, "no_media"))
            except Exception as e:  # noqa: BLE001
                report["errors"] += 1
                log.warning("INDEX_VERIFY_RECHECK_ERROR channel_id=%s "
                            "message_id=%s exc=%s", channel_id, msg,
                            type(e).__name__)
                # NOTE: no _above_latest_unknown here — the probe already
                # proved the message EXISTS above the walk range, which is
                # the decisive truncation evidence regardless of whether
                # the content recheck succeeded.

    # Deferred walk-truncation verdict (V25 §5): decide from probe
    # EVIDENCE, not from the raw id comparison — a channel whose only
    # above-latest DB rows are confirmed-dead orphans converges back to
    # an honest coverage=full after reconciliation (rows are never
    # deleted, so a numeric-only rule would report partial forever).
    if _above_latest_suspected:
        if _above_latest_live or _above_latest_unknown:
            report["coverage"] = "partial"
            if _above_latest_live:
                report["coverage_note"] = (
                    f"walk stopped at message {latest} but "
                    f"{_above_latest_live} DB-recorded message(s) above "
                    f"the walk range were found LIVE (gap-truncated "
                    f"discovery — db_max={_db_max}); re-run after fixing "
                    f"the channel history")
            else:
                report["coverage_note"] = (
                    f"the database indexes message {_db_max} above the "
                    f"walk range ({latest}) and {_above_latest_unknown} "
                    f"could not be verified right now (transient Telegram "
                    f"errors) — re-run to confirm")
            log.warning(
                "INDEX_VERIFY_WALK_TRUNCATED channel_id=%s latest=%s "
                "db_max=%s above_live=%s above_unknown=%s above_dead=%s",
                channel_id, latest, _db_max, _above_latest_live,
                _above_latest_unknown, _above_latest_dead)
        else:
            log.info(
                "INDEX_VERIFY_ABOVE_LATEST_ALL_DEAD channel_id=%s "
                "latest=%s db_max=%s above_dead=%s (confirmed orphans — "
                "coverage stays full; the walk covered every live message)",
                channel_id, latest, _db_max, _above_latest_dead)

    report["stale_file_ids"] = len(stale_fid_rows)

    # ------------------------------------------------------------------
    # Phase C — pure database cross-matrix.
    # ------------------------------------------------------------------
    dup_ident = _rows_to_dicts(
        await deps.db.verification_duplicate_identities())
    report["duplicate_identities"] = len(dup_ident)
    null_dups = _rows_to_dicts(
        await deps.db.verification_null_identity_duplicates())
    report["null_identity_duplicates"] = len(null_dups)
    report["null_identities"] = sum(
        1 for r in db_rows if not r.get("file_unique_id"))
    broken = _rows_to_dicts(
        await deps.db.verification_broken_payload_refs(50))
    report["broken_payload_refs"] = len(broken)
    for b in broken:
        _cap(report["broken_payload_refs_detail"],
             f"payload '{b['payload']}' -> index_id {b['index_id']}")
    on_unavail_c = await deps.db.verification_payloads_on_unavailable()
    report["payloads_on_unavailable"] = on_unavail_c
    # BOT-45 §8 (Task E): the count keeps its exact semantics — every
    # record in THIS channel's verification scope now also carries a
    # per-record diagnostic line + PAYLOAD_ON_UNAVAILABLE telemetry.
    await _diagnose_payloads_on_unavailable(
        deps, log, report, channel_id, db_rows,
        {int(r["id"]): why for (r, why) in orphans},
        {int(r["id"]) for (r, _i) in recovered_candidates},
        {int(r["id"]) for (r, _i) in source_changed})
    cross_c = await deps.db.verification_cross_channel_orphans()
    report["cross_channel_orphans"] = cross_c
    report["invalid_file_ids"] = sum(
        1 for r in db_rows if not r.get("file_id"))
    report["invalid_media_types"] = sum(
        1 for r in db_rows
        if r.get("media_type") not in KNOWN_MEDIA_TYPES)
    if deps.current_bot_id is not None and \
            deps.file_id_owner_bot_id is not None and \
            int(deps.current_bot_id) != int(deps.file_id_owner_bot_id):
        report["epoch_stale"] = True

    # ------------------------------------------------------------------
    # Phase D — reconciliation (guarded, non-destructive).
    # ------------------------------------------------------------------
    if reconcile:
        await _progress(
            f"\U0001F50D Verifying Index — {title}\n\n"
            f"Phase 3/3: reconciling…\n"
            f"(indexing missing media, repairing stale file ids, "
            f"marking unavailable sources)")
        # 1) source exists, DB missing -> index it (identity-disciplined).
        for msg, info in live.items():
            row = by_msg.get(msg)
            uid = str(info.get("file_unique_id") or "")
            if row is None and uid and uid not in {
                    str(r.get("file_unique_id") or "") for r in db_rows}:
                try:
                    outcome, _ = await deps.index_one_message(
                        bot, admin_id, channel_id, msg)
                    if outcome == "indexed":
                        report["reconciled_indexed"] += 1
                    elif outcome == "duplicate":
                        report["reconciled_indexed"] += 1  # became indexed via dedup repair
                    else:
                        report["reconcile_failed"] += 1
                except Exception as e:  # noqa: BLE001
                    report["reconcile_failed"] += 1
                    log.warning("INDEX_VERIFY_RECONCILE_INDEX_ERROR "
                                "channel_id=%s message_id=%s exc=%s",
                                channel_id, msg, type(e).__name__)
        # 2) DB exists, source exists, stale file_id -> atomic in-place repair.
        for row, fid_live in stale_fid_rows:
            try:
                ok = await deps.db.repair_indexed_file_file_id(
                    int(row["id"]), fid_live)
                if ok:
                    report["reconciled_repaired"] += 1
                else:
                    report["reconcile_failed"] += 1
            except Exception as e:  # noqa: BLE001
                report["reconcile_failed"] += 1
                log.warning("INDEX_VERIFY_RECONCILE_REPAIR_ERROR pk=%s exc=%s",
                            row.get("id"), type(e).__name__)
        # 3) DB exists, source permanently gone -> mark unavailable
        #    (NEVER delete; payload references untouched).
        for row, why in orphans:
            try:
                await deps.db.mark_indexed_file_source_status(
                    int(row["id"]), "unavailable",
                    note=f"verification {why} @ {_now_iso()}")
                report["reconciled_marked_unavailable"] += 1
            except Exception as e:  # noqa: BLE001
                report["reconcile_failed"] += 1
                log.warning("INDEX_VERIFY_RECONCILE_UNAVAILABLE_ERROR pk=%s "
                            "exc=%s", row.get("id"), type(e).__name__)
        # 4) previously-unavailable rows whose source is back -> recover.
        for row, info in recovered_candidates:
            try:
                await deps.db.mark_indexed_file_source_status(
                    int(row["id"]), "available", note=f"recovered @ {_now_iso()}")
                fid_live = info.get("file_id")
                if fid_live and fid_live != row.get("file_id"):
                    await deps.db.repair_indexed_file_file_id(
                        int(row["id"]), str(fid_live))
                report["reconciled_recovered"] += 1
            except Exception as e:  # noqa: BLE001
                report["reconcile_failed"] += 1
                log.warning("INDEX_VERIFY_RECONCILE_RECOVER_ERROR pk=%s exc=%s",
                            row.get("id"), type(e).__name__)
        # 5) BOT-45 §7 (Task E) — same (channel_id, message_id) now hosts
        #    NEW media (new file_unique_id — previously only recorded as
        #    source_changed_identity): guarded IN-PLACE source media
        #    replacement. file_pk, payload FKs, website associations and
        #    package associations are PRESERVED (UPDATE in place — never
        #    a second canonical source, nothing deleted). The ONLY
        #    accepted evidence is the authoritative Telegram fetch this
        #    engine performed; a missing fresh identity is REJECTED,
        #    never fabricated.
        for row, info in source_changed:
            try:
                outcome = await _replace_source_media_in_place(
                    deps, log, channel_id=channel_id, row=row, info=info,
                    report=report)
            except Exception as e:  # noqa: BLE001 — never breaks the pass
                log.warning("INDEX_VERIFY_RECONCILE_REPLACE_ERROR pk=%s "
                            "exc=%s", row.get("id"), type(e).__name__)
                outcome = "failed"
            if outcome == "replaced":
                report["source_replaced"] += 1
            elif outcome == "failed":
                report["reconcile_failed"] += 1
            # "skipped": identity discipline — report-only; the
            # source_changed_identity counter already carries it.
        # 6) BOT-45 §8 (Task E) — same identity, EDITED source metadata:
        #    refresh the MUTABLE metadata in place (identity-immutable
        #    columns never touched), emit the reindex comparison result
        #    (INDEX_REINDEX_METADATA_CHANGED / _UNCHANGED) and propagate
        #    source-derived display names + website labels.
        for row, info in metadata_rows:
            await _refresh_and_report_source_metadata(
                deps, log, channel_id=channel_id, row=row, info=info,
                report=report, reconcile=True)
    else:
        # Read-only pass: the SAME metadata comparison with honest
        # telemetry and NO writes (the columns this pass's row snapshot
        # actually carries; Reconcile applies the refresh).
        for row, info in metadata_rows:
            await _refresh_and_report_source_metadata(
                deps, log, channel_id=channel_id, row=row, info=info,
                report=report, reconcile=False)

    # ------------------------------------------------------------------
    # Terminal status — honest coverage semantics.
    # ------------------------------------------------------------------
    if report["errors"] > 0 and report["messages_scanned"] == 0:
        report["status"] = VERIFY_STATUS_FAILED
    elif gap_stop is not None or report["coverage"] == "partial":
        report["status"] = VERIFY_STATUS_PARTIAL
    elif report["errors"] > 0:
        report["status"] = VERIFY_STATUS_PARTIAL
    else:
        report["status"] = VERIFY_STATUS_COMPLETE
    report["finished_at"] = _now_iso()
    log.info(
        "INDEX_VERIFY_COMPLETE channel_id=%s status=%s coverage=%s "
        "messages_scanned=%s media=%s db_total=%s source_missing_from_db=%s "
        "orphans=%s stale_fids=%s changed_identity=%s dup_identity=%s "
        "null_identity=%s broken_payload_refs=%s payloads_on_unavailable=%s "
        "cross_channel=%s invalid_fids=%s invalid_types=%s epoch_stale=%s "
        "reconciled(indexed=%s repaired=%s unavailable=%s recovered=%s "
        "failed=%s) source_replaced=%s reindex_meta_changed=%s "
        "reindex_meta_unchanged=%s",
        channel_id, report["status"], report["coverage"],
        report["messages_scanned"], report["media_messages"],
        report["db_total"], report["source_missing_from_db"],
        report["orphaned_records"], report["stale_file_ids"],
        report["source_changed_identity"], report["duplicate_identities"],
        report["null_identities"], report["broken_payload_refs"],
        report["payloads_on_unavailable"], report["cross_channel_orphans"],
        report["invalid_file_ids"], report["invalid_media_types"],
        1 if report["epoch_stale"] else 0,
        report["reconciled_indexed"], report["reconciled_repaired"],
        report["reconciled_marked_unavailable"],
        report["reconciled_recovered"], report["reconcile_failed"],
        report["source_replaced"], report["reindex_metadata_changed"],
        report["reindex_metadata_unchanged"])
    return report


def render_report(report: Dict[str, Any], title: str,
                  *, reconcile: bool) -> str:
    """Render the verification report as admin-facing plain text.

    The status line is truthful: 'SUCCESS' only for a FULL, error-free scan
    (spec §28 — never report success for a partial verification)."""
    status = report.get("status", VERIFY_STATUS_FAILED)
    if status == VERIFY_STATUS_COMPLETE:
        head = "\u2705 Verification Complete (full scan)"
    elif status == VERIFY_STATUS_PARTIAL:
        head = "\u26A0\uFE0F Verification Complete — PARTIAL COVERAGE"
        if report.get("coverage_note"):
            head += f"\n{report['coverage_note']}"
    else:
        head = "\u274C Verification FAILED"
        if report.get("coverage_note"):
            head += f"\n{report['coverage_note']}"
    if reconcile and report.get("source_replaced", 0):
        ident_note = (f"in-place replacement applied: "
                      f"{report['source_replaced']}")
    else:
        ident_note = "canonical preserved"
    lines = [
        f"{head}",
        "",
        f"\U0001F4E1 Channel: {title}",
        f"\u23F1 Started: {str(report.get('started_at', '-'))[:19]}",
        f"\u23F1 Finished: {str(report.get('finished_at', '-') or '-')[:19]}",
        "",
        "\U0001F4CB SOURCE vs DATABASE",
        f"  Messages scanned: {report.get('messages_scanned', 0)}",
        f"  Live media found: {report.get('media_messages', 0)}",
        f"  No-media messages: {report.get('no_media', 0)}",
        f"  DB records (channel): {report.get('db_total', 0)} "
        f"(available {report.get('db_available', 0)}, "
        f"unavailable {report.get('db_unavailable', 0)})",
        f"  Source media missing from DB: "
        f"{report.get('source_missing_from_db', 0)}",
        f"  DB records with source gone (orphans): "
        f"{report.get('orphaned_records', 0)}",
        f"  Source now hosts a different file: "
        f"{report.get('source_changed_identity', 0)} ({ident_note})",
        f"  Source metadata (reindex comparison): "
        f"{report.get('reindex_metadata_changed', 0)} changed / "
        f"{report.get('reindex_metadata_unchanged', 0)} unchanged "
        f"(file_pk + payload survive)",
        "",
        "\U0001F9EA INTEGRITY",
        f"  Stale file_ids (vs live source): {report.get('stale_file_ids', 0)}",
        f"  Invalid/missing file_ids: {report.get('invalid_file_ids', 0)}",
        f"  Duplicate identities: {report.get('duplicate_identities', 0)}",
        f"  NULL-identity rows: {report.get('null_identities', 0)} "
        f"(dup pairs: {report.get('null_identity_duplicates', 0)})",
        f"  Invalid media types: {report.get('invalid_media_types', 0)}",
        f"  Cross-channel orphan records: "
        f"{report.get('cross_channel_orphans', 0)}",
        f"  Broken payload references: "
        f"{report.get('broken_payload_refs', 0)}",
        f"  Payloads on unavailable files: "
        f"{report.get('payloads_on_unavailable', 0)}",
        f"  File-ID epoch stale (bot token changed): "
        f"{'YES — run Full Reindex to refresh' if report.get('epoch_stale') else 'no'}",
        f"  Errors during verification: {report.get('errors', 0)}",
    ]
    # BOT-45 §8 (Task E): the payloads_on_unavailable count line keeps its
    # exact name/format — every diagnosed record now carries its own
    # diagnostic line (payload_id, file_pk, message_id, availability,
    # exact reason).
    unavail_detail = report.get("payloads_on_unavailable_detail") or []
    if unavail_detail:
        lines.append("  Diagnostics (payloads on unavailable sources):")
        for item in unavail_detail[:10]:
            lines.append(f"    {item}")
        if len(unavail_detail) > 10:
            lines.append(f"    (+{len(unavail_detail) - 10} more)")
    for key, cap in (("source_missing_from_db_detail", 8),
                     ("orphaned_records_detail", 8),
                     ("source_changed_identity_detail", 6),
                     ("broken_payload_refs_detail", 6),
                     ("source_replaced_detail", 6)):
        detail = report.get(key) or []
        if detail:
            lines.append("  e.g. " + ", ".join(detail[:cap]))
    if reconcile:
        lines += [
            "",
            "\U0001F527 RECONCILIATION (non-destructive)",
            f"  Indexed missing media: {report.get('reconciled_indexed', 0)}",
            f"  File ids repaired in place: "
            f"{report.get('reconciled_repaired', 0)}",
            f"  Marked unavailable (source gone): "
            f"{report.get('reconciled_marked_unavailable', 0)}",
            f"  Recovered (source back): "
            f"{report.get('reconciled_recovered', 0)}",
            f"  Source media replaced in place (new identity): "
            f"{report.get('source_replaced', 0)}",
            f"  Reconciliation failures: {report.get('reconcile_failed', 0)}",
            "",
            "\u2139\uFE0F Nothing was deleted. Payload relationships were "
            "never modified.",
        ]
    else:
        lines += [
            "",
            "\u2139\uFE0F Read-only verification — nothing was changed. "
            "Run Reconcile to apply the safe repairs.",
        ]
    return "\n".join(lines)


__all__ = [
    "Deps", "run_verification", "render_report",
    "VERIFY_STATUS_COMPLETE", "VERIFY_STATUS_PARTIAL",
    "VERIFY_STATUS_FAILED", "VERIFY_STATUS_RUNNING",
    "VERIFY_MAX_CONSEC_MISSING", "KNOWN_MEDIA_TYPES",
]
