"""MANAGED BOTS (v37, Task 8) — Telegram managed-bot creation coordination.

STANDALONE MODULE — never imports ``app.presentation.*`` (the same
discipline as every other ``app/network/*`` module). All presentation
collaborators (``safe_send_text`` / ``safe_edit_text``, the My Network
panel, conversation-state helpers, the token-validation transport) are
resolved through the injected runtime namespace ``ns`` AT CALL TIME —
exactly the late-binding contract ``app/network/lifecycle.py`` uses.

What this module owns
---------------------
* ``begin_managed_creation`` — the PRIMARY Create Network Bot path: a
  REPLY keyboard carrying ``telegram.KeyboardButtonRequestManagedBot``
  (Telegram's own managed-bot creation UI — no BotFather, no token
  pasting) + a pending state (``nmg_pending``) in ``context.user_data``
  stamped with a fresh timestamp and a per-creation unique
  ``request_id``.
* ``handle_managed_bot_created`` — the ``Message.managed_bot_created``
  service-message handler: fetches the new bot's token server-side via
  ``Bot.get_managed_bot_token`` (NEVER logged, never displayed),
  validates with the SAME direct getMe transport the registry uses, and
  registers through ``BotRegistryService.attempt_registration`` as
  PLATFORM_MANAGED / created_via="managed_bot_flow". Orphan, expired
  and wrong-owner service messages are politely ignored (replay-safe).
* ``handle_managed_bot_updated`` — the ``Update.managed_bot``
  (``telegram.ManagedBotUpdated``) handler: redacted-id logging + a
  control audit event when the affected bot is registered; completes a
  token replacement we initiated.
* ``replace_managed_bot_token_atomic`` — the ADMIN token replacement
  for PLATFORM_MANAGED bots: ``Bot.replace_managed_bot_token`` → getMe
  validation (identity match) → vault encrypt (fail-closed) → atomic
  credential swap → worker restart + health check. ANY failure BEFORE
  the swap leaves the known-good stored credential byte-identical.
* ``capability_status`` / ``log_managed_bots_ready`` — the truthful
  ``User.can_manage_bots`` diagnostic (True/False/None).
* ``send_setup_wizard`` / ``run_setup_verification`` /
  ``handle_setup_wizard_callback`` — BOT-45/46 Task H (master prompt
  §4): after CREATE NETWORK BOT / ATTACH BOT TOKEN the admin receives
  the COMPLETE 6-step operational setup wizard (created/attached
  identity → add to channel → the permissions the implementation
  ACTUALLY requires → the precise server-verification states →
  channel configuration → a REAL safe server-side membership test →
  "✓ Network Bot Ready" or a precise actionable error state) with
  ``NETWORK_BOT_SETUP_*`` telemetry wired into the verification flow
  (safe fields only — never tokens).

Token security (same contract as registry.py/credentials.py): the
plaintext token exists transiently in memory only; it is never logged,
never echoed, never displayed. Logs carry masked ids only.
"""
from __future__ import annotations

import asyncio
import logging
import secrets
import threading
import time
from typing import Any, Dict, Optional, Tuple

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    KeyboardButtonRequestManagedBot,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

try:  # PTB >= 21.5 native copy buttons (verified present in 22.8)
    from telegram import CopyTextButton
except ImportError:  # pragma: no cover — older PTB without copy buttons
    CopyTextButton = None  # type: ignore[assignment]

from app.core.constants import (
    NET_BOT_CB,
    NET_CREATE_CB,
    NET_DEFAULT_MAX_BOTS,
    NET_LEGACY_CB,
    NET_MANAGED_CB,
    NET_REG_CB,
    NET_SETTING_ENABLED,
    NET_SETTING_MAX_BOTS,
)

logger = logging.getLogger("app.network.managed_bots")

# ----------------------------------------------------------------------
# Pending-creation state (context.user_data). The KEY string is mirrored
# in app/presentation/telegram/state.py CONVERSATION_INPUT_STATE_KEYS so
# the v36 hygiene purges it on every non-entry callback navigation.
# ----------------------------------------------------------------------
MANAGED_BOT_PENDING_STATE_KEY = "nmg_pending"

# The managed-bot creation window mirrors the v36 conversation timeout
# (10 minutes). Expired pending states are ignored + dropped.
MANAGED_BOT_FLOW_TIMEOUT_SECONDS: float = 600.0

MGMT_PLATFORM_MANAGED = "PLATFORM_MANAGED"
CREDENTIAL_CONTROL_PLATFORM = "PLATFORM"
CREATED_VIA_MANAGED_FLOW = "managed_bot_flow"

# Registration audit event names (control_audit_events — no secrets).
EVT_MANAGED_BOT_CREATED = "MANAGED_BOT_CREATED"
EVT_MANAGED_BOT_REGISTERED = "MANAGED_BOT_REGISTERED"
EVT_MANAGED_BOT_UPDATED = "MANAGED_BOT_UPDATED"
EVT_MANAGED_BOT_TOKEN_REPLACED = "MANAGED_BOT_TOKEN_REPLACED"
EVT_MANAGED_BOT_TOKEN_REPLACED_CONFIRMED = (
    "MANAGED_BOT_TOKEN_REPLACED_CONFIRMED")

# ----------------------------------------------------------------------
# request_id allocation — unique per pending creation (signed 32-bit).
# Random start + strictly monotonic increments: two begins can never
# collide, and the id survives process restarts statistically.
# ----------------------------------------------------------------------
_request_id_lock = threading.Lock()
_REQUEST_ID_MAX = 2 ** 31 - 2
_request_id_next: int = secrets.randbelow(1 << 30) + 1

# Token replacements WE initiated (bot telegram id -> epoch). A
# subsequent Update.managed_bot for the same bot completes the flow.
_pending_token_replacements: Dict[int, float] = {}
_PENDING_REPLACE_TTL = 300.0


def next_managed_bot_request_id() -> int:
    """A unique signed-32-bit request_id for the next pending creation."""
    global _request_id_next
    with _request_id_lock:
        rid = int(_request_id_next)
        _request_id_next = rid + 1 if rid < _REQUEST_ID_MAX else 1
    return rid


def _now() -> float:
    return time.time()


# ----------------------------------------------------------------------
# Small ns-resolution helpers (never import the presentation layer —
# resolve collaborators through the injected namespace at CALL time).
# ----------------------------------------------------------------------
def _ns_get(ns, name: str, default=None):
    try:
        return getattr(ns, name, default)
    except Exception:  # noqa: BLE001
        return default


async def _ns_call(ns, name: str, *args, default=None, **kwargs):
    """Call an optional async-or-plain ns collaborator (keyword-only
    ``default`` is the fallback for a missing/unhealthy collaborator and
    is NEVER forwarded to the callee)."""
    fn = _ns_get(ns, name)
    if not callable(fn):
        return default
    try:
        res = fn(*args, **kwargs)
        if hasattr(res, "__await__"):
            res = await res
        return res
    except Exception:  # noqa: BLE001 — UI/diagnostic helpers must never crash the flow
        return default


def _ns_call_sync(ns, name: str, *args, default=None):
    """Call an optional SYNCHRONOUS ns collaborator; missing → default."""
    fn = _ns_get(ns, name)
    if not callable(fn):
        return default
    try:
        return fn(*args)
    except Exception:  # noqa: BLE001
        return default


def _origin_back(ns, context) -> str:
    """Origin-aware Back callback (v36 §4): the panel the wizard was
    opened from ("" = user surface → My Network)."""
    origin = _ns_call_sync(ns, "get_net_wizard_origin", context, default="")
    return str(origin or "") or f"{NET_REG_CB}back"


async def _is_admin(ns, user_id: int) -> bool:
    res = await _ns_call(ns, "is_admin", int(user_id), default=False)
    if res is not None:
        return bool(res)
    admins = _ns_get(ns, "ADMIN_IDS", None) or []
    try:
        return int(user_id) in [int(a) for a in admins]
    except Exception:  # noqa: BLE001
        return False


def _pending_expired(state: Optional[dict],
                     now: Optional[float] = None) -> bool:
    """True when the pending state's stamp is older than 10 minutes
    (mirrors state._conversation_state_expired semantics: unstamped
    states never expire — legacy mid-flow safety)."""
    if not isinstance(state, dict):
        return False
    try:
        ts = float(state.get("ts") or state.get("stamp") or 0)
    except (TypeError, ValueError):
        return False
    if ts <= 0:
        return False
    return (now if now is not None else _now()) - ts \
        > MANAGED_BOT_FLOW_TIMEOUT_SECONDS


# ----------------------------------------------------------------------
# NETWORK BOT SETUP WIZARD (BOT-45/46 Task H — master prompt §4).
# After CREATE NETWORK BOT / ATTACH BOT TOKEN the admin receives the
# COMPLETE 6-step operational wizard: (1) created/attached identity,
# (2) add to channel, (3) the permissions the implementation ACTUALLY
# requires (grep-verified against file_delivery.verify_delivery_
# channel: broadcast CHANNEL transport, FDB Administrator + Delete
# Messages, Network Bot membership — nothing invented), (4) the
# precise server-verification states, (5) channel configuration,
# (6) a real safe server-side membership test → "✓ Network Bot
# Ready" or a precise actionable error — with NETWORK_BOT_SETUP_*
# telemetry (safe fields only, NEVER tokens).
# ----------------------------------------------------------------------

# STEP 4 — the precise server-verification states (the §4 contract).
SETUP_STATE_CONNECTED = "connected"
SETUP_STATE_PERMISSION_MISSING = "permission_missing"
SETUP_STATE_NOT_FOUND = "not_found"
SETUP_STATE_TELEGRAM_ERROR = "telegram_error"
SETUP_STATE_TIMEOUT = "timeout"
# Honest wizard-internal states: before the first Verify tap / when no
# server-side probe could execute at all.
SETUP_STATE_PENDING = "pending"
SETUP_STATE_MEMBERSHIP_UNAVAILABLE = "membership_check_unavailable"

# The 8 §4 telemetry events (safe fields only — never tokens).
NETWORK_BOT_SETUP_OPEN = "NETWORK_BOT_SETUP_OPEN"
NETWORK_BOT_CREATED = "NETWORK_BOT_CREATED"
NETWORK_BOT_ATTACHED = "NETWORK_BOT_ATTACHED"
NETWORK_BOT_VERIFY_START = "NETWORK_BOT_VERIFY_START"
NETWORK_BOT_VERIFY_RESULT = "NETWORK_BOT_VERIFY_RESULT"
NETWORK_BOT_CHANNEL_TEST = "NETWORK_BOT_CHANNEL_TEST"
NETWORK_BOT_SETUP_COMPLETE = "NETWORK_BOT_SETUP_COMPLETE"
NETWORK_BOT_SETUP_ERROR = "NETWORK_BOT_SETUP_ERROR"
NETWORK_BOT_SETUP_TELEMETRY_EVENTS: Tuple[str, ...] = (
    NETWORK_BOT_SETUP_OPEN,
    NETWORK_BOT_CREATED,
    NETWORK_BOT_ATTACHED,
    NETWORK_BOT_VERIFY_START,
    NETWORK_BOT_VERIFY_RESULT,
    NETWORK_BOT_CHANNEL_TEST,
    NETWORK_BOT_SETUP_COMPLETE,
    NETWORK_BOT_SETUP_ERROR,
)

# STEP 2 wizard buttons route through NET_BOT_CB sub-actions
# (``nbot:<id>:setup`` / ``nbot:<id>:verify`` — the same sub-action
# namespace as :changetoken/:disable/:enable/:remove). The network_ui
# ``_handle_net_bot_callback`` dispatcher delegates them to
# ``handle_setup_wizard_callback`` (one-line wiring); until that
# delegation lands, unknown sub-actions degrade to the per-bot
# management panel — never a dead button.
NET_BOT_SETUP_ACTION = "setup"
NET_BOT_VERIFY_ACTION = "verify"

# Per-probe bound (asyncio.wait_for) so the STEP 4 timeout state is
# deterministic even when Telegram hangs.
_SETUP_PROBE_TIMEOUT_SECONDS: float = 10.0

# SAFE telemetry fields (the §4 whitelist: bot ids / channel id /
# state / result / reason + opaque diagnostics). Token material can
# NEVER appear: unknown field names are dropped and values are
# scrubbed + length-capped (the managed-bot token only ever lives in
# the transient registration path and is never passed here).
_SETUP_TELEMETRY_SAFE_FIELDS: Tuple[str, ...] = (
    "network_bot_id", "bot_id", "bot_username", "channel_id", "state",
    "result", "reason", "request_id", "created_via", "worker",
    "member_status", "chat_type", "channel_title", "error",
)
_SETUP_TELEMETRY_VALUE_MAX = 120


def _setup_telemetry_scrub(value) -> str:
    text = str(value if value is not None else "").strip()
    if not text:
        return ""
    text = text.replace("\n", " ").replace("\r", " ")
    if len(text) > _SETUP_TELEMETRY_VALUE_MAX:
        text = text[:_SETUP_TELEMETRY_VALUE_MAX]
    return text


def log_network_bot_setup_telemetry(event: str, log=None, **fields) -> str:
    """Emit one NETWORK_BOT_SETUP_* telemetry line.

    SAFE FIELDS ONLY (the §4 whitelist): network_bot_id / bot_id /
    bot_username / channel_id / state / result / reason (+ opaque
    diagnostics). Anything outside the whitelist is dropped — token
    material can never leak through this emitter. Returns the logged
    line (handy for tests)."""
    parts: list = [str(event)]
    for key in _SETUP_TELEMETRY_SAFE_FIELDS:
        if key not in fields:
            continue
        val = _setup_telemetry_scrub(fields[key])
        if val:
            parts.append(f"{key}={val}")
    line = " ".join(parts)
    try:
        (log or logger).info("%s", line)
    except Exception:  # noqa: BLE001 — telemetry is best-effort
        pass
    return line


# §4 ERROR STATES — every one handled separately, each with a NEXT
# ACTION (never a flat "Failed").
NETWORK_BOT_SETUP_ERROR_STATES: Dict[str, Dict[str, str]] = {
    "invalid_token": {
        "title": "Invalid bot token",
        "message": "Telegram rejected this bot credential.",
        "next_action": "Create a fresh credential (Create Network "
                       "Bot, or a new @BotFather token) and attach "
                       "it again.",
    },
    "bot_not_found": {
        "title": "Network Bot not found",
        "message": "This Network Bot is no longer registered on the "
                   "platform.",
        "next_action": "Open My Network and register the bot again.",
    },
    "bot_cannot_access_channel": {
        "title": "Bot cannot access the channel",
        "message": "The Network Bot is not present in the Delivery "
                   "Channel (never added, or removed).",
        "next_action": "Add the bot to the channel as an "
                       "administrator, then tap Verify again.",
    },
    "bot_not_administrator": {
        "title": "Bot is not an administrator",
        "message": "The bot is in the channel but lacks the required "
                   "administrator rights.",
        "next_action": "Open the channel → Administrators → promote "
                       "the bot, then tap Verify again.",
    },
    "channel_not_found": {
        "title": "Channel not found",
        "message": "The Delivery Channel could not be reached — it "
                   "must be a broadcast channel the platform's File "
                   "Delivery Bot can see.",
        "next_action": "Add the File Delivery Bot as administrator of "
                       "the channel, then tap Verify again.",
    },
    "permission_missing": {
        "title": "Permission missing",
        "message": "The File Delivery Bot needs Administrator rights "
                   "with Delete Messages in the Delivery Channel.",
        "next_action": "Open the channel → Administrators → enable "
                       "Delete Messages for the File Delivery Bot, "
                       "then tap Verify again.",
    },
    "telegram_timeout": {
        "title": "Telegram timeout",
        "message": "Telegram did not answer the verification probes "
                   "in time.",
        "next_action": "Tap Verify again in a moment.",
    },
    "telegram_network_failure": {
        "title": "Telegram network failure",
        "message": "The platform could not reach Telegram "
                   "(network/DNS).",
        "next_action": "Wait briefly and tap Verify again.",
    },
    "telegram_error": {
        "title": "Telegram error",
        "message": "Telegram returned an unexpected error during "
                   "verification.",
        "next_action": "Tap Verify again; if it persists, contact "
                       "the platform admin.",
    },
    "membership_check_unavailable": {
        "title": "Membership check unavailable",
        "message": "The server-side membership test could not run "
                   "(the bot's worker is offline or the platform "
                   "verifier is unavailable).",
        "next_action": "Retry once the Network Bot shows ACTIVE, or "
                       "contact the platform admin.",
    },
    "already_configured": {
        "title": "Already configured",
        "message": "This channel is already configured for a Network "
                   "Bot.",
        "next_action": "Use the existing configuration, or choose a "
                       "different channel for this bot.",
    },
    "duplicate_bot": {
        "title": "Duplicate bot",
        "message": "This bot is already registered on the platform.",
        "next_action": "Open My Network → Manage Bot for the "
                       "existing registration.",
    },
    "unauthorized_admin": {
        "title": "Unauthorized",
        "message": "Only the bot's owner (or a platform admin) can "
                   "run this setup action.",
        "next_action": "Ask the bot's owner to complete the setup.",
    },
}


def render_setup_error_state(error_key: str, detail: str = "") -> str:
    """One §4 ERROR STATE as a precise, actionable message — every
    state carries its own next action; NEVER a flat "Failed"."""
    entry = NETWORK_BOT_SETUP_ERROR_STATES.get(str(error_key or ""))
    if entry is None:
        text = ("⛔️ Setup did not complete"
                + (f" ({error_key})" if error_key else "") + ".")
        if detail:
            text += f"\n\n{detail}"
        text += ("\n\n➡️ Next: tap Verify again, or open My Network → "
                 "Manage Bot for diagnostics.")
        return text
    text = f"⛔️ {entry['title']}\n\n{entry['message']}"
    if detail:
        text += f"\n\n{detail}"
    text += f"\n\n➡️ Next: {entry['next_action']}"
    return text


def classify_setup_telegram_error(exc: BaseException) -> Tuple[str, str]:
    """Map a live Telegram exception to ``(STEP 4 server-verification
    state, §4 error-state key)`` — timeout / DNS-network / not-found /
    permission are told apart, never a flat "Failed"."""
    name = type(exc).__name__
    low = str(exc or "").lower()
    if "timed out" in low or "timeout" in low \
            or name in ("TimedOut", "TimeoutError"):
        return SETUP_STATE_TIMEOUT, "telegram_timeout"
    if "chat not found" in low or "chat was deleted" in low:
        return SETUP_STATE_NOT_FOUND, "bot_cannot_access_channel"
    if name == "Forbidden" or "bot was kicked" in low \
            or "bot is not a member" in low or "not a member" in low:
        return SETUP_STATE_NOT_FOUND, "bot_cannot_access_channel"
    if "not enough rights" in low or "kicked" in low:
        return SETUP_STATE_PERMISSION_MISSING, "bot_not_administrator"
    if "dns" in low or name == "NetworkError":
        return SETUP_STATE_TELEGRAM_ERROR, "telegram_network_failure"
    return SETUP_STATE_TELEGRAM_ERROR, "telegram_error"


# The production verification-chain reasons (verify_delivery_channel /
# verify_delivery_group / run_verification) → (STEP 4 state, §4
# error-state key).
_SETUP_VERIFY_REASON_MAP: Dict[str, Tuple[str, str]] = {
    "chat_not_found": (SETUP_STATE_NOT_FOUND, "channel_not_found"),
    "not_a_channel": (SETUP_STATE_NOT_FOUND, "channel_not_found"),
    "not_a_group": (SETUP_STATE_NOT_FOUND, "channel_not_found"),
    "fdb_not_admin": (SETUP_STATE_PERMISSION_MISSING, "permission_missing"),
    "network_bot_not_member": (SETUP_STATE_NOT_FOUND,
                               "bot_cannot_access_channel"),
    "network_bot_not_admin": (SETUP_STATE_PERMISSION_MISSING,
                              "bot_not_administrator"),
    "network_bot_token_invalid": (SETUP_STATE_TELEGRAM_ERROR,
                                  "invalid_token"),
    "bot_not_found": (SETUP_STATE_NOT_FOUND, "bot_not_found"),
    "verifier_unavailable": (SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
                             "membership_check_unavailable"),
    "repo_primitive_missing": (SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
                               "membership_check_unavailable"),
    "network_bot_worker_offline": (SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
                                   "membership_check_unavailable"),
    "fdb_not_operational": (SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
                            "membership_check_unavailable"),
    "group_already_used": (SETUP_STATE_PERMISSION_MISSING,
                           "already_configured"),
    "invalid_token": (SETUP_STATE_TELEGRAM_ERROR, "invalid_token"),
    "telegram_unreachable": (SETUP_STATE_TELEGRAM_ERROR,
                             "telegram_network_failure"),
    # The wizard's own STEP 4 state strings can round-trip as reasons
    # (probe-derived failures) — they must classify to themselves.
    "connected": (SETUP_STATE_CONNECTED, ""),
    "pending": (SETUP_STATE_PENDING, ""),
    SETUP_STATE_MEMBERSHIP_UNAVAILABLE: (
        SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
        "membership_check_unavailable"),
    SETUP_STATE_TIMEOUT: (SETUP_STATE_TIMEOUT, "telegram_timeout"),
    SETUP_STATE_TELEGRAM_ERROR: (SETUP_STATE_TELEGRAM_ERROR,
                                 "telegram_error"),
    SETUP_STATE_NOT_FOUND: (SETUP_STATE_NOT_FOUND,
                            "bot_cannot_access_channel"),
    SETUP_STATE_PERMISSION_MISSING: (SETUP_STATE_PERMISSION_MISSING,
                                     "permission_missing"),
}


def classify_setup_verification_reason(reason) -> Tuple[str, str]:
    """Map a verification-chain reason to ``(STEP 4 state, §4
    error-state key)`` (reuses the existing reason vocabulary; unknown
    reasons still classify honestly — never "Failed")."""
    key = str(reason or "").strip()
    mapped = _SETUP_VERIFY_REASON_MAP.get(key)
    if mapped is not None:
        return mapped
    low = key.lower()
    if "timeout" in low:
        return SETUP_STATE_TIMEOUT, "telegram_timeout"
    if "token" in low:
        return SETUP_STATE_TELEGRAM_ERROR, "invalid_token"
    if "permission" in low or "rights" in low or "admin" in low:
        return SETUP_STATE_PERMISSION_MISSING, "permission_missing"
    if "not_found" in low or "not member" in low or "member" in low:
        return SETUP_STATE_NOT_FOUND, "bot_cannot_access_channel"
    if "unreachable" in low or "network" in low or "dns" in low:
        return SETUP_STATE_TELEGRAM_ERROR, "telegram_network_failure"
    return SETUP_STATE_TELEGRAM_ERROR, "telegram_error"


def build_setup_wizard_text(*, username: str, bot_id: int,
                            state: str = "created",
                            network_bot_id: int = 0,
                            channel_name: str = "",
                            channel_id: int = 0,
                            bot_status: str = "",
                            membership_status: str = "",
                            verification_state: str = SETUP_STATE_PENDING,
                            verification_detail: str = "",
                            membership_ready: bool = False,
                            note: str = "") -> str:
    """The COMPLETE 6-step §4 setup wizard text (fits Telegram's
    4096-char message bound; every step is truthful — pending states
    say exactly what to do next, never a fabricated PASS)."""
    uname = str(username or "").lstrip("@") or "?"
    configured = ("attached" if str(state) == "attached"
                  else "configured")
    vs = str(verification_state or SETUP_STATE_PENDING)
    glyph = {
        SETUP_STATE_CONNECTED: "🟢",
        SETUP_STATE_PERMISSION_MISSING: "🟠",
        SETUP_STATE_NOT_FOUND: "🔴",
        SETUP_STATE_TELEGRAM_ERROR: "🟠",
        SETUP_STATE_TIMEOUT: "🟠",
        SETUP_STATE_MEMBERSHIP_UNAVAILABLE: "🟠",
    }.get(vs, "⚪️")
    step4 = f"{glyph} State: {vs}"
    if membership_ready:
        step6 = ("✓ Real server-side membership test passed (the "
                 "bot's own client can read the channel)\n"
                 "✓ Network Bot Ready")
    elif vs == SETUP_STATE_PENDING:
        step6 = ("⏳ Not run yet — the real server-side test runs "
                 "when you tap Verify.")
    else:
        step6 = f"{glyph} {vs}"
        if verification_detail:
            step6 += f"\n{verification_detail}"
        else:
            step6 += ("\nFix the issue above, then tap Verify "
                      "again.")
    text = (
        "🤖 NETWORK BOT SETUP — @%s\n\n"
        "1️⃣ CREATED\n"
        "✓ Bot identity detected%s\n"
        "✓ Bot username: @%s\n"
        "✓ Bot registered: Network Bot #%s\n"
        "✓ Credential %s (encrypted at rest)\n\n"
        "2️⃣ ADD TO CHANNEL\n"
        "Add this bot to your channel as an administrator.\n"
        "After adding it, return here and tap Verify.\n"
        "(Channel → Manage Channel → Administrators → Add @%s)\n\n"
        "3️⃣ REQUIRED PERMISSIONS\n"
        "• Channel: a broadcast channel (groups are not accepted)\n"
        "• File Delivery Bot: Administrator + Delete Messages\n"
        "• Network Bot: present in the channel\n"
        "(Only the permissions the platform actually verifies — "
        "nothing else is required.)\n\n"
        "4️⃣ SERVER VERIFICATION\n"
        "%s\n\n"
        "5️⃣ CHANNEL CONFIGURATION\n"
        "Channel name: %s\n"
        "Channel ID: %s\n"
        "Bot username: @%s\n"
        "Bot status: %s\n"
        "Membership verification: %s\n\n"
        "6️⃣ MEMBERSHIP TEST\n"
        "%s"
    ) % (
        uname,
        f" (Bot ID {int(bot_id)})" if int(bot_id or 0) else "",
        uname,
        int(network_bot_id or 0) or "?",
        configured,
        uname,
        step4,
        channel_name or "— (not configured yet)",
        str(int(channel_id)) if int(channel_id or 0) else
        "— (not configured yet)",
        uname,
        str(bot_status or "?"),
        str(membership_status or "not run yet"),
        step6,
    )
    if note:
        text += f"\n\n{note}"
    return text


def build_setup_wizard_keyboard(network_bot_id: int,
                                username: str) -> InlineKeyboardMarkup:
    """STEP 2 buttons: [ Copy Bot Username ] [ Open Bot ] and
    [ Add to Channel ] [ Verify ] (+ the persistent manage rows).

    Copy uses Telegram's native ``CopyTextButton`` (the same pattern
    the Global Payload Link panel uses); Open Bot is a plain t.me URL
    button; Add to Channel / Verify are ``NET_BOT_CB`` sub-actions
    (``nbot:<id>:setup`` / ``nbot:<id>:verify``) delegated to
    ``handle_setup_wizard_callback`` by the network_ui dispatcher."""
    nid = int(network_bot_id or 0)
    uname = str(username or "").lstrip("@")
    row_one: list = []
    if uname and uname != "?":
        if CopyTextButton is not None:
            try:
                row_one.append(InlineKeyboardButton(
                    "📋 Copy Bot Username",
                    copy_text=CopyTextButton(text=f"@{uname}")))
            except Exception:  # noqa: BLE001 — older PTB fallback
                pass
        row_one.append(InlineKeyboardButton(
            "🔗 Open Bot", url=f"https://t.me/{uname}"))
    rows: list = []
    if row_one:
        rows.append(row_one)
    rows.append([
        InlineKeyboardButton(
            "➕ Add to Channel",
            callback_data=f"{NET_BOT_CB}{nid}:{NET_BOT_SETUP_ACTION}"),
        InlineKeyboardButton(
            "✅ Verify",
            callback_data=f"{NET_BOT_CB}{nid}:{NET_BOT_VERIFY_ACTION}"),
    ])
    rows.append([InlineKeyboardButton(
        "🤖 Manage Bot", callback_data=f"{NET_BOT_CB}{nid}")])
    rows.append([
        InlineKeyboardButton(
            "➕ Create Another Bot",
            callback_data=f"{NET_CREATE_CB}start"),
        InlineKeyboardButton("🔄 Refresh",
                             callback_data=f"{NET_REG_CB}back"),
    ])
    rows.append([InlineKeyboardButton(
        "⬅️ My Network", callback_data=f"{NET_REG_CB}back")])
    return InlineKeyboardMarkup(rows)


def _setup_row_bot_id(row) -> int:
    """The network_bot_id of a network_bots row (id-aliased in the
    repository SELECT — both spellings accepted defensively)."""
    try:
        return int((row or {}).get("network_bot_id")
                   or (row or {}).get("id") or 0)
    except (TypeError, ValueError):
        return 0


class ManagedBotCoordinator:
    """Coordinates the Telegram managed-bot lifecycle with injected
    adapters (db / registry / workers / vault / logger).

    The bot.py-style wiring happens through the module-level facade
    functions below, which receive the RUNTIME NAMESPACE (``ns``) and
    construct the coordinator from its singletons — the same pattern
    ``app/network/lifecycle.py`` uses. Every method ALSO takes ``ns``
    so presentation collaborators (safe send/edit, the My Network
    panel, conversation-state helpers) resolve at CALL time.
    """

    def __init__(self, db=None, registry=None, workers=None, vault=None,
                 logger=None) -> None:
        self.db = db
        self.registry = registry
        self.workers = workers
        self.vault = vault
        self.logger = logger

    # ------------------------------------------------------------------
    # collaborators resolved through ns at call time (fail-closed honest)
    # ------------------------------------------------------------------
    def _db(self, ns):
        return self.db if self.db is not None else _ns_get(ns, "db")

    def _registry(self, ns):
        return self.registry if self.registry is not None \
            else _ns_get(ns, "_net_registry")

    def _workers(self, ns):
        return self.workers if self.workers is not None \
            else _ns_get(ns, "_net_workers")

    def _vault(self, ns):
        return self.vault if self.vault is not None \
            else _ns_get(ns, "_net_vault")

    def _log(self, ns):
        return self.logger if self.logger is not None \
            else _ns_get(ns, "logger", logger)

    # ------------------------------------------------------------------
    # A) begin — the reply-keyboard managed-bot creation request
    # ------------------------------------------------------------------
    async def begin_managed_creation(self, ns, update, context,
                                     user) -> None:
        """Render the managed-bot creation request keyboard + set the
        pending state. Fail-closed BEFORE anything is collected when the
        platform cannot encrypt credentials (honest message, no keyboard,
        no state).

        b10 §7 (B10-B2): works from the MAIN bot AND from any registered
        NETWORK bot — a WORKER bot that itself has Telegram's
        ``can_manage_bots`` capability can manage (create) new bots, so
        the SAME KeyboardButtonRequestManagedBot flow runs there; the
        MANAGED_BOT_CREATED service message then arrives at THAT worker
        (the new bot's manager) — the worker wiring registers the
        managed-bot handlers for exactly this. A worker WITHOUT the
        capability is refused with the TRUTHFUL reason + the exact
        one-time @BotFather setup instruction (never "open the main
        bot" when the bot could be made capable)."""
        log = self._log(ns)
        db = self._db(ns)
        q = getattr(update, "callback_query", None)
        chat_id = getattr(update, "effective_chat", None)
        chat_id = getattr(chat_id, "id", None) if chat_id is not None else None
        if chat_id is None:
            return
        user_id = int(getattr(user, "id", 0) or 0)
        back_cb = _origin_back(ns, context)

        # b10 §1: beginning a NEW input conversation retires any durable
        # token-input intent (single-active-conversation discipline).
        _ns_call_sync(ns, "clear_pending_token_intent", user_id,
                      default=None)

        # b10 §7: WORKER context — capability-gated, never blanket-refused.
        worker_nid = await _ns_call(ns, "_net_context_id", context,
                                    default=None)
        worker_username = ""
        if worker_nid:
            worker_username = str(
                _ns_call_sync(ns, "_net_serving_bot_username", context,
                              default="") or "").lstrip("@")
            # BOT-13 §2 (stale-capability fix): the PERSISTED capability is
            # a CACHE with a TTL — a recorded can_manage_bots=0 NEVER
            # permanently blocks the user.  When the cached False is FRESH
            # (< TTL) the refusal is served without the getMe round-trip;
            # when it is STALE (>= TTL) a LIVE getMe refresh runs FIRST
            # (persist → use) and only its fresh result can refuse.
            # NULL (never checked) or 1 (True) → the LIVE check below runs
            # and its fresh result is persisted (worker-start hook /
            # MANAGED_BOT_CAPABILITY_REFRESH keep the cache current).
            persisted_can: Optional[bool] = None
            checked_at: Optional[str] = None
            if db is not None:
                try:
                    row = await db.get_network_bot(int(worker_nid))
                    raw = (row or {}).get("can_manage_bots")
                    persisted_can = (None if raw is None
                                     else bool(int(raw)))
                    checked_at = (row or {}).get("capability_checked_at")
                except Exception:  # noqa: BLE001 — unknown → live check
                    persisted_can = None
            if persisted_can is False and not await self._capability_cache_stale(
                    db, checked_at):
                log.info(
                    "MANAGED_BOT_BEGIN_REFUSED user_id=%s "
                    "network_bot_id=%s reason=worker_not_manager_persisted "
                    "(fresh cached can_manage_bots=0 within the capability "
                    "TTL — auto-refreshes when stale, or via 🔄 Refresh "
                    "Capability / worker restart)", user_id, int(worker_nid))
                await _ns_call(
                    ns, "safe_edit_text", q,
                    "🤖 CREATE A NETWORK BOT\n\n"
                    "⛔️ This Network Bot"
                    + (f" (@{worker_username})" if worker_username
                       else "")
                    + " cannot manage other bots yet.\n\n"
                    "Telegram requires a ONE-TIME setup in @BotFather:\n"
                    "1️⃣ Open @BotFather in Telegram\n"
                    "2️⃣ /mybots → choose this bot\n"
                    "3️⃣ Bot Settings → “Manage Other Bots” → ENABLE\n\n"
                    "After enabling it, tap 🔄 Refresh Capability below — "
                    "the capability is re-checked live and this screen "
                    "updates immediately.",
                    default=None,
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🔄 Refresh Capability",
                                              callback_data="net:caps")],
                        [InlineKeyboardButton("⬅️ Back",
                                              callback_data=back_cb)]]))
                return
            if persisted_can is False:
                log.info(
                    "MANAGED_BOT_CAPABILITY_REFRESH_STALE "
                    "network_bot_id=%s checked_at=%s (cached False is "
                    "stale — live getMe runs before any refusal)",
                    int(worker_nid), checked_at or "-")
            cap = await self.worker_capability(context.bot)
            # BOT-11 (spec §1): persist the FRESH live result (True/False/
            # None) — never a fabricated value.
            if db is not None:
                setter = getattr(db, "set_network_bot_capability", None)
                if callable(setter):
                    try:
                        await setter(int(worker_nid),
                                     cap.get("can_manage_bots"))
                    except Exception:  # noqa: BLE001 — best-effort
                        pass
            if not cap.get("ready"):
                can = cap.get("can_manage_bots")
                if can is False:
                    log.info(
                        "MANAGED_BOT_BEGIN_REFUSED user_id=%s "
                        "network_bot_id=%s reason=worker_not_manager "
                        "(this network bot lacks the Telegram "
                        "can_manage_bots capability — one-time BotFather "
                        "setup required)", user_id, int(worker_nid))
                    await _ns_call(
                        ns, "safe_edit_text", q,
                        "🤖 CREATE A NETWORK BOT\n\n"
                        "⛔️ This Network Bot"
                        + (f" (@{worker_username})" if worker_username
                           else "")
                        + " cannot manage other bots yet.\n\n"
                        "Telegram requires a ONE-TIME setup in "
                        "@BotFather:\n"
                        "1️⃣ Open @BotFather in Telegram\n"
                        "2️⃣ /mybots → choose this bot\n"
                        "3️⃣ Bot Settings → “Manage Other Bots” → "
                        "ENABLE\n\n"
                        "After enabling it, tap 🤖 Create Network Bot "
                        "here again — the same managed creation flow "
                        "runs directly in this bot.",
                        default=None,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅️ Back",
                                                  callback_data=back_cb)]]))
                else:
                    log.info(
                        "MANAGED_BOT_BEGIN_REFUSED user_id=%s "
                        "network_bot_id=%s "
                        "reason=worker_capability_unknown (Telegram did "
                        "not report can_manage_bots on getMe)",
                        user_id, int(worker_nid))
                    await _ns_call(
                        ns, "safe_edit_text", q,
                        "🤖 CREATE A NETWORK BOT\n\n"
                        "⚠️ Could not verify whether this Network Bot"
                        + (f" (@{worker_username})" if worker_username
                           else "")
                        + " can manage other bots (Telegram did not "
                        "report the capability).\n\n"
                        "Please try again in a moment.",
                        default=None,
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("⬅️ Back",
                                                  callback_data=back_cb)]]))
                return
            log.info(
                "MANAGED_BOT_BEGIN_CONTEXT user_id=%s network_bot_id=%s "
                "context=worker can_manage_bots=True username=@%s "
                "(managed creation from a registered Network Bot — "
                "same flow as the main bot)",
                user_id, int(worker_nid), worker_username)

        # Fail-closed gates (mirrors the v36 discipline: never invite a
        # credential the platform cannot protect).
        enabled = True
        if db is not None:
            try:
                enabled = bool(await db.get_setting_bool(
                    NET_SETTING_ENABLED, True))
            except Exception:  # noqa: BLE001
                enabled = False
        if not enabled:
            log.info("MANAGED_BOT_BEGIN_REFUSED user_id=%s "
                     "reason=network_disabled", user_id)
            text = "🌐 The Network is currently disabled."
            if q is not None:
                await _ns_call(ns, "safe_edit_text", q, text,
                                     default=None)
            else:
                await _ns_call(ns, "safe_send_text", context.bot,
                                     chat_id, text, default=None)
            return
        registry = self._registry(ns)
        if registry is None or not getattr(registry, "can_encrypt_tokens",
                                           True):
            log.warning(
                "MANAGED_BOT_BEGIN_REFUSED user_id=%s "
                "reason=encryption_key_missing (dedicated "
                "NETWORK_TOKEN_ENCRYPTION_KEY not configured — nothing "
                "collected)", user_id)
            text = (
                "🤖 CREATE A NETWORK BOT\n\n"
                "⛔️ Temporarily unavailable.\n\n"
                "The platform's encryption key is not configured — ask "
                "the platform admin to set NETWORK_TOKEN_ENCRYPTION_KEY "
                "and restart.\n\n"
                "No token was collected (bot tokens are only accepted "
                "when they can be stored encrypted)."
            )
            if q is not None:
                await _ns_call(ns, "safe_edit_text", q, text,
                                     default=None,
                                     reply_markup=InlineKeyboardMarkup([
                                         [InlineKeyboardButton(
                                             "⬅️ Back",
                                             callback_data=back_cb)]]))
            else:
                await _ns_call(
                    ns, "safe_send_text", context.bot, chat_id, text,
                    default=None,
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back",
                                              callback_data=back_cb)]]))
            return

        # Per-user limit — informational only (the registry transaction
        # enforces the real cap).
        max_bots = NET_DEFAULT_MAX_BOTS
        cur = 0
        if db is not None:
            try:
                max_bots = int(await db.get_setting_int(
                    NET_SETTING_MAX_BOTS, NET_DEFAULT_MAX_BOTS))
                cur = int(await db.count_network_bots_for_owner(user_id))
            except Exception:  # noqa: BLE001 — informational only
                cur = 0

        # v36 hygiene: entering a conversation purges every other one.
        await _ns_call(ns, "clear_conversation_input_states", context,
                             default=None)

        request_id = next_managed_bot_request_id()
        now = _now()
        context.user_data[MANAGED_BOT_PENDING_STATE_KEY] = {
            "step": "await_managed_bot",
            "request_id": int(request_id),
            "owner_user_id": user_id,
            "ts": now,
            "stamp": now,
        }

        admin = await _is_admin(ns, user_id)
        rows = [
            [InlineKeyboardButton("❌ Cancel",
                                  callback_data=f"{NET_MANAGED_CB}cancel")],
            [InlineKeyboardButton("⬅️ Back", callback_data=back_cb)],
        ]
        if admin:
            # The relabeled LEGACY manual import — migration only, never
            # the primary path (Task 8 spec B).
            rows.append([InlineKeyboardButton(
                "⏳ Legacy Manual Import (admin)",
                callback_data=f"{NET_LEGACY_CB}start")])
        text = (
            "🤖 CREATE A NETWORK BOT\n\n"
            "Tap the 🤖 Create Network Bot button below — Telegram's "
            "managed-bot creation window opens. Choose a name and a "
            "@username there and confirm: the bot is created by Telegram "
            + (f"under this bot's (@{worker_username}) management.\n\n"
               if worker_nid and worker_username else
               "under this main bot's management.\n\n")
            + "What happens next:\n"
            "• the new bot is created and managed by Telegram under "
            "this bot\n"
            "• the platform registers it automatically and starts it\n"
            "• the credential is generated securely — nothing is ever "
            "typed here\n\n"
            f"🤖 Your bots: {cur}/{max_bots}\n"
            "⭐ +5 points when the bot completes Delivery Group setup\n"
            "⌛️ The creation window expires after 10 minutes."
        )
        if q is not None:
            await _ns_call(ns, "safe_edit_text", q, text, default=None,
                                 reply_markup=InlineKeyboardMarkup(rows))
        else:
            await _ns_call(ns, "safe_send_text", context.bot, chat_id,
                                 text, default=None,
                                 reply_markup=InlineKeyboardMarkup(rows))

        # The managed-bot REQUEST keyboard — a message carries either an
        # inline or a reply keyboard, so this is a separate message.
        reply_kb = ReplyKeyboardMarkup(
            [[KeyboardButton(
                "🤖 Create Network Bot",
                request_managed_bot=KeyboardButtonRequestManagedBot(
                    request_id=int(request_id),
                    suggested_name=None,
                    suggested_username=None))]],
            one_time_keyboard=True,
            resize_keyboard=True,
        )
        await _ns_call(
            ns, "safe_send_text", context.bot, chat_id,
            "👇 Tap 🤖 Create Network Bot to open Telegram's managed-bot "
            "creation window:",
            default=None, reply_markup=reply_kb)
        log.info("MANAGED_BOT_BEGIN user_id=%s request_id=%s "
                 "current_bots=%s limit=%s context=%s%s", user_id,
                 request_id, cur, max_bots,
                 "worker" if worker_nid else "main",
                 f" network_bot_id={int(worker_nid)}" if worker_nid else "")

    # ------------------------------------------------------------------
    # B) Message.managed_bot_created — complete the creation
    # ------------------------------------------------------------------
    async def handle_managed_bot_created(self, ns, update,
                                         context) -> None:
        """The MANAGED_BOT_CREATED service message (registered on the
        MAIN bot AND, since b10 §7 (B10-B2), on every NETWORK worker —
        a capable worker is the manager of the bots it creates). Requires
        a fresh pending state owned by the acting user; replays/orphans/
        expired/wrong-owner are politely ignored. The token is fetched
        server-side, NEVER logged."""
        log = self._log(ns)
        msg = getattr(update, "effective_message", None)
        service = getattr(msg, "managed_bot_created", None)
        bot_user = getattr(service, "bot", None)
        if bot_user is None:
            return
        acting = getattr(update, "effective_user", None)
        acting_id = int(getattr(acting, "id", 0) or 0)
        bot_tg_id = int(getattr(bot_user, "id", 0) or 0)
        bot_username = str(getattr(bot_user, "username", "") or "").lstrip("@")
        chat_id = getattr(update, "effective_chat", None)
        chat_id = getattr(chat_id, "id", None) if chat_id is not None else None
        state = context.user_data.get(MANAGED_BOT_PENDING_STATE_KEY)

        if not isinstance(state, dict) \
                or str(state.get("step")) != "await_managed_bot":
            log.info("MANAGED_BOT_CREATED_ORPHAN user_id=%s bot_id=%s "
                     "reason=no_pending_creation (replay or unsolicited; "
                     "ignored)", acting_id, bot_tg_id)
            return
        if _pending_expired(state):
            context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY, None)
            log.info("MANAGED_BOT_CREATED_ORPHAN user_id=%s bot_id=%s "
                     "reason=expired (pending creation older than 10 "
                     "minutes — state dropped, ignored)",
                     acting_id, bot_tg_id)
            return
        owner_id = int(state.get("owner_user_id") or 0)
        if not acting_id or not owner_id or acting_id != owner_id:
            log.info("MANAGED_BOT_CREATED_ORPHAN user_id=%s bot_id=%s "
                     "reason=owner_mismatch expected_owner=%s (ignored)",
                     acting_id, bot_tg_id, owner_id)
            return

        db = self._db(ns)
        registry = self._registry(ns)
        workers = self._workers(ns)

        # 1) fetch the token server-side (NEVER logged, never displayed)
        token = ""
        try:
            token = str(await context.bot.get_managed_bot_token(
                user_id=bot_tg_id) or "")
        except Exception as exc:  # noqa: BLE001 — honest failure, no token
            log.warning("MANAGED_BOT_TOKEN_FETCH_FAILED user_id=%s "
                        "bot_id=%s error=%s", acting_id, bot_tg_id,
                        type(exc).__name__)
        if not token:
            context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY, None)
            await self._send_failure(
                ns, context, chat_id,
                "⚠️ The new bot was created, but the platform could not "
                "retrieve its credential. Nothing was stored. "
                "Please start again.",
                error_key="telegram_network_failure")
            return

        # 2) validate with the SAME direct getMe transport the registry
        #    uses + identity match against the created bot.
        validator = _ns_get(ns, "_net_validate_token_via_telegram")
        if callable(validator):
            try:
                val = await validator(token)
            except Exception:  # noqa: BLE001 — transport-level failure
                val = None
            if isinstance(val, dict):
                if not val.get("ok"):
                    context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY,
                                          None)
                    reason = str(val.get("reason") or "telegram_rejected")
                    log.info("MANAGED_BOT_REGISTER_FAILED owner=%s "
                             "bot_id=%s reason=%s (validation)",
                             owner_id, bot_tg_id, reason)
                    await self._send_failure(
                        ns, context, chat_id,
                        f"❌ Telegram rejected the new bot's credential "
                        f"({reason}). Nothing was stored — please start "
                        f"again.",
                        error_key="invalid_token", detail=f"Reason: {reason}")
                    return
                vbot = val.get("bot") or {}
                if int(vbot.get("id") or 0) != bot_tg_id:
                    context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY,
                                          None)
                    log.warning("MANAGED_BOT_REGISTER_FAILED owner=%s "
                                "bot_id=%s reason=identity_mismatch",
                                owner_id, bot_tg_id)
                    await self._send_failure(
                        ns, context, chat_id,
                        "❌ Credential identity mismatch — nothing was "
                        "stored. Please start again.",
                        error_key="invalid_token",
                        detail="The credential belongs to a different "
                                "bot identity.")
                    return

        # 3) register through the registry (PLATFORM_MANAGED, managed flow)
        if registry is None:
            context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY, None)
            await self._send_failure(ns, context, chat_id,
                                     "❌ Platform services are not ready "
                                     "yet — nothing was stored. Try again "
                                     "in a moment.")
            return
        res = await registry.attempt_registration(
            int(owner_id), token,
            consent_confirmed=True,
            management_mode=MGMT_PLATFORM_MANAGED,
            credential_control=CREDENTIAL_CONTROL_PLATFORM,
            created_via=CREATED_VIA_MANAGED_FLOW)

        if not res.get("ok"):
            reason = str(res.get("reason") or "unknown")
            context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY, None)
            log.info("MANAGED_BOT_REGISTER_FAILED owner=%s bot_id=%s "
                     "reason=%s", owner_id, bot_tg_id, reason)
            if reason == "duplicate_bot" and res.get("same_owner"):
                # Idempotent success — show the EXISTING bot's management
                # view (the bot is already registered for this owner).
                existing_id = int(res.get("existing_bot_id") or 0)
                log.info("MANAGED_BOT_REGISTER_IDEMPOTENT owner=%s "
                         "bot_id=%s network_bot_id=%s (duplicate, same "
                         "owner)", owner_id, bot_tg_id, existing_id)
                status_line = "ACTIVE"
                if db is not None and existing_id:
                    try:
                        row = await db.get_network_bot(existing_id)
                        if row:
                            status_line = str(row.get("status") or "ACTIVE")
                    except Exception:  # noqa: BLE001
                        pass
                await self._send_success(
                    ns, context, chat_id, existing_id, bot_username,
                    status_line, bot_id=bot_tg_id,
                    note=("ℹ️ Already registered — the existing bot's "
                          "setup wizard is shown.\n➡️ Next: complete the "
                          "channel steps below, or open Manage Bot."))
                return
            friendly = {
                "invalid_token": "Telegram rejected the new bot's "
                                 "credential.",
                "telegram_unreachable": "Could not reach Telegram — try "
                                        "again shortly.",
                "duplicate_bot": "This bot is already registered on the "
                                 "platform.",
                "registration_limit_reached": "You reached the maximum "
                                              "registered bots limit.",
                "network_disabled": "The Network is currently disabled.",
                "encryption_key_missing": "The platform's encryption key "
                                          "is not configured — ask the "
                                          "platform admin.",
            }.get(reason, f"Registration failed ({reason}).")
            # §4 Task H: the known reasons map to their precise error
            # state (message + next action) — never a flat "Failed".
            error_key = {
                "invalid_token": "invalid_token",
                "telegram_unreachable": "telegram_network_failure",
                "duplicate_bot": "duplicate_bot",
            }.get(reason, "")
            await self._send_failure(
                ns, context, chat_id,
                f"❌ {friendly}\n\nNothing was stored.",
                back=True, error_key=error_key,
                detail=f"Reason: {reason}" if error_key else "")
            return

        # 4) success: worker start → mark ACTIVE → audit → panel
        nid = int(res.get("network_bot_id") or 0)
        tg_id = int(res.get("telegram_bot_id") or bot_tg_id)
        username = str(res.get("username") or bot_username)
        worker = None
        if workers is not None:
            try:
                worker = await workers.start_worker(nid, tg_id, username,
                                                    token)
            except Exception as exc:  # noqa: BLE001 — isolated failure
                log.warning("MANAGED_BOT_WORKER_START_FAILED "
                            "network_bot_id=%s error=%s", nid,
                            type(exc).__name__)
                worker = None
        if worker is not None:
            try:
                await registry.mark_active(nid)
            except Exception:  # noqa: BLE001
                pass
            status_line = "ACTIVE"
        else:
            status_line = "PENDING (worker will start at the next restart)"
        if db is not None:
            try:
                await db.insert_control_audit_event(
                    EVT_MANAGED_BOT_CREATED, actor_user_id=int(owner_id),
                    network_bot_id=nid,
                    detail=f"username=@{username} request_id="
                           f"{state.get('request_id')}")
                await db.insert_control_audit_event(
                    EVT_MANAGED_BOT_REGISTERED, actor_user_id=int(owner_id),
                    network_bot_id=nid)
            except Exception:  # noqa: BLE001 — audit is best-effort
                pass
        log.info("MANAGED_BOT_REGISTER_SUCCESS owner=%s "
                 "network_bot_id=%s telegram_bot_id=%s username=@%s "
                 "created_via=%s worker=%s",
                 owner_id, nid, tg_id, username, CREATED_VIA_MANAGED_FLOW,
                 "started" if worker is not None else "failed")
        context.user_data.pop(MANAGED_BOT_PENDING_STATE_KEY, None)
        await self._send_success(ns, context, chat_id, nid, username,
                                 status_line, bot_id=tg_id)

    async def _send_success(self, ns, context, chat_id, network_bot_id: int,
                            username: str, status_line: str,
                            note: str = "", bot_id: int = 0,
                            state: str = "created") -> None:
        """The success terminal — now renders the COMPLETE 6-step
        setup wizard (BOT-45/46 Task H, master prompt §4) instead of
        the bare "✅ Network Bot created successfully" card. The reply
        keyboard from the creation request is still removed with the
        NEXT message per the managed-flow contract."""
        if chat_id is None:
            return
        try:
            await _ns_call(
                ns, "safe_send_text", context.bot, chat_id,
                "🤖 Managed bot creation finished — keyboard restored.",
                default=None, reply_markup=ReplyKeyboardRemove())
        except Exception:  # noqa: BLE001
            pass
        await self.send_setup_wizard(
            ns, context, chat_id, network_bot_id, username,
            bot_id=bot_id, state=state, status_line=status_line,
            note=note)

    async def send_setup_wizard(self, ns, context, chat_id,
                                network_bot_id: int, username: str,
                                bot_id: int = 0, state: str = "created",
                                status_line: str = "",
                                note: str = "") -> None:
        """Render + send the COMPLETE 6-step §4 setup wizard.

        The single presentation entry point for BOTH success paths:
        CREATE NETWORK BOT (``state="created"`` — used by
        ``_send_success``) and ATTACH BOT TOKEN (``state="attached"``
        — called by the network_ui attach flow). Steps 4/5/6 are
        always TRUTHFUL: when a Delivery Channel is already
        configured the REAL read-only own-client membership probe
        runs inline; otherwise the pending state says exactly what to
        do next. Emits NETWORK_BOT_SETUP_OPEN + the CREATED/ATTACHED
        event (safe fields only)."""
        if chat_id is None:
            return
        log = self._log(ns)
        db = self._db(ns)
        nid = int(network_bot_id or 0)
        row = None
        if db is not None and nid:
            try:
                row = await db.get_network_bot(nid)
            except Exception:  # noqa: BLE001 — honest row-less render
                row = None
        uname = str(username or (row or {}).get("username") or
                    "").lstrip("@")
        tg_id = int(bot_id or (row or {}).get("telegram_bot_id") or 0)
        bot_status = str(status_line or (row or {}).get("status")
                         or "ACTIVE")
        channel_id = 0
        try:
            channel_id = int((row or {}).get("delivery_channel_chat_id")
                             or 0)
        except (TypeError, ValueError):
            channel_id = 0
        membership_status = "not run yet"
        verification_state = SETUP_STATE_PENDING
        verification_detail = ("Tap Verify after adding the bot to "
                               "your channel.")
        channel_name = ""
        membership_ready = False
        if channel_id and row is not None:
            # REAL read-only probe with the bot's OWN client so STEP
            # 5/6 are live facts (never a fabricated PASS).
            probe = await self._probe_channel_membership(
                ns, nid, tg_id, channel_id, uname)
            verification_state = str(probe.get("state")
                                     or SETUP_STATE_PENDING)
            membership_ready = bool(probe.get("member")) \
                and verification_state == SETUP_STATE_CONNECTED
            if probe.get("member_status"):
                membership_status = (
                    f"✓ verified ({probe.get('member_status')})"
                    if membership_ready
                    else str(probe.get("member_status")))
            channel_name = str(probe.get("channel_title") or "")
            if probe.get("detail"):
                verification_detail = str(probe.get("detail"))
        text = build_setup_wizard_text(
            username=uname, bot_id=tg_id, state=state, network_bot_id=nid,
            channel_name=channel_name, channel_id=channel_id,
            bot_status=bot_status, membership_status=membership_status,
            verification_state=verification_state,
            verification_detail=verification_detail,
            membership_ready=membership_ready, note=note)
        kb = build_setup_wizard_keyboard(nid, uname)
        await _ns_call(ns, "safe_send_text", context.bot, chat_id, text,
                       default=None, reply_markup=kb)
        log_network_bot_setup_telemetry(
            NETWORK_BOT_SETUP_OPEN, log, network_bot_id=nid,
            bot_id=tg_id, bot_username=uname,
            channel_id=channel_id or None, state=state)
        if state == "attached":
            log_network_bot_setup_telemetry(
                NETWORK_BOT_ATTACHED, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname,
                channel_id=channel_id or None, state=state)
        elif state == "created":
            log_network_bot_setup_telemetry(
                NETWORK_BOT_CREATED, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname,
                channel_id=channel_id or None, state=state)

    async def _probe_channel_membership(self, ns, network_bot_id: int,
                                        telegram_bot_id: int,
                                        channel_id: int,
                                        username: str = "") \
            -> Dict[str, Any]:
        """STEP 6 — a REAL, safe, server-side membership test.

        Read-only probes with the NETWORK BOT'S OWN worker client
        (``get_me`` / ``get_chat`` / ``get_chat_member`` — the same
        probe pattern FileDeliveryBotManager.network_delivery_group_
        access_check uses): live identity, channel visibility, the
        bot's own membership and the File Delivery Bot's administrator
        status + Delete Messages privilege. NEVER writes, never sends,
        never raises, never logs tokens; every probe is bounded by
        asyncio.wait_for so the timeout state is deterministic. Every
        Telegram failure classifies to the precise §4 state (timeout /
        DNS-network / not-found / permission) — never a flat
        "Failed". Emits NETWORK_BOT_CHANNEL_TEST (safe fields)."""
        log = self._log(ns)
        nid = int(network_bot_id or 0)
        tg_id = int(telegram_bot_id or 0)
        cid = int(channel_id or 0)
        uname = str(username or "").lstrip("@")
        out: Dict[str, Any] = {
            "state": SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
            "member": False, "member_status": "",
            "channel_title": "", "channel_type": "", "detail": "",
            "bot_id": tg_id, "channel_id": cid,
        }
        workers = self._workers(ns)
        client = None
        if workers is not None:
            try:
                client = workers.get_bot_client(nid)
            except Exception:  # noqa: BLE001
                client = None
        if client is None or not callable(getattr(client, "get_me", None)):
            out["detail"] = ("The Network Bot's worker is not running "
                             "right now — the server-side membership "
                             "test could not execute.")
            log_network_bot_setup_telemetry(
                NETWORK_BOT_CHANNEL_TEST, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname, channel_id=cid,
                result="unavailable", reason="no_running_worker")
            return out

        def _log_test(result: str, reason: str = "") -> None:
            log_network_bot_setup_telemetry(
                NETWORK_BOT_CHANNEL_TEST, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname, channel_id=cid,
                result=result, state=out.get("state"),
                member_status=out.get("member_status") or None,
                chat_type=out.get("channel_type") or None,
                channel_title=out.get("channel_title") or None,
                reason=reason or None)

        # -- identity: get_me with the bot's OWN client ---------------
        try:
            me = await asyncio.wait_for(
                client.get_me(), _SETUP_PROBE_TIMEOUT_SECONDS)
            live_id = int(getattr(me, "id", 0) or 0)
            if tg_id and live_id and live_id != tg_id:
                out.update(
                    state=SETUP_STATE_TELEGRAM_ERROR,
                    detail=(f"Live bot identity ({live_id}) does not "
                            f"match the registered Bot ID ({tg_id})."))
                _log_test("failed", "identity_mismatch")
                return out
        except asyncio.TimeoutError:
            out.update(
                state=SETUP_STATE_TIMEOUT,
                detail="Telegram getMe timed out during the membership "
                       "test.")
            _log_test("failed", "timeout")
            return out
        except Exception as exc:  # noqa: BLE001 — classified, honest
            state, key = classify_setup_telegram_error(exc)
            out.update(
                state=state,
                detail=f"Telegram getMe failed ({type(exc).__name__}).")
            _log_test("failed", key)
            return out
        # -- channel visibility + type --------------------------------
        try:
            chat = await asyncio.wait_for(
                client.get_chat(cid), _SETUP_PROBE_TIMEOUT_SECONDS)
            out["channel_title"] = str(getattr(chat, "title", "") or "")
            out["channel_type"] = str(getattr(chat, "type", "") or "")
        except asyncio.TimeoutError:
            out.update(
                state=SETUP_STATE_TIMEOUT,
                detail="Telegram getChat timed out during the membership "
                       "test.")
            _log_test("failed", "timeout")
            return out
        except Exception as exc:  # noqa: BLE001 — classified, honest
            state, key = classify_setup_telegram_error(exc)
            out.update(
                state=state,
                detail=(f"The bot cannot see the channel "
                        f"({type(exc).__name__})."))
            _log_test("failed", key)
            return out
        if out["channel_type"] and out["channel_type"] != "channel":
            out.update(
                state=SETUP_STATE_PERMISSION_MISSING,
                detail=(f"Chat type is {out['channel_type']} — a "
                        "broadcast CHANNEL is required."))
        # -- the bot's own membership ---------------------------------
        member_status = ""
        try:
            member = await asyncio.wait_for(
                client.get_chat_member(cid, tg_id),
                _SETUP_PROBE_TIMEOUT_SECONDS)
            member_status = str(getattr(member, "status", "") or "")
            out["member_status"] = member_status
            out["member"] = member_status in ("administrator", "creator",
                                               "member")
            if not out["member"]:
                out["state"] = SETUP_STATE_NOT_FOUND
                out["detail"] = ("Bot membership status in the channel: "
                                 f"{member_status}.")
        except asyncio.TimeoutError:
            out.update(
                state=SETUP_STATE_TIMEOUT,
                detail="Telegram getChatMember timed out during the "
                       "membership test.")
            _log_test("failed", "timeout")
            return out
        except Exception as exc:  # noqa: BLE001 — classified, honest
            state, key = classify_setup_telegram_error(exc)
            out.update(
                state=state,
                detail=(f"Membership probe failed "
                        f"({type(exc).__name__})."))
            _log_test("failed", key)
            return out
        # -- FDB admin + Delete Messages (STEP 3's real requirements) --
        fdb = _ns_get(ns, "_fdb")
        fdb_id = int(getattr(fdb, "telegram_bot_id", 0) or 0) \
            if fdb is not None else 0
        if fdb_id and cid:
            try:
                fm = await asyncio.wait_for(
                    client.get_chat_member(cid, fdb_id),
                    _SETUP_PROBE_TIMEOUT_SECONDS)
                fs = str(getattr(fm, "status", "") or "")
                if fs not in ("administrator", "creator"):
                    out["state"] = SETUP_STATE_PERMISSION_MISSING
                    out["detail"] = ("The File Delivery Bot is not an "
                                     "administrator of the channel.")
                elif getattr(fm, "can_delete_messages", None) is False:
                    out["state"] = SETUP_STATE_PERMISSION_MISSING
                    out["detail"] = ("The File Delivery Bot lacks the "
                                     "Delete Messages privilege.")
            except Exception:  # noqa: BLE001 — best-effort; the full
                # chain re-checks on Verify.
                pass
        # -- final decision -------------------------------------------
        if out["member"] and out.get("state") \
                not in (SETUP_STATE_PERMISSION_MISSING,
                        SETUP_STATE_NOT_FOUND):
            out["state"] = SETUP_STATE_CONNECTED
            out["detail"] = ("Server verified: the bot sees the channel "
                             f"({out['channel_type']}) and its membership "
                             f"is {member_status}.")
        _log_test("ok" if (out["member"]
                           and out["state"] == SETUP_STATE_CONNECTED)
                  else "failed")
        return out

    async def run_setup_verification(self, ns, network_bot_id: int, *,
                                     owner_user_id: Optional[int] = None,
                                     chat_id: Optional[int] = None) \
            -> Dict[str, Any]:
        """The wizard's Verify engine (the §4 run_verification
        equivalent — the NETWORK_BOT_SETUP_* telemetry wiring point).

        NETWORK_BOT_VERIFY_START → the REAL server-side checks →
        NETWORK_BOT_VERIFY_RESULT (+ NETWORK_BOT_CHANNEL_TEST inside
        the own-client membership probe, NETWORK_BOT_SETUP_COMPLETE on
        full success, NETWORK_BOT_SETUP_ERROR on every classified
        failure). When a Delivery Channel is known, the FULL
        production chain runs (``ns._fdb.verify_delivery_channel`` —
        the same chain delivery_ui.run_verification runs, including
        the set_delivery_channel persistence + DELIVERY_CHANNEL_*
        logs); the own-client membership test ALWAYS runs too, so
        STEP 6 reflects the bot's own view. Safe fields only — never
        tokens."""
        log = self._log(ns)
        db = self._db(ns)
        nid = int(network_bot_id or 0)
        res: Dict[str, Any] = {"ok": False,
                               "state": SETUP_STATE_TELEGRAM_ERROR,
                               "error_key": "", "message": "",
                               "next_action": "", "checks": {}}
        log_network_bot_setup_telemetry(
            NETWORK_BOT_VERIFY_START, log, network_bot_id=nid,
            channel_id=int(chat_id) if chat_id else None)
        row = None
        if db is not None and nid:
            try:
                row = await db.get_network_bot(nid)
            except Exception:  # noqa: BLE001
                row = None
        if not row:
            res.update(
                state=SETUP_STATE_NOT_FOUND, error_key="bot_not_found",
                message=render_setup_error_state("bot_not_found"),
                next_action=NETWORK_BOT_SETUP_ERROR_STATES[
                    "bot_not_found"]["next_action"])
            log_network_bot_setup_telemetry(
                NETWORK_BOT_VERIFY_RESULT, log, network_bot_id=nid,
                result="failed", state=SETUP_STATE_NOT_FOUND,
                reason="bot_not_found")
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_ERROR, log, network_bot_id=nid,
                state=SETUP_STATE_NOT_FOUND, reason="bot_not_found")
            return res
        tg_id = int(row.get("telegram_bot_id") or 0)
        uname = str(row.get("username") or "").lstrip("@")
        owner = int(owner_user_id or row.get("owner_user_id") or 0)
        if str(row.get("status") or "") == "TOKEN_INVALID":
            res.update(
                state=SETUP_STATE_TELEGRAM_ERROR, error_key="invalid_token",
                message=render_setup_error_state(
                    "invalid_token",
                    "The stored credential is marked TOKEN_INVALID — "
                    "the bot cannot operate."),
                next_action=NETWORK_BOT_SETUP_ERROR_STATES[
                    "invalid_token"]["next_action"])
            log_network_bot_setup_telemetry(
                NETWORK_BOT_VERIFY_RESULT, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname,
                result="failed", state=SETUP_STATE_TELEGRAM_ERROR,
                reason="invalid_token")
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_ERROR, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname,
                state=SETUP_STATE_TELEGRAM_ERROR, reason="invalid_token")
            return res
        channel = int(chat_id or 0)
        if not channel:
            try:
                channel = int(row.get("delivery_channel_chat_id") or 0)
            except (TypeError, ValueError):
                channel = 0
        if not channel:
            # No Delivery Channel yet — the honest pending state with
            # the exact §4 STEP 2 next action.
            res.update(
                state=SETUP_STATE_PENDING, error_key="",
                message=("⏳ No Delivery Channel is configured for this "
                         f"bot yet.\n\nAdd @{uname} to your channel as "
                         "an administrator, then tap Verify."),
                next_action=("Add the bot to your channel as an "
                             "administrator, then tap Verify again."))
            log_network_bot_setup_telemetry(
                NETWORK_BOT_VERIFY_RESULT, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname, result="pending",
                state=SETUP_STATE_PENDING, reason="channel_not_configured")
            return res
        # STEP 6 — the real own-client membership test (always runs).
        probe = await self._probe_channel_membership(
            ns, nid, tg_id, channel, uname)
        res["checks"]["membership"] = probe
        # The FULL production verification chain (the
        # run_verification equivalent — persists the channel on
        # success + DELIVERY_CHANNEL_* logs).
        chain = None
        fdb = _ns_get(ns, "_fdb")
        verifier = getattr(fdb, "verify_delivery_channel", None) \
            if fdb is not None else None
        if callable(verifier):
            try:
                chain = await verifier(
                    row, int(channel),
                    title=str(probe.get("channel_title") or ""),
                    owner_user_id=owner)
            except Exception as exc:  # noqa: BLE001 — classified
                state, key = classify_setup_telegram_error(exc)
                chain = {"ok": False, "reason": key,
                         "checks": {"exception_class":
                                    type(exc).__name__}}
        res["checks"]["delivery_channel"] = chain
        chain_ok = bool(isinstance(chain, dict) and chain.get("ok"))
        probe_ok = bool(probe.get("member")) \
            and probe.get("state") == SETUP_STATE_CONNECTED
        if chain_ok and probe_ok:
            res.update(
                ok=True, state=SETUP_STATE_CONNECTED, error_key="",
                message=("✓ Membership verified server-side\n"
                         "✓ Network Bot Ready"),
                next_action="The bot is fully operational.")
            log_network_bot_setup_telemetry(
                NETWORK_BOT_VERIFY_RESULT, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname, channel_id=channel,
                result="ok", state=SETUP_STATE_CONNECTED)
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_COMPLETE, log, network_bot_id=nid,
                bot_id=tg_id, bot_username=uname, channel_id=channel,
                state=SETUP_STATE_CONNECTED)
            return res
        # Failure → the precise §4 state + actionable error state.
        reason = ""
        if isinstance(chain, dict) and not chain_ok:
            reason = str(chain.get("reason") or "")
        if not reason and not probe_ok:
            pstate = str(probe.get("state") or "")
            if not probe.get("member") and pstate not in (
                    SETUP_STATE_MEMBERSHIP_UNAVAILABLE,
                    SETUP_STATE_TIMEOUT,
                    SETUP_STATE_TELEGRAM_ERROR,
                    SETUP_STATE_PERMISSION_MISSING,
                    ""):
                reason = "network_bot_not_member"
            else:
                reason = pstate or SETUP_STATE_TELEGRAM_ERROR
        state, key = classify_setup_verification_reason(reason)
        detail = ""
        if isinstance(chain, dict):
            checks = chain.get("checks") or {}
            if checks.get("fdb_missing_privileges"):
                detail = ("Missing permissions: "
                          + ", ".join(str(p) for p in
                                       checks["fdb_missing_privileges"]))
        res.update(
            state=state, error_key=key,
            message=render_setup_error_state(key, detail),
            next_action=NETWORK_BOT_SETUP_ERROR_STATES.get(
                key, {}).get("next_action", ""))
        log_network_bot_setup_telemetry(
            NETWORK_BOT_VERIFY_RESULT, log, network_bot_id=nid,
            bot_id=tg_id, bot_username=uname, channel_id=channel,
            result="failed", state=state, reason=key)
        log_network_bot_setup_telemetry(
            NETWORK_BOT_SETUP_ERROR, log, network_bot_id=nid,
            bot_id=tg_id, bot_username=uname, channel_id=channel,
            state=state, reason=key)
        return res

    async def handle_setup_wizard_callback(self, ns, update, context,
                                           user, network_bot_id: int,
                                           action: str = "") -> None:
        """The wizard's own buttons — the ``nbot:<id>:setup`` (Add to
        Channel) and ``nbot:<id>:verify`` (Verify) NET_BOT_CB
        sub-actions, delegated here by the network_ui
        ``_handle_net_bot_callback`` dispatcher (one-line wiring:
        ``if action in ("setup", "verify"): await managed_bots.
        handle_setup_wizard_callback(...)``). ``setup`` answers with
        the exact add-to-channel steps; ``verify`` runs the REAL
        verification and re-renders the wizard with the fresh
        STEP 4/5/6 state."""
        act = str(action or NET_BOT_VERIFY_ACTION).strip().lower()
        if act == NET_BOT_SETUP_ACTION:
            await self._handle_setup_add_to_channel(
                ns, update, context, user, network_bot_id)
            return
        await self._handle_setup_verify(ns, update, context, user,
                                        network_bot_id)

    async def _setup_wizard_row(self, ns, network_bot_id: int):
        """Resolve + ownership-gate the bot row for a wizard button.
        Returns ``(row, None)`` on success or ``(None, refusal)`` where
        ``refusal`` is the already-rendered precise §4 error text."""
        log = self._log(ns)
        db = self._db(ns)
        nid = int(network_bot_id or 0)
        row = None
        if db is not None and nid:
            try:
                row = await db.get_network_bot(nid)
            except Exception:  # noqa: BLE001
                row = None
        if not row:
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_ERROR, log, network_bot_id=nid,
                state=SETUP_STATE_NOT_FOUND, reason="bot_not_found")
            return None, render_setup_error_state("bot_not_found")
        return row, None

    async def _setup_wizard_owned(self, ns, update, context, user,
                                  network_bot_id: int):
        """Row + ownership/admin gate (spec §63 — users manage their
        OWN bots only; the network_ui dispatcher re-checks before
        delegating — defense in depth for direct wiring)."""
        row, refusal = await self._setup_wizard_row(ns, network_bot_id)
        if refusal is not None:
            await _ns_call(ns, "safe_answer_callback",
                           getattr(update, "callback_query", None),
                           refusal, default=None, show_alert=True)
            return None, refusal
        uid = int(getattr(user, "id", 0) or 0) if user is not None \
            else int(getattr(
                getattr(update, "effective_user", None), "id", 0) or 0)
        if uid and int(row.get("owner_user_id") or 0) != uid \
                and not await _is_admin(ns, uid):
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_ERROR, log=self._log(ns),
                network_bot_id=int(network_bot_id or 0),
                state=SETUP_STATE_PERMISSION_MISSING,
                reason="unauthorized_admin")
            refusal = render_setup_error_state("unauthorized_admin")
            await _ns_call(ns, "safe_answer_callback",
                           getattr(update, "callback_query", None),
                           refusal, default=None, show_alert=True)
            return None, refusal
        return row, None

    async def _handle_setup_add_to_channel(self, ns, update, context,
                                           user,
                                           network_bot_id: int) -> None:
        """[ Add to Channel ] — the exact Telegram steps (no invented
        deep links; Telegram has no add-bot-to-channel URL — the
        admin adds the bot from the channel's Administrators screen)."""
        row, refusal = await self._setup_wizard_owned(
            ns, update, context, user, network_bot_id)
        if refusal is not None:
            return
        q = getattr(update, "callback_query", None)
        uname = str(row.get("username") or "").lstrip("@")
        await _ns_call(
            ns, "safe_answer_callback", q,
            "➕ Add @%s to your channel:\n\n"
            "1. Open your channel\n"
            "2. Manage Channel → Administrators → Add Admin\n"
            "3. Search @%s and add it\n"
            "4. Return here and tap Verify" % (uname, uname),
            default=None, show_alert=True)

    async def _handle_setup_verify(self, ns, update, context, user,
                                   network_bot_id: int) -> None:
        """[ Verify ] — run the REAL verification (run_setup_
        verification) and re-render the wizard with the fresh state."""
        row, refusal = await self._setup_wizard_owned(
            ns, update, context, user, network_bot_id)
        if refusal is not None:
            return
        q = getattr(update, "callback_query", None)
        chat = getattr(update, "effective_chat", None)
        chat_id = getattr(chat, "id", None) \
            if chat is not None else None
        uid = int(getattr(user, "id", 0) or 0) if user is not None else 0
        nid = int(network_bot_id or 0)
        await _ns_call(ns, "safe_answer_callback", q,
                       "⏳ Verifying Network Bot…", default=None)
        res = await self.run_setup_verification(
            ns, nid, owner_user_id=uid or None)
        probe = (res.get("checks") or {}).get("membership") or {}
        uname = str(row.get("username") or "").lstrip("@")
        tg_id = int(row.get("telegram_bot_id") or 0)
        channel = 0
        try:
            channel = int(row.get("delivery_channel_chat_id") or 0)
        except (TypeError, ValueError):
            channel = 0
        if not channel and probe.get("channel_id"):
            try:
                channel = int(probe.get("channel_id") or 0)
            except (TypeError, ValueError):
                channel = 0
        membership_status = (
            f"✓ verified ({probe.get('member_status')})"
            if res.get("ok")
            else str(probe.get("member_status") or "not run yet"))
        text = build_setup_wizard_text(
            username=uname, bot_id=tg_id, state="created",
            network_bot_id=nid,
            channel_name=str(probe.get("channel_title") or ""),
            channel_id=channel,
            bot_status=str(row.get("status") or "?"),
            membership_status=membership_status,
            verification_state=str(res.get("state")
                                   or SETUP_STATE_PENDING),
            verification_detail=str(res.get("message") or ""),
            membership_ready=bool(res.get("ok")))
        kb = build_setup_wizard_keyboard(nid, uname)
        if q is not None:
            await _ns_call(ns, "safe_edit_text", q, text, default=None,
                           reply_markup=kb)
        elif chat_id is not None:
            await _ns_call(ns, "safe_send_text", context.bot, chat_id,
                           text, default=None, reply_markup=kb)

    async def _send_failure(self, ns, context, chat_id, text: str,
                            back: bool = False, error_key: str = "",
                            detail: str = "") -> None:
        """Honest failure notice + keyboard restore (never the token).
        BOT-45/46 Task H: when ``error_key`` is given, the precise §4
        error state (message + next action) is appended and
        NETWORK_BOT_SETUP_ERROR telemetry fires — never a flat
        "Failed"."""
        if chat_id is None:
            return
        if error_key:
            log_network_bot_setup_telemetry(
                NETWORK_BOT_SETUP_ERROR, self._log(ns),
                reason=error_key, state="failed")
            text = f"{text}\n\n{render_setup_error_state(error_key, detail)}"
        try:
            await _ns_call(
                ns, "safe_send_text", context.bot, chat_id,
                "🤖 Managed bot creation closed — keyboard restored.",
                default=None, reply_markup=ReplyKeyboardRemove())
        except Exception:  # noqa: BLE001
            pass
        rows = []
        if back:
            rows.append([InlineKeyboardButton(
                "⬅️ My Network", callback_data=f"{NET_REG_CB}back")])
        await _ns_call(ns, "safe_send_text", context.bot, chat_id,
                             text, default=None,
                             reply_markup=InlineKeyboardMarkup(rows)
                             if rows else None)

    # ------------------------------------------------------------------
    # C) Update.managed_bot — informational + replacement completion
    # ------------------------------------------------------------------
    async def handle_managed_bot_updated(self, ns, update,
                                         context) -> None:
        """``telegram.ManagedBotUpdated`` (creation / token update / owner
        update of a managed bot). Redacted-id logging; a control audit
        event when the affected bot is registered; completes a token
        replacement WE initiated (within the marker TTL)."""
        log = self._log(ns)
        mb = getattr(update, "managed_bot", None)
        if mb is None:
            return
        creator = getattr(mb, "user", None)
        bot_user = getattr(mb, "bot", None)
        creator_id = int(getattr(creator, "id", 0) or 0)
        bot_tg_id = int(getattr(bot_user, "id", 0) or 0)
        bot_username = str(getattr(bot_user, "username", "") or "").lstrip("@")
        log.info("MANAGED_BOT_UPDATED user_id=%s bot_id=%s%s",
                 creator_id, bot_tg_id,
                 f" username=@{bot_username}" if bot_username else "")
        db = self._db(ns)
        if db is None or not bot_tg_id:
            return
        row = None
        try:
            row = await db.get_network_bot_by_telegram_id(bot_tg_id)
        except Exception:  # noqa: BLE001
            row = None
        if not row:
            return
        nid = int(row.get("network_bot_id") or row.get("id") or 0)
        initiated = _pending_token_replacements.pop(bot_tg_id, None)
        detail = f"username=@{bot_username}"
        try:
            if initiated is not None:
                await db.insert_control_audit_event(
                    EVT_MANAGED_BOT_TOKEN_REPLACED_CONFIRMED,
                    actor_user_id=creator_id or None,
                    network_bot_id=nid, detail=detail)
                log.info("MANAGED_BOT_TOKEN_REPLACED_CONFIRMED "
                         "network_bot_id=%s bot_id=%s", nid, bot_tg_id)
            else:
                await db.insert_control_audit_event(
                    EVT_MANAGED_BOT_UPDATED, actor_user_id=creator_id or None,
                    network_bot_id=nid, detail=detail)
        except Exception:  # noqa: BLE001 — audit is best-effort
            pass

    # ------------------------------------------------------------------
    # D) ADMIN token replacement (atomic, failure-safe)
    # ------------------------------------------------------------------
    async def replace_token_atomic(self, ns, update, context,
                                   network_bot_id: int,
                                   admin_user_id: int) -> None:
        """Replace a PLATFORM_MANAGED bot's token through Telegram's
        managed-bot API. Order of operations (never destroy the working
        credential first):

        1. ``Bot.replace_managed_bot_token`` (revokes the old token
           server-side);
        2. getMe validation + identity match against the REGISTERED
           telegram_bot_id;
        3. vault encrypt (fail-closed);
        4. atomic DB credential swap;
        5. worker restart + health check; only then is the old state
           retired. ANY failure BEFORE the swap leaves the stored
           credential byte-identical (honestly reported)."""
        log = self._log(ns)
        db = self._db(ns)
        q = getattr(update, "callback_query", None)
        chat_id = getattr(update, "effective_chat", None)
        chat_id = getattr(chat_id, "id", None) if chat_id is not None else None
        nid = int(network_bot_id or 0)

        async def _report(text: str, alert: bool = False) -> None:
            if q is not None:
                await _ns_call(ns, "safe_answer_callback", q, text,
                                     default=None, show_alert=alert)
            elif chat_id is not None:
                await _ns_call(ns, "safe_send_text", context.bot,
                                     chat_id, text, default=None)

        if db is None:
            await _report("Platform services are not ready.", alert=True)
            return
        row = None
        try:
            row = await db.get_network_bot(nid)
        except Exception:  # noqa: BLE001
            row = None
        if not row:
            await _report("Bot not found.", alert=True)
            return
        if str(row.get("management_mode")) != MGMT_PLATFORM_MANAGED:
            log.info("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                     "result=failed reason=not_platform_managed "
                     "user_id=%s", nid, admin_user_id)
            await _report("Only platform-managed bots support managed "
                          "token replacement.", alert=True)
            return
        cred = None
        try:
            cred = await db.get_network_bot_credential(nid)
        except Exception:  # noqa: BLE001
            cred = None
        if not cred:
            log.info("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                     "result=failed reason=no_stored_credential user_id=%s",
                     nid, admin_user_id)
            await _report("No stored credential for this bot.",
                          alert=True)
            return
        tg_id = int(row.get("telegram_bot_id") or 0)
        username = str(row.get("username") or "")

        # 1) ask Telegram for a fresh token (old one is revoked NOW,
        #    server-side — the swap below must complete to recover).
        new_token = ""
        try:
            new_token = str(await context.bot.replace_managed_bot_token(
                user_id=tg_id) or "")
        except Exception as exc:  # noqa: BLE001
            log.warning("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                        "result=failed reason=replace_api_failed "
                        "error=%s user_id=%s", nid, type(exc).__name__,
                        admin_user_id)
        if not new_token:
            await _report("❌ Telegram did not return a new token. The "
                          "previous credential was kept untouched.",
                          alert=True)
            return

        # 2) getMe validation + identity match (direct transport).
        validator = _ns_get(ns, "_net_validate_token_via_telegram")
        if callable(validator):
            try:
                val = await validator(new_token)
            except Exception:  # noqa: BLE001
                val = None
            if not isinstance(val, dict) or not val.get("ok") \
                    or int((val.get("bot") or {}).get("id") or 0) != tg_id:
                reason = (str((val or {}).get("reason")
                              or "identity_mismatch")
                          if isinstance(val, dict) and not val.get("ok")
                          else "identity_mismatch")
                log.warning("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                            "result=failed reason=%s user_id=%s (the "
                            "previous credential was kept untouched)",
                            nid, reason, admin_user_id)
                await _report(
                    "❌ The new token failed validation "
                    f"({reason}). The previous credential was kept "
                    "untouched.", alert=True)
                return

        # 3) encrypt (fail-closed).
        vault = self._vault(ns)
        if vault is None:
            log.warning("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                        "result=failed reason=vault_unavailable user_id=%s",
                        nid, admin_user_id)
            await _report("❌ Credential vault unavailable. The previous "
                          "credential was kept untouched.", alert=True)
            return
        try:
            encrypted = vault.encrypt(new_token)
        except Exception as exc:  # noqa: BLE001 — fail-closed vault
            log.warning("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                        "result=failed reason=encrypt_refused error=%s "
                        "user_id=%s", nid, type(exc).__name__,
                        admin_user_id)
            await _report("❌ Encryption refused (dedicated key not "
                          "configured). The previous credential was kept "
                          "untouched.", alert=True)
            return

        # 4) ATOMIC credential swap.
        key_version = int(getattr(vault, "key_version", 1) or 1)
        await db.replace_network_bot_credential(
            nid, encrypted_token=encrypted, key_version=key_version)

        # 5) worker restart + health check (the old worker runs a token
        #    Telegram just revoked).
        workers = self._workers(ns)
        registry = self._registry(ns)
        worker = None
        if workers is not None:
            try:
                if workers.get(nid) is not None:
                    await workers.stop_worker(nid)
            except Exception:  # noqa: BLE001
                pass
            try:
                worker = await workers.start_worker(nid, tg_id, username,
                                                    new_token)
            except Exception as exc:  # noqa: BLE001
                log.warning("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                            "worker_restart_failed error=%s", nid,
                            type(exc).__name__)
                worker = None
        health_ok = False
        if worker is not None and workers is not None:
            try:
                client = workers.get_bot_client(nid)
                if client is not None and callable(
                        getattr(client, "get_me", None)):
                    await client.get_me()
                    health_ok = True
            except Exception:  # noqa: BLE001
                health_ok = False
            if health_ok and registry is not None:
                try:
                    await registry.mark_active(nid)
                    await registry.mark_health(nid, "HEALTHY")
                except Exception:  # noqa: BLE001
                    pass

        # 6) retire old state — the replacement marker lets the follow-up
        #    Update.managed_bot complete the flow (audit).
        _prune_pending_replacements()
        _pending_token_replacements[int(tg_id)] = _now()
        try:
            await db.insert_control_audit_event(
                EVT_MANAGED_BOT_TOKEN_REPLACED,
                actor_user_id=int(admin_user_id), network_bot_id=nid,
                detail=("username=@%s worker=%s health=%s"
                        % (username,
                           "restarted" if worker is not None else "failed",
                           "ok" if health_ok else "unchecked")))
        except Exception:  # noqa: BLE001
            pass
        log.info("MANAGED_BOT_TOKEN_REPLACED network_bot_id=%s "
                 "result=ok worker=%s health_check=%s user_id=%s",
                 nid, "restarted" if worker is not None else "failed",
                 "ok" if health_ok else "unchecked", admin_user_id)
        worker_txt = ("restarted" if worker is not None
                      else "will start at the next restart")
        await _report(
            f"✅ Managed bot token replaced for @{username}.\n"
            f"Worker: {worker_txt}\n"
            f"Health check: {'ok' if health_ok else 'pending'}")

    # ------------------------------------------------------------------
    # E) capability diagnostics (truthful)
    # ------------------------------------------------------------------
    async def capability_status(self, ns,
                                bot=None) -> Dict[str, Any]:
        """The main bot's own managed-bot capability.

        Prefers a fresh ``bot.get_me()`` (when a context bot is
        available), falls back to the startup-cached User. Returns
        ``{"can_manage_bots": True|False|None, "ready": bool}`` —
        ``None`` means Telegram did not report the flag (truthful)."""
        me = None
        if bot is not None:
            getter = getattr(bot, "get_me", None)
            if callable(getter):
                try:
                    me = await getter()
                except Exception:  # noqa: BLE001
                    me = None
        if me is None:
            me = _ns_get(ns, "_MAIN_BOT_ME", None)
        elif _ns_get(ns, "_MAIN_BOT_ME", None) is not me:
            try:
                ns._MAIN_BOT_ME = me  # refresh the cache
            except Exception:  # noqa: BLE001
                pass
        can: Optional[bool] = None
        if me is not None:
            raw = getattr(me, "can_manage_bots", None)
            if raw is not None:
                can = bool(raw)
        return {"can_manage_bots": can, "ready": can is True}

    async def worker_capability(self, bot=None) -> Dict[str, Any]:
        """b10 §7 (B10-B2): a NETWORK WORKER bot's own managed-bot
        capability — a FRESH getMe on the WORKER's bot client.

        Deliberately does NOT touch the ``ns._MAIN_BOT_ME`` cache (that
        is the MAIN bot's identity — refreshing it with a worker's getMe
        would poison the truthful main-bot diagnostic). Returns
        ``{"can_manage_bots": True|False|None, "ready": bool}``; ``None``
        means Telegram did not report the flag (the caller then refuses
        honestly with reason=worker_capability_unknown)."""
        me = None
        if bot is not None:
            getter = getattr(bot, "get_me", None)
            if callable(getter):
                try:
                    me = await getter()
                except Exception:  # noqa: BLE001
                    me = None
        can: Optional[bool] = None
        if me is not None:
            raw = getattr(me, "can_manage_bots", None)
            if raw is not None:
                can = bool(raw)
        return {"can_manage_bots": can, "ready": can is True}

    async def _capability_cache_stale(self, db,
                                      checked_at: Optional[str]) -> bool:
        """BOT-13 §2: is a persisted capability older than the TTL?

        TTL setting: ``network_capability_ttl_seconds`` (default 300).
        A missing/unparseable ``checked_at`` counts as STALE (unknown age
        → refresh), a missing db likewise — the caller then falls back to
        the live getMe check before any refusal (never a permanent False).
        """
        if db is None:
            return True
        if not checked_at:
            return True
        ttl = 300
        try:
            getter = getattr(db, "get_setting_int", None)
            if callable(getter):
                ttl = int(await getter("network_capability_ttl_seconds",
                                       300))
        except Exception:  # noqa: BLE001 — default TTL on any read error
            ttl = 300
        try:
            from datetime import datetime, timezone
            stamp = str(checked_at).replace("Z", "+00:00")
            when = datetime.fromisoformat(stamp)
            if when.tzinfo is None:
                when = when.replace(tzinfo=timezone.utc)
            age = (datetime.now(timezone.utc) - when).total_seconds()
            return age >= max(0, ttl)
        except Exception:  # noqa: BLE001 — unparseable → stale (refresh)
            return True


def _prune_pending_replacements() -> None:
    now = _now()
    for k in [k for k, v in _pending_token_replacements.items()
              if now - v > _PENDING_REPLACE_TTL]:
        _pending_token_replacements.pop(k, None)


# ----------------------------------------------------------------------
# BOT-11 (spec §1) — the bulk capability refresh (persisted per bot)
# ----------------------------------------------------------------------
async def refresh_all_capabilities(ns) -> Dict[str, Any]:
    """BOT-11 (spec §1): refresh the persisted getMe-derived
    ``can_manage_bots`` capability for EVERY ACTIVE registered bot.

    For each bot: resolve the worker bot client through
    ``ns._net_workers`` (get_bot_client), call ``get_me()``, read
    ``can_manage_bots`` (True/False/None) and persist via
    ``db.set_network_bot_capability``. A bot WITHOUT a running worker
    persists the honest NULL (+ capability_checked_at) with the reason
    logged — NEVER a fabricated capability. Logs
    MANAGED_BOT_CAPABILITY_REFRESH (start, counts) +
    MANAGED_BOT_CAPABILITY_RESULT (per bot: nid + can=True/False/None +
    reason when None).

    Returns {"checked": N, "true": [nid...], "false": [nid...],
    "unknown": [nid...]} — the truthful three-way split."""
    db = _ns_get(ns, "db")
    workers = _ns_get(ns, "_net_workers")
    log = _ns_get(ns, "logger", None) or logger
    setter = getattr(db, "set_network_bot_capability", None) \
        if db is not None else None
    result: Dict[str, Any] = {"checked": 0, "true": [], "false": [],
                              "unknown": []}
    bots: list = []
    if db is not None:
        try:
            bots = list(await db.list_network_bots() or [])
        except Exception:  # noqa: BLE001 — honest empty refresh
            log.warning("MANAGED_BOT_CAPABILITY_REFRESH list failed "
                        "(reporting zero checked)", exc_info=True)
            bots = []
    active = [b for b in bots
              if str((b or {}).get("status") or "") == "ACTIVE"]
    log.info("MANAGED_BOT_CAPABILITY_REFRESH start total=%s active=%s "
             "(getMe can_manage_bots per ACTIVE bot, persisted per bot)",
             len(bots), len(active))

    async def _persist(nid: int, can: Optional[bool]) -> None:
        if callable(setter):
            try:
                await setter(int(nid), can)
            except Exception:  # noqa: BLE001 — persistence best-effort
                pass

    for b in active:
        nid = int((b or {}).get("network_bot_id")
                  or (b or {}).get("id") or 0)
        if nid <= 0:
            continue
        result["checked"] += 1
        client = None
        if workers is not None:
            try:
                client = workers.get_bot_client(nid)
            except Exception:  # noqa: BLE001
                client = None
        if client is None:
            await _persist(nid, None)
            log.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                     "can=None reason=no_running_worker", nid)
            result["unknown"].append(nid)
            continue
        getter = getattr(client, "get_me", None)
        if not callable(getter):
            await _persist(nid, None)
            log.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                     "can=None reason=no_get_me", nid)
            result["unknown"].append(nid)
            continue
        try:
            me = await getter()
        except Exception as exc:  # noqa: BLE001 — honest unknown
            await _persist(nid, None)
            log.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s "
                     "can=None reason=getMe_failed detail=%s", nid,
                     type(exc).__name__)
            result["unknown"].append(nid)
            continue
        raw = getattr(me, "can_manage_bots", None)
        can = None if raw is None else bool(raw)
        await _persist(nid, can)
        log.info("MANAGED_BOT_CAPABILITY_RESULT network_bot_id=%s can=%s",
                 nid, "None" if can is None
                 else ("True" if can else "False"))
        result["true" if can is True else
               ("false" if can is False else "unknown")].append(nid)
    log.info("MANAGED_BOT_CAPABILITY_REFRESH done checked=%s true=%s "
             "false=%s unknown=%s", result["checked"],
             len(result["true"]), len(result["false"]),
             len(result["unknown"]))
    return result


# ----------------------------------------------------------------------
# Facade functions — the runtime-namespace wiring entry points (the
# same ``ns``-injection pattern as app/network/lifecycle.py).
# ----------------------------------------------------------------------
def coordinator_for(ns) -> ManagedBotCoordinator:
    """Build a coordinator from the runtime namespace's singletons."""
    return ManagedBotCoordinator(
        db=_ns_get(ns, "db"),
        registry=_ns_get(ns, "_net_registry"),
        workers=_ns_get(ns, "_net_workers"),
        vault=_ns_get(ns, "_net_vault"),
        logger=_ns_get(ns, "logger", logger),
    )


async def begin_managed_creation(ns, update, context, user) -> None:
    """Facade: render the managed-bot creation request (see
    ManagedBotCoordinator.begin_managed_creation)."""
    await coordinator_for(ns).begin_managed_creation(ns, update, context,
                                                      user)


async def handle_managed_bot_created(ns, update, context) -> None:
    """Facade: Message.managed_bot_created completion handler."""
    await coordinator_for(ns).handle_managed_bot_created(ns, update,
                                                          context)


async def handle_managed_bot_updated(ns, update, context) -> None:
    """Facade: Update.managed_bot (ManagedBotUpdated) handler."""
    await coordinator_for(ns).handle_managed_bot_updated(ns, update,
                                                          context)


async def replace_managed_bot_token_atomic(ns, update, context,
                                           network_bot_id: int,
                                           admin_user_id: int) -> None:
    """Facade: ADMIN managed-bot token replacement (atomic)."""
    await coordinator_for(ns).replace_token_atomic(
        ns, update, context, int(network_bot_id), int(admin_user_id))


async def capability_status(ns, bot=None) -> Dict[str, Any]:
    """Facade: the truthful managed-bot capability diagnostic."""
    return await coordinator_for(ns).capability_status(ns, bot)


async def send_setup_wizard(ns, context, chat_id, network_bot_id: int,
                            username: str, *, bot_id: int = 0,
                            state: str = "created",
                            status_line: str = "",
                            note: str = "") -> None:
    """Facade: render + send the COMPLETE 6-step §4 setup wizard.

    The ATTACH BOT TOKEN success path (network_ui) calls this with
    ``state="attached"`` after the token is validated + persisted;
    the CREATE NETWORK BOT path goes through
    ``handle_managed_bot_created`` → ``_send_success`` with
    ``state="created"``. Emits NETWORK_BOT_SETUP_OPEN (+
    NETWORK_BOT_ATTACHED / NETWORK_BOT_CREATED)."""
    await coordinator_for(ns).send_setup_wizard(
        ns, context, chat_id, int(network_bot_id), str(username),
        bot_id=int(bot_id), state=str(state), status_line=str(status_line),
        note=str(note))


async def run_setup_verification(ns, network_bot_id: int, *,
                                 owner_user_id: Optional[int] = None,
                                 chat_id: Optional[int] = None) \
        -> Dict[str, Any]:
    """Facade: the wizard's Verify engine (the run_verification
    equivalent for the §4 wizard — runs the REAL own-client
    membership test + the full ``ns._fdb.verify_delivery_channel``
    production chain, with the NETWORK_BOT_SETUP_* telemetry wired
    in). Safe fields only — never tokens."""
    return await coordinator_for(ns).run_setup_verification(
        ns, int(network_bot_id), owner_user_id=owner_user_id,
        chat_id=chat_id)


async def handle_setup_wizard_callback(ns, update, context, user,
                                       network_bot_id: int,
                                       action: str = "") -> None:
    """Facade: the wizard's own buttons — the ``nbot:<id>:setup``
    (Add to Channel) and ``nbot:<id>:verify`` (Verify) NET_BOT_CB
    sub-actions. The network_ui ``_handle_net_bot_callback``
    dispatcher delegates here with a one-line wiring:

        if action in ("setup", "verify"):
            await managed_bots.handle_setup_wizard_callback(
                ns, update, context, user, nid, action)
            return

    Until that delegation lands, unknown sub-actions degrade to the
    per-bot management panel (never a dead button)."""
    await coordinator_for(ns).handle_setup_wizard_callback(
        ns, update, context, user, int(network_bot_id), str(action))


async def worker_capability_status(ns, bot=None) -> Dict[str, Any]:
    """Facade: a NETWORK WORKER bot's own managed-bot capability
    (b10 §7 — fresh getMe on the worker's client; never touches the
    main-bot cache)."""
    return await coordinator_for(ns).worker_capability(bot)


def log_managed_bots_ready(log, can_manage_bots) -> None:
    """The truthful startup diagnostic — None means Telegram did not
    report the flag on the main bot's own getMe."""
    if can_manage_bots is True:
        val = "True"
    elif can_manage_bots is False:
        val = "False"
    else:
        val = "None"
    (log or logger).info("MANAGED_BOTS_READY can_manage_bots=%s "
                         "(managed-bot creation %s)", val,
                         "available" if val == "True"
                         else ("unavailable" if val == "False"
                               else "capability not reported by Telegram"))


__all__ = [
    "ManagedBotCoordinator",
    "MANAGED_BOT_PENDING_STATE_KEY",
    "MANAGED_BOT_FLOW_TIMEOUT_SECONDS",
    "next_managed_bot_request_id",
    "coordinator_for",
    "begin_managed_creation",
    "handle_managed_bot_created",
    "handle_managed_bot_updated",
    "replace_managed_bot_token_atomic",
    "capability_status",
    "worker_capability_status",
    "refresh_all_capabilities",
    "log_managed_bots_ready",
    # BOT-45/46 Task H (master prompt §4) — the 6-step setup wizard:
    "send_setup_wizard",
    "run_setup_verification",
    "handle_setup_wizard_callback",
    "log_network_bot_setup_telemetry",
    "build_setup_wizard_text",
    "build_setup_wizard_keyboard",
    "render_setup_error_state",
    "classify_setup_telegram_error",
    "classify_setup_verification_reason",
    "NETWORK_BOT_SETUP_TELEMETRY_EVENTS",
    "NETWORK_BOT_SETUP_ERROR_STATES",
    "SETUP_STATE_CONNECTED",
    "SETUP_STATE_PERMISSION_MISSING",
    "SETUP_STATE_NOT_FOUND",
    "SETUP_STATE_TELEGRAM_ERROR",
    "SETUP_STATE_TIMEOUT",
    "SETUP_STATE_PENDING",
    "SETUP_STATE_MEMBERSHIP_UNAVAILABLE",
]
