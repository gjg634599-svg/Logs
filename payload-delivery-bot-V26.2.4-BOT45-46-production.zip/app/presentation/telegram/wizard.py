"""Payload Creation Wizard — PCW steps, creation, edits, wizard state.

Extracted VERBATIM from the legacy bot.py monolith as part of
the ARCHITECTURE PROPER BREAKDOWN. All functions here are
composed into the shared runtime namespace
(app/presentation/telegram/namespace.py -> runtime);
cross-section state and collaborators resolve through that
namespace at CALL time (the late-binding contract the
regression suites rely on).
"""
from __future__ import annotations



def clear_wizard_states(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear all pending wizard/awaiting states. Called when any panel opens
    to prevent stale state leakage (e.g. 'Send start message text' persisting
    when the admin navigates to Storage).

    Also cancels any pending forward/broadcast batch debounce timers so a
    navigation away does not fire a stale collection generation.

    BOT-45/46 (Task F): clearing a LIVE, not-yet-terminated Payload
    Creation Wizard state here is the 'admin backed out / navigated away'
    terminal — it emits WIZARD_CANCELLED (never a silent mid-wizard end,
    the production message-872 evidence class).
    """
    # BOT-45/46: the pcw state is popped through this shared helper on every
    # panel navigation — emit the cancel terminal BEFORE the pop.
    try:
        _pcw_maybe_cancel_terminal(context, "navigation")
    except Exception:  # noqa: BLE001 — terminal telemetry is best-effort
        pass
    for key in ALL_WIZARD_STATES:
        context.user_data.pop(key, None)
    # Cancel + clear pending batch debounce timers (Issue 1: never fire a
    # collection generation after the admin navigated away).
    for batch_key in ("fwd_batch_multi",):
        timer_key = f"{batch_key}_timer"
        context.user_data.pop(timer_key, None)
        context.user_data.pop(batch_key, None)
    # Cancel any pending browse auto-delete timer (Issue 2).
    for k in list(context.user_data.keys()):
        if k.startswith("browse_msg_"):
            entry = context.user_data.pop(k, None)
            if entry and isinstance(entry, dict):
                task = entry.get("task")
                if task:
                    try:
                        task.cancel()
                    except Exception:  # noqa: BLE001
                        pass



def _pcw_step_progress(step: str) -> str:
    """Return a 'Step X/6' progress label for the wizard footer."""
    n = PCW_STEP_NUMBER.get(step, 1)
    return f"Step {n}/{PCW_TOTAL_STEPS}"



def _pcw_new_state(index_id: Optional[int] = None) -> Dict[str, Any]:
    """Build a fresh wizard state with safe defaults (create mode).

    BOT7 wizard ownership: `owner_id` stamps the admin who started the wizard.
    context.user_data is already per-user in PTB, so this is defense-in-depth —
    the text-input handler rejects any state whose owner_id doesn't match the
    acting user (stale/foreign wizard state can never mutate another admin's
    object).
    """
    return {
        "step": "name",
        "mode": "create",
        "owner_id": None,
        "edit_payload_id": None,
        "index_id": index_id,
        "collection_msg_ids": None,
        "collection_channel_id": None,
        "collection_code": None,
        "name": None,                        # routing slug (sanitized, immutable)
        "display_name": None,                # BOTV13: human-readable title (editable)
        "access_policy": ACCESS_POLICY_DEFAULT,
        "required_referrals": REFERRAL_REQUIRED_DEFAULT,
        "watch_ads_enabled": 0,               # WATCH_AD (v25): default OFF
        "preview_mode": PREVIEW_MODE_AUTO,  # V3: default to Auto Preview
        "preview_media_file_id": None,
        "preview_media_type": None,
        "preview_description": None,
        "preview_source": None,  # auto|select|custom|disabled
        "delete_after": None,  # inherit global
        "one_time": 0,
    }



def _pcw_is_collection(state: Dict[str, Any]) -> bool:
    """True if the wizard is operating on a collection (2+ files)."""
    msg_ids = state.get("collection_msg_ids")
    return bool(msg_ids) and len(msg_ids) >= 2



def _pcw_file_count(state: Dict[str, Any]) -> int:
    """Number of files this payload will deliver (1 for single, N for collection)."""
    msg_ids = state.get("collection_msg_ids")
    if msg_ids:
        return len(msg_ids)
    return 1 if state.get("index_id") else 0



def _pcw_mode_label(state: Dict[str, Any]) -> str:
    """Header label: 'Create Payload' or 'Edit Payload'."""
    return "Edit Payload" if state.get("mode") == "edit" else "Create Payload"



def _pcw_file_summary(state: Dict[str, Any]) -> str:
    """One-line summary of the selected file(s) for display."""
    msg_ids = state.get("collection_msg_ids")
    if msg_ids:
        return f"\U0001F4E6 Collection: {len(msg_ids)} files"
    if state.get("index_id"):
        return "\U0001F4C4 Single file"
    return "\u2014 (no file selected)"



def _pcw_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    return context.user_data.get(PCW_KEY)



def _pcw_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    # BOT-45/46 (Task F): an unterminated live wizard cleared here is the
    # cancel terminal (user backed out / session expired) — never silent.
    try:
        _pcw_maybe_cancel_terminal(context, "pcw_clear")
    except Exception:  # noqa: BLE001 — terminal telemetry is best-effort
        pass
    context.user_data.pop(PCW_KEY, None)



def nav_set(context: ContextTypes.DEFAULT_TYPE, origin: str,
            payload_id: Optional[int] = None,
            list_page: Optional[int] = None) -> None:
    """Set the navigation context so submenus know where to return.

    PHASE 6 §7: `list_page` preserves the originating Payload List page —
    every payload-detail child screen returns to the detail, and the detail's
    Back returns to that exact list page.
    """
    context.user_data[NAV_KEY] = {"origin": origin, "payload_id": payload_id,
                                  "list_page": list_page}



def nav_get(context: ContextTypes.DEFAULT_TYPE) -> Optional[Dict[str, Any]]:
    """Get the current navigation context (or None)."""
    return context.user_data.get(NAV_KEY)



def nav_clear(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear the navigation context."""
    context.user_data.pop(NAV_KEY, None)



def _nav_list_page(context: ContextTypes.DEFAULT_TYPE) -> Optional[int]:
    """PHASE 6 §7 helper: the preserved Payload List page (or None)."""
    ctx = nav_get(context)
    if not ctx:
        return None
    lp = ctx.get("list_page")
    if lp is None:
        return None
    try:
        return max(0, int(lp))
    except (TypeError, ValueError):
        return None



async def nav_return(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Return to the originating page based on the navigation context.

    Returns True if a return was performed, False if no context exists
    (caller should fall back to its default behavior).
    """
    ctx = nav_get(context)
    if not ctx:
        return False
    origin = ctx.get("origin")
    pid = ctx.get("payload_id")
    if origin == "payload_details" and pid is not None:
        await pm_payload_detail(update, context, int(pid))
        return True
    return False



def _pcw_clear_awaiting_flags(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear all leftover wizard awaiting_* flags after a successful create."""
    for flag in _PCW_AWAITING_FLAGS:
        context.user_data.pop(flag, None)



def _pcw_step_index(step: str) -> int:
    try:
        return PCW_STEPS.index(step)
    except ValueError:
        return 0



def _policy_label_full(policy: str) -> str:
    return {
        ACCESS_POLICY_OPEN: "\U0001F7E2 Open \u2014 no gate",
        ACCESS_POLICY_FORCE_JOIN: "\U0001F6E1 Force Join",
        ACCESS_POLICY_FORCE_JOIN_REFERRAL: "\U0001F512 Force Join + Referral",
        ACCESS_POLICY_PASSWORD: "\U0001F511 Password (future)",
        ACCESS_POLICY_COUPON: "\U0001F3AB Coupon (future)",
        ACCESS_POLICY_PAYMENT: "\U0001F4B3 Payment (future)",
        ACCESS_POLICY_VIP: "\U0001F451 VIP (future)",
        ACCESS_POLICY_CUSTOM: "\u2699 Custom (future)",
    }.get(policy, policy)



def _preview_label_full(mode: str) -> str:
    return {
        PREVIEW_MODE_DISABLED: "\u26D4 Disabled",
        PREVIEW_MODE_AUTO: "\U0001F50D Auto Preview",
        PREVIEW_MODE_SELECT: "\U0001F4C2 Select Existing File",
        PREVIEW_MODE_CUSTOM: "\U0001F4E4 Upload Custom Preview",
        PREVIEW_MODE_THUMBNAIL: "\U0001F5BC Thumbnail",
        PREVIEW_MODE_DESCRIPTION: "\U0001F4DD Preview Text",
    }.get(mode, mode)



def _delete_timer_label(da: Optional[int]) -> str:
    if da is None:
        return "inherit global"
    if da == 0:
        return "never"
    return f"{da}s"



async def pcw_log_wizard_event(event_type: str, **kw: Any) -> None:
    """Reuse the existing access_events analytics infrastructure for wizard
    lifecycle events. Single analytics system — no second logger introduced."""
    await db.log_access_event(event_type, **kw)



async def pcw_auto_generate_name(state: Dict[str, Any]) -> str:
    """Generate a collision-free payload name automatically (Skip button).

    Uses the selected file's slug as the base (single-file), or a 'coll_'
    prefix + short hex for collections. Appends _2, _3 ... on collision so the
    result is always unique and deep-link-compatible (?start=<name>).
    """
    base = ""
    if _pcw_is_collection(state):
        base = "coll_" + _secrets.token_hex(3)
    elif state.get("index_id"):
        frow = await db.get_indexed_file_by_id(state["index_id"])
        if frow:
            base = sanitize_slug(frow["file_name"] or f"file_{state['index_id']}")
    if not base:
        base = "payload_" + _secrets.token_hex(3)
    slug = base
    n = 2
    while await db.get_payload(slug):
        slug = f"{base}_{n}"
        n += 1
        if n > 1000:
            # Extremely unlikely fallback — append random hex.
            slug = f"{base}_{_secrets.token_hex(2)}"
            break
    return slug



async def pcw_start(update: Update, context: ContextTypes.DEFAULT_TYPE,
                    index_id: Optional[int] = None) -> None:
    """Launch the Payload Creation Wizard.

    If index_id is provided, the file is pre-selected (launched from file
    detail / recent files / single-file flow). If None, the wizard asks for a
    message ID after the name step.
    """
    # BOT7: server-side permission enforcement (hiding buttons is NOT
    # security). Owner/env admins bypass via has_permission.
    _uid = update.effective_user.id if update.effective_user else None
    if _uid is None or not await has_permission(_uid, PERM_PAYLOAD_CREATE):
        logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=pcw_start "
                    "result=denied reason=missing_perm perm=%s", _uid,
                    PERM_PAYLOAD_CREATE)
        await _perm_denied_notice(update, context, "create payloads")
        return
    clear_wizard_states(context)
    state = _pcw_new_state(index_id=index_id)
    state["owner_id"] = update.effective_user.id if update.effective_user else None
    context.user_data[PCW_KEY] = state
    logger.info("BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s mode=create",
                state["owner_id"])
    await pcw_log_wizard_event("wizard_started")
    await pcw_show_name_step(update, context)



async def pcw_start_collection(update: Update, context: ContextTypes.DEFAULT_TYPE,
                               channel_id: int, message_ids: List[int]) -> None:
    """Launch the wizard with a collection pre-selected (2+ forwarded files).

    The collection is NOT created until the admin confirms. The wizard stores
    the message_ids in state and creates the collection row atomically inside
    create_payload_from_wizard() on confirmation. Transitions directly into
    Step 1 (no extra "Launching" message — keeps the chat clean).
    """
    # BOT7: server-side permission enforcement (collection creation).
    _uid = update.effective_user.id if update.effective_user else None
    if _uid is None or not await has_permission(_uid, PERM_PAYLOAD_CREATE):
        logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=pcw_start_collection "
                    "result=denied reason=missing_perm perm=%s", _uid,
                    PERM_PAYLOAD_CREATE)
        await _perm_denied_notice(update, context, "create payloads")
        return
    clear_wizard_states(context)
    state = _pcw_new_state(index_id=None)
    state["collection_msg_ids"] = list(message_ids)
    state["collection_channel_id"] = channel_id
    state["owner_id"] = update.effective_user.id if update.effective_user else None
    context.user_data[PCW_KEY] = state
    logger.info("BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s mode=create_collection "
                "files=%s", state["owner_id"], len(message_ids))
    await pcw_log_wizard_event("wizard_started")
    await pcw_show_name_step(update, context)



async def pcw_start_edit(update: Update, context: ContextTypes.DEFAULT_TYPE,
                         payload_id: int) -> None:
    """Launch the wizard in EDIT mode — preload all existing values.

    Reuses the exact same wizard UI as creation. Only modified values are
    saved (diffed against the preloaded snapshot in apply_wizard_edits()).
    Collection membership/ordering is NEVER editable from the wizard.

    V15: sets the navigation context so wizard Cancel/Back return to the
    Payload Details page (not the link generator).
    """
    # BOT7: server-side permission enforcement for payload editing.
    _uid = update.effective_user.id if update.effective_user else None
    if _uid is None or not await has_permission(_uid, PERM_PAYLOAD_EDIT):
        logger.info("BOT6_ADMIN_PERMISSION user_id=%s action=pcw_start_edit "
                    "payload_id=%s result=denied reason=missing_perm perm=%s",
                    _uid, payload_id, PERM_PAYLOAD_EDIT)
        await _perm_denied_notice(update, context, "edit payloads")
        return
    row = await db.get_payload_by_id(payload_id)
    if not row:
        await safe_answer_callback(update.callback_query, "Payload not found.", show_alert=True)
        return
    clear_wizard_states(context)
    # V15: set navigation context so Cancel/Home/Back return to payload details.
    nav_set(context, "payload_details", payload_id=payload_id)
    state = _pcw_new_state(index_id=row["index_id"])
    state["mode"] = "edit"
    state["edit_payload_id"] = payload_id
    state["name"] = row["payload"]  # immutable routing slug (for display only)
    # BOTV13: preload the editable display_name.
    state["display_name"] = row["display_name"] if "display_name" in row.keys() and row["display_name"] else None
    state["delete_after"] = row["delete_after"]
    state["one_time"] = int(row["one_time"]) if row["one_time"] else 0
    policy = row["access_policy"] if "access_policy" in row.keys() else None
    if not policy:
        policy = await db.get_access_policy(payload_id)
    state["access_policy"] = (policy if policy in ACCESS_POLICIES_IMPLEMENTED
                              else ACCESS_POLICY_DEFAULT)
    # WATCH_AD (v25): preload the payload's current Watch Ads state so the
    # wizard shows and can flip OFF -> ON / ON -> OFF. Editing unrelated
    # fields never erases it (the diff only writes when the value changed).
    state["watch_ads_enabled"] = 1 if _safe_row_get(row, "watch_ads_enabled") else 0
    # Preload referral campaign + preview config if present.
    campaign = await db.get_referral_campaign_by_payload(payload_id)
    if campaign:
        state["required_referrals"] = int(campaign["required_referrals"])
        state["preview_mode"] = campaign["preview_mode"] or PREVIEW_MODE_DISABLED
        state["preview_media_file_id"] = campaign["preview_media_file_id"] if "preview_media_file_id" in campaign.keys() else None
        state["preview_media_type"] = campaign["preview_media_type"] if "preview_media_type" in campaign.keys() else None
        state["preview_description"] = campaign["preview_description"] if "preview_description" in campaign.keys() else None
    # Detect collection: payload_code may be a c<code> deep-link. We cannot
    # change collection membership from the wizard (immutable), so we just
    # record the code for display.
    # V26 (message-872 identity fix): the CANONICAL predicate — a
    # single-file payload named 'clip…' is never treated as its
    # (nonexistent) collection.
    pcode = row["payload"]
    if is_collection_link(pcode):
        state["collection_code"] = parse_collection_link(pcode)
    state["owner_id"] = update.effective_user.id if update.effective_user else None
    context.user_data[PCW_KEY] = state
    logger.info("BOT6_ADMIN_WIZARD_START wizard=pcw user_id=%s mode=edit payload_id=%s",
                state["owner_id"], payload_id)
    await pcw_log_wizard_event("wizard_started", payload_id=payload_id)
    await pcw_show_name_step(update, context)



async def pcw_show_name_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 1: Payload Name (optional — Send custom name or Skip to auto-generate).

    Shows the Selected File / Selected Collection before asking for the name.
    """
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "name"
    mode_lbl = _pcw_mode_label(state)
    # Selected File / Collection summary (no IDs exposed).
    if _pcw_is_collection(state):
        selected_line = f"\U0001F4E6 Selected Collection\nFiles: {_pcw_file_count(state)}\nReady to configure."
    elif state.get("index_id"):
        frow = await db.get_indexed_file_by_id(state["index_id"])
        if frow:
            # BOT-43: the filename renders as a code span — this step is a
            # ParseMode.MARKDOWN message and a RAW filename with unmatched
            # markdown entities (`[`, `_`, `*`, backtick) crashes the send
            # with "Can't parse entities: can't find end of the entity"
            # (the production file_pk=681 wizard failure). Inside a code
            # span Telegram ignores every special character except the
            # backtick — md_code_span neutralizes that too.
            selected_line = (
                f"\U0001F4C4 Selected File\n"
                f"{md_code_span(truncate(frow['file_name'], 60) or '(unnamed)')}"
                f"\nReady to configure.")
        else:
            selected_line = "\U0001F4C4 Selected File\nReady to configure."
    else:
        selected_line = "\U0001F4C4 No file selected yet\nSend a Message ID after the name, or forward a file."
    cur_name = state.get("display_name") or state.get("name")
    name_line = f"\nCurrent: {md_code_span(cur_name)}" if cur_name else ""
    text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('name')}\n\n"
        f"{selected_line}\n"
        f"\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\n"
        f"\U0001F4DD Payload Name{name_line}\n\n"
        "Send a custom name, or tap Skip to auto-generate one.\n"
        "Human-readable names are accepted (spaces, mixed case OK)."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u270F\uFE0F Send Name", callback_data="pcw:nameinput"),
         InlineKeyboardButton("\u23ED\uFE0F Skip", callback_data="pcw:nameskip")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
         InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
         InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")],
    ])
    if update.callback_query:
        await safe_edit_text(update.callback_query, text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def pcw_show_file_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 1b: File selection (only when no file pre-selected)."""
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "file"
    mode_lbl = _pcw_mode_label(state)
    text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('file')}\n\n"
        f"\U0001F4DD Payload Name: {md_code_span(state['name'])}\n\n"
        "Now choose the file this payload will deliver:\n"
        "\u2022 Send a Message ID (e.g. 8619), or\n"
        "\u2022 Forward a file from a storage channel."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
         InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
         InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")],
    ])
    await safe_send_text(context.bot, update.effective_chat.id, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def pcw_show_policy_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 2: Access Policy selection."""
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "policy"
    cur = state["access_policy"]
    mode_lbl = _pcw_mode_label(state)
    rows: List[List[InlineKeyboardButton]] = []
    # Implemented policies first (selectable).
    for p in (ACCESS_POLICY_OPEN, ACCESS_POLICY_FORCE_JOIN, ACCESS_POLICY_FORCE_JOIN_REFERRAL):
        mark = "\u2713 " if p == cur else ""
        rows.append([InlineKeyboardButton(f"{mark}{_policy_label_full(p)}",
                                          callback_data=f"pcw:policy:{p}")])
    # Future policies (shown but flagged; selecting falls back to FORCE_JOIN).
    rows.append([InlineKeyboardButton("\U0001F511 Password (future)", callback_data=f"pcw:policy:{ACCESS_POLICY_PASSWORD}")])
    rows.append([InlineKeyboardButton("\U0001F4B3 Payment (future)", callback_data=f"pcw:policy:{ACCESS_POLICY_PAYMENT}")])
    rows.append([InlineKeyboardButton("\U0001F451 VIP (future)", callback_data=f"pcw:policy:{ACCESS_POLICY_VIP}")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
                 InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
                 InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")])
    rows.append([InlineKeyboardButton("\u2705 Next \u27A1\uFE0F", callback_data="pcw:next")])
    policy_text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('policy')}\n\n"
        "\U0001F510 Access Policy\n\n"
        f"Current: {_policy_label_full(cur)}\n\n"
        "Choose how users authorize before receiving this payload."
    )
    kb = InlineKeyboardMarkup(rows)
    if update.callback_query:
        await safe_edit_text(update.callback_query, policy_text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, policy_text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def pcw_show_referrals_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 3: Required Referrals (only for FORCE_JOIN_REFERRAL)."""
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "referrals"
    cur = state["required_referrals"]
    mode_lbl = _pcw_mode_label(state)
    rows: List[List[InlineKeyboardButton]] = []
    for n in REFERRAL_REQUIRED_PRESETS:
        mark = "\u2713 " if n == cur else ""
        rows.append([InlineKeyboardButton(f"{mark}{n}",
                                          callback_data=f"pcw:req:{n}")])
    rows.append([InlineKeyboardButton("\u2328\uFE0F Custom Number",
                                      callback_data="pcw:reqcustom")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
                 InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
                 InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")])
    rows.append([InlineKeyboardButton("\u2705 Next \u27A1\uFE0F", callback_data="pcw:next")])
    referrals_text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('referrals')}\n\n"
        "\U0001F465 Required Referrals\n\n"
        f"Current: {cur}\n\n"
        "0 = instant unlock (no referrals needed).\n"
        "Each payload has its OWN campaign \u2014 unlocking one never unlocks another."
    )
    kb = InlineKeyboardMarkup(rows)
    if update.callback_query:
        await safe_edit_text(update.callback_query, referrals_text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, referrals_text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def pcw_show_watchads_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """WATCH_AD (v25) — Step 4: require a verified rewarded ad for this payload.

    Toggle UI follows the existing wizard conventions (Back preserves the
    Watch Ads state, Cancel never touches the DB, Confirm persists it). The
    payload is CREATED with this configuration already applied.
    """
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "watchads"
    cur = int(state.get("watch_ads_enabled") or 0)
    mode_lbl = _pcw_mode_label(state)
    status_line = "\u2705 Enabled" if cur else "\u274C Disabled"
    rows: List[List[InlineKeyboardButton]] = [
        [InlineKeyboardButton("\u274C Disabled", callback_data="pcw:wad:0"),
         InlineKeyboardButton("\u2705 Enabled", callback_data="pcw:wad:1")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
         InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
         InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")],
        [InlineKeyboardButton("\u2705 Next \u27A1\uFE0F", callback_data="pcw:next")],
    ]
    text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('watchads')}\n\n"
        "\U0001F3AC Watch Ads\n\n"
        f"Current: {status_line}\n\n"
        "When enabled, users must complete a verified rewarded\n"
        "ad (Monetag Mini App) before this payload unlocks.\n\n"
        "Watch Ads is an independent requirement \u2014 it works\n"
        "with any access policy and never bypasses Force Join\n"
        "or referral requirements.\n\n"
        "Requires the global Watch Ads configuration:\n"
        "Settings \u2192 \U0001F3AC Watch Ads Settings."
    )
    kb = InlineKeyboardMarkup(rows)
    if update.callback_query:
        await safe_edit_text(update.callback_query, text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text,
                             parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



async def _resolve_preview(state: Dict[str, Any]) -> Dict[str, Any]:
    """V5: THE single WIZARD-TIME preview resolution function.

    Resolves the final preview media using the priority order:
      1. Custom uploaded preview (preview_media_file_id set by upload)
      2. Selected collection preview (preview_mode == select, media set)
      3. Auto preview (preview_mode == auto, auto-detect compatible media)
      4. Description only (no media)
      5. Disabled (no preview)

    Returns a dict with:
      - mode: the effective preview mode (disabled/auto/select/custom/description)
      - file_id: the resolved file_id (or None)
      - media_type: the resolved media_type (or None)
      - source: "custom" | "select" | "auto" | "disabled" | "description"
      - file_name: the source file name (or None)
    """
    # 1. Custom uploaded preview always wins.
    if state.get("preview_media_file_id") and state.get("preview_media_type"):
        return {
            "mode": PREVIEW_MODE_CUSTOM,
            "file_id": state["preview_media_file_id"],
            "media_type": state["preview_media_type"],
            "source": "custom",
            "file_name": "Custom Upload",
        }
    # 2. Selected collection preview.
    if state.get("preview_mode") == PREVIEW_MODE_SELECT and state.get("preview_media_file_id"):
        return {
            "mode": PREVIEW_MODE_SELECT,
            "file_id": state["preview_media_file_id"],
            "media_type": state.get("preview_media_type"),
            "source": "select",
            "file_name": state.get("preview_source_name", "Selected File"),
        }
    # 3. Auto preview — detect first compatible media.
    if state.get("preview_mode") in (PREVIEW_MODE_AUTO, None):
        auto = await _auto_detect_preview_media(state)
        if auto:
            return {
                "mode": PREVIEW_MODE_AUTO,
                "file_id": auto["file_id"],
                "media_type": auto["media_type"],
                "source": "auto",
                "file_name": auto.get("file_name", "Auto-detected"),
            }
        # No compatible media → disable.
        return {"mode": PREVIEW_MODE_DISABLED, "file_id": None,
                "media_type": None, "source": "disabled", "file_name": None}
    # 4. Description-only mode (no media).
    if state.get("preview_mode") == PREVIEW_MODE_DESCRIPTION:
        return {"mode": PREVIEW_MODE_DESCRIPTION, "file_id": None,
                "media_type": None, "source": "description", "file_name": None}
    # 5. Disabled.
    return {"mode": PREVIEW_MODE_DISABLED, "file_id": None,
            "media_type": None, "source": "disabled", "file_name": None}



async def _auto_detect_preview_media(state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Auto-detect the BEST preview-compatible media from the payload's file(s).

    V4: When multiple compatible files exist, picks the best by priority:
      Video > Animation > Photo
    Returns {file_id, media_type, file_name, index_id} or None.
    """
    # Priority order: video first, then animation, then photo.
    TYPE_PRIORITY = {"video": 0, "animation": 1, "photo": 2}

    if _pcw_is_collection(state):
        chan = state.get("collection_channel_id")
        msg_ids = state.get("collection_msg_ids") or []
        candidates = []
        for mid in msg_ids:
            row = await db.get_indexed_file_by_channel_msg(chan, int(mid))
            if row and row["media_type"] in PREVIEW_COMPATIBLE_TYPES:
                candidates.append({
                    "file_id": row["file_id"],
                    "media_type": row["media_type"],
                    "file_name": row["file_name"],
                    "index_id": int(row["id"]),
                    "_priority": TYPE_PRIORITY.get(row["media_type"], 99),
                })
        if not candidates:
            return None
        # Sort by priority (video=0, animation=1, photo=2).
        candidates.sort(key=lambda c: c["_priority"])
        best = candidates[0]
        del best["_priority"]
        return best
    # Single file.
    idx = state.get("index_id")
    if idx:
        row = await db.get_indexed_file_by_id(idx)
        if row and row["media_type"] in PREVIEW_COMPATIBLE_TYPES:
            return {
                "file_id": row["file_id"],
                "media_type": row["media_type"],
                "file_name": row["file_name"],
                "index_id": int(row["id"]),
            }
    return None



async def _list_collection_compatible_media(state: Dict[str, Any]) -> List[Dict[str, Any]]:
    """List all preview-compatible media in a collection for the selector."""
    if not _pcw_is_collection(state):
        return []
    chan = state.get("collection_channel_id")
    msg_ids = state.get("collection_msg_ids") or []
    result = []
    for i, mid in enumerate(msg_ids):
        row = await db.get_indexed_file_by_channel_msg(chan, int(mid))
        if row and row["media_type"] in PREVIEW_COMPATIBLE_TYPES:
            result.append({
                "file_id": row["file_id"],
                "media_type": row["media_type"],
                "file_name": row["file_name"] or f"File {i+1}",
                "file_size": row["file_size"],
                "duration": row["duration"],
                "index_id": int(row["id"]),
                "position": i,
            })
    return result



# ----------------------------------------------------------------
# V5 RUNTIME RESOLVER — operates on DB rows (campaign + payload).
# Used by show_referral_preview_screen, the plgsetprev callback, and any
# runtime path that needs the effective preview. SELF-HEALING: when auto
# preview's stored file_id is missing/stale, it re-detects compatible media
# from the payload's files and persists the result back to the campaign row
# so users ALWAYS receive preview media when Auto Preview is enabled.
# ----------------------------------------------------------------
async def _auto_detect_campaign_preview_media(
    campaign, payload_row=None
) -> Optional[Dict[str, Any]]:
    """V5: Auto-detect the best preview-compatible media for a CAMPAIGN at runtime.

    Scans the payload's file(s) — single file or collection — and returns the
    best compatible media (Video > Animation > Photo). Used by the runtime
    resolver when auto-preview's stored file_id is missing/stale.
    """
    TYPE_PRIORITY = {"video": 0, "animation": 1, "photo": 2}
    pid = campaign["payload_id"] if "payload_id" in campaign.keys() else None
    pcode = campaign["payload_code"] if "payload_code" in campaign.keys() else ""
    # Collection payload → scan all items.
    # V26 (message-872 identity fix): the CANONICAL predicate (same fix
    # class — a 'c…'-named single payload is not a collection).
    if pcode and is_collection_link(pcode):
        code = parse_collection_link(pcode)
        items = await db.get_collection_items(code)
        candidates = []
        for it in items:
            mt = _safe_row_get(it, "media_type")
            fid = _safe_row_get(it, "file_id")
            if mt in PREVIEW_COMPATIBLE_TYPES and fid:
                candidates.append({
                    "file_id": fid,
                    "media_type": mt,
                    "file_name": _safe_row_get(it, "file_name") or "File",
                    "_priority": TYPE_PRIORITY.get(mt, 99),
                })
        if not candidates:
            return None
        candidates.sort(key=lambda c: c["_priority"])
        best = candidates[0]
        del best["_priority"]
        return best
    # Single-file payload → resolve via index_id.
    if payload_row is None and pid is not None:
        payload_row = await db.get_payload_by_id(int(pid))
    if not payload_row:
        return None
    idx = payload_row["index_id"] if "index_id" in payload_row.keys() else None
    if idx:
        row = await db.get_indexed_file_by_id(int(idx))
        if row and row["media_type"] in PREVIEW_COMPATIBLE_TYPES:
            return {
                "file_id": row["file_id"],
                "media_type": row["media_type"],
                "file_name": row["file_name"] or "File",
            }
    return None



async def _resolve_campaign_preview(
    campaign, payload_row=None
) -> Dict[str, Any]:
    """V5: THE single RUNTIME preview resolver (operates on DB rows).

    Used by:
      - show_referral_preview_screen (locked dashboard delivery)
      - plgsetprev callback (when admin sets auto/select from the access panel)
      - Any runtime path needing the effective preview for a campaign.

    Priority order (identical to the wizard _resolve_preview):
      1. Custom uploaded preview (mode=custom, media set)
      2. Selected collection preview (mode=select, media set)
      3. Auto preview (mode=auto — SELF-HEALING: re-detect + persist if needed)
      4. Description only (no media)
      5. Disabled (no preview)

    Returns a dict: {mode, file_id, media_type, source, file_name}.
    Never raises — on any failure returns the disabled state.
    """
    disabled = {"mode": PREVIEW_MODE_DISABLED, "file_id": None,
                "media_type": None, "source": "disabled", "file_name": None}
    if campaign is None:
        return disabled
    try:
        mode = campaign["preview_mode"] if "preview_mode" in campaign.keys() else None
        mode = mode or PREVIEW_MODE_DISABLED
    except Exception:  # noqa: BLE001
        return disabled
    stored_file_id = _safe_row_get(campaign, "preview_media_file_id")
    stored_media_type = _safe_row_get(campaign, "preview_media_type")

    # 1. Custom / Select → use the stored media directly.
    if mode in (PREVIEW_MODE_CUSTOM, PREVIEW_MODE_SELECT) and stored_file_id and stored_media_type:
        src = "custom" if mode == PREVIEW_MODE_CUSTOM else "select"
        return {"mode": mode, "file_id": stored_file_id,
                "media_type": stored_media_type, "source": src,
                "file_name": "Custom Upload" if src == "custom" else "Selected File"}

    # 2. Auto → re-detect if stored media is missing (self-healing).
    if mode == PREVIEW_MODE_AUTO:
        if stored_file_id and stored_media_type:
            return {"mode": PREVIEW_MODE_AUTO, "file_id": stored_file_id,
                    "media_type": stored_media_type, "source": "auto",
                    "file_name": "Auto Preview"}
        detected = await _auto_detect_campaign_preview_media(campaign, payload_row)
        if detected:
            # Persist resolved media back to the campaign so future opens are
            # instant and the dashboard always shows preview media.
            try:
                await db.update_referral_campaign(
                    campaign["id"],
                    preview_media_file_id=detected["file_id"],
                    preview_media_type=detected["media_type"])
                logger.info("Preview V5: self-healed auto preview for campaign %s (type=%s).",
                            campaign["id"], detected["media_type"])
            except Exception as e:  # noqa: BLE001
                logger.warning("Preview V5: self-heal persist failed: %s", e)
            return {"mode": PREVIEW_MODE_AUTO, "file_id": detected["file_id"],
                    "media_type": detected["media_type"], "source": "auto",
                    "file_name": detected.get("file_name", "Auto Preview")}
        return disabled

    # 3. Description only.
    if mode == PREVIEW_MODE_DESCRIPTION:
        return {"mode": PREVIEW_MODE_DESCRIPTION, "file_id": None,
                "media_type": None, "source": "description", "file_name": None}

    # 4. Legacy thumbnail with stored media → treat as custom.
    if mode == PREVIEW_MODE_THUMBNAIL and stored_file_id and stored_media_type:
        return {"mode": PREVIEW_MODE_CUSTOM, "file_id": stored_file_id,
                "media_type": stored_media_type, "source": "custom",
                "file_name": "Thumbnail"}
    return disabled



async def pcw_show_preview_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 4: Preview Settings (BOTV13 redesign — clean card layout).

    Layout per spec:
    ━━━━━━━━━━━━━━━━━━━━
    🎬 Preview Settings
    Step 4 / 5
    ━━━━━━━━━━━━━━━━━━━━
    Current Mode: ✅ Auto Preview (or ❌ Disabled, etc.)
    Preview Media: Video (or None)
    Preview Caption: None (or "set")
    ━━━━━━━━━━━━━━━━━━━━
    [🤖 Auto Preview] [📤 Upload Preview]
    [📝 Caption] [🖼 Dashboard Media]
    [🚫 Disable Preview] [🗑 Remove Preview]
    ───────────────
    [⬅ Back] [➡ Next] [🏠 Home] [❌ Cancel]
    """
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "preview"
    cur = state["preview_mode"]
    has_desc = bool(state.get("preview_description"))
    mode_lbl = _pcw_mode_label(state)
    # V4: Use _resolve_preview to get the effective preview state.
    resolved = await _resolve_preview(state)
    eff_source = resolved["source"]
    eff_file_id = resolved["file_id"]
    eff_media_type = resolved["media_type"]
    eff_file_name = resolved.get("file_name")
    has_custom = bool(state.get("preview_media_file_id"))

    # --- Current Mode label ---
    mode_labels = {
        PREVIEW_MODE_AUTO: "\u2705 Auto Preview",
        PREVIEW_MODE_SELECT: "\u2705 Selected Preview",
        PREVIEW_MODE_CUSTOM: "\u2705 Custom Preview",
        PREVIEW_MODE_DESCRIPTION: "\u2705 Description Only",
        PREVIEW_MODE_DISABLED: "\u274C Disabled",
        PREVIEW_MODE_THUMBNAIL: "\u2705 Thumbnail",
    }
    cur_mode_label = mode_labels.get(cur, f"\u2705 {cur.title()}")

    # --- Preview Media label ---
    if eff_file_id and eff_media_type:
        media_label = eff_media_type.title()
        if eff_file_name:
            media_label += f" ({truncate(eff_file_name, 24)})"
    else:
        media_label = "None"

    # --- Preview Caption label ---
    caption_label = "set" if has_desc else "None"

    # --- Build the card text ---
    SEP = "\u2501" * 20
    SEP2 = "\u2500" * 20
    text = (
        f"{SEP}\n"
        f"\U0001F3AC Preview Settings\n"
        f"{_pcw_step_progress('preview')}\n"
        f"{SEP}\n\n"
        f"Current Mode\n{cur_mode_label}\n\n"
        f"Preview Media\n{media_label}\n\n"
        f"Preview Caption\n{caption_label}\n"
        f"{SEP}\n"
    )

    # --- Build buttons (2-column grid per spec) ---
    rows: List[List[InlineKeyboardButton]] = []
    # Row 1: Auto Preview + Upload Preview
    auto_mark = "\u2713 " if cur == PREVIEW_MODE_AUTO else ""
    upload_mark = "\u2705 " if has_custom else ""
    rows.append([
        InlineKeyboardButton(f"{auto_mark}\U0001F916 Auto Preview",
                             callback_data=f"pcw:preview:{PREVIEW_MODE_AUTO}"),
        InlineKeyboardButton(f"{upload_mark}\U0001F4E4 Upload Preview",
                             callback_data="pcw:prevmedia"),
    ])
    # Row 2: Caption + Dashboard Media
    desc_mark = "\u2705 " if has_desc else ""
    rows.append([
        InlineKeyboardButton(f"{desc_mark}\U0001F4DD Caption",
                             callback_data="pcw:prevdesc"),
        InlineKeyboardButton("\U0001F5BC Dashboard Media",
                             callback_data="dash:media"),
    ])
    # Row 3: Disable Preview + Remove Preview
    dis_mark = "\u2713 " if cur == PREVIEW_MODE_DISABLED else ""
    remove_label = "\u274C Remove Preview" if has_custom else "\u274C Remove Preview"
    remove_cb = "pcw:prevmediaremove" if has_custom else f"pcw:preview:{PREVIEW_MODE_DISABLED}"
    rows.append([
        InlineKeyboardButton(f"{dis_mark}\U0001F6AB Disable Preview",
                             callback_data=f"pcw:preview:{PREVIEW_MODE_DISABLED}"),
        InlineKeyboardButton(remove_label, callback_data=remove_cb),
    ])
    # Collection-only: Choose Preview (select mode)
    if _pcw_is_collection(state):
        sel_mark = "\u2713 " if cur == PREVIEW_MODE_SELECT else ""
        rows.append([InlineKeyboardButton(f"{sel_mark}\U0001F5BC Choose Preview (Collection)",
                                          callback_data=f"pcw:preview:{PREVIEW_MODE_SELECT}")])
    # Separator + Navigation
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
                 InlineKeyboardButton("\u27A1\uFE0F Next", callback_data="pcw:next")])
    rows.append([InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
                 InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")])
    kb = InlineKeyboardMarkup(rows)
    if update.callback_query:
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
    else:
        await safe_send_text(context.bot, update.effective_chat.id, text, reply_markup=kb)



async def pcw_show_collection_preview_selector(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """V5: Collection Preview Selector — list all compatible media for selection.

    Each entry shows: position number, type icon, filename, size, duration.
    The currently-selected file (if any) is marked with a checkmark.
    """
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "prevselect"
    media_list = await _list_collection_compatible_media(state)
    if not media_list:
        await safe_send_text(context.bot, update.effective_chat.id,
            "\u274C No preview-compatible media found in this collection.\n\n"
            "Supported: Photo, Video, Animation")
        await pcw_show_preview_step(update, context)
        return
    current_sel = state.get("preview_media_file_id")
    lines = [f"\u2795 {_pcw_mode_label(state)} \u2014 Select Preview", "",
             "Choose a file to use as the preview:", ""]
    buttons: List[List[InlineKeyboardButton]] = []
    icon_map = {"photo": "\U0001F5BC", "video": "\U0001F3AC", "animation": "\U0001F3A8"}
    for i, m in enumerate(media_list):
        icon = icon_map.get(m["media_type"], "\U0001F4C4")
        size_str = f" \u00B7 {format_size(m.get('file_size'))}" if m.get("file_size") else ""
        dur_str = f" \u00B7 {format_duration(m.get('duration'))}" if m.get("duration") else ""
        is_sel = bool(current_sel and current_sel == m.get("file_id"))
        sel_mark = "\u2705 " if is_sel else ""
        name = truncate(m["file_name"], 30) or "Unnamed"
        lines.append(f"{sel_mark}{i+1}. {icon} {name} \u00B7 {m['media_type']}{size_str}{dur_str}")
        label = f"{sel_mark}{icon} {i+1}. {name}{size_str}{dur_str}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"pcw:prevselect:{m['index_id']}")])
    buttons.append([InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back")])
    await safe_edit_text(update.callback_query, "\n".join(lines),
                         reply_markup=InlineKeyboardMarkup(buttons))



async def pcw_show_advanced_delivery(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Advanced Delivery overlay — optional delete timer + one-time override.

    This is the ONLY delivery surface in the 5-step wizard. It is opened from
    the Review/Confirm page (not a standalone step). State is preserved: the
    admin returns to the Confirm step on Back.
    """
    state = _pcw_get(context)
    if not state:
        return
    state["step"] = "advdelivery"
    da = state["delete_after"]
    ot = state["one_time"]
    ot_label = "\U0001F511 One-time: ON" if ot else "\U0001F511 One-time: OFF"
    mode_lbl = _pcw_mode_label(state)
    rows: List[List[InlineKeyboardButton]] = []
    for secs in DELETE_TIMER_PRESETS:
        mark = "\u2713 " if da == secs else ""
        rows.append([InlineKeyboardButton(f"{mark}\u23F0 {DELETE_TIMER_LABELS[secs]}",
                                          callback_data=f"pcw:timer:{secs}")])
    inh_mark = "\u2713 " if da is None else ""
    rows.append([InlineKeyboardButton(f"{inh_mark}\u23F0 Inherit global",
                                      callback_data=f"pcw:timer:{INHERIT_SENTINEL}")])
    rows.append([InlineKeyboardButton(ot_label, callback_data="pcw:onetimetoggle")])
    rows.append([InlineKeyboardButton("\u2B05\uFE0F Back to Review", callback_data="pcw:back")])
    await safe_edit_text(update.callback_query,
        f"\u2795 {mode_lbl} \u2014 Advanced Delivery\n\n"
        f"Delete timer: {_delete_timer_label(da)}\n"
        f"One-time: {'ON' if ot else 'OFF'}",
        parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup(rows))



async def pcw_show_confirm_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Step 5: Review & Confirm — summary + Create button.

    Advanced Delivery is opened from here as an overlay (pcw:advdelivery),
    NOT as a standalone wizard step.
    """
    state = _pcw_get(context)
    if not state:
        return
    # Validate: name + file must be set.
    errors = pcw_validate(state)
    if errors:
        text = "\u274C Cannot proceed yet:\n\n"
        for e in errors:
            text += f"\u2022 {e}\n"
        text += "\nFix the above, then return here."
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
             InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
             InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")],
        ])
        await safe_edit_text(update.callback_query, text, reply_markup=kb)
        return
    state["step"] = "confirm"
    da_label = _delete_timer_label(state["delete_after"])
    ot_label = "ON" if state["one_time"] else "OFF"
    policy = state["access_policy"]
    mode_lbl = _pcw_mode_label(state)
    create_label = "\u2705 Save Changes" if state.get("mode") == "edit" else "\u2705 Create Payload"

    # V5: Use _resolve_preview for the summary — show the RESOLVED preview state
    # (source label, media type, filename) rather than raw wizard fields.
    resolved = await _resolve_preview(state)
    is_coll = _pcw_is_collection(state)
    file_count = _pcw_file_count(state)
    prev_mode = _preview_label_full(resolved["mode"])
    # Human-friendly source labels (matches the Preview Engine V5 priority).
    _SOURCE_LABELS = {
        "custom": "Custom Upload",
        "select": "Collection Selection",
        "auto": "Auto Preview",
        "description": "Description Only",
        "disabled": "Disabled",
    }
    prev_source = _SOURCE_LABELS.get(resolved["source"], resolved["source"].title())
    if resolved["file_id"] and resolved.get("file_name") and resolved["source"] == "auto":
        # Auto Preview shows the resolved filename for clarity.
        # BOT-43: the filename renders as a code span — the confirm step is
        # a ParseMode.MARKDOWN message and a RAW filename with unmatched
        # markdown entities crashes the send (the production file_pk=681
        # "Can't parse entities" family).
        prev_source = (f"Auto Preview "
                       f"{md_code_span(truncate(resolved.get('file_name') or '', 24))}")
    prev_media = f"\u2705 {resolved['media_type']}" if resolved["file_id"] else "\u2014 none"
    prev_desc = "\u2705 set" if state.get("preview_description") else "\u2014 none"

    # BOTV13: show the human-readable display_name as the title, routing slug below.
    display_val = state.get("display_name") or state.get("name") or "(unnamed)"
    text = (
        f"\u2795 {mode_lbl} \u2014 {_pcw_step_progress('confirm')}\n\n"
        f"\U0001F4CB Payload Summary\n\n"
        f"\u2022 Name: {display_val}\n"
        f"\u2022 Routing ID: {md_code_span(state['name'])}\n"
    )
    if is_coll:
        text += f"\u2022 Type: Collection\n"
        text += f"\u2022 Files: {file_count}\n"
    else:
        text += f"\u2022 Type: Single File\n"
    text += f"\u2022 Access: {_policy_label_full(policy)}\n"
    if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        text += f"\u2022 Required Referrals: {state['required_referrals']}\n"
    # WATCH_AD (v25): the summary always shows the Watch Ads state so the
    # admin can verify it before creating / saving.
    wad_on = bool(int(state.get("watch_ads_enabled") or 0))
    text += f"\u2022 \U0001F3AC Watch Ads: {'ON' if wad_on else 'OFF'}\n"
    text += f"\u2022 Preview: {prev_mode}\n"
    text += f"  \u2014 Source: {prev_source}\n"
    text += f"  \u2014 Media: {prev_media}\n"
    text += f"  \u2014 Description: {prev_desc}\n"
    text += f"\u2022 Auto Delete: {da_label}\n"
    text += f"\u2022 One-Time: {ot_label}\n"
    text += f"\u2022 Protection: Enabled (inherit global)\n"
    text += f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
    if state.get("mode") == "edit":
        text += "Only modified values will be saved.\n"
    else:
        text += "Everything is configured. The payload will be production-ready\n"
        text += "immediately after creation.\n"
    text += f"\n\u26A0\uFE0F No database writes occur until you press Create."
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(create_label, callback_data="pcw:create")],
        [InlineKeyboardButton("\u2699\uFE0F Advanced Delivery", callback_data="pcw:advdelivery")],
        [InlineKeyboardButton("\u2B05\uFE0F Back", callback_data="pcw:back"),
         InlineKeyboardButton("\U0001F3E0 Home", callback_data="pcw:home"),
         InlineKeyboardButton("\u274C Cancel", callback_data="pcw:cancel")],
    ])
    await safe_edit_text(update.callback_query, text,
                         parse_mode=ParseMode.MARKDOWN, reply_markup=kb)



def pcw_validate(state: Dict[str, Any]) -> List[str]:
    """Return a list of validation errors. Empty = ready to create/save.

    Handles both single-file and collection payloads, and is mode-aware
    (edit mode allows the name to be unchanged).
    """
    errors: List[str] = []
    # BOTV13: validate the routing slug (state["name"]). For collections this
    # is the derived slug; the actual c<code> is generated at create time.
    if not state.get("name"):
        errors.append("Payload name is not set")
    elif not validate_payload(state["name"]):
        errors.append("Routing slug is invalid (internal — please retry with a different name)")
    # BOTV13: validate the human-readable display_name if set.
    dn = state.get("display_name")
    if dn is not None and not validate_display_name(dn):
        errors.append("Display name is invalid (max 128; no control characters)")
    # A file OR a collection must be selected (in edit mode the payload row
    # already carries index_id, so this is satisfied).
    if not state.get("index_id") and not state.get("collection_msg_ids") and not state.get("collection_code"):
        errors.append("No file selected (send a Message ID or forward a file)")
    policy = state.get("access_policy", ACCESS_POLICY_DEFAULT)
    if policy not in ACCESS_POLICIES_IMPLEMENTED:
        errors.append(f"Access policy '{policy}' is not yet implemented")
    if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        try:
            n = int(state.get("required_referrals", REFERRAL_REQUIRED_DEFAULT))
            if n < 0:
                errors.append("Required referrals cannot be negative")
        except (TypeError, ValueError):
            errors.append("Required referrals must be a number")
    pm = state.get("preview_mode", PREVIEW_MODE_DISABLED)
    if pm not in PREVIEW_MODES_ALL:
        errors.append(f"Unknown preview mode '{pm}'")
    # Timer validation (if explicitly set, must be a known preset or 0/inherit).
    da = state.get("delete_after")
    if da is not None:
        try:
            dv = int(da)
            if dv < 0:
                errors.append("Delete timer cannot be negative")
        except (TypeError, ValueError):
            errors.append("Delete timer must be a number")
    return errors



async def pcw_render_current_step(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Re-render whatever step the wizard is on (V3: handles sub-steps)."""
    state = _pcw_get(context)
    if not state:
        return
    step = state.get("step", "name")
    if step == "referrals" and state["access_policy"] != ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        step = "watchads"
        state["step"] = step
    if step == "name" or step == "awaiting_name":
        state["step"] = "name"
        await pcw_show_name_step(update, context)
    elif step == "file":
        await pcw_show_file_step(update, context)
    elif step == "policy":
        await pcw_show_policy_step(update, context)
    elif step == "referrals":
        await pcw_show_referrals_step(update, context)
    elif step == "watchads":
        await pcw_show_watchads_step(update, context)
    elif step == "preview":
        await pcw_show_preview_step(update, context)
    elif step == "prevselect":
        await pcw_show_collection_preview_selector(update, context)
    elif step == "advdelivery":
        await pcw_show_advanced_delivery(update, context)
    elif step == "confirm":
        await pcw_show_confirm_step(update, context)



def _pcw_has_file(state: Dict[str, Any]) -> bool:
    """True if a single file OR a collection is selected (or in edit mode)."""
    return bool(state.get("index_id") or state.get("collection_msg_ids")
                or state.get("collection_code") or state.get("mode") == "edit")



async def pcw_go_next(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Advance to the next applicable step (V3: 5 steps, no separate delivery)."""
    state = _pcw_get(context)
    if not state:
        return
    order = list(PCW_STEPS)
    cur = state.get("step", "name")
    if cur == "awaiting_name":
        cur = "name"
        state["step"] = "name"
    # Sub-steps: advdelivery and prevselect return to their parent.
    if cur == "advdelivery":
        await pcw_show_confirm_step(update, context)
        return
    if cur == "prevselect":
        await pcw_show_preview_step(update, context)
        return
    if cur == "name" and not _pcw_has_file(state):
        await pcw_show_file_step(update, context)
        return
    if cur == "file":
        await pcw_show_policy_step(update, context)
        return
    try:
        idx = order.index(cur)
    except ValueError:
        idx = 0
    nxt = order[idx + 1] if idx + 1 < len(order) else "confirm"
    if nxt == "referrals" and state["access_policy"] != ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        nxt = "watchads"
    if nxt == "policy":
        await pcw_show_policy_step(update, context)
    elif nxt == "referrals":
        await pcw_show_referrals_step(update, context)
    elif nxt == "watchads":
        await pcw_show_watchads_step(update, context)
    elif nxt == "preview":
        await pcw_show_preview_step(update, context)
    elif nxt == "confirm":
        await pcw_show_confirm_step(update, context)



async def pcw_go_back(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Go to the previous applicable step (V3: 5 steps, no separate delivery).

    V15: if on the first step (name) in EDIT mode, Back returns to the Payload
    Details page instead of re-rendering the name step.
    """
    state = _pcw_get(context)
    if not state:
        return
    order = list(PCW_STEPS)
    cur = state.get("step", "name")
    if cur == "awaiting_name":
        cur = "name"
        state["step"] = "name"
    # Sub-steps: advdelivery goes back to confirm, prevselect goes back to preview.
    if cur == "advdelivery":
        await pcw_show_confirm_step(update, context)
        return
    if cur == "prevselect":
        await pcw_show_preview_step(update, context)
        return
    # V15: if on the first step in edit mode, Back returns to payload details.
    if cur == "name" and state.get("mode") == "edit":
        edit_pid = state.get("edit_payload_id")
        _pcw_clear(context)
        if edit_pid is not None and await nav_return(update, context):
            return  # returned to payload details
        await links_panel(update, context)
        return
    try:
        idx = order.index(cur)
    except ValueError:
        idx = 0
    prev = order[idx - 1] if idx - 1 >= 0 else "name"
    if prev == "referrals" and state["access_policy"] != ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        prev = "policy"
    if prev == "watchads" and state["access_policy"] != ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        prev = "policy"
    if prev == "name" and not _pcw_has_file(state):
        prev = "file"
    if prev == "name":
        await pcw_show_name_step(update, context)
    elif prev == "file":
        await pcw_show_file_step(update, context)
    elif prev == "policy":
        await pcw_show_policy_step(update, context)
    elif prev == "referrals":
        await pcw_show_referrals_step(update, context)
    elif prev == "watchads":
        await pcw_show_watchads_step(update, context)
    elif prev == "preview":
        await pcw_show_preview_step(update, context)
    elif prev == "confirm":
        await pcw_show_confirm_step(update, context)



async def _pcw_pre_create_validation(state: Dict[str, Any]) -> List[str]:
    """Run all pre-create checks and return descriptive error strings.

    Verifies: payload name uniqueness (create mode), selected files still
    exist, indexed rows still exist, referral requirement, preview media,
    timer values, campaign uniqueness. These are server-side checks that run
    AFTER the wizard confirms, so a file deleted mid-wizard is caught.
    """
    errors: List[str] = []
    name = state.get("name")
    is_edit = state.get("mode") == "edit"
    edit_pid = state.get("edit_payload_id")

    # Name uniqueness.
    if name:
        existing = await db.get_payload(name)
        if existing and (not is_edit or int(existing["id"]) != int(edit_pid)):
            errors.append(f"A payload named '{name}' already exists. Choose another name.")

    # File existence (single-file mode, create only — edit mode keeps the row).
    if not is_edit:
        if state.get("index_id") and not state.get("collection_msg_ids"):
            frow = await db.get_indexed_file_by_id(state["index_id"])
            if not frow:
                errors.append("The selected file no longer exists in the index. "
                              "It may have been removed. Select another file.")
        # Collection: verify every message_id still resolves to an indexed row.
        if state.get("collection_msg_ids") and state.get("collection_channel_id"):
            chan = state["collection_channel_id"]
            missing = 0
            for mid in state["collection_msg_ids"]:
                r = await db.get_indexed_file_by_channel_msg(chan, int(mid))
                if not r:
                    missing += 1
            if missing:
                errors.append(f"{missing} of {len(state['collection_msg_ids'])} forwarded "
                              "files are no longer indexed. Reindex the channel and retry.")

    # Referral requirement.
    policy = state.get("access_policy", ACCESS_POLICY_DEFAULT)
    if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
        try:
            req = int(state.get("required_referrals", REFERRAL_REQUIRED_DEFAULT))
            if req < 0:
                errors.append("Required referrals cannot be negative.")
        except (TypeError, ValueError):
            errors.append("Required referrals must be a number.")

    # Preview media consistency: if a media-requiring mode is selected but no
    # media was uploaded, AUTO-DOWNGRADE to disabled (do NOT block creation).
    # This fixes the "Create Payload does nothing" bug when preview is configured
    # but media upload was skipped/missed.
    pm = state.get("preview_mode", PREVIEW_MODE_DISABLED)
    if pm in (PREVIEW_MODE_THUMBNAIL, PREVIEW_MODE_CUSTOM) and not state.get("preview_media_file_id"):
        logger.warning("Wizard: preview mode '%s' requires media but none uploaded — auto-downgrading to disabled.", pm)
        state["preview_mode"] = PREVIEW_MODE_DISABLED

    # Timer value.
    da = state.get("delete_after")
    if da is not None:
        try:
            if int(da) < 0:
                errors.append("Delete timer cannot be negative.")
        except (TypeError, ValueError):
            errors.append("Delete timer must be a number.")

    # Campaign uniqueness (create mode): a payload cannot have two campaigns.
    if not is_edit and policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL and name:
        # The payload doesn't exist yet, so no campaign can exist — this is a
        # forward-looking guard. Included for completeness.
        pass
    return errors



async def create_payload_from_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """THE atomic backend: create payload + (collection) + campaign + preview
    config in ONE transaction.

    - Validation runs first; no partial/incomplete payload is ever committed.
    - For collections, the collection row + items are created inside the same
      transaction as the payload.
    - For REFERRAL policy, the campaign + preview media are created in the
      same transaction.
    - On ANY failure, the transaction is rolled back — no orphan campaigns,
      no orphan payloads, no orphan collections.
    - On success the wizard state is cleared and the payload detail panel opens.
    - In edit mode, only modified values are saved (no campaign recreation).
    """
    state = _pcw_get(context)
    if not state:
        await safe_answer_callback(update.callback_query, "Wizard session expired.", show_alert=True)
        return
    # Duplicate-tap guard: if a create is already in progress for this wizard,
    # acknowledge and ignore the second tap (idempotent).
    if state.get("creating"):
        await safe_answer_callback(update.callback_query, "Already creating...", show_alert=False)
        return
    # Mark creating-in-progress + acknowledge the callback IMMEDIATELY so
    # Telegram never shows a stuck spinner.
    state["creating"] = True
    await safe_answer_callback(update.callback_query)
    logger.info("Wizard: [1] Callback received — create flow starting.")
    logger.info("Wizard: [2] Wizard state loaded (mode=%s name=%s policy=%s).",
                state.get("mode"), state.get("name"), state.get("access_policy"))
    try:
        # 1. Structural validation (cheap, in-memory).
        logger.info("Wizard: [3] Validation started.")
        errors = pcw_validate(state)
        if errors:
            logger.warning("Wizard: [CREATE] Structural validation FAILED: %s", errors)
            # BOT-45/46 (Task F): the attempt terminates — classified,
            # never silent (the wizard state stays so the admin can fix
            # and retry; the alert below already carries the precise
            # corrective instruction).
            await _pcw_wizard_terminal(
                context, "failed", "VALIDATION_ERROR", state=state,
                db=db, log=logger,
                detail="; ".join(e for e in errors)[:120])
            await safe_answer_callback(update.callback_query,
                "Cannot proceed: " + "; ".join(errors), show_alert=True)
            await pcw_show_confirm_step(update, context)
            return
        # 2. Server-side pre-create validation (files still exist, name unique, etc.)
        errors = await _pcw_pre_create_validation(state)
        if errors:
            logger.warning("Wizard: [CREATE] Server-side validation FAILED: %s", errors)
            # BOT-45/46 (Task F): classify media/index vs duplicate vs
            # validation and terminate the attempt.
            await _pcw_wizard_terminal(
                context, "failed",
                _pcw_classify_validation_errors(errors), state=state,
                db=db, log=logger,
                detail="; ".join(e for e in errors)[:120])
            await safe_answer_callback(update.callback_query,
                "Validation failed: " + "; ".join(errors), show_alert=True)
            await pcw_show_confirm_step(update, context)
            return
        logger.info("Wizard: [4] Validation passed.")

        is_edit = state.get("mode") == "edit"
        if is_edit:
            logger.info("Wizard: [CREATE] Edit mode — applying edits.")
            await apply_wizard_edits(update, context, state)
            return

        name = state["name"]
        policy = state["access_policy"]
        is_collection = _pcw_is_collection(state)
        # IDEMPOTENT DETECTION: if a payload with this name already exists (e.g.
        # a previous create succeeded but the success-screen render crashed),
        # do NOT create a duplicate. Clear wizard state + open the existing
        # payload's manager. This prevents duplicate payloads on retry.
        existing = await db.get_payload(name)
        if existing:
            logger.info("Wizard: payload '%s' already exists (id=%s) — opening manager (idempotent).",
                        name, existing["id"])
            # BOT-45/46 (Task F): this attempt terminates SUCCESSFULLY (the
            # goal — the payload exists and is managed — is achieved), never
            # silently.
            await _pcw_wizard_terminal(
                context, "complete", "SUCCESS", state=state,
                db=db, log=logger, payload_id=int(existing["id"]),
                detail="outcome=already_exists")
            _pcw_clear(context)
            _pcw_clear_awaiting_flags(context)
            await safe_answer_callback(update.callback_query,
                "\u2705 Payload already exists. Opening manager.")
            await pm_payload_detail(update, context, int(existing["id"]))
            return
        # 3. Atomic creation inside a single BEGIN IMMEDIATE transaction.
        await _create_payload_atomic(update, context, state, name, policy, is_collection)
    finally:
        # Clear the creating-flag (wizard state itself is cleared on success
        # inside _create_payload_atomic; on failure it stays so the admin can retry).
        st = _pcw_get(context)
        if st:
            st.pop("creating", None)



async def _create_payload_atomic(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  state: Dict[str, Any], name: str,
                                  policy: str, is_collection: bool) -> None:
    """Atomic payload creation (called by create_payload_from_wizard).

    On success: clears wizard state + shows the Payload Created screen.
    On failure: rolls back + returns to the confirm step (wizard state preserved).
    """
    try:
        logger.info("Wizard: [5] Preview processed (mode=%s media=%s desc=%s).",
                    state.get("preview_mode"),
                    bool(state.get("preview_media_file_id")),
                    bool(state.get("preview_description")))
        logger.info("Wizard: [6] Referral processed (policy=%s req=%s).",
                    policy, state.get("required_referrals"))
        logger.info("Wizard: [7] Delivery processed (timer=%s one_time=%s).",
                    state.get("delete_after"), state.get("one_time"))
        logger.info("Wizard: [8] Database transaction started (BEGIN IMMEDIATE).")
        # BOTV13 fix: safety-check in_transaction so a stray open transaction
        # (from a crashed prior call) is rolled back first. Prevents
        # "cannot start a transaction within a transaction". The wizard create
        # path is admin-only (low concurrency) — the high-concurrency referral
        # path (qualify_referral_atomic) uses the full write_lock.
        try:
            if db.conn.in_transaction:
                logger.warning("Wizard txn: in_transaction on entry — safety ROLLBACK.")
                await db.conn.execute("ROLLBACK")
        except Exception:  # noqa: BLE001
            pass
        await db.conn.execute("BEGIN IMMEDIATE")
        created_collection_code: Optional[str] = None

        if is_collection:
            logger.info("Wizard: [CREATE] Saving collection (%d files).", len(state["collection_msg_ids"]))
            # Create the collection row + items inside the transaction.
            chan = state["collection_channel_id"]
            msg_ids = [int(m) for m in state["collection_msg_ids"]]
            code = None
            for _ in range(10):
                candidate = generate_collection_code()
                cur = await db.conn.execute(
                    "SELECT 1 FROM collections WHERE collection_id = ?", (candidate,))
                if not await cur.fetchone():
                    now = _now_iso()
                    admin_id = update.effective_user.id if update.effective_user else None
                    await db.conn.execute(
                        "INSERT INTO collections (collection_id, channel_id, file_count, created_at, created_by) "
                        "VALUES (?, ?, ?, ?, ?)",
                        (candidate, chan, len(msg_ids), now, admin_id))
                    rows = [(candidate, chan, int(mid), pos)
                            for pos, mid in enumerate(msg_ids)]
                    await db.conn.executemany(
                        "INSERT INTO collection_items (collection_id, channel_id, message_id, position) "
                        "VALUES (?, ?, ?, ?)", rows)
                    code = candidate
                    break
            if not code:
                await db.conn.execute("ROLLBACK")
                await safe_answer_callback(update.callback_query,
                    "Failed to allocate a unique collection code. Please retry.", show_alert=True)
                # Wizard state preserved — return to confirm so admin can retry.
                await pcw_show_confirm_step(update, context)
                return
            created_collection_code = code
            # The payload name is the c<code> link so /start c<code> resolves it.
            payload_name = f"{COLLECTION_LINK_PREFIX}{code}"
            # index_id is nominal for collections (the first item); the Access
            # Engine resolves collections by code, not index_id.
            first_row = await db.get_indexed_file_by_channel_msg(chan, msg_ids[0])
            index_id_for_payload = int(first_row["id"]) if first_row else 0
        else:
            payload_name = name
            index_id_for_payload = state["index_id"]

        # Create the payload row.
        logger.info("Wizard: [9] Payload inserted (name=%s policy=%s).", payload_name, policy)
        now = _now_iso()
        # BOTV13: store display_name (human-readable title) alongside the
        # immutable routing slug (payload_name). For collections, the display_name
        # is what the admin typed; the slug stays c<code>. For single-file, the
        # display_name is the admin's text and the slug is the sanitized version.
        display_name_val = state.get("display_name") or payload_name
        # BOT-45/46 (Task D, schema v47): display-name PROVENANCE —
        #   'admin_override' when the admin typed a display name, or for a
        #   collection (the c<code> package name is admin-curated, never
        #   source-derived);
        #   'source' when the single-file wizard auto-generated it from the
        #   CURRENT source filename (Skip -> sanitize_slug(file_name)).
        #   A later source refresh only rewrites 'source'/NULL rows.
        display_origin_val = ("admin_override"
                              if (state.get("display_name") or is_collection)
                              else "source")
        cur = await db.conn.execute(
            """INSERT INTO payloads
               (payload, display_name, index_id, status, delete_after, one_time, password,
                expires_at, max_clicks, current_clicks, access_policy,
                watch_ads_enabled, display_name_origin, created_at, updated_at)
               VALUES (?, ?, ?, 'active', ?, ?, NULL, NULL, 0, 0, ?, ?, ?, ?, ?)""",
            (payload_name, display_name_val, index_id_for_payload, state["delete_after"],
             state["one_time"], policy,
             1 if int(state.get("watch_ads_enabled") or 0) else 0,
             display_origin_val, now, now))
        pid = int(cur.lastrowid)
        logger.info("Wizard: [CREATE] Payload saved (id=%s watch_ads=%s).",
                    pid, bool(int(state.get("watch_ads_enabled") or 0)))

        # If REFERRAL, create the campaign + preview config in the same txn.
        cid: Optional[int] = None
        if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
            # V4: Use _resolve_preview to get the effective preview values.
            resolved = await _resolve_preview(state)
            eff_mode = resolved["mode"]
            eff_file_id = resolved["file_id"]
            eff_media_type = resolved["media_type"]
            logger.info("Wizard: [10] Preview saved (mode=%s source=%s file_id=%s type=%s desc=%s).",
                        eff_mode, resolved["source"],
                        bool(eff_file_id), eff_media_type,
                        bool(state.get("preview_description")))
            logger.info("Wizard: [11] Referral saved (req=%s).", state["required_referrals"])
            cur = await db.conn.execute(
                """INSERT INTO referral_campaigns
                   (payload_id, payload_code, required_referrals, preview_mode,
                    unlock_mode, enabled, created_at,
                    preview_media_file_id, preview_media_type, preview_description)
                   VALUES (?, ?, ?, ?, 'permanent', 1, ?, ?, ?, ?)""",
                (pid, payload_name, state["required_referrals"], eff_mode,
                 now, eff_file_id, eff_media_type, state.get("preview_description")))
            cid = int(cur.lastrowid)
            logger.info("Wizard: [CREATE] Campaign saved (id=%s).", cid)
        else:
            logger.info("Wizard: [CREATE] No referral campaign needed (policy=%s).", policy)

        logger.info("Wizard: [12] Delivery saved (timer=%s one_time=%s).",
                    state.get("delete_after"), state.get("one_time"))
        logger.info("Wizard: [13] Transaction committed.")
        await db.conn.commit()
        logger.info("Wizard: [CREATE] Transaction committed successfully.")
    except Exception as exc:  # noqa: BLE001
        # Roll back EVERYTHING on any failure — no orphan rows.
        try:
            await db.conn.execute("ROLLBACK")
        except Exception:  # noqa: BLE001
            pass
        logger.error("Wizard: [CREATE] Atomic create FAILED, rolled back: %s", exc, exc_info=True)
        # BOT-45/46 (Task F): the attempt terminates with a CLASSIFIED
        # safe reason — Telegram transport vs media/index vs validation
        # vs publication failure are separated; retryable transport errors
        # get a [ Retry ] button, permanent errors a precise corrective
        # instruction.
        _reason, _instr, _retryable = _pcw_classify_wizard_failure(exc=exc)
        await _pcw_wizard_terminal(
            context, "failed", _reason, state=state, db=db, log=logger,
            detail=f"exc={type(exc).__name__}")
        await _pcw_wizard_failure_screen(
            update, context, _reason, _instr, _retryable)
        # Wizard state preserved — the failure screen's Back/Retry returns
        # here so admin can fix + retry.
        return

    # 4. Post-commit analytics (fire-and-forget, outside the transaction).
    try:
        await db.log_access_event("payload_created", payload_id=pid, campaign_id=cid)
        if is_collection:
            await db.log_access_event("collection_created", payload_id=pid, campaign_id=cid)
        if policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
            await db.log_access_event("referral_enabled", payload_id=pid, campaign_id=cid)
            if state.get("preview_media_file_id") or state.get("preview_description"):
                await db.log_access_event("preview_enabled", payload_id=pid, campaign_id=cid)
            # Seed a campaign_view so the campaign shows initial activity.
            await db.log_access_event("campaign_view", payload_id=pid, campaign_id=cid)
        await db.log_access_event("wizard_completed", payload_id=pid, campaign_id=cid)
    except Exception as e:  # noqa: BLE001
        logger.warning("Wizard: analytics logging failed (non-fatal): %s", e)
    logger.info("Wizard: created %s payload '%s' (id=%s) policy=%s collection=%s",
                "collection" if is_collection else "single", payload_name, pid,
                policy, created_collection_code)

    # 5. Clear ALL wizard state (only after successful commit) + show success.
    # Clear the wizard state dict + any leftover awaiting_* flags so no stale
    # prompt can intercept the next message.
    logger.info("BOT6_ADMIN_WIZARD_COMPLETE wizard=pcw user_id=%s payload_id=%s "
                "policy=%s collection=%s",
                update.effective_user.id if update.effective_user else None,
                pid, policy, bool(created_collection_code))
    # BOT-45/46 (Task F): the terminal WIZARD_COMPLETE event — with the
    # SOURCE IDENTITY fields (channel_id, message_id, file_pk,
    # file_unique_id_hash) so every wizard attempt is traceable to the
    # exact Telegram source it published (safe fields only — the
    # file_unique_id is hashed, raw ids never logged).
    await _pcw_wizard_terminal(
        context, "complete", "SUCCESS", state=state, db=db, log=logger,
        payload_id=pid,
        detail="mode=%s policy=%s collection=%s" % (
            "edit" if state.get("mode") == "edit" else "create",
            policy, bool(created_collection_code)))
    logger.info("Wizard: [14] Wizard cleared.")
    _pcw_clear(context)
    _pcw_clear_awaiting_flags(context)
    # payload_created_screen answers the callback + opens the Payload Manager.
    try:
        logger.info("Wizard: [15] Payload Manager opened (pid=%s).", pid)
        await payload_created_screen(update, context, pid)
        logger.info("Wizard: [CREATE] Payload Manager opened successfully (pid=%s).", pid)
    except Exception as e:  # noqa: BLE001
        logger.error("Wizard: [CREATE] Management screen failed (payload already created): %s", e, exc_info=True)
        # Payload is already committed — don't roll back. Send plain-text fallback.
        try:
            # BOTV13 Part 1: use display_name for the success message + human-friendly link.
            dn = state.get("display_name") or payload_name
            await safe_send_text(context.bot, update.effective_chat.id,
                f"\u2705 Payload created: {dn}\n"
                f"{build_link(payload_name, display_name=dn)}\n\n"
                f"Open Payload Manager to manage this payload.")
        except Exception:
            pass



async def apply_wizard_edits(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              state: Dict[str, Any]) -> None:
    """Edit-mode save: diff the wizard state against the existing payload row
    and save ONLY modified values. Never recreates campaigns unnecessarily.

    Collection membership/ordering is immutable from the wizard.
    """
    pid = state["edit_payload_id"]
    row = await db.get_payload_by_id(pid)
    if not row:
        # BOT-45/46 (Task F): the edit attempt terminates — the SOURCE
        # payload is gone (not a silent wizard end).
        await _pcw_wizard_terminal(
            context, "failed", "SOURCE_NOT_FOUND", state=state,
            db=db, log=logger, payload_id=int(pid) if pid else None,
            detail="payload row missing")
        await safe_answer_callback(update.callback_query, "Payload no longer exists.", show_alert=True)
        _pcw_clear(context)
        return

    # Begin a transaction for atomic edits.
    try:
        # BOTV13 fix: safety-check in_transaction so a stray open transaction
        # (from a concurrent referral qualification) is rolled back first.
        # The wizard edit path is admin-only (low concurrency); the high-
        # concurrency referral path uses the full write_lock.
        try:
            if db.conn.in_transaction:
                logger.warning("Wizard edit txn: in_transaction on entry — safety ROLLBACK.")
                await db.conn.execute("ROLLBACK")
        except Exception:  # noqa: BLE001
            pass
        await db.conn.execute("BEGIN IMMEDIATE")
        # BOTV13: Name change now edits ONLY display_name. The routing slug
        # (payload column) is NEVER modified — so /start links, referral tokens,
        # collection c<code> routing, and retrieve records all keep working.
        # Collection payloads CAN have their display_name changed (the c<code>
        # slug stays untouched). No uniqueness check on display_name (it's not
        # unique — only the slug is).
        new_display = state.get("display_name")
        if new_display:
            old_display = row["display_name"] if "display_name" in row.keys() else None
            if new_display != old_display:
                await db.conn.execute(
                    "UPDATE payloads SET display_name = ?, updated_at = ? WHERE id = ?",
                    (new_display, _now_iso(), pid))
                # BOT-45/46 (Task D, schema v47): the wizard-typed display
                # name is an EXPLICIT admin override — mark the provenance
                # so any later source-filename refresh preserves it (same
                # transaction, no second write path).
                await db.conn.execute(
                    "UPDATE payloads SET display_name_origin = 'admin_override' "
                    "WHERE id = ?", (pid,))
        # delete_after, one_time, access_policy.
        if state["delete_after"] != row["delete_after"]:
            await db.conn.execute(
                "UPDATE payloads SET delete_after = ?, updated_at = ? WHERE id = ?",
                (state["delete_after"], _now_iso(), pid))
        if int(state["one_time"]) != int(row["one_time"] or 0):
            await db.conn.execute(
                "UPDATE payloads SET one_time = ?, updated_at = ? WHERE id = ?",
                (int(state["one_time"]), _now_iso(), pid))
        new_policy = state["access_policy"]
        old_policy = row["access_policy"] if "access_policy" in row.keys() else await db.get_access_policy(pid)
        if new_policy != old_policy:
            await db.conn.execute(
                "UPDATE payloads SET access_policy = ?, updated_at = ? WHERE id = ?",
                (new_policy, _now_iso(), pid))

        # WATCH_AD (v25): persist the Watch Ads toggle only when it changed
        # (OFF -> ON / ON -> OFF). Cancel never reaches here; editing unrelated
        # fields never erases the state (diffed write).
        new_wad = 1 if int(state.get("watch_ads_enabled") or 0) else 0
        old_wad = 1 if _safe_row_get(row, "watch_ads_enabled") else 0
        if new_wad != old_wad:
            await db.conn.execute(
                "UPDATE payloads SET watch_ads_enabled = ?, updated_at = ? WHERE id = ?",
                (new_wad, _now_iso(), pid))
            logger.info("Watch Ad %s for payload %s",
                        "enabled" if new_wad else "disabled", pid)
            await db.log_access_event(
                "watch_ads_enabled" if new_wad else "watch_ads_disabled",
                payload_id=pid)

        # Campaign handling: reconcile campaign state with the new policy.
        campaign = await db.get_referral_campaign_by_payload(pid)
        if new_policy == ACCESS_POLICY_FORCE_JOIN_REFERRAL:
            if campaign:
                # Update existing campaign fields (no recreation).
                updates = {}
                if int(campaign["required_referrals"]) != int(state["required_referrals"]):
                    updates["required_referrals"] = int(state["required_referrals"])
                if (campaign["preview_mode"] or PREVIEW_MODE_DISABLED) != state["preview_mode"]:
                    updates["preview_mode"] = state["preview_mode"]
                pmf = campaign["preview_media_file_id"] if "preview_media_file_id" in campaign.keys() else None
                pmt = campaign["preview_media_type"] if "preview_media_type" in campaign.keys() else None
                pdesc = campaign["preview_description"] if "preview_description" in campaign.keys() else None
                if state.get("preview_media_file_id") != pmf:
                    updates["preview_media_file_id"] = state.get("preview_media_file_id")
                if state.get("preview_media_type") != pmt:
                    updates["preview_media_type"] = state.get("preview_media_type")
                if state.get("preview_description") != pdesc:
                    updates["preview_description"] = state.get("preview_description")
                # Re-enable if it was disabled.
                if not campaign["enabled"]:
                    updates["enabled"] = 1
                if updates:
                    sets = [f"{k} = ?" for k in updates]
                    params = list(updates.values()) + [campaign["id"]]
                    await db.conn.execute(
                        f"UPDATE referral_campaigns SET {', '.join(sets)} WHERE id = ?", params)
            else:
                # Policy changed TO referral and no campaign exists — create one.
                # V4: Use _resolve_preview for effective preview values.
                resolved = await _resolve_preview(state)
                now = _now_iso()
                await db.conn.execute(
                    """INSERT INTO referral_campaigns
                       (payload_id, payload_code, required_referrals, preview_mode,
                        unlock_mode, enabled, created_at,
                        preview_media_file_id, preview_media_type, preview_description)
                       VALUES (?, ?, ?, ?, 'permanent', 1, ?, ?, ?, ?)""",
                    (pid, row["payload"], state["required_referrals"], resolved["mode"],
                     now, resolved["file_id"], resolved["media_type"],
                     state.get("preview_description")))
        else:
            # Policy is not REFERRAL — disable any existing campaign (history
            # + progress preserved, never deleted).
            if campaign and campaign["enabled"]:
                await db.conn.execute(
                    "UPDATE referral_campaigns SET enabled = 0 WHERE id = ?",
                    (campaign["id"],))

        await db.conn.commit()
    except Exception as exc:  # noqa: BLE001
        try:
            await db.conn.execute("ROLLBACK")
        except Exception:  # noqa: BLE001
            pass
        logger.error("Wizard: edit save failed, rolled back: %s", exc)
        # BOT-45/46 (Task F): classified terminal + failure screen
        # (retryable transport errors get [ Retry ]; permanent errors a
        # precise corrective instruction).
        _reason, _instr, _retryable = _pcw_classify_wizard_failure(exc=exc)
        await _pcw_wizard_terminal(
            context, "failed", _reason, state=state, db=db, log=logger,
            payload_id=int(pid) if pid else None,
            detail=f"exc={type(exc).__name__}")
        await _pcw_wizard_failure_screen(
            update, context, _reason, _instr, _retryable)
        # Wizard state preserved — the failure screen's Back/Retry returns
        # here so admin can fix + retry.
        return

    # Post-commit analytics (non-fatal).
    try:
        await db.log_access_event("wizard_completed", payload_id=pid)
    except Exception as e:  # noqa: BLE001
        logger.warning("Wizard: analytics logging failed (non-fatal): %s", e)
    logger.info("Wizard: saved edits for payload id=%s", pid)
    # BOT-45/46 (Task F): the edit-mode SUCCESS terminal — with the source
    # identity fields of the payload's canonical indexed file.
    await _pcw_wizard_terminal(
        context, "complete", "SUCCESS", state=state, db=db, log=logger,
        payload_id=int(pid), detail="mode=edit")
    # Clear ALL wizard state + awaiting flags.
    _pcw_clear(context)
    _pcw_clear_awaiting_flags(context)
    await safe_answer_callback(update.callback_query, "\u2705 Changes saved successfully.")
    await pm_payload_detail(update, context, pid)



async def payload_created_screen(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                  payload_id: int) -> None:
    """Success screen shown after the wizard creates a payload.

    Per spec: "The admin MUST immediately see the Payload Access Manager."
    This function delegates directly to pm_payload_detail (the Payload Manager)
    so the admin sees the exact same management screen as when editing an
    existing payload. A short toast ("Payload created!") is shown first.
    """
    await safe_answer_callback(update.callback_query, "\u2705 Payload created!")
    await pm_payload_detail(update, context, payload_id)


# ============================================================
# BOT-45/46 (Task F): WIZARD TERMINAL STATES
# ============================================================
# Production evidence (message 872): BOT6_ADMIN_WIZARD_START
# (pcw, create_single_msgid) never reached a terminal result — the log
# ended mid-wizard when the admin backed out. EVERY wizard attempt now
# terminates in exactly one of:
#
#   WIZARD_COMPLETE   (reason=SUCCESS + the SOURCE IDENTITY fields)
#   WIZARD_FAILED     (a classified safe reason from the set below)
#   WIZARD_CANCELLED  (the admin backed out / navigated away — terminal,
#                      emitted from _pcw_clear / clear_wizard_states so
#                      NO exit path is silent)
#
# Failure classes are SEPARATED at the existing failure points:
#   Telegram transport (timeout / DNS) | media/index failure | validation
#   failure | publication (database) failure. Retryable transport/publication
#   errors render a [ Retry ] button (pcw:create — the wizard state is
#   preserved); permanent errors render a precise corrective instruction.

# The classified safe reason vocabulary (master prompt §9).
WIZARD_TERMINAL_REASONS = (
    "SUCCESS",
    "TELEGRAM_TIMEOUT",
    "TELEGRAM_DNS_ERROR",
    "SOURCE_NOT_FOUND",
    "MEDIA_INVALID",
    "INDEX_MISSING",
    "DUPLICATE_SOURCE",
    "VALIDATION_ERROR",
    "PUBLISH_ERROR",
)
# Retryable = the same attempt can succeed right after a Retry tap
# (transient transport / rolled-back publication).
WIZARD_RETRYABLE_REASONS = frozenset({
    "TELEGRAM_TIMEOUT", "TELEGRAM_DNS_ERROR", "PUBLISH_ERROR",
})

# The corrective instruction per failure class (precise, actionable —
# never a bare "Failed").
_WIZARD_FAILURE_INSTRUCTIONS = {
    "TELEGRAM_TIMEOUT":
        "Telegram timed out talking to the server.\n"
        "The wizard state is preserved — tap Retry.",
    "TELEGRAM_DNS_ERROR":
        "Telegram DNS/network failure.\n"
        "Check this server's network/DNS, then tap Retry.",
    "SOURCE_NOT_FOUND":
        "The payload/source no longer exists.\n"
        "Refresh the Payload Manager and restart the wizard.",
    "MEDIA_INVALID":
        "The selected media is unusable (identity/metadata missing).\n"
        "Reindex the storage channel (Storage → Reindex), then reselect "
        "the file.",
    "INDEX_MISSING":
        "The selected file(s) are no longer indexed.\n"
        "Reindex the storage channel (Storage → Reindex), then restart "
        "the wizard and reselect the file.",
    "DUPLICATE_SOURCE":
        "A payload with this name/source already exists.\n"
        "Choose a different name (Back), or open the existing payload "
        "from the Payload Manager.",
    "VALIDATION_ERROR":
        "Fix the highlighted values (Back), then press Create again.",
    "PUBLISH_ERROR":
        "The database write failed and was FULLY rolled back — no partial "
        "data was written.\n"
        "Tap Retry; if it persists, check the database file and "
        "permissions.",
}

# Marks a wizard state dict as already terminal (blocks the double event
# when _pcw_clear / clear_wizard_states run after a real terminal).
_PCW_TERMINAL_FLAG = "_terminal_emitted"


def _pcw_classify_wizard_failure(exc: Any = None) -> Tuple[str, str, bool]:
    """BOT-45/46 (Task F): classify an exception from the wizard create /
    save path into (safe reason code, corrective instruction, retryable).

    Classification separates Telegram TRANSPORT failure from media/index
    failure from validation failure from PUBLICATION (database) failure —
    the master prompt §9 contract. Pure function (testable).
    """
    name = type(exc).__name__ if exc is not None else ""
    lname = name.lower()
    try:
        text = str(exc or "").lower()
    except Exception:  # noqa: BLE001 — never fail inside classification
        text = ""
    module = ""
    if exc is not None:
        try:
            module = str(getattr(type(exc), "__module__", "") or "").lower()
        except Exception:  # noqa: BLE001
            module = ""
    if "timedout" in lname or "timeout" in text or "timed out" in text:
        reason = "TELEGRAM_TIMEOUT"
    elif ("network" in lname or "dns" in text or "resolve" in text
            or "getaddrinfo" in text or "name or service not known" in text):
        reason = "TELEGRAM_DNS_ERROR"
    elif ("telegram" in module or "telegram" in lname
            or "retryafter" in lname or "flood" in text):
        # Any other Telegram transport error — retryable family.
        reason = "TELEGRAM_TIMEOUT"
    elif "integrity" in lname or "unique constraint" in text:
        reason = "DUPLICATE_SOURCE"
    elif ("sqlite" in module or "aiosqlite" in module
            or "database" in text or "database is locked" in text):
        reason = "PUBLISH_ERROR"
    elif ("media" in text or "file_unique_id" in text
            or "file_id" in text or "indexed" in text
            or lname in ("keyerror", "attributeerror")):
        reason = "MEDIA_INVALID"
    else:
        reason = "PUBLISH_ERROR"
    instruction = _WIZARD_FAILURE_INSTRUCTIONS.get(
        reason, _WIZARD_FAILURE_INSTRUCTIONS["PUBLISH_ERROR"])
    retryable = reason in WIZARD_RETRYABLE_REASONS
    return reason, instruction, retryable


def _pcw_classify_validation_errors(errors: Any) -> str:
    """BOT-45/46 (Task F): map a pre-create validation error list to the
    classified safe reason (duplicate source vs index missing vs plain
    validation). Pure function (testable)."""
    try:
        joined = " ".join(str(e or "") for e in (errors or [])).lower()
    except Exception:  # noqa: BLE001
        joined = ""
    if "already exists" in joined:
        return "DUPLICATE_SOURCE"
    if ("no longer exists in the index" in joined
            or "no longer indexed" in joined
            or "reindex" in joined):
        return "INDEX_MISSING"
    if "media" in joined and ("missing" in joined or "invalid" in joined):
        return "MEDIA_INVALID"
    return "VALIDATION_ERROR"


async def _pcw_source_identity_fields(state: Any, db: Any = None
                                      ) -> Dict[str, Any]:
    """BOT-45/46 (Task F): the SOURCE IDENTITY fields for a wizard state —
    channel_id, message_id, file_pk, file_unique_id_hash (sha256[:16] of
    the file_unique_id — raw ids are NEVER logged).

    Single-file: the canonical indexed row of state['index_id'].
    Collection: the channel + FIRST message + its indexed row (the
    collection's anchor identity). Best-effort: every unresolvable field
    renders '-' (never fabricated — the identity discipline).
    """
    out = {"channel_id": "-", "message_id": "-", "file_pk": "-",
           "file_unique_id_hash": "-"}
    try:
        if not state:
            return out
        if db is None:
            ns = _wz_runtime_ns()
            db = getattr(ns, "db", None) if ns is not None else None
        if db is None:
            # Offline (no db): the wizard state's own identity fields.
            if state.get("collection_channel_id") is not None:
                out["channel_id"] = int(state["collection_channel_id"])
            msg_ids = state.get("collection_msg_ids") or []
            if msg_ids:
                out["message_id"] = int(msg_ids[0])
            if state.get("index_id"):
                out["file_pk"] = int(state["index_id"])
            return out
        row = None
        if state.get("collection_msg_ids") and state.get(
                "collection_channel_id") is not None:
            out["channel_id"] = int(state["collection_channel_id"])
            out["message_id"] = int(state["collection_msg_ids"][0])
            try:
                row = await db.get_indexed_file_by_channel_message(
                    out["channel_id"], out["message_id"])
            except Exception:  # noqa: BLE001 — best-effort identity
                row = None
        elif state.get("index_id"):
            try:
                row = await db.get_indexed_file_by_id(int(state["index_id"]))
            except Exception:  # noqa: BLE001 — best-effort identity
                row = None
        if row is not None:
            keys = row.keys() if hasattr(row, "keys") else []
            if "channel_id" in keys:
                out["channel_id"] = int(row["channel_id"])
            if "message_id" in keys:
                out["message_id"] = int(row["message_id"])
            if "id" in keys:
                out["file_pk"] = int(row["id"])
            if "file_unique_id" in keys:
                uid = str(row["file_unique_id"] or "").strip()
                if uid:
                    out["file_unique_id_hash"] = _wz_hashlib.sha256(
                        uid.encode("utf-8", "replace")).hexdigest()[:16]
    except Exception:  # noqa: BLE001 — identity fields are best-effort
        pass
    return out


async def _pcw_wizard_terminal(context: Any, kind: str, reason: str, *,
                               state: Any = None, payload_id: Any = None,
                               db: Any = None, log: Any = None,
                               detail: str = "") -> None:
    """BOT-45/46 (Task F): emit the wizard TERMINAL event.

    kind: 'complete' | 'failed' | 'cancelled'  ->  WIZARD_COMPLETE /
    WIZARD_FAILED / WIZARD_CANCELLED with the exact safe reason and the
    source identity fields. Marks the state terminal so a later
    _pcw_clear / clear_wizard_states never double-fires a cancel event.
    Also mirrors the event into the existing single analytics system
    (wizard_completed / wizard_failed / wizard_cancelled) — best-effort.
    NEVER raises.
    """
    log = log or _wz_log
    try:
        kind = str(kind or "").strip().lower()
        if kind not in ("complete", "failed", "cancelled"):
            kind = "failed"
        reason = str(reason or "").strip().upper()
        if kind == "complete":
            reason = "SUCCESS"
        elif reason not in WIZARD_TERMINAL_REASONS:
            reason = "PUBLISH_ERROR" if kind == "failed" else "OTHER"
        if state is not None and isinstance(state, dict):
            state[_PCW_TERMINAL_FLAG] = True
        owner = None
        mode = "-"
        step = "-"
        if state is not None and isinstance(state, dict):
            owner = state.get("owner_id")
            mode = str(state.get("mode") or "-")
            step = str(state.get("step") or "-")
        elif context is not None:
            ud = getattr(context, "user_data", None) or {}
            st = ud.get("pcw")
            if isinstance(st, dict):
                owner = st.get("owner_id")
                mode = str(st.get("mode") or "-")
                step = str(st.get("step") or "-")
        src = await _pcw_source_identity_fields(state, db=db)
        event = {"complete": "WIZARD_COMPLETE",
                 "failed": "WIZARD_FAILED",
                 "cancelled": "WIZARD_CANCELLED"}[kind]
        log.info(
            "%s wizard=pcw user_id=%s mode=%s step=%s payload_id=%s "
            "reason=%s channel_id=%s message_id=%s file_pk=%s "
            "file_unique_id_hash=%s%s",
            event, (owner if owner is not None else "-"), mode, step,
            (int(payload_id) if payload_id is not None else "-"), reason,
            src["channel_id"], src["message_id"], src["file_pk"],
            src["file_unique_id_hash"],
            (f" ({detail})" if detail else ""))
        # Mirror into the existing single analytics system (best-effort).
        try:
            ns = _wz_runtime_ns()
            if ns is not None:
                ev = {"complete": "wizard_completed",
                      "failed": "wizard_failed",
                      "cancelled": "wizard_cancelled"}[kind]
                await ns.pcw_log_wizard_event(
                    ev, payload_id=payload_id, reason=reason)
        except Exception:  # noqa: BLE001 — analytics is non-fatal
            pass
    except Exception as exc:  # noqa: BLE001 — a terminal never raises
        try:
            log.warning("WIZARD terminal emit failed: %s",
                        type(exc).__name__)
        except Exception:  # noqa: BLE001
            pass


def _pcw_maybe_cancel_terminal(context: Any, via: str = "pcw_clear") -> None:
    """BOT-45/46 (Task F): the CANCEL terminal.

    Called from _pcw_clear / clear_wizard_states BEFORE the pcw state is
    popped: a LIVE, not-yet-terminated wizard being cleared IS the 'admin
    backed out / navigated away' outcome — it emits WIZARD_CANCELLED so
    the log can never end mid-wizard silently (the message-872 class).
    SYNC (logger-only — the db-backed identity fields come from the
    wizard state itself; the callbacks.py cancel path additionally fires
    its own BOT6_ADMIN_WIZARD_CANCEL + wizard_cancelled analytics event).
    NEVER raises.
    """
    try:
        if context is None:
            return
        ud = getattr(context, "user_data", None) or {}
        state = ud.get("pcw")
        if not isinstance(state, dict) or state.get(_PCW_TERMINAL_FLAG):
            return
        state[_PCW_TERMINAL_FLAG] = True
        _wz_log.info(
            "WIZARD_CANCELLED wizard=pcw user_id=%s mode=%s step=%s "
            "payload_id=%s via=%s channel_id=%s message_id=%s file_pk=%s "
            "file_unique_id_hash=- (the admin backed out / navigated away "
            "— terminal, not silence)",
            (state.get("owner_id") if state.get("owner_id") is not None
             else "-"),
            str(state.get("mode") or "-"), str(state.get("step") or "-"),
            (int(state["edit_payload_id"])
             if state.get("edit_payload_id") is not None else "-"),
            str(via or "-"),
            (int(state["collection_channel_id"])
             if state.get("collection_channel_id") is not None else "-"),
            (int((state.get("collection_msg_ids") or [])[0])
             if state.get("collection_msg_ids") else "-"),
            (int(state["index_id"]) if state.get("index_id") else "-"))
    except Exception:  # noqa: BLE001 — a terminal never raises
        pass


async def _pcw_wizard_failure_screen(update: Any, context: Any,
                                     reason: str, instruction: str,
                                     retryable: bool) -> None:
    """BOT-45/46 (Task F): the classified wizard FAILURE screen.

    Retryable errors (transport / rolled-back publication) render a
    [ Retry ] button (pcw:create — the existing create callback; the
    wizard state is preserved). Permanent errors render the precise
    corrective instruction with Back/Home/Cancel. Follows the wizard's
    existing button/callback patterns exactly. NEVER raises.
    """
    try:
        ns = _wz_runtime_ns()
        if ns is None:
            return
        reason = str(reason or "PUBLISH_ERROR").upper()
        text = (f"\u274C Wizard failed \u2014 {reason}\n\n"
                f"{instruction}\n"
                f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
                f"No partial data was written.")
        rows = []
        if retryable:
            rows.append([ns.InlineKeyboardButton(
                "\U0001F501 Retry", callback_data="pcw:create")])
        rows.append([ns.InlineKeyboardButton("\u2B05\uFE0F Back",
                                             callback_data="pcw:back"),
                     ns.InlineKeyboardButton("\U0001F3E0 Home",
                                             callback_data="pcw:home"),
                     ns.InlineKeyboardButton("\u274C Cancel",
                                             callback_data="pcw:cancel")])
        kb = ns.InlineKeyboardMarkup(rows)
        q = getattr(update, "callback_query", None)
        if q is not None:
            try:
                await ns.safe_answer_callback(q)
            except Exception:  # noqa: BLE001
                pass
            try:
                await ns.safe_edit_text(q, text, reply_markup=kb)
                return
            except Exception:  # noqa: BLE001 — fall through to send
                pass
        chat = getattr(update, "effective_chat", None)
        chat_id = getattr(chat, "id", None) if chat is not None else None
        if chat_id is not None and context is not None:
            try:
                await ns.safe_send_text(context.bot, chat_id, text,
                                        reply_markup=kb)
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001 — a screen never raises
        pass


# ------------------------------------------------------------------
# BOT-45/46: module-local imports + namespace registration of the new
# Task-F helpers. namespace.py copies vars(state) into the shared runtime
# namespace (step 1) and only rebinds MANIFEST-listed section names
# (step 2); the manifest is the frozen authoritative bot.py AST table,
# so these new names are registered onto the STATE foundation at import
# time instead — they become ordinary namespace names before
# _assemble() runs, keeping the late-binding contract exactly (the
# rebound wizard functions resolve them through the namespace globals;
# monkey-patching runtime.<name> keeps working everywhere).
# ------------------------------------------------------------------
import hashlib as _wz_hashlib  # noqa: E402
import logging as _wz_logging  # noqa: E402
import sys as _wz_sys  # noqa: E402

_wz_log = _wz_logging.getLogger("payload-bot")


def _wz_runtime_ns():
    """Resolve the shared presentation runtime namespace at CALL time."""
    return _wz_sys.modules.get("app.presentation.telegram.runtime")


from app.presentation.telegram import state as _wz_state_reg  # noqa: E402

_wz_state_reg.WIZARD_TERMINAL_REASONS = WIZARD_TERMINAL_REASONS
_wz_state_reg.WIZARD_RETRYABLE_REASONS = WIZARD_RETRYABLE_REASONS
# BOT-45/46 round 2 (bot-46.log production evidence — 13× "Callback error
# (pcw:create): name '_WIZARD_FAILURE_INSTRUCTIONS' is not defined"):
# the module-level dict was FORGOTTEN in this registration block while
# the two sibling constants above WERE registered — the manifest-owned
# (rebound) _pcw_classify_wizard_failure resolves its globals through
# the SHARED namespace, so the failure-classification path raised
# NameError exactly when the wizard create FAILED (the DB error was
# swallowed by the NameError — the admin saw neither the classified
# failure screen nor the [ Retry ] button). Registered here alongside
# its siblings: the namespace copy is the one the rebound functions see.
_wz_state_reg._WIZARD_FAILURE_INSTRUCTIONS = _WIZARD_FAILURE_INSTRUCTIONS
_wz_state_reg._pcw_classify_wizard_failure = _pcw_classify_wizard_failure
_wz_state_reg._pcw_classify_validation_errors = \
    _pcw_classify_validation_errors
_wz_state_reg._pcw_source_identity_fields = _pcw_source_identity_fields
_wz_state_reg._pcw_wizard_terminal = _pcw_wizard_terminal
_wz_state_reg._pcw_maybe_cancel_terminal = _pcw_maybe_cancel_terminal
_wz_state_reg._pcw_wizard_failure_screen = _pcw_wizard_failure_screen
_wz_state_reg._wz_runtime_ns = _wz_runtime_ns
_wz_state_reg._PCW_TERMINAL_FLAG = _PCW_TERMINAL_FLAG
# The module-private SUPPORT names the rebound manifest functions resolve
# through the namespace globals (the DD2 landmine class this architecture
# exists to prevent): the logger + hashlib module + sys module used by
# _pcw_wizard_terminal / _pcw_source_identity_fields / _wz_runtime_ns.
_wz_state_reg._wz_log = _wz_log
_wz_state_reg._wz_hashlib = _wz_hashlib
_wz_state_reg._wz_logging = _wz_logging
_wz_state_reg._wz_sys = _wz_sys
