"""Telegram presentation runtime state (ARCHITECTURE PROPER BREAKDOWN).

The authoritative home of the import zone, configuration
bindings, constants, locks, caches and singletons that the
Telegram presentation sections share. Parsed VERBATIM from
the legacy bot.py monolith (import zone + every module-level
statement, original order preserved).

The shared runtime NAMESPACE object is assembled by
namespace.py: every section function is rebound into it, so
late binding and the regression suites' monkey-patching
semantics (patching ``runtime.<name>``) keep working.
"""

from __future__ import annotations

# ------------------------------------------------------------------
# Deployment identity (V5.1 §50 semantics, package form): SHA-256
# over the presentation section sources — same copy → same id, any
# edit → new id. Exposed for tests via _runtime_source_bytes().
# ------------------------------------------------------------------
import hashlib as _identity_hashlib
import os as _identity_os

_RUNTIME_ID_EXCLUDE = {"__init__.py", "state.py", "namespace.py",
                            "_manifest.py"}


def _runtime_identity_files():
    pkg_dir = _identity_os.path.dirname(_identity_os.path.abspath(__file__))
    return sorted(
        f for f in _identity_os.listdir(pkg_dir)
        if f.endswith(".py") and f not in _RUNTIME_ID_EXCLUDE)


def _runtime_source_bytes() -> bytes:
    pkg_dir = _identity_os.path.dirname(_identity_os.path.abspath(__file__))
    parts = []
    for name in _runtime_identity_files():
        with open(_identity_os.path.join(pkg_dir, name), "rb") as _f:
            parts.append(_f.read())
    return b"\n".join(parts)


def compute_runtime_source_digest() -> str:
    return _identity_hashlib.sha256(_runtime_source_bytes()).hexdigest()[:12]


def _compute_runtime_build_id() -> str:
    """V5.1 deployment identity (package form — see module docstring)."""
    return "bot6-" + compute_runtime_source_digest()



# ============================================================
# IMPORTS
# ============================================================
import asyncio

import hashlib

import hmac

import json

import logging

import os

import random as _random

import re

import time

import unicodedata

import zlib

from dataclasses import dataclass, field

from datetime import datetime, timezone, timedelta

from typing import Any, Dict, List, Optional, Set, Tuple


import aiosqlite

import sqlite3

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    InputMediaVideo,
    InputMediaAnimation,
    Message,
    User,
    BotCommand,
    BotCommandScopeDefault,
    BotCommandScopeChat,
    WebAppInfo,
)

from telegram.constants import ChatMemberStatus, ParseMode

from telegram.error import (
    BadRequest,
    Forbidden,
    NetworkError,
    RetryAfter,
    TelegramError,
    TimedOut,
)

from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    ChatJoinRequestHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)


# Load .env if python-dotenv is available (optional convenience).
try:  # pragma: no cover - optional dependency
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # noqa: BLE001
    pass


# ============================================================================
# PHASE 8: MODULAR SERVICE LAYER (app/core/*)
# ============================================================================
# The new correctness-critical services live in the app/ package (staged
# modularization — see docs/ARCHITECTURE.md):
#   app/core/indexing_engine.py — durable index jobs, resume, truthful states
#   app/core/verification.py     — source↔DB↔payload verification + reconcile
#   app/core/fj_link_health.py   — Force-Join invite-link health + cache
# These modules NEVER import this file (no circular imports); everything is
# wired at call time. DEPLOYMENT NOTE: the app/ directory MUST be deployed
# together with bot.py (the ZIP package is the deployment unit — copying the
# single bot.py file alone is no longer supported and fails fast here).
from app.core import fj_link_health as _fj_health

from app.core import indexing_engine as _idx_engine

from app.core import verification as _verification_engine


# NETWORK PLATFORM (Phase 8 → Network): the additive multi-bot layer.
# Same standalone-module discipline as app/core/* — these services never
# import this file; bot.py wires them with its DB adapter / transports at
# call time. See docs/ARCHITECTURE.md (§ Network Platform).
#   app/network/credentials.py — CredentialVault (authenticated token encryption)
#   app/network/registry.py    — verified-activation bot registration + health
#   app/network/points.py      — idempotent points ledger + atomic debits
#   app/network/routing.py     — health-aware router + opaque signed g-links
#   app/network/broadcast.py   — durable network broadcast engine
#   app/network/workers.py     — BotWorkerManager (shared-logic worker apps)
from app.network.credentials import CredentialVault, mask_token as _mask_token

from app.network.registry import (
    BotRegistryService as _BotRegistryService,
    token_format_ok as _net_token_format_ok,
)

from app.network.points import PointService as _PointService

from app.network.routing import (
    GlobalPayloadLinks as _GlobalPayloadLinks,
    NetworkRouter as _NetworkRouter,
    MAX_REDIRECTS as _NET_MAX_REDIRECTS,
)

from app.network.broadcast import (
    NetworkBroadcastEngine as _NetworkBroadcastEngine,
    classify_send_error as _net_classify_send_error,
)

from app.network.workers import BotWorkerManager as _BotWorkerManager


# ============================================================
# ARCHITECTURE PHASE — shared modules extracted from bot.py
# ============================================================
# The canonical homes for the extracted responsibilities (see
# docs/ARCHITECTURE_AUDIT.md and docs/BOT_COMPATIBILITY.md). Every name
# below is re-exported here so the legacy module surface — and the
# regression suites that read/patch B.<name> — behave identically.
from app.core.constants import (
    DEFAULT_RETRIEVE_BUTTON,
    DEFAULT_RETRIEVE_TEXT,
    ACCESS_POLICY_OPEN, ACCESS_POLICY_FORCE_JOIN,
    ACCESS_POLICY_FORCE_JOIN_REFERRAL, ACCESS_POLICY_PASSWORD,
    ACCESS_POLICY_COUPON, ACCESS_POLICY_PAYMENT, ACCESS_POLICY_VIP,
    ACCESS_POLICY_CUSTOM, ACCESS_POLICIES_IMPLEMENTED,
    ACCESS_POLICIES_ALL, ACCESS_POLICY_DEFAULT,
    PREVIEW_MODE_DISABLED, PREVIEW_MODE_THUMBNAIL,
    PREVIEW_MODE_DESCRIPTION, PREVIEW_MODE_CUSTOM, PREVIEW_MODE_AUTO,
    PREVIEW_MODE_SELECT, PREVIEW_MODES_ALL, PREVIEW_MODE_DEFAULT,
    REFERRAL_REQUIRED_PRESETS, REFERRAL_REQUIRED_DEFAULT,
    REFERRAL_TOKEN_LENGTH,
    WATCH_AD_STATUS_PENDING, WATCH_AD_STATUS_REWARDED,
    WATCH_AD_STATUS_EXPIRED, WATCH_AD_STATUS_REJECTED,
    WATCH_AD_REASON_REQUIRED, WATCH_AD_REASON_UNLOCKED,
    WATCH_AD_PROVIDER_DEFAULT,
    WATCH_AD_AD_CONTROL_KEY, WATCH_AD_AD_CONTROL_SHORT,
    WATCH_AD_AD_CONTROL_TWO, WATCH_AD_AD_CONTROL_RANDOM,
    WATCH_AD_AD_CONTROL_THREE, WATCH_AD_AD_CONTROL_MODES,
    WATCH_AD_AD_CONTROL_DEFAULT, WATCH_AD_RANDOM_MIN,
    WATCH_AD_RANDOM_MAX, WATCH_AD_MAX_REQUIRED_ADS,
    WATCH_ADS_GLOBAL_ENABLED_KEY, WATCH_ADS_SESSION_TTL_KEY,
    WATCH_ADS_SESSION_TTL_MIN, WATCH_ADS_SESSION_TTL_MAX,
    WATCH_AD_OVERRIDE_GLOBAL, WATCH_AD_SESSION_TTL,
    ENABLE_ANALYTICS,
)

from app.storage.dbutil import now_iso as _now_iso, safe_row_get as _safe_row_get

from app.storage.database import DatabaseBase

from app.storage.schema import (
    Database,  # noqa: F401 — compatibility re-export (tests construct B.Database)
    SCHEMA_VERSION,  # noqa: F401 — compatibility re-export (tests pin B.SCHEMA_VERSION)
    WATCH_AD_TOKEN_BYTES,
    set_runtime_context as _schema_set_runtime_context,
)

from app.storage.repositories.referrals import generate_referral_token

from app.bootstrap.config import (EnvDefaults, RuntimeConfig,
                                    compute_runtime_build_id)


# ARCHITECTURE DECOUPLING — the composition modules this facade delegates to
# (§3 bootstrap / §4 container / §7-§9 network+web lifecycle). app/* NEVER
# imports bot.py: the legacy namespace is INJECTED as a parameter.
import sys as _sys_mod

from app.bootstrap import application as _app_bootstrap

from app.services import container as _app_container

from app.services.container import legacy_service_factories as _legacy_service_factories

from app.web import server as _web_server

from app.network import lifecycle as _net_lifecycle

from app.network import managed_bots as _managed_bots

from app.network import bot_miniapp as _bot_miniapp



# ============================================================
# ARCHITECTURE PHASE — core services & adapter modules
# ============================================================
from app.core.format import (
    MEDIA_TYPE_LABELS,
    _MD_SPECIAL,
    escape_md,
    fmt_ts,
    format_duration,
    format_size,
    md_code_span,
    media_emoji,
    media_type_label,
    truncate,
)

from app.core.payload.service import (
    _CONTROL_CHARS_RE,
    _MARKDOWN_SPECIALS_RE,
    _PASSWORD_SALT,
    build_range_link,
    compact_callback_arg,
    generate_collection_code,
    is_internal_id_ref,
    get_payload_display_name,
    hash_password,
    is_collection_link,
    is_msg_link,
    is_password_hashed,
    is_range_link,
    is_valid_date,
    make_payload_service,
    parse_collection_link,
    parse_msg_link,
    parse_range_link,
    sanitize_display_name,
    sanitize_payload_name,
    sanitize_slug,
    validate_display_name,
    validate_payload,
    verify_password,
)

from app.core.referral.service import (
    is_referral_link,
    make_referral_service,
    parse_referral_token,
)

from app.core.watch_ads.service import (
    WATCH_AD_TEMPLATE_MAX_LEN,
    WATCH_AD_TEMPLATE_SETTING_KEY,
    WATCH_AD_UNLOCK_TEMPLATE_DEFAULT,
    _WATCH_AD_TEMPLATE_FIELDS,
    make_watch_ads_service,
)

from app.core.access.engine import (
    AccessResult,
    make_access_points_service,
)

from app.core.force_join.service import (
    ChannelAccessStatus,
    MemberCheckResult,
    make_force_join_service,
)

from app.core.delivery.service import (
    make_delivery_service,
)

from app.web.auth import (
    make_web_auth_service,
)

from app.presentation.telegram.keyboards import (
    make_keyboards,
)

from app.presentation.telegram.network_ui import (
    _NET_LINK_RE,
    _NET_REG_STATE_KEY,
    make_network_ui,
)

from app.core.constants import (
    AUTO_DELETE_DEFAULT,
    BROWSE_AUTO_DELETE_DELAY,
    COLLECTION_CODE_LENGTH,
    COLLECTION_LINK_PREFIX,
    DISPLAY_NAME_MAX_LENGTH,
    FJ_BATCH_SIZE_DEFAULT,
    FJ_MODE_DEFAULT,
    FJ_MODE_FIXED_ORDER,
    FJ_MODE_PROGRESSIVE_RANDOM,
    FJ_MODE_SHOW_ALL,
    JOIN_REQUEST_POLICY_APPROVAL,
    JOIN_REQUEST_POLICY_REQUEST,
    JOIN_REQUEST_TTL,
    MSG_LINK_PREFIX,
    NET_BCAST_CB,
    NET_BOT_CB,
    NET_CB_PREFIX,
    NET_CREATE_CB,
    NET_DEFAULT_MAX_BOTS,
    NET_DEFAULT_POINTS_PER_BOT,
    NET_DEFAULT_POINT_COST,
    NET_DG_CB,
    NET_LEGACY_CB,
    NET_MANAGED_CB,
    NET_PTS_CB,
    NET_PT_UNLOCK_CB,
    NET_REG_CB,
    CONTROL_CB,
    NET_SETTING_BCAST_CONFIRM,
    NET_SETTING_BCAST_RATE,
    NET_SETTING_ENABLED,
    NET_SETTING_HEALTH_INTERVAL,
    NET_SETTING_MAX_BOTS,
    NET_SETTING_MAX_REWARD,
    NET_SETTING_POINTS_ACCESS,
    NET_SETTING_POINTS_PER_BOT,
    NET_SETTING_POINT_COST,
    PAYLOAD_PATTERN,
    RANGE_LINK_PREFIX,
    REFERRAL_LINK_PREFIX,
    WATCH_AD_INITDATA_MAX_AGE,
    WATCH_AD_SDK_MAX_CHARS,
)



# WATCH_AD (Monetag Mini App): aiohttp powers the Watch Ads Mini App HTTP
# server that runs INSIDE the same Python process / event loop as the bot.
# It is an optional-at-import dependency: if missing, the bot still runs and
# Watch Ads simply reports "temporarily unavailable" (no crash, no second
# process, no second application).
try:  # pragma: no cover - optional dependency
    from aiohttp import web as _aiohttp_web
    import aiohttp as _aiohttp_client

    AIOHTTP_AVAILABLE = True
except Exception:  # noqa: BLE001
    _aiohttp_web = None
    _aiohttp_client = None
    AIOHTTP_AVAILABLE = False



# ============================================================
# CONFIGURATION  (edit here OR set via environment variables)
# ============================================================
# ARCHITECTURE DECOUPLING: environment parsing + validation moved to
# app/bootstrap/config.py (RuntimeConfig.from_env) — identical parsing,
# validation order, and error messages. The parsed values are bound here as
# module-level names so the legacy namespace (and the regression suites'
# monkey-patching semantics, e.g. B.MINI_APP_DEV_ALLOW_HTTP) keep working
# unchanged.
_CFG = RuntimeConfig.from_env(__file__)


BOT_TOKEN: str = _CFG.bot_token

ADMIN_IDS: list[int] = list(_CFG.admin_ids)


DATABASE_FILE: str = _CFG.database_file



RUNTIME_BUILD_ID: str = _compute_runtime_build_id()

# Bot username is auto-detected at startup via bot.get_me(). It can be seeded
# from the environment as a fallback, but is overwritten once the bot connects.
BOT_USERNAME: str = _CFG.bot_username


# PHASE 7 HOTFIX (bot.log 22 — token-change incident): Telegram file_ids are
# BOT-SCOPED. When the bot token changes, every file_id previously stored in
# indexed_files was issued to the OLD bot and is potentially invalid for the
# new one. post_init detects the bot-identity change (bot_settings
# file_id_owner_bot_id) and sets this flag for the lifetime of the process:
#   * delivery then VALIDATES stored file_ids proactively (getFile probe)
#     and self-recovers from the source channel before/instead of failing;
#   * re-indexing refreshes canonical file_ids in place (exact duplicates).
# Reactive delivery-time recovery is ALWAYS armed regardless of this flag —
# the flag only makes recovery proactive instead of after-the-fact.
FILE_IDS_STALE_EPOCH: bool = False


# Auto delete (seconds). 0 = never. Overridable per-payload and via settings.
# Auto reindex background loop interval (seconds).
AUTO_REINDEX_INTERVAL: int = _CFG.auto_reindex_interval


ENABLE_FORCE_JOIN: bool = _CFG.enable_force_join

# BOTV13 Phase 1C: auto-payload creation defaults to OFF. Channel indexing
# still runs (files are stored), but no user-facing payload is auto-created.
# Admins can enable it via Settings → Auto Payload: OFF → Enable.
ENABLE_AUTO_PAYLOAD: bool = _CFG.enable_auto_payload


# Rate limiting
RATE_LIMIT_WINDOW: int = 60        # seconds

RATE_LIMIT_MAX: int = 20           # max /start deliveries per user per window


# Reindex tuning
# Issue 26: incremental reindex model. The old "1 → 500 / 1 → 1000 / 1 → latest"
# forward scan is REMOVED. The new model uses a per-channel cursor:
#   - First scan:  scan BACKWARDS from latest_message_id (stop 100 missing)
#   - Normal scan: scan FORWARDS from last_scanned_message_id+1 to latest_message_id
#   - Auto reindex: skip if latest <= last_scanned
# Stop conditions (normal scan): latest reached, 50 consecutive missing,
# 100 consecutive no-media, safety cap.
REINDEX_DEFAULT_COUNT: int = 500   # upper safety cap (prevents infinite scan)

REINDEX_DELAY: float = 0.05        # polite delay between fetches

# Normal scan: stop after this many consecutive missing messages (history gap).
REINDEX_MAX_CONSEC_MISSING: int = 50

# Normal scan: stop after this many consecutive messages with no media (channel
# tail has only text posts, no more files to index).
REINDEX_MAX_CONSEC_NO_MEDIA: int = 100

# First scan (backward): stop after this many consecutive missing (determines
# latest_message_id + indexes existing content).
REINDEX_FIRST_SCAN_MAX_MISSING: int = 100

AUTO_SCAN_MAX_MISSING: int = 10   # auto-loop stops after this many missing in a row

AUTO_SCAN_LIMIT: int = 100        # max messages scanned per channel per auto-loop cycle

# Backward scan starting offset: we don't know the absolute latest message_id, so
# we probe from a high number and walk backwards. This is the probe ceiling.
# Set high enough to cover any practical channel size (exponential search means
# only ~24 probes needed even for 10M messages).
REINDEX_PROBE_CEILING: int = 10000000


# Auto delete timer presets (seconds). 0 = never.
DELETE_TIMER_PRESETS: List[int] = [10, 20, 30, 60, 300, 0]

DELETE_TIMER_LABELS: Dict[int, str] = {10: "10s", 20: "20s", 30: "30s", 60: "60s",
                                       120: "120s", 300: "300s", 0: "Never"}

INHERIT_SENTINEL: int = -1  # payload.delete_after == NULL means "inherit global"


# Database schema version (bump when adding migrations)
# v10 (Issues #49-#62): Retrieve settings enforcement, Global Branding panel,
# Collection Branding UI, Source Post Branding toggle, Retrieve analytics.
# v11 (Issue #84): Reply-based retrieve system — branding UI removed, retrieve
# message text/button settings added. Branding DB tables kept for compat.
# v12 (Issues #85-#93): Reindex probe fix, force-join dynamic eval, internal
# message protection wrapper, retrieve failure handling, dead branding settings
# cleanup.
# v13 (Issue #94): Payload Referral Gate System — referral_campaigns,
# referral_tokens, referral_history, payload_unlocks tables.
# v14 (Access Engine V1): Centralized authorization layer. Adds
# payloads.access_policy (OPEN | FORCE_JOIN | FORCE_JOIN_REFERRAL), preview
# media columns on referral_campaigns, access_events analytics table, and
# rebuilds referral_history to remove ON DELETE CASCADE (history is permanent).
# Existing payloads migrate to FORCE_JOIN (their existing behaviour). Existing
# referral campaigns migrate their policy to FORCE_JOIN_REFERRAL.
# v23 (BOTV13 Phase A): Force Join STABLE ACTIVE BATCH state machine. Adds
# active_batch / completed_batches / batch_cursor columns to fj_progress so the
# current batch is PERSISTED and never recalculated from the unjoined set.
# Non-destructive ALTER ADD COLUMN (idempotent, backward compatible).
# v24 (BOT6 Phase 4): ONE canonical FJ dashboard per admin chat. Adds the
# fj_dashboards table (admin_chat_id, dashboard_message_id, updated_at) so
# config changes EDIT the persisted dashboard message instead of sending new
# ones. Also REMOVES the unlocked_payload_ids access bypass (the column stays
# for backward compat but is no longer read as an access fast-path — current
# Telegram state alone determines access).
# BOT7 RESTORATION: the v23/BOTV13 unlocked_payload_ids semantics are
# RESTORED on top of v24 (no schema change): a payload whose FJ batch
# completed is recorded and may be re-opened without the NEXT batch being
# created/enforced for it, while a currently ACTIVE batch still live-checks
# every access (see _get_fj_batch / _unjoined_for_access).
# v25 (WATCH_AD): payload-level Watch Ads access requirement. Adds
# payloads.watch_ads_enabled (INTEGER NOT NULL DEFAULT 0 — existing payloads
# stay OFF) and the watch_ad_sessions table for secure, replay-protected,
# per-user/per-payload rewarded-ad sessions. Global runtime config keys
# (watch_ads_mini_app_url / watch_ads_monetag_sdk / watch_ads_unlock_window)
# live in the EXISTING bot_settings table — no new settings system.
# v30 (WEBSITE PHASE 2 — part A): richer indexed media metadata for the
# Payload Website / Mini App / player. indexed_files gains five NULLABLE
# columns (mime_type, width, height, thumb_file_id, thumb_file_unique_id).
# Additive-only: every existing table/column/row is untouched; legacy rows
# keep NULL metadata (never fabricated); re-indexing backfills what the
# source message actually provides.
# v31 (WEBSITE PHASE 3 — planned "v30 part B"): the website_payloads
# PRESENTATION table + the website_enabled setting seed. Implemented as a
# separate version block because a database already stamped at 30 must
# re-enter a migration block to receive the new presentation table and
# seed (restart-safe on already-migrated deployments) — the documented
# 27→28→29→30 chain precedent. Additive-only: no existing table, column,
# row or Telegram-side behavior is touched.
# v32 (WEBSITE PHASE 4 — Media Gateway): SETTINGS-ONLY migration (no DDL —
# the streaming cache is filesystem state, never schema). Seeds the live
# streaming/cache toggles + bounds into the EXISTING bot_settings table
# (INSERT OR IGNORE — admin values are never overwritten):
#   website_stream_enabled ('true' — streaming works when the Website is
#     ON; the website_enabled GLOBAL gate still applies first),
#   website_cache_enabled ('true'), website_cache_max_bytes (2 GiB),
#   website_cache_ttl_seconds (3600), website_stream_token_ttl (300 s —
#   short-lived by design), website_max_concurrent_streams (32).
# Additive / idempotent / restart-safe / non-destructive.

# ============================================================
# NETWORK PLATFORM (v29) — constants (Phase 8 → Network)
# All values are CONFIGURABLE via bot_settings (spec §7/§8) — nothing is
# hard-coded at the use sites; these are only the DEFAULTS.
# ============================================================


# Network callback prefixes (verified non-colliding with the ~120 existing
# prefixes enumerated in the Phase N0 audit):
#   net:<view>            — admin: Network Control Center views
#   nreg:<step>           — user/admin: Add-Bot registration wizard
#   nbot:<id>:<action>    — user/admin: registered-bot management
#   npts:<view>           — user: My Points / history
#   ptunlock:<pid>        — user: atomic point unlock for a payload
#   gpl:<id>:<action>     — admin: Global Payload Link management
#   nbc:<view>            — admin: Network Broadcast Center
NET_GPL_CB = "gpl:"



# Message-ID direct links: prefix used in deep links like ?start=m8619

# Range links: prefix used in deep links like ?start=r8619_8625
# DEPRECATED (Issue 2 Critical Fix): kept for backward-compat. New collections
# use COLLECTION_LINK_PREFIX. Old r<link> links are auto-migrated on open.

# Collection links: prefix used in deep links like ?start=c7f3a9b2
# Issue 2 Critical Fix: explicit collection storage replaces unreliable ranges.

# Issue #94: Referral links — ?start=ref_<token>. The token is an opaque 16-char
# hex string that maps to (campaign_id, inviter_user_id) in referral_tokens.
# Using an opaque token avoids parsing ambiguity (payload names can contain
# underscores, so ref_payload_token would be ambiguous).

# ============================================================
# WATCH_AD (v25/v26) — constants
# ============================================================
# Watch Ads is an INDEPENDENT payload-level requirement, NOT an access policy.
# V2 (v26) semantics — REFERRAL OR WATCH ADS (never AND):
#   base access policy (OPEN / FORCE_JOIN / FORCE_JOIN_REFERRAL)
#     + Force Join (always a mandatory prerequisite, never bypassed)
#     + referral requirement OR watch_ads requirement (whichever completes)
#     = authorized
# For OPEN / FORCE_JOIN payloads Watch Ads remains the sole optional
# requirement (identical to v25). For FORCE_JOIN_REFERRAL payloads the user
# unlocks by completing EITHER the referral goal OR the Watch Ads reward.
# Do NOT set access_policy = WATCH_AD — the base policy stays untouched.
# Callback prefixes (no collisions with any existing prefix):
#   wad:<payload_id>        — user-facing: create/resolve a secure ad session
#   wadcheck:<arg>          — user-facing: re-run delivery (like verify:)
#   plgwad:<pid>            — admin: per-payload Watch Ads config panel
#   plgwadt:<pid>           — admin: toggle watch_ads_enabled
#   plgwadm:<pid>           — admin (v27): per-payload Ads Mode override chooser
#   plgwadmset:<pid>:<mode> — admin (v27): persist the ads-mode override
#   panel:wadsettings       — admin: global Watch Ads Settings section
#   wadcfg:web / wadcfg:sdk / … — admin: global website/SDK management
#   wadcfg:control / wadcfg:controlset:<mode> — admin: Ads Control mode
#   wadcfg:status           — admin (v27): Status & Monitoring panel
#   wadcfg:globalon / wadcfg:globaloff / wadcfg:globaloffyes — admin (v27):
#                             GLOBAL master switch (OFF is confirm-gated)
#   wadcfg:ttl / wadcfg:ttlset:<secs> — admin (v27): session timeout presets
#   wadcfg:reconcile / wadcfg:reconcileyes — admin (v27): reconcile stuck
#                             sessions (confirm-gated)
WATCH_AD_CALLBACK_PREFIX: str = "wad:"

WATCH_AD_CHECK_PREFIX: str = "wadcheck:"



# Length of the random collection code (hex). 8 hex chars = 4 bytes = ~4 billion
# combinations, low collision risk for any practical collection count.

# Collection browse pagination (used by range Browse Files)
COLLECTION_BROWSE_PAGE_SIZE: int = 8


# Collection download-all flood control
COLLECTION_SEND_DELAY: float = 1.0


# Album delivery: max items per send_media_group call (Telegram limit is 10)
ALBUM_MAX_ITEMS: int = 10


# Multi-file forward detection: time to wait for remaining album messages (seconds)
FORWARD_BATCH_WAIT: float = 1.5


# Auto reindex on startup (one-shot scan after init)
AUTO_REINDEX_ON_STARTUP: bool = _CFG.auto_reindex_on_startup


# Broadcast worker tuning
BROADCAST_CONCURRENCY: int = 5

BROADCAST_BATCH_SIZE: int = 100

BROADCAST_SEND_DELAY: float = 0.05

BROADCAST_MAX_RETRIES: int = 3

BROADCAST_PROGRESS_EVERY: int = 25

SCHEDULED_BROADCAST_POLL_INTERVAL: int = 60  # seconds

CLEANUP_LOOP_INTERVAL: int = 10  # seconds


# ============================================================
# WATCH_AD (v25) — payload-level Watch Ads access requirement
# ============================================================
# An admin can enable Watch Ads (watch_ads_enabled) on an individual payload.
# Normal users must then complete a VERIFIED rewarded advertisement (Monetag
# SDK for Telegram Mini Apps + server-side S2S postback) before the payload
# unlocks. Watch Ads is an INDEPENDENT requirement on top of the existing
# base policy (OPEN / FORCE_JOIN / FORCE_JOIN_REFERRAL) — it is NOT a policy
# replacement and it NEVER bypasses Force Join or the existing referral flow.
#
# Runtime toggles (admin-managed from Telegram, persisted in bot_settings):
#   watch_ads_mini_app_url    — public HTTPS base URL of the Mini App website
#   watch_ads_monetag_sdk     — the official Monetag SDK/ad-tag code (verbatim)
#   watch_ads_unlock_window   — seconds a verified ad unlock stays valid
# The MINI_APP_BASE_URL environment variable is ONLY an optional seed value
# for watch_ads_mini_app_url; the database value is authoritative and is NEVER
# overwritten by the environment on restart.
MINI_APP_PORT: int = _CFG.mini_app_port

MINI_APP_ENABLED: bool = _CFG.mini_app_enabled

# Production requires HTTPS for Telegram Mini Apps. HTTP may only be permitted
# when this explicit development switch is set.
MINI_APP_DEV_ALLOW_HTTP: bool = _CFG.mini_app_dev_allow_http

MINI_APP_BASE_URL: str = _CFG.mini_app_base_url

# How long a VERIFIED ad unlock satisfies the Watch Ads requirement
# (rewarded_at -> unlock_expires_at). Default 180s per the product example.
WATCH_AD_UNLOCK_WINDOW: int = _CFG.watch_ad_unlock_window

# Admin-configurable default verification/session timeout (bot_settings
# watch_ads_session_ttl); WATCH_AD_SESSION_TTL (env) only seeds the DEFAULT
# and is never persisted over a DB value on restart.
# Anti-spam: max new ad sessions per (user, payload) per hour. Prevents
# unlimited simultaneous sessions when the user presses Watch Ad repeatedly.
WATCH_AD_SESSION_HOURLY_CAP: int = (
    EnvDefaults.from_env().watch_ad_session_hourly_cap)


# ARCHITECTURE DECOUPLING: inject the parsed runtime context into the
# storage-owned schema layer (app/storage/schema.py — Database + migrations
# extracted verbatim from this module). The storage layer never imports the
# Telegram/entry layer; this is the composition wiring (same late-binding
# direction as every other app/* service dependency).
_schema_set_runtime_context(
    admin_ids=ADMIN_IDS,
    database_file=DATABASE_FILE,
    runtime_build_id=RUNTIME_BUILD_ID,
    watch_ad_unlock_window=WATCH_AD_UNLOCK_WINDOW,
    watch_ad_session_hourly_cap=WATCH_AD_SESSION_HOURLY_CAP,
)

# Telegram Mini App initData freshness (auth_date age, seconds).
# Secure session token: 16 random bytes -> 32 hex chars (unguessable).
# Monetag SDK code size guard (admin paste is treated as untrusted config).


# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler("bot.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

logging.getLogger("httpx").setLevel(logging.WARNING)

logging.getLogger("telegram").setLevel(logging.INFO)

logger = logging.getLogger("payload-bot")



# ---- Collection link helpers (Issue 2 Critical Fix) ----
import secrets as _secrets



# ---- Issue #94: Referral link helpers ----


# ---- BOTV13 Part 1: Routing ID helpers ----

# Routing IDs for single-file payloads are 8-char hex tokens (no underscore
# inside, so they're always the last _-separated segment of a human-friendly
# link). Collections use c<code> (also no internal underscore). This makes
# extraction trivial: split by '_', take the last segment.
ROUTING_ID_LENGTH = 8  # 8 hex chars = 4 bytes



# ============================================================
# ALBUM / MEDIA GROUP DELIVERY HELPERS
# ============================================================
# Per Issue 3 spec: ONLY photo / video / animation may be grouped into albums.
# Telegram rejects mixed groups containing documents ("Document can't be mixed
# with other media types"), so documents, voice, sticker and video_note are
# always delivered sequentially via send_file(). This eliminates the album
# mix-type error entirely while still chunking eligible media as 10+10+5...
ALBUM_ELIGIBLE_TYPES = {"photo", "video", "animation"}

# Types that must always be sent individually (cannot join a media group).
ALBUM_UNSUPPORTED_TYPES = {"document", "audio", "voice", "sticker", "video_note"}


# ============================================================
# V5.2 — DELIVERY TRANSIENT-ERROR RETRY (bot.log 18 @ 03:40:39:
# "Album send failed (chunk 0): Timed out" -> sequential fallback ->
# "Network error during delivery: TimedOut" -> send_file had ZERO retry
# -> the file permanently failed with only a generic message).
#
# Transient Telegram/network errors (TimedOut, NetworkError, RetryAfter
# flood windows) are retried with BOUNDED EXPONENTIAL BACKOFF. Deterministic
# rejections (BadRequest) and permission errors (Forbidden) are NEVER
# retried — they cannot succeed. Only the FAILED file/chunk is retried;
# files already delivered successfully are never re-sent. When every retry
# fails, the user gets an actionable [🔄 Retry Failed File] button that
# re-enters the SAME pipeline (fresh Access Engine authorization +
# _deliver_files_core) — never a delivery bypass.
# ============================================================
DELIVERY_TRANSIENT_ATTEMPTS = 3   # total attempts per file/chunk (1 + 2 retries)

DELIVERY_RETRY_BASE_DELAY = 1.0   # seconds; doubles per retry (1s, 2s, ...)

DELIVERY_RETRY_MAX_DELAY = 5.0    # per-retry backoff cap

DELIVERY_FLOOD_SLEEP_CAP = 15     # cap for RetryAfter flood sleeps (seconds)

# V25 §10 (bot-34.log): the bounded cap (seconds) for in-handler
# FloodWait retries in safe_send_text — a commanded wait at or below
# this retries the send ONCE after sleeping; anything longer returns
# None honestly (never a multi-minute block of the update pipeline).
# Lives in the namespace foundation so the REBOUND safe_send_text
# resolves it through the shared globals.
SAFE_SEND_FLOOD_RETRY_CAP = 3



# ============================================================
# PHASE 7 HOTFIX — STALE file_id DETECTION & VALIDATION
# (bot.log 22: bot token changed -> every stored file_id invalid)
# ============================================================
# Telegram file_ids are BOT-SCOPED. A file_id captured by the previous bot
# token is rejected by the new bot with the SAME BadRequest message seen in
# production: "Wrong file identifier/http url specified". These helpers
# recognize that exact error class anywhere it surfaces (send_* probes,
# getFile validation) so delivery can self-recover from the source channel
# instead of failing.
_WRONG_FILE_ID_MARKERS = (
    "wrong file identifier",          # the production signature
    "http url specified",             # ".../http url specified" (same error)
    "wrong remote file identifier",   # related Telegram variant
    "invalid file_id",                # defensive variant
)



# In-process memo of getFile probe results (file_id -> 'valid'|'invalid').
# Bounded by the number of distinct stored file_ids (~#indexed files).
_FILE_ID_PROBE_CACHE: Dict[str, str] = {}



# ============================================================
# GLOBAL STATE
# ============================================================
db: Optional[Database] = None

# (rate_limiter is instantiated by namespace.py AFTER the RateLimiter
# class is rebuilt against the shared namespace — see _ASSEMBLE_LATE.)

auto_reindex_task: Optional[asyncio.Task] = None

broadcast_scheduler_task: Optional[asyncio.Task] = None

cleanup_task: Optional[asyncio.Task] = None

startup_reindex_task: Optional[asyncio.Task] = None


# BOT6: GLOBAL indexing lock — only ONE indexing operation may run at a time
# across ALL channels (spec: "Only one indexing operation may run at once").
# The per-channel channel_reindex_lock below is retained as a secondary guard.
# INDEX_GLOBAL_LOCK is created in post_init (asyncio.Lock must be created in a
# running loop). Before post_init runs it is None; indexing helpers check.
INDEX_GLOBAL_LOCK: Optional[asyncio.Lock] = None



# Issue 3 Critical Fix: per-channel reindex lock. Prevents duplicate reindex
# workers from running on the same channel simultaneously. Only ONE reindex
# worker per channel at any time.
channel_reindex_lock: Dict[int, bool] = {}



# ============================================================
# PHASE 7 (Task 1): index cancellation registry + run-summary persistence
# ============================================================
# A scan checks _INDEX_CANCEL_FLAGS each iteration; the Storage Center's
# Index Status panel exposes a Stop button. Stop is GRACEFUL: the loop
# breaks at the next message boundary, the incremental cursor is updated to
# the furthest scanned message, the batch queue is flushed, and the run
# summary is persisted — a restart (or pressing Reindex again) resumes from
# the cursor, never re-scanning from scratch and never losing progress.
# ============================================================
_INDEX_CANCEL_FLAGS: Set[int] = set()

INDEX_RUN_STATS_KEY = "index_last_run:{channel_id}"



# ============================================================================
# PHASE 8 (§6): DURABLE INDEX JOB STATE (bot_settings KV, one JSON blob per
# channel). Persisted every JOB_PERSIST_EVERY messages + at every flush
# boundary + at completion, so an interrupted scan (bot restart, admin stop,
# crash) RESUMES from its exact position instead of restarting from zero.
# ============================================================================
INDEX_JOB_KEY = "index_job:{channel_id}"

INDEX_VERIFY_KEY = "index_verify:{channel_id}"



# ============================================================
# ISSUE 7: REQUEST-TO-JOIN POLICY SWITCH (in-memory cache)
# ============================================================
# Two policies for Request-to-Join channels:
#   "request"  -> ChatJoinRequest grants access immediately (admin approval NOT required)
#   "approval" -> user must be an actual member (admin must approve)

# BOTV13 Phase 3: Progressive Force Join modes.

# In-memory timestamped cache: (user_id, channel_id) -> timestamp of join request.
# NOT persisted to DB. Lost on bot restart (handled gracefully).
PENDING_JOIN_REQUESTS: Dict[Tuple[int, int], float] = {}


# PHASE 6 §11: Verify-button debounce — (user_id) -> monotonic timestamp of
# the last accepted Verify tap. A fresh authoritative get_chat_member check
# runs on every ACCEPTED tap; rapid double-taps (double-click / Telegram
# re-delivery) are debounced so the bot never hammers Telegram.
FJ_VERIFY_DEBOUNCE_SECONDS: float = 2.0

_FJ_VERIFY_LAST_TAP: Dict[int, float] = {}



# All wizard / awaiting states that can be set in context.user_data.
# Opening a new panel must clear these to prevent stale wizard state.
ALL_WIZARD_STATES: List[str] = [
    "awaiting_single_msgid", "awaiting_search_msgid",
    "awaiting_range_start", "awaiting_range_end",
    "awaiting_fwd_range_first", "awaiting_fwd_range_last",
    "awaiting_fwd_batch",
    "awaiting_start_text", "awaiting_start_buttons", "awaiting_media",
    "awaiting_broadcast", "awaiting_create_payload", "awaiting_find_payload",
    "awaiting_payload_rename", "awaiting_storage_add", "awaiting_file_search",
    "awaiting_dm_single", "awaiting_dm_coll", "awaiting_dm_buttons",
    "awaiting_admin_add",
    "awaiting_fj_batch_size",
    "awaiting_custom_timer",
    "awaiting_password",
    # Watch Ads admin: Monetag SDK / Mini App URL text inputs (same
    # stale-state hazard class — any navigation away must purge them).
    "awaiting_wad_sdk", "awaiting_wad_url",
    # v36 §18A: Website Monetag SDK (website_monetag_ad_tag) text input.
    "awaiting_wsdk",
    # Task 9: Video Pre-Roll Ads URL text inputs (wspr: panel).
    "awaiting_wspr_src",
    "awaiting_wspr_vast",
    # Issue 25: Force-Join wizard states.
    "awaiting_fj_add", "awaiting_fj_edit", "awaiting_fj_remove",
    # Issue #63: Force Join text/media editors.
    "awaiting_fj_editjoin", "awaiting_fj_editverify", "awaiting_fj_editchanbtn",
    "awaiting_fj_media",
    # Issue #48: Reindex From File wizard state.
    "awaiting_reidx_fromfile",
    # Issue #84: Retrieve message text/button editors (branding wizards removed).
    "awaiting_retrieve_text", "awaiting_retrieve_button",
    "awaiting_retrieve_limit", "awaiting_retrieve_window",
    # Issue #94: Referral Gate required referrals editor.
    "awaiting_refgate_req",
    # Access Engine V1: referral editors (custom required, preview media/desc).
    "awaiting_refgate_reqcustom",
    "awaiting_refgate_prevmedia",
    "awaiting_refgate_prevdesc",
    # Access Engine V1: Payload Creation Wizard (entire state dict).
    "pcw",
    # V10: Dashboard Editor text input state + category + preview tracking.
    "dash_edit_key",
    "dash_edit_category",
    "dash_edit_template",  # V11: single-template editor awaiting flag
    "dashboard_draft",  # legacy draft (auto-save mode no longer uses it)
    "dash_preview_msg_id",
    "dash_media_upload",  # V14: dashboard banner upload awaiting flag
    # WEBSITE PHASE 3: Add Website Payload wizard state + per-listing
    # editors (title/description/tags/position/thumbnail/base URL).
    "wsite_wizard",
    "wsite_edit",
    # V26 FINAL (Part 9): the package multi-selection state — purged on
    # any panel navigation like every other wizard state.
    "wsite_pkg_pick",
    # GAP-CLOSURE: Website CATEGORY wizard/editor states (wsitecat:) +
    # ADS campaign/creative wizard + campaign/exempt editor states
    # (wsad:) — cleared on any panel navigation like every other state.
    "wsitecat_wizard",
    "wsitecat_edit",
    "wsad_wizard",
    "wsad_edit",
]


# Issue 25: Force-Join wizard idle timeout (seconds). If the admin doesn't
# send input within this window the wizard auto-cancels (no stale state).
FORCE_JOIN_WIZARD_TIMEOUT: int = 300  # 5 minutes


# ============================================================
# v36 — CONVERSATION INPUT STATE HYGIENE (final production fix)
#
# ROOT CAUSE of the live bot-6.log FDB failure: text-input
# conversation states (ctl_fdb_state / ctl_create_state /
# ncreate_state / net_reg_state / ctl_rotate_state) were NEVER
# cleared when the admin navigated to another panel, so a stale
# "await_owner" state from an earlier ctl:managed:create HIJACKED
# the File Delivery Bot token ("Send the OWNER's numeric Telegram
# user id") and a stale ncreate "await_token" state consumed the
# token itself (NETWORK_BOT_REGISTER_FAILED encryption_key_missing).
#
# Fix: ONE list, ONE purge function, invoked from on_callback for
# every callback that is not itself an input-entry callback (those
# re-set their state AFTER the purge, inside their dispatcher),
# plus a single-active-conversation guard in text_handler.
# ============================================================

CONVERSATION_INPUT_STATE_KEYS: List[str] = [
    "ctl_fdb_state",        # control_ui: FDB token add/change
    "ctl_rotate_state",     # control_ui: managed bot credential rotation
    "ctl_create_state",     # control_ui: managed bot create (owner+token)
    "ncreate_state",        # delivery_ui: Create Network Bot wizard
    "net_reg_state",        # network_ui: Add Existing Bot wizard
    "awaiting_wad_sdk",     # watchads admin: Monetag TMA SDK
    "awaiting_wad_url",     # watchads admin: Mini App URL
    "awaiting_wsdk",        # v36 §18A: Website Monetag SDK
    "awaiting_wspr_src",    # Task 9: pre-roll ad source URL
    "awaiting_wspr_vast",   # Task 9: pre-roll VAST/VMAP URL (future hook)
    # MANAGED BOTS v37 (Task 8): the managed-bot creation pending state
    # (reply-keyboard request flow — app/network/managed_bots.py owns the
    # key string) and the ADMIN-ONLY legacy manual token import state
    # (delivery_ui nleg:). Distinct keys so the two flows can NEVER
    # consume each other's inputs or hijack other flows.
    "nmg_pending",           # managed_bots: await_managed_bot (10-min TTL)
    "nleg_state",            # delivery_ui: LEGACY admin token import
]

# Input states that hold SECRETS — purged with priority logging-free
# handling (never log contents).
CONVERSATION_SECRET_STATE_KEYS = (
    "ctl_fdb_state", "ctl_rotate_state", "ncreate_state", "net_reg_state",
)

# Callbacks that SET or READ one of the states above DURING their
# dispatch — the purge must run BEFORE them so their fresh state
# survives (they run after on_callback's purge). Everything else
# (every panel navigation, every Back, every Cancel) purges.
CONVERSATION_INPUT_ENTRY_EXEMPT: tuple = (
    "nreg:token",           # -> sets net_reg await_token
    "nreg:consent",         # -> READS token/owner to complete registration
    # A.5 (bot-25): both CONFIRMATION callbacks READ the token already
    # held in net_reg_state — the v36 master purge was destroying their
    # own state right before the handler read it ("The reactivation
    # window has closed" / "The confirmation window has closed" on
    # EVERY immediate confirmation). They arm nothing new; the durable
    # token intent is already retired (reactivate) / updated
    # (changeconfirm) by the flow that rendered the buttons.
    "nreg:reactivate",      # -> READS the held token (duplicate-bot
                            #    recovery confirmation)
    "nreg:changeconfirm",   # -> READS the held change-token (identity
                            #    replacement confirmation)
    "ncreate:token",        # -> pre-v37 wizard entry (replayed button
                            #    history lands on the managed begin flow)
    "ctl:fdb:add",          # -> sets ctl_fdb await_token
    "ctl:fdb:change",       # -> sets ctl_fdb await_token (change mode)
    "ctl:managed:create",   # -> sets ctl_create await_owner
    "nleg:token",           # v37 Task 8: sets the LEGACY import
                            #    await_token (admin-only namespace)
    # NOTE (A.5): nreg:changecancel and nreg:back are deliberately NOT
    # exempt — those exits intentionally clear the state.
)
CONVERSATION_INPUT_ENTRY_EXEMPT_PREFIXES = (
    "ctl:managed:rotate:",  # -> sets ctl_rotate await_token:<nid>
)

# Idle timeout for secret-input conversations (seconds). A state older
# than this is dropped on the next text message with an honest notice.
CONVERSATION_INPUT_TIMEOUT_SECONDS: float = 600.0


def _is_conversation_input_entry(data: str) -> bool:
    """True when this callback is the ENTRY POINT of an input flow —
    on_callback must NOT purge the state it is about to set/read."""
    if not data:
        return False
    if data in CONVERSATION_INPUT_ENTRY_EXEMPT:
        return True
    return any(data.startswith(p)
               for p in CONVERSATION_INPUT_ENTRY_EXEMPT_PREFIXES)


def clear_conversation_input_states(context) -> List[str]:
    """Purge every pending text-input conversation state (v36 root fix).

    Returns the list of purged keys (for diagnostics/tests). Never logs
    or inspects state contents — several hold secrets."""
    purged: List[str] = []
    for key in CONVERSATION_INPUT_STATE_KEYS:
        if context is not None and context.user_data.pop(key, None) is not None:
            purged.append(key)
    return purged


def _conversation_state_expired(state, now: Optional[float] = None) -> bool:
    """True when an input state's 'ts' stamp is older than the timeout
    (states without a stamp never expire — legacy mid-flow safety)."""
    try:
        ts = float((state or {}).get("ts") or 0)
    except (TypeError, ValueError):
        return False
    if ts <= 0:
        return False
    return (now if now is not None else time.time()) - ts \
        > CONVERSATION_INPUT_TIMEOUT_SECONDS


def reconcile_conversation_input_states(context) -> Optional[str]:
    """Single-active-conversation guard (defense in depth).

    If more than one conversation input state is somehow active at text
    time (e.g. stale states persisted across a mid-version upgrade),
    keep ONLY the most recently started one and purge the rest. Also
    drops states older than CONVERSATION_INPUT_TIMEOUT_SECONDS.
    Returns the surviving key (or None)."""
    if context is None:
        return None
    active = {}
    for key in CONVERSATION_INPUT_STATE_KEYS:
        st = context.user_data.get(key)
        if st is None:
            continue
        if _conversation_state_expired(st):
            context.user_data.pop(key, None)
            continue
        active[key] = st
    if not active:
        return None
    if len(active) == 1:
        return next(iter(active))
    newest_key = max(
        active, key=lambda k: float((active[k] or {}).get("ts") or 0))
    for key in list(active):
        if key != newest_key:
            context.user_data.pop(key, None)
    return newest_key


def stamp_conversation_state(state: Optional[dict]) -> Optional[dict]:
    """Attach the 'ts' freshness stamp to an input state (used by every
    state-creation point in control_ui / delivery_ui / network_ui)."""
    if isinstance(state, dict):
        state["ts"] = time.time()
    return state


# ============================================================
# b10 §1 (B10-B2): DURABLE TOKEN-INPUT INTENT (per-user, in-process).
# ------------------------------------------------------------
# ROOT CAUSE (bot-10.log): the "Add Existing Bot" token-input state
# (net_reg_state in context.user_data) is purged by ANY unrelated
# callback navigation (the v36 hygiene purge — a deliberate,
# STAYING root fix for the bot-6.log token-hijack class), while the
# "Send the Bot Token" prompt the user is still reading survives in
# the chat. The user pastes the token → no state → the generic admin
# fallback reply → the token is never processed and NO BOT_TOKEN_*
# stage log exists anywhere.
#
# FIX (the robust combination, spec §1):
#   * the INPUT INTENT now lives in this process-level per-user record
#     that SURVIVES unrelated callback navigation (the v36 purge only
#     clears context.user_data keys — it never touches this registry);
#     ONLY the token text handler (consumed — accepted exactly once),
#     an explicit Back/Cancel of the SAME flow, a newer input flow
#     (single-active-conversation discipline), or the 10-minute TTL
#     clears it;
#   * the token text handler accepts a token ONLY when this intent is
#     present — a pasted token with NO intent is never registered and
#     never falls through to the generic admin fallback (honest notice,
#     token never echoed);
#   * a token-shaped paste is accepted exactly once: the intent is
#     consumed on the DEFINITIVE outcomes (registered / duplicate /
#     limit / consent hand-over). Transient outcomes (invalid token,
#     Telegram unreachable) KEEP the intent so the user can retry.
#
# SECURITY: the record NEVER contains token material — only the flow
# name, the prompt location (for best-effort stale-prompt cleanup) and
# the freshness stamp. Stage logs log user_id/flow/length — NEVER the
# token.
# ============================================================
TOKEN_INTENT_TTL_SECONDS: float = CONVERSATION_INPUT_TIMEOUT_SECONDS

# The flows that may own the intent (each has its own prompt + text
# handler; the intent identifies WHICH handler a pasted token belongs
# to — the single-active-conversation rule, made durable).
TOKEN_INTENT_FLOWS = ("net_reg", "nleg", "net_change")  # b11 §6: the change-token flow (B11-D2)

_pending_token_intents: Dict[int, Dict[str, Any]] = {}


def _token_intent_expired(intent: Optional[dict],
                          now: Optional[float] = None) -> bool:
    """True when the intent's stamp is older than the 10-minute TTL
    (unstamped records never expire — legacy mid-flow safety)."""
    try:
        ts = float((intent or {}).get("ts") or 0)
    except (TypeError, ValueError):
        return False
    if ts <= 0:
        return False
    return (now if now is not None else time.time()) - ts \
        > TOKEN_INTENT_TTL_SECONDS


def set_pending_token_intent(user_id: int, flow: str, *,
                             chat_id: Optional[int] = None,
                             message_id: Optional[int] = None,
                             step: str = "await_token") -> Optional[dict]:
    """Arm the durable token-input intent for ONE user (b10 §1).

    Re-arming (re-opening the token prompt) replaces any previous
    intent — the single-active-conversation discipline. Logs
    BOT_TOKEN_INPUT_STARTED (never the token)."""
    try:
        uid = int(user_id or 0)
    except (TypeError, ValueError):
        return None
    if uid <= 0 or flow not in TOKEN_INTENT_FLOWS:
        return None
    intent = {
        "flow": str(flow),
        "step": str(step or "await_token"),
        "chat_id": int(chat_id) if chat_id is not None else None,
        "message_id": int(message_id) if message_id is not None else None,
        "ts": time.time(),
    }
    _pending_token_intents[uid] = intent
    logger.info("BOT_TOKEN_INPUT_STARTED user_id=%s flow=%s ttl=%ss "
                "(token input armed; the token itself is NEVER logged)",
                uid, intent["flow"], int(TOKEN_INTENT_TTL_SECONDS))
    return intent


def get_pending_token_intent(user_id: int) -> Optional[dict]:
    """The live token-input intent for this user (expired records are
    dropped and answered None — never token material)."""
    try:
        uid = int(user_id or 0)
    except (TypeError, ValueError):
        return None
    intent = _pending_token_intents.get(uid)
    if intent is None:
        return None
    if _token_intent_expired(intent):
        _pending_token_intents.pop(uid, None)
        logger.info("BOT_TOKEN_INPUT_EXPIRED user_id=%s flow=%s (10 min "
                    "idle timeout — nothing was saved)",
                    uid, intent.get("flow"))
        return None
    return dict(intent)


def update_pending_token_intent(user_id: int, **fields) -> None:
    """Patch live intent fields (e.g. step → await_consent after the
    getMe identity confirmation). No-op for a missing/expired intent."""
    try:
        uid = int(user_id or 0)
    except (TypeError, ValueError):
        return
    intent = _pending_token_intents.get(uid)
    if intent is None or _token_intent_expired(intent):
        return
    for key in ("flow", "step", "chat_id", "message_id"):
        if key in fields and fields[key] is not None:
            intent[key] = fields[key]
    intent["ts"] = time.time()


def consume_pending_token_intent(user_id: int) -> Optional[dict]:
    """Pop and return the live intent (the 'accept exactly once'
    primitive — called on the DEFINITIVE outcomes only)."""
    try:
        uid = int(user_id or 0)
    except (TypeError, ValueError):
        return None
    intent = _pending_token_intents.pop(uid, None)
    if intent is not None and _token_intent_expired(intent):
        return None
    return intent


def clear_pending_token_intent(user_id: int) -> Optional[dict]:
    """Explicit clear (Back/Cancel/newer input flow). Returns the intent
    that was cleared (for the best-effort stale-prompt cleanup) or
    None. Never raises, never logs token material."""
    try:
        uid = int(user_id or 0)
    except (TypeError, ValueError):
        return None
    return _pending_token_intents.pop(uid, None)


def token_input_intent_active(user_id: int) -> bool:
    """Convenience predicate (never token material)."""
    return get_pending_token_intent(user_id) is not None


# ---- v36 admin navigation ORIGIN (spec §4: explicit parent panels) ---
# The user-facing network wizards (ncreate / dg) are reachable BOTH from
# "My Network" (user surface) and from the admin Network Control panel.
# Back must return to the surface the wizard was opened from — the
# origin is remembered per-user (NOT in the static callback data).
NET_WIZARD_ORIGIN_KEY = "_net_wizard_origin"


def set_net_wizard_origin(context, origin: str) -> None:
    """Record the panel a network wizard was opened from ("" = user
    surface default: My Network)."""
    try:
        context.user_data[NET_WIZARD_ORIGIN_KEY] = str(origin or "")
    except Exception:  # noqa: BLE001
        pass


def get_net_wizard_origin(context) -> str:
    """The recorded wizard origin ("" when opened from the user surface)."""
    try:
        return str(context.user_data.get(NET_WIZARD_ORIGIN_KEY) or "")
    except Exception:  # noqa: BLE001
        return ""


def clear_net_wizard_origin(context) -> None:
    try:
        context.user_data.pop(NET_WIZARD_ORIGIN_KEY, None)
    except Exception:  # noqa: BLE001
        pass



# ============================================================
# PROTECTION ENGINE V3 — Simplified, impossible to misconfigure
# ============================================================
# Issue #41: V2 had too many route-specific toggles (Protect Albums, Protect
# Browse, Protect Download All, Protect Admin Preview) that exposed internal
# delivery implementation details and created conflicting states.
#
# V3 has ONE protection toggle. When ON, ALL delivery paths are protected
# automatically. No route-specific switches. No conflicts.
#
# Hide Internal References is ALWAYS enabled (not configurable) — users must
# NEVER see storage channel IDs, source IDs, message IDs, etc.
#
# Simple enough that any admin immediately understands:
#   1. Protection (ON/OFF — applies to everything)
#   2. Hide Source (ON/OFF — hide channel names/usernames)
#   3. Auto Delete (global timer)
# ============================================================

# V3 protection keys (simplified — Issue #42: Forward Blocking + Issue #43: Internal Bot Messages)
PROTECTION_V3_KEYS: List[str] = [
    "forward_blocking",       # Issue #42: protect_content for delivered files
    "internal_bot_messages",  # Issue #43: protect_content for bot-generated messages
    "hide_source",            # Hide source channel names/usernames
]


# Advanced-only keys (hidden from normal workflow)
PROTECTION_V3_ADVANCED_KEYS: List[str] = [
    "watermark",
    "anti_leech",
    "one_time_default",
    "preview_protection",
    "debug_logging",
]


PROTECTION_V3_DEFAULTS: Dict[str, bool] = {
    "forward_blocking":      True,
    "internal_bot_messages": True,
    "hide_source":           True,
    "watermark":             False,
    "anti_leech":            True,
    "one_time_default":      False,
    "preview_protection":    True,
    "debug_logging":         False,
}


# Auto-delete presets (seconds). 0 = OFF.
AUTO_DELETE_PRESETS: List[int] = [0, 10, 20, 30, 60, 300]



# ============================================================
# BOT5 CLEAN TIMER SEPARATION — three explicitly-named resolvers
# ============================================================
GLOBAL_PREVIEW_TIMER_DEFAULT: int = 20



# ============================================================
# FORCE-JOIN VERIFICATION  (BOT6 — authoritative membership engine)
# ============================================================
# BOT6 redesign: every Telegram API failure mode is classified into a DISTINCT
# semantic result. The old is_member() collapsed Forbidden / BadRequest
# "Member list is inaccessible" / "Chat not found" / generic TelegramError
# into a single False ("not member"), which produced the misleading user UX
# the operator repeatedly reported ("Bot not admin" surfaced as "please join").
#
# check_membership() is the AUTHORITATIVE primitive. is_member() is retained
# as a thin bool wrapper for legacy callers, but the Access Engine and the FJ
# UI now consume the rich MemberCheckResult so they can render the CORRECT
# diagnostic ("Bot is not admin" vs "You have not joined").
from enum import Enum



# ============================================================================
# PHASE 8 (§11-§18): FORCE-JOIN INVITE-LINK HEALTH SERVICE WIRING
# ============================================================================
# The standalone engine lives in app/core/fj_link_health.py; these wrappers
# connect it to this bot's DB + settings. The service adds what the channel
# classifier could never see:
#   * the LINK ITSELF is verified (get_chat_invite_link): expired / revoked /
#     belongs-to-another-chat detection — production users were being shown
#     dead Join buttons while the channel was perfectly healthy;
#   * a TTL health cache (spec §18) so per-user Join screens do not hammer
#     the Telegram API;
#   * persisted health state (force_join_channels.link_health, v28) so the
#     admin panels and startup report show REAL states instead of repeating
#     raw 'Chat not found' warnings.
# ============================================================================
_FJ_LINK_HEALTH_CACHE = _fj_health.LinkHealthCache()



# (old build_force_join_keyboard removed — replaced by the safe version above)


# ============================================================
# AUTO DELETE SYSTEM  (Issue 34: persistent — survives restart)
# ============================================================
# Every scheduled deletion is stored in the pending_deletions DB table so the
# bot can recover after restart/crash/VPS reboot. The asyncio task is still
# created for immediate in-memory timing, but the DB row is the source of truth.
# On startup, due rows are deleted immediately; upcoming rows are re-scheduled.

# Deletion type constants.
DELETION_TYPE_DELIVERY = "delivery"

DELETION_TYPE_BROWSE = "browse"

DELETION_TYPE_ADMIN_PREVIEW = "admin_preview"

DELETION_TYPE_STATUS = "status"


# In-memory tracker of scheduled deletion tasks (for cancellation). Maps
# (chat_id, message_id) -> asyncio.Task. Cleared on restart (DB is the truth).
_pending_deletion_tasks: Dict[Tuple[int, int], asyncio.Task] = {}


# ============================================================
# BOT-45/46 (Task B — v47) — AUTO DELETE CONSISTENCY CONSTANTS
# ============================================================
# Root cause (production.log 170/171 sweeps): a failed Telegram delete
# (timeout / DNS / network) was settled SILENTLY — the pending_deletions
# row was removed and the message leaked with no retry. The delete is now
# CLASSIFIED (ok / retry / permanent) and a transient failure keeps the
# row PENDING with a BOUNDED exponential backoff recorded durably on the
# row itself (pending_deletions.attempts / .last_error, schema v47):
#   * attempts       — bounded retry counter (0 = never failed);
#   * last_error     — the CLASSIFIED reason token of the most recent
#                      failure (never a raw exception, never a secret);
#   * backoff        — AUTO_DELETE_RETRY_BASE_DELAY * 2^attempts, capped
#                      by AUTO_DELETE_RETRY_MAX_DELAY;
#   * give-up        — after AUTO_DELETE_MAX_ATTEMPTS failed attempts the
#                      row is given up (AUTO_DELETE_GAVE_UP) so a dead
#                      target can never spin forever.
# Deterministic rejections (message already gone → idempotent success;
# invalid chat / other BadRequest / Forbidden → give up immediately) are
# NEVER retried — they cannot succeed. These constants live in the
# namespace foundation so the REBOUND deletion-section functions resolve
# them through the shared globals.
AUTO_DELETE_MAX_ATTEMPTS = 5      # total delete attempts before give-up

AUTO_DELETE_RETRY_BASE_DELAY = 60  # seconds; doubles per failed attempt

AUTO_DELETE_RETRY_MAX_DELAY = 3600  # backoff cap (1 hour)


# BOTV13: Dashboard banner message tracking (in-memory, no DB schema change).
# Maps (payload_id, user_id) -> banner_message_id. Ensures the previous
# decorative banner is deleted before a new one is sent, preventing banner
# accumulation when a user opens the referral dashboard multiple times.
_dashboard_banner_msgs: Dict[Tuple[int, int], Tuple[int, int]] = {}


# BOTV13 Fix: Per-referral dedup locks. Maps (campaign_id, inviter_user_id,
# referred_user_id) -> asyncio.Lock. Acquired in qualify_referral BEFORE the
# is_already_referred SELECT and held until qualify_referral_atomic returns.
# Closes the TOCTOU race where two concurrent /start ref_<token> clicks for the
# same referred user both pass the SELECT checks and both attempt the INSERT.
# The ON CONFLICT DO NOTHING in qualify_referral_atomic is the DB-level backstop,
# but this lock prevents the duplicate side-effects (notifications, auto-deliver,
# analytics) that fire outside the atomic block.
_referral_dedup_locks: Dict[Tuple[int, int, int], asyncio.Lock] = {}

_referral_dedup_locks_guard = asyncio.Lock()


# BOT6 P7: in-memory tracker of the canonical Force-Join user message per
# (chat_id, user_id). When the user clicks Verify, enforce_access re-renders
# the FJ page; without this tracker, every Verify creates a NEW message. With
# it, send_force_join_page receives edit_message_id and EDITS the existing
# message in place (same message_id across 0/3 → 1/3 → 2/3 → 3/3). Only
# recreated if Telegram confirms the original is gone.
_fj_user_messages: Dict[Tuple[int, int], int] = {}



# BOT6 FJ Message Lifecycle Decision Engine
# Determines whether to CREATE or EDIT the FJ user message based on the event
# source (fresh /start vs Verify callback from the current FJ message).
# This is SEPARATE from the authorization engine — it only decides the UI
# message lifecycle, not ALLOW/DENY or which channels are required.

# Event source constants for the FJ message decision.
FJ_EVENT_START = "START"          # fresh /start payload open

FJ_EVENT_VERIFY = "VERIFY"        # Verify callback from the FJ message

FJ_EVENT_REFRESH = "REFRESH"      # refresh/re-check from a non-FJ callback



# Issue 6: Browse Files silent auto-delete window (seconds). No notice,
# no countdown — the browse message simply disappears after this delay.
# Issue 7: Admin preview silent auto-delete window (seconds).
ADMIN_PREVIEW_AUTO_DELETE_DELAY: int = 20



# ============================================================
# V9 — DASHBOARD CONTROLLER (single sender / single updater)
# ============================================================
# THE single controller for the referral dashboard message lifecycle.
# No other function may construct dashboard text, send the dashboard, or edit
# the dashboard. All flows MUST call these helpers:
#
#   dashboard_send(...)   — initial send (media+caption OR text), persists mode
#   dashboard_update(...) — mode-aware edit (editMessageCaption vs editMessageText)
#   dashboard_delete(...) — delete the stored dashboard message
#
# dashboard_mode is persisted in payload_unlocks:
#   'TEXT'    → standalone text message → editMessageText
#   'CAPTION' → media caption           → editMessageCaption
#
# This PREVENTS the "There is no text in the message to edit" BadRequest that
# occurs when editMessageText is called on a media message (or vice versa).
# =====================================================================
DASHBOARD_MODE_TEXT = "TEXT"

DASHBOARD_MODE_CAPTION = "CAPTION"





# ============================================================
# ISSUE #49/#50/#53: RETRIEVE SYSTEM + RECOVERY CARDS
# ============================================================
# After files auto-delete, a persistent recovery card remains with a
# "Retrieve" button. The card stores a delivery_record ID (not Telegram
# message IDs) so delivery can be rebuilt from the source of truth.
# ============================================================



# ============================================================
# ISSUE #84: CENTRALIZED RETRIEVE MESSAGE RENDERER
# ============================================================
# One unified retrieve system. The retrieve message is attached to the actual
# delivered content using Telegram's native reply system (reply_to_message_id),
# replacing the old standalone branding card. All delivery paths MUST call this
# function — no custom implementations allowed.
#
# Text + button label are admin-configurable (Retrieve Settings panel).
# Default text:
#   ⏰ Files sent by the bot will be deleted after 20 seconds.
#   ✅ Save or forward files before deletion.
# Default button: 📥 Retrieve Media
#
# The message is NEVER included in auto-delete schedules. It persists until the
# retrieve limit/window is exhausted or the record is deleted.
# ============================================================

# Default retrieve message text (seeded into bot_settings on first run).
DEFAULT_RETRIEVE_BUTTON = "\U0001F4E5 Retrieve Media"



DEFAULT_RETURNING_WELCOME = "\U0001F44B Welcome back! Open a delivery link to get your file."



# ============================================================
# /help  (BOT6 Phase 25-27: user-facing guide + admin-configurable)
# ============================================================
# The OLD /help was admin-only and dumped the internal command catalog to
# anyone who passed the admin check. BOT6 replaces it with a proper user guide
# that is shown to EVERYONE (users + admins). The admin command list is no
# longer exposed to users; admins manage the bot via the Dashboard UI.
# The guide text is admin-configurable via the 📚 Help / User Guide panel and
# persisted in the help_message table (mirrors start_message).

DEFAULT_HELP_TEXT = (
    "\U0001F4DA HOW TO USE THIS BOT\n\n"
    "\U0001F517 Open the payload link\n"
    "Tap a delivery link (https://t.me/{username}?start=<payload>) to open a payload.\n\n"
    "\U0001F510 Join required channels\n"
    "If the bot asks you to join channels, join ALL of them.\n"
    "You can see which ones are joined (\u2705) and which are pending (\U0001F512).\n\n"
    "\u2705 Verify membership\n"
    "After joining, press \U0001F504 VERIFY MEMBERSHIP. The bot checks live.\n\n"
    "\U0001F4E6 Receive files\n"
    "Once verified, your files are delivered automatically.\n\n"
    "\u23F1 Automatic deletion\n"
    "Delivered files are deleted after a short timer to protect content.\n"
    "Save or forward files before the timer expires.\n\n"
    "\U0001F504 Retrieve previously delivered payloads\n"
    "Use /recent to re-receive a payload delivered in the last 24 hours.\n"
    "(Max 4, re-checked against current access rules.)\n\n"
    "\U0001F3AC Watch Preview\n"
    "Some payloads show a preview before unlock — tap Watch Preview to see it.\n\n"
    "\u2753 Troubleshooting\n"
    "If Verify keeps failing, make sure you joined EVERY required channel\n"
    "(check the \u2705 / \U0001F512 list). If a channel shows \u26A0\uFE0F, the bot may not\n"
    "be admin there — ask the channel admin to fix it."
).replace("{username}", BOT_USERNAME or "your_bot")



# PHASE 7 (Task 1): flush threshold for batched index inserts. The queue is
# flushed when it reaches this size (or at scan end / stop) — each flush is
# one short BEGIN IMMEDIATE + executemany + COMMIT under the DB write lock.
INDEX_BATCH_FLUSH_SIZE = 50



# ============================================================
# MULTI-FILE FORWARD BATCH PROCESSING
# ============================================================
# Time to wait after the last forwarded message before finalizing a batch.
# Resets on every new forward so slightly-delayed arrivals are all captured.
FORWARD_BATCH_FINALIZE_WAIT: float = FORWARD_BATCH_WAIT * 2



# ============================================================
# INLINE ADMIN PANEL  (main menu + sub-panels)
# ============================================================
# ============================================================
# BOTV13 PHASE 2: MULTI-ADMIN PERMISSION SYSTEM
# ============================================================
# Permission constants. The owner (first ADMIN_IDS entry) always has full
# access. Additional admins are stored in the `admins` table with a JSON
# permissions string. Every protected callback checks `has_permission`.
# Security rules:
#   - The owner cannot be removed, disabled, or have permissions reduced.
#   - An admin cannot grant themselves permissions they don't have.
#   - An admin cannot grant another user higher permissions than they possess.
#   - Every permission check is server-side (never rely on hiding buttons).
# ============================================================

PERM_PAYLOAD_VIEW = "payload.view"

PERM_PAYLOAD_CREATE = "payload.create"

PERM_PAYLOAD_EDIT = "payload.edit"

PERM_PAYLOAD_RENAME = "payload.rename"

PERM_PAYLOAD_DELETE = "payload.delete"

PERM_PAYLOAD_TOGGLE = "payload.toggle"

PERM_COLLECTION_VIEW = "collection.view"

PERM_COLLECTION_CREATE = "collection.create"

PERM_COLLECTION_EDIT = "collection.edit"

PERM_COLLECTION_DELETE = "collection.delete"

PERM_FJ_VIEW = "access.force_join.view"

PERM_FJ_EDIT = "access.force_join.edit"

PERM_REFERRAL_SETTINGS = "access.referral.settings"

PERM_PREVIEW_SETTINGS = "content.preview.settings"

PERM_DELIVERY_SETTINGS = "content.delivery.settings"

PERM_CHANNEL_MANAGE = "content.channel.manage"

PERM_ANALYTICS_VIEW = "analytics.view"

PERM_REFERRAL_ANALYTICS = "analytics.referral"

PERM_MANAGE_ADMINS = "admin.manage_admins"

PERM_MANAGE_PERMISSIONS = "admin.manage_permissions"

PERM_BOT_SETTINGS = "admin.bot_settings"


ALL_PERMISSIONS: List[str] = [
    PERM_PAYLOAD_VIEW, PERM_PAYLOAD_CREATE, PERM_PAYLOAD_EDIT,
    PERM_PAYLOAD_RENAME, PERM_PAYLOAD_DELETE, PERM_PAYLOAD_TOGGLE,
    PERM_COLLECTION_VIEW, PERM_COLLECTION_CREATE, PERM_COLLECTION_EDIT,
    PERM_COLLECTION_DELETE,
    PERM_FJ_VIEW, PERM_FJ_EDIT, PERM_REFERRAL_SETTINGS,
    PERM_PREVIEW_SETTINGS, PERM_DELIVERY_SETTINGS, PERM_CHANNEL_MANAGE,
    PERM_ANALYTICS_VIEW, PERM_REFERRAL_ANALYTICS,
    PERM_MANAGE_ADMINS, PERM_MANAGE_PERMISSIONS, PERM_BOT_SETTINGS,
]


PERMISSION_GROUPS: Dict[str, List[str]] = {
    "Payload": [PERM_PAYLOAD_VIEW, PERM_PAYLOAD_CREATE, PERM_PAYLOAD_EDIT,
                PERM_PAYLOAD_RENAME, PERM_PAYLOAD_DELETE, PERM_PAYLOAD_TOGGLE],
    "Collections": [PERM_COLLECTION_VIEW, PERM_COLLECTION_CREATE,
                     PERM_COLLECTION_EDIT, PERM_COLLECTION_DELETE],
    "Access": [PERM_FJ_VIEW, PERM_FJ_EDIT, PERM_REFERRAL_SETTINGS],
    "Content": [PERM_PREVIEW_SETTINGS, PERM_DELIVERY_SETTINGS, PERM_CHANNEL_MANAGE],
    "Analytics": [PERM_ANALYTICS_VIEW, PERM_REFERRAL_ANALYTICS],
    "Administration": [PERM_MANAGE_ADMINS, PERM_MANAGE_PERMISSIONS, PERM_BOT_SETTINGS],
}


# BOT7: sensible read-oriented preset offered when the Owner adds a new admin
# ("Grant Recommended Access"). Deliberately EXCLUDES destructive permissions
# (payload delete/edit, admin management, bot settings) — the owner can still
# grant those individually via the permission editor.
RECOMMENDED_ADMIN_PERMISSIONS: List[str] = [
    PERM_PAYLOAD_VIEW, PERM_PAYLOAD_CREATE,
    PERM_COLLECTION_VIEW,
    PERM_FJ_VIEW,
    PERM_ANALYTICS_VIEW,
]



# ============================================================
# BOTV7.1: REFERRAL DASHBOARD EDITOR
# ============================================================
# Admin panel for customizing the referral dashboard.
# V11: single-template editor — the admin edits ONE template field with
# placeholders. Settings submenu holds only non-template options (caption
# toggle, link preview toggle, progress bar style). Auto-save, no drafts.
# ============================================================

# ============================================================
# V11 — DASHBOARD EDITOR (single template, 4 actions, auto-save)
# ============================================================
# The admin edits ONE template field as a whole — no individual Header /
# Description / Footer fields. Four actions only:
#   ✏️ Edit Dashboard  → prompt for the full template, auto-save, return
#   👁 Live Preview     → render via the production renderer (single message)
#   ⚙️ Settings         → caption toggle, link preview toggle, progress style
#   ♻ Reset to Default  → restore the default template + settings
# Live preview edits a SINGLE message in-place (dash_preview_msg_id).
# ============================================================

# Progress bar styles available in Settings (kept — it's a non-template option).
PROGRESS_BAR_STYLES = [
    ("block", "\u2588\u2588\u2588\u2588\u2591\u2591\u2591\u2591\u2591\u2591  Block"),
    ("square", "\u25A0\u25A0\u25A0\u25A0\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1  Square"),
    ("emoji", "\U0001F7E9\U0001F7E9\U0001F7E9\U0001F7E9\u26AB\u26AB\u26AB\u26AB\u26AB\u26AB  Emoji"),
]



PAYLOADS_PER_PAGE = 10



# ============================================================
# PHASE 7 (Task 3) — SEARCH RESULTS PANEL (paginated, context-preserving)
# ============================================================
# Upgrades the EXISTING Search Payload feature (pl:find) into a real fuzzy
# database search with the SAME pagination design as the Payload Manager:
#   * 10 results per page, ⏮/◀/X/XX/▶/⏭ navigation (first/last rules)
#   * result -> payload detail -> Back returns to THE SAME search result page
#     (plsdetail:<qid>:<pid>:<page> / plsback:<qid>:<page>)
#   * restart-safe: the query is persisted in bot_settings (pl_search:<qid>)
#     so navigation still works after a bot restart (the qid is a crc32 of
#     the query — deterministic, no callback collisions with plpage/plback).
# ============================================================

PL_SEARCH_QUERY_MAX_LEN: int = 120

PL_SEARCH_HISTORY_KEEP: int = 50



# ============================================================
# ACCESS ENGINE V1 — PAYLOAD CREATION WIZARD
# ============================================================
# Replaces the old "create payload, then edit settings" two-step flow with a
# single guided wizard. Everything (name, access policy, referral config,
# preview media, delivery settings) is configured BEFORE the payload row is
# inserted. The payload is production-ready the instant it is created.
#
# Wizard state lives in context.user_data["pcw"] (payload-creation-wizard):
#   {
#     "step": "name"|"file"|"policy"|"referrals"|"watchads"|"preview"|
#             "previewmedia"|"previewdesc"|"delivery"|"confirm",
#     "mode": "create"|"edit",         # edit = editing an existing payload
#     "edit_payload_id": int|None,     # set when mode == "edit"
#     "index_id": int|None,            # pre-selected indexed file (single-file)
#     "collection_msg_ids": list|None, # pre-selected message_ids (collection)
#     "collection_channel_id": int|None, # channel for the collection
#     "collection_code": str|None,     # existing collection code (edit mode)
#     "name": str|None,
#     "access_policy": str,            # default FORCE_JOIN
#     "required_referrals": int,       # default 5 (only for REFERRAL)
#     "watch_ads_enabled": int,        # WATCH_AD (v25): 0/1 default 0
#     "preview_mode": str,             # default disabled
#     "preview_media_file_id": str|None,
#     "preview_media_type": str|None,
#     "preview_description": str|None,
#     "delete_after": int|None,        # None = inherit global
#     "one_time": int,                 # 0/1
#   }
#
# Entry points:
#   pcw:start            — Payload Manager "Create Payload" (no file yet)
#   pcw:startfile:<id>   — from file_detail / recent files (file pre-selected)
#   pcw:startcollection:<chan>:<id1>,<id2>,... — multi-file forward (collection)
#   pcw:edit:<pid>       — edit an existing payload (preload all values)
#   pcw:cancel           — abort + return to Payload Manager
# ============================================================

PCW_KEY = "pcw"  # context.user_data key for the wizard state


# Steps in display order (6-step wizard; "file" is an auxiliary sub-step
# reached only when no file/collection is pre-selected). Delivery is NOT a
# standalone step — it lives as the "Advanced Delivery" overlay opened from
# the Review/Confirm page. WATCH_AD (v25) adds the "watchads" step (Step 4)
# between referrals and preview; the payload is created with the Watch Ads
# configuration already applied.
PCW_STEPS = ("name", "policy", "referrals", "watchads", "preview", "confirm")

PCW_TOTAL_STEPS = 6


# Maps a step name to its 1-based display number (for "Step X/6").
PCW_STEP_NUMBER: Dict[str, int] = {
    "name": 1, "file": 1, "policy": 2, "referrals": 3, "watchads": 4,
    "preview": 5, "confirm": 6,
    "advdelivery": 6,  # advanced delivery overlay (sub-step of confirm)
    "prevselect": 5,   # preview selector overlay (sub-step of preview)
}



# ============================================================
# V15 — NAVIGATION CONTEXT (single source for "return to")
# ============================================================
# Tracks where the user came from so every submenu's Back/Cancel returns to
# the SAME originating page. The Payload Details page is the primary origin.
# Stored in context.user_data["nav_ctx"] = {"origin": ..., "payload_id": ...}
# ============================================================
NAV_KEY = "nav_ctx"



# Wizard-related awaiting_* flags that must be cleared after a successful
# create so no stale prompt (e.g. "Custom Required Referrals") can intercept
# the admin's next message.
_PCW_AWAITING_FLAGS = (
    "awaiting_refgate_req",
    "awaiting_refgate_reqcustom",
    "awaiting_refgate_prevmedia",
    "awaiting_refgate_prevdesc",
    "colsum_msg_ids",
    "colsum_channel_id",
)



# ============================================================
# PREVIEW ENGINE V5 — INTELLIGENT PREVIEW RESOLUTION
# ============================================================
# Two resolvers, one priority order:
#   _resolve_preview(state)            → wizard-time (operates on wizard state)
#   _resolve_campaign_preview(campaign) → runtime (operates on DB rows)
#
# Priority: Custom Upload → Selected Collection → Auto Preview →
#           Description Only → Disabled.
#
# Every subsystem MUST go through these resolvers. No direct reads of
# preview_media_file_id / preview_mode outside the resolver + the UI marks
# that show the admin the *current selection* (not the effective state).
# =====================================================================
# Compatible media types for preview (photo/video/animation only).
PREVIEW_COMPATIBLE_TYPES = frozenset({"photo", "video", "animation"})



# ============================================================
# WATCH_AD V2 (v26) — ADMIN: Ads Control (Short / Random / Three)
# ============================================================
WATCH_AD_AD_CONTROL_META: Dict[str, Dict[str, str]] = {
    WATCH_AD_AD_CONTROL_SHORT: {
        "label": "\U0001F3AF Short Ads (1)",
        "title": "Short Ads",
        "desc": ("One verified rewarded ad per session.\n"
                 "Prefers the shortest creative the provider\n"
                 "serves. The provider controls the actual ad\n"
                 "duration — rewards are always S2S-verified."),
    },
    WATCH_AD_AD_CONTROL_TWO: {
        "label": "2\uFE0F\u20E3 Two Ads (2)",
        "title": "Two Ads",
        "desc": ("Exactly 2 sequential verified rewarded ads\n"
                 "inside ONE Watch Ad session (one Telegram\n"
                 "button click). Ad 1 \u2192 reward \u2192 Ad 2 \u2192\n"
                 "reward \u2192 unlock."),
    },
    WATCH_AD_AD_CONTROL_RANDOM: {
        "label": "\U0001F3B2 Random Ads (1\u20133)",
        "title": "Random Ads",
        "desc": ("The required number of verified rewarded ads\n"
                 "is randomized SERVER-SIDE per session\n"
                 f"(1\u2013{WATCH_AD_RANDOM_MAX}). The frontend can\n"
                 "never choose or influence the count."),
    },
    WATCH_AD_AD_CONTROL_THREE: {
        "label": "3\uFE0F\u20E3 Three Ads (3)",
        "title": "Three Ads",
        "desc": ("Exactly 3 sequential verified rewarded ads\n"
                 "inside ONE Watch Ad session (one Telegram\n"
                 "button click). Ad 1 \u2192 reward \u2192 Ad 2 \u2192\n"
                 "reward \u2192 Ad 3 \u2192 reward \u2192 unlock."),
    },
}



# ---------- RECENT FILES PANEL ----------
RECENT_PAGE_SIZE = 8

RECENT_SORT_LABELS: Dict[str, str] = {
    "newest": "Newest",
    "oldest": "Oldest",
    "largest": "Largest",
    "downloads": "Most Downloaded",
}



# ============================================================
# WATCH_AD (v25) — MINI APP HTTP SERVER (same process / same codebase)
# ============================================================
# THE single Watch Ads Mini App served by the SAME Python application:
#   Telegram bot handlers            (python-telegram-bot, unchanged)
#   Existing Access Engine           (unchanged, single authorization layer)
#   Existing SQLite DB               (db — shared, ONE database)
#   Mini App HTTP routes             (aiohttp, same event loop)
#     GET  /watch-ad/<token>         — Mini App page (Telegram WebApp + admin
#                                      Monetag SDK, ymid = session token)
#     POST /api/watch-ad/status      — identity-verified session status poll
#     GET  /api/watch-ad/postback    — Monetag S2S reward verification
#     GET  /healthz                  — liveness probe
# The frontend is NEVER authoritative: reward=true / unlocked=true /
# JavaScript state / localStorage are never trusted. The ONLY unlock signal
# is the Monetag server-side postback (ymid -> session -> user+payload
# binding), validated inside process_watch_ad_reward.
#
# Production: the port (MINI_APP_PORT, default 8080) sits behind a reverse
# proxy (Nginx / Caddy / Cloudflare) that terminates HTTPS for the public
# domain configured in Settings → 🎬 Watch Ads Settings → 🌐 Website.
# ============================================================

# Runtime handle for the Mini App web server (aiohttp runner + site).
_mini_app_runner = None

_mini_app_site = None

# The bot instance (passed explicitly from post_init — never a global crawl).
_mini_app_bot = None

# Simple in-memory rate limit for status polling (per-token last-allowed ts).
_wad_status_ratelimit: Dict[str, float] = {}



# WATCH_AD V5 (§34): the Mini App's display-only lifecycle events. The
# frontend reports ad_start / ad_finish / reward_wait / next_ad so the
# production log shows the REAL ad sequence (which ad ran, when the provider
# SDK finished, how long verification waited, when the app advanced).
# SECURITY MODEL — unchanged: these events NEVER touch reward state, never
# create sessions, never influence access. Only the Monetag S2S postback
# (process_watch_ad_reward) may advance completed_ads. Identity is verified
# exactly like the status endpoint (initData HMAC + owner match).
_WATCH_AD_AD_EVENT_TYPES = frozenset({
    "ad_start", "ad_finish", "next_ad", "reward_wait"})

_WATCH_AD_AD_EVENT_CODES = {
    "ad_start": "WATCH_AD_AD_START",
    "ad_finish": "WATCH_AD_AD_FINISH",
    "next_ad": "WATCH_AD_NEXT_AD",
    "reward_wait": "WATCH_AD_REWARD_WAIT",
}



# ============================================================
# WEBSITE PHASE 3 — web presentation wiring (deps only, NO logic)
# ============================================================
# The Website presentation layer lives in app/web/site/*; this section
# only injects the EXISTING singletons at request time (late binding —
# the same Database, the same Access Engine, the same network registry).
# The website_enabled flag is checked in the PRESENTATION handlers only —
# never inside the Access Engine, never on Telegram-facing endpoints.

# Brief cache of decrypted ACTIVE network bot tokens for multi-token
# Mini App initData validation (avoid per-request decryption; tokens are
# NEVER logged and NEVER exposed in responses).
_website_net_token_cache: Dict[str, Any] = {"ts": 0.0, "tokens": []}

_WEBSITE_NET_TOKEN_CACHE_TTL: float = 60.0


# ============================================================
# v37 (bot-8 A13): CALLBACK rapid-click idempotency guard.
# Telegram clients can deliver the SAME callback twice when the user
# double-taps (observed in bot-8: ctl:fdb twice within 24ms;
# ctl:fdb:restart 2s apart). For the state-changing/expensive action
# prefixes below, an identical (user, callback) pair arriving within
# _CB_DEBOUNCE_SECONDS is answered honestly ("Already processing...")
# and skipped — no duplicate restart, no duplicate wizard-state churn.
# Pure navigation (panel:, nreg:, pl:...) is intentionally NOT debounced:
# re-rendering is cheap and idempotent. Lives in state.py so the REBOUND
# on_callback resolves it through the shared namespace globals.
#
# b10 (bot-10 §6): the guard was EXTENDED with exact-shape patterns —
# prefix matching cannot separate `nbot:<id>` (cheap read-only navigation
# that must stay undebounced) from `nbot:<id>:enable|disable|remove|
# replace` (state-changing; the bot-10 log showed three nbot:1:enable
# callbacks within ~500ms ALL executing). dg:verify is now debounced as
# a state-changing verification trigger; the +5 DELIVERY_READY award it
# may fire stays INDEPENDENTLY idempotent (ledger idempotency key —
# defense in depth, not a replacement). The predicate
# _cb_should_debounce lives here (state.py) for the same namespace
# reason as _debounced: callbacks.py's REBOUND on_callback cannot see
# callbacks.py module constants — it resolves names through the shared
# runtime namespace, of which this module is the foundation.
# ============================================================
_CB_DEBOUNCE_SECONDS = 1.2
_CB_DEBOUNCE_PREFIXES = (
    "gpl:gen:",         # mint a new Global Link (DB row per click)
    "gpl:create:",      # BOT-11 §16/§26 (B11-B): targeted mint (DB row
                        # per click; a per-user 2s mint guard in
                        # network_ui backs this up)
    "ctl:fdb:restart",  # restarts the FDB client + probe
    "ctl:managed:create",
    "ctl:managed:rotate",
    "nbc:cancel:", "nbc:pause:", "nbc:resume:",
)
# b10 §6: exact-shape state-changing actions (compiled once). Read-only
# navigation stays OUT: `nbot:<id>` (bot detail view), `panel:*`,
# `pl:*`, `nreg:back`, `dg:main`/`dg:bot:<id>` views etc.
_CB_DEBOUNCE_PATTERNS = (
    re.compile(r"^nbot:\d+:(enable|disable|remove|replace)$"),
    re.compile(r"^dg:(setup|new|existing|verify):\d+$"),
    re.compile(r"^ncreate:start$"),
    re.compile(r"^nmg:cancel$"),
    re.compile(r"^ctl:fdb:(add|change)$"),  # arms FDB token input
    re.compile(r"^nreg:token$"),            # arms token input
    # b10 §8 (B10-B2): the admin "Apply Main App Link to All Registered
    # Bots" action iterates every ACTIVE network bot and calls
    # setChatMenuButton on each — a state-changing Telegram-side bulk
    # operation (double-tap must not run it twice).
    re.compile(r"^net:miniapp$"),
    # BOT-11 §1 (B11-B): the admin "Refresh Bot Capabilities" action
    # calls getMe on every ACTIVE registered bot through the worker
    # clients and persists can_manage_bots — a Telegram-side bulk
    # operation (double-tap must not run it twice).
    re.compile(r"^net:caps$"),
)
_cb_last_seen: dict = {}


def _cb_should_debounce(data: str) -> bool:
    """True when this callback_data is a state-changing action that the
    rapid-click guard covers: the v37 A13 prefixes PLUS the b10 §6
    exact-shape patterns. Pure navigation is never debounced. Never
    raises — a guard failure must never break UX."""
    try:
        d = str(data or "")
        if d.startswith(_CB_DEBOUNCE_PREFIXES):
            return True
        for rx in _CB_DEBOUNCE_PATTERNS:
            if rx.match(d):
                return True
        return False
    except Exception:  # noqa: BLE001
        return False


def _debounced(user_id: int, data: str) -> bool:
    """True when this exact (user, callback) was seen within the window.
    Never raises; bounded memory (entries pruned opportunistically)."""
    try:
        key = (int(user_id), str(data)[:80])
        now = time.time()
        # opportunistic prune (the map stays tiny in practice — one entry
        # per distinct recent action per user)
        if len(_cb_last_seen) > 512:
            for k in [k for k, v in _cb_last_seen.items()
                      if now - v > _CB_DEBOUNCE_SECONDS * 4]:
                _cb_last_seen.pop(k, None)
        last = _cb_last_seen.get(key)
        _cb_last_seen[key] = now
        return last is not None and (now - last) < _CB_DEBOUNCE_SECONDS
    except Exception:  # noqa: BLE001 — the guard itself must never break UX
        return False


# WEBSITE PHASE 4: the Media Gateway singleton (Phase 1 media stack with
# the PRODUCTION recovery wiring + the shared bounded streaming cache +
# the gateway). Built ONCE per process on first use; a construction
# failure is sticky (streaming then reports honestly unavailable).
_website_gateway_singleton: Optional[Any] = None

_website_gateway_failed: bool = False



# ============================================================
# ============================================================
# NETWORK PLATFORM (v29) — Phase 8 → Network wiring
# ============================================================
# ============================================================
# ONE CENTRAL PLATFORM + SHARED BUSINESS LOGIC + MANY BOT EXECUTION
# CONTEXTS (spec §89). The services live in app/network/*; this section
# wires them into the bot: singleton instances, token validation
# transport, worker applications with SHARED handlers, the network
# source-copy delivery transport, Global Payload Link routing, the
# point-unlock callback, the My Network user panel, the admin Network
# Control Center, the Network Broadcast Center, and lifecycle hooks.
# ============================================================

# --- service singletons (created after DB connect in post_init) ---
_net_vault: Optional[CredentialVault] = None

_net_registry: Optional[_BotRegistryService] = None

_net_points: Optional[_PointService] = None

_net_router: Optional[_NetworkRouter] = None

_net_links: Optional[_GlobalPayloadLinks] = None

_net_broadcast: Optional[_NetworkBroadcastEngine] = None

_net_workers: Optional[_BotWorkerManager] = None

net_health_task: Optional[asyncio.Task] = None

_MAIN_BOT_TG_ID: Optional[int] = None  # the main bot's telegram id (post_init)

# MANAGED BOTS v37 (Task 8): the main bot's own User object captured at
# startup (post_init get_me) — the authoritative source for the truthful
# User.can_manage_bots diagnostic (capability_status in app/network/
# managed_bots.py refreshes it via context.bot.get_me() when available).
_MAIN_BOT_ME: Optional[Any] = None



# ----------------------------------------------------------------------
# NETWORK worker application — SAME shared business logic (spec §11/§12).
# The main bot keeps run_polling; workers use the PTB manual lifecycle.
# ----------------------------------------------------------------------
# User-safe callback prefixes allowed inside NETWORK workers. Anything
# else (admin panels, storage management, indexing, settings...) must be
# performed in the MAIN bot (spec §63) — fail-closed here.
# WS-C callback-integrity fix (spec §5/§42): the worker guard is
# `data.startswith(_NET_USER_CALLBACK_PREFIXES)` (app/network/lifecycle.py),
# so an entry must match the button's callback_data VERBATIM.
#   * preview_retrieve / coclose / rngclose are EXACT-match buttons (no
#     payload after the prefix) — the previous "xxx:" spellings never matched
#     them, so those user-facing buttons answered "This action is managed in
#     the main bot." inside network workers (orphan buttons, the §5 class).
#   * recentsearch:/plsclear: were dead entries matching no button at all
#     (their panels are admin-only and excluded from workers per §63) —
#     removed instead of keeping unreachable allow-list rows.
_NET_USER_CALLBACK_PREFIXES = (
    "verify:", "wad:", "wadcheck:", "wadhow:",
    "refcheck:", "refhow:", "refwatch:",
    "copy:", "retrieve:", "preview_retrieve", "retryfile:",
    "comenu:", "cobrowse:", "cocopy:", "cofile:", "coldl:", "coclose",
    "colsum:",
    "rngmenu:", "rngbrowse:", "rngcopy:", "rngdl:", "rngfile:", "rngclose",
    "recentpage:", "recentsort:", "start_home",
    "plpage:", "plsearch:", "plsback:", "plsdetail:",
    "pldetail:", "linkpreview:",
    NET_PT_UNLOCK_CB, NET_PTS_CB, NET_BOT_CB, NET_REG_CB,
    # FILE DELIVERY v34 (spec §72-§73): the Delivery Group wizard and the
    # Create Network Bot wizard work in network bots too (My Network is
    # shared); owner checks run inside the handlers.
    NET_DG_CB, NET_CREATE_CB,
    # MANAGED BOTS v37 (Task 8): the managed create flow's Cancel/Back is
    # user-facing (a stale inline Cancel button can be tapped inside a
    # network worker — it clears state + renders My Network there).
    NET_MANAGED_CB,
)



if __name__ == "__main__":
    main()
